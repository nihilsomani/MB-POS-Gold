import pandas as pd
import numpy as np
import os
import json
import time
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
import logging
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class AccumulationDistributionScanner:
    def __init__(self, api_key: str, access_token: str, cache_file: str = "nse_instruments_cache.json"):
        """
        Initialize the scanner with Kite Connect API
        
        Args:
            api_key: Zerodha API key
            access_token: Zerodha access token
            cache_file: File to cache NSE instrument tokens
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.cache_file = cache_file
        self.instruments_cache = {}
        self.nifty_token = None
        self.load_instruments_cache()
        
    def load_instruments_cache(self):
        """Load or create instruments cache"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f:
                    cache_data = json.load(f)
                    # Check if cache is recent (less than 1 day old)
                    cache_time = datetime.fromisoformat(cache_data.get('timestamp', '1970-01-01'))
                    if datetime.now() - cache_time < timedelta(days=1):
                        self.instruments_cache = cache_data.get('instruments', {})
                        self.nifty_token = cache_data.get('nifty_token')
                        logging.info(f"Loaded {len(self.instruments_cache)} instruments from cache")
                        return
            
            # Refresh cache if old or doesn't exist
            self.refresh_instruments_cache()
            
        except Exception as e:
            logging.error(f"Error loading cache: {e}")
            self.refresh_instruments_cache()
    
    def refresh_instruments_cache(self):
        """Refresh instruments cache from Kite API"""
        try:
            logging.info("Refreshing instruments cache...")
            instruments = self.kite.instruments("NSE")
            
            for instrument in instruments:
                symbol = instrument['tradingsymbol']
                self.instruments_cache[symbol] = {
                    'instrument_token': instrument['instrument_token'],
                    'exchange': instrument['exchange'],
                    'name': instrument['name']
                }
                
                # Cache NIFTY 50 token for relative strength calculation
                if symbol == 'NIFTY 500':
                    self.nifty_token = instrument['instrument_token']
            
            # Save cache
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'instruments': self.instruments_cache,
                'nifty_token': self.nifty_token
            }
            
            with open(self.cache_file, 'w') as f:
                json.dump(cache_data, f)
                
            logging.info(f"Cached {len(self.instruments_cache)} instruments")
            
        except Exception as e:
            logging.error(f"Error refreshing cache: {e}")
            raise
    
    def get_historical_data(self, instrument_token: int, days: int = 900) -> pd.DataFrame:
        """
        Fetch historical data for given instrument
        
        Args:
            instrument_token: Kite instrument token
            days: Number of days of historical data
            
        Returns:
            DataFrame with OHLCV data
        """
        try:
            to_date = datetime.now()
            from_date = to_date - timedelta(days=days)
            
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date'])
                df.set_index('date', inplace=True)
                df.sort_index(inplace=True)
            
            return df
            
        except Exception as e:
            logging.error(f"Error fetching data for token {instrument_token}: {e}")
            return pd.DataFrame()
    
    def calculate_moving_average(self, data: pd.Series, period: int) -> pd.Series:
        """Calculate simple moving average"""
        return data.rolling(window=period, min_periods=1).mean()
    
    def calculate_ema(self, data: pd.Series, period: int) -> pd.Series:
        """Calculate exponential moving average"""
        return data.ewm(span=period, adjust=False).mean()
    
    def calculate_relative_strength(self, stock_df: pd.DataFrame, nifty_df: pd.DataFrame) -> pd.Series:
        """
        Calculate relative strength vs NIFTY 50
        
        Args:
            stock_df: Stock price data
            nifty_df: NIFTY 50 price data
            
        Returns:
            Relative strength series
        """
        try:
            # Align dates
            common_dates = stock_df.index.intersection(nifty_df.index)
            stock_aligned = stock_df.loc[common_dates, 'close']
            nifty_aligned = nifty_df.loc[common_dates, 'close']
            
            # Calculate percentage change from base
            stock_base = stock_aligned.iloc[0]
            nifty_base = nifty_aligned.iloc[0]
            
            stock_pct = (stock_aligned / stock_base - 1) * 100
            nifty_pct = (nifty_aligned / nifty_base - 1) * 100
            
            relative_strength = stock_pct - nifty_pct
            
            return relative_strength.reindex(stock_df.index)
            
        except Exception as e:
            logging.error(f"Error calculating relative strength: {e}")
            return pd.Series(index=stock_df.index, dtype=float)
    
    def calculate_adaptive_volume_threshold(self, df: pd.DataFrame, lookback: int = 20) -> float:
        """
        Calculate adaptive volume threshold based on market volatility
        
        Args:
            df: OHLCV DataFrame
            lookback: Number of days to look back for volatility calculation
            
        Returns:
            Adaptive Z-score threshold (lower for volatile markets, higher for stable markets)
        """
        if len(df) < lookback:
            return 1.5  # Default threshold
            
        # Calculate volume volatility (coefficient of variation)
        recent_volume = df['volume'].tail(lookback)
        volume_cv = recent_volume.std() / recent_volume.mean()
        
        # Calculate price volatility
        recent_returns = df['close'].tail(lookback).pct_change().dropna()
        price_volatility = recent_returns.std()
        
        # Adjust threshold based on volatility
        # Higher volatility = lower threshold (more sensitive)
        # Lower volatility = higher threshold (less sensitive)
        
        if volume_cv > 0.8 or price_volatility > 0.03:  # High volatility
            threshold = 1.0  # More sensitive
        elif volume_cv > 0.5 or price_volatility > 0.02:  # Medium volatility
            threshold = 1.25  # Moderately sensitive
        else:  # Low volatility
            threshold = 1.5  # Less sensitive
        
        # Further refine based on market regime
        market_regime = self.detect_market_regime(df)
        
        if market_regime == 'sideways':
            threshold *= 0.8  # More sensitive in sideways markets
        elif market_regime == 'volatile':
            threshold *= 0.7  # Even more sensitive in volatile markets
        elif market_regime == 'trending':
            threshold *= 1.1  # Less sensitive in trending markets
            
        return max(0.5, min(2.0, threshold))  # Clamp between 0.5 and 2.0
    
    def detect_market_regime(self, df: pd.DataFrame, lookback: int = 20) -> str:
        """
        Detect current market regime to further refine volume thresholds
        
        Args:
            df: OHLCV DataFrame
            lookback: Number of days to look back for regime detection
            
        Returns:
            Market regime: 'trending', 'sideways', 'volatile', or 'stable'
        """
        if len(df) < lookback:
            return 'stable'
            
        recent_df = df.tail(lookback)
        
        # Calculate price trend strength
        price_changes = recent_df['close'].pct_change().dropna()
        trend_strength = abs(price_changes.mean()) / price_changes.std()
        
        # Calculate volume consistency
        volume_cv = recent_df['volume'].std() / recent_df['volume'].mean()
        
        # Calculate price range consistency
        price_ranges = recent_df['high'] - recent_df['low']
        range_cv = price_ranges.std() / price_ranges.mean()
        
        # Determine regime
        if trend_strength > 0.5 and volume_cv < 0.6:
            return 'trending'
        elif trend_strength < 0.2 and volume_cv < 0.4:
            return 'sideways'
        elif volume_cv > 0.8 or range_cv > 0.8:
            return 'volatile'
        else:
            return 'stable'
    
    def identify_accumulation_distribution(self, df: pd.DataFrame) -> Dict:
        """
        Identify accumulation/distribution patterns using volume-price analysis
        
        Args:
            df: OHLCV DataFrame
            
        Returns:
            Dictionary with analysis results
        """
        if len(df) < 50:
            return {'pattern': 'insufficient_data', 'confidence': 0}
        
        # Calculate volume moving averages
        df['volume_ma_20'] = self.calculate_moving_average(df['volume'], 20)
        df['volume_ma_50'] = self.calculate_moving_average(df['volume'], 50)
        
        # Calculate price ranges and volume ratios
        df['high_low_range'] = df['high'] - df['low']
        df['volume_ratio'] = df['volume'] / df['volume_ma_20']
        df['close_position'] = (df['close'] - df['low']) / (df['high'] - df['low'])
        
        # Calculate adaptive volume threshold using Z-score instead of fixed ratio
        # Handle cases where standard deviation might be zero or very small
        volume_std = df['volume'].rolling(20).std()
        volume_std = volume_std.replace(0, volume_std.mean())  # Replace zeros with mean
        volume_std = volume_std.fillna(volume_std.mean())  # Fill NaN with mean
        
        df['volume_z'] = (df['volume'] - df['volume_ma_20']) / volume_std
        
        # Calculate adaptive threshold based on market volatility
        adaptive_threshold = self.calculate_adaptive_volume_threshold(df)
        
        # Recent data for analysis (last 20 days)
        recent_df = df.tail(20).copy()
        
        # Accumulation indicators - use adaptive Z-score threshold
        high_volume_days = recent_df['volume_z'] > adaptive_threshold
        narrow_ranges = recent_df['high_low_range'] < recent_df['high_low_range'].mean()
        closes_near_high = recent_df['close_position'] > 0.7
        
        accumulation_score = (
            high_volume_days.sum() * 0.4 +
            narrow_ranges.sum() * 0.3 +
            closes_near_high.sum() * 0.3
        ) / len(recent_df)
        
        # Distribution indicators
        wide_ranges = recent_df['high_low_range'] > recent_df['high_low_range'].mean() * 1.5
        closes_near_low = recent_df['close_position'] < 0.3
        declining_volume = recent_df['volume'].rolling(5).mean().iloc[-1] < recent_df['volume'].rolling(10).mean().iloc[-5]
        
        distribution_score = (
            high_volume_days.sum() * 0.3 +
            wide_ranges.sum() * 0.4 +
            closes_near_low.sum() * 0.3
        ) / len(recent_df)
        
        # Determine pattern
        if accumulation_score > 0.6:
            pattern = 'accumulation'
            confidence = min(accumulation_score, 1.0)
        elif distribution_score > 0.6:
            pattern = 'distribution'
            confidence = min(distribution_score, 1.0)
        else:
            pattern = 'neutral'
            confidence = abs(accumulation_score - distribution_score)
        
        return {
            'pattern': pattern,
            'confidence': confidence,
            'accumulation_score': accumulation_score,
            'distribution_score': distribution_score,
            'recent_volume_avg': recent_df['volume'].mean(),
            'volume_spike_days': high_volume_days.sum(),
            'volume_z_score_avg': recent_df['volume_z'].mean(),
            'volume_z_score_max': recent_df['volume_z'].max(),
            'volume_z_score_min': recent_df['volume_z'].min(),
            'adaptive_threshold_used': adaptive_threshold,  # Dynamic Z-score threshold used
            'volume_volatility_cv': recent_df['volume'].std() / recent_df['volume'].mean(),
            'price_volatility': recent_df['close'].pct_change().dropna().std(),
            'market_regime': self.detect_market_regime(df),
            'threshold_adjustment_factor': adaptive_threshold / 1.5  # How much threshold was adjusted
        }
    
    def analyze_wyckoff_phases(self, df: pd.DataFrame) -> Dict:
        """
        Analyze Wyckoff phases based on price and volume patterns
        
        Args:
            df: OHLCV DataFrame
            
        Returns:
            Dictionary with Wyckoff phase analysis
        """
        if len(df) < 100:
            return {'phase': 'insufficient_data', 'confidence': 0}
        
        # Calculate key levels
        df['sma_20'] = self.calculate_moving_average(df['close'], 20)
        df['sma_50'] = self.calculate_moving_average(df['close'], 50)
        df['volume_sma_20'] = self.calculate_moving_average(df['volume'], 20)
        
        recent_df = df.tail(50).copy()
        
        # Identify support and resistance levels
        highs = recent_df['high'].rolling(window=5, center=True).max()
        lows = recent_df['low'].rolling(window=5, center=True).min()
        
        resistance_levels = recent_df[recent_df['high'] == highs]['high'].unique()
        support_levels = recent_df[recent_df['low'] == lows]['low'].unique()
        
        current_price = df['close'].iloc[-1]
        
        # Phase identification logic
        price_trend = df['close'].tail(20).pct_change().mean()
        volume_trend = df['volume'].tail(20).pct_change().mean()
        
        # Recent price action relative to moving averages
        above_sma20 = current_price > df['sma_20'].iloc[-1]
        above_sma50 = current_price > df['sma_50'].iloc[-1]
        
        # Volume analysis - use adaptive Z-score threshold
        avg_volume = df['volume_sma_20'].iloc[-1]
        recent_volume = df['volume'].tail(5).mean()
        
        # Calculate volume Z-score for recent period
        recent_volume_std = df['volume'].tail(20).std()
        if recent_volume_std > 0:
            recent_volume_z = (recent_volume - avg_volume) / recent_volume_std
            volume_increase = recent_volume_z > 0.8  # Adaptive threshold (0.8 Z-score)
        else:
            volume_increase = recent_volume > avg_volume * 1.2  # Fallback to fixed ratio
        
        # Phase determination
        if price_trend > 0.01 and above_sma20 and above_sma50:
            if volume_increase:
                phase = 'phase_e_markup'
                confidence = 0.8
            else:
                phase = 'phase_d_early_markup'
                confidence = 0.6
        elif price_trend < -0.01 and not above_sma20:
            if volume_increase:
                phase = 'phase_e_markdown'
                confidence = 0.8
            else:
                phase = 'phase_d_early_markdown'
                confidence = 0.6
        elif abs(price_trend) < 0.005:
            if volume_increase and len(resistance_levels) > 2:
                phase = 'phase_b_accumulation_distribution'
                confidence = 0.7
            else:
                phase = 'phase_a_transition'
                confidence = 0.5
        else:
            phase = 'phase_c_test'
            confidence = 0.4
        
        return {
            'phase': phase,
            'confidence': confidence,
            'price_trend': price_trend,
            'volume_trend': volume_trend,
            'support_levels': len(support_levels),
            'resistance_levels': len(resistance_levels),
            'current_vs_sma20': (current_price / df['sma_20'].iloc[-1] - 1) * 100,
            'current_vs_sma50': (current_price / df['sma_50'].iloc[-1] - 1) * 100
        }
    
    def analyze_weinstein_stages(self, df: pd.DataFrame) -> Dict:
        """
        Analyze Stan Weinstein's 4 stages
        
        Args:
            df: OHLCV DataFrame
            
        Returns:
            Dictionary with stage analysis
        """
        if len(df) < 150:  # Need ~30 weeks of data
            return {'stage': 'insufficient_data', 'confidence': 0}
        
        # Calculate 30-period moving average (weekly equivalent for daily data: 30*5 = 150 days, use 30 for daily)
        df['ma_30'] = self.calculate_moving_average(df['close'], 30)
        
        current_price = df['close'].iloc[-1]
        ma_30_current = df['ma_30'].iloc[-1]
        
        # Price position relative to 30MA
        above_ma30 = current_price > ma_30_current
        
        # Recent price action around 30MA
        recent_df = df.tail(30).copy()
        crosses_above = (recent_df['close'] > recent_df['ma_30']).sum()
        crosses_below = (recent_df['close'] < recent_df['ma_30']).sum()
        
        # Volume analysis
        recent_volume = recent_df['volume'].mean()
        long_term_volume = df['volume'].tail(90).mean()
        volume_increase = recent_volume > long_term_volume * 1.1
        
        # Trend analysis
        ma_30_slope = (df['ma_30'].iloc[-1] - df['ma_30'].iloc[-10]) / df['ma_30'].iloc[-10]
        price_slope = (df['close'].iloc[-1] - df['close'].iloc[-20]) / df['close'].iloc[-20]
        
        # Stage determination
        if above_ma30 and ma_30_slope > 0.02 and price_slope > 0.05:
            stage = 'stage_2_advancing'
            confidence = 0.9
        elif not above_ma30 and ma_30_slope < -0.02 and price_slope < -0.05:
            stage = 'stage_4_declining'
            confidence = 0.9
        elif crosses_above > 15 and crosses_below > 10:  # Oscillating around MA
            if df['close'].iloc[-30:].max() > df['close'].iloc[-60:-30].max():
                stage = 'stage_3_distribution'
                confidence = 0.7
            else:
                stage = 'stage_1_accumulation'
                confidence = 0.7
        else:
            # Transition stages
            if above_ma30 and ma_30_slope > 0:
                stage = 'stage_1_to_2_transition'
                confidence = 0.5
            elif not above_ma30 and ma_30_slope < 0:
                stage = 'stage_3_to_4_transition'
                confidence = 0.5
            else:
                stage = 'stage_unclear'
                confidence = 0.3
        
        return {
            'stage': stage,
            'confidence': confidence,
            'price_vs_ma30': (current_price / ma_30_current - 1) * 100,
            'ma30_slope': ma_30_slope * 100,
            'price_slope_20d': price_slope * 100,
            'volume_vs_avg': (recent_volume / long_term_volume - 1) * 100,
            'days_above_ma30': crosses_above,
            'days_below_ma30': crosses_below
        }
    
    def calculate_volume_analysis(self, df: pd.DataFrame) -> Dict:
        """
        Advanced volume analysis for accumulation/distribution
        
        Args:
            df: OHLCV DataFrame
            
        Returns:
            Dictionary with volume analysis
        """
        if len(df) < 50:
            return {'analysis': 'insufficient_data'}
        
        # Volume indicators
        df['volume_sma_20'] = self.calculate_moving_average(df['volume'], 20)
        df['volume_sma_50'] = self.calculate_moving_average(df['volume'], 50)
        
        # On Balance Volume (OBV)
        df['obv'] = 0
        for i in range(1, len(df)):
            if df['close'].iloc[i] > df['close'].iloc[i-1]:
                df['obv'].iloc[i] = df['obv'].iloc[i-1] + df['volume'].iloc[i]
            elif df['close'].iloc[i] < df['close'].iloc[i-1]:
                df['obv'].iloc[i] = df['obv'].iloc[i-1] - df['volume'].iloc[i]
            else:
                df['obv'].iloc[i] = df['obv'].iloc[i-1]
        
        # Volume Rate of Change
        df['volume_roc'] = df['volume'].pct_change(periods=10) * 100
        
        # Money Flow Index components
        df['typical_price'] = (df['high'] + df['low'] + df['close']) / 3
        df['money_flow'] = df['typical_price'] * df['volume']
        
        recent_df = df.tail(20)
        
        # Analysis
        volume_trend = recent_df['volume'].pct_change().mean()
        obv_trend = recent_df['obv'].pct_change().mean()
        
        # High volume, low price movement (accumulation/distribution sign)
        price_change = abs(recent_df['close'].pct_change().mean())
        volume_change = recent_df['volume'].pct_change().mean()
        
        divergence_score = volume_change / (price_change + 0.001)  # Avoid division by zero
        
        return {
            'volume_trend': volume_trend,
            'obv_trend': obv_trend,
            'divergence_score': divergence_score,
            'avg_volume_20d': recent_df['volume'].mean(),
            'volume_vs_50d_avg': (recent_df['volume'].mean() / df['volume_sma_50'].iloc[-1] - 1) * 100,
            'volume_spikes': (recent_df['volume'] > recent_df['volume'].mean() * 2).sum(),
            'current_obv': df['obv'].iloc[-1],
            'obv_change_20d': (df['obv'].iloc[-1] / df['obv'].iloc[-21] - 1) * 100 if len(df) > 21 else 0
        }
    
    def generate_trading_signals(self, analysis_results: Dict) -> Dict:
        """
        Generate trading signals based on all analysis components
        
        Args:
            analysis_results: Combined analysis results
            
        Returns:
            Dictionary with trading signals and reasoning
        """
        signals = {
            'primary_signal': 'hold',
            'confidence': 0,
            'entry_signal': False,
            'exit_signal': False,
            'reasons': []
        }
        
        # Extract analysis components
        pattern = analysis_results.get('accumulation_distribution', {})
        wyckoff = analysis_results.get('wyckoff_analysis', {})
        weinstein = analysis_results.get('weinstein_analysis', {})
        volume = analysis_results.get('volume_analysis', {})
        relative_strength = analysis_results.get('relative_strength_current', 0)
        
        confidence_sum = 0
        signal_count = 0
        
        # Accumulation signals
        if pattern.get('pattern') == 'accumulation' and pattern.get('confidence', 0) > 0.6:
            signals['primary_signal'] = 'buy'
            signals['entry_signal'] = True
            signals['reasons'].append(f"Strong accumulation pattern detected (confidence: {pattern.get('confidence', 0):.2f})")
            confidence_sum += pattern.get('confidence', 0) * 0.3
            signal_count += 1
        
        # Wyckoff phase signals
        wyckoff_phase = wyckoff.get('phase', '')
        if 'accumulation' in wyckoff_phase or 'early_markup' in wyckoff_phase:
            if signals['primary_signal'] == 'hold':
                signals['primary_signal'] = 'buy'
            signals['entry_signal'] = True
            signals['reasons'].append(f"Wyckoff phase indicates buying opportunity: {wyckoff_phase}")
            confidence_sum += wyckoff.get('confidence', 0) * 0.25
            signal_count += 1
        elif 'distribution' in wyckoff_phase or 'markdown' in wyckoff_phase:
            signals['primary_signal'] = 'sell'
            signals['exit_signal'] = True
            signals['reasons'].append(f"Wyckoff phase indicates selling opportunity: {wyckoff_phase}")
            confidence_sum += wyckoff.get('confidence', 0) * 0.25
            signal_count += 1
        
        # Weinstein stage signals
        weinstein_stage = weinstein.get('stage', '')
        if 'stage_1' in weinstein_stage or 'stage_2' in weinstein_stage:
            if 'stage_2' in weinstein_stage:
                signals['reasons'].append(f"Weinstein Stage 2 (Advancing): {weinstein_stage}")
                if signals['primary_signal'] == 'hold':
                    signals['primary_signal'] = 'buy'
                confidence_sum += weinstein.get('confidence', 0) * 0.2
                signal_count += 1
            else:
                signals['reasons'].append(f"Weinstein Stage 1 (Accumulation): {weinstein_stage}")
        elif 'stage_4' in weinstein_stage:
            signals['primary_signal'] = 'sell'
            signals['exit_signal'] = True
            signals['reasons'].append(f"Weinstein Stage 4 (Declining): {weinstein_stage}")
            confidence_sum += weinstein.get('confidence', 0) * 0.2
            signal_count += 1
        
        # Volume confirmation
        if volume.get('obv_trend', 0) > 0.02 and volume.get('volume_trend', 0) > 0.1:
            if signals['primary_signal'] in ['buy', 'hold']:
                signals['reasons'].append("Volume confirms accumulation (OBV and volume trending up)")
                confidence_sum += 0.15
                signal_count += 1
        elif volume.get('obv_trend', 0) < -0.02:
            if signals['primary_signal'] != 'sell':
                signals['exit_signal'] = True
            signals['reasons'].append("Volume indicates distribution (OBV trending down)")
        
        # Relative strength filter
        if relative_strength > 5:
            signals['reasons'].append(f"Strong relative strength vs NIFTY: {relative_strength:.1f}%")
            if signals['primary_signal'] == 'buy':
                confidence_sum += 0.1
        elif relative_strength < -10:
            signals['reasons'].append(f"Weak relative strength vs NIFTY: {relative_strength:.1f}%")
            if signals['primary_signal'] == 'buy':
                confidence_sum -= 0.1
        
        # Calculate final confidence
        if signal_count > 0:
            signals['confidence'] = min(confidence_sum / signal_count, 1.0)
        else:
            signals['confidence'] = 0.3
        
        # Additional contextual reasons
        if not signals['reasons']:
            signals['reasons'].append("No clear accumulation or distribution pattern detected")
        
        return signals
    
    def analyze_symbol(self, symbol: str) -> Dict:
        """
        Comprehensive analysis for a single symbol
        
        Args:
            symbol: Stock symbol to analyze
            
        Returns:
            Dictionary with complete analysis results
        """
        try:
            # Get instrument token
            if symbol not in self.instruments_cache:
                return {
                    'symbol': symbol,
                    'status': 'error',
                    'reason': 'Symbol not found in NSE instruments',
                    'timestamp': datetime.now().isoformat()
                }
            
            instrument_token = self.instruments_cache[symbol]['instrument_token']
            
            # Fetch historical data
            df = self.get_historical_data(instrument_token, days=365)
            if df.empty:
                return {
                    'symbol': symbol,
                    'status': 'error',
                    'reason': 'Unable to fetch historical data',
                    'timestamp': datetime.now().isoformat()
                }
            
            # Fetch NIFTY data for relative strength
            nifty_df = pd.DataFrame()
            if self.nifty_token:
                nifty_df = self.get_historical_data(self.nifty_token, days=365)
            
            # Perform all analyses
            accumulation_distribution = self.identify_accumulation_distribution(df)
            wyckoff_analysis = self.analyze_wyckoff_phases(df)
            weinstein_analysis = self.analyze_weinstein_stages(df)
            volume_analysis = self.calculate_volume_analysis(df)
            
            # Calculate relative strength
            relative_strength_series = pd.Series(dtype=float)
            if not nifty_df.empty:
                relative_strength_series = self.calculate_relative_strength(df, nifty_df)
            
            # Combine all analysis results
            analysis_results = {
                'accumulation_distribution': accumulation_distribution,
                'wyckoff_analysis': wyckoff_analysis,
                'weinstein_analysis': weinstein_analysis,
                'volume_analysis': volume_analysis,
                'relative_strength_current': relative_strength_series.iloc[-1] if len(relative_strength_series) > 0 else 0,
                'relative_strength_avg_30d': relative_strength_series.tail(30).mean() if len(relative_strength_series) > 30 else 0
            }
            
            # Generate trading signals
            trading_signals = self.generate_trading_signals(analysis_results)
            
            # Compile final results
            results = {
                'symbol': symbol,
                'status': 'success',
                'timestamp': datetime.now().isoformat(),
                'current_price': df['close'].iloc[-1],
                'price_change_1d': (df['close'].iloc[-1] / df['close'].iloc[-2] - 1) * 100 if len(df) > 1 else 0,
                'price_change_5d': (df['close'].iloc[-1] / df['close'].iloc[-6] - 1) * 100 if len(df) > 5 else 0,
                'price_change_20d': (df['close'].iloc[-1] / df['close'].iloc[-21] - 1) * 100 if len(df) > 20 else 0,
                'volume_current': df['volume'].iloc[-1],
                'volume_avg_20d': df['volume'].tail(20).mean(),
                
                # Pattern Analysis
                'accumulation_distribution_pattern': accumulation_distribution.get('pattern', 'unknown'),
                'ad_confidence': accumulation_distribution.get('confidence', 0),
                'ad_accumulation_score': accumulation_distribution.get('accumulation_score', 0),
                'ad_distribution_score': accumulation_distribution.get('distribution_score', 0),
                
                # Wyckoff Analysis
                'wyckoff_phase': wyckoff_analysis.get('phase', 'unknown'),
                'wyckoff_confidence': wyckoff_analysis.get('confidence', 0),
                'price_vs_sma20': wyckoff_analysis.get('current_vs_sma20', 0),
                'price_vs_sma50': wyckoff_analysis.get('current_vs_sma50', 0),
                
                # Weinstein Analysis
                'weinstein_stage': weinstein_analysis.get('stage', 'unknown'),
                'weinstein_confidence': weinstein_analysis.get('confidence', 0),
                'price_vs_ma30': weinstein_analysis.get('price_vs_ma30', 0),
                'ma30_slope': weinstein_analysis.get('ma30_slope', 0),
                
                # Volume Analysis
                'obv_trend': volume_analysis.get('obv_trend', 0),
                'volume_trend': volume_analysis.get('volume_trend', 0),
                'volume_divergence_score': volume_analysis.get('divergence_score', 0),
                'volume_vs_50d_avg': volume_analysis.get('volume_vs_50d_avg', 0),
                
                # Relative Strength
                'relative_strength_current': analysis_results['relative_strength_current'],
                'relative_strength_30d_avg': analysis_results['relative_strength_avg_30d'],
                
                # Trading Signals
                'primary_signal': trading_signals['primary_signal'],
                'signal_confidence': trading_signals['confidence'],
                'entry_signal': trading_signals['entry_signal'],
                'exit_signal': trading_signals['exit_signal'],
                'reasons': '; '.join(trading_signals['reasons']),
                
                # Summary
                'overall_bias': self.determine_overall_bias(analysis_results),
                'risk_level': self.assess_risk_level(analysis_results),
                'recommendation': self.generate_recommendation(trading_signals, analysis_results)
            }
            
            return results
            
        except Exception as e:
            logging.error(f"Error analyzing {symbol}: {e}")
            return {
                'symbol': symbol,
                'status': 'error',
                'reason': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def determine_overall_bias(self, analysis_results: Dict) -> str:
        """Determine overall market bias for the stock"""
        accumulation_score = analysis_results.get('accumulation_distribution', {}).get('accumulation_score', 0)
        distribution_score = analysis_results.get('accumulation_distribution', {}).get('distribution_score', 0)
        
        wyckoff_phase = analysis_results.get('wyckoff_analysis', {}).get('phase', '')
        weinstein_stage = analysis_results.get('weinstein_analysis', {}).get('stage', '')
        
        bullish_indicators = 0
        bearish_indicators = 0
        
        if accumulation_score > 0.6:
            bullish_indicators += 2
        elif distribution_score > 0.6:
            bearish_indicators += 2
        
        if 'accumulation' in wyckoff_phase or 'markup' in wyckoff_phase:
            bullish_indicators += 1
        elif 'distribution' in wyckoff_phase or 'markdown' in wyckoff_phase:
            bearish_indicators += 1
        
        if 'stage_1' in weinstein_stage or 'stage_2' in weinstein_stage:
            bullish_indicators += 1
        elif 'stage_3' in weinstein_stage or 'stage_4' in weinstein_stage:
            bearish_indicators += 1
        
        if bullish_indicators > bearish_indicators + 1:
            return 'bullish'
        elif bearish_indicators > bullish_indicators + 1:
            return 'bearish'
        else:
            return 'neutral'
    
    def assess_risk_level(self, analysis_results: Dict) -> str:
        """Assess risk level based on analysis"""
        weinstein_stage = analysis_results.get('weinstein_analysis', {}).get('stage', '')
        wyckoff_phase = analysis_results.get('wyckoff_analysis', {}).get('phase', '')
        relative_strength = analysis_results.get('relative_strength_current', 0)
        
        risk_score = 0
        
        # Stage-based risk
        if 'stage_4' in weinstein_stage:
            risk_score += 3
        elif 'stage_3' in weinstein_stage:
            risk_score += 2
        elif 'stage_2' in weinstein_stage:
            risk_score += 0
        elif 'stage_1' in weinstein_stage:
            risk_score += 1
        
        # Phase-based risk
        if 'markdown' in wyckoff_phase:
            risk_score += 2
        elif 'distribution' in wyckoff_phase:
            risk_score += 1
        
        # Relative strength risk
        if relative_strength < -15:
            risk_score += 2
        elif relative_strength < -5:
            risk_score += 1
        
        if risk_score >= 4:
            return 'high'
        elif risk_score >= 2:
            return 'medium'
        else:
            return 'low'
    
    def generate_recommendation(self, trading_signals: Dict, analysis_results: Dict) -> str:
        """Generate final recommendation"""
        signal = trading_signals['primary_signal']
        confidence = trading_signals['confidence']
        
        if signal == 'buy' and confidence > 0.7:
            return 'STRONG BUY'
        elif signal == 'buy' and confidence > 0.5:
            return 'BUY'
        elif signal == 'sell' and confidence > 0.7:
            return 'STRONG SELL'
        elif signal == 'sell' and confidence > 0.5:
            return 'SELL'
        elif trading_signals['exit_signal']:
            return 'CONSIDER SELLING'
        elif trading_signals['entry_signal']:
            return 'CONSIDER BUYING'
        else:
            return 'HOLD'
    
    def scan_symbols_from_csv(self, csv_file: str, output_file: str = None) -> pd.DataFrame:
        """
        Scan all symbols from CSV file and generate comprehensive report
        
        Args:
            csv_file: Path to CSV file containing symbols
            output_file: Output CSV file path (optional)
            
        Returns:
            DataFrame with analysis results
        """
        try:
            # Read symbols from CSV
            symbols_df = pd.read_csv(csv_file)
            if 'Symbol' not in symbols_df.columns:
                raise ValueError("CSV file must contain 'Symbol' column")
            
            symbols = symbols_df['Symbol'].tolist()
            logging.info(f"Found {len(symbols)} symbols to analyze")
            
            results = []
            
            for i, symbol in enumerate(symbols, 1):
                logging.info(f"Analyzing {symbol} ({i}/{len(symbols)})")
                
                try:
                    result = self.analyze_symbol(symbol)
                    results.append(result)
                    
                    # Add small delay to avoid rate limiting
                    time.sleep(0.5)
                    
                except Exception as e:
                    logging.error(f"Error analyzing {symbol}: {e}")
                    results.append({
                        'symbol': symbol,
                        'status': 'error',
                        'reason': str(e),
                        'timestamp': datetime.now().isoformat()
                    })
            
            # Convert to DataFrame
            results_df = pd.DataFrame(results)
            
            # Sort by signal confidence and recommendation
            priority_order = {'STRONG BUY': 6, 'BUY': 5, 'CONSIDER BUYING': 4, 
                            'HOLD': 3, 'CONSIDER SELLING': 2, 'SELL': 1, 'STRONG SELL': 0}
            
            results_df['recommendation_priority'] = results_df.get('recommendation', 'HOLD').map(priority_order)
            results_df = results_df.sort_values(['recommendation_priority', 'signal_confidence'], 
                                              ascending=[False, False])
            results_df = results_df.drop('recommendation_priority', axis=1)
            
            # Save to CSV if output file specified
            if output_file:
                results_df.to_csv(output_file, index=False)
                logging.info(f"Results saved to {output_file}")
            
            return results_df
            
        except Exception as e:
            logging.error(f"Error in scan_symbols_from_csv: {e}")
            raise
    
    def generate_summary_report(self, results_df: pd.DataFrame) -> Dict:
        """
        Generate summary statistics from scan results
        
        Args:
            results_df: DataFrame with analysis results
            
        Returns:
            Dictionary with summary statistics
        """
        successful_analyses = results_df[results_df['status'] == 'success']
        
        if len(successful_analyses) == 0:
            return {'error': 'No successful analyses found'}
        
        summary = {
            'total_symbols': len(results_df),
            'successful_analyses': len(successful_analyses),
            'failed_analyses': len(results_df) - len(successful_analyses),
            
            # Signal distribution
            'buy_signals': len(successful_analyses[successful_analyses['primary_signal'] == 'buy']),
            'sell_signals': len(successful_analyses[successful_analyses['primary_signal'] == 'sell']),
            'hold_signals': len(successful_analyses[successful_analyses['primary_signal'] == 'hold']),
            
            # Recommendation distribution
            'strong_buy': len(successful_analyses[successful_analyses['recommendation'] == 'STRONG BUY']),
            'buy': len(successful_analyses[successful_analyses['recommendation'] == 'BUY']),
            'consider_buying': len(successful_analyses[successful_analyses['recommendation'] == 'CONSIDER BUYING']),
            'hold': len(successful_analyses[successful_analyses['recommendation'] == 'HOLD']),
            'consider_selling': len(successful_analyses[successful_analyses['recommendation'] == 'CONSIDER SELLING']),
            'sell': len(successful_analyses[successful_analyses['recommendation'] == 'SELL']),
            'strong_sell': len(successful_analyses[successful_analyses['recommendation'] == 'STRONG SELL']),
            
            # Pattern distribution
            'accumulation_patterns': len(successful_analyses[successful_analyses['accumulation_distribution_pattern'] == 'accumulation']),
            'distribution_patterns': len(successful_analyses[successful_analyses['accumulation_distribution_pattern'] == 'distribution']),
            'neutral_patterns': len(successful_analyses[successful_analyses['accumulation_distribution_pattern'] == 'neutral']),
            
            # Weinstein stage distribution
            'stage_1': len(successful_analyses[successful_analyses['weinstein_stage'].str.contains('stage_1', na=False)]),
            'stage_2': len(successful_analyses[successful_analyses['weinstein_stage'].str.contains('stage_2', na=False)]),
            'stage_3': len(successful_analyses[successful_analyses['weinstein_stage'].str.contains('stage_3', na=False)]),
            'stage_4': len(successful_analyses[successful_analyses['weinstein_stage'].str.contains('stage_4', na=False)]),
            
            # Average metrics
            'avg_signal_confidence': successful_analyses['signal_confidence'].mean(),
            'avg_relative_strength': successful_analyses['relative_strength_current'].mean(),
            'avg_volume_vs_avg': successful_analyses['volume_vs_50d_avg'].mean(),
            
            # Top performers
            'top_accumulation_scores': successful_analyses.nlargest(5, 'ad_accumulation_score')[['symbol', 'ad_accumulation_score']].to_dict('records'),
            'top_relative_strength': successful_analyses.nlargest(5, 'relative_strength_current')[['symbol', 'relative_strength_current']].to_dict('records'),
            'highest_confidence_signals': successful_analyses.nlargest(5, 'signal_confidence')[['symbol', 'primary_signal', 'signal_confidence']].to_dict('records')
        }
        
        return summary


def main():
    """
    Main function to run the scanner
    """
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"  # Replace with your API key
    ACCESS_TOKEN = "KsXmaciLvSZew67oyDYeR2CcC1WmhWDD"  # Replace with your access token
    
    # File paths
    INPUT_CSV = "data/Stage2Shortlist.csv"  # Input CSV file with Symbol column
    OUTPUT_CSV = "sandeep-stan-wyckoff-claude_MCAP-great2500_25sept.csv"  # Output file
    CACHE_FILE = "nse_instruments_cache.json"  # Cache file for instruments
    
    try:
        # Initialize scanner
        logging.info("Initializing Accumulation Distribution Scanner...")
        scanner = AccumulationDistributionScanner(
            api_key=API_KEY,
            access_token=ACCESS_TOKEN,
            cache_file=CACHE_FILE
        )
        
        # Run scan
        logging.info(f"Starting scan of symbols from {INPUT_CSV}")
        results_df = scanner.scan_symbols_from_csv(INPUT_CSV, OUTPUT_CSV)
        
        # Generate summary
        summary = scanner.generate_summary_report(results_df)
        
        # Print summary
        print("\n" + "="*80)
        print("ACCUMULATION & DISTRIBUTION SCANNER SUMMARY")
        print("="*80)
        print(f"Total Symbols Analyzed: {summary['total_symbols']}")
        print(f"Successful Analyses: {summary['successful_analyses']}")
        print(f"Failed Analyses: {summary['failed_analyses']}")
        print()
        
        print("SIGNAL DISTRIBUTION:")
        print(f"  Buy Signals: {summary['buy_signals']}")
        print(f"  Sell Signals: {summary['sell_signals']}")
        print(f"  Hold Signals: {summary['hold_signals']}")
        print()
        
        print("RECOMMENDATION DISTRIBUTION:")
        print(f"  Strong Buy: {summary['strong_buy']}")
        print(f"  Buy: {summary['buy']}")
        print(f"  Consider Buying: {summary['consider_buying']}")
        print(f"  Hold: {summary['hold']}")
        print(f"  Consider Selling: {summary['consider_selling']}")
        print(f"  Sell: {summary['sell']}")
        print(f"  Strong Sell: {summary['strong_sell']}")
        print()
        
        print("PATTERN DISTRIBUTION:")
        print(f"  Accumulation: {summary['accumulation_patterns']}")
        print(f"  Distribution: {summary['distribution_patterns']}")
        print(f"  Neutral: {summary['neutral_patterns']}")
        print()
        
        print("WEINSTEIN STAGE DISTRIBUTION:")
        print(f"  Stage 1 (Accumulation): {summary['stage_1']}")
        print(f"  Stage 2 (Advancing): {summary['stage_2']}")
        print(f"  Stage 3 (Distribution): {summary['stage_3']}")
        print(f"  Stage 4 (Declining): {summary['stage_4']}")
        print()
        
        print("AVERAGE METRICS:")
        print(f"  Average Signal Confidence: {summary['avg_signal_confidence']:.2f}")
        print(f"  Average Relative Strength: {summary['avg_relative_strength']:.2f}%")
        print(f"  Average Volume vs 50D Avg: {summary['avg_volume_vs_avg']:.2f}%")
        print()
        
        print("TOP OPPORTUNITIES:")
        print("  Highest Accumulation Scores:")
        for item in summary['top_accumulation_scores']:
            print(f"    {item['symbol']}: {item['ad_accumulation_score']:.3f}")
        
        print("  Strongest Relative Strength:")
        for item in summary['top_relative_strength']:
            print(f"    {item['symbol']}: {item['relative_strength_current']:.2f}%")
        
        print("  Highest Confidence Signals:")
        for item in summary['highest_confidence_signals']:
            print(f"    {item['symbol']}: {item['primary_signal'].upper()} (Confidence: {item['signal_confidence']:.2f})")
        
        print("\n" + "="*80)
        print(f"Detailed results saved to: {OUTPUT_CSV}")
        print("="*80)
        
    except Exception as e:
        logging.error(f"Error in main execution: {e}")
        print(f"Error: {e}")


if __name__ == "__main__":
    main()