# Import necessary libraries
import pandas as pd
import pandas_ta as ta
import datetime
from datetime import timedelta # Keep timedelta separate for convenience
import time
import os
import pickle
import logging
import numpy as np
import re
from kiteconnect import KiteConnect

from ratelimit import limits, sleep_and_retry  # pip install ratelimit
from dotenv import load_dotenv  # pip install python-dotenv
import traceback # For detailed error logging

# --- Configuration ---
INPUT_CSV_PATH = 'data/MCAP-great2500.csv'
OUTPUT_CSV_PATH = 'MBSystemGemini_scan_results_MCAP-great2500_13Oct.csv'

# Rate limit configurations
HISTORICAL_RATE_LIMIT = 3  # 3 requests/second
QUOTE_RATE_LIMIT = 10      # 10 requests/second
ONE_SECOND = 1

# Logging setup
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables from .env file
load_dotenv()

# Log pandas-ta version for debugging
try:
    logger.info(f"pandas-ta version: {ta.__version__}")
except Exception as e:
    logger.warning(f"Could not get pandas_ta version: {e}")

# --- Kite Connect API Implementation ---
class KiteAPI:
    def __init__(self, api_key, access_token):
        logger.info("Initializing Kite Connect...")
        self.kite = None # Initialize kite object to None
        try:
            if not api_key or not access_token:
                 raise ValueError("API Key or Access Token is missing.")
            self.kite = KiteConnect(api_key=api_key)
            self.kite.set_access_token(access_token)
            # Verify connection by fetching profile (optional but recommended)
            profile = self.kite.profile()
            logger.info(f"Kite Connect initialized successfully for user: {profile.get('user_id')}")
            self.instrument_map = self._load_instruments()
        except ValueError as ve:
             logger.error(f"Initialization Error: {ve}")
        except Exception as e:
            logger.error(f"Failed to initialize Kite Connect or set access token: {e}")
            logger.error("Please ensure API Key and Access Token are valid and internet connection is stable.")
            # self.kite remains None

    def _load_instruments(self):
        if not self.kite:
             logger.error("Kite object not initialized. Cannot load instruments.")
             return {}
        logger.info("Fetching Instrument List from Kite API...")
        try:
            instruments = self.kite.instruments("NSE")
            instrument_map = {}
            try:
                df_symbols = pd.read_csv(INPUT_CSV_PATH)
                # Convert to uppercase and remove potential whitespace, handle NaN
                csv_symbols = set(df_symbols['Symbol'].dropna().astype(str).str.strip().str.upper())
                logger.info(f"Found {len(csv_symbols)} unique symbols in {INPUT_CSV_PATH}")
                matched_count = 0
                skipped_non_eq = 0
                for instrument in instruments:
                    # Ensure it's an equity instrument on NSE segment
                    if instrument and instrument.get('exchange') == 'NSE' and instrument.get('segment') == 'NSE':
                        if instrument.get('instrument_type') == 'EQ':
                            symbol_upper = instrument.get('tradingsymbol','').strip().upper()
                            if symbol_upper in csv_symbols:
                                instrument_map[instrument['tradingsymbol']] = instrument['instrument_token'] # Store original case symbol as key
                                matched_count += 1
                        else:
                             skipped_non_eq +=1

                logger.info(f"Loaded {len(instrument_map)} symbols from Kite API that match input CSV and are NSE Equity.")
                if skipped_non_eq > 0:
                     logger.debug(f"Skipped {skipped_non_eq} non-equity instruments during loading.")
                if matched_count < len(csv_symbols):
                     logger.warning(f"Could not find instrument tokens for {len(csv_symbols) - matched_count} symbols listed in the CSV.")

            except FileNotFoundError:
                 logger.warning(f"Input CSV '{INPUT_CSV_PATH}' not found. Loading all NSE equity instruments.")
                 instrument_map = {}
                 for instrument in instruments:
                     if instrument.get('exchange') == 'NSE' and instrument.get('segment') == 'NSE' and instrument.get('instrument_type') == 'EQ':
                         instrument_map[instrument['tradingsymbol']] = instrument['instrument_token']
                 logger.info(f"Loaded {len(instrument_map)} NSE equity instruments as fallback.")
            return instrument_map
        except Exception as e:
            logger.error(f"Error loading instruments: {e}", exc_info=True)
            return {}

    def get_instrument_token(self, symbol):
        # Case-insensitive lookup might be safer if input CSV case varies
        # return self.instrument_map.get(symbol.upper()) # If keys stored as upper
        return self.instrument_map.get(symbol) # Assumes keys stored in original case

    @sleep_and_retry
    @limits(calls=HISTORICAL_RATE_LIMIT, period=ONE_SECOND)
    def get_historical_data(self, instrument_token, from_date, to_date, interval):
        """
        Fetches historical data, handling chunking for monthly resampling.
        Expects from_date and to_date as datetime.datetime objects.
        """
        if not self.kite:
             logger.error("Kite object not initialized. Cannot fetch historical data.")
             return pd.DataFrame()
        # Check if instrument_token is valid before proceeding
        if not instrument_token or not isinstance(instrument_token, (int, str)):
             logger.error(f"Invalid instrument token provided: {instrument_token}")
             return pd.DataFrame()

        logger.info(f"Fetching Historical Data for {instrument_token} from {from_date.strftime('%Y-%m-%d')} to {to_date.strftime('%Y-%m-%d')} interval {interval}")

        # Ensure from_date and to_date are datetime.datetime objects
        if not isinstance(from_date, datetime.datetime) or not isinstance(to_date, datetime.datetime):
            logger.error(f"get_historical_data expects datetime.datetime objects, received {type(from_date)}, {type(to_date)}")
            # Attempt conversion if possible (e.g., from date) - This was problematic before, ensure robust conversion if kept
            try:
                if isinstance(from_date, datetime.date): from_date = datetime.datetime.combine(from_date, datetime.datetime.min.time())
                if isinstance(to_date, datetime.date): to_date = datetime.datetime.combine(to_date, datetime.datetime.max.time())
                if not isinstance(from_date, datetime.datetime) or not isinstance(to_date, datetime.datetime): raise TypeError("Conversion failed")
            except Exception:
                 logger.error("Failed to convert input dates to datetime objects.")
                 return pd.DataFrame()

        try:
            # --- Monthly Interval Handling (Chunking Daily Data) ---
            if interval == 'month':
                kite_interval = 'day'
                all_daily_data = []
                current_start_date = from_date.date() # Iterate using date objects
                end_loop_date = to_date.date()
                chunk_delta = timedelta(days=2 * 365 - 1) # Approx 2 years per chunk

                logger.info(f"Fetching daily data in chunks for monthly resampling ({current_start_date} to {end_loop_date})")
                logger.debug(f"Monthly resampling: chunk_delta={chunk_delta}, total_days={(end_loop_date - current_start_date).days}")

                while current_start_date <= end_loop_date:
                    current_end_date = min(current_start_date + chunk_delta, end_loop_date)
                    from_date_str = current_start_date.strftime('%Y-%m-%d')
                    to_date_str = current_end_date.strftime('%Y-%m-%d')

                    logger.debug(f"Fetching chunk: {instrument_token}, from={from_date_str}, to={to_date_str}, interval={kite_interval}")

                    try:
                        # continuous=False is often preferred for point-in-time scans
                        data_chunk = self.kite.historical_data(
                            instrument_token, from_date_str, to_date_str, kite_interval, continuous=False
                        )
                        if data_chunk:
                            df_chunk = pd.DataFrame(data_chunk)
                            all_daily_data.append(df_chunk)
                            logger.debug(f"Fetched chunk size: {len(df_chunk)}")
                        else:
                            logger.warning(f"No data returned for chunk: {instrument_token}, {from_date_str} to {to_date_str}")
                    except Exception as chunk_e:
                        # Specific handling for common errors during chunk fetch
                        if "invalid input date range" in str(chunk_e).lower() or "invalid from date" in str(chunk_e).lower() :
                             logger.warning(f"Invalid date range for chunk: {instrument_token} ({from_date_str} to {to_date_str}). Likely before listing. Skipping chunk.")
                        elif "429" in str(chunk_e) or "Too many requests" in str(chunk_e):
                             logger.warning("Rate limit hit during chunk fetch, retrying (decorator should handle)...")
                             raise # Re-raise for decorator
                        elif "token" in str(chunk_e).lower(): # Handle token expiry during loop? Unlikely but possible
                             logger.error(f"Token Exception during chunk fetch for {instrument_token}: {chunk_e}. Stopping process.")
                             # Depending on strategy, might want to re-authenticate or exit. For now, return empty.
                             return pd.DataFrame() # Stop processing this symbol if token invalid
                        else:
                             logger.error(f"Error fetching data chunk for {instrument_token} ({from_date_str} to {to_date_str}): {chunk_e}")
                             # Decide: continue with partial data or stop? Continue for now.

                    current_start_date = current_end_date + timedelta(days=1)
                    time.sleep(0.3) # Small sleep between chunk calls to be safe

                # --- Combine and Resample after chunking ---
                if not all_daily_data:
                    logger.warning(f"No daily data collected after chunking for {instrument_token}. Cannot generate monthly data.")
                    return pd.DataFrame()

                logger.debug(f"Combining {len(all_daily_data)} daily chunks for monthly resampling")
                df = pd.concat(all_daily_data, ignore_index=True)
                logger.debug(f"Combined daily data shape: {df.shape}")

                # --- Data Cleaning and Preparation ---
                if 'date' not in df.columns and 'timestamp' in df.columns: df.rename(columns={'timestamp': 'date'}, inplace=True)
                if 'date' not in df.columns:
                    logger.error("No 'date' or 'timestamp' column found after concatenating daily data.")
                    return pd.DataFrame()

                df['date'] = pd.to_datetime(df['date'])
                if pd.api.types.is_datetime64_any_dtype(df['date']) and df['date'].dt.tz is not None:
                    logger.debug(f"Detected timezone {df['date'].dt.tz} in daily data. Converting to naive UTC.")
                    try: df['date'] = df['date'].dt.tz_convert('UTC').dt.tz_localize(None)
                    except Exception as tz_e: logger.warning(f"Could not convert timezone reliably: {tz_e}. Attempting direct localize(None)."); df['date'] = df['date'].dt.tz_localize(None)

                for col in ['open', 'high', 'low', 'close', 'volume']:
                     if col in df.columns: df[col] = pd.to_numeric(df[col], errors='coerce')
                     else: logger.warning(f"Column '{col}' missing in fetched data for {instrument_token}."); df[col] = np.nan # Add missing column as NaN
                df.dropna(subset=['open', 'high', 'low', 'close', 'date'], inplace=True) # Keep rows even if volume is NaN? Depends on strategy. Let's keep volume check too.
                df.dropna(subset=['volume'], inplace=True)

                df = df.sort_values('date').drop_duplicates(subset=['date'], keep='last')
                if df.empty: logger.warning(f"DataFrame empty after cleaning/deduplication for {instrument_token}."); return pd.DataFrame()

                # --- Improved Monthly Resampling with Last Trading Day Dates ---
                df = df.set_index('date')
                logger.debug(f"Daily data indexed by date, shape: {df.shape}")
                
                # Group by year-month and find the last trading day of each month
                df['year_month'] = df.index.to_period('M')
                monthly_groups = df.groupby('year_month')
                logger.debug(f"Found {len(monthly_groups)} year-month groups for resampling")
                
                monthly_data = []
                for period, group in monthly_groups:
                    if not group.empty:
                        # Find the last trading day of this month
                        last_trading_date = group.index.max()
                        
                        # Aggregate OHLCV data
                        monthly_record = {
                            'date': last_trading_date,
                            'open': group.iloc[0]['open'],  # First day's open
                            'high': group['high'].max(),
                            'low': group['low'].min(),
                            'close': group.iloc[-1]['close'],  # Last day's close
                            'volume': group['volume'].sum()
                        }
                        monthly_data.append(monthly_record)
                
                logger.debug(f"Generated {len(monthly_data)} monthly records from daily data")
                
                if not monthly_data:
                    logger.warning(f"No monthly data generated for {instrument_token}.")
                    return pd.DataFrame()
                
                monthly_df = pd.DataFrame(monthly_data)
                monthly_df = monthly_df.sort_values('date')
                logger.debug(f"Monthly DataFrame shape after creation: {monthly_df.shape}")
                logger.debug(f"Monthly data date range: {monthly_df['date'].min()} to {monthly_df['date'].max()}")
                
                # Filter by requested date range
                pd_from_date = pd.Timestamp(from_date).normalize()
                pd_to_date = pd.Timestamp(to_date).normalize()
                monthly_df = monthly_df[(monthly_df['date'] >= pd_from_date) & (monthly_df['date'] <= pd_to_date)]
                logger.debug(f"After date filtering: {len(monthly_df)} records remain")
                
                if monthly_df.empty:
                    logger.warning(f"Monthly DataFrame empty after date filtering for {instrument_token}.")
                else:
                    logger.info(f"Successfully generated {len(monthly_df)} monthly records for {instrument_token} with last trading day dates.")
                
                return monthly_df

            # --- Daily Interval Handling (Direct Fetch) ---
            else: # interval == 'day' or other direct intervals
                from_date_str = from_date.strftime('%Y-%m-%d'); to_date_str = to_date.strftime('%Y-%m-%d')
                logger.debug(f"API call: instrument_token={instrument_token}, from={from_date_str}, to={to_date_str}, interval={interval}")
                data = self.kite.historical_data(instrument_token, from_date_str, to_date_str, interval, continuous=False)
                df = pd.DataFrame(data)
                if not df.empty:
                    if 'timestamp' in df.columns: df.rename(columns={'timestamp': 'date'}, inplace=True)
                    if 'date' not in df.columns: logger.error("No 'date' or 'timestamp' column in daily data."); return pd.DataFrame()

                    df['date'] = pd.to_datetime(df['date'])
                    if pd.api.types.is_datetime64_any_dtype(df['date']) and df['date'].dt.tz is not None: logger.debug(f"Making daily data timezone naive."); df['date'] = df['date'].dt.tz_localize(None)

                    for col in ['open', 'high', 'low', 'close', 'volume']:
                        if col in df.columns: df[col] = pd.to_numeric(df[col], errors='coerce')
                        else: logger.warning(f"Column '{col}' missing in daily data for {instrument_token}."); df[col] = np.nan
                    df.dropna(subset=['open', 'high', 'low', 'close', 'date', 'volume'], inplace=True)
                    if df.empty: logger.warning(f"Daily data empty after cleaning for {instrument_token}.")
                    else: logger.info(f"Successfully fetched {len(df)} {interval} records for {instrument_token}")
                else: logger.warning(f"No {interval} data returned for {instrument_token} in the specified range.")
                return df

        except Exception as e:
            # General catch-all for unexpected errors during the process
            tb_str = traceback.format_exc()
            logger.error(f"Unexpected error in get_historical_data for {instrument_token} ({interval}): {e}\nTraceback:\n{tb_str}")
            return pd.DataFrame() # Return empty DF on unexpected error

    @sleep_and_retry
    @limits(calls=QUOTE_RATE_LIMIT, period=ONE_SECOND)
    def get_quote(self, instrument_tokens):
        if not self.kite:
             logger.error("Kite object not initialized. Cannot fetch quote data.")
             return {}
        # Filter out None or invalid tokens before converting to string
        tokens_str = [str(token) for token in instrument_tokens if token is not None and isinstance(token, (int, str)) and str(token).isdigit()]
        if not tokens_str:
            logger.warning("No valid instrument tokens provided for quote fetch.")
            return {}

        logger.info(f"Fetching Quote Data for {len(tokens_str)} instruments")
        try:
            # API expects list of strings
            quote_dict = self.kite.quote(tokens_str)
            # Return with string keys for consistency
            return {str(k): v for k, v in quote_dict.items()}
        except Exception as e:
            if "429" in str(e) or "Too many requests" in str(e):
                logger.warning("Rate limit hit on quote fetch, retrying...")
                raise # Re-raise for decorator
            elif "token" in str(e).lower():
                 logger.error(f"Token Exception during quote fetch: {e}")
                 # This might indicate the main token expired. Handle appropriately.
                 # Maybe raise a specific exception to signal main loop to stop/re-auth?
                 # For now, return empty.
                 return {}
            else:
                tb_str = traceback.format_exc()
                logger.error(f"Error fetching quote data: {e}\nTraceback:\n{tb_str}")
                return {}

# --- Improved Data Validation ---
def validate_historical_data(df, from_date, to_date, interval):
    """
    Validates fetched historical data with dynamic requirements based on indicator needs.
    Expects date objects for comparison.
    """
    logger.debug(f"=== VALIDATION START: interval={interval}, from_date={from_date}, to_date={to_date} ===")
    logger.debug(f"Input DataFrame shape: {df.shape if df is not None else 'None'}")
    logger.debug(f"Input DataFrame columns: {list(df.columns) if df is not None else 'None'}")
    
    # Convert inputs to date objects for internal comparison consistency
    try:
        if isinstance(from_date, datetime.datetime): from_date = from_date.date()
        if isinstance(to_date, datetime.datetime): to_date = to_date.date()
        if not isinstance(from_date, datetime.date) or not isinstance(to_date, datetime.date):
             raise TypeError("Input dates are not valid date/datetime types")
        logger.debug(f"Date conversion successful: from_date={from_date}, to_date={to_date}")
    except Exception as date_conv_e:
         logger.error(f"Validation Error: Could not use input dates: {date_conv_e}")
         return False, "Invalid Date Input Types"

    if df is None or df.empty:
        logger.debug("DataFrame is None or empty")
        return False, "Empty Data"

    expected_cols = ['date', 'open', 'high', 'low', 'close', 'volume']
    missing_cols = [col for col in expected_cols if col not in df.columns]
    if missing_cols:
        logger.warning(f"Missing columns: {missing_cols}")
        logger.debug(f"Available columns: {list(df.columns)}")
        return False, f"Missing Columns: {missing_cols}"

    # Check data types (allow ints as well as floats for prices/volume)
    for col in ['open', 'high', 'low', 'close', 'volume']:
        if not pd.api.types.is_numeric_dtype(df[col]):
             logger.warning(f"Column '{col}' is not numeric ({df[col].dtype}).")
             logger.debug(f"Column '{col}' sample values: {df[col].head(3).tolist()}")
             return False, f"Non-numeric column: {col}"

    # Check for NaNs in critical columns
    nan_check_ohlc = df[['open', 'high', 'low', 'close']].isnull().values.any()
    if nan_check_ohlc:
        logger.warning("NaN values found in OHLC columns.")
        logger.debug(f"NaN counts per column: {df[['open', 'high', 'low', 'close']].isnull().sum().to_dict()}")
        return False, "NaN in OHLC"
    
    nan_check_volume = df['volume'].isnull().values.any()
    if nan_check_volume:
         logger.warning("NaN values found in Volume column.")
         logger.debug(f"Volume NaN count: {df['volume'].isnull().sum()}")

    # Date checks
    date_dtype_check = pd.api.types.is_datetime64_any_dtype(df['date'])
    if not date_dtype_check:
         logger.warning("'date' column is not a datetime type.")
         logger.debug(f"Date column dtype: {df['date'].dtype}")
         logger.debug(f"Date column sample values: {df['date'].head(3).tolist()}")
         return False, "Date column invalid type"
    
    date_nan_check = df['date'].isnull().values.any()
    if date_nan_check:
         logger.warning("NaN values found in date column.")
         logger.debug(f"Date NaN count: {df['date'].isnull().sum()}")
         return False, "NaN in Date"

    # Dynamic length validation based on indicator requirements
    if interval == 'day':
        # For daily data, we need enough rows for RSI(36) + some buffer
        # RSI(36) needs 36 periods + buffer for other indicators
        min_required_for_indicators = 40  # RSI(36) + buffer
        actual_available = len(df)
        
        logger.debug(f"Daily validation: actual_available={actual_available}, min_required={min_required_for_indicators}")
        
        if actual_available < min_required_for_indicators:
            logger.warning(f"Insufficient daily data for indicators: {actual_available} rows, need at least {min_required_for_indicators} for RSI(36) calculations.")
            return False, f"Insufficient Daily Rows for Indicators ({actual_available} < {min_required_for_indicators})"
        
        # Gap check (allow weekends/holidays) - check diff on sorted dates
        df_sorted = df.sort_values('date')
        date_diffs = df_sorted['date'].diff().dt.days
        if date_diffs.max() > 7: # Allow for week + holiday gaps
            logger.warning(f"Large gaps detected in daily data: max {date_diffs.max()} days")

    elif interval == 'month':
        # Dynamic minimum requirements based on available data
        actual_available = len(df)
        
        logger.debug(f"Monthly validation: actual_available={actual_available}")
        logger.debug(f"Monthly data date range: {df['date'].min()} to {df['date'].max()}")
        logger.debug(f"Monthly data sample: {df[['date', 'close']].head(3).to_dict('records')}")
        
        # Determine minimum requirements based on available data
        if actual_available >= 30:
            # Full TRIX(10) calculation possible
            min_required_for_indicators = 30
            trix_period = 10
            logger.debug(f"Using TRIX(10) - requires {min_required_for_indicators} periods")
        elif actual_available >= 20:
            # Use TRIX(5) instead of TRIX(10)
            min_required_for_indicators = 15
            trix_period = 5
            logger.debug(f"Using TRIX(5) - requires {min_required_for_indicators} periods (TRIX(5) needs ~14 periods)")
        elif actual_available >= 15:
            # Use TRIX(3) for very limited data
            min_required_for_indicators = 10
            trix_period = 3
            logger.debug(f"Using TRIX(3) - requires {min_required_for_indicators} periods (TRIX(3) needs ~9 periods)")
        elif actual_available >= 5:
            # Skip TRIX calculation but allow processing with basic indicators
            min_required_for_indicators = 5  # Minimum for basic SMA calculations
            trix_period = None  # No TRIX calculation
            logger.debug(f"Skipping TRIX calculation - insufficient data ({actual_available} < 15), using basic indicators only")
        else:
            # Insufficient data for any meaningful analysis
            min_required_for_indicators = 5
            trix_period = None
            logger.warning(f"Insufficient monthly data for any analysis: {actual_available} rows, need at least 5 for basic indicators")
            logger.debug(f"Available data spans: {actual_available} months")
            return False, f"Insufficient Monthly Rows for Basic Analysis ({actual_available} < 5)"
        
        if actual_available < min_required_for_indicators:
            logger.warning(f"Insufficient monthly data for TRIX({trix_period}): {actual_available} rows, need at least {min_required_for_indicators}")
            logger.debug(f"TRIX({trix_period}) requires ~{trix_period * 3 - 1} periods: {trix_period} (EMA1) + {trix_period-1} (EMA2) + {trix_period-1} (EMA3) + 1 (pct_change)")
            logger.debug(f"Available data spans: {actual_available} months")
            return False, f"Insufficient Monthly Rows for TRIX({trix_period}) ({actual_available} < {min_required_for_indicators})"
        
        # Store the determined TRIX period for use in indicator calculations
        df.attrs['trix_period'] = trix_period
        if trix_period is not None:
            logger.debug(f"Monthly validation passed with TRIX({trix_period})")
        else:
            logger.debug(f"Monthly validation passed without TRIX (insufficient data for TRIX calculation)")

    # Check if date range fetched covers requested range reasonably
    try:
        min_df_date = pd.to_datetime(df['date'].min()).date() if pd.notna(df['date'].min()) else None
        max_df_date = pd.to_datetime(df['date'].max()).date() if pd.notna(df['date'].max()) else None

        logger.debug(f"Data date range: {min_df_date} to {max_df_date}")
        logger.debug(f"Requested date range: {from_date} to {to_date}")

        if min_df_date and max_df_date:
             # Allow data starting later than from_date (recent listing), but should end near to_date
             if max_df_date < (to_date - timedelta(days=7 if interval=='day' else 35)): # Allow some lag
                 logger.warning(f"Data may be stale: Max date {max_df_date} significantly before target end date {to_date}.")
             if min_df_date > to_date: # Data starts after requested end? Invalid.
                  logger.warning(f"Data starts ({min_df_date}) after requested end date ({to_date}).")
                  return False, "Date Range Mismatch (Starts Late)"

    except Exception as date_range_e:
         logger.warning(f"Could not perform date range check: {date_range_e}")

    logger.debug(f"=== VALIDATION PASSED: interval={interval} ===")
    return True, "OK"

# --- In-Memory Caching for Current Session ---
# Simple in-memory cache for the current scanning session only
session_cache = {}

def get_cached_data(key):
    """Retrieves data from session cache if available. Returns a copy."""
    cached_item = session_cache.get(key)
    if cached_item is not None:
        logger.debug(f"Session cache hit for key: {key}")
        # Return a copy to prevent modification of the cached object
        return cached_item.copy() if isinstance(cached_item, pd.DataFrame) else cached_item
    else:
        logger.debug(f"Session cache miss for key: {key}")
        return None

def set_cached_data(key, data):
    """Adds/updates data in the session cache."""
    # Store a copy to prevent modifying the original df affecting the cache
    data_to_cache = data.copy() if isinstance(data, pd.DataFrame) else data
    session_cache[key] = data_to_cache
    logger.debug(f"Added to session cache: {key}")


# --- Indicator Calculations ---
# --- Indicator Calculations ---
def calculate_indicators(df, timeframe="monthly", symbol=None):
    """Calculates technical indicators using pandas_ta."""
    if df is None or df.empty:
        logger.warning(f"Cannot calculate indicators: Empty DataFrame for {timeframe}")
        return None, "Empty Input DF"

    # Determine min_length based on timeframe and indicators calculated
    if timeframe == "monthly":
        # Get the TRIX period that was determined during validation
        trix_period = df.attrs.get('trix_period', 10)
        
        # Calculate minimum length based on the TRIX period
        if trix_period == 10:
            min_length = 29  # TRIX(10) needs ~29 periods
        elif trix_period == 5:
            min_length = 15  # TRIX(5) needs ~14 periods + buffer
        elif trix_period == 3:
            min_length = 10  # TRIX(3) needs ~9 periods + buffer
        else:
            min_length = 29  # Default fallback
            
        logger.debug(f"Monthly indicators: using TRIX({trix_period}), min_length={min_length}")
    elif timeframe in ["daily", "weekly"]:
        # Daily indicators include RSIs up to 36.
        min_length = 30 
    else:
        min_length = 20 # A general default for other unhandled timeframes

    try:
        # Ensure columns are numeric where expected
        for col in ['open', 'high', 'low', 'close', 'volume']:
            if col in df.columns: df[col] = pd.to_numeric(df[col], errors='coerce')
            else: 
                logger.warning(f"Indicator Calc: Column '{col}' missing in input for {timeframe} (Symbol: {df.get('symbol_debug', 'N/A')})."); # Added symbol for context if possible
                return None, f"Missing Column {col}"

        # Drop rows if key OHLC columns became NaN after conversion
        original_rows = len(df)
        df.dropna(subset=['open', 'high', 'low', 'close'], inplace=True)
        if len(df) < original_rows:
            logger.debug(f"Dropped {original_rows - len(df)} rows with OHLC NaNs for {timeframe} (Symbol: {df.get('symbol_debug', 'N/A')}).")


        if len(df) < min_length:
            logger.warning(f"Insufficient data for {timeframe} indicators after NaNs removed: {len(df)} rows (need >= {min_length}) (Symbol: {df.get('symbol_debug', 'N/A')})")
            return None, f"Insufficient Rows after NaN removal ({len(df)} < {min_length})"

        # Create a copy to avoid SettingWithCopyWarning during calculations
        df_indicators = df.copy()

        # --- Standard Indicators ---
        df_indicators['sma3'] = ta.sma(df_indicators['close'], length=3)
        df_indicators['sma10'] = ta.sma(df_indicators['close'], length=10)

        # Enhanced TRIX Calculation with Dynamic Period
        # Get TRIX period from validation (None means skip TRIX calculation)
        trix_period = df_indicators.attrs.get('trix_period', 10)
        
        if trix_period is not None:
            logger.debug(f"Calculating TRIX({trix_period}) for {timeframe} timeframe")
            
            log_close = np.log(df_indicators['close']) # Take natural log of close
            ema1_log = ta.ema(log_close, length=trix_period)
            ema2_log = ta.ema(ema1_log, length=trix_period)
            ema3_log = ta.ema(ema2_log, length=trix_period)

            # Calculate 1-period difference of the triple EMA of log_close
            ema3_log_diff = ema3_log.diff(1) 
            trix_raw = 10000 * ema3_log_diff # Apply the 10000 multiplier
            df_indicators[f'trix_{trix_period}'] = trix_raw

            # TRIX Signal Line
            df_indicators[f'trix_{trix_period}_5'] = ta.sma(df_indicators[f'trix_{trix_period}'], length=5)
            
            # TRIX Momentum (Rate of Change)
            df_indicators['trix_momentum'] = df_indicators[f'trix_{trix_period}'].diff(1)
            
            # TRIX Volatility (Rolling Standard Deviation)
            df_indicators['trix_volatility'] = df_indicators[f'trix_{trix_period}'].rolling(window=6, min_periods=3).std()
            
            # TRIX Signal Line Crossover
            df_indicators['trix_crossover'] = (df_indicators[f'trix_{trix_period}'] > df_indicators[f'trix_{trix_period}_5']) & (df_indicators[f'trix_{trix_period}'].shift(1) <= df_indicators[f'trix_{trix_period}_5'].shift(1))
            df_indicators['trix_crossover'] = df_indicators['trix_crossover'].fillna(False)
        else:
            logger.debug(f"Skipping TRIX calculation for {timeframe} timeframe (insufficient data)")
            # Initialize TRIX-related columns with NaN values
            df_indicators['trix_na'] = np.nan
            df_indicators['trix_na_5'] = np.nan
            df_indicators['trix_momentum'] = np.nan
            df_indicators['trix_volatility'] = np.nan
            df_indicators['trix_crossover'] = False

        # Keltner Channels - UPDATED SETTINGS
        kc_length = 10
        kc_mult = 0.5
        kc_mamode = 'ema' 
        
        try:
            kc_high = df_indicators['high'].astype(float)
            kc_low = df_indicators['low'].astype(float)
            kc_close = df_indicators['close'].astype(float)

            kc_result = ta.kc(high=kc_high, low=kc_low, close=kc_close,
                              length=kc_length, scalar=kc_mult, mamode=kc_mamode, atr_length=kc_length)
            
            kc_l_col_pattern1 = f"KCL{kc_mamode[0]}_{kc_length}_{str(float(kc_mult))}"
            kc_m_col_pattern1 = f"KCB{kc_mamode[0]}_{kc_length}_{str(float(kc_mult))}" 
            kc_u_col_pattern1 = f"KCU{kc_mamode[0]}_{kc_length}_{str(float(kc_mult))}"

            kc_l_col_pattern2 = f"KCL_{kc_length}_{kc_mult}"
            kc_m_col_pattern2_kcb = f"KCB_{kc_length}_{kc_mult}"
            kc_m_col_pattern2_kcm = f"KCM_{kc_length}_{kc_mult}"
            kc_u_col_pattern2 = f"KCU_{kc_length}_{kc_mult}"
            
            assigned_kc = False
            if kc_result is not None and not kc_result.empty:
                if all(col in kc_result.columns for col in [kc_l_col_pattern1, kc_m_col_pattern1, kc_u_col_pattern1]):
                    df_indicators['kc_lower'] = kc_result[kc_l_col_pattern1]
                    df_indicators['kc_middle'] = kc_result[kc_m_col_pattern1]
                    df_indicators['kc_upper'] = kc_result[kc_u_col_pattern1]
                    assigned_kc = True
                elif all(col in kc_result.columns for col in [kc_l_col_pattern2, kc_m_col_pattern2_kcb, kc_u_col_pattern2]):
                    df_indicators['kc_lower'] = kc_result[kc_l_col_pattern2]
                    df_indicators['kc_middle'] = kc_result[kc_m_col_pattern2_kcb]
                    df_indicators['kc_upper'] = kc_result[kc_u_col_pattern2]
                    assigned_kc = True
                elif all(col in kc_result.columns for col in [kc_l_col_pattern2, kc_m_col_pattern2_kcm, kc_u_col_pattern2]):
                    df_indicators['kc_lower'] = kc_result[kc_l_col_pattern2]
                    df_indicators['kc_middle'] = kc_result[kc_m_col_pattern2_kcm]
                    df_indicators['kc_upper'] = kc_result[kc_u_col_pattern2]
                    assigned_kc = True
                else: 
                    logger.warning(f"KC columns with specific patterns not found for L={kc_length}, M={kc_mult} (Symbol: {df.get('symbol_debug', 'N/A')}). Columns: {list(kc_result.columns)}. Trying generic match.")
                    kc_map = { 'lower': ['KCL'], 'middle': ['KCB', 'KCM'], 'upper': ['KCU'] }
                    found_all_generic = True
                    for band_key, patterns in kc_map.items():
                        col_found = None
                        for p_specific_prefix in patterns:
                            p1 = f"{p_specific_prefix}{kc_mamode[0]}_{kc_length}_{str(float(kc_mult))}"
                            p2 = f"{p_specific_prefix}_{kc_length}_{str(float(kc_mult))}"
                            if p1 in kc_result.columns: col_found = p1; break
                            if p2 in kc_result.columns: col_found = p2; break
                        if col_found: break 
                        if not col_found:
                             col_found = next((col for col in kc_result.columns if any(col.upper().startswith(p.upper()) for p in patterns)), None)
                        
                        if col_found:
                            df_indicators[f'kc_{band_key}'] = kc_result[col_found]
                        else:
                            logger.error(f"Could not find KC '{band_key}' band column (Symbol: {df.get('symbol_debug', 'N/A')}) using patterns {patterns} from {list(kc_result.columns)}. Setting to NaN.");
                            df_indicators[f'kc_{band_key}'] = np.nan
                            found_all_generic = False
                    if found_all_generic: assigned_kc = True
            
            if not assigned_kc:
                logger.error(f"Failed to assign KC (Symbol: {df.get('symbol_debug', 'N/A')}). Result from ta.kc was: {kc_result.head(2) if kc_result is not None else 'None'}")
                df_indicators['kc_lower'], df_indicators['kc_middle'], df_indicators['kc_upper'] = np.nan, np.nan, np.nan

        except Exception as kc_e:
            logger.error(f"Error calculating KCs (Symbol: {df.get('symbol_debug', 'N/A')}) L={kc_length}, M={kc_mult}: {kc_e}. Setting KC to NaN.", exc_info=True)
            df_indicators['kc_lower'], df_indicators['kc_middle'], df_indicators['kc_upper'] = np.nan, np.nan, np.nan

        # KC Slope and Distance Calculations (for monthly timeframe)
        if timeframe == "monthly":
            # KC Middle Slope (3-period)
            df_indicators['kc_middle_slope'] = df_indicators['kc_middle'].diff(3) / 3
            
            # Distance from KC Middle (as percentage)
            df_indicators['distance_from_kc_middle'] = ((df_indicators['close'] - df_indicators['kc_middle']) / df_indicators['kc_middle']) * 100
            
            # KC Middle Trend (positive slope check)
            df_indicators['kc_middle_trend'] = df_indicators['kc_middle_slope'] > 0
            
            # Monthly Bearish Fractal Analysis (for additional insight)
            highs = df_indicators['high']
            lows = df_indicators['low']
            
            # Bearish fractal: current low is lower than 2 bars before and 2 bars after
            low_minus_1 = lows.shift(1)
            low_minus_2 = lows.shift(2)
            low_plus_1 = lows.shift(-1)
            low_plus_2 = lows.shift(-2)
            
            df_indicators['monthly_bearish_fractal'] = (lows < low_minus_2) & (lows < low_minus_1) & \
                                                     (lows < low_plus_1) & (lows < low_plus_2)
            df_indicators['monthly_bearish_fractal'] = df_indicators['monthly_bearish_fractal'].fillna(False)
            
            # Check if last month had bearish fractal and current price broke above last month's high
            df_indicators['last_month_bearish_fractal'] = df_indicators['monthly_bearish_fractal'].shift(1)
            df_indicators['last_month_high'] = highs.shift(1)
            df_indicators['monthly_bearish_fractal_breakout'] = (df_indicators['last_month_bearish_fractal'] == True) & \
                                                              (df_indicators['close'] > df_indicators['last_month_high'])

            # --- NEW: Major Bearish Fractal Breakout ---
            # For each row, check if close > max(high) of all previous bearish fractal months
            def calc_major_bf_breakout(idx, close_val):
                # Get all previous indices
                prev_bf = df_indicators.loc[:idx-1] if idx > 0 else df_indicators.iloc[0:0]
                prev_bf_highs = prev_bf.loc[prev_bf['monthly_bearish_fractal'], 'high']
                if prev_bf_highs.empty:
                    return False
                return close_val > prev_bf_highs.max()
            
            # Calculate major breakout for each row
            major_breakout_results = []
            for idx, row in df_indicators.iterrows():
                prev_bf = df_indicators.loc[:idx-1] if idx > 0 else df_indicators.iloc[0:0]
                prev_bf_highs = prev_bf.loc[prev_bf['monthly_bearish_fractal'], 'high']
                max_prev_bf_high = prev_bf_highs.max() if not prev_bf_highs.empty else None
                major_breakout = row['close'] > max_prev_bf_high if max_prev_bf_high is not None else False
                
                major_breakout_results.append({
                    'idx': idx,
                    'month': row.name if hasattr(row.name, 'strftime') else f"Month_{idx}",
                    'low': row['low'],
                    'high': row['high'], 
                    'close': row['close'],
                    'bearish_fractal': row['monthly_bearish_fractal'],
                    'prev_bf_highs': list(prev_bf_highs.values) if not prev_bf_highs.empty else [],
                    'max_prev_bf_high': max_prev_bf_high,
                    'major_breakout': major_breakout
                })
            
            df_indicators['major_bearish_fractal_breakout'] = [r['major_breakout'] for r in major_breakout_results]
            
            # Log detailed breakdown for debugging (only for stocks that pass monthly filter)
            if symbol and len(major_breakout_results) > 0:
                logger.info(f"=== {symbol} - Major Bearish Fractal Breakout Analysis ===")
                logger.info(f"Month\tLow\tHigh\tClose\tBearish_Fractal\tPrev_BF_Highs\tMax_Prev_BF_High\tMajor_Breakout")
                logger.info(f"-----\t---\t----\t-----\t---------------\t-------------\t----------------\t--------------")
                for result in major_breakout_results[-5:]:  # Show last 5 months
                    month_str = str(result['month'])[:10] if hasattr(result['month'], 'strftime') else str(result['month'])
                    prev_bf_str = str(result['prev_bf_highs']) if result['prev_bf_highs'] else "[]"
                    max_prev_str = f"{result['max_prev_bf_high']:.2f}" if result['max_prev_bf_high'] is not None else "None"
                    logger.info(f"{month_str}\t{result['low']:.2f}\t{result['high']:.2f}\t{result['close']:.2f}\t{result['bearish_fractal']}\t{prev_bf_str}\t{max_prev_str}\t{result['major_breakout']}")

        if timeframe in ["daily", "weekly"]: 
            df_indicators['rsi12'] = ta.rsi(df_indicators['close'], length=12)
            df_indicators['rsi24'] = ta.rsi(df_indicators['close'], length=24)
            df_indicators['rsi36'] = ta.rsi(df_indicators['close'], length=36)
            df_indicators['rsi18'] = ta.rsi(df_indicators['close'], length=18)
            df_indicators['rsi18_ma6'] = ta.sma(df_indicators['rsi18'], length=6)

            # --- Weekly TRIX Calculation (NEW) ---
            if timeframe == "weekly":
                # Determine TRIX period for weekly data based on available weeks
                weekly_trix_period = 5  # Default for weekly data (shorter than monthly)
                if len(df_indicators) >= 25:
                    weekly_trix_period = 5  # TRIX(5) for 25+ weeks
                elif len(df_indicators) >= 15:
                    weekly_trix_period = 3  # TRIX(3) for 15-24 weeks
                else:
                    weekly_trix_period = 3  # TRIX(3) for limited data
                
                logger.debug(f"Calculating Weekly TRIX({weekly_trix_period}) for {timeframe} timeframe")
                
                # Weekly TRIX Calculation (same method as monthly)
                log_close_weekly = np.log(df_indicators['close'])
                ema1_log_weekly = ta.ema(log_close_weekly, length=weekly_trix_period)
                ema2_log_weekly = ta.ema(ema1_log_weekly, length=weekly_trix_period)
                ema3_log_weekly = ta.ema(ema2_log_weekly, length=weekly_trix_period)
                
                # Calculate 1-period difference of the triple EMA of log_close
                ema3_log_diff_weekly = ema3_log_weekly.diff(1)
                trix_raw_weekly = 10000 * ema3_log_diff_weekly
                df_indicators[f'weekly_trix_{weekly_trix_period}'] = trix_raw_weekly
                
                # Weekly TRIX Signal Line
                df_indicators[f'weekly_trix_{weekly_trix_period}_3'] = ta.sma(df_indicators[f'weekly_trix_{weekly_trix_period}'], length=3)
                
                # Weekly TRIX Momentum (Rate of Change)
                df_indicators['weekly_trix_momentum'] = df_indicators[f'weekly_trix_{weekly_trix_period}'].diff(1)
                
                # Weekly TRIX Volatility (Rolling Standard Deviation)
                df_indicators['weekly_trix_volatility'] = df_indicators[f'weekly_trix_{weekly_trix_period}'].rolling(window=4, min_periods=2).std()
                
                # Weekly TRIX Signal Line Crossover
                df_indicators['weekly_trix_crossover'] = (df_indicators[f'weekly_trix_{weekly_trix_period}'] > df_indicators[f'weekly_trix_{weekly_trix_period}_3']) & (df_indicators[f'weekly_trix_{weekly_trix_period}'].shift(1) <= df_indicators[f'weekly_trix_{weekly_trix_period}_3'].shift(1))
                df_indicators['weekly_trix_crossover'] = df_indicators['weekly_trix_crossover'].fillna(False)
                
                # Store the weekly TRIX period for reference
                df_indicators.attrs['weekly_trix_period'] = weekly_trix_period

            # ATR calculation (must be done before ROC ATR-adjusted calculations)
            if all(col in df_indicators.columns for col in ['high', 'low', 'close']):
                if len(df_indicators[['high', 'low', 'close']].dropna()) >= 14:
                    df_indicators['atr'] = ta.atr(df_indicators['high'].astype(float), df_indicators['low'].astype(float), df_indicators['close'].astype(float), length=14)
                    # ATR percentage of price
                    df_indicators['atr_percent'] = (df_indicators['atr'] / df_indicators['close']) * 100
                else: 
                    df_indicators['atr'] = np.nan
                    df_indicators['atr_percent'] = np.nan
            else: 
                df_indicators['atr'] = np.nan
                df_indicators['atr_percent'] = np.nan

            # Enhanced ROC calculations with ATR adjustment (now ATR is available)
            roc12 = ta.roc(df_indicators['close'], length=12)
            if roc12 is not None and not roc12.empty: 
                df_indicators['roc12_3_min'] = roc12.rolling(window=3, min_periods=1).min()
                # ATR-adjusted ROC12 threshold
                if 'atr' in df_indicators.columns and not df_indicators['atr'].isna().all():
                    df_indicators['roc12_atr_adjusted'] = roc12 / df_indicators['atr'].rolling(window=14, min_periods=1).mean()
                else:
                    df_indicators['roc12_atr_adjusted'] = np.nan
            else: 
                df_indicators['roc12_3_min'] = np.nan
                df_indicators['roc12_atr_adjusted'] = np.nan

            roc24 = ta.roc(df_indicators['close'], length=24)
            if roc24 is not None and not roc24.empty: 
                df_indicators['roc24_3_min'] = roc24.rolling(window=3, min_periods=1).min()
                # ATR-adjusted ROC24 threshold
                if 'atr' in df_indicators.columns and not df_indicators['atr'].isna().all():
                    df_indicators['roc24_atr_adjusted'] = roc24 / df_indicators['atr'].rolling(window=14, min_periods=1).mean()
                else:
                    df_indicators['roc24_atr_adjusted'] = np.nan
            else: 
                df_indicators['roc24_3_min'] = np.nan
                df_indicators['roc24_atr_adjusted'] = np.nan

            # Volume-weighted price performance
            df_indicators['vwap'] = (df_indicators['close'] * df_indicators['volume']).rolling(window=20, min_periods=1).sum() / df_indicators['volume'].rolling(window=20, min_periods=1).sum()
            df_indicators['price_vs_vwap'] = ((df_indicators['close'] - df_indicators['vwap']) / df_indicators['vwap']) * 100

            # Volume analysis
            df_indicators['volume_sma'] = df_indicators['volume'].rolling(window=20, min_periods=1).mean()
            df_indicators['volume_ratio'] = df_indicators['volume'] / df_indicators['volume_sma']

            # Enhanced Fractal Analysis for Multibagger Strategy
            highs = df_indicators['high']
            lows = df_indicators['low']
            
            # Bullish Fractal (for entry confirmation)
            high_minus_1 = highs.shift(1)
            high_minus_2 = highs.shift(2)
            high_plus_1 = highs.shift(-1)
            high_plus_2 = highs.shift(-2)
            
            # Bullish fractal: current high is higher than 2 bars before and 2 bars after
            df_indicators['bullish_fractal'] = (highs > high_minus_2) & (highs > high_minus_1) & \
                                             (highs > high_plus_1) & (highs > high_plus_2)
            df_indicators['bullish_fractal'] = df_indicators['bullish_fractal'].fillna(False)
            
            # Bearish Fractal (for consolidation detection)
            low_minus_1 = lows.shift(1)
            low_minus_2 = lows.shift(2)
            low_plus_1 = lows.shift(-1)
            low_plus_2 = lows.shift(-2)
            
            # Bearish fractal: current low is lower than 2 bars before and 2 bars after
            df_indicators['bearish_fractal'] = (lows < low_minus_2) & (lows < low_minus_1) & \
                                             (lows < low_plus_1) & (lows < low_plus_2)
            df_indicators['bearish_fractal'] = df_indicators['bearish_fractal'].fillna(False)
            
            # Fractal Strength Analysis
            # Count recent bullish fractals (last 5 periods)
            df_indicators['bullish_fractal_count'] = df_indicators['bullish_fractal'].rolling(window=5, min_periods=1).sum()
            
            # Count recent bearish fractals (last 5 periods) - for consolidation detection
            df_indicators['bearish_fractal_count'] = df_indicators['bearish_fractal'].rolling(window=5, min_periods=1).sum()
            
            # Enhanced Fractal Breakout Detection
            # Find the highest high from recent bearish fractal periods (consolidation resistance)
            df_indicators['recent_bearish_fractal_high'] = df_indicators['high'].rolling(window=5, min_periods=1).max().shift(1)
            
            # Price breaking above recent bearish fractal high (consolidation breakout)
            df_indicators['fractal_breakout'] = df_indicators['close'] > df_indicators['recent_bearish_fractal_high']
            
            # Alternative: Price breaking above recent bullish fractal high
            df_indicators['bullish_fractal_breakout'] = df_indicators['close'] > df_indicators['high'].rolling(window=5, min_periods=1).max().shift(1)

        return df_indicators, "OK"

    except Exception as e:
        logger.error(f"Error calculating {timeframe} indicators (Symbol: {df.get('symbol_debug', 'N/A')}): {e}", exc_info=True)
        return df, f"Indicator Calculation Error: {e}"
# --- Scanning Logic ---
# --- Scanning Logic ---
def run_scan(kite_api, symbols):
    results = []
    today_dt = datetime.datetime.now()
    today_date = today_dt.date()

    monthly_from_dt = today_dt - timedelta(days=2.5*365)
    weekly_from_dt = today_dt - timedelta(days=1.5*365)  # ~18 months for weekly data

    monthly_from_date_key = monthly_from_dt.date()
    weekly_from_date_key = weekly_from_dt.date()
    today_key = today_date

    all_valid_tokens = [kite_api.get_instrument_token(s) for s in symbols if kite_api.get_instrument_token(s)]
    quote_data_map = {}
    if all_valid_tokens:
        batch_size = 400 
        logger.info(f"Fetching quotes for {len(all_valid_tokens)} valid tokens in batches of {batch_size}...")
        for i in range(0, len(all_valid_tokens), batch_size):
            batch_tokens = all_valid_tokens[i:i+batch_size]
            try:
                quote_data_batch = kite_api.get_quote(batch_tokens)
                if quote_data_batch: quote_data_map.update(quote_data_batch)
                logger.info(f"Fetched quote batch {i//batch_size + 1}/{(len(all_valid_tokens) + batch_size - 1)//batch_size}")
            except Exception as e: logger.error(f"Error fetching quote data batch (starts with token {batch_tokens[0]}...): {e}")
        logger.info(f"Finished fetching quotes. Received data for {len(quote_data_map)} tokens.")
    else: logger.warning("No valid instrument tokens found for any symbols.")

    processed_count = 0
    total_symbols = len(symbols)
    for symbol in symbols:
        processed_count += 1
        instrument_token = kite_api.get_instrument_token(symbol)

        result_data = {
            'Symbol': symbol, 'InstrumentToken': instrument_token if instrument_token else 'Not Found',
            'ScanDate': today_date.strftime('%Y-%m-%d'), 'ProcessingStatus': 'Started',
            'LastPrice': np.nan, 'DailyVolume': np.nan, 'MarketCap_Est_Cr': np.nan,
            'VolumeFilterResult': 'N/A (Filter Removed)',
            'MonthlyDataStatus': 'Not Fetched', 'MonthlyIndicatorStatus': 'Not Calculated', 'MonthlyFilterResult': 'Not Checked',
            'Monthly_SMA3': np.nan, 'Monthly_SMA10': np.nan, 
            'Monthly_Prev_SMA3': np.nan, 'Monthly_Prev_SMA10': np.nan,
            'Monthly_KC_Middle': np.nan, 'Monthly_Prev_KC_Middle': np.nan, 
            'Monthly_KC_Middle_Slope': np.nan, 'Monthly_Distance_From_KC_Middle': np.nan,
            'Monthly_3x10_Cross_Check': False, 'Monthly_KC_Slope_Check': False, 'Monthly_Distance_Check': False,
            'Monthly_TRIX10': np.nan, 'Monthly_TRIX_Momentum': np.nan, 'Monthly_TRIX_Volatility': np.nan,
            'Monthly_TRIX_Check': False, 'Monthly_TRIX_Momentum_Check': False, 'Monthly_TRIX_Crossover_Check': False,
            'Monthly_Last_Month_Bearish_Fractal': False, 'Monthly_Bearish_Fractal_Breakout': False,
            'Monthly_TRIX_Period_Used': 'N/A', 'Monthly_Data_Quality': 'N/A',
            'WeeklyDataStatus': 'Not Fetched', 'WeeklyIndicatorStatus': 'Not Calculated', 'WeeklyFilterResult': 'Not Checked',
            'Weekly_Close': np.nan, 'Weekly_SMA3': np.nan, 'Weekly_SMA10': np.nan, 'Weekly_RSI12': np.nan, 'Weekly_RSI24': np.nan,
            'Weekly_ATR': np.nan, 'Weekly_ATR_Percent': np.nan, 'Weekly_Volume_Ratio': np.nan, 'Weekly_Price_vs_VWAP': np.nan,
            'Weekly_Trend_Check': False, 'Weekly_RSI_Check': False, 'Weekly_Volume_Check': False,
            'Weekly_Bullish_Fractal_Count': np.nan, 'Weekly_Bearish_Fractal_Count': np.nan, 'Weekly_Fractal_Breakout': False, 'Weekly_Bullish_Fractal_Breakout': False, 'Weekly_Fractal_Strength': False,
            'Weekly_TRIX5': np.nan, 'Weekly_TRIX_Momentum': np.nan, 'Weekly_TRIX_Volatility': np.nan,
            'Weekly_TRIX_Check': False, 'Weekly_TRIX_Momentum_Check': False, 'Weekly_TRIX_Crossover_Check': False,
            'Weekly_TRIX_Period_Used': 'N/A',
            'Weekly_Entry_Signal': False, 'Trend_Stage': 'None', 'Conviction_Level': 'None', 'Potential_Setup_Type': 'None'
        }

        if not instrument_token:
            logger.warning(f"Skipping {symbol}: Instrument token not found.")
            result_data['ProcessingStatus'] = 'Token Not Found'
            results.append(result_data)
            continue

        logger.info(f"\n--- Processing ({processed_count}/{total_symbols}): {symbol} ({instrument_token}) ---")

        try:
            quote_info = quote_data_map.get(str(instrument_token))
            if quote_info and isinstance(quote_info, dict):
                last_price = quote_info.get('last_price')
                daily_volume_from_quote = quote_info.get('volume')
                result_data['LastPrice'] = float(last_price) if pd.notna(last_price) else np.nan
                result_data['DailyVolume'] = int(daily_volume_from_quote) if pd.notna(daily_volume_from_quote) else np.nan
                if pd.notna(last_price) and pd.notna(daily_volume_from_quote) and daily_volume_from_quote > 0:
                    market_cap_proxy_cr = (last_price * daily_volume_from_quote) / 10000000
                    result_data['MarketCap_Est_Cr'] = round(market_cap_proxy_cr, 2)
                else: result_data['MarketCap_Est_Cr'] = 0.0 if pd.notna(last_price) else np.nan
                logger.debug(f"{symbol}: Price: {result_data['LastPrice']:.2f}, Volume (from quote): {result_data['DailyVolume']}")
                result_data['ProcessingStatus'] = 'Quote Data Processed'
            else:
                logger.warning(f"No valid quote data for {symbol} ({instrument_token}). LastPrice/DailyVolume (from quote) are NaN.")
                result_data['ProcessingStatus'] = 'Quote Data Missing/Invalid'
        except Exception as e:
            logger.error(f"Error processing quote data for {symbol}: {e}", exc_info=True)
            result_data['ProcessingStatus'] = f'Quote Processing Error: {e}'
            results.append(result_data)
            continue

        df_monthly = None
        monthly_indicators_ok = False
        passed_monthly_filters = False
        major_bf_breakout = False  # NEW

        try:
            monthly_cache_key = f"{instrument_token}_monthly_{monthly_from_date_key}_{today_key}"
            logger.debug(f"{symbol}: Monthly cache key: {monthly_cache_key}")
            
            df_monthly_from_source = get_cached_data(monthly_cache_key)
            if df_monthly_from_source is None:
                logger.debug(f"{symbol}: Monthly data not in cache, fetching from API...")
                logger.debug(f"{symbol}: Fetching monthly data from {monthly_from_dt} to {today_dt}")
                df_monthly_from_source = kite_api.get_historical_data(instrument_token, monthly_from_dt, today_dt, 'month')
                logger.debug(f"{symbol}: API returned monthly data shape: {df_monthly_from_source.shape if df_monthly_from_source is not None else 'None'}")
                if df_monthly_from_source is not None and not df_monthly_from_source.empty:
                    set_cached_data(monthly_cache_key, df_monthly_from_source)
                    logger.debug(f"{symbol}: Monthly data cached successfully")
            else:
                logger.debug(f"{symbol}: Monthly data found in cache, shape: {df_monthly_from_source.shape}")

            logger.debug(f"{symbol}: Starting monthly data validation...")
            is_valid_monthly, val_status_monthly = validate_historical_data(df_monthly_from_source, monthly_from_date_key, today_key, 'month')
            result_data['MonthlyDataStatus'] = val_status_monthly
            logger.debug(f"{symbol}: Monthly validation result: {is_valid_monthly}, status: {val_status_monthly}")

            if is_valid_monthly:
                df_monthly_with_indicators, ind_status_monthly = calculate_indicators(df_monthly_from_source.copy(), timeframe="monthly", symbol=symbol)
                result_data['MonthlyIndicatorStatus'] = ind_status_monthly
                if df_monthly_with_indicators is not None and ind_status_monthly == "OK":
                    monthly_indicators_ok = True
                    df_monthly = df_monthly_with_indicators
                    
                    # Track TRIX period used and data quality
                    trix_period = df_monthly.attrs.get('trix_period', 10)
                    monthly_data_points = len(df_monthly)
                    
                    if trix_period is not None:
                        result_data['Monthly_TRIX_Period_Used'] = f'TRIX({trix_period})'
                    else:
                        result_data['Monthly_TRIX_Period_Used'] = 'No TRIX (Insufficient Data)'
                    
                    # Classify data quality based on available months
                    if monthly_data_points >= 30:
                        result_data['Monthly_Data_Quality'] = 'Excellent (30+ months)'
                    elif monthly_data_points >= 20:
                        result_data['Monthly_Data_Quality'] = 'Good (20-29 months)'
                    elif monthly_data_points >= 15:
                        result_data['Monthly_Data_Quality'] = 'Fair (15-19 months)'
                    else:
                        result_data['Monthly_Data_Quality'] = 'Poor (<15 months)'
                    
                    logger.debug(f"{symbol}: Using {result_data['Monthly_TRIX_Period_Used']} with {result_data['Monthly_Data_Quality']}") 

                    min_monthly_rows_for_filter = 3  # Need at least 3 rows for slope calculations
                    if len(df_monthly) >= min_monthly_rows_for_filter:
                        last_m = df_monthly.iloc[-1]; prev_m = df_monthly.iloc[-2]
                        # Get TRIX period from the DataFrame attributes
                        trix_period = df_monthly.attrs.get('trix_period', 10)
                        
                        # Determine TRIX column based on whether TRIX was calculated
                        if trix_period is not None:
                            trix_column = f'trix_{trix_period}'
                        else:
                            trix_column = 'trix_na'  # Use the placeholder column
                        
                        result_data.update({
                            'Monthly_SMA3': last_m.get('sma3', np.nan), 'Monthly_SMA10': last_m.get('sma10', np.nan),
                            'Monthly_Prev_SMA3': prev_m.get('sma3', np.nan), 'Monthly_Prev_SMA10': prev_m.get('sma10', np.nan),
                            'Monthly_KC_Middle': last_m.get('kc_middle', np.nan), 
                            'Monthly_Prev_KC_Middle': prev_m.get('kc_middle', np.nan),
                            'Monthly_KC_Middle_Slope': last_m.get('kc_middle_slope', np.nan),
                            'Monthly_Distance_From_KC_Middle': last_m.get('distance_from_kc_middle', np.nan),
                            'Monthly_TRIX10': last_m.get(trix_column, np.nan),  # Dynamic TRIX column
                            'Monthly_TRIX_Momentum': last_m.get('trix_momentum', np.nan),
                            'Monthly_TRIX_Volatility': last_m.get('trix_volatility', np.nan),
                            'Monthly_Last_Month_Bearish_Fractal': last_m.get('last_month_bearish_fractal', False),
                            'Monthly_Bearish_Fractal_Breakout': last_m.get('monthly_bearish_fractal_breakout', False),
                            'Major_Bearish_Fractal_Breakout': last_m.get('major_bearish_fractal_breakout', False),  # NEW
                        })
                        
                        # Enhanced SMA3 vs KC Middle Cross Analysis
                        sma3_now, kc_mid_now = result_data['Monthly_SMA3'], result_data['Monthly_KC_Middle']
                        sma3_prev, kc_mid_prev = result_data['Monthly_Prev_SMA3'], result_data['Monthly_Prev_KC_Middle']
                        kc_slope = result_data['Monthly_KC_Middle_Slope']
                        distance_from_kc = result_data['Monthly_Distance_From_KC_Middle']
                        
                        # Basic cross check
                        cross_check = all(pd.notna([sma3_now, kc_mid_now, sma3_prev, kc_mid_prev])) and \
                                          (last_price > kc_mid_now and sma3_prev < kc_mid_prev)
                        result_data['Monthly_3x10_Cross_Check'] = cross_check
                        
                        # KC Slope check (KC Middle should be trending up)
                        kc_slope_check = pd.notna(kc_slope) and kc_slope > 0
                        result_data['Monthly_KC_Slope_Check'] = kc_slope_check
                        
                        # Distance check (avoid whipsaws - price should be reasonably above KC Middle)
                        distance_check = pd.notna(distance_from_kc) and distance_from_kc > 0.5  # At least 0.5% above KC Middle
                        result_data['Monthly_Distance_Check'] = distance_check
                        
                        # Enhanced TRIX Analysis with Dynamic Period
                        trix_val = result_data['Monthly_TRIX10']
                        trix_momentum = result_data['Monthly_TRIX_Momentum']
                        trix_volatility = result_data['Monthly_TRIX_Volatility']
                        
                        # Check if TRIX data is available
                        if trix_period is not None and pd.notna(trix_val):
                            # Dynamic TRIX threshold based on period and volatility
                            if pd.notna(trix_volatility) and trix_volatility > 0:
                                # Adjust threshold based on TRIX period and volatility
                                # Shorter periods (3,5) are more sensitive, so use lower thresholds
                                base_threshold = 1.5 if trix_period >= 10 else (1.0 if trix_period >= 5 else 0.5)
                                dynamic_trix_threshold = min(base_threshold * 1.5, base_threshold + (trix_volatility * 0.3))
                            else:
                                # Default thresholds based on TRIX period
                                dynamic_trix_threshold = 1.5 if trix_period >= 10 else (1.0 if trix_period >= 5 else 0.5)
                            
                            # Basic TRIX check with dynamic threshold
                            trix_check = trix_val < dynamic_trix_threshold
                            result_data['Monthly_TRIX_Check'] = trix_check
                            
                            logger.debug(f"{symbol}: TRIX({trix_period}) value: {trix_val:.4f}, threshold: {dynamic_trix_threshold:.4f}, check: {trix_check}")
                            
                            # TRIX Momentum check (should be improving)
                            trix_momentum_check = pd.notna(trix_momentum) and trix_momentum > -0.5  # Momentum should not be too negative
                            result_data['Monthly_TRIX_Momentum_Check'] = trix_momentum_check
                            
                            # TRIX Signal Line Crossover check
                            trix_crossover = last_m.get('trix_crossover', False)
                            result_data['Monthly_TRIX_Crossover_Check'] = trix_crossover
                        else:
                            # No TRIX data available - skip TRIX checks
                            trix_check = True  # Don't fail the filter due to missing TRIX
                            trix_momentum_check = True  # Don't fail the filter due to missing TRIX momentum
                            trix_crossover = False  # No crossover data available
                            result_data['Monthly_TRIX_Check'] = trix_check
                            result_data['Monthly_TRIX_Momentum_Check'] = trix_momentum_check
                            result_data['Monthly_TRIX_Crossover_Check'] = trix_crossover
                            
                            logger.debug(f"{symbol}: Skipping TRIX checks - insufficient data for TRIX calculation")
                        
                        # Enhanced Monthly Filter Logic
                        # Primary conditions: Cross + TRIX + KC Slope + Distance
                        primary_conditions = cross_check and trix_check and kc_slope_check and distance_check
                        
                        # Secondary conditions: TRIX Momentum + Crossover (bonus points)
                        secondary_conditions = trix_momentum_check and trix_crossover
                        
                        # --- NEW: Major breakout must also meet all primary conditions ---
                        if major_bf_breakout and primary_conditions:
                            passed_monthly_filters = True
                            filter_quality = "Major Breakout" if secondary_conditions else "Major Breakout (Basic)"
                            result_data['MonthlyFilterResult'] = f'Pass ({filter_quality})'
                            result_data['ProcessingStatus'] = f'Passed Monthly Filter ({filter_quality})'
                            logger.info(f"{symbol}: Passed Monthly Filter ({filter_quality}) - Major Breakout!")
                        elif primary_conditions:
                            passed_monthly_filters = True
                            filter_quality = "Strong" if secondary_conditions else "Good"
                            result_data['MonthlyFilterResult'] = f'Pass ({filter_quality})'
                            result_data['ProcessingStatus'] = f'Passed Monthly Filter ({filter_quality})'
                            trix_display = f"TRIX: {trix_check}" if trix_period is not None else "TRIX: N/A (No Data)"
                            logger.info(f"{symbol}: Passed Monthly Filter ({filter_quality}) - Cross: {cross_check}, {trix_display}, KC Slope: {kc_slope_check}, Distance: {distance_check}, Momentum: {trix_momentum_check}, Crossover: {trix_crossover}")
                        else:
                            # Detailed failure logging
                            trix_display_val = f"{trix_val:.2f}" if pd.notna(trix_val) else "N/A (No Data)"
                            kc_slope_display = f"{kc_slope:.4f}" if pd.notna(kc_slope) else "NaN"
                            distance_display = f"{distance_from_kc:.2f}%" if pd.notna(distance_from_kc) else "NaN"
                            trix_display = f"TRIX: {trix_check} ({trix_display_val})" if trix_period is not None else "TRIX: N/A (No Data)"
                            logger.info(f"{symbol}: Failed Monthly Filter - Cross: {cross_check}, {trix_display}, KC Slope: {kc_slope_check} ({kc_slope_display}), Distance: {distance_check} ({distance_display})")
                            result_data['MonthlyFilterResult'] = f'Fail (Cross: {cross_check}, TRIX: {trix_check}, KC Slope: {kc_slope_check}, Distance: {distance_check})'
                            result_data['ProcessingStatus'] = 'Failed Monthly Filter'
                    else:
                        result_data['ProcessingStatus'] = 'Monthly Data Insufficient for Filter Logic'
                        result_data['MonthlyIndicatorStatus'] = f"Too few rows after indicators ({len(df_monthly)}) for filter"
                else: result_data['ProcessingStatus'] = f'Monthly Indicator Error: {ind_status_monthly}'
            else: result_data['ProcessingStatus'] = f'Monthly Data Invalid: {val_status_monthly}'
        except Exception as e_monthly:
            logger.error(f"Exception in monthly processing for {symbol}: {e_monthly}", exc_info=True)
            result_data['ProcessingStatus'] = f'Error in Monthly Processing: {e_monthly}'

        # --- Weekly Timeframe Processing (Bridge between Monthly and Daily) ---
        df_weekly = None
        weekly_indicators_ok = False
        passed_weekly_filters = False

        try:
            weekly_cache_key = f"{instrument_token}_weekly_{weekly_from_date_key}_{today_key}"
            df_weekly_from_source = get_cached_data(weekly_cache_key)
            if df_weekly_from_source is None:
                df_weekly_from_source = kite_api.get_historical_data(instrument_token, weekly_from_dt, today_dt, 'week')
                if df_weekly_from_source is not None and not df_weekly_from_source.empty:
                    set_cached_data(weekly_cache_key, df_weekly_from_source)

            is_valid_weekly, val_status_weekly = validate_historical_data(df_weekly_from_source, weekly_from_date_key, today_key, 'week')
            result_data['WeeklyDataStatus'] = val_status_weekly

            if is_valid_weekly:
                df_weekly_with_indicators, ind_status_weekly = calculate_indicators(df_weekly_from_source.copy(), timeframe="weekly")
                result_data['WeeklyIndicatorStatus'] = ind_status_weekly
                if df_weekly_with_indicators is not None and ind_status_weekly == "OK":
                    weekly_indicators_ok = True
                    df_weekly = df_weekly_with_indicators

                    min_weekly_rows_for_filter = 3
                    if len(df_weekly) >= min_weekly_rows_for_filter:
                        last_w = df_weekly.iloc[-1]
                        # Get weekly TRIX period used
                        weekly_trix_period = df_weekly.attrs.get('weekly_trix_period', 5)
                        weekly_trix_column = f'weekly_trix_{weekly_trix_period}'
                        
                        result_data.update({
                            'Weekly_Close': last_w.get('close', np.nan),
                            'Weekly_SMA3': last_w.get('sma3', np.nan),
                            'Weekly_SMA10': last_w.get('sma10', np.nan),
                            'Weekly_RSI12': last_w.get('rsi12', np.nan),
                            'Weekly_RSI24': last_w.get('rsi24', np.nan),
                            'Weekly_ATR': last_w.get('atr', np.nan),
                            'Weekly_ATR_Percent': last_w.get('atr_percent', np.nan),
                            'Weekly_Volume_Ratio': last_w.get('volume_ratio', np.nan),
                            'Weekly_Price_vs_VWAP': last_w.get('price_vs_vwap', np.nan),
                            'Weekly_Bullish_Fractal_Count': last_w.get('bullish_fractal_count', np.nan),
                            'Weekly_Bearish_Fractal_Count': last_w.get('bearish_fractal_count', np.nan),
                            'Weekly_Fractal_Breakout': last_w.get('fractal_breakout', False),
                            'Weekly_Bullish_Fractal_Breakout': last_w.get('bullish_fractal_breakout', False),
                            'Weekly_TRIX5': last_w.get(weekly_trix_column, np.nan),
                            'Weekly_TRIX_Momentum': last_w.get('weekly_trix_momentum', np.nan),
                            'Weekly_TRIX_Volatility': last_w.get('weekly_trix_volatility', np.nan),
                            'Weekly_TRIX_Crossover_Check': last_w.get('weekly_trix_crossover', False),
                            'Weekly_TRIX_Period_Used': f'Weekly TRIX({weekly_trix_period})'
                        })

                        # Weekly trend confirmation
                        weekly_close = result_data['Weekly_Close']
                        weekly_sma3 = result_data['Weekly_SMA3']
                        weekly_sma10 = result_data['Weekly_SMA10']
                        
                        # Weekly trend should be supportive (price above SMAs)
                        weekly_trend_check = all(pd.notna([weekly_close, weekly_sma3, weekly_sma10])) and \
                                           weekly_close > weekly_sma3 and weekly_sma3 > weekly_sma10
                        result_data['Weekly_Trend_Check'] = weekly_trend_check

                        # Weekly RSI should not be overbought
                        weekly_rsi12 = result_data['Weekly_RSI12']
                        weekly_rsi_check = pd.notna(weekly_rsi12) and weekly_rsi12 < 70
                        result_data['Weekly_RSI_Check'] = weekly_rsi_check

                        # Weekly volume should be supportive
                        weekly_volume_ratio = result_data['Weekly_Volume_Ratio']
                        weekly_volume_check = pd.notna(weekly_volume_ratio) and weekly_volume_ratio > 0.8
                        result_data['Weekly_Volume_Check'] = weekly_volume_check

                        # --- Weekly TRIX Analysis (NEW) ---
                        weekly_trix_val = result_data['Weekly_TRIX5']
                        weekly_trix_momentum = result_data['Weekly_TRIX_Momentum']
                        weekly_trix_volatility = result_data['Weekly_TRIX_Volatility']
                        weekly_trix_crossover = result_data['Weekly_TRIX_Crossover_Check']
                        
                        # Dynamic weekly TRIX threshold based on period and volatility
                        if pd.notna(weekly_trix_volatility) and weekly_trix_volatility > 0:
                            # Adjust threshold based on TRIX period and volatility
                            base_threshold = 1.0 if weekly_trix_period >= 5 else 0.5
                            dynamic_weekly_trix_threshold = min(base_threshold * 1.5, base_threshold + (weekly_trix_volatility * 0.3))
                        else:
                            # Default thresholds based on TRIX period
                            dynamic_weekly_trix_threshold = 1.0 if weekly_trix_period >= 5 else 0.5
                        
                        # Weekly TRIX check with dynamic threshold
                        weekly_trix_check = pd.notna(weekly_trix_val) and weekly_trix_val < dynamic_weekly_trix_threshold
                        result_data['Weekly_TRIX_Check'] = weekly_trix_check
                        
                        # Weekly TRIX Momentum check (should be improving)
                        weekly_trix_momentum_check = pd.notna(weekly_trix_momentum) and weekly_trix_momentum > -0.5
                        result_data['Weekly_TRIX_Momentum_Check'] = weekly_trix_momentum_check
                        
                        logger.debug(f"{symbol}: Weekly TRIX({weekly_trix_period}) value: {weekly_trix_val:.4f}, threshold: {dynamic_weekly_trix_threshold:.4f}, check: {weekly_trix_check}")

                        # Weekly filter passes if trend, RSI, and TRIX are good
                        passed_weekly_filters = weekly_trend_check and weekly_rsi_check and weekly_trix_check
                        result_data['WeeklyFilterResult'] = 'Pass' if passed_weekly_filters else 'Fail'
                        
                        if passed_weekly_filters:
                            logger.info(f"{symbol}: Passed Weekly Filter - Trend: {weekly_trend_check}, RSI: {weekly_rsi_check}, TRIX: {weekly_trix_check}, Volume: {weekly_volume_check}")
                        else:
                            # Detailed failure logging for weekly
                            trix_display_val = f"{weekly_trix_val:.2f}" if pd.notna(weekly_trix_val) else "NaN"
                            logger.info(f"{symbol}: Failed Weekly Filter - Trend: {weekly_trend_check}, RSI: {weekly_rsi_check}, TRIX: {weekly_trix_check} ({trix_display_val}), Volume: {weekly_volume_check}")
                    else:
                        result_data['ProcessingStatus'] = 'Weekly Data Insufficient for Filter Logic'
                        result_data['WeeklyIndicatorStatus'] = f"Too few rows after indicators ({len(df_weekly)}) for filter"
                else:
                    result_data['ProcessingStatus'] = f'Weekly Indicator Error: {ind_status_weekly}'
            else:
                result_data['ProcessingStatus'] = f'Weekly Data Invalid: {val_status_weekly}'
        except Exception as e_weekly:
            logger.error(f"Exception in weekly processing for {symbol}: {e_weekly}", exc_info=True)
            result_data['ProcessingStatus'] = f'Error in Weekly Processing: {e_weekly}'

        # --- Enhanced Classification System: Trend Stage + Conviction (for ALL stocks) ---
        
        # 1. Determine Trend Stage (based on monthly data)
        trend_stage = 'None'
        monthly_cross_check = result_data['Monthly_3x10_Cross_Check']
        monthly_sma3 = result_data['Monthly_SMA3']
        monthly_kc_middle = result_data['Monthly_KC_Middle']
        
        if monthly_cross_check:  # Fresh cross detected
            trend_stage = 'Fresh Breakout'
        elif all(pd.notna([monthly_sma3, monthly_kc_middle])) and monthly_sma3 > monthly_kc_middle:
            # Check how far above KC Middle (distance analysis)
            distance_from_kc = result_data['Monthly_Distance_From_KC_Middle']
            if pd.notna(distance_from_kc):
                if distance_from_kc < 5.0:  # Less than 5% above KC Middle
                    trend_stage = 'Trend Continuation'
                elif distance_from_kc < 15.0:  # 5-15% above KC Middle
                    trend_stage = 'Established Trend'
                else:  # More than 15% above KC Middle
                    trend_stage = 'Extended Trend'
            else:
                trend_stage = 'Trend Continuation'
        else:
            trend_stage = 'No Trend'
        
        result_data['Trend_Stage'] = trend_stage
        
        # 2. Determine Conviction Level (based on weekly conditions)
        conviction_level = 'None'
        conditions_met = 0
        
        if weekly_indicators_ok:
            weekly_close = result_data['Weekly_Close']
            weekly_sma3 = result_data['Weekly_SMA3']
            weekly_sma10 = result_data['Weekly_SMA10']
            weekly_rsi12 = result_data['Weekly_RSI12']
            weekly_volume_ratio = result_data['Weekly_Volume_Ratio']
            weekly_atr_percent = result_data['Weekly_ATR_Percent']
            weekly_bullish_fractal_count = result_data['Weekly_Bullish_Fractal_Count']
            weekly_bearish_fractal_count = result_data['Weekly_Bearish_Fractal_Count']
            weekly_fractal_breakout = result_data['Weekly_Fractal_Breakout']
            weekly_bullish_fractal_breakout = result_data['Weekly_Bullish_Fractal_Breakout']
            
            # Entry signal conditions for multibagger strategy
            entry_conditions = []
            
            # 1. Price momentum (close above SMAs with proper alignment)
            price_momentum = all(pd.notna([weekly_close, weekly_sma3, weekly_sma10])) and \
                           weekly_close > weekly_sma3 and weekly_sma3 > weekly_sma10
            entry_conditions.append(price_momentum)
            
            # 2. RSI not overbought but showing strength (30-70 range preferred)
            rsi_condition = pd.notna(weekly_rsi12) and 30 <= weekly_rsi12 <= 70
            entry_conditions.append(rsi_condition)
            
            # 3. Volume confirmation (above average volume)
            volume_condition = pd.notna(weekly_volume_ratio) and weekly_volume_ratio > 1.0
            entry_conditions.append(volume_condition)
            
            # 4. Volatility check (not too volatile for long-term hold)
            volatility_condition = pd.notna(weekly_atr_percent) and weekly_atr_percent < 8.0  # Less than 8% weekly volatility
            entry_conditions.append(volatility_condition)
            
            # 5. Enhanced Fractal Analysis (NEW - consolidation + breakout pattern)
            # Check for consolidation (bearish fractals) followed by breakout
            consolidation_pattern = pd.notna(weekly_bearish_fractal_count) and weekly_bearish_fractal_count >= 1  # Had some selling pressure
            breakout_confirmation = weekly_fractal_breakout  # Price broke above consolidation resistance
            fractal_strength = consolidation_pattern and breakout_confirmation
            entry_conditions.append(fractal_strength)
            result_data['Weekly_Fractal_Strength'] = fractal_strength
            
            # 6. Alternative: Bullish Fractal Breakout (if no consolidation pattern)
            # If no consolidation, check for bullish fractal breakout
            bullish_fractal_breakout = weekly_bullish_fractal_breakout
            entry_conditions.append(bullish_fractal_breakout)
            
            conditions_met = sum(entry_conditions)
            
            # Generate entry signal if majority of conditions are met (now 6 conditions, need 4+)
            entry_signal = conditions_met >= 4  # At least 4 out of 6 conditions
            result_data['Weekly_Entry_Signal'] = entry_signal
        
        # Determine conviction level based on conditions met
        if conditions_met >= 5:  # 5-6 conditions met
            conviction_level = 'High Conviction'
        elif conditions_met >= 4:  # 4 conditions met
            conviction_level = 'Moderate Conviction'
        elif conditions_met >= 3:  # 3 conditions met
            conviction_level = 'Low Conviction'
        else:
            conviction_level = 'No Conviction'
        
        result_data['Conviction_Level'] = conviction_level
        
        # 3. Generate Final Setup Type with Data Quality Classification
        if passed_monthly_filters and passed_weekly_filters and entry_signal:
            # Get data quality for classification
            data_quality = result_data.get('Monthly_Data_Quality', 'Unknown')
            trix_period_used = result_data.get('Monthly_TRIX_Period_Used', 'TRIX(10)')
            
            if trend_stage == 'Fresh Breakout' and conviction_level == 'High Conviction':
                setup_type = f'Fresh Breakout (High Conviction) - {data_quality}'
            elif trend_stage == 'Fresh Breakout' and conviction_level == 'Moderate Conviction':
                setup_type = f'Fresh Breakout (Moderate Conviction) - {data_quality}'
            elif trend_stage in ['Trend Continuation', 'Established Trend'] and conviction_level in ['High Conviction', 'Moderate Conviction']:
                setup_type = f'{trend_stage} ({conviction_level}) - {data_quality}'
            elif trend_stage == 'Extended Trend':
                setup_type = f'{trend_stage} ({conviction_level}) - {data_quality}'
            else:
                setup_type = f'{trend_stage} ({conviction_level}) - {data_quality}'
            
            result_data['Potential_Setup_Type'] = setup_type
            result_data['ProcessingStatus'] = f'Completed ({setup_type})'
            logger.info(f"{symbol}: {setup_type}! - Trend: {trend_stage}, Conviction: {conviction_level}, Conditions: {conditions_met}/6, {trix_period_used}")
        else:
            # Provide meaningful classification even for failed stocks
            data_quality = result_data.get('Monthly_Data_Quality', 'Unknown')
            trix_period_used = result_data.get('Monthly_TRIX_Period_Used', 'TRIX(10)')
            
            if not passed_monthly_filters:
                setup_type = f'Failed Monthly Filter ({trend_stage}) - {data_quality}'
            elif not passed_weekly_filters:
                setup_type = f'Failed Weekly Filter ({trend_stage}) - {data_quality}'
            elif not entry_signal:
                setup_type = f'No Entry Signal ({trend_stage}, {conviction_level}) - {data_quality}'
            else:
                setup_type = f'No Setup ({trend_stage}, {conviction_level}) - {data_quality}'
            
            result_data['Potential_Setup_Type'] = setup_type
            if result_data['ProcessingStatus'] in ['Started', 'Quote Data Processed', 'Quote Data Missing/Invalid']:
                result_data['ProcessingStatus'] = f'Completed ({setup_type})'
            logger.info(f"{symbol}: {setup_type} - Trend: {trend_stage}, Conviction: {conviction_level}, Conditions: {conditions_met}/6, {trix_period_used}")
        
        # --- Final Status Processing ---
        if result_data['ProcessingStatus'] in ['Started', 'Quote Data Processed', 'Quote Data Missing/Invalid']:
            if not monthly_indicators_ok and not weekly_indicators_ok:
                result_data['ProcessingStatus'] = 'Data Incomplete or Indicator Errors'
            elif passed_monthly_filters and passed_weekly_filters and result_data['Weekly_Entry_Signal']:
                result_data['ProcessingStatus'] = 'Completed (Multibagger Entry)'
            elif passed_monthly_filters and passed_weekly_filters and not result_data['Weekly_Entry_Signal']:
                result_data['ProcessingStatus'] = 'Completed (No Entry Signal)'
            elif passed_monthly_filters and not passed_weekly_filters:
                result_data['ProcessingStatus'] = 'Failed Weekly Filter'
            elif not passed_monthly_filters:
                if result_data['MonthlyDataStatus'] == 'OK' and result_data['MonthlyIndicatorStatus'] == 'OK':
                    result_data['ProcessingStatus'] = 'Failed Monthly Filter'


        results.append(result_data)

    logger.info(f"Finished processing all {total_symbols} symbols.")
    return pd.DataFrame(results)
# --- Main Execution ---
if __name__ == "__main__":
    logger.info(f"--- Starting MB System Scanner ---")
    logger.info(f"--- Scan Date: {datetime.date.today().strftime('%Y-%m-%d')} ---")
    start_time = time.time()

    # --- API Credentials ---
    # Add detailed debug prints HERE
    print("\n--- DEBUG INFO ---") # Make it stand out
    print(f"Current Working Directory: {os.getcwd()}")
    print(f"Script Location: {__file__}")
    print("Attempting to load environment variables...")

    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "Ugdu4KaylHzCMxHysqfKHX8FuFH24s3j"

    # Check EXACTLY what was loaded using repr() to see hidden characters/None
    print(f"Loaded API_KEY (repr): {repr(API_KEY)}")
    print(f"Loaded ACCESS_TOKEN (repr): {repr(ACCESS_TOKEN)}")

    # Evaluate the conditions for the security check separately
    cond_api_key_missing = not API_KEY
    cond_access_token_missing = not ACCESS_TOKEN
    # Handle potential None before comparing to string placeholders
    cond_api_key_is_placeholder = (API_KEY == "YOUR_API_KEY") if API_KEY else False
    cond_access_token_is_placeholder = (ACCESS_TOKEN == "YOUR_ACCESS_TOKEN") if ACCESS_TOKEN else False

    print(f"Condition 'not API_KEY': {cond_api_key_missing}")
    print(f"Condition 'not ACCESS_TOKEN': {cond_access_token_missing}")
    print(f"Condition 'API_KEY == YOUR_API_KEY': {cond_api_key_is_placeholder}")
    print(f"Condition 'ACCESS_TOKEN == YOUR_ACCESS_TOKEN': {cond_access_token_is_placeholder}")

    # --- !!! SECURITY CHECK !!! ---
    print("Entering security check...")
    # Use the evaluated conditions
    if cond_api_key_missing or cond_access_token_missing or cond_api_key_is_placeholder or cond_access_token_is_placeholder:
        print("!!! Security check FAILED !!!") # Make failure obvious in print
        logger.critical("CRITICAL: API_KEY or ACCESS_TOKEN is not set correctly or contains placeholder values.")
        logger.critical("Please check environment variables (e.g., .env file location, names, values).")
        print("--- END DEBUG INFO (EXITING) ---")
        exit(1) # Script exits here if check fails
    print("Security check PASSED.")
    print("--- END DEBUG INFO ---")
    # --- !!! END SECURITY CHECK !!! ---


    # --- Initialize API ---
    logger.info("Attempting to Initialize KiteAPI...") # Add log before init
    kite_api = KiteAPI(api_key=API_KEY, access_token=ACCESS_TOKEN)
    if not kite_api.kite or not kite_api.instrument_map :
         logger.error("Kite API initialization failed or no instruments mapped. Exiting.")
         exit(1)

    # --- Load Symbols ---
    symbols_list = []
    try:
        symbols_df = pd.read_csv(INPUT_CSV_PATH)
        symbols_list = symbols_df['Symbol'].dropna().astype(str).str.strip().unique().tolist()
        logger.info(f"Loaded {len(symbols_list)} unique symbols from {INPUT_CSV_PATH}")
    except FileNotFoundError:
        logger.error(f"Input file not found at {INPUT_CSV_PATH}. Cannot proceed.")
        exit(1)
    except Exception as e:
        logger.error(f"Error reading symbols CSV: {e}", exc_info=True)
        exit(1)

    # --- Run Scan ---
    # (rest of the main block remains the same)
    if symbols_list:
        scan_results_df = run_scan(kite_api, symbols_list)

        if scan_results_df is not None and not scan_results_df.empty:
            # Define column order for output CSV (Monthly + Weekly only for multibagger strategy)
            columns_order = [
            'Symbol', 'InstrumentToken', 'ScanDate', 'ProcessingStatus',
            'LastPrice', 'DailyVolume', 'MarketCap_Est_Cr','VolumeFilterResult',
            'MonthlyDataStatus', 'MonthlyIndicatorStatus', 'MonthlyFilterResult',
            'Monthly_SMA3', 'Monthly_SMA10', 'Monthly_Prev_SMA3', 'Monthly_Prev_SMA10',
            'Monthly_KC_Middle', 'Monthly_Prev_KC_Middle', 'Monthly_KC_Middle_Slope', 'Monthly_Distance_From_KC_Middle',
            'Monthly_3x10_Cross_Check', 'Monthly_KC_Slope_Check', 'Monthly_Distance_Check',
            'Monthly_TRIX10', 'Monthly_TRIX_Momentum', 'Monthly_TRIX_Volatility',
            'Monthly_TRIX_Check', 'Monthly_TRIX_Momentum_Check', 'Monthly_TRIX_Crossover_Check',
            'Monthly_Last_Month_Bearish_Fractal', 'Monthly_Bearish_Fractal_Breakout',
            'Major_Bearish_Fractal_Breakout', # NEW
            'Monthly_TRIX_Period_Used', 'Monthly_Data_Quality',
            'WeeklyDataStatus', 'WeeklyIndicatorStatus', 'WeeklyFilterResult',
            'Weekly_Close', 'Weekly_SMA3', 'Weekly_SMA10', 'Weekly_RSI12', 'Weekly_RSI24',
            'Weekly_ATR', 'Weekly_ATR_Percent', 'Weekly_Volume_Ratio', 'Weekly_Price_vs_VWAP',
            'Weekly_Trend_Check', 'Weekly_RSI_Check', 'Weekly_Volume_Check',
            'Weekly_TRIX5', 'Weekly_TRIX_Momentum', 'Weekly_TRIX_Volatility',
            'Weekly_TRIX_Check', 'Weekly_TRIX_Momentum_Check', 'Weekly_TRIX_Crossover_Check',
            'Weekly_TRIX_Period_Used',
            'Weekly_Bullish_Fractal_Count', 'Weekly_Bearish_Fractal_Count', 'Weekly_Fractal_Breakout', 'Weekly_Bullish_Fractal_Breakout', 'Weekly_Fractal_Strength',
            'Weekly_Entry_Signal', 'Trend_Stage', 'Conviction_Level', 'Potential_Setup_Type'
            ]
    
            # Reindex to ensure all columns exist and are ordered
            scan_results_df = scan_results_df.reindex(columns=columns_order, fill_value=np.nan)

            # Round float columns for cleaner output
            float_cols = scan_results_df.select_dtypes(include=['float']).columns
            scan_results_df[float_cols] = scan_results_df[float_cols].round(4)

            # --- Save Results ---
            try:
                scan_results_df.to_csv(OUTPUT_CSV_PATH, index=False, na_rep='NaN') # Use NaN representation
                logger.info(f"Scan complete. Results for {len(scan_results_df)} symbols saved to {OUTPUT_CSV_PATH}")
                # Log summary
                setups_found = scan_results_df[scan_results_df['Potential_Setup_Type'] != 'None']
                logger.info(f"Found {len(setups_found)} potential setups:")
                if not setups_found.empty: logger.info(f"\n{setups_found.groupby('Potential_Setup_Type').size().to_string()}")
                
                # Log TRIX period usage summary
                trix_periods_used = {}
                for symbol in scan_results_df['Symbol']:
                    # This would need to be tracked during processing, but for now just log the approach
                    pass
                logger.info("Dynamic TRIX periods implemented: TRIX(10) for 30+ months, TRIX(5) for 20-29 months, TRIX(3) for 15-19 months")
            except Exception as e: logger.error(f"Error saving results to CSV: {e}", exc_info=True)
        else: logger.info("Scan ran, but the results DataFrame is empty or None.")
    else: logger.error("No symbols loaded from the input file.")

    # --- Final Actions ---
    end_time = time.time()
    logger.info(f"Scanner finished in {end_time - start_time:.2f} seconds.")
    logger.info(f"Session cache contained {len(session_cache)} items during this run.")
    logger.info(f"--- MB System Scanner Finished ---")