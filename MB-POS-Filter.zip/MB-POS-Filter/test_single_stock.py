"""Quick test script to debug single stock analysis"""
import sys
sys.path.insert(0, '.')

from kiteconnect import KiteConnect
import pandas as pd

API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "Ugdu4KaylHzCMxHysqfKHX8FuFH24s3j"

# Initialize
kite = KiteConnect(api_key=API_KEY)
kite.set_access_token(ACCESS_TOKEN)

# Get instruments
print("Fetching instruments...")
instruments = kite.instruments("NSE")
instrument_map = {
    inst['tradingsymbol']: inst['instrument_token']
    for inst in instruments
    if inst['segment'] == 'NSE' and inst['instrument_type'] == 'EQ'
}

# Test with one stock
test_symbol = "RELIANCE"
if test_symbol in instrument_map:
    print(f"\nTesting {test_symbol}...")
    print(f"Instrument token: {instrument_map[test_symbol]}")
    
    # Fetch data
    from datetime import datetime, timedelta
    to_date = datetime.now()
    from_date = to_date - timedelta(days=90)  # Request 90 days to get ~60 trading days
    
    data = kite.historical_data(
        instrument_token=instrument_map[test_symbol],
        from_date=from_date,
        to_date=to_date,
        interval="day"
    )
    
    df = pd.DataFrame(data)
    print(f"Data length: {len(df)} days")
    print(f"\nLast 5 days:")
    print(df[['date', 'open', 'high', 'low', 'close', 'volume']].tail())
    
    # Check range expansion
    if len(df) >= 5:
        current_range = df['high'].iloc[-1] - df['low'].iloc[-1]
        prev_3_range_avg = (df['high'].iloc[-4:-1] - df['low'].iloc[-4:-1]).mean()
        range_ratio = current_range / prev_3_range_avg if prev_3_range_avg > 0 else 0
        
        current_vol = df['volume'].iloc[-1]
        prev_3_vol_avg = df['volume'].iloc[-4:-1].mean()
        vol_ratio = current_vol / prev_3_vol_avg if prev_3_vol_avg > 0 else 0
        
        print(f"\nExpansion Analysis:")
        print(f"Current range: {current_range:.2f}")
        print(f"Prev 3 days avg range: {prev_3_range_avg:.2f}")
        print(f"Range expansion ratio: {range_ratio:.2f}x")
        print(f"Volume expansion ratio: {vol_ratio:.2f}x")
        print(f"Is expanding? Range: {range_ratio >= 1.5}, Volume: {vol_ratio >= 2.0}")
else:
    print(f"{test_symbol} not found!")

