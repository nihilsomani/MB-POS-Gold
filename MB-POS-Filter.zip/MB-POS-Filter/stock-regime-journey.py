#!/usr/bin/env python3
"""
Stock Life Cycle Scanner using Kite Connect API
Analyzes where stocks are in their journey: Base -> Uptrend -> Shakeouts -> Consolidation -> Climax -> Distribution -> Downtrend
"""

import pandas as pd
import numpy as np
import json
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import requests
from kiteconnect import KiteConnect
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def percentile_of_score(arr, value):
    """Return percentile (0-1) of value within arr. arr must be 1D numpy array."""
    arr = np.asarray(arr)
    arr = arr[~np.isnan(arr)]
    if len(arr) == 0:
        return 0.0
    # proportion of historical values strictly less than value
    return float((arr < value).sum()) / len(arr)

class StockLifeCycleScanner:
    """
    Advanced stock scanner that identifies life cycle phases using technical analysis
    without external libraries like TALIB
    """
    
    def __init__(self, api_key: str, access_token: str):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.instruments_cache = {}
        self.rate_limit_delay = 0.1  # 100ms between API calls
        self.batch_size = 50  # Process in batches to manage memory
        
    def load_nse_instruments(self) -> Dict:
        """Load and cache NSE instruments to avoid repetitive API calls"""
        if self.instruments_cache:
            logger.info("Using cached instruments")
            return self.instruments_cache
            
        try:
            logger.info("Fetching NSE instruments...")
            instruments = self.kite.instruments("NSE")
            
            # Create lookup dictionary
            for instrument in instruments:
                symbol = instrument['tradingsymbol']
                self.instruments_cache[symbol] = {
                    'instrument_token': instrument['instrument_token'],
                    'exchange': instrument['exchange'],
                    'segment': instrument['segment'],
                    'lot_size': instrument['lot_size']
                }
            
            logger.info(f"Cached {len(self.instruments_cache)} NSE instruments")
            return self.instruments_cache
            
        except Exception as e:
            logger.error(f"Error loading instruments: {e}")
            return {}
    
    def get_historical_data(self, symbol: str, days: int = 400) -> Optional[pd.DataFrame]:
        """Fetch historical OHLCV data with rate limiting"""
        try:
            if symbol not in self.instruments_cache:
                logger.warning(f"Symbol {symbol} not found in cache")
                return None
                
            instrument_token = self.instruments_cache[symbol]['instrument_token']
            
            # Calculate date range
            to_date = datetime.now().date()
            from_date = to_date - timedelta(days=days)
            
            # Fetch data with rate limiting
            time.sleep(self.rate_limit_delay)
            
            historical_data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if not historical_data:
                return None
                
            df = pd.DataFrame(historical_data)
            df['date'] = pd.to_datetime(df['date'])
            df = df.sort_values('date').reset_index(drop=True)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def calculate_moving_averages(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate various moving averages"""
        periods = [10, 20, 30, 50, 200]
        
        for period in periods:
            df[f'ma_{period}'] = df['close'].rolling(window=period).mean()
            
        # Calculate slopes (rate of change over 5 periods)
        df['ma_50_slope'] = df['ma_50'].diff(5) / 5
        df['ma_200_slope'] = df['ma_200'].diff(5) / 5
        
        return df
    
    def calculate_volume_metrics(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate volume-based metrics"""
        df['volume_ma_20'] = df['volume'].rolling(window=20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_ma_20']
        
        # On Balance Volume (OBV)
        df['price_change'] = df['close'].diff()
        df['obv'] = 0
        
        for i in range(1, len(df)):
            if df.loc[i, 'price_change'] > 0:
                df.loc[i, 'obv'] = df.loc[i-1, 'obv'] + df.loc[i, 'volume']
            elif df.loc[i, 'price_change'] < 0:
                df.loc[i, 'obv'] = df.loc[i-1, 'obv'] - df.loc[i, 'volume']
            else:
                df.loc[i, 'obv'] = df.loc[i-1, 'obv']
        
        return df
    
    def calculate_volatility_metrics(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate Average True Range and volatility metrics"""
        df['prev_close'] = df['close'].shift(1)
        df['tr1'] = df['high'] - df['low']
        df['tr2'] = abs(df['high'] - df['prev_close'])
        df['tr3'] = abs(df['low'] - df['prev_close'])
        df['true_range'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)
        df['atr_14'] = df['true_range'].rolling(window=14).mean()
        
        # Calculate percentage moves
        df['pct_change'] = df['close'].pct_change()
        df['volatility_20'] = df['pct_change'].rolling(window=20).std()
        
        return df
    
    def calculate_relative_strength(self, df: pd.DataFrame, benchmark_data: pd.DataFrame = None) -> pd.DataFrame:
        """Calculate relative strength vs benchmark (simplified version)"""
        if benchmark_data is not None and len(benchmark_data) == len(df):
            df['rs'] = df['close'] / benchmark_data['close']
            df['rs_ma_10'] = df['rs'].rolling(window=10).mean()
            df['rs_slope'] = df['rs_ma_10'].diff(5) / 5
        else:
            # Simple momentum if no benchmark
            df['rs_slope'] = df['close'].pct_change(10)
            
        return df
    
    def detect_accumulation_distribution_days(self, df: pd.DataFrame, lookback: int = 20) -> Tuple[int, int]:
        """Count accumulation vs distribution days in recent period"""
        recent_df = df.tail(lookback)
        
        accumulation_days = 0
        distribution_days = 0
        
        for i in range(1, len(recent_df)):
            price_up = recent_df.iloc[i]['close'] > recent_df.iloc[i-1]['close']
            volume_up = recent_df.iloc[i]['volume'] > recent_df.iloc[i]['volume_ma_20']
            
            if price_up and volume_up:
                accumulation_days += 1
            elif not price_up and volume_up:
                distribution_days += 1
                
        return accumulation_days, distribution_days
    
    def detect_shakeouts(self, df: pd.DataFrame) -> Dict:
        """Detect shallow and deep shakeouts"""
        if len(df) < 50:
            return {'shallow_shakeout': 0, 'deep_shakeout': 0, 'survived_shakeout': False}
        
        recent_high = df['high'].tail(50).max()
        current_price = df['close'].iloc[-1]
        pullback_pct = (recent_high - current_price) / recent_high * 100
        
        # Check for recovery from pullback
        low_after_high = df.loc[df['high'] == recent_high].index[0]
        if low_after_high < len(df) - 5:  # At least 5 days after high
            recovery_strength = (current_price - df['low'].iloc[low_after_high:].min()) / df['low'].iloc[low_after_high:].min()
        else:
            recovery_strength = 0
        
        shakeout_data = {
            'pullback_pct': pullback_pct,
            'recovery_strength': recovery_strength,
            'shallow_shakeout': 1 if 5 <= pullback_pct <= 15 and recovery_strength > 0.05 else 0,
            'deep_shakeout': 1 if 20 <= pullback_pct <= 40 and recovery_strength > 0.1 else 0,
            'survived_shakeout': recovery_strength > 0.1 and pullback_pct > 10
        }
        
        return shakeout_data
    
    def calculate_life_cycle_score(self, df: pd.DataFrame) -> Dict:
        """Calculate comprehensive life cycle score based on framework"""
        if len(df) < 200:
            return {'score': 0, 'phase': 'INSUFFICIENT_DATA', 'components': {}}
        
        latest = df.iloc[-1]
        scores = {}
        
        # (A) Trend Strength Score (-3 to +3)
        trend_score = 0
        if latest['close'] > latest['ma_200']: trend_score += 1
        if latest['ma_50'] > latest['ma_200']: trend_score += 1  
        if latest['ma_10'] > latest['ma_30']: trend_score += 1
        if latest['close'] < latest['ma_200']: trend_score -= 1
        if latest['ma_50'] < latest['ma_200']: trend_score -= 1
        if latest['ma_10'] < latest['ma_30']: trend_score -= 1
        scores['trend_strength'] = trend_score
        
        # (B) Slope & Momentum Score (-2 to +2)
        slope_score = 0
        if latest['ma_50_slope'] > 0: slope_score += 1
        if latest['ma_200_slope'] > 0: slope_score += 1
        if latest['ma_50_slope'] < 0: slope_score -= 1
        if latest['ma_200_slope'] < 0: slope_score -= 1
        scores['slope_momentum'] = slope_score
        
        # (C) Volume/Participation Score (-2 to +2)
        volume_score = 0
        acc_days, dist_days = self.detect_accumulation_distribution_days(df)
        
        # Check for breakout volume
        if latest['volume_ratio'] > 1.5 and latest['close'] > latest['ma_50']:
            volume_score += 2
        elif acc_days > dist_days:
            volume_score += 1
        elif dist_days > acc_days:
            volume_score -= 1
        if latest['volume_ratio'] < 0.5:  # Very low volume
            volume_score -= 1
            
        scores['volume_participation'] = volume_score
        
        # (D) Volatility & Shakeouts Score (-2 to +2)
        shakeout_data = self.detect_shakeouts(df)
        volatility_score = 0
        
        if shakeout_data['shallow_shakeout']:
            volatility_score += 1
        if shakeout_data['deep_shakeout'] and shakeout_data['survived_shakeout']:
            volatility_score += 2
        if shakeout_data['pullback_pct'] > 40 and not shakeout_data['survived_shakeout']:
            volatility_score -= 2
            
        scores['volatility_shakeouts'] = volatility_score
        
        # (E) Relative Strength Score (-2 to +2)  
        rs_score = 0
        if 'rs_slope' in df.columns:
            if latest['rs_slope'] > 0.05:
                rs_score = 2
            elif latest['rs_slope'] < -0.05:
                rs_score = -2
        scores['relative_strength'] = rs_score
        
        # (F) Climax/Distribution Flags (-3 to 0)
        climax_score = 0
        
        # Check for parabolic move
        recent_return = (latest['close'] / df['close'].iloc[-21] - 1) * 100  # 3 week return
        if recent_return > 30 and latest['volume_ratio'] > 2:
            climax_score -= 3
        
        # Check for failed breakouts
        failed_breakouts = 0
        for i in range(len(df)-10, len(df)):
            if i > 0 and df.iloc[i]['close'] > df.iloc[i-1]['high'] and df.iloc[i]['volume_ratio'] > 1.5:
                if df.iloc[i+1:i+4]['close'].mean() < df.iloc[i-1]['high']:  # Failed to hold
                    failed_breakouts += 1
        
        if failed_breakouts >= 2:
            climax_score -= 2
            
        scores['climax_distribution'] = climax_score
        
        # Calculate total score
        total_score = sum(scores.values())
        
        # Compute historical percentiles for extreme signal detection
        # Compute recent 21-day return (if available)
        recent_return_21 = None
        if len(df) >= 22:
            recent_return_21 = (df['close'].iloc[-1] / df['close'].iloc[-22] - 1) * 100.0

        # Build historical arrays (skip the last slice so we don't include current period in hist)
        hist_returns_21 = df['close'].pct_change(21).dropna().values  # in fraction form
        hist_returns_21 = hist_returns_21 * 100.0  # convert to percent

        hist_vol_ratios = df['volume_ratio'].dropna().values
        hist_atr = df['atr_14'].dropna().values

        # Compute percentiles for the recent values
        ret21_pctile = percentile_of_score(hist_returns_21, recent_return_21) if recent_return_21 is not None else 0.0
        vol_pctile = percentile_of_score(hist_vol_ratios, latest['volume_ratio'])
        atr_pctile = percentile_of_score(hist_atr, latest['atr_14'])

        # Define an "extreme" gate for CLIMAX detection
        is_extreme_climax = (ret21_pctile >= 0.95) or (vol_pctile >= 0.90) or (atr_pctile >= 0.90)
        
        # Determine phase with extreme gate for CLIMAX
        if total_score <= -5:
            phase = "STAGE_4_DOWNTREND"
        elif -4 <= total_score <= -2:
            phase = "DISTRIBUTION_TOP"
        elif -1 <= total_score <= 1:
            phase = "BASE_ACCUMULATION" 
        elif 2 <= total_score <= 4:
            phase = "STAGE_2_UPTREND"
        elif 5 <= total_score <= 7:
            phase = "STRONG_RALLY"
        elif total_score >= 8:
            if scores.get('climax_distribution', 0) < 0 and is_extreme_climax:
                phase = "CLIMAX_EUPHORIA"
            else:
                phase = "STRONG_RALLY"
        else:
            phase = "STRONG_RALLY"
        
        return {
            'total_score': total_score,
            'phase': phase,
            'components': scores,
            'shakeout_data': shakeout_data,
            'acc_dist_ratio': acc_days / max(dist_days, 1),
            'percentiles': {
                'return_21_pctile': ret21_pctile,
                'volume_pctile': vol_pctile,
                'atr_pctile': atr_pctile,
                'is_extreme_climax': is_extreme_climax
            }
        }
    
    def generate_observations(self, symbol: str, df: pd.DataFrame, analysis: Dict) -> str:
        """Generate nuanced observations and comments"""
        latest = df.iloc[-1]
        observations = []
        
        # Phase-specific observations
        phase = analysis['phase']
        score = analysis['total_score']
        components = analysis['components']
        
        observations.append(f"📍 PHASE: {phase} (Score: {score})")
        
        if phase == "BASE_ACCUMULATION":
            observations.append("🔍 Stock in accumulation phase - potential energy building")
            if components['volume_participation'] > 0:
                observations.append("✅ Volume shows accumulation pattern")
            if latest['close'] > latest['ma_200']:
                observations.append("💡 Above 200MA suggests strength in base")
                
        elif phase == "STAGE_2_UPTREND":
            observations.append("🚀 Stock in healthy uptrend - momentum building")
            if components['volatility_shakeouts'] > 0:
                observations.append("💪 Successfully weathered shakeouts - shows resilience")
            if latest['volume_ratio'] > 1.2:
                observations.append("📈 Volume supporting the move")
                
        elif phase == "STRONG_RALLY":
            observations.append("⚡ Strong rally phase - institutional participation likely")
            if analysis['acc_dist_ratio'] > 2:
                observations.append("🎯 Strong accumulation vs distribution ratio")
            observations.append("⚠️ Monitor for climax signals")
            
        elif phase == "CLIMAX_EUPHORIA":
            observations.append("🚨 CAUTION: Climax phase detected - euphoric conditions")
            observations.append("📊 High probability of distribution ahead")
            observations.append("🎪 Retail frenzy likely - consider profit taking")
            
            # Add extreme signal details
            percentiles = analysis.get('percentiles', {})
            if percentiles.get('is_extreme_climax'):
                extreme_signals = []
                if percentiles.get('return_21_pctile', 0) >= 0.95:
                    extreme_signals.append(f"21d return: {percentiles['return_21_pctile']:.1%} percentile")
                if percentiles.get('volume_pctile', 0) >= 0.90:
                    extreme_signals.append(f"Volume: {percentiles['volume_pctile']:.1%} percentile")
                if percentiles.get('atr_pctile', 0) >= 0.90:
                    extreme_signals.append(f"ATR: {percentiles['atr_pctile']:.1%} percentile")
                if extreme_signals:
                    observations.append(f"🔥 Extreme signals: {', '.join(extreme_signals)}")
            
        elif phase == "DISTRIBUTION_TOP":
            observations.append("📉 Distribution phase - smart money likely exiting")
            if components['climax_distribution'] < -1:
                observations.append("❌ Multiple failed breakouts detected")
            observations.append("⚠️ Avoid new positions")
            
        elif phase == "STAGE_4_DOWNTREND":
            observations.append("💥 Downtrend confirmed - avoid until base formation")
            if analysis['shakeout_data']['pullback_pct'] > 50:
                observations.append("🩸 Severe decline - potential capitulation zone")
        
        # Technical observations
        ma_alignment = "🔄 "
        if latest['ma_10'] > latest['ma_30'] > latest['ma_50'] > latest['ma_200']:
            ma_alignment += "Perfect bullish MA alignment"
        elif latest['ma_10'] < latest['ma_30'] < latest['ma_50'] < latest['ma_200']:
            ma_alignment += "Perfect bearish MA alignment"
        else:
            ma_alignment += "Mixed MA signals"
        observations.append(ma_alignment)
        
        # Volume insight
        vol_insight = f"📊 Volume: {latest['volume_ratio']:.1f}x average"
        if latest['volume_ratio'] > 2:
            vol_insight += " (HIGH)"
        elif latest['volume_ratio'] < 0.5:
            vol_insight += " (LOW)"
        observations.append(vol_insight)
        
        # Volatility insight
        atr_pct = (latest['atr_14'] / latest['close']) * 100
        observations.append(f"🌊 Volatility: {atr_pct:.1f}% ATR")
        
        return " | ".join(observations)
    
    def scan_symbols_from_csv(self, csv_file_path: str, output_file: str = None) -> pd.DataFrame:
        """Main scanning function that processes CSV input"""
        logger.info(f"Starting scan from {csv_file_path}")
        
        # Load instruments cache
        self.load_nse_instruments()
        
        # Read symbols from CSV
        try:
            symbols_df = pd.read_csv(csv_file_path)
            # Assume first column contains symbols
            symbols = symbols_df.iloc[:, 0].tolist()
            logger.info(f"Found {len(symbols)} symbols to scan")
        except Exception as e:
            logger.error(f"Error reading CSV: {e}")
            return pd.DataFrame()
        
        results = []
        processed = 0
        
        for i, symbol in enumerate(symbols):
            try:
                logger.info(f"Processing {symbol} ({i+1}/{len(symbols)})")
                
                # Fetch historical data
                df = self.get_historical_data(symbol)
                if df is None or len(df) < 200:
                    logger.warning(f"Insufficient data for {symbol}")
                    continue
                
                # Calculate all technical indicators
                df = self.calculate_moving_averages(df)
                df = self.calculate_volume_metrics(df)
                df = self.calculate_volatility_metrics(df)
                df = self.calculate_relative_strength(df)
                
                # Perform life cycle analysis
                analysis = self.calculate_life_cycle_score(df)
                
                # Generate observations
                observations = self.generate_observations(symbol, df, analysis)
                
                # Store results
                latest = df.iloc[-1]
                percentiles = analysis.get('percentiles', {})
                result = {
                    'Symbol': symbol,
                    'Date': latest['date'].strftime('%Y-%m-%d'),
                    'Close': latest['close'],
                    'Phase': analysis['phase'],
                    'Score': analysis['total_score'],
                    'Trend_Strength': analysis['components']['trend_strength'],
                    'Volume_Score': analysis['components']['volume_participation'], 
                    'Volatility_Score': analysis['components']['volatility_shakeouts'],
                    'RS_Score': analysis['components']['relative_strength'],
                    'Volume_Ratio': f"{latest['volume_ratio']:.1f}x",
                    'Pullback_Pct': f"{analysis['shakeout_data']['pullback_pct']:.1f}%",
                    'Acc_Dist_Ratio': f"{analysis['acc_dist_ratio']:.1f}",
                    'Return_21_Pctile': f"{percentiles.get('return_21_pctile', 0):.1%}",
                    'Volume_Pctile': f"{percentiles.get('volume_pctile', 0):.1%}",
                    'ATR_Pctile': f"{percentiles.get('atr_pctile', 0):.1%}",
                    'Is_Extreme_Climax': percentiles.get('is_extreme_climax', False),
                    'Observations': observations
                }
                
                results.append(result)
                processed += 1
                
                # Progress update
                if processed % 10 == 0:
                    logger.info(f"Processed {processed}/{len(symbols)} symbols")
                
            except Exception as e:
                logger.error(f"Error processing {symbol}: {e}")
                continue
        
        # Create results DataFrame
        results_df = pd.DataFrame(results)
        
        if not results_df.empty:
            # Sort by score (highest first)
            results_df = results_df.sort_values('Score', ascending=False)
            
            # Save to file if specified
            if output_file:
                results_df.to_csv(output_file, index=False)
                logger.info(f"Results saved to {output_file}")
            
            # Print summary
            logger.info(f"\n=== SCAN SUMMARY ===")
            logger.info(f"Total processed: {len(results_df)}")
            phase_counts = results_df['Phase'].value_counts()
            for phase, count in phase_counts.items():
                logger.info(f"{phase}: {count}")
        
        return results_df

# Example usage
def main():
    """Example usage of the scanner"""
    
    # Initialize scanner with your Kite Connect credentials
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "oW65VS6B688yUSOYY7fL4ybqtidH5BBP"
    
    scanner = StockLifeCycleScanner(API_KEY, ACCESS_TOKEN)
    
    # Run scan from CSV file
    results = scanner.scan_symbols_from_csv(
        csv_file_path="data\\MCAP-great2500.csv",  # Your CSV file with symbols
        output_file="stock_scan_results_new.csv"
    )
    
    # Display top results
    if not results.empty:
        print("\n🏆 TOP OPPORTUNITIES:")
        print(results.head(10)[['Symbol', 'Phase', 'Score', 'Observations']].to_string(index=False))
        
        print("\n🚀 STAGE 2 UPTREND STOCKS:")
        stage2_stocks = results[results['Phase'] == 'STAGE_2_UPTREND']
        if not stage2_stocks.empty:
            print(stage2_stocks[['Symbol', 'Score', 'Volume_Ratio', 'Observations']].to_string(index=False))

if __name__ == "__main__":
    main()