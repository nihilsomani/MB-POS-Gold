# Quick Start Guide - EMA Pullback Backtesting

## 🚀 Get Started in 5 Minutes

### Step 1: Run a Basic Backtest

```python
python backtest_scanner.py
```

This will:
- Backtest the last 2 years of data
- Use default parameters (conservative settings)
- Generate detailed results in `backtest_results/` folder

**Expected output:**
```
BACKTEST RESULTS
=================================================================
Period: 2022-10-23 to 2024-10-23 (730 days)
Initial Capital: ₹10,00,000.00
Final Capital: ₹11,24,500.00
Total Return: ₹1,24,500.00 (12.45%)
...
```

### Step 2: Analyze Results

Two files are created:

#### 1. `trades_detailed_YYYYMMDD_HHMMSS.csv`
Open in Excel to see:
- Every trade entry and exit
- Profit/loss per trade
- Setup types and quality scores
- Technical indicators at entry

**Quick checks:**
- Sort by `Net_PnL` to see best/worst trades
- Filter by `Setup_Type` to compare strategies
- Group by `Exit_Reason` to understand outcomes

#### 2. `summary_YYYYMMDD_HHMMSS.json`
Overall performance metrics:
```json
{
    "Total_Return": 12.45,
    "Win_Rate": 58.33,
    "Profit_Factor": 1.85,
    "Max_Drawdown_Pct": -5.23
}
```

### Step 3: Interpret Key Metrics

**✅ Good Results (Strategy is Working):**
- Total Return: > 15% annually
- Win Rate: > 50%
- Profit Factor: > 1.5
- Max Drawdown: < 10%

**⚠️ Acceptable Results (Needs Optimization):**
- Total Return: 5-15% annually
- Win Rate: 40-50%
- Profit Factor: 1.0-1.5
- Max Drawdown: 10-20%

**❌ Poor Results (Strategy Needs Rethinking):**
- Total Return: < 5% annually
- Win Rate: < 40%
- Profit Factor: < 1.0
- Max Drawdown: > 20%

## 🎯 Customize Your Backtest

### Quick Parameter Changes

Edit `backtest_scanner.py` at the bottom:

```python
# Example: More aggressive settings
backtester.max_position_size = 0.10  # 10% per trade (instead of 5%)
backtester.stop_loss_pct = 0.05      # 5% stop (instead of 3%)
backtester.target_pct = 0.10         # 10% target (instead of 6%)
backtester.min_quality_score = 2     # Only best setups (instead of 1)
```

### Test Different Time Periods

```python
# Last 6 months
END_DATE = datetime.now()
START_DATE = END_DATE - timedelta(days=180)

# Specific year
START_DATE = datetime(2023, 1, 1)
END_DATE = datetime(2023, 12, 31)

# Bull run period
START_DATE = datetime(2020, 4, 1)
END_DATE = datetime(2021, 3, 31)
```

## 🔧 Find Optimal Parameters

### Option 1: Run Full Optimization

```python
python optimize_parameters.py
```

**This will:**
- Test 100+ parameter combinations
- Take 30-60 minutes
- Find best settings automatically
- Rank strategies by multiple criteria

**Expected output:**
```
OPTIMIZATION RESULTS
======================================================================
--- TOP 5 BALANCED STRATEGIES ---

1. Position Size: 5% | Stop Loss: 3% | Target: 6% | Min Quality: 1
   Return: 18.45% | Win Rate: 62.5% | PF: 2.1 | Drawdown: -6.2%

2. Position Size: 2% | Stop Loss: 2% | Target: 4% | Min Quality: 2
   Return: 14.23% | Win Rate: 68.2% | PF: 1.9 | Drawdown: -3.8%
...
```

### Option 2: Manual Testing (Faster)

Test specific combinations:

```python
# Test 1: Conservative
backtester.max_position_size = 0.02
backtester.stop_loss_pct = 0.02
backtester.target_pct = 0.04
backtester.run_backtest(...)

# Test 2: Moderate
backtester.max_position_size = 0.05
backtester.stop_loss_pct = 0.03
backtester.target_pct = 0.06
backtester.run_backtest(...)

# Test 3: Aggressive
backtester.max_position_size = 0.10
backtester.stop_loss_pct = 0.05
backtester.target_pct = 0.10
backtester.run_backtest(...)
```

## 📊 Common Scenarios & Solutions

### Scenario 1: Very Few Trades (< 20 in 2 years)

**Problem:** Not enough trading opportunities

**Solutions:**
```python
# Lower quality requirement
backtester.min_quality_score = 0  # Accept all setups

# OR add more symbols to input CSV
# OR extend backtest period
START_DATE = END_DATE - timedelta(days=1095)  # 3 years
```

### Scenario 2: Many Losses, Low Win Rate

**Problem:** Too many stop losses hit

**Solutions:**
```python
# Wider stops
backtester.stop_loss_pct = 0.05  # 5% instead of 3%

# OR only trade high quality setups
backtester.min_quality_score = 2

# OR larger targets (better R:R)
backtester.target_pct = 0.09  # 9% instead of 6%
```

### Scenario 3: High Win Rate but Low Profit

**Problem:** Small wins, occasional big losses

**Solutions:**
```python
# Increase position size
backtester.max_position_size = 0.10

# OR optimize R:R ratio
backtester.stop_loss_pct = 0.02
backtester.target_pct = 0.06  # 3:1 R:R
```

### Scenario 4: Large Drawdowns

**Problem:** Too much risk per trade

**Solutions:**
```python
# Reduce position size
backtester.max_position_size = 0.02  # 2% per trade

# OR tighter stops
backtester.stop_loss_pct = 0.02

# OR stricter entry criteria
backtester.min_quality_score = 2
```

## 📈 Next Steps After Backtesting

### 1. Validate Results (5 minutes)

Check if results make sense:
- [ ] Are there enough trades? (>20)
- [ ] Is win rate reasonable? (40-70%)
- [ ] Is profit factor good? (>1.3)
- [ ] Is drawdown acceptable? (<15%)

### 2. Test Robustness (15 minutes)

Run on different periods:
```python
# Test on 3 different years
for year in [2022, 2023, 2024]:
    START_DATE = datetime(year, 1, 1)
    END_DATE = datetime(year, 12, 31)
    backtester.run_backtest(...)
```

Good strategies perform consistently across periods.

### 3. Analyze Trade Details (10 minutes)

Open `trades_detailed_*.csv` and check:

**Best trades:**
- What setup types worked best?
- What quality scores were winners?
- Any patterns in entry conditions?

**Worst trades:**
- What went wrong?
- Any avoidable mistakes?
- Need parameter adjustments?

### 4. Paper Trade (1-2 months)

Before going live:
1. Run live scanner daily
2. Record trades on paper
3. Compare with backtest expectations
4. Build confidence

### 5. Go Live (Start Small)

When ready:
1. Start with 25-50% of capital
2. Take every signal as per rules
3. Keep detailed records
4. Review weekly

## ⚡ Pro Tips

### Tip 1: Focus on Risk-Adjusted Returns

Don't just chase highest returns:
```
Strategy A: 30% return, 25% drawdown → Risk-Adjusted = 1.2
Strategy B: 20% return, 8% drawdown → Risk-Adjusted = 2.5

Strategy B is BETTER (higher risk-adjusted return)
```

### Tip 2: Quality Over Quantity

Better to have:
- 30 trades with 65% win rate
- Than 100 trades with 45% win rate

Use `min_quality_score` to filter.

### Tip 3: Match Parameters to Market

**Bull Market:**
- Wider targets (0.08-0.10)
- Longer holding (25-30 days)
- Accept more setups (min_quality = 0)

**Bear Market:**
- Tighter stops (0.02)
- Shorter holding (10-15 days)
- Stricter quality (min_quality = 2)

### Tip 4: Transaction Costs Matter

Every trade costs ~0.3% round-trip.

For ₹50,000 position:
- Entry cost: ~₹75
- Exit cost: ~₹75
- Total: ~₹150

Need at least 0.5% move just to break even!

### Tip 5: Save Your Best Configs

Create a config file:
```python
# best_config.py
CONSERVATIVE = {
    'max_position_size': 0.02,
    'stop_loss_pct': 0.02,
    'target_pct': 0.04,
    'min_quality_score': 2,
    'max_holding_days': 15
}

MODERATE = {
    'max_position_size': 0.05,
    'stop_loss_pct': 0.03,
    'target_pct': 0.06,
    'min_quality_score': 1,
    'max_holding_days': 20
}

AGGRESSIVE = {
    'max_position_size': 0.10,
    'stop_loss_pct': 0.05,
    'target_pct': 0.10,
    'min_quality_score': 0,
    'max_holding_days': 30
}
```

## 🐛 Troubleshooting

### Error: "Insufficient data for symbol"

**Cause:** Symbol doesn't have enough historical data

**Fix:** Check if symbol is newly listed or delisted

### Error: "Failed to load instruments cache"

**Cause:** API connection issue

**Fix:** 
1. Check internet connection
2. Verify API key and access token
3. Check if market is open (for live tokens)

### Error: "Rate limit exceeded"

**Cause:** Too many API calls too fast

**Fix:** Already handled in code, but if persists:
```python
self.min_request_interval = 0.5  # Increase from 0.35
```

### Warning: "No trades executed"

**Cause:** Parameters too strict or period too short

**Fix:**
```python
# Relax parameters
backtester.min_quality_score = 0
# OR extend period
START_DATE = END_DATE - timedelta(days=1095)  # 3 years
```

## 📚 Reference

### File Structure
```
F4/scan/
├── myscanner.py              # Live scanner
├── backtest_scanner.py       # Backtest engine
├── optimize_parameters.py    # Parameter optimization
├── BACKTEST_README.md        # Full documentation
└── QUICKSTART_BACKTEST.md    # This file
```

### Key Parameters Reference

| Parameter | Default | Description | Range |
|-----------|---------|-------------|-------|
| `max_position_size` | 0.05 | % of capital per trade | 0.02-0.10 |
| `stop_loss_pct` | 0.03 | Stop loss % | 0.02-0.05 |
| `target_pct` | 0.06 | Target profit % | 0.04-0.10 |
| `min_quality_score` | 1 | Minimum setup quality | 0-2 |
| `max_holding_days` | 20 | Max days to hold | 10-30 |

### Setup Type Priority

1. **BOUNCED_FROM_EMA** (Best)
   - Highest win rate
   - Already showing momentum
   - Quality score = 2

2. **PULLBACK_TO_21_EMA** (Good)
   - Classic pullback setup
   - Quality score = 0-2

3. **BETWEEN_21_55_EMA** (Okay)
   - Deeper pullback
   - Lower win rate
   - Quality score = 0-2

## 🎓 Learning Resources

### Understanding Results

1. **Win Rate**: % of winning trades
   - Higher is better, but not everything
   - Professional traders: 40-60%

2. **Profit Factor**: Gross profit / Gross loss
   - Must be > 1.0 to be profitable
   - Good: > 1.5
   - Excellent: > 2.0

3. **Max Drawdown**: Largest peak-to-trough decline
   - Psychological metric
   - Can you handle this loss?
   - Keep < 20% for most traders

4. **Risk-Adjusted Return**: Return / Drawdown
   - Best overall metric
   - Accounts for risk taken
   - Higher is always better

### Recommended Reading Order

1. Read this file (you're here! ✓)
2. Run basic backtest
3. Read BACKTEST_README.md for details
4. Optimize parameters
5. Paper trade before going live

## ✅ Quick Checklist

Before going live, ensure:

- [ ] Backtest shows positive returns
- [ ] Win rate > 45%
- [ ] Profit factor > 1.3
- [ ] Max drawdown acceptable to you
- [ ] Tested on multiple time periods
- [ ] Analyzed best/worst trades
- [ ] Paper traded for 1-2 months
- [ ] Comfortable with risk per trade
- [ ] Have clear entry/exit rules
- [ ] Ready to follow system mechanically

## 🚦 Start Here

**Complete beginner?**
1. Run `python backtest_scanner.py`
2. Check if results are positive
3. Read BACKTEST_README.md
4. Paper trade

**Some experience?**
1. Customize parameters
2. Run optimization
3. Test robustness
4. Paper trade best config

**Experienced trader?**
1. Review code logic
2. Modify entry/exit rules
3. Add custom features
4. Optimize and deploy

---

**Questions?**
- Check BACKTEST_README.md for detailed explanations
- Review code comments for technical details
- Test different parameters to understand impact

**Ready to backtest?**
```bash
python backtest_scanner.py
```

Good luck! 🚀📈

