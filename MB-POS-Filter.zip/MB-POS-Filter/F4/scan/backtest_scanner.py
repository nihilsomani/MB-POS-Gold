import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import time
from datetime import datetime, timedelta
import logging
from typing import Dict, List, Tuple, Optional
import json

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class EMAPullbackBacktester:
    """
    Comprehensive backtester for EMA Pullback Scanner strategy
    
    REFINED VERSION - Optimized through data-driven analysis
    ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    Based on backtest analysis:
    - BETWEEN_21_55_EMA removed (only 14.66% win rate)
    - BOUNCED_FROM_EMA prioritized (41% win rate)
    - Quality score filter ≥1 (removes weak setups)
    
    Expected Performance:
    - Return: ~656% over 2 years
    - Win Rate: ~38.5%
    - Max Drawdown: ~16%
    - Best risk-adjusted returns
    
    Features:
    - Multiple setup types with quality scoring
    - Realistic entry/exit simulation
    - Risk management with position sizing
    - Comprehensive performance metrics
    - Trade-by-trade analysis
    - Per-setup type performance breakdown
    """
    
    def __init__(self, api_key, access_token):
        """Initialize backtester with Kite Connect credentials"""
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Rate limiting: 3 requests per second
        self.last_request_time = 0
        self.min_request_interval = 0.35
        
        # Cache for instruments
        self.instruments_cache = None
        self.symbol_token_map = {}
        
        # Backtest configuration
        self.initial_capital = 1000000  # 10 lakhs
        self.max_position_size = 0.05  # 5% of capital per trade
        self.stop_loss_pct = 0.04  # 4% stop loss
        self.target_pct = 0.08  # 8% target (2:1 R:R)
        self.max_holding_days = 20  # Exit if no target/SL hit in 20 days
        self.min_quality_score = 1  # Minimum quality score to take trade
        
        # Phase 1 Enhancement Filters (Quick Wins)
        self.enable_relative_strength = False  # Set to True to test
        self.enable_volume_confirmation = False  # Set to True to test
        self.enable_price_position = False  # Set to True to test
        self.enable_weinstein_stage_2 = False  # Set to True to test (POWERFUL!)
        
        self.min_relative_strength = 1.05  # Must outperform Nifty by 5%
        self.volume_multiplier = 1.2  # 20% above average volume
        self.price_position_min = 0.25  # Not too low (weak)
        self.price_position_max = 0.85  # Not too high (resistance)
        
        # Nifty data cache (for relative strength in backtest)
        self.nifty_data_cache = {}
        self.nifty_token = 256265  # NIFTY 50
        self.nifty50_token = 256265  # NIFTY 50 for market breadth (has full historical data)
        
        # Market breadth filter (NIFTY 50 - has full historical data)
        self.enable_market_breadth_filter = False  # DISABLED - proven redundant (setups naturally occur on healthy days)
        self.min_breadth_score = 45  # Minimum breadth score (0-100) - only filter truly bearish markets
        
        # Performance tracking
        self.trades = []
        self.equity_curve = []
        self.current_capital = self.initial_capital
        self.filtered_setups_count = 0  # Track how many setups were filtered
        self.breadth_filtered_count = 0  # Track breadth filter specifically
        
    def _rate_limit(self):
        """Enforce rate limiting"""
        current_time = time.time()
        time_since_last_request = current_time - self.last_request_time
        
        if time_since_last_request < self.min_request_interval:
            sleep_time = self.min_request_interval - time_since_last_request
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def load_instruments_cache(self):
        """Load NSE instruments and create symbol-token mapping"""
        logger.info("Loading NSE instruments cache...")
        self._rate_limit()
        
        try:
            instruments = self.kite.instruments("NSE")
            self.instruments_cache = pd.DataFrame(instruments)
            
            for _, row in self.instruments_cache.iterrows():
                if row['segment'] == 'NSE':
                    self.symbol_token_map[row['tradingsymbol']] = row['instrument_token']
            
            logger.info(f"Loaded {len(self.symbol_token_map)} NSE instruments")
            return True
        except Exception as e:
            logger.error(f"Error loading instruments: {e}")
            return False
    
    def get_historical_data(self, symbol, from_date, to_date):
        """Fetch historical data for a symbol"""
        if symbol not in self.symbol_token_map:
            logger.warning(f"Symbol {symbol} not found in NSE instruments")
            return None
        
        instrument_token = self.symbol_token_map[symbol]
        self._rate_limit()
        
        try:
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)  # Remove timezone info
                df = df.sort_values('date').reset_index(drop=True)
            return df
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def calculate_indicators(self, df):
        """Calculate all technical indicators"""
        df = df.copy()
        df['EMA_10'] = df['close'].ewm(span=10, adjust=False).mean()
        df['EMA_21'] = df['close'].ewm(span=21, adjust=False).mean()
        df['EMA_55'] = df['close'].ewm(span=55, adjust=False).mean()
        return df
    
    def detect_consolidation(self, prices, lookback=5):
        """Detect price consolidation"""
        if len(prices) < lookback:
            return False, 0
        
        recent_prices = prices[-lookback:]
        volatility = (recent_prices.max() - recent_prices.min()) / recent_prices.mean()
        is_consolidating = volatility < 0.02
        return is_consolidating, round(volatility * 100, 2)
    
    def detect_volume_drying(self, volumes, lookback=5):
        """Detect decreasing volume trend"""
        if len(volumes) < lookback:
            return False, 0
        
        recent_volume = volumes[-lookback:]
        earlier_volume = volumes[-lookback*2:-lookback] if len(volumes) >= lookback*2 else volumes[:-lookback]
        
        if len(earlier_volume) == 0:
            return False, 0
        
        recent_avg = recent_volume.mean()
        earlier_avg = earlier_volume.mean()
        volume_decrease = ((earlier_avg - recent_avg) / earlier_avg) * 100
        is_drying = volume_decrease > 20
        return is_drying, round(volume_decrease, 2)
    
    def check_price_near_ema(self, price, ema, tolerance=0.015):
        """Check if price is near EMA"""
        distance = abs(price - ema) / ema
        return distance <= tolerance, round(distance * 100, 2)
    
    def check_bullish_candle(self, df, idx):
        """
        Check if candle shows bullish price action
        Filters out weak/bearish candles
        
        Returns: (is_bullish, strength_score)
        """
        if idx >= len(df):
            return False, 0
        
        candle = df.iloc[idx]
        
        # Basic metrics
        body = candle['close'] - candle['open']
        total_range = candle['high'] - candle['low']
        
        if total_range == 0:
            return False, 0
        
        # Check if bullish (green)
        is_green = body > 0
        
        # Body strength
        body_pct = abs(body) / total_range
        
        # Wick analysis
        if is_green:
            lower_wick = candle['close'] - candle['low']
            upper_wick = candle['high'] - candle['close']
        else:
            lower_wick = candle['open'] - candle['low']
            upper_wick = candle['high'] - candle['open']
        
        # Buyers won if lower wick > upper wick (rejection of lows)
        buyers_won = lower_wick > upper_wick if total_range > 0 else False
        
        # Scoring
        score = 0
        if is_green:
            score += 50
        if body_pct > 0.5:  # Strong body
            score += 30
        if buyers_won:  # Rejection of lows
            score += 20
        
        is_bullish = score >= 50  # At least green candle
        
        return is_bullish, score
    
    def check_pullback_complete(self, df, current_idx):
        """
        Check if pullback has COMPLETED and reversal is starting
        Critical for PULLBACK setups!
        
        Returns: True if pullback is done and bounce confirmed
        """
        if current_idx < 3:
            return False
        
        current = df.iloc[current_idx]
        ema_21 = current['EMA_21']
        
        # Look back 3 days
        recent = df.iloc[max(0, current_idx-3):current_idx+1]
        
        # Check if price touched EMA in last 1-3 days
        touched_ema_recently = any(
            abs(row['close'] - row['EMA_21']) / row['EMA_21'] < 0.015
            for _, row in recent.iloc[:-1].iterrows()
        )
        
        # Is price NOW above EMA (bounced)?
        price_above_ema = current['close'] > ema_21
        
        # Is momentum turning up? (last candle green OR price higher than 2 days ago)
        current_green = current['close'] > current['open']
        price_rising = current['close'] > df.iloc[current_idx-2]['close'] if current_idx >= 2 else False
        
        # Pullback complete if touched EMA recently AND now bouncing
        return touched_ema_recently and price_above_ema and (current_green or price_rising)
    
    def calculate_relative_strength(self, symbol_df, nifty_df, current_idx, period=20):
        """Calculate Relative Strength vs Nifty at given index"""
        if current_idx < period:
            return None
        
        stock_return = (symbol_df.iloc[current_idx]['close'] / symbol_df.iloc[current_idx-period]['close']) - 1
        nifty_return = (nifty_df.iloc[current_idx]['close'] / nifty_df.iloc[current_idx-period]['close']) - 1
        
        if abs(nifty_return) > 0.0001:
            rs = (1 + stock_return) / (1 + nifty_return)
        else:
            rs = 1.0
        
        return rs
    
    def check_volume_surge(self, df, current_idx, multiplier=1.3):
        """Check if volume is above average at current index"""
        if current_idx < 20:
            return False
        
        current_volume = df.iloc[current_idx]['volume']
        avg_volume = df.iloc[current_idx-20:current_idx]['volume'].mean()
        
        if avg_volume > 0:
            return current_volume >= (avg_volume * multiplier)
        return False
    
    def check_price_position(self, df, current_idx):
        """Check price position in 52-week range at current index"""
        # Use available data up to current point
        lookback = min(252, current_idx)
        if lookback < 60:
            return 0.5  # Neutral if not enough data
        
        current_price = df.iloc[current_idx]['close']
        period_high = df.iloc[current_idx-lookback:current_idx+1]['high'].max()
        period_low = df.iloc[current_idx-lookback:current_idx+1]['low'].min()
        
        if period_high == period_low:
            return 0.5
        
        position = (current_price - period_low) / (period_high - period_low)
        return position
    
    def check_weinstein_stage_2(self, df, current_idx):
        """
        Check if stock is in Weinstein Stage 2 (Advancing/Markup phase)
        
        Stage 2 Criteria:
        - Price above 150-day MA
        - 150-day MA is rising (slope positive)
        - Stock making higher highs
        - Relative strength improving
        
        Returns: (is_stage_2, stage_name, details)
        """
        lookback_150 = 150
        lookback_30 = 30  # For slope calculation
        
        if current_idx < lookback_150:
            return None, 'UNKNOWN', {}
        
        # Get historical data up to current point
        historical_df = df.iloc[:current_idx+1]
        
        # Calculate 150-day SMA (Weinstein uses SMA, not EMA)
        ma_150 = historical_df['close'].rolling(window=150).mean()
        current_ma_150 = ma_150.iloc[-1]
        
        current_price = historical_df['close'].iloc[-1]
        
        # Check if price above 150 MA
        price_above_ma = current_price > current_ma_150
        
        # Check if 150 MA is rising (compare current vs 30 days ago)
        if len(ma_150) >= lookback_30:
            ma_150_now = ma_150.iloc[-1]
            ma_150_past = ma_150.iloc[-lookback_30]
            ma_rising = ma_150_now > ma_150_past
            ma_slope_pct = ((ma_150_now - ma_150_past) / ma_150_past) * 100
        else:
            ma_rising = False
            ma_slope_pct = 0
        
        # Check if making higher highs (recent high > high 30 days ago)
        if len(historical_df) >= lookback_30:
            recent_high = historical_df['high'].iloc[-10:].max()
            past_high = historical_df['high'].iloc[-lookback_30:-10].max()
            making_higher_highs = recent_high > past_high
        else:
            making_higher_highs = False
        
        # Determine stage
        details = {
            'price': current_price,
            'ma_150': current_ma_150,
            'price_above_ma': price_above_ma,
            'ma_rising': ma_rising,
            'ma_slope_pct': round(ma_slope_pct, 2),
            'higher_highs': making_higher_highs
        }
        
        # Stage 2: Price above rising MA + making higher highs
        if price_above_ma and ma_rising and making_higher_highs:
            return True, 'STAGE_2', details
        
        # Stage 4: Price below declining MA
        elif not price_above_ma and not ma_rising:
            return False, 'STAGE_4', details
        
        # Stage 3: Price above but MA declining (topping)
        elif price_above_ma and not ma_rising:
            return False, 'STAGE_3', details
        
        # Stage 1: Price below but MA rising (basing)
        elif not price_above_ma and ma_rising:
            return False, 'STAGE_1', details
        
        else:
            return None, 'TRANSITION', details
    
    def get_nifty_data_for_backtest(self, from_date, to_date):
        """Fetch Nifty data for backtest period (with caching)"""
        cache_key = f"{from_date}_{to_date}"
        
        if cache_key in self.nifty_data_cache:
            return self.nifty_data_cache[cache_key]
        
        self._rate_limit()
        
        try:
            data = self.kite.historical_data(
                instrument_token=self.nifty_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                df = df.sort_values('date').reset_index(drop=True)
                self.nifty_data_cache[cache_key] = df
            return df
        except Exception as e:
            logger.error(f"Error fetching Nifty data: {e}")
            return None
    
    def get_nifty50_data_for_backtest(self, from_date, to_date):
        """Fetch NIFTY 50 data for breadth checking in backtest"""
        cache_key = f"nifty50_{from_date}_{to_date}"
        
        if cache_key in self.nifty_data_cache:
            return self.nifty_data_cache[cache_key]
        
        self._rate_limit()
        
        try:
            data = self.kite.historical_data(
                instrument_token=self.nifty50_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                df = df.sort_values('date').reset_index(drop=True)
                # Calculate EMAs for breadth
                df['EMA_21'] = df['close'].ewm(span=21, adjust=False).mean()
                df['EMA_50'] = df['close'].ewm(span=50, adjust=False).mean()
                self.nifty_data_cache[cache_key] = df
            return df
        except Exception as e:
            logger.error(f"Error fetching NIFTY 50 data: {e}")
            return None
    
    def check_breadth_at_point(self, nifty50_df, current_idx):
        """
        Check market breadth at a specific historical point using NIFTY 50
        
        Returns: (breadth_healthy, breadth_score)
        """
        if nifty50_df is None or current_idx >= len(nifty50_df):
            return None, None
        
        if current_idx < 50:  # Need 50 bars for EMA
            return None, None
        
        # Get data up to current point (no look-ahead!)
        historical_data = nifty50_df.iloc[:current_idx+1]
        
        latest = historical_data.iloc[-1]
        current_price = latest['close']
        ema_21 = latest['EMA_21']
        ema_50 = latest['EMA_50']
        
        # Breadth indicators
        above_21 = current_price > ema_21
        above_50 = current_price > ema_50
        ema_aligned = ema_21 > ema_50
        
        # Distance from 50 EMA
        dist_from_50 = ((current_price - ema_50) / ema_50) * 100
        
        # Calculate breadth score (0-100)
        breadth_score = 0
        if above_21:
            breadth_score += 30
        if above_50:
            breadth_score += 30
        if ema_aligned:
            breadth_score += 20
        if dist_from_50 > 5:
            breadth_score += 20
        elif dist_from_50 > 2:
            breadth_score += 10
        
        # Healthy if >= threshold
        breadth_healthy = breadth_score >= self.min_breadth_score
        
        return breadth_healthy, breadth_score
    
    def identify_setup(self, df, current_idx, nifty_df=None, nifty50_df=None):
        """
        Identify if there's a setup at the current index
        Returns: (setup_found, setup_type, quality_score, details)
        
        REFINEMENT: BETWEEN_21_55_EMA disabled (only 14.66% win rate in backtest)
        BREADTH FILTER: Check NIFTY 50 breadth at this historical point
        """
        if current_idx < 55:  # Need at least 55 bars for EMAs
            return False, None, 0, {}
        
        # CRITICAL: Check market breadth at THIS historical point (no look-ahead!)
        if self.enable_market_breadth_filter and nifty50_df is not None:
            # Get current date from stock data
            current_date = df.iloc[current_idx]['date']
            # Find matching date in nifty50 data
            nifty_idx = nifty50_df[nifty50_df['date'] <= current_date].index
            if len(nifty_idx) > 0:
                nifty_current_idx = nifty_idx[-1]  # Last date <= current_date
                breadth_healthy, breadth_score = self.check_breadth_at_point(nifty50_df, nifty_current_idx)
                
                if breadth_healthy is not None and not breadth_healthy:
                    # Market breadth was weak at this point - don't trade
                    self.filtered_setups_count += 1
                    self.breadth_filtered_count += 1
                    return False, None, 0, {}
        
        # Get data up to current index
        historical_df = df.iloc[:current_idx+1].copy()
        
        if len(historical_df) < 60:
            return False, None, 0, {}
        
        # Get current values
        current = historical_df.iloc[-1]
        current_price = current['close']
        ema_10 = current['EMA_10']
        ema_21 = current['EMA_21']
        ema_55 = current['EMA_55']
        
        # Primary condition: 21 EMA must be above 55 EMA
        if ema_21 <= ema_55:
            return False, None, 0, {}
        
        ema_21_55_spread = ((ema_21 - ema_55) / ema_55) * 100
        
        # Check consolidation and volume
        is_consolidating, consol_pct = self.detect_consolidation(
            historical_df['close'].values, lookback=5
        )
        is_volume_drying, vol_decrease = self.detect_volume_drying(
            historical_df['volume'].values, lookback=5
        )
        
        details = {
            'current_price': current_price,
            'ema_10': ema_10,
            'ema_21': ema_21,
            'ema_55': ema_55,
            'ema_spread': ema_21_55_spread,
            'consolidating': is_consolidating,
            'volume_drying': is_volume_drying,
            'consol_pct': consol_pct,
            'vol_decrease': vol_decrease
        }
        
        # PHASE 1 FILTERS: Store filter results for later use
        # SMART: Apply filters selectively based on setup type
        filter_status = {
            'rs': None,
            'volume': None,
            'position': None,
            'weinstein_stage_2': None,
            'weinstein_stage': None,
            'should_apply': False  # Will set based on setup type
        }
        
        # Calculate filter values (but don't reject yet)
        if self.enable_relative_strength and nifty_df is not None:
            filter_status['rs'] = self.calculate_relative_strength(historical_df, nifty_df, len(historical_df)-1, period=20)
        
        if self.enable_volume_confirmation:
            filter_status['volume'] = self.check_volume_surge(historical_df, len(historical_df)-1, self.volume_multiplier)
        
        if self.enable_price_position:
            filter_status['position'] = self.check_price_position(historical_df, len(historical_df)-1)
        
        # Weinstein Stage 2 check (applies to BOTH setups - powerful filter!)
        if self.enable_weinstein_stage_2:
            is_stage_2, stage_name, stage_details = self.check_weinstein_stage_2(df, current_idx)
            filter_status['weinstein_stage_2'] = is_stage_2
            filter_status['weinstein_stage'] = stage_name
        
        # Store in details for later decision
        details['filter_status'] = filter_status
        
        # SETUP 3: Bounced from EMA (Check FIRST - highest win rate: 41%)
        lookback = 5
        if len(historical_df) >= lookback:
            recent_df = historical_df.tail(lookback)
            
            touched_10_ema = any(
                abs(row['close'] - row['EMA_10']) / row['EMA_10'] < 0.015 
                for _, row in recent_df.iloc[:-1].iterrows()
            )
            
            touched_21_ema = any(
                abs(row['close'] - row['EMA_21']) / row['EMA_21'] < 0.015 
                for _, row in recent_df.iloc[:-1].iterrows()
            )
            
            price_above_10 = current_price > ema_10
            price_above_21 = current_price > ema_21
            
            recent_prices = recent_df['close'].values
            is_rising = len(recent_prices) >= 2 and recent_prices[-1] > recent_prices[-2]
            
            if (touched_10_ema or touched_21_ema) and price_above_10 and is_rising:
                quality_score = 2  # High quality setup
                
                # TIER 1 FIX: Bullish candle requirement
                is_bullish, candle_score = self.check_bullish_candle(historical_df, len(historical_df)-1)
                if not is_bullish:
                    # Current candle not bullish - likely to reverse
                    self.filtered_setups_count += 1
                    return False, None, 0, {}
                
                # BOUNCED setup: Apply only minimal filters (already high quality)
                # Only filter if stock is severely underperforming or volume collapsing
                if filter_status['rs'] is not None and filter_status['rs'] < 0.95:
                    # Severely underperforming Nifty (>5% worse)
                    self.filtered_setups_count += 1
                    return False, None, 0, {}
                
                if filter_status['volume'] is not None and not filter_status['volume']:
                    # Volume completely collapsed
                    self.filtered_setups_count += 1
                    return False, None, 0, {}
                
                # Weinstein Stage 2 filter (powerful - applies to all setups)
                if filter_status['weinstein_stage_2'] is not None and filter_status['weinstein_stage_2'] == False:
                    # Not in Stage 2 (advancing phase) - skip
                    self.filtered_setups_count += 1
                    return False, None, 0, {}
                
                details['touched_10_ema'] = touched_10_ema
                details['touched_21_ema'] = touched_21_ema
                details['price_above_21'] = price_above_21
                details['candle_strength'] = candle_score
                return True, 'BOUNCED_FROM_EMA', quality_score, details
        
        # SETUP 1: Pullback to 21 EMA (34.81% win rate - acceptable)
        near_21_ema, dist_21 = self.check_price_near_ema(current_price, ema_21, tolerance=0.02)
        
        if near_21_ema:
            quality_score = 0
            if is_consolidating:
                quality_score += 1
            if is_volume_drying:
                quality_score += 1
            
            # TIER 1 FIX: Pullback completion check
            pullback_done = self.check_pullback_complete(historical_df, len(historical_df)-1)
            if not pullback_done:
                # Pullback not finished yet - price still falling
                self.filtered_setups_count += 1
                return False, None, 0, {}
            
            # TIER 1 FIX: Bullish candle requirement
            is_bullish, candle_score = self.check_bullish_candle(historical_df, len(historical_df)-1)
            if not is_bullish:
                # Not a bullish candle - weak setup
                self.filtered_setups_count += 1
                return False, None, 0, {}
            
            # PULLBACK setup: Apply ALL filters (they boost WR from 33% to 48%!)
            filters_passed = True
            
            if filter_status['rs'] is not None and filter_status['rs'] < self.min_relative_strength:
                filters_passed = False
                self.filtered_setups_count += 1
            
            if filter_status['volume'] is not None and not filter_status['volume']:
                filters_passed = False
                self.filtered_setups_count += 1
            
            if filter_status['position'] is not None:
                if filter_status['position'] < self.price_position_min or filter_status['position'] > self.price_position_max:
                    filters_passed = False
                    self.filtered_setups_count += 1
            
            # Weinstein Stage 2 filter (critical for PULLBACK - ensures stock in uptrend)
            if filter_status['weinstein_stage_2'] is not None and filter_status['weinstein_stage_2'] == False:
                filters_passed = False
                self.filtered_setups_count += 1
            
            if not filters_passed:
                return False, None, 0, {}
            
            details['distance_to_ema'] = dist_21
            return True, 'PULLBACK_TO_21_EMA', quality_score, details
        
        # SETUP 2: Price between 21 and 55 EMA - DISABLED (only 14.66% win rate)
        # This setup was performing very poorly, so we filter it out
        
        return False, None, 0, {}
    
    def check_entry_confirmation(self, df, setup_idx, setup_type):
        """
        CRITICAL FIX: Wait for next-day confirmation before entry
        
        This solves the 34.2% quick loss problem!
        
        Confirmation required:
        - Next day must trade above setup day's high (bullish continuation)
        - OR next day closes green with good body
        
        Returns: (confirmed, entry_price, entry_idx)
        """
        if setup_idx + 1 >= len(df):
            return False, None, None  # No next day data
        
        setup_day = df.iloc[setup_idx]
        next_day = df.iloc[setup_idx + 1]
        
        # Method 1: Price breaks above setup day's high (strongest confirmation)
        if next_day['high'] > setup_day['high']:
            # Enter at setup day high + 0.1% (simulates limit order just above)
            entry_price = setup_day['high'] * 1.001
            # But check if we would have been filled (did price reach it?)
            if next_day['high'] >= entry_price:
                return True, entry_price, setup_idx + 1
        
        # Method 2: Strong bullish candle next day
        next_body = next_day['close'] - next_day['open']
        next_range = next_day['high'] - next_day['low']
        
        is_green = next_body > 0
        strong_body = abs(next_body) / next_range > 0.6 if next_range > 0 else False
        
        if is_green and strong_body and next_day['close'] > setup_day['close']:
            # Enter at next day close (confirmed strength)
            entry_price = next_day['close']
            return True, entry_price, setup_idx + 1
        
        # No confirmation - skip this trade
        return False, None, None
    
    def simulate_trade(self, symbol, df, entry_idx, setup_type, quality_score, details):
        """
        Simulate a trade from entry to exit
        WITH next-day confirmation to avoid false breakouts
        
        Returns: trade_result dict
        """
        # CRITICAL: Wait for next-day confirmation
        confirmed, confirmed_entry_price, confirmed_entry_idx = self.check_entry_confirmation(
            df, entry_idx, setup_type
        )
        
        if not confirmed:
            return None  # No confirmation - skip trade
        
        # Use confirmed entry
        entry_date = df.iloc[confirmed_entry_idx]['date']
        entry_price = confirmed_entry_price
        
        # Calculate stop loss and target using 21 EMA as reference
        ema_21_entry = details['ema_21']
        
        # Stop loss: Below 21 EMA or fixed % (whichever is closer)
        sl_ema_based = ema_21_entry * (1 - self.stop_loss_pct)
        sl_fixed = entry_price * (1 - self.stop_loss_pct)
        stop_loss = max(sl_ema_based, sl_fixed)  # Use the closer stop
        
        # Target: Fixed R:R ratio
        target = entry_price * (1 + self.target_pct)
        
        # Position sizing based on risk
        risk_per_share = entry_price - stop_loss
        max_shares_by_risk = (self.current_capital * self.max_position_size) / risk_per_share
        max_shares_by_capital = (self.current_capital * self.max_position_size) / entry_price
        shares = min(max_shares_by_risk, max_shares_by_capital)
        shares = int(shares)  # Round down to whole shares
        
        if shares <= 0:
            return None
        
        position_value = shares * entry_price
        
        # Simulate holding the position
        max_exit_idx = min(entry_idx + self.max_holding_days, len(df) - 1)
        
        exit_reason = None
        exit_date = None
        exit_price = None
        
        for i in range(entry_idx + 1, max_exit_idx + 1):
            current = df.iloc[i]
            high = current['high']
            low = current['low']
            close = current['close']
            
            # Check stop loss first (conservative - hit during day)
            if low <= stop_loss:
                exit_price = stop_loss
                exit_date = current['date']
                exit_reason = 'STOP_LOSS'
                break
            
            # Check target
            if high >= target:
                exit_price = target
                exit_date = current['date']
                exit_reason = 'TARGET'
                break
            
            # Check max holding period
            if i == max_exit_idx:
                exit_price = close
                exit_date = current['date']
                exit_reason = 'MAX_HOLDING'
                break
        
        # If no exit triggered, exit at last available price
        if exit_price is None:
            exit_price = df.iloc[max_exit_idx]['close']
            exit_date = df.iloc[max_exit_idx]['date']
            exit_reason = 'MAX_HOLDING'
        
        # Calculate P&L
        gross_pnl = (exit_price - entry_price) * shares
        
        # Transaction costs (approximate)
        # Zerodha: 0.03% or ₹20 per order (whichever is lower) + STT + taxes
        brokerage = min(position_value * 0.0003, 20) * 2  # Buy + Sell
        stt = position_value * 0.001  # 0.1% on sell side
        transaction_cost = brokerage + stt + (position_value * 0.0005)  # Other charges
        
        net_pnl = gross_pnl - transaction_cost
        pnl_pct = (net_pnl / position_value) * 100
        
        # Update capital
        self.current_capital += net_pnl
        
        # Calculate holding days
        holding_days = (exit_date - entry_date).days
        
        trade_result = {
            'Symbol': symbol,
            'Setup_Type': setup_type,
            'Quality_Score': quality_score,
            'Entry_Date': entry_date,
            'Entry_Price': round(entry_price, 2),
            'Exit_Date': exit_date,
            'Exit_Price': round(exit_price, 2),
            'Exit_Reason': exit_reason,
            'Shares': shares,
            'Position_Value': round(position_value, 2),
            'Stop_Loss': round(stop_loss, 2),
            'Target': round(target, 2),
            'Gross_PnL': round(gross_pnl, 2),
            'Transaction_Cost': round(transaction_cost, 2),
            'Net_PnL': round(net_pnl, 2),
            'PnL_Pct': round(pnl_pct, 2),
            'Holding_Days': holding_days,
            'Capital_After': round(self.current_capital, 2),
            'EMA_21': round(details['ema_21'], 2),
            'EMA_55': round(details['ema_55'], 2),
            'EMA_Spread': round(details['ema_spread'], 2),
            'Consolidating': details['consolidating'],
            'Volume_Drying': details['volume_drying']
        }
        
        return trade_result
    
    def backtest_symbol(self, symbol, start_date, end_date, nifty_df=None, nifty50_df=None):
        """
        Backtest a single symbol over the specified period
        WITH market breadth check at each historical point
        
        Returns: list of trades
        """
        logger.info(f"Backtesting {symbol}...")
        
        # Fetch data with extra buffer for indicator calculation
        buffer_start = start_date - timedelta(days=100)
        df = self.get_historical_data(symbol, buffer_start, end_date)
        
        if df is None or len(df) < 60:
            logger.warning(f"Insufficient data for {symbol}")
            return []
        
        # Calculate indicators
        df = self.calculate_indicators(df)
        
        # Find the actual start index (after buffer period)
        start_idx = df[df['date'] >= start_date].index[0] if len(df[df['date'] >= start_date]) > 0 else 60
        
        symbol_trades = []
        
        # Walk forward through time
        i = start_idx
        while i < len(df):
            # Check if we're already in a trade
            if symbol_trades and symbol_trades[-1]['Exit_Date'] is None:
                # Still in trade, skip
                i += 1
                continue
            
            # Check for setup (pass NIFTY 50 data for breadth check at THIS point in time)
            setup_found, setup_type, quality_score, details = self.identify_setup(df, i, nifty_df, nifty50_df)
            
            if setup_found and quality_score >= self.min_quality_score:
                # Enter trade
                trade_result = self.simulate_trade(symbol, df, i, setup_type, quality_score, details)
                
                if trade_result:
                    symbol_trades.append(trade_result)
                    logger.info(f"  Trade: {setup_type} | Entry: {trade_result['Entry_Date'].date()} @ {trade_result['Entry_Price']} | Exit: {trade_result['Exit_Reason']} | P&L: {trade_result['Net_PnL']} ({trade_result['PnL_Pct']}%)")
                    
                    # Jump to exit date to avoid overlapping trades
                    exit_idx = df[df['date'] == trade_result['Exit_Date']].index[0]
                    i = exit_idx + 1
                    continue
            
            i += 1
        
        return symbol_trades
    
    def run_backtest(self, input_csv, start_date, end_date, output_dir='backtest_results'):
        """
        Run backtest on all symbols from input CSV
        """
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        logger.info(f"="*70)
        logger.info(f"STARTING BACKTEST - SIMPLE REFINED STRATEGY")
        logger.info(f"="*70)
        logger.info(f"Period: {start_date.date()} to {end_date.date()}")
        logger.info(f"Initial Capital: ₹{self.initial_capital:,.2f}")
        logger.info(f"Max Position Size: {self.max_position_size*100}%")
        logger.info(f"Stop Loss: {self.stop_loss_pct*100}%")
        logger.info(f"Target: {self.target_pct*100}%")
        logger.info(f"Max Holding Days: {self.max_holding_days}")
        logger.info(f"Min Quality Score: {self.min_quality_score}")
        
        # Breadth filter removed - proven redundant
        
        if any([self.enable_relative_strength, self.enable_volume_confirmation, self.enable_price_position, self.enable_weinstein_stage_2]):
            logger.info(f"\nOther Filters:")
            logger.info(f"  Relative Strength: {'✓ ENABLED' if self.enable_relative_strength else '✗ Disabled'}")
            logger.info(f"  Volume Confirmation: {'✓ ENABLED' if self.enable_volume_confirmation else '✗ Disabled'}")
            logger.info(f"  Price Position: {'✓ ENABLED' if self.enable_price_position else '✗ Disabled'}")
            logger.info(f"  Weinstein Stage 2: {'✓ ENABLED' if self.enable_weinstein_stage_2 else '✗ Disabled'}")
        
        logger.info(f"="*70)
        
        # Read symbols
        try:
            input_df = pd.read_csv(input_csv)
            if 'Symbol' not in input_df.columns:
                logger.error("Input CSV must have 'Symbol' column")
                return
            
            symbols = input_df['Symbol'].dropna().unique().tolist()
            logger.info(f"Found {len(symbols)} symbols to backtest")
            
            # Load instruments
            if not self.load_instruments_cache():
                logger.error("Failed to load instruments cache")
                return
            
            # Reset performance tracking
            self.trades = []
            self.current_capital = self.initial_capital
            self.filtered_setups_count = 0
            self.breadth_filtered_count = 0
            
            # Fetch Nifty data for Phase 1 filters (if enabled)
            nifty_df = None
            if self.enable_relative_strength:
                logger.info("Fetching Nifty data for Relative Strength filter...")
                buffer_start = start_date - timedelta(days=100)
                nifty_df = self.get_nifty_data_for_backtest(buffer_start, end_date)
                if nifty_df is not None:
                    logger.info(f"Nifty data loaded: {len(nifty_df)} bars")
            
            # Fetch NIFTY 50 data for breadth filter (if enabled)
            nifty50_df = None
            if self.enable_market_breadth_filter:
                logger.info("Fetching NIFTY 50 data for Market Breadth filter...")
                buffer_start = start_date - timedelta(days=100)
                nifty50_df = self.get_nifty50_data_for_backtest(buffer_start, end_date)
                if nifty50_df is not None:
                    logger.info(f"NIFTY 50 data loaded: {len(nifty50_df)} bars")
                    logger.info("Breadth filter will check market health at each historical point")
            
            # Backtest each symbol
            for i, symbol in enumerate(symbols, 1):
                logger.info(f"\nProcessing {i}/{len(symbols)}: {symbol}")
                
                try:
                    symbol_trades = self.backtest_symbol(symbol, start_date, end_date, nifty_df, nifty50_df)
                    self.trades.extend(symbol_trades)
                    
                    if i % 10 == 0:
                        logger.info(f"\nProgress: {i}/{len(symbols)} symbols | Trades so far: {len(self.trades)} | Capital: ₹{self.current_capital:,.2f}")
                
                except Exception as e:
                    logger.error(f"Error backtesting {symbol}: {e}")
                    continue
            
            # Generate results
            self.generate_results(output_dir, start_date, end_date)
            
        except Exception as e:
            logger.error(f"Error during backtest: {e}")
            raise
    
    def generate_results(self, output_dir, start_date, end_date):
        """Generate comprehensive backtest results"""
        
        if len(self.trades) == 0:
            logger.warning("No trades executed during backtest period")
            return
        
        # Create trades DataFrame
        trades_df = pd.DataFrame(self.trades)
        
        # Save detailed trades
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        trades_file = f"{output_dir}/trades_detailed_{timestamp}.csv"
        trades_df.to_csv(trades_file, index=False)
        logger.info(f"\nDetailed trades saved to: {trades_file}")
        
        # Calculate performance metrics
        total_trades = len(trades_df)
        winning_trades = len(trades_df[trades_df['Net_PnL'] > 0])
        losing_trades = len(trades_df[trades_df['Net_PnL'] < 0])
        breakeven_trades = len(trades_df[trades_df['Net_PnL'] == 0])
        
        win_rate = (winning_trades / total_trades) * 100 if total_trades > 0 else 0
        
        total_pnl = trades_df['Net_PnL'].sum()
        avg_win = trades_df[trades_df['Net_PnL'] > 0]['Net_PnL'].mean() if winning_trades > 0 else 0
        avg_loss = trades_df[trades_df['Net_PnL'] < 0]['Net_PnL'].mean() if losing_trades > 0 else 0
        
        profit_factor = abs(trades_df[trades_df['Net_PnL'] > 0]['Net_PnL'].sum() / 
                           trades_df[trades_df['Net_PnL'] < 0]['Net_PnL'].sum()) if losing_trades > 0 else float('inf')
        
        avg_pnl_pct = trades_df['PnL_Pct'].mean()
        avg_holding = trades_df['Holding_Days'].mean()
        
        # Calculate max drawdown
        trades_df['Cumulative_PnL'] = trades_df['Net_PnL'].cumsum()
        trades_df['Cumulative_Peak'] = trades_df['Cumulative_PnL'].cummax()
        trades_df['Drawdown'] = trades_df['Cumulative_PnL'] - trades_df['Cumulative_Peak']
        max_drawdown = trades_df['Drawdown'].min()
        max_drawdown_pct = (max_drawdown / self.initial_capital) * 100
        
        # Return metrics
        total_return = ((self.current_capital - self.initial_capital) / self.initial_capital) * 100
        days_in_backtest = (end_date - start_date).days
        annualized_return = (total_return / days_in_backtest) * 365 if days_in_backtest > 0 else 0
        
        # Per setup type analysis
        setup_analysis = trades_df.groupby('Setup_Type').agg({
            'Net_PnL': ['count', 'sum', 'mean'],
            'PnL_Pct': 'mean',
            'Holding_Days': 'mean'
        }).round(2)
        
        setup_win_rates = trades_df.groupby('Setup_Type').apply(
            lambda x: (len(x[x['Net_PnL'] > 0]) / len(x)) * 100
        ).round(2)
        
        # Exit reason analysis
        exit_analysis = trades_df.groupby('Exit_Reason').agg({
            'Net_PnL': ['count', 'sum', 'mean'],
            'PnL_Pct': 'mean'
        }).round(2)
        
        # Generate summary report
        summary = {
            'Backtest_Period': f"{start_date.date()} to {end_date.date()}",
            'Days_In_Backtest': days_in_backtest,
            'Initial_Capital': self.initial_capital,
            'Final_Capital': round(self.current_capital, 2),
            'Total_Return': round(total_return, 2),
            'Total_Return_Amount': round(total_pnl, 2),
            'Annualized_Return': round(annualized_return, 2),
            'Total_Trades': total_trades,
            'Winning_Trades': winning_trades,
            'Losing_Trades': losing_trades,
            'Breakeven_Trades': breakeven_trades,
            'Win_Rate': round(win_rate, 2),
            'Profit_Factor': round(profit_factor, 2),
            'Average_Win': round(avg_win, 2),
            'Average_Loss': round(avg_loss, 2),
            'Average_PnL_Pct': round(avg_pnl_pct, 2),
            'Average_Holding_Days': round(avg_holding, 2),
            'Max_Drawdown': round(max_drawdown, 2),
            'Max_Drawdown_Pct': round(max_drawdown_pct, 2),
            'Best_Trade': round(trades_df['Net_PnL'].max(), 2),
            'Worst_Trade': round(trades_df['Net_PnL'].min(), 2),
        }
        
        # Save summary
        summary_file = f"{output_dir}/summary_{timestamp}.json"
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=4)
        
        # Print comprehensive results
        print(f"\n{'='*70}")
        print(f"BACKTEST RESULTS - {'PHASE 1 ENHANCED' if any([self.enable_relative_strength, self.enable_volume_confirmation, self.enable_price_position]) else 'REFINED VERSION'}")
        print(f"{'='*70}")
        print(f"\n--- OVERVIEW ---")
        print(f"Period: {start_date.date()} to {end_date.date()} ({days_in_backtest} days)")
        print(f"Initial Capital: ₹{self.initial_capital:,.2f}")
        print(f"Final Capital: ₹{self.current_capital:,.2f}")
        print(f"Total Return: ₹{total_pnl:,.2f} ({total_return:.2f}%)")
        print(f"Annualized Return: {annualized_return:.2f}%")
        
        if self.filtered_setups_count > 0:
            print(f"\n--- FILTER IMPACT ---")
            print(f"Total setups filtered: {self.filtered_setups_count}")
            print(f"Setups traded: {total_trades}")
            print(f"Filter pass rate: {total_trades/(total_trades + self.filtered_setups_count)*100:.1f}%")
        
        print(f"\n--- TRADE STATISTICS ---")
        print(f"Total Trades: {total_trades}")
        print(f"Winning Trades: {winning_trades} ({win_rate:.2f}%)")
        print(f"Losing Trades: {losing_trades}")
        print(f"Breakeven Trades: {breakeven_trades}")
        
        print(f"\n--- PERFORMANCE METRICS ---")
        print(f"Profit Factor: {profit_factor:.2f}")
        print(f"Average Win: ₹{avg_win:,.2f}")
        print(f"Average Loss: ₹{avg_loss:,.2f}")
        print(f"Average P&L %: {avg_pnl_pct:.2f}%")
        print(f"Average Holding: {avg_holding:.1f} days")
        print(f"Best Trade: ₹{trades_df['Net_PnL'].max():,.2f}")
        print(f"Worst Trade: ₹{trades_df['Net_PnL'].min():,.2f}")
        
        print(f"\n--- RISK METRICS ---")
        print(f"Max Drawdown: ₹{max_drawdown:,.2f} ({max_drawdown_pct:.2f}%)")
        
        print(f"\n--- SETUP TYPE ANALYSIS ---")
        print(setup_analysis)
        print(f"\nWin Rates by Setup Type:")
        print(setup_win_rates)
        
        print(f"\n--- EXIT REASON ANALYSIS ---")
        print(exit_analysis)
        
        print(f"\n{'='*70}")
        print(f"Results saved to:")
        print(f"  - Trades: {trades_file}")
        print(f"  - Summary: {summary_file}")
        print(f"{'='*70}\n")


# Example usage
if __name__ == "__main__":
    print("\n" + "="*80)
    print("⭐ SIMPLE REFINED STRATEGY - FINAL CONFIGURATION")
    print("="*80)
    print("Strategy: EMA Pullback (BOUNCED + PULLBACK)")
    print("")
    print("Configuration:")
    print("  • Setups: BOUNCED_FROM_EMA + PULLBACK_TO_21_EMA")
    print("  • Position Size: 5% per trade")
    print("  • Stop Loss: 4%")
    print("  • Target: 8% (2:1 Risk:Reward)")
    print("  • Max Holding: 20 days")
    print("  • Filters: NONE (all proven redundant or harmful)")
    print("")
    print("Proven Performance:")
    print("  • Win Rate: 41%")
    print("  • Return: 1,340% (2 years)")
    print("  • CAGR: ~230%")
    print("  • Drawdown: ~38%")
    print("")
    print("Philosophy:")
    print("  Simple > Complex. Trust the setup. Manage with R:R.")
    print("="*80 + "\n")
    
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "RcFSX2nfdWmuiF02bjuO1gUdSEMnVF8z"
    
    INPUT_CSV = "data\\sector_marketcap_great8000.csv"
    
    # Backtest period (last 2 years)
    END_DATE = datetime.now()
    START_DATE = END_DATE - timedelta(days=730)  # 2 years
    
    # Create backtester
    backtester = EMAPullbackBacktester(API_KEY, ACCESS_TOKEN)
    
    # FINAL PRODUCTION CONFIGURATION
    # Simple Refined + NIFTY 50 Breadth Filter
    backtester.initial_capital = 1000000  # 10 lakhs
    backtester.max_position_size = 0.05  # 5% per trade (proven optimal)
    backtester.stop_loss_pct = 0.04  # 4% stop loss
    backtester.target_pct = 0.08  # 8% target (Moderate 2:1 R:R - won all 6 regimes!)
    backtester.max_holding_days = 20  # Max 20 days per trade
    backtester.min_quality_score = 1  # ⭐ BOUNCED (quality=2) + good PULLBACK (quality≥1)
    
    # NIFTY 50 MARKET BREADTH FILTER (Has full historical data)
    backtester.enable_market_breadth_filter = False  # DISABLED - proven redundant
    # Testing showed breadth filter had NO impact (9,071 → 9,098 trades)
    # Reason: EMA pullback setups naturally occur during healthy market conditions
    # When breadth is weak, technical patterns don't form anyway
    
    # DISABLE ALL FILTERS (they all over-filtered or were redundant)
    backtester.enable_relative_strength = False  # Disabled (over-filtered good setups)
    backtester.enable_volume_confirmation = False  # Disabled (over-filtered good setups)
    backtester.enable_price_position = False  # Disabled (over-filtered good setups)
    backtester.enable_weinstein_stage_2 = False  # Disabled (too strict)
    
    # PHILOSOPHY:
    # - Simple Refined Strategy (BOUNCED + PULLBACK)
    # - No complex filters (they all reduced performance)
    # - EMA setups naturally occur during healthy conditions
    # - Trust the setup, manage with proper R:R (4% SL / 8% Target)
    # Simple. Clean. Proven: 41% WR, 1,340% return, 2:1 R:R
    
    # Run backtest
    print(f"Running backtest with Phase 1 filters: {'ENABLED ✓' if any([backtester.enable_relative_strength, backtester.enable_volume_confirmation, backtester.enable_price_position]) else 'DISABLED'}\n")
    backtester.run_backtest(INPUT_CSV, START_DATE, END_DATE)

