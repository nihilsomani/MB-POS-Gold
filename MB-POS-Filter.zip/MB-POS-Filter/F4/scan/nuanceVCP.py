import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import time
import logging
from datetime import datetime, timedelta
import json
import os
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class VCPScanner:
    def __init__(self, api_key: str, access_token: str):
        """
        Initialize VCP Scanner with Kite Connect API
        
        Args:
            api_key: Kite Connect API key
            access_token: Kite Connect access token
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.instruments_cache = {}
        self.rate_limit_delay = 0.25  # 250ms delay between API calls
        self.last_api_call = 0
        
    def _rate_limit_sleep(self):
        """Ensure rate limit compliance"""
        current_time = time.time()
        time_since_last_call = current_time - self.last_api_call
        if time_since_last_call < self.rate_limit_delay:
            time.sleep(self.rate_limit_delay - time_since_last_call)
        self.last_api_call = time.time()
    
    def load_instruments_cache(self) -> Dict:
        """Load and cache NSE instruments to avoid repeated API calls"""
        # Try multiple possible cache file locations
        possible_cache_files = [
            'nse_instruments_cache.json',
            '../nse_instruments_cache.json',
            '../../nse_instruments_cache.json',
            'cache/instrument_cache.json',
            '../cache/instrument_cache.json',
            'instruments_cache.json',
            '../instruments_cache.json'
        ]
        
        cache_file = None
        for file_path in possible_cache_files:
            if os.path.exists(file_path):
                cache_file = file_path
                break
        
        if cache_file:
            # Check if cache is recent (less than 1 day old)
            cache_age = time.time() - os.path.getmtime(cache_file)
            if cache_age < 24 * 60 * 60:  # 24 hours
                logger.info(f"Loading instruments from cache: {cache_file}")
                try:
                    with open(cache_file, 'r') as f:
                        cache_data = json.load(f)
                    
                    # Handle different cache formats
                    if isinstance(cache_data, dict):
                        if 'instruments' in cache_data:
                            # Format: {"timestamp": "...", "instruments": {...}}
                            self.instruments_cache = cache_data['instruments']
                        else:
                            # Format: {"SYMBOL": {"instrument_token": ...}}
                            self.instruments_cache = cache_data
                    else:
                        logger.error(f"Unexpected cache format in {cache_file}")
                        self.instruments_cache = {}
                    
                    logger.info(f"Loaded {len(self.instruments_cache)} instruments from cache")
                    return self.instruments_cache
                    
                except Exception as e:
                    logger.error(f"Error loading cache from {cache_file}: {e}")
        
        logger.info("Fetching fresh instruments data from API")
        try:
            self._rate_limit_sleep()
            instruments = self.kite.instruments("NSE")
            
            # Create cache dictionary
            cache_dict = {}
            for instrument in instruments:
                cache_dict[instrument['tradingsymbol']] = {
                    'instrument_token': instrument['instrument_token'],
                    'exchange': instrument['exchange'],
                    'tradingsymbol': instrument['tradingsymbol'],
                    'name': instrument['name'],
                    'lot_size': instrument['lot_size'],
                    'tick_size': instrument['tick_size']
                }
            
            # Save to cache
            cache_file = 'nse_instruments_cache.json'
            with open(cache_file, 'w') as f:
                json.dump(cache_dict, f, indent=2)
            
            self.instruments_cache = cache_dict
            logger.info(f"Cached {len(cache_dict)} instruments")
            
        except Exception as e:
            logger.error(f"Error loading instruments: {e}")
            self.instruments_cache = {}
        
        return self.instruments_cache
    
    def get_historical_data(self, symbol: str, days: int = 100) -> Optional[pd.DataFrame]:
        """
        Fetch historical data for a symbol
        
        Args:
            symbol: Trading symbol
            days: Number of days of historical data
            
        Returns:
            DataFrame with OHLCV data or None if error
        """
        try:
            if symbol not in self.instruments_cache:
                logger.warning(f"Symbol {symbol} not found in instruments cache")
                return None
            
            instrument_token = self.instruments_cache[symbol]['instrument_token']
            
            # Calculate date range
            to_date = datetime.now()
            from_date = to_date - timedelta(days=days)
            
            self._rate_limit_sleep()
            
            # Fetch historical data
            historical_data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if not historical_data:
                return None
            
            # Convert to DataFrame
            df = pd.DataFrame(historical_data)
            df['date'] = pd.to_datetime(df['date'])
            df = df.set_index('date').sort_index()
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def calculate_moving_averages(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate various moving averages"""
        df['sma_10'] = df['close'].rolling(window=10).mean()
        df['sma_21'] = df['close'].rolling(window=21).mean()
        df['sma_50'] = df['close'].rolling(window=50).mean()
        df['sma_200'] = df['close'].rolling(window=200).mean()
        df['ema_10'] = df['close'].ewm(span=10).mean()
        df['ema_21'] = df['close'].ewm(span=21).mean()
        return df
    
    def calculate_volatility_metrics(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate volatility and range metrics"""
        df['true_range'] = np.maximum(
            df['high'] - df['low'],
            np.maximum(
                abs(df['high'] - df['close'].shift(1)),
                abs(df['low'] - df['close'].shift(1))
            )
        )
        df['atr_14'] = df['true_range'].rolling(window=14).mean()
        df['daily_range'] = ((df['high'] - df['low']) / df['close']) * 100
        df['volatility_20'] = df['close'].pct_change().rolling(window=20).std() * np.sqrt(252) * 100
        return df
    
    def identify_swing_highs_lows(self, df: pd.DataFrame, window: int = 5) -> pd.DataFrame:
        """Identify swing highs and lows"""
        df['swing_high'] = df['high'].rolling(window=window*2+1, center=True).max() == df['high']
        df['swing_low'] = df['low'].rolling(window=window*2+1, center=True).min() == df['low']
        return df
    
    def detect_base_formation(self, df: pd.DataFrame, lookback: int = 50) -> Dict:
        """
        Detect base formation characteristics
        
        Returns:
            Dictionary with base analysis results
        """
        if len(df) < lookback:
            return {'base_detected': False, 'reason': 'Insufficient data'}
        
        recent_data = df.tail(lookback).copy()
        
        # Find significant high (base left side)
        base_high = recent_data['high'].max()
        base_high_idx = recent_data['high'].idxmax()
        
        # Data after the high
        after_high = recent_data[recent_data.index > base_high_idx]
        
        if len(after_high) < 10:
            return {'base_detected': False, 'reason': 'Not enough data after high'}
        
        # Calculate base metrics
        base_depth = ((base_high - after_high['low'].min()) / base_high) * 100
        base_width = len(after_high)
        current_price = df['close'].iloc[-1]
        
        # Base requirements
        min_base_depth = 8.0  # Minimum 8% correction
        max_base_depth = 50.0  # Maximum 50% correction
        min_base_width = 7  # Minimum 7 days
        
        base_valid = (min_base_depth <= base_depth <= max_base_depth and 
                     base_width >= min_base_width)
        
        return {
            'base_detected': base_valid,
            'base_high': base_high,
            'base_low': after_high['low'].min(),
            'base_depth': base_depth,
            'base_width': base_width,
            'current_price': current_price,
            'distance_from_high': ((base_high - current_price) / base_high) * 100
        }
    
    def analyze_vcp_characteristics(self, df: pd.DataFrame) -> Dict:
        """
        Analyze VCP (Volatility Contraction Pattern) characteristics
        
        Returns:
            Dictionary with VCP analysis results
        """
        if len(df) < 50:
            return {'vcp_detected': False, 'reason': 'Insufficient data'}
        
        # Get base formation data
        base_info = self.detect_base_formation(df)
        if not base_info['base_detected']:
            return {'vcp_detected': False, 'reason': 'No valid base formation'}
        
        recent_data = df.tail(30).copy()  # Focus on recent 30 days
        
        # Calculate contraction metrics
        volatility_windows = [5, 10, 15, 20]
        volatility_metrics = {}
        
        for window in volatility_windows:
            if len(recent_data) >= window:
                vol_data = recent_data.tail(window)
                volatility_metrics[f'avg_range_{window}d'] = vol_data['daily_range'].mean()
                volatility_metrics[f'max_range_{window}d'] = vol_data['daily_range'].max()
                volatility_metrics[f'volume_trend_{window}d'] = vol_data['volume'].pct_change().mean()
        
        # VCP Pattern Analysis
        last_5_days = recent_data.tail(5)
        last_10_days = recent_data.tail(10)
        last_15_days = recent_data.tail(15)
        
        # Volume contraction
        avg_volume_recent = last_5_days['volume'].mean()
        avg_volume_base = df.tail(50)['volume'].mean()
        volume_contraction = (avg_volume_recent / avg_volume_base) * 100
        
        # Price tightness
        recent_range = last_5_days['daily_range'].mean()
        base_range = df.tail(50)['daily_range'].mean()
        range_contraction = (recent_range / base_range) * 100
        
        # Volatility contraction analysis
        vol_5d = last_5_days['daily_range'].mean()
        vol_10d = last_10_days['daily_range'].mean()
        vol_15d = last_15_days['daily_range'].mean()
        
        # VCP Criteria
        vcp_criteria = {
            'volume_drying_up': volume_contraction <= 70,  # Volume 30% below average
            'range_contracting': range_contraction <= 60,  # Range 40% below average
            'progressive_contraction': vol_5d <= vol_10d <= vol_15d,
            'tight_recent_action': recent_range <= 3.0,  # Recent range under 3%
            'low_volume_bars': (last_5_days['volume'] < avg_volume_base * 0.8).sum() >= 3
        }
        
        vcp_score = sum(vcp_criteria.values()) / len(vcp_criteria) * 100
        
        # Final VCP detection
        vcp_detected = vcp_score >= 60  # At least 60% criteria met
        
        return {
            'vcp_detected': vcp_detected,
            'vcp_score': vcp_score,
            'volume_contraction': volume_contraction,
            'range_contraction': range_contraction,
            'recent_avg_range': recent_range,
            'base_avg_range': base_range,
            'progressive_contraction': vcp_criteria['progressive_contraction'],
            'tight_action': vcp_criteria['tight_recent_action'],
            'volume_drying_up': vcp_criteria['volume_drying_up'],
            **volatility_metrics
        }
    
    def analyze_breakout_potential(self, df: pd.DataFrame) -> Dict:
        """Analyze breakout potential and entry setup"""
        if len(df) < 20:
            return {'breakout_setup': False}
        
        recent_data = df.tail(20)
        current_price = df['close'].iloc[-1]
        
        # Resistance levels
        resistance_level = recent_data['high'].max()
        resistance_test_count = (recent_data['high'] >= resistance_level * 0.98).sum()
        
        # Support levels
        support_level = recent_data['low'].min()
        
        # Current position analysis
        distance_to_resistance = ((resistance_level - current_price) / current_price) * 100
        distance_to_support = ((current_price - support_level) / current_price) * 100
        
        # Volume analysis for breakout
        last_3_days = recent_data.tail(3)
        volume_buildup = last_3_days['volume'].mean() > recent_data['volume'].mean()
        
        # Breakout setup criteria
        breakout_setup = (
            distance_to_resistance <= 3.0 and  # Within 3% of resistance
            distance_to_support >= 2.0 and     # At least 2% above support
            current_price > df['ema_21'].iloc[-1]  # Above 21 EMA
        )
        
        return {
            'breakout_setup': breakout_setup,
            'resistance_level': resistance_level,
            'support_level': support_level,
            'distance_to_resistance': distance_to_resistance,
            'distance_to_support': distance_to_support,
            'resistance_tests': resistance_test_count,
            'volume_buildup': volume_buildup,
            'current_vs_ema21': ((current_price - df['ema_21'].iloc[-1]) / df['ema_21'].iloc[-1]) * 100
        }
    
    def comprehensive_analysis(self, symbol: str) -> Dict:
        """
        Perform comprehensive VCP analysis for a symbol
        
        Returns:
            Dictionary with all analysis results
        """
        logger.info(f"Analyzing {symbol}")
        
        # Initialize result dictionary
        result = {
            'symbol': symbol,
            'timestamp': datetime.now().isoformat(),
            'data_available': False,
            'analysis_completed': False
        }
        
        try:
            # Fetch historical data
            df = self.get_historical_data(symbol, days=100)
            
            if df is None or len(df) < 50:
                result['error'] = 'Insufficient historical data'
                return result
            
            result['data_available'] = True
            result['data_points'] = len(df)
            
            # Calculate technical indicators
            df = self.calculate_moving_averages(df)
            df = self.calculate_volatility_metrics(df)
            df = self.identify_swing_highs_lows(df)
            
            # Current price metrics
            current_price = df['close'].iloc[-1]
            result['current_price'] = current_price
            result['volume'] = df['volume'].iloc[-1]
            result['daily_range'] = df['daily_range'].iloc[-1]
            
            # Moving average analysis
            result['sma_10'] = df['sma_10'].iloc[-1]
            result['sma_21'] = df['sma_21'].iloc[-1]
            result['sma_50'] = df['sma_50'].iloc[-1]
            result['sma_200'] = df['sma_200'].iloc[-1]
            
            # Price vs MA analysis
            result['price_vs_sma10'] = ((current_price - df['sma_10'].iloc[-1]) / df['sma_10'].iloc[-1]) * 100
            result['price_vs_sma21'] = ((current_price - df['sma_21'].iloc[-1]) / df['sma_21'].iloc[-1]) * 100
            result['price_vs_sma50'] = ((current_price - df['sma_50'].iloc[-1]) / df['sma_50'].iloc[-1]) * 100
            
            # Trend analysis
            result['ma_trend'] = (df['sma_10'].iloc[-1] > df['sma_21'].iloc[-1] > df['sma_50'].iloc[-1])
            result['above_sma200'] = current_price > df['sma_200'].iloc[-1]
            
            # Base formation analysis
            base_analysis = self.detect_base_formation(df)
            result.update({f'base_{k}': v for k, v in base_analysis.items()})
            
            # VCP analysis
            vcp_analysis = self.analyze_vcp_characteristics(df)
            result.update({f'vcp_{k}': v for k, v in vcp_analysis.items()})
            
            # Breakout potential
            breakout_analysis = self.analyze_breakout_potential(df)
            result.update({f'breakout_{k}': v for k, v in breakout_analysis.items()})
            
            # Volume analysis
            avg_volume_20d = df['volume'].tail(20).mean()
            result['avg_volume_20d'] = avg_volume_20d
            result['volume_vs_avg'] = (df['volume'].iloc[-1] / avg_volume_20d) * 100
            
            # Volatility analysis
            result['atr_14'] = df['atr_14'].iloc[-1]
            result['volatility_20d'] = df['volatility_20'].iloc[-1]
            
            # Final scoring
            result['overall_score'] = self.calculate_overall_score(result)
            result['analysis_completed'] = True
            
        except Exception as e:
            logger.error(f"Error analyzing {symbol}: {e}")
            result['error'] = str(e)
        
        return result
    
    def calculate_overall_score(self, analysis: Dict) -> float:
        """Calculate overall VCP score based on various factors"""
        score = 0
        max_score = 100
        
        # Base formation (30 points)
        if analysis.get('base_base_detected', False):
            score += 30
            # Bonus for optimal base depth
            base_depth = analysis.get('base_base_depth', 0)
            if 10 <= base_depth <= 25:
                score += 5
        
        # VCP characteristics (40 points)
        if analysis.get('vcp_vcp_detected', False):
            score += 20
            vcp_score = analysis.get('vcp_vcp_score', 0)
            score += (vcp_score / 100) * 20
        
        # Breakout setup (20 points)
        if analysis.get('breakout_breakout_setup', False):
            score += 20
        
        # Technical strength (10 points)
        if analysis.get('ma_trend', False):
            score += 5
        if analysis.get('above_sma200', False):
            score += 5
        
        return min(score, max_score)
    
    def scan_universe(self, universe_file: str, output_file: str = None) -> pd.DataFrame:
        """
        Scan entire universe of stocks
        
        Args:
            universe_file: Path to CSV file with 'Symbol' column
            output_file: Optional output file path
            
        Returns:
            DataFrame with analysis results
        """
        logger.info(f"Starting universe scan from {universe_file}")
        
        # Load universe
        try:
            universe_df = pd.read_csv(universe_file)
            if 'Symbol' not in universe_df.columns:
                raise ValueError("Universe file must contain 'Symbol' column")
            
            symbols = universe_df['Symbol'].unique().tolist()
            logger.info(f"Found {len(symbols)} symbols to analyze")
            
        except Exception as e:
            logger.error(f"Error loading universe file: {e}")
            return pd.DataFrame()
        
        # Load instruments cache
        self.load_instruments_cache()
        
        # Analyze each symbol
        results = []
        total_symbols = len(symbols)
        
        for i, symbol in enumerate(symbols, 1):
            logger.info(f"Processing {symbol} ({i}/{total_symbols})")
            
            try:
                analysis = self.comprehensive_analysis(symbol)
                results.append(analysis)
                
                # Progress update every 10 symbols
                if i % 10 == 0:
                    logger.info(f"Completed {i}/{total_symbols} symbols")
                
            except Exception as e:
                logger.error(f"Error processing {symbol}: {e}")
                results.append({
                    'symbol': symbol,
                    'error': str(e),
                    'analysis_completed': False
                })
        
        # Create results DataFrame
        results_df = pd.DataFrame(results)
        
        # Sort by overall score (descending)
        if 'overall_score' in results_df.columns:
            results_df = results_df.sort_values('overall_score', ascending=False)
        
        # Save results
        if output_file is None:
            output_file = f"vcp_scan_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        results_df.to_csv(output_file, index=False)
        logger.info(f"Results saved to {output_file}")
        
        # Print summary
        total_analyzed = results_df['analysis_completed'].sum()
        vcp_detected = results_df['vcp_vcp_detected'].sum() if 'vcp_vcp_detected' in results_df.columns else 0
        base_detected = results_df['base_base_detected'].sum() if 'base_base_detected' in results_df.columns else 0
        
        logger.info(f"Scan completed: {total_analyzed} symbols analyzed")
        logger.info(f"VCP patterns detected: {vcp_detected}")
        logger.info(f"Base formations detected: {base_detected}")
        
        return results_df

# Example usage
if __name__ == "__main__":
    # Configuration - Replace with your actual credentials
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "xrnc6Z9Q7nLPcLiGZI10P4nxmjMqhl4B"
    
    # Initialize scanner
    scanner = VCPScanner(API_KEY, ACCESS_TOKEN)
    
    # Run scan
    results = scanner.scan_universe("data/MCAP-great2500.csv", "vcp_scan_results_4oct25_RSFiltered_TrendVolume_1.csv")
    
    # Display top results
    if not results.empty:
        print("\n=== TOP VCP CANDIDATES ===")
        top_results = results.head(10)
        
        # Define display columns and filter out missing ones
        desired_columns = ['symbol', 'overall_score', 'vcp_vcp_detected', 'base_base_detected', 
                          'current_price', 'vcp_vcp_score', 'base_base_depth']
        display_columns = [col for col in desired_columns if col in top_results.columns]
        
        if display_columns:
            print(top_results[display_columns].to_string(index=False))
        else:
            print("No analysis columns available for display")
            print("Available columns:", list(top_results.columns))
    else:
        print("No results to display - all symbols failed analysis")