"""
Deep Analysis of Trade Failures
Identify why 60% of trades are losing
"""

import pandas as pd
import numpy as np

# Read latest backtest results
df = pd.read_csv('backtest_results/trades_detailed_20251023_222909.csv')

print("="*80)
print("🔍 DEEP FAILURE ANALYSIS")
print("="*80)

# Overall stats
total_trades = len(df)
winners = df[df['Net_PnL'] > 0]
losers = df[df['Net_PnL'] < 0]

print(f"\nTotal Trades: {total_trades}")
print(f"Winners: {len(winners)} ({len(winners)/total_trades*100:.1f}%)")
print(f"Losers: {len(losers)} ({len(losers)/total_trades*100:.1f}%)")

# Loss analysis
print("\n" + "="*80)
print("❌ LOSS BREAKDOWN")
print("="*80)

print("\n1. Exit Reasons for Losses:")
print(losers.groupby('Exit_Reason')['Net_PnL'].agg(['count', 'mean', 'sum']))

print("\n2. Setup Type Loss Analysis:")
print(losers.groupby('Setup_Type')['Net_PnL'].agg(['count', 'mean', 'sum']))

print("\n3. Holding Period for Losses:")
print(f"Average: {losers['Holding_Days'].mean():.1f} days")
print(f"Median: {losers['Holding_Days'].median():.1f} days")
print(f"\nDistribution:")
print(f"  1-2 days: {len(losers[losers['Holding_Days'] <= 2])} ({len(losers[losers['Holding_Days'] <= 2])/len(losers)*100:.1f}%)")
print(f"  3-5 days: {len(losers[(losers['Holding_Days'] > 2) & (losers['Holding_Days'] <= 5)])} ({len(losers[(losers['Holding_Days'] > 2) & (losers['Holding_Days'] <= 5)])/len(losers)*100:.1f}%)")
print(f"  6-10 days: {len(losers[(losers['Holding_Days'] > 5) & (losers['Holding_Days'] <= 10)])} ({len(losers[(losers['Holding_Days'] > 5) & (losers['Holding_Days'] <= 10)])/len(losers)*100:.1f}%)")
print(f"  10+ days: {len(losers[losers['Holding_Days'] > 10])} ({len(losers[losers['Holding_Days'] > 10])/len(losers)*100:.1f}%)")

# Quick losses (hit SL fast)
quick_losses = losers[losers['Holding_Days'] <= 2]
print(f"\n4. Quick Losses (≤2 days): {len(quick_losses)}")
print(f"   These are likely FALSE BREAKOUTS or immediate reversals")
print(f"   Avg loss: ₹{quick_losses['Net_PnL'].mean():.2f}")

# Win analysis
print("\n" + "="*80)
print("✅ WIN BREAKDOWN (For Comparison)")
print("="*80)

print("\n1. Exit Reasons for Wins:")
print(winners.groupby('Exit_Reason')['Net_PnL'].agg(['count', 'mean', 'sum']))

print("\n2. Setup Type Win Analysis:")
print(winners.groupby('Setup_Type')['Net_PnL'].agg(['count', 'mean', 'sum']))

print("\n3. Holding Period for Winners:")
print(f"Average: {winners['Holding_Days'].mean():.1f} days")
print(f"Median: {winners['Holding_Days'].median():.1f} days")

# Key insights
print("\n" + "="*80)
print("💡 KEY INSIGHTS")
print("="*80)

# Insight 1: Entry timing
print("\n1. ENTRY TIMING ISSUE:")
same_day_sl = losers[losers['Holding_Days'] == 0]
next_day_sl = losers[losers['Holding_Days'] == 1]
print(f"   Same-day stop loss: {len(same_day_sl)} trades")
print(f"   Next-day stop loss: {len(next_day_sl)} trades")
print(f"   Combined: {len(same_day_sl) + len(next_day_sl)} trades ({(len(same_day_sl) + len(next_day_sl))/len(losers)*100:.1f}% of losses)")
print("   → Suggests entering too early without confirmation!")

# Insight 2: Win/Loss by setup
print("\n2. SETUP TYPE PERFORMANCE:")
for setup in df['Setup_Type'].unique():
    setup_df = df[df['Setup_Type'] == setup]
    wr = len(setup_df[setup_df['Net_PnL'] > 0]) / len(setup_df) * 100
    avg_win = setup_df[setup_df['Net_PnL'] > 0]['Net_PnL'].mean()
    avg_loss = setup_df[setup_df['Net_PnL'] < 0]['Net_PnL'].mean()
    print(f"   {setup}:")
    print(f"     Win Rate: {wr:.2f}%")
    print(f"     Avg Win: ₹{avg_win:.2f}")
    print(f"     Avg Loss: ₹{avg_loss:.2f}")
    print(f"     Win/Loss Ratio: {abs(avg_win/avg_loss):.2f}:1")

# Insight 3: Stop loss efficiency
stop_losses = df[df['Exit_Reason'] == 'STOP_LOSS']
print(f"\n3. STOP LOSS ANALYSIS:")
print(f"   Total SL hits: {len(stop_losses)} ({len(stop_losses)/total_trades*100:.1f}% of all trades)")
print(f"   Avg days to SL: {stop_losses['Holding_Days'].mean():.1f} days")
print(f"   SL hit within 3 days: {len(stop_losses[stop_losses['Holding_Days'] <= 3])} ({len(stop_losses[stop_losses['Holding_Days'] <= 3])/len(stop_losses)*100:.1f}%)")
print("   → Fast SL hits suggest entry timing issue or stop too tight")

print("\n" + "="*80)
print("🎯 ROOT CAUSE HYPOTHESES")
print("="*80)

print("\n1. ENTRY TIMING (Most Likely):")
print("   Problem: Entering at close when setup appears")
print("   Reality: Should wait for next-day confirmation")
print("   Fix: Require bullish candle or breakout above entry high")

print("\n2. STOP LOSS PLACEMENT (Likely):")
print("   Problem: Fixed 3% stop might be too tight")
print("   Reality: Needs to be below actual support (not just %)")
print("   Fix: Use ATR-based stops or support-based stops")

print("\n3. FALSE BREAKOUTS (Likely):")
print("   Problem: Bounces that immediately reverse")
print("   Reality: Need stronger momentum confirmation")
print("   Fix: Require 2-day confirmation or price above previous high")

print("\n4. QUALITY SCORING (Possible):")
print("   Problem: Current quality doesn't capture all factors")
print("   Reality: Missing key technical conditions")
print("   Fix: Add more quality criteria (candlestick patterns, RSI, etc.)")

print("\n" + "="*80)
print("📊 Analysis complete")
print("="*80)

