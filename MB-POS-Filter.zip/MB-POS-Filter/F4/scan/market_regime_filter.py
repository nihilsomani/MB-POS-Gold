"""
Market Regime Filter - Determine if market conditions are favorable for trading

Checks:
1. Nifty trend strength (above key EMAs)
2. Market breadth (% of stocks above EMAs)
3. Volatility (VIX level)
4. Recent market performance

Usage:
    filter = MarketRegimeFilter(kite)
    regime = filter.get_market_regime()
    if regime in ['STRONG_TRENDING', 'TRENDING']:
        # Trade aggressively
    elif regime == 'CONSOLIDATING':
        # Trade selectively or sit out
    else:
        # Don't trade
"""

import pandas as pd
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class MarketRegimeFilter:
    """
    Determines current market regime for trading decisions
    """
    
    def __init__(self, kite):
        """Initialize with KiteConnect instance"""
        self.kite = kite
        self.nifty_token = 256265  # NIFTY 50 instrument token
        self.nifty500_token = 14977026  # NIFTY 500 instrument token (broader market breadth)
        
    def get_nifty_data(self, days=250):
        """Fetch Nifty 50 historical data (250 days to ensure 200 EMA calculation)"""
        try:
            from_date = datetime.now() - timedelta(days=days)
            to_date = datetime.now()
            
            data = self.kite.historical_data(
                instrument_token=self.nifty_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                df = df.sort_values('date').reset_index(drop=True)
                
                # Calculate EMAs
                df['EMA_21'] = df['close'].ewm(span=21, adjust=False).mean()
                df['EMA_50'] = df['close'].ewm(span=50, adjust=False).mean()
                df['EMA_200'] = df['close'].ewm(span=200, adjust=False).mean()
                
                return df
            return None
        except Exception as e:
            logger.error(f"Error fetching Nifty data: {e}")
            return None
    
    def calculate_trend_strength(self, df):
        """
        Calculate trend strength score (0-100)
        Higher = stronger uptrend
        """
        if df is None or len(df) < 50:
            return 0
        
        latest = df.iloc[-1]
        current_price = latest['close']
        ema_21 = latest['EMA_21']
        ema_50 = latest['EMA_50']
        
        # Check if we have 200 EMA (optional)
        has_200_ema = 'EMA_200' in df.columns and len(df) >= 200
        ema_200 = latest['EMA_200'] if has_200_ema else None
        
        score = 0
        
        # Price above EMAs (40 points)
        if current_price > ema_21:
            score += 15
        if current_price > ema_50:
            score += 15
        if has_200_ema and current_price > ema_200:
            score += 10
        elif not has_200_ema:
            # If no 200 EMA, give partial points based on 50 EMA
            score += 10 if current_price > ema_50 else 0
        
        # EMA alignment (30 points)
        if ema_21 > ema_50:
            score += 15
        if has_200_ema and ema_50 > ema_200:
            score += 15
        elif not has_200_ema:
            # If no 200 EMA, give points if 21 > 50 (already bullish)
            score += 15 if ema_21 > ema_50 else 0
        
        # Recent momentum (20 points)
        if len(df) >= 20:
            recent_returns = (current_price - df.iloc[-20]['close']) / df.iloc[-20]['close']
            if recent_returns > 0.05:  # 5% gain in 20 days
                score += 20
            elif recent_returns > 0:
                score += 10
        
        # Price distance from 21 EMA (10 points)
        distance_from_21 = (current_price - ema_21) / ema_21
        if distance_from_21 > 0:  # Price above 21 EMA
            if distance_from_21 > 0.05:  # More than 5% above
                score += 10
            elif distance_from_21 > 0.02:  # 2-5% above
                score += 8
            else:  # 0-2% above
                score += 5
        elif distance_from_21 < -0.03:  # More than 3% below
            score -= 10
        
        return min(100, max(0, score))
    
    def get_nifty500_breadth(self):
        """
        Get NIFTY 500 index value and calculate market breadth proxy
        
        Uses index price vs EMA as breadth indicator:
        - NIFTY 500 > 50 EMA = Healthy breadth
        - NIFTY 500 < 50 EMA = Weak breadth
        
        Returns: (breadth_healthy, details)
        """
        try:
            from_date = datetime.now() - timedelta(days=100)
            to_date = datetime.now()
            
            data = self.kite.historical_data(
                instrument_token=self.nifty500_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if not data or len(data) < 50:
                return None, {}
            
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
            df = df.sort_values('date').reset_index(drop=True)
            
            # Calculate EMAs
            df['EMA_21'] = df['close'].ewm(span=21, adjust=False).mean()
            df['EMA_50'] = df['close'].ewm(span=50, adjust=False).mean()
            
            latest = df.iloc[-1]
            current_price = latest['close']
            ema_21 = latest['EMA_21']
            ema_50 = latest['EMA_50']
            
            # Breadth indicators
            above_21 = current_price > ema_21
            above_50 = current_price > ema_50
            ema_aligned = ema_21 > ema_50
            
            # Distance from EMAs (as breadth proxy)
            dist_from_50 = ((current_price - ema_50) / ema_50) * 100
            
            # Breadth score (0-100)
            breadth_score = 0
            if above_21:
                breadth_score += 30
            if above_50:
                breadth_score += 30
            if ema_aligned:
                breadth_score += 20
            if dist_from_50 > 5:  # >5% above 50 EMA
                breadth_score += 20
            elif dist_from_50 > 2:
                breadth_score += 10
            
            # Healthy if score >= 60
            breadth_healthy = breadth_score >= 60
            
            details = {
                'nifty500_price': round(current_price, 2),
                'ema_21': round(ema_21, 2),
                'ema_50': round(ema_50, 2),
                'above_21': above_21,
                'above_50': above_50,
                'ema_aligned': ema_aligned,
                'distance_from_50': round(dist_from_50, 2),
                'breadth_score': breadth_score,
                'breadth_healthy': breadth_healthy
            }
            
            return breadth_healthy, details
            
        except Exception as e:
            logger.warning(f"Could not fetch NIFTY 200 data: {e}")
            return None, {}
    
    def calculate_market_breadth(self, symbols_df):
        """
        Calculate what % of stocks are above their 21 EMA
        (Requires running scanner first to get this data)
        """
        # This is a placeholder - would need actual calculation
        # For now, return None to skip this check
        return None
    
    def get_vix_level(self):
        """
        Get India VIX level
        Returns: VIX value or None if unavailable
        """
        try:
            # India VIX token: 264969
            vix_token = 264969
            
            from_date = datetime.now() - timedelta(days=5)
            to_date = datetime.now()
            
            data = self.kite.historical_data(
                instrument_token=vix_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if data and len(data) > 0:
                return data[-1]['close']
            return None
        except Exception as e:
            logger.warning(f"Could not fetch VIX: {e}")
            return None
    
    def get_market_regime(self):
        """
        Determine current market regime
        
        Returns:
            regime: str - One of:
                'STRONG_TRENDING' - Very favorable for trading
                'TRENDING' - Good for trading
                'CONSOLIDATING' - Marginal, trade selectively
                'WEAK' - Avoid trading
                'UNKNOWN' - Cannot determine
            
            details: dict - Supporting information
        """
        
        # Get Nifty data (250 days for reliable 200 EMA)
        nifty_df = self.get_nifty_data()
        if nifty_df is None:
            return 'UNKNOWN', {'error': 'Could not fetch Nifty data'}
        
        # Calculate trend strength
        trend_score = self.calculate_trend_strength(nifty_df)
        
        # Get VIX
        vix = self.get_vix_level()
        
        # Get latest Nifty values
        latest = nifty_df.iloc[-1]
        current_price = latest['close']
        ema_21 = latest['EMA_21']
        ema_50 = latest['EMA_50']
        
        # Calculate recent return
        recent_return = (current_price - nifty_df.iloc[-20]['close']) / nifty_df.iloc[-20]['close'] * 100
        
        # Get NIFTY 500 breadth (CRITICAL - market health indicator)
        breadth_healthy, breadth_details = self.get_nifty500_breadth()
        
        details = {
            'nifty_price': round(current_price, 2),
            'ema_21': round(ema_21, 2),
            'ema_50': round(ema_50, 2),
            'trend_score': trend_score,
            'recent_return_20d': round(recent_return, 2),
            'vix': round(vix, 2) if vix else None,
            'price_above_21ema': current_price > ema_21,
            'price_above_50ema': current_price > ema_50,
            'ema_alignment': ema_21 > ema_50,
            'breadth_healthy': breadth_healthy,
            'breadth_score': breadth_details.get('breadth_score') if breadth_details else None,
            'nifty500_above_50ema': breadth_details.get('above_50') if breadth_details else None,
        }
        
        # Determine regime (with NIFTY 500 breadth override!)
        if trend_score >= 70:
            if vix and vix < 15:
                regime = 'STRONG_TRENDING'
            else:
                regime = 'TRENDING'
        elif trend_score >= 50:
            regime = 'TRENDING'
        elif trend_score >= 30:
            regime = 'CONSOLIDATING'
        else:
            regime = 'WEAK'
        
        # Adjust for high VIX (fear)
        if vix and vix > 25:
            if regime == 'STRONG_TRENDING':
                regime = 'TRENDING'
            elif regime == 'TRENDING':
                regime = 'CONSOLIDATING'
        
        # CRITICAL: NIFTY 200 Breadth Override (User's brilliant suggestion!)
        # If market breadth is unhealthy, downgrade regime
        if breadth_healthy is not None and not breadth_healthy:
            # Market breadth weak - be more conservative
            if regime == 'STRONG_TRENDING':
                regime = 'TRENDING'
            elif regime == 'TRENDING':
                regime = 'CONSOLIDATING'
            # If already CONSOLIDATING or WEAK, stay there
        
        return regime, details
    
    def should_trade(self, regime=None):
        """
        Simple decision: Should we trade today?
        
        Args:
            regime: str or None - If None, will calculate current regime
        
        Returns:
            bool: True if favorable to trade
        """
        if regime is None:
            regime, _ = self.get_market_regime()
        
        return regime in ['STRONG_TRENDING', 'TRENDING']
    
    def get_position_sizing_multiplier(self, regime=None):
        """
        Get position sizing multiplier based on regime
        
        Returns:
            float: Multiplier for position size
                1.5 = Trade 50% larger positions
                1.0 = Normal position size
                0.5 = Trade 50% smaller positions
                0.0 = Don't trade
        """
        if regime is None:
            regime, _ = self.get_market_regime()
        
        multipliers = {
            'STRONG_TRENDING': 1.5,   # Trade larger
            'TRENDING': 1.0,           # Normal
            'CONSOLIDATING': 0.5,      # Trade smaller or skip
            'WEAK': 0.0,               # Don't trade
            'UNKNOWN': 0.5,            # Conservative if unsure
        }
        
        return multipliers.get(regime, 0.5)
    
    def print_regime_report(self):
        """Print a detailed regime report"""
        regime, details = self.get_market_regime()
        
        print("\n" + "="*70)
        print("📊 MARKET REGIME ANALYSIS")
        print("="*70)
        print(f"\nCurrent Regime: {regime}")
        print(f"Should Trade: {'✅ YES' if self.should_trade(regime) else '❌ NO'}")
        print(f"\nNifty 50 Analysis:")
        print(f"  Price: {details['nifty_price']}")
        print(f"  21 EMA: {details['ema_21']} ({'✓ Above' if details['price_above_21ema'] else '✗ Below'})")
        print(f"  50 EMA: {details['ema_50']} ({'✓ Above' if details['price_above_50ema'] else '✗ Below'})")
        print(f"  Trend Strength: {details['trend_score']}/100")
        print(f"  Recent Return (20d): {details['recent_return_20d']:.2f}%")
        if details['vix']:
            print(f"  VIX: {details['vix']}")
        
        print(f"\nNifty 500 Breadth (Market Health):")
        if details['breadth_score'] is not None:
            print(f"  Breadth Score: {details['breadth_score']}/100")
            print(f"  Status: {'✅ HEALTHY' if details['breadth_healthy'] else '❌ WEAK'}")
            print(f"  Above 50 EMA: {'✓ Yes' if details['nifty500_above_50ema'] else '✗ No'}")
        else:
            print(f"  Status: ⚠️ Unable to fetch NIFTY 500 data")
        
        print(f"\nTrading Recommendation:")
        if regime == 'STRONG_TRENDING':
            print("  ✅ EXCELLENT conditions - Trade aggressively")
            print("  ✅ Use full position sizes")
            print("  ✅ Take all quality setups")
        elif regime == 'TRENDING':
            print("  ✅ GOOD conditions - Trade normally")
            print("  ✅ Use standard position sizes")
            print("  ✅ Take quality setups")
        elif regime == 'CONSOLIDATING':
            print("  ⚠️  MARGINAL conditions - Trade selectively")
            print("  ⚠️  Use reduced position sizes (50%)")
            print("  ⚠️  Only take best setups (quality=2)")
        elif regime == 'WEAK':
            print("  ❌ POOR conditions - Avoid trading")
            print("  ❌ Preserve capital")
            print("  ❌ Wait for better regime")
        else:
            print("  ⚠️  UNKNOWN conditions - Be cautious")
        
        print("="*70 + "\n")
        
        return regime, details


# Example usage
if __name__ == "__main__":
    from kiteconnect import KiteConnect
    
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "RcFSX2nfdWmuiF02bjuO1gUdSEMnVF8z"
    
    # Create filter
    kite = KiteConnect(api_key=API_KEY)
    kite.set_access_token(ACCESS_TOKEN)
    
    regime_filter = MarketRegimeFilter(kite)
    
    # Check current regime
    regime_filter.print_regime_report()

