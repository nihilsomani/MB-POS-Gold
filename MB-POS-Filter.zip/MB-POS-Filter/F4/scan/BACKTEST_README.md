# EMA Pullback Strategy Backtester

## Overview

This is a comprehensive backtesting engine for the EMA Pullback Scanner strategy. It simulates realistic trading over historical data to validate strategy performance before live deployment.

## Key Features

### 1. **Realistic Trade Simulation**
- Walk-forward testing (no look-ahead bias)
- Proper entry/exit timing based on historical bar data
- Intraday high/low consideration for stop loss and target hits
- Transaction costs included (brokerage, STT, taxes)

### 2. **Risk Management**
- Position sizing based on capital and risk
- Configurable stop loss and target levels
- Maximum holding period protection
- Capital preservation logic

### 3. **Setup Quality Filtering**
- Quality scores (0-2) based on consolidation and volume
- Minimum quality threshold for trade entry
- Three setup types tested separately

### 4. **Comprehensive Metrics**
- Win rate and profit factor
- Risk-adjusted returns
- Maximum drawdown tracking
- Average holding period
- Per-setup type performance
- Exit reason analysis

### 5. **Detailed Reporting**
- Trade-by-trade breakdown (CSV)
- Summary statistics (JSON)
- Performance by setup type
- Exit reason analysis

## Setup Types

### 1. PULLBACK_TO_21_EMA
- Price within 2% of 21 EMA
- 21 EMA above 55 EMA (trend filter)
- Quality boosters: consolidation, volume drying

### 2. BETWEEN_21_55_EMA
- Price between 21 and 55 EMA
- Deeper pullback in uptrend
- Quality boosters: consolidation, volume drying

### 3. BOUNCED_FROM_EMA
- Price touched 10 or 21 EMA recently
- Now above EMA and rising
- High quality setup (score = 2)

## Configuration Parameters

```python
# Capital and Position Sizing
initial_capital = 1000000        # Starting capital (₹10 lakhs)
max_position_size = 0.05         # 5% of capital per trade

# Risk Management
stop_loss_pct = 0.03             # 3% stop loss
target_pct = 0.06                # 6% target (2:1 R:R)
max_holding_days = 20            # Exit after 20 days if no SL/target

# Entry Filters
min_quality_score = 1            # Minimum quality score (0-2)
```

## How to Use

### Basic Usage

```python
from backtest_scanner import EMAPullbackBacktester
from datetime import datetime, timedelta

# Initialize
API_KEY = "your_api_key"
ACCESS_TOKEN = "your_access_token"
backtester = EMAPullbackBacktester(API_KEY, ACCESS_TOKEN)

# Set backtest period
END_DATE = datetime.now()
START_DATE = END_DATE - timedelta(days=730)  # 2 years

# Run backtest
backtester.run_backtest(
    input_csv="data/MB_symbols_enriched_sector.csv",
    start_date=START_DATE,
    end_date=END_DATE
)
```

### Custom Configuration

```python
# Aggressive settings (higher risk/reward)
backtester.max_position_size = 0.10  # 10% per trade
backtester.stop_loss_pct = 0.05      # 5% stop
backtester.target_pct = 0.10         # 10% target
backtester.min_quality_score = 2     # Only highest quality setups

# Conservative settings (lower risk)
backtester.max_position_size = 0.02  # 2% per trade
backtester.stop_loss_pct = 0.02      # 2% stop
backtester.target_pct = 0.04         # 4% target (still 2:1 R:R)
backtester.min_quality_score = 0     # All setups
```

### Testing Different Periods

```python
# Bear market (2022)
START_DATE = datetime(2022, 1, 1)
END_DATE = datetime(2022, 12, 31)

# Bull market (2023-2024)
START_DATE = datetime(2023, 1, 1)
END_DATE = datetime(2024, 12, 31)

# Recent performance (last 6 months)
END_DATE = datetime.now()
START_DATE = END_DATE - timedelta(days=180)
```

## Output Files

### 1. Trades Detailed CSV
Contains every trade with:
- Entry/exit dates and prices
- Setup type and quality score
- Position size and shares
- Stop loss and target levels
- P&L (gross and net)
- Transaction costs
- Holding days
- Technical indicators at entry

**Example:**
```
Symbol,Setup_Type,Quality_Score,Entry_Date,Entry_Price,Exit_Date,Exit_Price,Exit_Reason,Net_PnL,PnL_Pct,...
RELIANCE,BOUNCED_FROM_EMA,2,2024-01-15,2500.50,2024-01-28,2650.30,TARGET,7489.60,5.99,...
TCS,PULLBACK_TO_21_EMA,1,2024-01-20,3450.00,2024-01-25,3380.25,STOP_LOSS,-3498.75,-2.02,...
```

### 2. Summary JSON
Overall performance metrics:
```json
{
    "Total_Return": 12.45,
    "Win_Rate": 58.33,
    "Profit_Factor": 1.85,
    "Max_Drawdown_Pct": -5.23,
    "Average_Holding_Days": 8.5,
    ...
}
```

## Understanding Results

### Key Metrics Explained

**Win Rate**: % of trades that were profitable
- Good: > 50%
- Excellent: > 60%

**Profit Factor**: Gross profit / Gross loss
- Profitable: > 1.0
- Good: > 1.5
- Excellent: > 2.0

**Max Drawdown**: Largest peak-to-trough decline
- Good: < 10%
- Acceptable: 10-20%
- High risk: > 20%

**Average Holding**: Days per trade
- Short-term: 5-10 days
- Medium-term: 10-20 days
- Long-term: > 20 days

### Setup Type Performance

Compare performance across three setup types:
- Which has highest win rate?
- Which generates most profit?
- Which has best risk/reward?

**Example Analysis:**
```
BOUNCED_FROM_EMA:
  - Trades: 45
  - Win Rate: 68%
  - Avg P&L: ₹4,200
  - Best performing setup type

PULLBACK_TO_21_EMA:
  - Trades: 78
  - Win Rate: 52%
  - Avg P&L: ₹1,800
  - Most common setup

BETWEEN_21_55_EMA:
  - Trades: 23
  - Win Rate: 48%
  - Avg P&L: ₹500
  - Weakest setup type
```

### Exit Reason Analysis

Understand how trades exit:
```
TARGET (40%):
  - Best outcome
  - Avg P&L: ₹5,200

STOP_LOSS (35%):
  - Risk management working
  - Avg P&L: ₹-2,100

MAX_HOLDING (25%):
  - Consolidating trades
  - Avg P&L: ₹-800
```

## Strategy Optimization

### What to Test

1. **Position Sizing**
   - 2%, 5%, 10% per trade
   - Impact on drawdown vs returns

2. **Stop Loss Levels**
   - 2%, 3%, 5%
   - Tighter stops = more stopped out
   - Wider stops = larger losses

3. **Risk:Reward Ratios**
   - 1:1 (3% SL, 3% target)
   - 2:1 (3% SL, 6% target)
   - 3:1 (3% SL, 9% target)

4. **Quality Filters**
   - Min score 0: All setups
   - Min score 1: Good quality
   - Min score 2: Only best setups

5. **Holding Period**
   - 10 days: Fast exits
   - 20 days: Medium term
   - 30 days: Patient holding

### Optimization Process

1. **Baseline Test** (current settings)
   ```python
   backtester.max_position_size = 0.05
   backtester.stop_loss_pct = 0.03
   backtester.target_pct = 0.06
   backtester.run_backtest(...)
   # Note: Win rate, profit factor, drawdown
   ```

2. **Test Position Sizing**
   ```python
   for size in [0.02, 0.05, 0.10]:
       backtester.max_position_size = size
       backtester.run_backtest(...)
       # Compare results
   ```

3. **Test Risk Management**
   ```python
   for sl, target in [(0.02, 0.04), (0.03, 0.06), (0.05, 0.10)]:
       backtester.stop_loss_pct = sl
       backtester.target_pct = target
       backtester.run_backtest(...)
   ```

4. **Test Quality Filters**
   ```python
   for min_score in [0, 1, 2]:
       backtester.min_quality_score = min_score
       backtester.run_backtest(...)
   ```

## Realistic Expectations

### Transaction Costs
Included in every trade:
- Brokerage: ₹20 per order (or 0.03%)
- STT: 0.1% on sell side
- Other charges: ~0.05%
- Total: ~0.2-0.4% round trip

### Market Conditions Matter
- Bull markets: Higher win rates, bigger profits
- Bear markets: Lower win rates, frequent stops
- Sideways markets: More timeouts, smaller moves

### Strategy Performance Benchmarks
**Good Strategy:**
- Win rate: 50-60%
- Profit factor: > 1.5
- Annual return: 15-25%
- Max drawdown: < 15%

**Excellent Strategy:**
- Win rate: > 60%
- Profit factor: > 2.0
- Annual return: > 25%
- Max drawdown: < 10%

## Common Issues & Solutions

### 1. Too Few Trades
**Symptoms:** Only 5-10 trades in 2 years
**Solutions:**
- Lower `min_quality_score`
- Increase EMA tolerance
- Add more symbols
- Extend backtest period

### 2. High Drawdown
**Symptoms:** Max drawdown > 20%
**Solutions:**
- Reduce `max_position_size`
- Tighten `stop_loss_pct`
- Increase `min_quality_score`
- Limit concurrent positions

### 3. Low Win Rate
**Symptoms:** Win rate < 40%
**Solutions:**
- Check market regime
- Increase `min_quality_score`
- Adjust setup tolerances
- Review exit strategy

### 4. Low Profit Factor
**Symptoms:** Profit factor < 1.0
**Solutions:**
- Increase target_pct (wider targets)
- Better entry timing
- Tighter quality filters
- Review transaction costs

## Advanced Features

### Custom Stop Loss Logic

Current: EMA-based or fixed % (whichever is closer)

You can modify `simulate_trade()` to use:
- ATR-based stops
- Trailing stops
- Time-based stops
- Support level stops

### Portfolio-Level Risk Management

Add max concurrent positions:
```python
def check_max_positions(self):
    active_positions = len([t for t in self.trades 
                           if t['Exit_Date'] is None])
    return active_positions < self.max_concurrent_positions
```

### Sector Diversification

Limit positions per sector:
```python
def check_sector_limit(self, symbol):
    # Get sector from input CSV
    # Count active positions in sector
    # Return True if under limit
    pass
```

## Tips for Live Trading

1. **Paper Trade First**
   - Run strategy in parallel for 1-2 months
   - Verify signals match backtest logic
   - Build confidence

2. **Start Small**
   - Use 25-50% of intended capital
   - Scale up after confirming results
   - Build psychological comfort

3. **Keep Records**
   - Log every trade decision
   - Compare with backtest expectations
   - Identify deviations

4. **Monitor Key Metrics**
   - Are you getting expected setups?
   - Is win rate matching backtest?
   - Are exits happening as expected?

5. **Accept Reality**
   - Live results will differ from backtest
   - Slippage, emotions, timing differences
   - Expect 10-20% performance degradation

## Next Steps

1. **Run Initial Backtest**
   ```bash
   python backtest_scanner.py
   ```

2. **Analyze Results**
   - Review trade details CSV
   - Check summary metrics
   - Identify best/worst trades

3. **Optimize Parameters**
   - Test different configurations
   - Find best risk/reward balance
   - Consider market conditions

4. **Validate Strategy**
   - Test across different periods
   - Bull, bear, sideways markets
   - Recent vs historical data

5. **Deploy Strategy**
   - Paper trade first
   - Start with small capital
   - Monitor and adjust

## Conclusion

This backtester provides a solid foundation for validating your EMA pullback strategy. Use it to:
- Understand strategy strengths/weaknesses
- Optimize parameters
- Set realistic expectations
- Build confidence before live trading

Remember: **Past performance doesn't guarantee future results**, but proper backtesting significantly improves your odds of success.

---

**Questions or Issues?**
Review the code comments and console output for detailed information. The backtester logs every step for transparency.

