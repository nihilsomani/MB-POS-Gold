import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import warnings
import logging
import time
import requests
import json
warnings.filterwarnings('ignore')

class KiteDataProvider:
    """Handles Kite Connect API integration for market data"""
    
    def __init__(self, api_key, access_token=None):
        self.api_key = api_key
        self.access_token = access_token
        self.kite = None
        self.instruments_cache = None
        self.last_instruments_fetch = None
        self.instruments_cache_duration = 3600  # 1 hour cache
        self.rate_limit_delay = 0.5  # 500ms delay between API calls
        self.initialize_connection()
    
    def initialize_connection(self):
        """Initialize Kite Connect session"""
        try:
            self.kite = KiteConnect(api_key=self.api_key)
            if self.access_token:
                self.kite.set_access_token(self.access_token)
                print("Kite Connect initialized successfully!")
            else:
                print("Access token required. Please complete the login process.")
        except Exception as e:
            print(f"Error initializing Kite Connect: {e}")
    
    def get_login_url(self):
        """Get login URL for authentication"""
        if self.kite:
            return self.kite.login_url()
        return None
    
    def set_access_token(self, request_token, api_secret):
        """Generate and set access token"""
        try:
            data = self.kite.generate_session(request_token, api_secret=api_secret)
            self.access_token = data["access_token"]
            self.kite.set_access_token(self.access_token)
            print(f"Access token generated: {self.access_token}")
            return self.access_token
        except Exception as e:
            print(f"Error generating access token: {e}")
            return None
    
    def fetch_historical_data(self, instrument_token, from_date, to_date, interval="day"):
        """Fetch historical data from Kite Connect with rate limiting"""
        try:
            if not self.access_token:
                print("Please set access token first")
                return None
            
            # Add rate limiting for historical data calls
            time.sleep(self.rate_limit_delay)
            
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            # Convert to DataFrame
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            
            # Rename columns to match standard format
            df.rename(columns={
                'open': 'Open',
                'high': 'High', 
                'low': 'Low',
                'close': 'Close',
                'volume': 'Volume'
            }, inplace=True)
            
            return df
        except Exception as e:
            print(f"Error fetching historical data: {e}")
            return None
    
    def get_instruments(self, force_refresh=False):
        """Get all available instruments with caching"""
        try:
            # Check if cache is valid
            current_time = time.time()
            if (not force_refresh and 
                self.instruments_cache is not None and 
                self.last_instruments_fetch is not None and 
                (current_time - self.last_instruments_fetch) < self.instruments_cache_duration):
                return self.instruments_cache
            
            if not self.access_token:
                print("Please set access token first")
                return None
            
            # Add rate limiting
            time.sleep(self.rate_limit_delay)
            
            instruments = self.kite.instruments()
            self.instruments_cache = pd.DataFrame(instruments)
            self.last_instruments_fetch = current_time
            
            print(f"✅ Fetched {len(self.instruments_cache)} instruments from Kite Connect")
            return self.instruments_cache
            
        except Exception as e:
            print(f"Error fetching instruments: {e}")
            # Try to use cached data if available
            if self.instruments_cache is not None:
                print("Using cached instruments data")
                return self.instruments_cache
            return None
    
    def get_nse_instruments_fallback(self):
        """Get NSE instruments from public API as fallback"""
        try:
            # NSE public API for instruments
            url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                # Parse CSV content
                lines = response.text.strip().split('\n')
                instruments = []
                
                for line in lines[1:]:  # Skip header
                    parts = line.split(',')
                    if len(parts) >= 2:
                        symbol = parts[0].strip().strip('"')
                        name = parts[1].strip().strip('"')
                        # Create a mock instrument token (this won't work for actual trading)
                        # but helps identify valid symbols
                        instruments.append({
                            'tradingsymbol': symbol,
                            'name': name,
                            'exchange': 'NSE',
                            'instrument_token': f"NSE_{symbol}",  # Mock token
                            'instrument_type': 'EQ'
                        })
                
                df = pd.DataFrame(instruments)
                print(f"✅ Fetched {len(df)} NSE instruments from public API")
                return df
                
        except Exception as e:
            print(f"Error fetching NSE instruments fallback: {e}")
            return None
    
    def find_instrument_token(self, trading_symbol, exchange="NSE"):
        """Find instrument token for a given symbol with improved error handling"""
        try:
            # First try Kite Connect instruments
            instruments = self.get_instruments()
            
            if instruments is not None:
                filtered = instruments[
                    (instruments['tradingsymbol'] == trading_symbol) & 
                    (instruments['exchange'] == exchange)
                ]
                if not filtered.empty:
                    return filtered.iloc[0]['instrument_token']
            
            # If Kite Connect fails, try NSE fallback for validation
            if exchange == "NSE":
                nse_instruments = self.get_nse_instruments_fallback()
                if nse_instruments is not None:
                    filtered = nse_instruments[
                        nse_instruments['tradingsymbol'] == trading_symbol
                    ]
                    if not filtered.empty:
                        # Symbol exists on NSE but we need to find the real token
                        # Return a special marker to indicate symbol exists but needs manual lookup
                        return f"NSE_VALID_{trading_symbol}"
            
            return None
            
        except Exception as e:
            print(f"Error finding instrument token for {trading_symbol}: {e}")
            return None

class LunarCycleAnalyzer:
    """Analyzes market movements based on lunar cycles"""
    
    def __init__(self):
        # Known new moon date as reference (January 11, 2024)
        self.reference_new_moon = datetime(2024, 1, 11)
        self.lunar_cycle_days = 29.53  # Average lunar cycle
        
    def get_lunar_phase(self, date):
        """Calculate lunar phase for given date"""
        if isinstance(date, str):
            date = datetime.strptime(date, '%Y-%m-%d')
        elif hasattr(date, 'date'):
            date = date.date()
            date = datetime.combine(date, datetime.min.time())
        
        days_since_ref = (date - self.reference_new_moon).days
        cycle_position = (days_since_ref % self.lunar_cycle_days) / self.lunar_cycle_days
        
        if cycle_position < 0.125 or cycle_position >= 0.875:
            return "New Moon"
        elif 0.125 <= cycle_position < 0.375:
            return "Waxing"
        elif 0.375 <= cycle_position < 0.625:
            return "Full Moon"
        else:
            return "Waning"
    
    def is_significant_lunar_period(self, date):
        """Check if date falls during significant lunar periods"""
        phase = self.get_lunar_phase(date)
        return phase in ["New Moon", "Full Moon"]
    
    def get_lunar_influence_strength(self, date):
        """Calculate enhanced lunar influence strength with timing precision"""
        phase = self.get_lunar_phase(date)
        
        # Calculate days from significant lunar events
        days_from_new_moon = None
        days_from_full_moon = None
        
        # Find nearest significant lunar events
        for i in range(-15, 16):  # Check ±15 days
            check_date = date + timedelta(days=i)
            check_phase = self.get_lunar_phase(check_date)
            if check_phase == "New Moon" and days_from_new_moon is None:
                days_from_new_moon = abs(i)
            if check_phase == "Full Moon" and days_from_full_moon is None:
                days_from_full_moon = abs(i)
        
        # ENHANCED scoring based on proximity to significant events
        if phase in ["New Moon", "Full Moon"]:
            # Exact new/full moon = maximum strength
            return 2.5  # INCREASED from 2.0
        elif phase == "Waning":
            # Check proximity to full moon
            if days_from_full_moon is not None and days_from_full_moon <= 1:
                return 2.0  # INCREASED: Very strong waning within 1 day of full moon
            elif days_from_full_moon is not None and days_from_full_moon <= 2:
                return 1.8  # INCREASED: Strong waning near full moon
            elif days_from_new_moon is not None and days_from_new_moon <= 2:
                return 0.6  # Slightly increased: Weak waning near new moon
            else:
                return 1.0  # INCREASED: Standard waning
        elif phase == "Waxing":
            # Check proximity to new moon
            if days_from_new_moon is not None and days_from_new_moon <= 1:
                return 2.0  # INCREASED: Very strong waxing within 1 day of new moon
            elif days_from_new_moon is not None and days_from_new_moon <= 2:
                return 1.8  # INCREASED: Strong waxing near new moon
            elif days_from_full_moon is not None and days_from_full_moon <= 2:
                return 0.6  # Slightly increased: Weak waxing near full moon
            else:
                return 1.0  # INCREASED: Standard waxing
        else:
            return 0.4  # Slightly increased: Other phases

class GannAnalyzer:
    """Implements Gann Theory analysis with Indian market adaptations"""
    
    def __init__(self, data):
        self.data = data
        self.gann_angles = {
            '1x1': 1.0,    # 1 point price per 1 day
            '1x2': 0.5,    # 1 point price per 2 days
            '2x1': 2.0,    # 2 points price per 1 day
            '1x4': 0.25,   # 1 point price per 4 days
            '4x1': 4.0     # 4 points price per 1 day
        }
    
    def find_significant_pivots(self, lookback=20):
        """Find significant pivot points in price data"""
        pivots = []
        
        for i in range(lookback, len(self.data) - lookback):
            current_high = self.data.iloc[i]['High']
            current_low = self.data.iloc[i]['Low']
            
            # Check for swing high
            is_swing_high = True
            for j in range(i - lookback, i + lookback + 1):
                if j != i and self.data.iloc[j]['High'] >= current_high:
                    is_swing_high = False
                    break
            
            # Check for swing low  
            is_swing_low = True
            for j in range(i - lookback, i + lookback + 1):
                if j != i and self.data.iloc[j]['Low'] <= current_low:
                    is_swing_low = False
                    break
            
            if is_swing_high:
                pivots.append({
                    'date': self.data.index[i],
                    'price': current_high,
                    'type': 'high'
                })
            elif is_swing_low:
                pivots.append({
                    'date': self.data.index[i], 
                    'price': current_low,
                    'type': 'low'
                })
        
        return pivots
    
    def calculate_gann_levels(self, pivot_price, pivot_date, current_date, angle='1x1'):
        """Calculate Gann levels from a pivot point"""
        try:
            if isinstance(current_date, str):
                current_date = pd.to_datetime(current_date)
            if isinstance(pivot_date, str):
                pivot_date = pd.to_datetime(pivot_date)
            
            days_diff = (current_date - pivot_date).days
            if days_diff <= 0:
                return pivot_price
            
            angle_value = self.gann_angles.get(angle, 1.0)
            price_movement = days_diff * angle_value
            
            return pivot_price + price_movement, pivot_price - price_movement
        except Exception as e:
            print(f"Error calculating Gann levels: {e}")
            return pivot_price, pivot_price
    
    def find_gann_squares(self, price):
        """Find Gann square levels"""
        sqrt_price = np.sqrt(price)
        lower_square = (int(sqrt_price)) ** 2
        upper_square = (int(sqrt_price) + 1) ** 2
        
        # Calculate additional square levels
        square_levels = []
        base_sqrt = int(sqrt_price)
        
        for i in range(-2, 3):
            level = (base_sqrt + i) ** 2
            if level > 0:
                square_levels.append(level)
        
        return sorted(square_levels)
    
    def get_gann_signals(self, current_price=None):
        """Generate Gann-based trading signals with reduced scoring"""
        if current_price is None:
            current_price = self.data['Close'].iloc[-1]
        
        signals = []
        pivots = self.find_significant_pivots()
        
        # Check Gann square levels with STRICTER tolerance
        square_levels = self.find_gann_squares(current_price)
        tolerance = current_price * 0.01  # REDUCED from 1.5% to 1% tolerance
        
        for level in square_levels:
            if abs(current_price - level) <= tolerance:
                signal_type = "Support" if level < current_price else "Resistance"
                # REDUCED strength scoring
                distance_ratio = abs(current_price - level) / tolerance
                if distance_ratio <= 0.3:  # Very close
                    strength = 1.5
                elif distance_ratio <= 0.6:  # Close
                    strength = 1.0
                else:  # Within tolerance but not close
                    strength = 0.5
                
                signals.append({
                    'type': 'Gann Square',
                    'signal': signal_type,
                    'level': level,
                    'strength': strength
                })
        
        # Check Gann fan levels from recent pivots with REDUCED scoring
        if len(pivots) >= 2:
            latest_pivot = pivots[-1]
            current_date = self.data.index[-1]
            
            upper_level, lower_level = self.calculate_gann_levels(
                latest_pivot['price'], 
                latest_pivot['date'], 
                current_date
            )
            
            if abs(current_price - upper_level) <= tolerance:
                signals.append({
                    'type': 'Gann Fan',
                    'signal': 'Resistance',
                    'level': upper_level,
                    'strength': 1.0  # REDUCED from 2 to 1
                })
            elif abs(current_price - lower_level) <= tolerance:
                signals.append({
                    'type': 'Gann Fan', 
                    'signal': 'Support',
                    'level': lower_level,
                    'strength': 1.0  # REDUCED from 2 to 1
                })
        
        return signals

class ElliottWaveAnalyzer:
    """Enhanced Elliott Wave Theory analysis for Indian markets"""
    
    def __init__(self, data):
        self.data = data
        self.fibonacci_ratios = [0.236, 0.382, 0.5, 0.618, 0.786, 1.0, 1.272, 1.618, 2.618]
        self.wave_degrees = {
            'Supercycle': {'min_days': 365, 'description': 'Multi-year waves'},
            'Cycle': {'min_days': 180, 'description': 'Annual waves'},
            'Primary': {'min_days': 90, 'description': 'Quarterly waves'},
            'Intermediate': {'min_days': 30, 'description': 'Monthly waves'},
            'Minor': {'min_days': 7, 'description': 'Weekly waves'},
            'Minute': {'min_days': 1, 'description': 'Daily waves'}
        }
    
    def enhanced_peak_trough_detection(self, data, min_strength=3):
        """Enhanced peak/trough detection with strength scoring"""
        peaks = []
        troughs = []
        
        # Use multiple timeframe analysis
        for window in [5, 10, 20]:
            # Calculate local extrema
            highs = data['High'].rolling(window=window*2+1, center=True).max()
            lows = data['Low'].rolling(window=window*2+1, center=True).min()
            
            for i in range(window, len(data) - window):
                # Peak detection with strength scoring
                if data.iloc[i]['High'] == highs.iloc[i]:
                    strength = self.calculate_extrema_strength(data, i, 'peak', window)
                    if strength >= min_strength:
                        peaks.append({
                            'index': i,
                            'price': data.iloc[i]['High'],
                            'date': data.index[i],
                            'strength': strength,
                            'timeframe': window,
                            'type': 'Peak'
                        })
                
                # Trough detection with strength scoring
                if data.iloc[i]['Low'] == lows.iloc[i]:
                    strength = self.calculate_extrema_strength(data, i, 'trough', window)
                    if strength >= min_strength:
                        troughs.append({
                            'index': i,
                            'price': data.iloc[i]['Low'],
                            'date': data.index[i],
                            'strength': strength,
                            'timeframe': window,
                            'type': 'Trough'
                        })
        
        # Remove duplicates and rank by strength
        peaks = self.deduplicate_extrema(peaks)
        troughs = self.deduplicate_extrema(troughs)
        
        return peaks, troughs
    
    def calculate_extrema_strength(self, data, index, extrema_type, window):
        """Calculate strength of peak/trough based on multiple factors"""
        strength = 0
        price = data.iloc[index]['High'] if extrema_type == 'peak' else data.iloc[index]['Low']
        
        # Volume confirmation
        volume_avg = data['Volume'].iloc[index-window:index+window].mean()
        if data.iloc[index]['Volume'] > volume_avg * 1.2:
            strength += 1
        
        # Price significance
        price_range = data.iloc[index-window:index+window]
        if extrema_type == 'peak':
            if price > price_range['High'].quantile(0.9):
                strength += 2
        else:
            if price < price_range['Low'].quantile(0.1):
                strength += 2
        
        # Time at extreme
        consecutive_bars = 1
        if extrema_type == 'peak':
            for j in range(1, min(5, window)):
                if (index + j < len(data) and 
                    data.iloc[index]['High'] >= data.iloc[index + j]['High']):
                    consecutive_bars += 1
        else:
            for j in range(1, min(5, window)):
                if (index + j < len(data) and 
                    data.iloc[index]['Low'] <= data.iloc[index + j]['Low']):
                    consecutive_bars += 1
        
        strength += min(consecutive_bars, 3)
        
        return strength
    
    def deduplicate_extrema(self, extrema_list):
        """Remove duplicate extrema and rank by strength"""
        if not extrema_list:
            return []
        
        # Sort by index
        extrema_list.sort(key=lambda x: x['index'])
        
        # Remove duplicates (within 3 bars)
        deduplicated = []
        for extrema in extrema_list:
            is_duplicate = False
            for existing in deduplicated:
                if abs(extrema['index'] - existing['index']) <= 3:
                    # Keep the stronger one
                    if extrema['strength'] > existing['strength']:
                        deduplicated.remove(existing)
                        deduplicated.append(extrema)
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                deduplicated.append(extrema)
        
        # Sort by strength (highest first)
        deduplicated.sort(key=lambda x: x['strength'], reverse=True)
        
        return deduplicated
    
    def find_peaks_troughs(self, window=5):
        """Legacy method - now uses enhanced detection"""
        peaks, troughs = self.enhanced_peak_trough_detection(self.data, min_strength=2)
        
        # Convert to legacy format for backward compatibility
        legacy_peaks = []
        legacy_troughs = []
        
        for peak in peaks:
            legacy_peaks.append({
                'date': peak['date'],
                'price': peak['price'],
                'type': peak['type'],
                'index': peak['index'],
                'strength': peak.get('strength', 0)
            })
        
        for trough in troughs:
            legacy_troughs.append({
                'date': trough['date'],
                'price': trough['price'],
                'type': trough['type'],
                'index': trough['index'],
                'strength': trough.get('strength', 0)
            })
        
        return legacy_peaks, legacy_troughs
    
    def calculate_fibonacci_levels(self, high_price, low_price, trend_direction='up'):
        """Calculate Fibonacci retracement/extension levels"""
        diff = abs(high_price - low_price)
        levels = {}
        
        if trend_direction == 'up':
            for ratio in self.fibonacci_ratios:
                levels[f'{ratio:.3f}'] = high_price - (diff * ratio)
        else:
            for ratio in self.fibonacci_ratios:
                levels[f'{ratio:.3f}'] = low_price + (diff * ratio)
        
        return levels
    
    def validate_elliott_rules(self, waves):
        """Enhanced Elliott Wave rule validation"""
        if len(waves) < 5:
            return False
        
        try:
            validation_score = 0
            max_score = 5
            
            # Rule 1: Wave 2 cannot retrace more than 100% of Wave 1
            wave1_range = abs(waves[1]['price'] - waves[0]['price'])
            wave2_retrace = abs(waves[2]['price'] - waves[1]['price'])
            if wave2_retrace <= wave1_range:
                validation_score += 1
            
            # Rule 2: Wave 3 cannot be the shortest of waves 1, 3, and 5
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave3_length = abs(waves[3]['price'] - waves[2]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            if not (wave3_length < wave1_length and wave3_length < wave5_length):
                validation_score += 1
            
            # Rule 3: Wave 4 cannot overlap with Wave 1 price territory
            wave1_high = max(waves[0]['price'], waves[1]['price'])
            wave1_low = min(waves[0]['price'], waves[1]['price'])
            wave4_price = waves[3]['price']
            
            if not (wave1_low <= wave4_price <= wave1_high):
                validation_score += 1
            
            # Rule 4: Check Fibonacci relationships
            if self.check_fibonacci_relationships(waves):
                validation_score += 1
            
            # Rule 5: Check wave alternation
            if self.check_wave_alternation(waves):
                validation_score += 1
            
            # Return True if at least 4 out of 5 rules pass
            return validation_score >= 4
            
        except Exception as e:
            print(f"Error in Elliott Wave validation: {e}")
            return False
    
    def check_fibonacci_relationships(self, waves):
        """Check if wave relationships follow Fibonacci ratios"""
        try:
            if len(waves) < 5:
                return False
            
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave3_length = abs(waves[3]['price'] - waves[2]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            # Check if Wave 3 is 1.618 times Wave 1 (common relationship)
            w3_w1_ratio = wave3_length / wave1_length if wave1_length > 0 else 0
            if 1.5 <= w3_w1_ratio <= 1.8:
                return True
            
            # Check if Wave 5 equals Wave 1
            w5_w1_ratio = wave5_length / wave1_length if wave1_length > 0 else 0
            if 0.8 <= w5_w1_ratio <= 1.2:
                return True
            
            # Check if Wave 5 is 0.618 times Wave 3
            w5_w3_ratio = wave5_length / wave3_length if wave3_length > 0 else 0
            if 0.5 <= w5_w3_ratio <= 0.7:
                return True
            
            return False
            
        except:
            return False
    
    def check_wave_alternation(self, waves):
        """Check if waves alternate between peaks and troughs properly"""
        try:
            if len(waves) < 5:
                return False
            
            # Check that we have alternating peaks and troughs
            types = [wave['type'] for wave in waves[:5]]
            
            # Should start with either peak or trough and alternate
            if types[0] == types[1] or types[1] == types[2] or types[2] == types[3] or types[3] == types[4]:
                return False
            
            return True
            
        except:
            return False
    
    def classify_wave_degree(self, waves):
        """Classify the degree of Elliott Wave pattern"""
        try:
            if len(waves) < 2:
                return 'Unknown'
            
            # Calculate total duration
            start_date = waves[0]['date']
            end_date = waves[-1]['date']
            duration_days = (end_date - start_date).days
            
            # Classify based on duration
            for degree, info in self.wave_degrees.items():
                if duration_days >= info['min_days']:
                    return degree
            
            return 'Minute'
            
        except:
            return 'Unknown'
    
    def identify_wave_type(self, waves):
        """Identify if the pattern is impulse or corrective"""
        try:
            if len(waves) < 5:
                return 'Incomplete'
            
            # Check if it follows impulse pattern (5 waves)
            if len(waves) == 5:
                # Check if it's trending in one direction overall
                start_price = waves[0]['price']
                end_price = waves[4]['price']
                
                # If overall direction is up and waves 1,3,5 are up movements
                if end_price > start_price:
                    return 'Impulse (Up)'
                elif end_price < start_price:
                    return 'Impulse (Down)'
            
            # Check for corrective patterns (3 waves)
            elif len(waves) == 3:
                return 'Corrective'
            
            return 'Complex'
            
        except:
            return 'Unknown'
    
    def detect_wave_pattern(self):
        """Enhanced Elliott Wave pattern detection with multiple pattern types"""
        peaks, troughs = self.enhanced_peak_trough_detection(self.data, min_strength=2)
        
        # Combine and sort all turning points
        all_points = peaks + troughs
        all_points.sort(key=lambda x: x['index'])
        
        if len(all_points) < 5:
            return None
        
        best_pattern = None
        best_score = 0
        
        # Look for 5-wave impulse patterns
        for i in range(len(all_points) - 4):
            wave_candidate = all_points[i:i+5]
            
            # Check if it alternates between peaks and troughs
            types = [point['type'] for point in wave_candidate]
            if len(set(types)) == 2:  # Should have both peaks and troughs
                
                # Validate Elliott Wave rules
                if self.validate_elliott_rules(wave_candidate):
                    
                    # Calculate wave characteristics
                    wave_analysis = self.analyze_wave_structure(wave_candidate)
                    
                    # Calculate enhanced pattern strength
                    pattern_strength = self.calculate_enhanced_pattern_strength(wave_candidate)
                    
                    # Get additional classifications
                    wave_degree = self.classify_wave_degree(wave_candidate)
                    wave_type = self.identify_wave_type(wave_candidate)
                    
                    # Calculate overall score
                    overall_score = pattern_strength + self.calculate_confidence_score(wave_candidate)
                    
                    if overall_score > best_score:
                        best_pattern = {
                            'waves': wave_candidate,
                            'analysis': wave_analysis,
                            'completion_date': wave_candidate[-1]['date'],
                            'pattern_strength': pattern_strength,
                            'wave_degree': wave_degree,
                            'wave_type': wave_type,
                            'confidence_score': overall_score,
                            'fibonacci_analysis': self.analyze_fibonacci_relationships(wave_candidate)
                        }
                        best_score = overall_score
        
        # If no 5-wave pattern found, look for 3-wave corrective patterns
        if best_pattern is None:
            for i in range(len(all_points) - 2):
                wave_candidate = all_points[i:i+3]
                
                # Check for corrective pattern characteristics
                if self.is_corrective_pattern(wave_candidate):
                    wave_analysis = self.analyze_wave_structure(wave_candidate)
                    
                    best_pattern = {
                        'waves': wave_candidate,
                        'analysis': wave_analysis,
                        'completion_date': wave_candidate[-1]['date'],
                        'pattern_strength': 2,  # Lower strength for corrective patterns
                        'wave_degree': self.classify_wave_degree(wave_candidate),
                        'wave_type': 'Corrective',
                        'confidence_score': 3,
                        'fibonacci_analysis': self.analyze_fibonacci_relationships(wave_candidate)
                    }
                    break
        
        return best_pattern
    
    def is_corrective_pattern(self, waves):
        """Check if a 3-wave pattern is a valid corrective pattern"""
        try:
            if len(waves) != 3:
                return False
            
            # Check alternation
            types = [wave['type'] for wave in waves]
            if len(set(types)) != 2:
                return False
            
            # Check if middle wave retraces significantly
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave2_length = abs(waves[2]['price'] - waves[1]['price'])
            
            # Wave 2 should retrace at least 38.2% of wave 1
            retracement = wave2_length / wave1_length if wave1_length > 0 else 0
            return retracement >= 0.382
            
        except:
            return False
    
    def calculate_enhanced_pattern_strength(self, waves):
        """Calculate enhanced pattern strength with multiple factors - FIXED SCORING"""
        strength = 0
        
        try:
            # Base strength for having 5 waves (REDUCED from 3 to 1.5)
            strength += 1.5
            
            # Volume confirmation (REDUCED from 0-2 to 0-1)
            volume_strength = self.calculate_volume_strength(waves) * 0.5
            strength += volume_strength
            
            # Fibonacci relationship strength (REDUCED from 0-3 to 0-1.5)
            fib_strength = self.calculate_fibonacci_strength(waves) * 0.5
            strength += fib_strength
            
            # Time symmetry (REDUCED from 0-1 to 0-0.5)
            time_strength = self.calculate_time_symmetry_strength(waves) * 0.5
            strength += time_strength
            
            # Price symmetry (REDUCED from 0-1 to 0-0.5)
            price_strength = self.calculate_price_symmetry_strength(waves) * 0.5
            strength += price_strength
            
            # CAP AT 5 POINTS (not 10)
            return min(strength, 5.0)
            
        except:
            return 1
    
    def calculate_volume_strength(self, waves):
        """Calculate strength based on volume confirmation"""
        try:
            volume_score = 0
            
            for wave in waves:
                index = wave['index']
                if index < len(self.data):
                    # Check if volume was above average during the wave
                    window_start = max(0, index - 5)
                    window_end = min(len(self.data), index + 5)
                    avg_volume = self.data['Volume'].iloc[window_start:window_end].mean()
                    
                    if self.data.iloc[index]['Volume'] > avg_volume * 1.1:
                        volume_score += 0.5
            
            return min(volume_score, 2)
            
        except:
            return 0
    
    def calculate_fibonacci_strength(self, waves):
        """Calculate strength based on Fibonacci relationships - STRICTER SCORING"""
        try:
            if len(waves) < 5:
                return 0
            
            fib_score = 0
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave3_length = abs(waves[3]['price'] - waves[2]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            # STRICTER: Check Wave 3 / Wave 1 ratio (tighter tolerances)
            w3_w1_ratio = wave3_length / wave1_length if wave1_length > 0 else 0
            if 1.55 <= w3_w1_ratio <= 1.65:  # Tighter range for 1.618
                fib_score += 2
            elif 1.45 <= w3_w1_ratio <= 1.75:  # Wider but still strict
                fib_score += 1
            
            # STRICTER: Check Wave 5 / Wave 1 ratio
            w5_w1_ratio = wave5_length / wave1_length if wave1_length > 0 else 0
            if 0.95 <= w5_w1_ratio <= 1.05:  # Tighter range for 1.0
                fib_score += 2
            elif 0.85 <= w5_w1_ratio <= 1.15:  # Wider but still strict
                fib_score += 1
            
            # CAP AT 2 POINTS (reduced from 3)
            return min(fib_score, 2)
            
        except:
            return 0
    
    def calculate_time_symmetry_strength(self, waves):
        """Calculate strength based on time symmetry"""
        try:
            if len(waves) < 5:
                return 0
            
            # Calculate time ratios between waves
            time_ratios = []
            for i in range(1, len(waves)):
                time_diff = (waves[i]['date'] - waves[i-1]['date']).days
                time_ratios.append(time_diff)
            
            # Check for Fibonacci time relationships
            symmetry_score = 0
            if len(time_ratios) >= 4:
                # Wave 2 time vs Wave 4 time
                if time_ratios[1] > 0 and time_ratios[3] > 0:
                    ratio = time_ratios[3] / time_ratios[1]
                    if 0.6 <= ratio <= 1.6:
                        symmetry_score += 1
            
            return min(symmetry_score, 1)
            
        except:
            return 0
    
    def calculate_price_symmetry_strength(self, waves):
        """Calculate strength based on price symmetry"""
        try:
            if len(waves) < 5:
                return 0
            
            symmetry_score = 0
            
            # Check if waves 1 and 5 are similar in magnitude
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            if wave1_length > 0:
                ratio = wave5_length / wave1_length
                if 0.8 <= ratio <= 1.2:
                    symmetry_score += 1
                elif 0.6 <= ratio <= 1.4:
                    symmetry_score += 0.5
            
            return min(symmetry_score, 1)
            
        except:
            return 0
    
    def calculate_confidence_score(self, waves):
        """Calculate overall confidence score for the pattern - FIXED SCORING"""
        try:
            confidence = 0
            
            # Base confidence for valid pattern (REDUCED from 2 to 1)
            confidence += 1
            
            # Add confidence based on strength of individual waves (REDUCED multiplier)
            for wave in waves:
                if 'strength' in wave:
                    confidence += wave['strength'] * 0.1  # REDUCED from 0.2 to 0.1
            
            # Add confidence for recent waves (REDUCED bonus)
            total_days = (waves[-1]['date'] - waves[0]['date']).days
            if total_days > 0:
                recent_factor = min(30 / total_days, 1)
                confidence += recent_factor * 1  # REDUCED from 2 to 1
            
            # CAP AT 3 POINTS (not 5)
            return min(confidence, 3.0)
            
        except:
            return 0.5
    
    def analyze_fibonacci_relationships(self, waves):
        """Detailed Fibonacci relationship analysis"""
        try:
            if len(waves) < 5:
                return {}
            
            analysis = {}
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave3_length = abs(waves[3]['price'] - waves[2]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            # Calculate ratios
            analysis['w3_w1_ratio'] = wave3_length / wave1_length if wave1_length > 0 else 0
            analysis['w5_w1_ratio'] = wave5_length / wave1_length if wave1_length > 0 else 0
            analysis['w5_w3_ratio'] = wave5_length / wave3_length if wave3_length > 0 else 0
            
            # Identify Fibonacci matches
            fib_matches = []
            target_ratios = [0.618, 1.0, 1.618, 2.618]
            
            for ratio_name, ratio_value in [('W3/W1', analysis['w3_w1_ratio']), 
                                           ('W5/W1', analysis['w5_w1_ratio']),
                                           ('W5/W3', analysis['w5_w3_ratio'])]:
                for target in target_ratios:
                    if abs(ratio_value - target) < 0.1:
                        fib_matches.append(f"{ratio_name} ≈ {target}")
            
            analysis['fibonacci_matches'] = fib_matches
            analysis['fibonacci_score'] = len(fib_matches)
            
            return analysis
            
        except:
            return {}
    
    def analyze_wave_structure(self, waves):
        """Analyze the structure of detected waves"""
        analysis = {}
        
        for i, wave in enumerate(waves):
            wave_name = f"Wave_{i+1}"
            analysis[wave_name] = {
                'price': wave['price'],
                'date': wave['date'],
                'type': wave['type']
            }
            
            if i > 0:
                prev_wave = waves[i-1]
                move_size = abs(wave['price'] - prev_wave['price'])
                move_direction = 'up' if wave['price'] > prev_wave['price'] else 'down'
                
                analysis[wave_name].update({
                    'move_size': move_size,
                    'direction': move_direction,
                    'days': (wave['date'] - prev_wave['date']).days
                })
        
        return analysis
    
    def calculate_pattern_strength(self, waves):
        """Calculate the strength/reliability of the Elliott Wave pattern"""
        strength = 0
        
        # Check Fibonacci relationships
        if len(waves) >= 5:
            try:
                wave1_size = abs(waves[1]['price'] - waves[0]['price'])
                wave3_size = abs(waves[3]['price'] - waves[2]['price'])
                wave5_size = abs(waves[4]['price'] - waves[3]['price'])
                
                # Wave 3 is often 1.618 times Wave 1
                if 1.5 < (wave3_size / wave1_size) < 1.8:
                    strength += 2
                
                # Wave 5 is often equal to Wave 1
                if 0.8 < (wave5_size / wave1_size) < 1.2:
                    strength += 1
                
                strength += 1  # Base strength for having 5 waves
                
            except ZeroDivisionError:
                pass
        
        return min(strength, 5)  # Max strength of 5

class IntegratedMarketAnalyzer:
    """Enhanced market analyzer using Kite Connect API"""
    
    def __init__(self, api_key, access_token=None, symbol="NIFTY 50", instrument_token=256265):
        self.symbol = symbol
        self.instrument_token = instrument_token
        self.data_provider = KiteDataProvider(api_key, access_token)
        self.data = None
        self.lunar_analyzer = LunarCycleAnalyzer()
        self.gann_analyzer = None
        self.elliott_analyzer = None
    
    def fetch_market_data(self, days=180):
        """Fetch historical market data"""
        try:
            to_date = datetime.now()
            from_date = to_date - timedelta(days=days)
            
            print(f"Fetching {self.symbol} data from {from_date.date()} to {to_date.date()}...")
            
            self.data = self.data_provider.fetch_historical_data(
                instrument_token=self.instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if self.data is not None and not self.data.empty:
                print(f"Successfully fetched {len(self.data)} trading sessions")
                self.gann_analyzer = GannAnalyzer(self.data)
                self.elliott_analyzer = ElliottWaveAnalyzer(self.data)
                return True
            else:
                print("No data received")
                return False
                
        except Exception as e:
            print(f"Error fetching market data: {e}")
            return False
    
    def generate_combined_signals(self):
        """Generate comprehensive trading signals"""
        if self.data is None:
            return []
        
        signals = []
        current_price = self.data['Close'].iloc[-1]
        current_date = self.data.index[-1]
        
        # Initialize signal components
        signal_strength = 0
        signal_type = "Hold"
        reasons = []
        
        # 1. Lunar Analysis
        lunar_phase = self.lunar_analyzer.get_lunar_phase(current_date)
        lunar_strength = self.lunar_analyzer.get_lunar_influence_strength(current_date)
        lunar_significant = self.lunar_analyzer.is_significant_lunar_period(current_date)
        
        if lunar_significant:
            signal_strength += lunar_strength
            reasons.append(f"Significant lunar phase: {lunar_phase}")
        
        # 2. Gann Analysis
        gann_signals = self.gann_analyzer.get_gann_signals(current_price)
        gann_strength = 0
        
        for gann_signal in gann_signals:
            gann_strength += gann_signal['strength']
            reasons.append(f"Gann {gann_signal['signal']} at {gann_signal['level']:.2f} ({gann_signal['type']})")
            
            if gann_signal['signal'] == 'Support' and signal_type != 'Sell':
                signal_type = "Buy"
            elif gann_signal['signal'] == 'Resistance' and signal_type != 'Buy':
                signal_type = "Sell"
        
        signal_strength += gann_strength
        
        # 3. Elliott Wave Analysis
        elliott_pattern = self.elliott_analyzer.detect_wave_pattern()
        elliott_strength = 0
        elliott_confidence = 0
        
        if elliott_pattern:
            elliott_strength = elliott_pattern['pattern_strength']
            elliott_confidence = elliott_pattern.get('confidence_score', 0)
            wave_type = elliott_pattern.get('wave_type', 'Unknown')
            
            # CRITICAL FIX: Differentiate corrective vs impulse patterns
            if wave_type == 'Corrective':
                # Corrective patterns get REDUCED scoring (max 3 points instead of 5)
                elliott_strength *= 0.6  # Reduce corrective patterns
                reasons.append(f"Corrective Elliott Wave pattern (Strength: {elliott_strength:.1f}/3)")
            elif wave_type.startswith('Impulse'):
                # Impulse patterns keep full scoring
                reasons.append(f"Impulse Elliott Wave pattern (Strength: {elliott_strength:.1f}/5)")
            else:
                # Unknown patterns get reduced scoring
                elliott_strength *= 0.7
                reasons.append(f"Elliott Wave pattern (Strength: {elliott_strength:.1f}/5)")
            
            # FIXED: Properly weight Elliott Wave contribution
            signal_strength += elliott_strength
            
            last_wave = elliott_pattern['waves'][-1]
            
            # FIXED: Determine signal based on wave completion with proper direction logic
            if last_wave['type'] == 'Peak':
                if signal_type != 'Buy':
                    signal_type = "Sell"
                if wave_type == 'Corrective':
                    reasons.append("End of corrective wave (lower probability)")
                elif 'Up' in wave_type:
                    reasons.append("End of 5-wave up impulse cycle")
                elif 'Down' in wave_type:
                    reasons.append("End of 5-wave down impulse cycle")
                else:
                    reasons.append("End of impulse wave cycle")
            else:  # last_wave['type'] == 'Trough'
                if signal_type != 'Sell':
                    signal_type = "Buy"
                if wave_type == 'Corrective':
                    reasons.append("End of corrective wave (lower probability)")
                elif 'Up' in wave_type:
                    reasons.append("End of corrective wave in up impulse")
                elif 'Down' in wave_type:
                    reasons.append("End of corrective wave in down impulse")
                else:
                    reasons.append("End of corrective wave")
        
        # COMPREHENSIVE FIX: Calculate final confidence with proper weighting
        # Updated scoring: Elliott Wave: 0-5 points, Gann: 0-2 points, Lunar: 0-2 points
        # Total possible: 9 points, normalize to 10-point scale
        base_confidence = signal_strength + elliott_confidence * 0.3  # Reduced Elliott confidence weight
        
        # STRICTER QUALITY GATES
        confirmations = sum([
            lunar_significant,
            len(gann_signals) > 0,
            elliott_pattern is not None
        ])
        
        # Apply quality multipliers based on confirmations
        if confirmations >= 3:
            # All three confirmations = full score
            quality_multiplier = 1.0
        elif confirmations == 2:
            # Two confirmations = 90% of score
            quality_multiplier = 0.9
        elif confirmations == 1:
            # One confirmation = 70% of score
            quality_multiplier = 0.7
        else:
            # No confirmations = 50% of score
            quality_multiplier = 0.5
        
        # Apply quality gates and cap at 10
        final_confidence = min(base_confidence * quality_multiplier, 10.0)
        
        # ADDITIONAL PENALTIES for weak setups
        if elliott_pattern and elliott_pattern.get('wave_type') == 'Corrective':
            # Corrective patterns get additional penalty for high scores
            if final_confidence > 7:
                final_confidence *= 0.85  # 15% penalty for corrective patterns above 7
        
        # PENALTY for weak Gann signals
        if len(gann_signals) > 0:
            max_gann_strength = max([s.get('strength', 0) for s in gann_signals])
            if max_gann_strength < 1.0:  # Weak Gann signals
                final_confidence *= 0.9  # 10% penalty
        
        # Generate final signal with STRICTER THRESHOLDS
        if signal_strength >= 1.5:  # Slightly lowered threshold
            # Additional quality check: High confidence requires exceptional confluence
            if final_confidence >= 9:
                # 9+ confidence requires ALL three confirmations + strong individual components
                if confirmations < 3:
                    final_confidence = 8.0  # Cap at 8 if not all confirmations
                elif elliott_pattern and elliott_pattern.get('wave_type') == 'Corrective':
                    final_confidence = 8.5  # Cap corrective patterns at 8.5
            
            # Cap very high scores to prevent overconfidence
            if final_confidence > 9.5:
                final_confidence = 9.5
            
            # ENHANCED: Determine signal context based on trend analysis
            signal_context = self._determine_signal_context(current_price, signal_type, final_confidence)
            
            signals.append({
                'Date': current_date,
                'Price': current_price,
                'Signal': signal_type,
                'Signal_Context': signal_context,
                'Strength': round(final_confidence, 1),  # FIXED: Use properly calculated confidence
                'Reasons': reasons,
                'Lunar_Phase': lunar_phase,
                'Lunar_Strength': lunar_strength,
                'Gann_Strength': gann_strength,
                'Elliott_Strength': elliott_strength,
                'Elliott_Confidence': elliott_confidence,
                'Wave_Type': wave_type if elliott_pattern else 'None',
                'Quality_Score': confirmations,
                'Components': {
                    'lunar_significant': lunar_significant,
                    'gann_signals': gann_signals,
                    'elliott_pattern': elliott_pattern is not None
                }
            })
        
        return signals
    
    def _determine_signal_context(self, current_price, signal_type, confidence):
        """Determine signal context based on trend analysis and confidence"""
        if self.data is None or len(self.data) < 50:
            return "Unknown"
        
        # Calculate trend indicators
        sma_20 = self.data['Close'].rolling(window=20).mean().iloc[-1]
        sma_50 = self.data['Close'].rolling(window=50).mean().iloc[-1]
        price_vs_sma20 = (current_price - sma_20) / sma_20 * 100
        price_vs_sma50 = (current_price - sma_50) / sma_50 * 100
        
        # Determine trend context
        if price_vs_sma20 > 2 and price_vs_sma50 > 2:
            trend_context = "Strong Uptrend"
        elif price_vs_sma20 > 0 and price_vs_sma50 > 0:
            trend_context = "Uptrend"
        elif price_vs_sma20 < -2 and price_vs_sma50 < -2:
            trend_context = "Strong Downtrend"
        elif price_vs_sma20 < 0 and price_vs_sma50 < 0:
            trend_context = "Downtrend"
        else:
            trend_context = "Sideways"
        
        # Determine signal context
        if confidence >= 8:
            if signal_type == "Buy" and "Uptrend" in trend_context:
                return "BUY for Trend"
            elif signal_type == "Sell" and "Downtrend" in trend_context:
                return "SELL for Trend"
            elif signal_type == "Buy" and "Sideways" in trend_context:
                return "BUY for Swing"
            elif signal_type == "Sell" and "Sideways" in trend_context:
                return "SELL for Swing"
            else:
                return f"{signal_type} (Counter-trend)"
        elif confidence >= 6:
            if "Sideways" in trend_context:
                return f"{signal_type} for Range"
            else:
                return f"{signal_type} (Weak)"
        else:
            return f"{signal_type} (Low Confidence)"
    
    def create_comprehensive_report(self):
        """Generate detailed analysis report"""
        if self.data is None:
            print("No data available. Please fetch market data first.")
            return
        
        signals = self.generate_combined_signals()
        
        print("="*70)
        print("ADVANCED MARKET ANALYSIS REPORT - KITE CONNECT")
        print("="*70)
        print(f"Symbol: {self.symbol}")
        print(f"Instrument Token: {self.instrument_token}")
        print(f"Analysis Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} IST")
        print(f"Data Period: {self.data.index[0].strftime('%Y-%m-%d')} to {self.data.index[-1].strftime('%Y-%m-%d')}")
        print(f"Total Trading Sessions: {len(self.data)}")
        print()
        
        # Current Market Status
        current_price = self.data['Close'].iloc[-1]
        prev_price = self.data['Close'].iloc[-2]
        high_52w = self.data['High'].max()
        low_52w = self.data['Low'].min()
        price_change = ((current_price - prev_price) / prev_price) * 100
        
        print("CURRENT MARKET STATUS:")
        print(f"Current Price: ₹{current_price:.2f}")
        print(f"Previous Close: ₹{prev_price:.2f}")
        print(f"Price Change: {price_change:+.2f}%")
        print(f"52-Week High: ₹{high_52w:.2f}")
        print(f"52-Week Low: ₹{low_52w:.2f}")
        print(f"Distance from 52W High: {((current_price - high_52w) / high_52w * 100):+.2f}%")
        print(f"Distance from 52W Low: {((current_price - low_52w) / low_52w * 100):+.2f}%")
        print()
        
        # Lunar Cycle Analysis
        today = datetime.now()
        lunar_phase = self.lunar_analyzer.get_lunar_phase(today)
        lunar_strength = self.lunar_analyzer.get_lunar_influence_strength(today)
        lunar_significant = self.lunar_analyzer.is_significant_lunar_period(today)
        
        print("LUNAR CYCLE ANALYSIS:")
        print(f"Current Phase: {lunar_phase}")
        print(f"Influence Strength: {lunar_strength}/3")
        print(f"Significant Period: {'Yes' if lunar_significant else 'No'}")
        
        # Next significant lunar events
        next_new_moon_days = None
        next_full_moon_days = None
        for i in range(1, 30):
            future_date = today + timedelta(days=i)
            phase = self.lunar_analyzer.get_lunar_phase(future_date)
            if phase == "New Moon" and next_new_moon_days is None:
                next_new_moon_days = i
            if phase == "Full Moon" and next_full_moon_days is None:
                next_full_moon_days = i
            if next_new_moon_days and next_full_moon_days:
                break
        
        if next_new_moon_days:
            print(f"Next New Moon: {next_new_moon_days} days")
        if next_full_moon_days:
            print(f"Next Full Moon: {next_full_moon_days} days")
        print()
        
        # Gann Theory Analysis
        print("GANN THEORY ANALYSIS:")
        gann_signals = self.gann_analyzer.get_gann_signals(current_price)
        square_levels = self.gann_analyzer.find_gann_squares(current_price)
        
        print(f"Current Gann Squares: {[f'₹{level:.0f}' for level in square_levels[:5]]}")
        
        nearest_support = max([level for level in square_levels if level < current_price], default=None)
        nearest_resistance = min([level for level in square_levels if level > current_price], default=None)
        
        if nearest_support:
            print(f"Nearest Support: ₹{nearest_support:.2f} ({((current_price - nearest_support) / current_price * 100):.2f}% below)")
        if nearest_resistance:
            print(f"Nearest Resistance: ₹{nearest_resistance:.2f} ({((nearest_resistance - current_price) / current_price * 100):.2f}% above)")
        
        if gann_signals:
            print("Active Gann Signals:")
            for signal in gann_signals:
                print(f"  - {signal['type']}: {signal['signal']} at ₹{signal['level']:.2f} (Strength: {signal['strength']})")
        else:
            print("No active Gann signals")
        print()
        
        # Enhanced Elliott Wave Analysis
        print("ENHANCED ELLIOTT WAVE ANALYSIS:")
        elliott_pattern = self.elliott_analyzer.detect_wave_pattern()
        
        if elliott_pattern:
            print(f"Pattern Detected (Strength: {elliott_pattern['pattern_strength']}/10)")
            print(f"Wave Type: {elliott_pattern.get('wave_type', 'Unknown')}")
            print(f"Wave Degree: {elliott_pattern.get('wave_degree', 'Unknown')}")
            print(f"Confidence Score: {elliott_pattern.get('confidence_score', 0):.1f}/10")
            print()
            
            print("Wave Structure:")
            for wave_name, wave_data in elliott_pattern['analysis'].items():
                print(f"  {wave_name}: ₹{wave_data['price']:.2f} ({wave_data['type']}) on {wave_data['date'].strftime('%Y-%m-%d')}")
                if 'move_size' in wave_data:
                    print(f"    Movement: {wave_data['direction']} ₹{wave_data['move_size']:.2f} over {wave_data['days']} days")
                if 'strength' in wave_data:
                    print(f"    Wave Strength: {wave_data['strength']}/6")
            
            # Enhanced Fibonacci analysis
            if 'fibonacci_analysis' in elliott_pattern and elliott_pattern['fibonacci_analysis']:
                fib_analysis = elliott_pattern['fibonacci_analysis']
                print()
                print("Fibonacci Relationship Analysis:")
                
                if 'w3_w1_ratio' in fib_analysis:
                    print(f"  Wave 3/Wave 1 Ratio: {fib_analysis['w3_w1_ratio']:.3f}")
                if 'w5_w1_ratio' in fib_analysis:
                    print(f"  Wave 5/Wave 1 Ratio: {fib_analysis['w5_w1_ratio']:.3f}")
                if 'w5_w3_ratio' in fib_analysis:
                    print(f"  Wave 5/Wave 3 Ratio: {fib_analysis['w5_w3_ratio']:.3f}")
                
                if 'fibonacci_matches' in fib_analysis and fib_analysis['fibonacci_matches']:
                    print("  Fibonacci Matches:")
                    for match in fib_analysis['fibonacci_matches']:
                        print(f"    ✓ {match}")
                
                print(f"  Fibonacci Score: {fib_analysis.get('fibonacci_score', 0)}/3")
            
            # Traditional Fibonacci levels
            waves = elliott_pattern['waves']
            if len(waves) >= 3:
                fib_levels = self.elliott_analyzer.calculate_fibonacci_levels(
                    waves[-1]['price'], waves[-3]['price']
                )
                print()
                print("Key Fibonacci Retracement Levels:")
                for ratio, level in list(fib_levels.items())[:5]:
                    distance = ((level - current_price) / current_price * 100)
                    print(f"  {ratio}: ₹{level:.2f} ({distance:+.2f}%)")
        else:
            print("No clear Elliott Wave pattern detected in recent data")
            print("Analyzing recent peaks and troughs with enhanced detection...")
            peaks, troughs = self.elliott_analyzer.enhanced_peak_trough_detection(self.data, min_strength=2)
            if peaks or troughs:
                recent_points = sorted((peaks + troughs)[-5:], key=lambda x: x['index'])
                for point in recent_points:
                    strength_info = f" (Strength: {point.get('strength', 0)}/6)" if 'strength' in point else ""
                    print(f"  {point['type']}: ₹{point['price']:.2f} on {point['date'].strftime('%Y-%m-%d')}{strength_info}")
        print()
        
        # Combined Analysis & Signals
        print("INTEGRATED TRADING SIGNALS:")
        if signals:
            for signal in signals:
                print(f"SIGNAL: {signal['Signal'].upper()}")
                print(f"Signal Context: {signal.get('Signal_Context', 'Standard')}")
                print(f"Confidence: {signal['Strength']}/10")
                print(f"Current Price: ₹{signal['Price']:.2f}")
                print(f"Lunar Phase: {signal['Lunar_Phase']}")
                
                print("Signal Components:")
                print(f"  • Lunar Strength: {signal['Lunar_Strength']}/3")
                print(f"  • Gann Strength: {signal['Gann_Strength']}")
                print(f"  • Elliott Strength: {signal['Elliott_Strength']}")
                
                print("Reasoning:")
                for i, reason in enumerate(signal['Reasons'], 1):
                    print(f"  {i}. {reason}")
                
                print()
                print("TRADING RECOMMENDATION:")
                if signal['Signal'] == 'Buy':
                    print("• Position: LONG")
                    print("• Entry: Current levels or on dips")
                    if nearest_support:
                        print(f"• Stop Loss: Below ₹{nearest_support:.2f}")
                    if nearest_resistance:
                        print(f"• Target: ₹{nearest_resistance:.2f}")
                elif signal['Signal'] == 'Sell':
                    print("• Position: SHORT")
                    print("• Entry: Current levels or on rallies")
                    if nearest_resistance:
                        print(f"• Stop Loss: Above ₹{nearest_resistance:.2f}")
                    if nearest_support:
                        print(f"• Target: ₹{nearest_support:.2f}")
                else:
                    print("• Position: HOLD")
                    print("• Wait for clearer signals")
                
                print(f"• Risk Level: {'High' if signal['Strength'] < 5 else 'Medium' if signal['Strength'] < 7 else 'Low'}")
        else:
            print("No significant signals generated at this time.")
            print("Recommendation: HOLD current positions and wait for clearer market direction.")
        
        print()
        print("MARKET OUTLOOK:")
        
        # Technical momentum
        sma_20 = self.data['Close'].rolling(20).mean().iloc[-1]
        sma_50 = self.data['Close'].rolling(50).mean().iloc[-1]
        
        if current_price > sma_20 > sma_50:
            trend = "BULLISH"
        elif current_price < sma_20 < sma_50:
            trend = "BEARISH"
        else:
            trend = "SIDEWAYS"
        
        print(f"Short-term Trend: {trend}")
        print(f"20-day SMA: ₹{sma_20:.2f}")
        print(f"50-day SMA: ₹{sma_50:.2f}")
        
        # Volatility analysis
        returns = self.data['Close'].pct_change().dropna()
        volatility = returns.std() * np.sqrt(252) * 100
        avg_volume = self.data['Volume'].mean()
        recent_volume = self.data['Volume'].iloc[-5:].mean()
        volume_ratio = recent_volume / avg_volume
        
        print(f"Annualized Volatility: {volatility:.1f}%")
        print(f"Volume Activity: {'High' if volume_ratio > 1.2 else 'Normal' if volume_ratio > 0.8 else 'Low'}")
        
        print()
        print("RISK MANAGEMENT:")
        print("• Position Size: Risk maximum 2% of capital per trade")
        print("• Use stop losses as indicated above")
        print("• Monitor lunar and Gann levels for exit signals")
        print("• Review positions during significant lunar phases")
        
        print()
        print("DISCLAIMER:")
        print("• This analysis combines traditional technical analysis with esoteric methods")
        print("• Past performance does not guarantee future results")
        print("• Markets can remain irrational longer than you can remain solvent")
        print("• Always consult with a qualified financial advisor")
        print("• Use proper risk management and position sizing")
        print("="*70)

def setup_kite_connection():
    """Helper function to setup Kite Connect"""
    print("Setting up Kite Connect API...")
    print()
    
    api_key = input("Enter your Kite Connect API Key: ").strip()
    
    if not api_key:
        print("API Key is required. Please get one from https://developers.kite.trade/")
        return None, None
    
    # Check if user has access token
    has_token = input("Do you have an access token? (y/n): ").lower().strip()
    
    if has_token == 'y':
        access_token = input("Enter your access token: ").strip()
        return api_key, access_token
    else:
        print("\nTo get an access token:")
        print("1. Go to the login URL that will be displayed")
        print("2. Login with your Kite credentials")
        print("3. Copy the 'request_token' from the redirect URL")
        print("4. Enter it below along with your API secret")
        
        kite_helper = KiteDataProvider(api_key)
        login_url = kite_helper.get_login_url()
        
        if login_url:
            print(f"\nLogin URL: {login_url}")
            print("\nAfter logging in, you'll be redirected to a URL like:")
            print("https://your-redirect-url/?request_token=XXXXXX&action=login&status=success")
            
            request_token = input("\nEnter the request_token from the URL: ").strip()
            api_secret = input("Enter your API secret: ").strip()
            
            if request_token and api_secret:
                access_token = kite_helper.set_access_token(request_token, api_secret)
                return api_key, access_token
        
        return api_key, None

def get_instrument_token():
    """Helper to get instrument token for different symbols"""
    print("\nSelect instrument:")
    print("1. NIFTY 50 (Default)")
    print("2. BANK NIFTY") 
    print("3. Custom symbol")
    
    choice = input("Enter choice (1-3): ").strip()
    
    instruments = {
        '1': {'name': 'NIFTY 50', 'token': 256265},
        '2': {'name': 'NIFTY BANK', 'token': 260105}
    }
    
    if choice in instruments:
        return instruments[choice]['name'], instruments[choice]['token']
    elif choice == '3':
        symbol = input("Enter trading symbol (e.g., RELIANCE, TCS): ").strip().upper()
        print(f"You'll need to find the instrument token for {symbol}")
        print("The script will attempt to find it automatically")
        return symbol, None
    else:
        return 'NIFTY 50', 256265

def create_token_mapping_file(api_key, access_token, symbols_list, output_file="token_mapping.json"):
    """Create a mapping file of symbols to tokens to avoid repeated API calls"""
    try:
        print(f"🔧 Creating token mapping file for {len(symbols_list)} symbols...")
        
        data_provider = KiteDataProvider(api_key, access_token)
        token_mapping = {}
        
        # Get all instruments once
        instruments = data_provider.get_instruments()
        
        if instruments is not None:
            print(f"✅ Processing {len(instruments)} instruments...")
            
            for symbol in symbols_list:
                symbol_clean = symbol.strip().upper()
                filtered = instruments[
                    (instruments['tradingsymbol'] == symbol_clean) & 
                    (instruments['exchange'] == 'NSE')
                ]
                
                if not filtered.empty:
                    token_mapping[symbol_clean] = int(filtered.iloc[0]['instrument_token'])
                    print(f"✅ {symbol_clean}: {int(filtered.iloc[0]['instrument_token'])}")
                else:
                    token_mapping[symbol_clean] = None
                    print(f"❌ {symbol_clean}: Not found")
        
        # Save mapping to file
        with open(output_file, 'w') as f:
            json.dump(token_mapping, f, indent=2)
        
        print(f"💾 Token mapping saved to {output_file}")
        return token_mapping
        
    except Exception as e:
        print(f"❌ Error creating token mapping: {e}")
        return None

def load_token_mapping(mapping_file="token_mapping.json"):
    """Load token mapping from file"""
    try:
        with open(mapping_file, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"⚠️  Token mapping file {mapping_file} not found")
        return None
    except Exception as e:
        print(f"❌ Error loading token mapping: {e}")
        return None

def run_scanner(api_key, access_token, input_file="data\\MCAP-great2500.csv", days=180, output_file="scanner_output_MCAP-great2500_29sep25.csv"):
    """Run scanner mode to analyze multiple symbols from CSV input"""
    try:
        # Read symbols from CSV
        symbols_df = pd.read_csv(input_file)
        
        # Validate required columns
        if 'Symbol' not in symbols_df.columns:
            print(f"❌ Error: 'Symbol' column not found in {input_file}")
            print("Required CSV format: Symbol")
            return
        
        results = []
        analyzer = IntegratedMarketAnalyzer(api_key, access_token)
        
        # Load or create token mapping
        token_mapping = load_token_mapping()
        if token_mapping is None:
            print("🔧 Creating token mapping file...")
            symbols_list = symbols_df['Symbol'].tolist()
            token_mapping = create_token_mapping_file(api_key, access_token, symbols_list)
            if token_mapping is None:
                print("❌ Failed to create token mapping. Exiting...")
                return None
        
        print(f"\n🔍 Starting scanner analysis for {len(symbols_df)} symbols...")
        print("="*70)
        
        for index, row in symbols_df.iterrows():
            symbol = row['Symbol'].strip().upper()
            print(f"\n📊 Analyzing {symbol} ({index+1}/{len(symbols_df)})")
            print("-" * 50)
            
            # Get token from mapping (much faster than API calls)
            token = token_mapping.get(symbol)
            
            # Handle different token types
            if token is None:
                print(f"❌ Symbol {symbol} not found in token mapping")
                results.append({
                    "Symbol": symbol,
                    "Price": 0,
                    "Signal": "ERROR",
                    "Confidence": 0,
                    "Reasons": "Symbol not found in token mapping",
                    "Support/Target": "N/A",
                    "Lunar_Phase": "N/A",
                    "Gann_Levels": "N/A",
                    "Elliott_Pattern": "N/A"
                })
                continue
            else:
                print(f"✅ Using token for {symbol}: {token}")
            
            # Update analyzer for this symbol
            analyzer.symbol = symbol
            analyzer.instrument_token = token
            
            # Fetch market data with error handling
            try:
                if analyzer.fetch_market_data(days=days):
                    signals = analyzer.generate_combined_signals()
                    
                    if signals:
                        sig = signals[0]
                        
                        # Extract Gann levels for support/target
                        gann_levels = []
                        if 'Components' in sig and 'gann_signals' in sig['Components']:
                            for gann_sig in sig['Components']['gann_signals']:
                                gann_levels.append(f"{gann_sig['signal']}: {gann_sig['level']:.2f}")
                        
                        results.append({
                            "Symbol": symbol,
                            "Price": sig['Price'],
                            "Signal": sig['Signal'],
                            "Confidence": sig['Strength'],
                            "Reasons": "; ".join(sig['Reasons']),
                            "Support/Target": "; ".join(gann_levels) if gann_levels else "N/A",
                            "Lunar_Phase": sig.get('Lunar_Phase', 'N/A'),
                            "Gann_Levels": len(sig.get('Components', {}).get('gann_signals', [])),
                            "Elliott_Pattern": "Yes" if sig.get('Components', {}).get('elliott_pattern', False) else "No"
                        })
                        
                        # Print enhanced summary for this symbol
                        wave_type = sig.get('Wave_Type', 'None')
                        quality_score = sig.get('Quality_Score', 0)
                        
                        print(f"✅ {symbol}: {sig['Signal']} (Confidence: {sig['Strength']}/10)")
                        print(f"   Price: ₹{sig['Price']:.2f} | Lunar: {sig.get('Lunar_Phase', 'N/A')}")
                        
                        # Show enhanced quality metrics
                        if wave_type != 'None':
                            print(f"   Elliott: {wave_type} | Quality: {quality_score}/3")
                        
                        if gann_levels:
                            print(f"   Gann: {'; '.join(gann_levels[:2])}")
                        
                    else:
                        results.append({
                            "Symbol": symbol,
                            "Price": analyzer.data['Close'].iloc[-1] if analyzer.data is not None else 0,
                            "Signal": "HOLD",
                            "Confidence": 0,
                            "Reasons": "No significant signals detected",
                            "Support/Target": "N/A",
                            "Lunar_Phase": analyzer.lunar_analyzer.get_lunar_phase(datetime.now()),
                            "Gann_Levels": 0,
                            "Elliott_Pattern": "No"
                        })
                        print(f"⚠️  {symbol}: HOLD (No clear signals)")
                else:
                    print(f"❌ Failed to fetch data for {symbol}")
                    results.append({
                        "Symbol": symbol,
                        "Price": 0,
                        "Signal": "ERROR",
                        "Confidence": 0,
                        "Reasons": "Failed to fetch market data",
                        "Support/Target": "N/A",
                        "Lunar_Phase": "N/A",
                        "Gann_Levels": "N/A",
                        "Elliott_Pattern": "N/A"
                    })
            except Exception as e:
                print(f"❌ Error analyzing {symbol}: {e}")
                results.append({
                    "Symbol": symbol,
                    "Price": 0,
                    "Signal": "ERROR",
                    "Confidence": 0,
                    "Reasons": f"Analysis error: {str(e)[:100]}",
                    "Support/Target": "N/A",
                    "Lunar_Phase": "N/A",
                    "Gann_Levels": "N/A",
                    "Elliott_Pattern": "N/A"
                })
        
        # Export results to CSV
        results_df = pd.DataFrame(results)
        results_df.to_csv(output_file, index=False)
        
        print("\n" + "="*70)
        print(f"✅ Scanner complete! Results saved to {output_file}")
        print("="*70)
        
        # Print summary statistics
        signal_counts = results_df['Signal'].value_counts()
        print("\n📈 SCANNER SUMMARY:")
        print(f"Total symbols analyzed: {len(results_df)}")
        print(f"Successful analyses: {len(results_df[results_df['Signal'] != 'ERROR'])}")
        print("\nSignal distribution:")
        for signal, count in signal_counts.items():
            print(f"  {signal}: {count}")
        
        # Show top signals by confidence
        if len(results_df) > 0:
            top_signals = results_df[results_df['Confidence'] > 0].nlargest(5, 'Confidence')
            if not top_signals.empty:
                print("\n🎯 TOP SIGNALS BY CONFIDENCE:")
                for _, row in top_signals.iterrows():
                    print(f"  {row['Symbol']}: {row['Signal']} (Confidence: {row['Confidence']}/10)")
        
        return results_df
        
    except FileNotFoundError:
        print(f"❌ Error: Input file '{input_file}' not found.")
        print("Please create an input.csv file with a 'Symbol' column containing stock symbols.")
        return None
    except Exception as e:
        print(f"❌ Error running scanner: {e}")
        return None

def main():
    """Enhanced main function with scanner mode support"""
    print("="*60)
    print("ADVANCED MARKET ANALYSIS SYSTEM")
    print("Lunar Cycles + Gann Theory + Elliott Waves")
    print("Powered by Kite Connect API")
    print("="*60)
    print()
    
    # Setup Kite connection
    api_key, access_token = setup_kite_connection()
    
    if not api_key:
        print("Cannot proceed without API key. Exiting...")
        return
    
    if not access_token:
        print("Cannot proceed without access token. Please complete the authentication process.")
        return
    
    # Choose analysis mode
    print("\nAnalysis Mode:")
    print("1. Single Symbol Analysis (Interactive)")
    print("2. Scanner Mode (Batch CSV Processing)")
    
    choice = input("Select mode (1-2): ").strip()
    
    if choice == '2':
        # Scanner mode
        input_file = input("Enter input CSV file path (default: input.csv): ").strip()
        if not input_file:
            input_file = "input.csv"
        
        output_file = input("Enter output CSV file path (default: scanner_output.csv): ").strip()
        if not output_file:
            output_file = "scanner_output.csv"
        
        days = input("Enter analysis period in days (default: 180): ").strip()
        try:
            days = int(days) if days else 180
        except ValueError:
            days = 180
        
        run_scanner(api_key, access_token, input_file, days, output_file)
        return
    
    # Single symbol analysis mode (original functionality)
    symbol, instrument_token = get_instrument_token()
    
    print(f"\nInitializing analysis for {symbol}...")
    
    # Initialize analyzer
    analyzer = IntegratedMarketAnalyzer(
        api_key=api_key,
        access_token=access_token,
        symbol=symbol,
        instrument_token=instrument_token
    )
    
    # Handle custom symbols
    if instrument_token is None:
        print(f"Finding instrument token for {symbol}...")
        found_token = analyzer.data_provider.find_instrument_token(symbol)
        if found_token:
            analyzer.instrument_token = found_token
            print(f"Found instrument token: {found_token}")
        else:
            print(f"Could not find instrument token for {symbol}")
            print("Please check the symbol or use the default NIFTY 50")
            return
    
    # Fetch data
    success = analyzer.fetch_market_data(days=180)
    
    if success:
        print("\n" + "="*60)
        print("GENERATING COMPREHENSIVE ANALYSIS...")
        print("="*60)
        
        # Generate comprehensive report
        analyzer.create_comprehensive_report()
        
        # Offer additional analysis
        print("\nAdditional Analysis Options:")
        print("1. Generate price chart")
        print("2. Export data to CSV")
        print("3. Show detailed Elliott Wave analysis")
        
        choice = input("Select option (1-3) or press Enter to exit: ").strip()
        
        if choice == '1':
            create_price_chart(analyzer)
        elif choice == '2':
            export_data(analyzer)
        elif choice == '3':
            detailed_elliott_analysis(analyzer)
    
    else:
        print("Failed to fetch market data. Please check:")
        print("• Your internet connection")
        print("• API key and access token validity")
        print("• Instrument token correctness")
        print("• Kite Connect subscription status")

def create_price_chart(analyzer):
    """Create and display price chart with analysis overlays"""
    try:
        plt.style.use('dark_background')
        fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(15, 12))
        
        # Price chart with moving averages
        ax1.plot(analyzer.data.index, analyzer.data['Close'], label=f'{analyzer.symbol} Close', color='white', linewidth=1.5)
        ax1.plot(analyzer.data.index, analyzer.data['Close'].rolling(20).mean(), label='20 SMA', color='orange', alpha=0.8)
        ax1.plot(analyzer.data.index, analyzer.data['Close'].rolling(50).mean(), label='50 SMA', color='cyan', alpha=0.8)
        
        # Add Gann levels
        current_price = analyzer.data['Close'].iloc[-1]
        square_levels = analyzer.gann_analyzer.find_gann_squares(current_price)
        
        for level in square_levels[:3]:
            ax1.axhline(y=level, color='yellow', linestyle='--', alpha=0.5, label=f'Gann Square {level:.0f}')
        
        ax1.set_title(f'{analyzer.symbol} - Advanced Technical Analysis', fontsize=14, color='white')
        ax1.set_ylabel('Price (₹)', color='white')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Volume chart
        colors = ['green' if analyzer.data['Close'].iloc[i] > analyzer.data['Open'].iloc[i] else 'red' 
                 for i in range(len(analyzer.data))]
        ax2.bar(analyzer.data.index, analyzer.data['Volume'], color=colors, alpha=0.7)
        ax2.set_title('Volume Analysis', fontsize=12, color='white')
        ax2.set_ylabel('Volume', color='white')
        ax2.grid(True, alpha=0.3)
        
        # RSI and momentum
        delta = analyzer.data['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        ax3.plot(analyzer.data.index, rsi, label='RSI', color='purple')
        ax3.axhline(y=70, color='red', linestyle='--', alpha=0.7, label='Overbought')
        ax3.axhline(y=30, color='green', linestyle='--', alpha=0.7, label='Oversold')
        ax3.fill_between(analyzer.data.index, 30, 70, alpha=0.1, color='gray')
        ax3.set_title('RSI Momentum', fontsize=12, color='white')
        ax3.set_ylabel('RSI', color='white')
        ax3.set_xlabel('Date', color='white')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        ax3.set_ylim(0, 100)
        
        plt.tight_layout()
        plt.show()
        
    except Exception as e:
        print(f"Error creating chart: {e}")
        print("Make sure matplotlib is installed: pip install matplotlib")

def export_data(analyzer):
    """Export analysis data to CSV"""
    try:
        filename = f"{analyzer.symbol}_analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
        
        # Add analysis columns
        export_data = analyzer.data.copy()
        export_data['SMA_20'] = analyzer.data['Close'].rolling(20).mean()
        export_data['SMA_50'] = analyzer.data['Close'].rolling(50).mean()
        
        # Add lunar phases
        lunar_phases = []
        for date in analyzer.data.index:
            lunar_phases.append(analyzer.lunar_analyzer.get_lunar_phase(date))
        export_data['Lunar_Phase'] = lunar_phases
        
        # Export to CSV
        export_data.to_csv(filename)
        print(f"Data exported to: {filename}")
        
    except Exception as e:
        print(f"Error exporting data: {e}")

def detailed_elliott_analysis(analyzer):
    """Show detailed Elliott Wave analysis"""
    print("\n" + "="*50)
    print("DETAILED ELLIOTT WAVE ANALYSIS")
    print("="*50)
    
    elliott_pattern = analyzer.elliott_analyzer.detect_wave_pattern()
    
    if elliott_pattern:
        waves = elliott_pattern['waves']
        analysis = elliott_pattern['analysis']
        
        print(f"Pattern Strength: {elliott_pattern['pattern_strength']}/5")
        print(f"Completion Date: {elliott_pattern['completion_date'].strftime('%Y-%m-%d')}")
        print()
        
        print("Detailed Wave Analysis:")
        for i, (wave_name, wave_data) in enumerate(analysis.items()):
            print(f"\n{wave_name}:")
            print(f"  Price: ₹{wave_data['price']:.2f}")
            print(f"  Date: {wave_data['date'].strftime('%Y-%m-%d')}")
            print(f"  Type: {wave_data['type']}")
            
            if 'move_size' in wave_data:
                print(f"  Movement: {wave_data['direction']} ₹{wave_data['move_size']:.2f}")
                print(f"  Duration: {wave_data['days']} days")
                
                # Calculate move velocity
                if wave_data['days'] > 0:
                    velocity = wave_data['move_size'] / wave_data['days']
                    print(f"  Velocity: ₹{velocity:.2f}/day")
        
        # Fibonacci analysis between waves
        print("\nFibonacci Relationships:")
        if len(waves) >= 5:
            wave1_size = abs(waves[1]['price'] - waves[0]['price'])
            wave3_size = abs(waves[3]['price'] - waves[2]['price'])
            wave5_size = abs(waves[4]['price'] - waves[3]['price'])
            
            print(f"Wave 3 / Wave 1 ratio: {wave3_size/wave1_size:.3f}")
            print(f"Wave 5 / Wave 1 ratio: {wave5_size/wave1_size:.3f}")
            print(f"Wave 5 / Wave 3 ratio: {wave5_size/wave3_size:.3f}")
            
            # Check for common Fibonacci ratios
            ratios_to_check = [0.618, 1.0, 1.618, 2.618]
            print("\nFibonacci Ratio Matches:")
            
            for ratio in ratios_to_check:
                w3_w1_diff = abs((wave3_size/wave1_size) - ratio)
                w5_w1_diff = abs((wave5_size/wave1_size) - ratio)
                
                if w3_w1_diff < 0.1:
                    print(f"  Wave 3/Wave 1 ≈ {ratio} ✓")
                if w5_w1_diff < 0.1:
                    print(f"  Wave 5/Wave 1 ≈ {ratio} ✓")
    else:
        print("No clear Elliott Wave pattern detected.")
        
        # Show recent turning points anyway
        peaks, troughs = analyzer.elliott_analyzer.find_peaks_troughs()
        all_points = sorted((peaks + troughs)[-10:], key=lambda x: x['date'])
        
        print("\nRecent Turning Points:")
        for point in all_points:
            print(f"  {point['date'].strftime('%Y-%m-%d')}: ₹{point['price']:.2f} ({point['type']})")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nAnalysis interrupted by user. Goodbye!")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        print("Please check your Kite Connect setup and try again.")