import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import warnings
import logging
import time
import requests
import json
from pathlib import Path
from typing import Optional, Dict, List, Tuple, Union, Any
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
import os

warnings.filterwarnings('ignore')

# Configure logging with UTF-8 encoding for emoji support
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('market_analyzer.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Fix Windows console encoding for StreamHandler
for handler in logging.getLogger().handlers:
    if isinstance(handler, logging.StreamHandler) and hasattr(handler.stream, 'reconfigure'):
        try:
            handler.stream.reconfigure(encoding='utf-8')
        except Exception:
            # If reconfigure fails, emojis will still appear in print() but not logger
            pass

@dataclass
class AnalysisConfig:
    """Configuration class for market analysis parameters"""
    # API Configuration
    rate_limit_delay: float = 0.5
    instruments_cache_duration: int = 3600
    max_retries: int = 3
    
    # Lunar Analysis
    reference_new_moon: datetime = datetime(2024, 1, 11)
    lunar_cycle_days: float = 29.53
    
    # Gann Analysis
    gann_tolerance_pct: float = 0.01  # 1% tolerance
    gann_lookback_period: int = 20
    
    # Elliott Wave Analysis
    elliott_min_strength: int = 2
    elliott_peak_windows: List[int] = None
    fibonacci_tolerance: float = 0.15  # Sliding scale tolerance (15% = realistic for noisy data)
    fibonacci_curve: str = "linear"  # 'linear' or 'gaussian' decay curve
    
    # Scanner Configuration
    scanner_parallel_workers: int = 5
    scanner_timeout_seconds: int = 30
    default_analysis_days: int = 180
    
    # Signal Scoring Weights (for sigmoid-based scoring)
    # NOTE: Fibonacci is part of Elliott Wave (not separate to avoid double-counting)
    weight_elliott: float = 0.40   # 40% - comprehensive pattern (includes Fibonacci ratios)
    weight_gann: float = 0.30      # 30% - geometric support/resistance levels
    weight_momentum: float = 0.20  # 20% - RSI/trend strength (INCREASED from 10%)
    weight_volume: float = 0.10    # 10% - volume confirmation (NEW - institutional standard)
    
    # Sigmoid parameters
    sigmoid_steepness: float = 0.5  # Controls sigmoid curve steepness
    sigmoid_midpoint: float = 5.0   # Midpoint of sigmoid function
    
    # Relative Strength Analysis
    enable_relative_strength: bool = True
    rs_lookback_period: int = 20
    rs_strong_threshold: float = 0.05  # 5% outperformance
    rs_moderate_threshold: float = 0.02 # 2% outperformance
    
    # Signal Determination Mode
    signal_mode: str = "balanced"  # "balanced" (default) or "aggressive"
    
    # Balanced mode thresholds (recommended for most traders)
    rs_moderate_override: float = 1.5   # RS threshold for guidance (75th percentile)
    technical_conflict_limit: float = -3.0  # Max acceptable technical opposition
    balanced_buy_threshold: float = 1.0  # Voting threshold for buy
    balanced_sell_threshold: float = -1.0  # Voting threshold for sell
    
    # Aggressive mode thresholds (for pure momentum traders)
    rs_strong_override: float = 2.0  # RS threshold for override (95th percentile)
    overwhelming_opposition: float = 8.0  # Threshold to overcome RS override
    aggressive_buy_threshold: float = 0.8  # Lower voting threshold
    aggressive_sell_threshold: float = -0.8  # Lower voting threshold
    
    # Probabilistic Targets
    fib_extensions: List[float] = None  # Will be set in __post_init__
    enable_probabilistic_targets: bool = True
    
    # Cycle Projection
    enable_cycle_projection: bool = True
    cycle_fib_multipliers: List[float] = None  # Will be set in __post_init__
    
    # NIFTY 50 instrument for relative strength
    nifty50_instrument_token: int = 256265
    
    def __post_init__(self):
        if self.elliott_peak_windows is None:
            self.elliott_peak_windows = [5, 10, 20]
        
        if self.fib_extensions is None:
            # Standard Fibonacci extension levels
            self.fib_extensions = [1.0, 1.272, 1.618, 2.0, 2.618]
        
        if self.cycle_fib_multipliers is None:
            # Time-based Fibonacci multipliers for cycle projection
            self.cycle_fib_multipliers = [1.0, 1.272, 1.618, 2.0]

# Global configuration instance
config = AnalysisConfig()

class KiteDataProvider:
    """Handles Kite Connect API integration for market data"""
    
    def __init__(self, api_key: str, access_token: Optional[str] = None):
        self.api_key = api_key
        self.access_token = access_token
        self.kite: Optional[KiteConnect] = None
        self.instruments_cache: Optional[pd.DataFrame] = None
        self.last_instruments_fetch: Optional[float] = None
        self.instruments_cache_duration = config.instruments_cache_duration
        self.rate_limit_delay = config.rate_limit_delay
        self.last_request_time = 0.0  # For rate limiting
        self.min_request_interval = 0.35  # 350ms between requests (like TimelessScanner)
        self.max_retries = 3  # Retry logic
        self.initialize_connection()
    
    def _rate_limit(self) -> None:
        """Enforce rate limiting for Kite API (like TimelessScanner)"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            sleep_time = self.min_request_interval - time_since_last
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def _api_call_with_retry(self, func, *args, **kwargs):
        """
        Execute API call with retry logic and exponential backoff.
        
        Args:
            func: API function to call
            *args, **kwargs: Arguments to pass to function
            
        Returns:
            Result of API call or None on failure
        """
        for attempt in range(self.max_retries):
            try:
                self._rate_limit()  # Enforce rate limiting before each call
                return func(*args, **kwargs)
            except Exception as e:
                error_str = str(e).lower()
                # Check for rate limit errors
                if "too many requests" in error_str or "rate limit" in error_str:
                    if attempt < self.max_retries - 1:
                        # Exponential backoff: 1s, 2s, 3s
                        retry_delay = (attempt + 1) * 1.0
                        logger.warning(f"Rate limit hit, retrying in {retry_delay}s (attempt {attempt + 1}/{self.max_retries})")
                        time.sleep(retry_delay)
                        continue
                    else:
                        logger.error(f"Max retries reached for rate limit error: {e}")
                        raise
                else:
                    # Non-rate-limit error, raise immediately
                    raise
        return None
    
    def initialize_connection(self) -> None:
        """Initialize Kite Connect session"""
        try:
            self.kite = KiteConnect(api_key=self.api_key)
            if self.access_token:
                self.kite.set_access_token(self.access_token)
                logger.info("Kite Connect initialized successfully!")
            else:
                logger.warning("Access token required. Please complete the login process.")
        except Exception as e:
            logger.error(f"Error initializing Kite Connect: {e}", exc_info=True)
    
    def get_login_url(self) -> Optional[str]:
        """Get login URL for authentication"""
        if self.kite:
            return self.kite.login_url()
        return None
    
    def set_access_token(self, request_token: str, api_secret: str) -> Optional[str]:
        """Generate and set access token"""
        try:
            data = self.kite.generate_session(request_token, api_secret=api_secret)
            self.access_token = data["access_token"]
            self.kite.set_access_token(self.access_token)
            logger.info(f"Access token generated: {self.access_token}")
            return self.access_token
        except Exception as e:
            logger.error(f"Error generating access token: {e}", exc_info=True)
            return None
    
    def fetch_historical_data(self, instrument_token: Union[int, str], 
                             from_date: datetime, to_date: datetime, 
                             interval: str = "day") -> Optional[pd.DataFrame]:
        """Fetch historical data from Kite Connect with rate limiting and retry logic"""
        try:
            if not self.access_token:
                logger.warning("Please set access token first")
                return None
            
            # Use retry logic with exponential backoff
            data = self._api_call_with_retry(
                self.kite.historical_data,
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            if not data:
                logger.warning(f"No data returned for instrument {instrument_token}")
                return None
            
            # Convert to DataFrame
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            
            # Rename columns to match standard format
            df.rename(columns={
                'open': 'Open',
                'high': 'High', 
                'low': 'Low',
                'close': 'Close',
                'volume': 'Volume'
            }, inplace=True)
            
            logger.info(f"Fetched {len(df)} records for instrument {instrument_token}")
            return df
        except Exception as e:
            logger.error(f"Error fetching historical data for {instrument_token}: {e}", exc_info=True)
            return None
    
    def get_instruments(self, force_refresh: bool = False) -> Optional[pd.DataFrame]:
        """Get all available instruments with caching and retry logic"""
        try:
            # Check if cache is valid
            current_time = time.time()
            if (not force_refresh and 
                self.instruments_cache is not None and 
                self.last_instruments_fetch is not None and 
                (current_time - self.last_instruments_fetch) < self.instruments_cache_duration):
                logger.debug("Using cached instruments data")
                return self.instruments_cache
            
            if not self.access_token:
                logger.warning("Please set access token first")
                return None
            
            # Use retry logic with exponential backoff
            instruments = self._api_call_with_retry(self.kite.instruments)
            
            if instruments:
                self.instruments_cache = pd.DataFrame(instruments)
                self.last_instruments_fetch = current_time
                
                logger.info(f"Fetched {len(self.instruments_cache)} instruments from Kite Connect")
                print(f"✅ Fetched {len(self.instruments_cache)} instruments")
                return self.instruments_cache
            else:
                logger.warning("No instruments data returned")
                return None
            
        except Exception as e:
            logger.error(f"Error fetching instruments: {e}", exc_info=True)
            # Try to use cached data if available
            if self.instruments_cache is not None:
                logger.warning("Using stale cached instruments data after error")
                return self.instruments_cache
            return None
    
    def get_nse_instruments_fallback(self) -> Optional[pd.DataFrame]:
        """Get NSE instruments from public API as fallback"""
        try:
            # NSE public API for instruments - with proper headers
            url = "https://archives.nseindia.com/content/equities/EQUITY_L.csv"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Connection': 'keep-alive',
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            
            if response.status_code == 200:
                # Parse CSV content
                lines = response.text.strip().split('\n')
                instruments = []
                
                for line in lines[1:]:  # Skip header
                    parts = line.split(',')
                    if len(parts) >= 2:
                        symbol = parts[0].strip().strip('"')
                        name = parts[1].strip().strip('"')
                        # Create a mock instrument token (this won't work for actual trading)
                        # but helps identify valid symbols
                        instruments.append({
                            'tradingsymbol': symbol,
                            'name': name,
                            'exchange': 'NSE',
                            'instrument_token': f"NSE_{symbol}",  # Mock token
                            'instrument_type': 'EQ'
                        })
                
                df = pd.DataFrame(instruments)
                logger.info(f"Fetched {len(df)} NSE instruments from public API")
                print(f"✅ Fetched {len(df)} NSE instruments from public API")
                return df
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error fetching NSE instruments fallback: {e}")
            return None
        except Exception as e:
            logger.error(f"Error fetching NSE instruments fallback: {e}", exc_info=True)
            return None
    
    def find_instrument_token(self, trading_symbol: str, 
                             exchange: str = "NSE") -> Optional[Union[int, str]]:
        """Find instrument token for a given symbol with improved error handling"""
        try:
            # First try Kite Connect instruments
            instruments = self.get_instruments()
            
            if instruments is not None:
                filtered = instruments[
                    (instruments['tradingsymbol'] == trading_symbol) & 
                    (instruments['exchange'] == exchange)
                ]
                if not filtered.empty:
                    token = filtered.iloc[0]['instrument_token']
                    logger.info(f"Found token {token} for {trading_symbol}")
                    return token
            
            # If Kite Connect fails, try NSE fallback for validation
            if exchange == "NSE":
                nse_instruments = self.get_nse_instruments_fallback()
                if nse_instruments is not None:
                    filtered = nse_instruments[
                        nse_instruments['tradingsymbol'] == trading_symbol
                    ]
                    if not filtered.empty:
                        # Symbol exists on NSE but we need to find the real token
                        logger.warning(f"Symbol {trading_symbol} found in NSE but needs manual token lookup")
                        return f"NSE_VALID_{trading_symbol}"
            
            logger.warning(f"Could not find instrument token for {trading_symbol}")
            return None
            
        except Exception as e:
            logger.error(f"Error finding instrument token for {trading_symbol}: {e}", exc_info=True)
            return None

def normalize_datetime(date_input: Union[str, datetime, pd.Timestamp]) -> datetime:
    """
    Standardize datetime handling across the application.
    Ensures all datetimes are timezone-naive for consistent calculations.
    
    Args:
        date_input: Date as string, datetime, or pandas Timestamp
        
    Returns:
        Normalized timezone-naive datetime object
        
    Raises:
        ValueError: If date format is invalid
    """
    result = None
    
    if isinstance(date_input, str):
        try:
            result = pd.to_datetime(date_input).to_pydatetime()
        except Exception as e:
            raise ValueError(f"Invalid date string format: {date_input}") from e
    elif isinstance(date_input, pd.Timestamp):
        result = date_input.to_pydatetime()
    elif isinstance(date_input, datetime):
        result = date_input
    elif hasattr(date_input, 'date'):
        # Handle datetime.date objects
        result = datetime.combine(date_input.date(), datetime.min.time())
    else:
        raise ValueError(f"Unsupported date type: {type(date_input)}")
    
    # Remove timezone info to make it timezone-naive if present
    if result.tzinfo is not None:
        result = result.replace(tzinfo=None)
    
    return result

def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """
    Safely perform division with zero-check.
    
    Args:
        numerator: Numerator value
        denominator: Denominator value
        default: Value to return if denominator is zero
        
    Returns:
        Result of division or default value
    """
    if denominator == 0 or pd.isna(denominator) or pd.isna(numerator):
        return default
    return numerator / denominator

def sigmoid_normalize(raw_score: float, steepness: float = 0.5, 
                     midpoint: float = 5.0, scale: float = 10.0) -> float:
    """
    Apply sigmoid normalization to convert raw scores to bounded confidence.
    
    The sigmoid function maps unbounded input to a bounded range [0, scale],
    with smooth transitions and natural suppression of weak signals.
    
    Args:
        raw_score: Unbounded raw score from weighted components
        steepness: Controls curve steepness (higher = sharper transitions)
        midpoint: Center point of sigmoid curve
        scale: Maximum output value (typically 10 for 0-10 confidence)
        
    Returns:
        Normalized score in range [0, scale]
        
    Formula:
        score = scale / (1 + exp(-steepness * (raw_score - midpoint)))
        
    Example:
        >>> sigmoid_normalize(5.0)  # At midpoint
        5.0
        >>> sigmoid_normalize(10.0)  # High raw score
        9.3
        >>> sigmoid_normalize(0.0)  # Low raw score
        0.7
    """
    try:
        exponent = -steepness * (raw_score - midpoint)
        # Prevent overflow for very large exponents
        if exponent > 100:
            return 0.0
        elif exponent < -100:
            return scale
        
        normalized = scale / (1.0 + np.exp(exponent))
        return round(normalized, 1)
    except Exception as e:
        logger.error(f"Error in sigmoid normalization: {e}")
        # Fallback to simple clipping
        return min(max(raw_score, 0.0), scale)

def fib_match_score(ratio: float, target: float, 
                   tolerance: Optional[float] = None,
                   curve: Optional[str] = None) -> float:
    """
    Calculate Fibonacci match score with sliding scale (realistic for noisy financial data).
    
    Unlike binary thresholds, this provides smooth degradation:
    - Perfect match → full score (2.0)
    - Close match → partial credit (gradual decay)
    - Far match → zero score
    
    Args:
        ratio: Observed wave ratio (e.g., Wave3/Wave1 = 1.70)
        target: Target Fibonacci ratio (e.g., 1.618, 1.0, 0.618)
        tolerance: Maximum acceptable deviation (default: from config, typically 0.15)
        curve: Decay curve type - 'linear' or 'gaussian' (default: from config)
        
    Returns:
        Score from 0.0 to 2.0 based on proximity to target
        
    Examples:
        >>> fib_match_score(1.618, 1.618, 0.15)  # Perfect match
        2.0
        >>> fib_match_score(1.70, 1.618, 0.15)   # Close (diff=0.082)
        0.91
        >>> fib_match_score(1.54, 1.618, 0.15)   # Pretty close (diff=0.078)
        0.96
        >>> fib_match_score(1.80, 1.618, 0.15)   # Too far (diff=0.182)
        0.0
        
    Rationale:
        Financial data is noisy. A ratio of 1.54 vs 1.55 is not meaningfully different,
        yet binary thresholds would score them as 0 vs 2. Sliding scale is more realistic.
    """
    # Use config defaults if not specified
    if tolerance is None:
        tolerance = config.fibonacci_tolerance
    if curve is None:
        curve = config.fibonacci_curve
    
    # Calculate deviation from target
    diff = abs(ratio - target)
    
    # Outside tolerance window → zero score
    if diff >= tolerance:
        return 0.0
    
    # Calculate proximity factor (1.0 at exact match, 0.0 at tolerance edge)
    normalized_diff = diff / tolerance
    
    if curve == 'gaussian':
        # Gaussian-like decay: more forgiving for small deviations, stricter at edges
        # Uses exp(-3x²) which gives ~0.05 at edge, ~1.0 at center
        proximity_factor = np.exp(-3.0 * normalized_diff**2)
    else:  # 'linear' (default)
        # Linear decay: simple and predictable
        proximity_factor = 1.0 - normalized_diff
    
    # Return score (max 2.0 points per match)
    return 2.0 * proximity_factor

class LunarCycleAnalyzer:
    """Analyzes market movements based on lunar cycles"""
    
    def __init__(self):
        # Known new moon date as reference (January 11, 2024)
        self.reference_new_moon = config.reference_new_moon
        self.lunar_cycle_days = config.lunar_cycle_days
        
    def get_lunar_phase(self, date: Union[str, datetime, pd.Timestamp]) -> str:
        """
        Calculate lunar phase for given date.
        
        Args:
            date: Date to calculate phase for
            
        Returns:
            Lunar phase as string (New Moon, Waxing, Full Moon, or Waning)
        """
        # Normalize datetime input
        date = normalize_datetime(date)
        
        days_since_ref = (date - self.reference_new_moon).days
        cycle_position = (days_since_ref % self.lunar_cycle_days) / self.lunar_cycle_days
        
        if cycle_position < 0.125 or cycle_position >= 0.875:
            return "New Moon"
        elif 0.125 <= cycle_position < 0.375:
            return "Waxing"
        elif 0.375 <= cycle_position < 0.625:
            return "Full Moon"
        else:
            return "Waning"
    
    def is_significant_lunar_period(self, date: Union[str, datetime, pd.Timestamp]) -> bool:
        """
        Check if date falls during significant lunar periods.
        
        Args:
            date: Date to check
            
        Returns:
            True if New Moon or Full Moon, False otherwise
        """
        phase = self.get_lunar_phase(date)
        return phase in ["New Moon", "Full Moon"]
    
    def get_lunar_influence_strength(self, date: Union[str, datetime, pd.Timestamp]) -> float:
        """
        Calculate enhanced lunar influence strength with timing precision.
        
        Args:
            date: Date to calculate influence for
            
        Returns:
            Influence strength (0-2.5)
        """
        # Normalize the date first
        date = normalize_datetime(date)
        phase = self.get_lunar_phase(date)
        
        # Calculate days from significant lunar events
        days_from_new_moon = None
        days_from_full_moon = None
        
        # Find nearest significant lunar events
        for i in range(-15, 16):  # Check ±15 days
            check_date = date + timedelta(days=i)
            check_phase = self.get_lunar_phase(check_date)
            if check_phase == "New Moon" and days_from_new_moon is None:
                days_from_new_moon = abs(i)
            if check_phase == "Full Moon" and days_from_full_moon is None:
                days_from_full_moon = abs(i)
        
        # ENHANCED scoring based on proximity to significant events
        if phase in ["New Moon", "Full Moon"]:
            # Exact new/full moon = maximum strength
            return 2.5  # INCREASED from 2.0
        elif phase == "Waning":
            # Check proximity to full moon
            if days_from_full_moon is not None and days_from_full_moon <= 1:
                return 2.0  # INCREASED: Very strong waning within 1 day of full moon
            elif days_from_full_moon is not None and days_from_full_moon <= 2:
                return 1.8  # INCREASED: Strong waning near full moon
            elif days_from_new_moon is not None and days_from_new_moon <= 2:
                return 0.6  # Slightly increased: Weak waning near new moon
            else:
                return 1.0  # INCREASED: Standard waning
        elif phase == "Waxing":
            # Check proximity to new moon
            if days_from_new_moon is not None and days_from_new_moon <= 1:
                return 2.0  # INCREASED: Very strong waxing within 1 day of new moon
            elif days_from_new_moon is not None and days_from_new_moon <= 2:
                return 1.8  # INCREASED: Strong waxing near new moon
            elif days_from_full_moon is not None and days_from_full_moon <= 2:
                return 0.6  # Slightly increased: Weak waxing near full moon
            else:
                return 1.0  # INCREASED: Standard waxing
        else:
            return 0.4  # Slightly increased: Other phases

class GannAnalyzer:
    """Implements Gann Theory analysis with Indian market adaptations"""
    
    def __init__(self, data):
        self.data = data
        self.gann_angles = {
            '1x1': 1.0,    # 1 point price per 1 day
            '1x2': 0.5,    # 1 point price per 2 days
            '2x1': 2.0,    # 2 points price per 1 day
            '1x4': 0.25,   # 1 point price per 4 days
            '4x1': 4.0     # 4 points price per 1 day
        }
    
    def find_significant_pivots(self, lookback=20):
        """Find significant pivot points in price data"""
        pivots = []
        
        for i in range(lookback, len(self.data) - lookback):
            current_high = self.data.iloc[i]['High']
            current_low = self.data.iloc[i]['Low']
            
            # Check for swing high
            is_swing_high = True
            for j in range(i - lookback, i + lookback + 1):
                if j != i and self.data.iloc[j]['High'] >= current_high:
                    is_swing_high = False
                    break
            
            # Check for swing low  
            is_swing_low = True
            for j in range(i - lookback, i + lookback + 1):
                if j != i and self.data.iloc[j]['Low'] <= current_low:
                    is_swing_low = False
                    break
            
            if is_swing_high:
                pivots.append({
                    'date': self.data.index[i],
                    'price': current_high,
                    'type': 'high'
                })
            elif is_swing_low:
                pivots.append({
                    'date': self.data.index[i], 
                    'price': current_low,
                    'type': 'low'
                })
        
        return pivots
    
    def calculate_gann_levels(self, pivot_price: float, pivot_date: Union[str, datetime, pd.Timestamp], 
                             current_date: Union[str, datetime, pd.Timestamp], 
                             angle: str = '1x1') -> Tuple[float, float]:
        """
        Calculate Gann levels from a pivot point.
        
        Args:
            pivot_price: Price at pivot point
            pivot_date: Date of pivot
            current_date: Current date for calculation
            angle: Gann angle to use (default: '1x1')
            
        Returns:
            Tuple of (upper_level, lower_level)
        """
        try:
            # Normalize dates to ensure timezone-naive comparison
            current_date = normalize_datetime(current_date)
            pivot_date = normalize_datetime(pivot_date)
            
            days_diff = (current_date - pivot_date).days
            if days_diff <= 0:
                return pivot_price, pivot_price
            
            angle_value = self.gann_angles.get(angle, 1.0)
            price_movement = days_diff * angle_value
            
            return pivot_price + price_movement, pivot_price - price_movement
        except Exception as e:
            logger.error(f"Error calculating Gann levels: {e}", exc_info=True)
            return pivot_price, pivot_price
    
    def find_gann_squares(self, price):
        """Find Gann square levels"""
        sqrt_price = np.sqrt(price)
        lower_square = (int(sqrt_price)) ** 2
        upper_square = (int(sqrt_price) + 1) ** 2
        
        # Calculate additional square levels
        square_levels = []
        base_sqrt = int(sqrt_price)
        
        for i in range(-2, 3):
            level = (base_sqrt + i) ** 2
            if level > 0:
                square_levels.append(level)
        
        return sorted(square_levels)
    
    def get_gann_signals(self, current_price=None):
        """Generate Gann-based trading signals with reduced scoring"""
        if current_price is None:
            current_price = self.data['Close'].iloc[-1]
        
        signals = []
        pivots = self.find_significant_pivots()
        
        # Check Gann square levels with STRICTER tolerance
        square_levels = self.find_gann_squares(current_price)
        tolerance = current_price * 0.01  # REDUCED from 1.5% to 1% tolerance
        
        for level in square_levels:
            if abs(current_price - level) <= tolerance:
                signal_type = "Support" if level < current_price else "Resistance"
                # REDUCED strength scoring
                distance_ratio = abs(current_price - level) / tolerance
                if distance_ratio <= 0.3:  # Very close
                    strength = 1.5
                elif distance_ratio <= 0.6:  # Close
                    strength = 1.0
                else:  # Within tolerance but not close
                    strength = 0.5
                
                signals.append({
                    'type': 'Gann Square',
                    'signal': signal_type,
                    'level': level,
                    'strength': strength
                })
        
        # Check Gann fan levels from recent pivots with REDUCED scoring
        if len(pivots) >= 2:
            latest_pivot = pivots[-1]
            current_date = self.data.index[-1]
            
            upper_level, lower_level = self.calculate_gann_levels(
                latest_pivot['price'], 
                latest_pivot['date'], 
                current_date
            )
            
            if abs(current_price - upper_level) <= tolerance:
                signals.append({
                    'type': 'Gann Fan',
                    'signal': 'Resistance',
                    'level': upper_level,
                    'strength': 1.0  # REDUCED from 2 to 1
                })
            elif abs(current_price - lower_level) <= tolerance:
                signals.append({
                    'type': 'Gann Fan', 
                    'signal': 'Support',
                    'level': lower_level,
                    'strength': 1.0  # REDUCED from 2 to 1
                })
        
        return signals

class ElliottWaveAnalyzer:
    """Enhanced Elliott Wave Theory analysis for Indian markets"""
    
    def __init__(self, data):
        self.data = data
        self.fibonacci_ratios = [0.236, 0.382, 0.5, 0.618, 0.786, 1.0, 1.272, 1.618, 2.618]
        self.wave_degrees = {
            'Supercycle': {'min_days': 365, 'description': 'Multi-year waves'},
            'Cycle': {'min_days': 180, 'description': 'Annual waves'},
            'Primary': {'min_days': 90, 'description': 'Quarterly waves'},
            'Intermediate': {'min_days': 30, 'description': 'Monthly waves'},
            'Minor': {'min_days': 7, 'description': 'Weekly waves'},
            'Minute': {'min_days': 1, 'description': 'Daily waves'}
        }
    
    def enhanced_peak_trough_detection(self, data, min_strength=3):
        """Enhanced peak/trough detection with strength scoring"""
        peaks = []
        troughs = []
        
        # Use multiple timeframe analysis
        for window in [5, 10, 20]:
            # Calculate local extrema
            highs = data['High'].rolling(window=window*2+1, center=True).max()
            lows = data['Low'].rolling(window=window*2+1, center=True).min()
            
            for i in range(window, len(data) - window):
                # Peak detection with strength scoring
                if data.iloc[i]['High'] == highs.iloc[i]:
                    strength = self.calculate_extrema_strength(data, i, 'peak', window)
                    if strength >= min_strength:
                        peaks.append({
                            'index': i,
                            'price': data.iloc[i]['High'],
                            'date': data.index[i],
                            'strength': strength,
                            'timeframe': window,
                            'type': 'Peak'
                        })
                
                # Trough detection with strength scoring
                if data.iloc[i]['Low'] == lows.iloc[i]:
                    strength = self.calculate_extrema_strength(data, i, 'trough', window)
                    if strength >= min_strength:
                        troughs.append({
                            'index': i,
                            'price': data.iloc[i]['Low'],
                            'date': data.index[i],
                            'strength': strength,
                            'timeframe': window,
                            'type': 'Trough'
                        })
        
        # Remove duplicates and rank by strength
        peaks = self.deduplicate_extrema(peaks)
        troughs = self.deduplicate_extrema(troughs)
        
        return peaks, troughs
    
    def calculate_extrema_strength(self, data, index, extrema_type, window):
        """Calculate strength of peak/trough based on multiple factors"""
        strength = 0
        price = data.iloc[index]['High'] if extrema_type == 'peak' else data.iloc[index]['Low']
        
        # Volume confirmation
        volume_avg = data['Volume'].iloc[index-window:index+window].mean()
        if data.iloc[index]['Volume'] > volume_avg * 1.2:
            strength += 1
        
        # Price significance
        price_range = data.iloc[index-window:index+window]
        if extrema_type == 'peak':
            if price > price_range['High'].quantile(0.9):
                strength += 2
        else:
            if price < price_range['Low'].quantile(0.1):
                strength += 2
        
        # Time at extreme
        consecutive_bars = 1
        if extrema_type == 'peak':
            for j in range(1, min(5, window)):
                if (index + j < len(data) and 
                    data.iloc[index]['High'] >= data.iloc[index + j]['High']):
                    consecutive_bars += 1
        else:
            for j in range(1, min(5, window)):
                if (index + j < len(data) and 
                    data.iloc[index]['Low'] <= data.iloc[index + j]['Low']):
                    consecutive_bars += 1
        
        strength += min(consecutive_bars, 3)
        
        return strength
    
    def deduplicate_extrema(self, extrema_list):
        """Remove duplicate extrema and rank by strength"""
        if not extrema_list:
            return []
        
        # Sort by index
        extrema_list.sort(key=lambda x: x['index'])
        
        # Remove duplicates (within 3 bars)
        deduplicated = []
        for extrema in extrema_list:
            is_duplicate = False
            for existing in deduplicated:
                if abs(extrema['index'] - existing['index']) <= 3:
                    # Keep the stronger one
                    if extrema['strength'] > existing['strength']:
                        deduplicated.remove(existing)
                        deduplicated.append(extrema)
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                deduplicated.append(extrema)
        
        # Sort by strength (highest first)
        deduplicated.sort(key=lambda x: x['strength'], reverse=True)
        
        return deduplicated
    
    def find_peaks_troughs(self, window=5):
        """Legacy method - now uses enhanced detection"""
        peaks, troughs = self.enhanced_peak_trough_detection(self.data, min_strength=2)
        
        # Convert to legacy format for backward compatibility
        legacy_peaks = []
        legacy_troughs = []
        
        for peak in peaks:
            legacy_peaks.append({
                'date': peak['date'],
                'price': peak['price'],
                'type': peak['type'],
                'index': peak['index'],
                'strength': peak.get('strength', 0)
            })
        
        for trough in troughs:
            legacy_troughs.append({
                'date': trough['date'],
                'price': trough['price'],
                'type': trough['type'],
                'index': trough['index'],
                'strength': trough.get('strength', 0)
            })
        
        return legacy_peaks, legacy_troughs
    
    def calculate_fibonacci_levels(self, high_price, low_price, trend_direction='up'):
        """Calculate Fibonacci retracement/extension levels"""
        diff = abs(high_price - low_price)
        levels = {}
        
        if trend_direction == 'up':
            for ratio in self.fibonacci_ratios:
                levels[f'{ratio:.3f}'] = high_price - (diff * ratio)
        else:
            for ratio in self.fibonacci_ratios:
                levels[f'{ratio:.3f}'] = low_price + (diff * ratio)
        
        return levels
    
    def validate_elliott_rules(self, waves):
        """Enhanced Elliott Wave rule validation"""
        if len(waves) < 5:
            return False
        
        try:
            validation_score = 0
            max_score = 5
            
            # Rule 1: Wave 2 cannot retrace more than 100% of Wave 1
            wave1_range = abs(waves[1]['price'] - waves[0]['price'])
            wave2_retrace = abs(waves[2]['price'] - waves[1]['price'])
            if wave2_retrace <= wave1_range:
                validation_score += 1
            
            # Rule 2: Wave 3 cannot be the shortest of waves 1, 3, and 5
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave3_length = abs(waves[3]['price'] - waves[2]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            if not (wave3_length < wave1_length and wave3_length < wave5_length):
                validation_score += 1
            
            # Rule 3: Wave 4 cannot overlap with Wave 1 price territory
            wave1_high = max(waves[0]['price'], waves[1]['price'])
            wave1_low = min(waves[0]['price'], waves[1]['price'])
            wave4_price = waves[3]['price']
            
            if not (wave1_low <= wave4_price <= wave1_high):
                validation_score += 1
            
            # Rule 4: Check Fibonacci relationships
            if self.check_fibonacci_relationships(waves):
                validation_score += 1
            
            # Rule 5: Check wave alternation
            if self.check_wave_alternation(waves):
                validation_score += 1
            
            # Return True if at least 4 out of 5 rules pass
            return validation_score >= 4
            
        except Exception as e:
            print(f"Error in Elliott Wave validation: {e}")
            return False
    
    def check_fibonacci_relationships(self, waves):
        """Check if wave relationships follow Fibonacci ratios"""
        try:
            if len(waves) < 5:
                return False
            
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave3_length = abs(waves[3]['price'] - waves[2]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            # Check if Wave 3 is 1.618 times Wave 1 (common relationship)
            w3_w1_ratio = wave3_length / wave1_length if wave1_length > 0 else 0
            if 1.5 <= w3_w1_ratio <= 1.8:
                return True
            
            # Check if Wave 5 equals Wave 1
            w5_w1_ratio = wave5_length / wave1_length if wave1_length > 0 else 0
            if 0.8 <= w5_w1_ratio <= 1.2:
                return True
            
            # Check if Wave 5 is 0.618 times Wave 3
            w5_w3_ratio = wave5_length / wave3_length if wave3_length > 0 else 0
            if 0.5 <= w5_w3_ratio <= 0.7:
                return True
            
            return False
            
        except:
            return False
    
    def check_wave_alternation(self, waves):
        """Check if waves alternate between peaks and troughs properly"""
        try:
            if len(waves) < 5:
                return False
            
            # Check that we have alternating peaks and troughs
            types = [wave['type'] for wave in waves[:5]]
            
            # Should start with either peak or trough and alternate
            if types[0] == types[1] or types[1] == types[2] or types[2] == types[3] or types[3] == types[4]:
                return False
            
            return True
            
        except:
            return False
    
    def classify_wave_degree(self, waves):
        """Classify the degree of Elliott Wave pattern"""
        try:
            if len(waves) < 2:
                return 'Unknown'
            
            # Calculate total duration
            start_date = waves[0]['date']
            end_date = waves[-1]['date']
            duration_days = (end_date - start_date).days
            
            # Classify based on duration
            for degree, info in self.wave_degrees.items():
                if duration_days >= info['min_days']:
                    return degree
            
            return 'Minute'
            
        except:
            return 'Unknown'
    
    def identify_wave_type(self, waves):
        """Identify if the pattern is impulse or corrective"""
        try:
            if len(waves) < 5:
                return 'Incomplete'
            
            # Check if it follows impulse pattern (5 waves)
            if len(waves) == 5:
                # Check if it's trending in one direction overall
                start_price = waves[0]['price']
                end_price = waves[4]['price']
                
                # If overall direction is up and waves 1,3,5 are up movements
                if end_price > start_price:
                    return 'Impulse (Up)'
                elif end_price < start_price:
                    return 'Impulse (Down)'
            
            # Check for corrective patterns (3 waves)
            elif len(waves) == 3:
                return 'Corrective'
            
            return 'Complex'
            
        except:
            return 'Unknown'
    
    def detect_wave_pattern(self):
        """Enhanced Elliott Wave pattern detection with multiple pattern types"""
        peaks, troughs = self.enhanced_peak_trough_detection(self.data, min_strength=2)
        
        # Combine and sort all turning points
        all_points = peaks + troughs
        all_points.sort(key=lambda x: x['index'])
        
        if len(all_points) < 5:
            return None
        
        best_pattern = None
        best_score = 0
        
        # Look for 5-wave impulse patterns
        for i in range(len(all_points) - 4):
            wave_candidate = all_points[i:i+5]
            
            # Check if it alternates between peaks and troughs
            types = [point['type'] for point in wave_candidate]
            if len(set(types)) == 2:  # Should have both peaks and troughs
                
                # Validate Elliott Wave rules
                if self.validate_elliott_rules(wave_candidate):
                    
                    # Calculate wave characteristics
                    wave_analysis = self.analyze_wave_structure(wave_candidate)
                    
                    # Calculate enhanced pattern strength
                    pattern_strength = self.calculate_enhanced_pattern_strength(wave_candidate)
                    
                    # Get additional classifications
                    wave_degree = self.classify_wave_degree(wave_candidate)
                    wave_type = self.identify_wave_type(wave_candidate)
                    
                    # Calculate overall score
                    overall_score = pattern_strength + self.calculate_confidence_score(wave_candidate)
                    
                    if overall_score > best_score:
                        best_pattern = {
                            'waves': wave_candidate,
                            'analysis': wave_analysis,
                            'completion_date': wave_candidate[-1]['date'],
                            'pattern_strength': pattern_strength,
                            'wave_degree': wave_degree,
                            'wave_type': wave_type,
                            'confidence_score': overall_score,
                            'fibonacci_analysis': self.analyze_fibonacci_relationships(wave_candidate)
                        }
                        best_score = overall_score
        
        # If no 5-wave pattern found, look for 3-wave corrective patterns
        if best_pattern is None:
            for i in range(len(all_points) - 2):
                wave_candidate = all_points[i:i+3]
                
                # Check for corrective pattern characteristics
                if self.is_corrective_pattern(wave_candidate):
                    wave_analysis = self.analyze_wave_structure(wave_candidate)
                    
                    best_pattern = {
                        'waves': wave_candidate,
                        'analysis': wave_analysis,
                        'completion_date': wave_candidate[-1]['date'],
                        'pattern_strength': 2,  # Lower strength for corrective patterns
                        'wave_degree': self.classify_wave_degree(wave_candidate),
                        'wave_type': 'Corrective',
                        'confidence_score': 3,
                        'fibonacci_analysis': self.analyze_fibonacci_relationships(wave_candidate)
                    }
                    break
        
        return best_pattern
    
    def is_corrective_pattern(self, waves):
        """Check if a 3-wave pattern is a valid corrective pattern"""
        try:
            if len(waves) != 3:
                return False
            
            # Check alternation
            types = [wave['type'] for wave in waves]
            if len(set(types)) != 2:
                return False
            
            # Check if middle wave retraces significantly
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave2_length = abs(waves[2]['price'] - waves[1]['price'])
            
            # Wave 2 should retrace at least 38.2% of wave 1
            retracement = wave2_length / wave1_length if wave1_length > 0 else 0
            return retracement >= 0.382
            
        except:
            return False
    
    def calculate_enhanced_pattern_strength(self, waves):
        """Calculate enhanced pattern strength with multiple factors - FIXED SCORING"""
        strength = 0
        
        try:
            # Base strength for having 5 waves (REDUCED from 3 to 1.5)
            strength += 1.5
            
            # Volume confirmation (REDUCED from 0-2 to 0-1)
            volume_strength = self.calculate_volume_strength(waves) * 0.5
            strength += volume_strength
            
            # Fibonacci relationship strength (REDUCED from 0-3 to 0-1.5)
            fib_strength = self.calculate_fibonacci_strength(waves) * 0.5
            strength += fib_strength
            
            # Time symmetry (REDUCED from 0-1 to 0-0.5)
            time_strength = self.calculate_time_symmetry_strength(waves) * 0.5
            strength += time_strength
            
            # Price symmetry (REDUCED from 0-1 to 0-0.5)
            price_strength = self.calculate_price_symmetry_strength(waves) * 0.5
            strength += price_strength
            
            # CAP AT 5 POINTS (not 10)
            return min(strength, 5.0)
            
        except:
            return 1
    
    def calculate_volume_strength(self, waves):
        """Calculate strength based on volume confirmation"""
        try:
            volume_score = 0
            
            for wave in waves:
                index = wave['index']
                if index < len(self.data):
                    # Check if volume was above average during the wave
                    window_start = max(0, index - 5)
                    window_end = min(len(self.data), index + 5)
                    avg_volume = self.data['Volume'].iloc[window_start:window_end].mean()
                    
                    if self.data.iloc[index]['Volume'] > avg_volume * 1.1:
                        volume_score += 0.5
            
            return min(volume_score, 2)
            
        except:
            return 0
    
    def calculate_fibonacci_strength(self, waves: List[Dict]) -> float:
        """
        Calculate strength based on Fibonacci relationships - IMPROVED SLIDING SCALE.
        
        Uses smooth degradation instead of binary thresholds to handle noisy financial data.
        Perfect ratios get full credit, close ratios get partial credit, far ratios get zero.
        
        Returns:
            Score from 0.0 to 2.0 based on Fibonacci relationship quality
        """
        try:
            if len(waves) < 5:
                return 0.0
            
            # Calculate wave lengths
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave3_length = abs(waves[3]['price'] - waves[2]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            # Calculate ratios with safe division
            w3_w1_ratio = safe_divide(wave3_length, wave1_length, default=0)
            w5_w1_ratio = safe_divide(wave5_length, wave1_length, default=0)
            
            # IMPROVED: Sliding scale scoring (realistic for noisy data)
            # Each match can contribute 0-2 points based on proximity
            fib_score = 0.0
            
            # Check Wave 3/Wave 1 ≈ 1.618 (Golden ratio)
            if w3_w1_ratio > 0:
                fib_score += fib_match_score(w3_w1_ratio, 1.618)
            
            # Check Wave 5/Wave 1 ≈ 1.0 (Equal waves)
            if w5_w1_ratio > 0:
                fib_score += fib_match_score(w5_w1_ratio, 1.0)
            
            # Optional: Check Wave 5/Wave 3 ≈ 0.618 (inverse golden ratio)
            # Commented out to keep scoring consistent with historical behavior
            # w5_w3_ratio = safe_divide(wave5_length, wave3_length, default=0)
            # if w5_w3_ratio > 0:
            #     fib_score += fib_match_score(w5_w3_ratio, 0.618) * 0.5  # Lower weight
            
            # Cap at 2 points (max from both primary ratios)
            return min(fib_score, 2.0)
            
        except Exception as e:
            logger.error(f"Error calculating Fibonacci strength: {e}")
            return 0.0
    
    def calculate_time_symmetry_strength(self, waves: List[Dict]) -> float:
        """Calculate strength based on time symmetry"""
        try:
            if len(waves) < 5:
                return 0
            
            # Calculate time ratios between waves
            time_ratios = []
            for i in range(1, len(waves)):
                time_diff = (waves[i]['date'] - waves[i-1]['date']).days
                time_ratios.append(time_diff)
            
            # Check for Fibonacci time relationships
            symmetry_score = 0
            if len(time_ratios) >= 4:
                # Wave 2 time vs Wave 4 time
                ratio = safe_divide(time_ratios[3], time_ratios[1], default=0)
                if 0.6 <= ratio <= 1.6:
                    symmetry_score += 1
            
            return min(symmetry_score, 1)
            
        except Exception as e:
            logger.error(f"Error calculating time symmetry strength: {e}")
            return 0
    
    def calculate_price_symmetry_strength(self, waves: List[Dict]) -> float:
        """Calculate strength based on price symmetry"""
        try:
            if len(waves) < 5:
                return 0
            
            symmetry_score = 0
            
            # Check if waves 1 and 5 are similar in magnitude
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            ratio = safe_divide(wave5_length, wave1_length, default=0)
            if 0.8 <= ratio <= 1.2:
                symmetry_score += 1
            elif 0.6 <= ratio <= 1.4:
                symmetry_score += 0.5
            
            return min(symmetry_score, 1)
            
        except Exception as e:
            logger.error(f"Error calculating price symmetry strength: {e}")
            return 0
    
    def calculate_confidence_score(self, waves):
        """Calculate overall confidence score for the pattern - FIXED SCORING"""
        try:
            confidence = 0
            
            # Base confidence for valid pattern (REDUCED from 2 to 1)
            confidence += 1
            
            # Add confidence based on strength of individual waves (REDUCED multiplier)
            for wave in waves:
                if 'strength' in wave:
                    confidence += wave['strength'] * 0.1  # REDUCED from 0.2 to 0.1
            
            # Add confidence for recent waves (REDUCED bonus)
            total_days = (waves[-1]['date'] - waves[0]['date']).days
            if total_days > 0:
                recent_factor = min(30 / total_days, 1)
                confidence += recent_factor * 1  # REDUCED from 2 to 1
            
            # CAP AT 3 POINTS (not 5)
            return min(confidence, 3.0)
            
        except:
            return 0.5
    
    def analyze_fibonacci_relationships(self, waves: List[Dict]) -> Dict[str, Any]:
        """Detailed Fibonacci relationship analysis"""
        try:
            if len(waves) < 5:
                return {}
            
            analysis = {}
            wave1_length = abs(waves[1]['price'] - waves[0]['price'])
            wave3_length = abs(waves[3]['price'] - waves[2]['price'])
            wave5_length = abs(waves[4]['price'] - waves[3]['price'])
            
            # Calculate ratios using safe division
            analysis['w3_w1_ratio'] = safe_divide(wave3_length, wave1_length, default=0)
            analysis['w5_w1_ratio'] = safe_divide(wave5_length, wave1_length, default=0)
            analysis['w5_w3_ratio'] = safe_divide(wave5_length, wave3_length, default=0)
            
            # Identify Fibonacci matches
            fib_matches = []
            target_ratios = [0.618, 1.0, 1.618, 2.618]
            
            for ratio_name, ratio_value in [('W3/W1', analysis['w3_w1_ratio']), 
                                           ('W5/W1', analysis['w5_w1_ratio']),
                                           ('W5/W3', analysis['w5_w3_ratio'])]:
                for target in target_ratios:
                    if abs(ratio_value - target) < 0.1:
                        fib_matches.append(f"{ratio_name} ≈ {target}")
            
            analysis['fibonacci_matches'] = fib_matches
            analysis['fibonacci_score'] = len(fib_matches)
            
            return analysis
            
        except:
            return {}
    
    def analyze_wave_structure(self, waves):
        """Analyze the structure of detected waves"""
        analysis = {}
        
        for i, wave in enumerate(waves):
            wave_name = f"Wave_{i+1}"
            analysis[wave_name] = {
                'price': wave['price'],
                'date': wave['date'],
                'type': wave['type']
            }
            
            if i > 0:
                prev_wave = waves[i-1]
                move_size = abs(wave['price'] - prev_wave['price'])
                move_direction = 'up' if wave['price'] > prev_wave['price'] else 'down'
                
                analysis[wave_name].update({
                    'move_size': move_size,
                    'direction': move_direction,
                    'days': (wave['date'] - prev_wave['date']).days
                })
        
        return analysis
    
    def calculate_pattern_strength(self, waves):
        """Calculate the strength/reliability of the Elliott Wave pattern"""
        strength = 0
        
        # Check Fibonacci relationships
        if len(waves) >= 5:
            try:
                wave1_size = abs(waves[1]['price'] - waves[0]['price'])
                wave3_size = abs(waves[3]['price'] - waves[2]['price'])
                wave5_size = abs(waves[4]['price'] - waves[3]['price'])
                
                # Wave 3 is often 1.618 times Wave 1
                if 1.5 < (wave3_size / wave1_size) < 1.8:
                    strength += 2
                
                # Wave 5 is often equal to Wave 1
                if 0.8 < (wave5_size / wave1_size) < 1.2:
                    strength += 1
                
                strength += 1  # Base strength for having 5 waves
                
            except ZeroDivisionError:
                pass
        
        return min(strength, 5)  # Max strength of 5

class RelativeStrengthAnalyzer:
    """
    Analyzes relative strength of a symbol vs benchmark (NIFTY 50).
    
    Helps identify:
    - Sector outperformance/underperformance
    - Lead/lag conditions
    - Quality of trend (absolute vs relative)
    """
    
    def __init__(self, symbol_data: pd.DataFrame, benchmark_data: pd.DataFrame):
        """
        Initialize relative strength analyzer.
        
        Args:
            symbol_data: Price data for the symbol
            benchmark_data: Price data for benchmark (NIFTY 50)
        """
        self.symbol_data = symbol_data
        self.benchmark_data = benchmark_data
        
    def calculate_rs_ratio(self) -> pd.Series:
        """
        Calculate relative strength ratio (Symbol/Benchmark).
        
        Returns:
            Time series of RS ratio
        """
        try:
            # Align dates between symbol and benchmark
            aligned_symbol = self.symbol_data['Close'].reindex(
                self.benchmark_data.index, method='ffill'
            )
            
            rs_ratio = aligned_symbol / self.benchmark_data['Close']
            return rs_ratio.dropna()
        except Exception as e:
            logger.error(f"Error calculating RS ratio: {e}")
            return pd.Series()
    
    def analyze_relative_strength(self, lookback: int = None) -> Dict[str, Any]:
        """
        Comprehensive relative strength analysis.
        
        Args:
            lookback: Lookback period in days (default: from config)
            
        Returns:
            Dictionary with RS metrics
        """
        if lookback is None:
            lookback = config.rs_lookback_period
            
        try:
            rs_ratio = self.calculate_rs_ratio()
            
            if len(rs_ratio) < lookback:
                logger.warning(f"Insufficient data for RS analysis: {len(rs_ratio)} < {lookback}")
                return self._get_empty_rs_result()
            
            # Current RS ratio
            current_rs = rs_ratio.iloc[-1]
            
            # RS moving average
            rs_ma = rs_ratio.rolling(lookback).mean()
            rs_ma_current = rs_ma.iloc[-1]
            rs_ma_prev = rs_ma.iloc[-lookback] if len(rs_ma) > lookback else rs_ma.iloc[0]
            
            # RS slope (rate of change)
            rs_slope = safe_divide(
                (rs_ma_current - rs_ma_prev),
                rs_ma_prev,
                default=0.0
            )
            
            # RS rank (percentile over lookback period)
            rs_rank = (rs_ratio.iloc[-1] > rs_ratio.iloc[-lookback:]).sum() / lookback
            
            # Classification based on slope
            if rs_slope > config.rs_strong_threshold:
                rs_signal = "STRONG OUTPERFORMANCE"
                rs_strength = 2.0
                rs_action = "BUY - Strong sector momentum"
            elif rs_slope > config.rs_moderate_threshold:
                rs_signal = "OUTPERFORMANCE"
                rs_strength = 1.0
                rs_action = "BUY - Moderate sector strength"
            elif rs_slope > -config.rs_moderate_threshold:
                rs_signal = "NEUTRAL"
                rs_strength = 0.0
                rs_action = "HOLD - No clear relative trend"
            elif rs_slope > -config.rs_strong_threshold:
                rs_signal = "UNDERPERFORMANCE"
                rs_strength = -1.0
                rs_action = "CAUTION - Sector weakness"
            else:
                rs_signal = "STRONG UNDERPERFORMANCE"
                rs_strength = -2.0
                rs_action = "AVOID - Strong sector weakness"
            
            # Trend consistency (is RS trending consistently?)
            rs_slope_5d = safe_divide(
                (rs_ma.iloc[-1] - rs_ma.iloc[-5]),
                rs_ma.iloc[-5],
                default=0.0
            ) if len(rs_ma) >= 5 else 0.0
            
            rs_slope_10d = safe_divide(
                (rs_ma.iloc[-1] - rs_ma.iloc[-10]),
                rs_ma.iloc[-10],
                default=0.0
            ) if len(rs_ma) >= 10 else 0.0
            
            # Check trend consistency
            slope_signs = [np.sign(rs_slope_5d), np.sign(rs_slope_10d), np.sign(rs_slope)]
            trend_consistent = len(set(slope_signs)) == 1 and slope_signs[0] != 0
            
            return {
                'rs_ratio': float(current_rs),
                'rs_ma': float(rs_ma_current),
                'rs_slope': float(rs_slope),
                'rs_slope_5d': float(rs_slope_5d),
                'rs_slope_10d': float(rs_slope_10d),
                'rs_rank': float(rs_rank),
                'rs_signal': rs_signal,
                'rs_strength': rs_strength,
                'rs_action': rs_action,
                'trend_consistent': trend_consistent,
                'outperformance_pct': float(rs_slope * 100)
            }
            
        except Exception as e:
            logger.error(f"Error in RS analysis: {e}", exc_info=True)
            return self._get_empty_rs_result()
    
    def _get_empty_rs_result(self) -> Dict[str, Any]:
        """Return empty RS result for error cases."""
        return {
            'rs_ratio': 1.0,
            'rs_ma': 1.0,
            'rs_slope': 0.0,
            'rs_slope_5d': 0.0,
            'rs_slope_10d': 0.0,
            'rs_rank': 0.5,
            'rs_signal': 'INSUFFICIENT DATA',
            'rs_strength': 0.0,
            'rs_action': 'N/A',
            'trend_consistent': False,
            'outperformance_pct': 0.0
        }

class ProbabilisticTargetCalculator:
    """
    Calculates probabilistic price targets using Fibonacci extensions.
    
    Instead of single point targets, provides probability-weighted target zones
    for better risk management and position sizing.
    """
    
    def __init__(self, wave_data: Optional[Dict] = None):
        """
        Initialize target calculator.
        
        Args:
            wave_data: Elliott Wave pattern data (optional)
        """
        self.wave_data = wave_data
    
    def calculate_wave_amplitude(self, waves: List[Dict]) -> float:
        """
        Calculate the amplitude of the most recent completed wave.
        
        Args:
            waves: List of wave data points
            
        Returns:
            Wave amplitude (price movement)
        """
        try:
            if len(waves) < 2:
                return 0.0
            
            # Use the most recent wave
            wave_start = waves[-2]['price']
            wave_end = waves[-1]['price']
            
            return abs(wave_end - wave_start)
        except Exception as e:
            logger.error(f"Error calculating wave amplitude: {e}")
            return 0.0
    
    def calculate_targets(self, current_price: float, 
                         wave_amplitude: float,
                         direction: str = 'up') -> Dict[str, Dict[str, float]]:
        """
        Calculate probabilistic targets using Fibonacci extensions.
        
        Args:
            current_price: Current market price
            wave_amplitude: Reference wave amplitude
            direction: 'up' for bullish targets, 'down' for bearish
            
        Returns:
            Dictionary of target levels with probabilities
        """
        try:
            if wave_amplitude == 0:
                logger.warning("Wave amplitude is zero, cannot calculate targets")
                return {}
            
            targets = {}
            direction_multiplier = 1 if direction == 'up' else -1
            
            # Define target levels with probabilities
            target_levels = [
                ('1.0x (Conservative)', 1.0, 0.70),
                ('1.272x (Moderate)', 1.272, 0.55),
                ('1.618x (Aggressive)', 1.618, 0.40),
                ('2.0x (Extended)', 2.0, 0.25),
                ('2.618x (Extreme)', 2.618, 0.15)
            ]
            
            for label, multiplier, base_probability in target_levels:
                target_price = current_price + (direction_multiplier * wave_amplitude * multiplier)
                distance_pct = ((target_price - current_price) / current_price) * 100
                
                # Adjust probability based on distance
                # Closer targets have higher probability
                distance_adjustment = max(0, 1 - abs(distance_pct) / 50)
                adjusted_probability = base_probability * (0.7 + 0.3 * distance_adjustment)
                
                targets[label] = {
                    'price': round(target_price, 2),
                    'multiplier': multiplier,
                    'probability': round(adjusted_probability, 2),
                    'distance_pct': round(distance_pct, 2),
                    'distance_points': round(target_price - current_price, 2)
                }
            
            return targets
            
        except Exception as e:
            logger.error(f"Error calculating probabilistic targets: {e}", exc_info=True)
            return {}
    
    def get_recommended_exits(self, targets: Dict[str, Dict[str, float]]) -> List[Dict[str, Any]]:
        """
        Generate recommended exit strategy based on target probabilities.
        
        Args:
            targets: Dictionary of calculated targets
            
        Returns:
            List of recommended exit levels with position percentages
        """
        try:
            if not targets:
                return []
            
            exits = []
            
            # Exit strategy: Take profits in stages
            # Higher probability targets = larger position reduction
            for label, target_data in targets.items():
                prob = target_data['probability']
                
                if prob >= 0.60:
                    position_pct = 0.25  # Exit 25% at high probability targets
                elif prob >= 0.40:
                    position_pct = 0.33  # Exit 33% at medium probability
                elif prob >= 0.25:
                    position_pct = 0.50  # Exit 50% at moderate probability
                else:
                    position_pct = 1.0   # Exit remaining at low probability
                
                exits.append({
                    'label': label,
                    'price': target_data['price'],
                    'probability': prob,
                    'exit_percentage': position_pct,
                    'distance_pct': target_data['distance_pct']
                })
            
            return exits
            
        except Exception as e:
            logger.error(f"Error generating exit recommendations: {e}")
            return []

class CycleProjectionAnalyzer:
    """
    Projects future cycle inflection points using time-based Fibonacci analysis.
    
    Helps predict WHEN the next major reversal might occur, which is critical
    for timing options strategies and avoiding whipsaws.
    """
    
    def __init__(self, wave_pattern: Optional[Dict] = None):
        """
        Initialize cycle projection analyzer.
        
        Args:
            wave_pattern: Elliott Wave pattern data
        """
        self.wave_pattern = wave_pattern
    
    def calculate_average_wave_duration(self, waves: List[Dict]) -> float:
        """
        Calculate average duration of waves in the pattern.
        
        Args:
            waves: List of wave data points
            
        Returns:
            Average wave duration in days
        """
        try:
            if len(waves) < 2:
                return 0.0
            
            durations = []
            for i in range(1, len(waves)):
                # Normalize dates to ensure timezone-naive comparison
                date1 = normalize_datetime(waves[i-1]['date'])
                date2 = normalize_datetime(waves[i]['date'])
                duration = (date2 - date1).days
                durations.append(duration)
            
            return np.mean(durations) if durations else 0.0
            
        except Exception as e:
            logger.error(f"Error calculating average wave duration: {e}")
            return 0.0
    
    def project_cycle_inflections(self, waves: List[Dict]) -> Dict[str, Any]:
        """
        Project future inflection points using Fibonacci time ratios.
        
        Args:
            waves: List of wave data points
            
        Returns:
            Dictionary with projected inflection dates and confidence
        """
        try:
            if len(waves) < 3:
                logger.warning("Insufficient waves for cycle projection")
                return {}
            
            # Get last completed wave date and normalize to timezone-naive
            last_wave_date = normalize_datetime(waves[-1]['date'])
            
            # Calculate average wave duration
            avg_duration = self.calculate_average_wave_duration(waves)
            
            if avg_duration == 0:
                logger.warning("Average duration is zero")
                return {}
            
            # Get current time (timezone-naive)
            current_time = normalize_datetime(datetime.now())
            
            projections = {}
            
            # Project inflection points using Fibonacci time multipliers
            for multiplier in config.cycle_fib_multipliers:
                projected_days = int(avg_duration * multiplier)
                projected_date = last_wave_date + timedelta(days=projected_days)
                
                # Ensure projected_date is timezone-naive
                projected_date = normalize_datetime(projected_date)
                
                # Calculate days from now safely
                days_from_now = (projected_date - current_time).days
                
                # Only include future projections (or very recent past within 3 days)
                if days_from_now >= -3:
                    # Calculate confidence based on pattern strength
                    # More consistent wave durations = higher confidence
                    duration_variance = self._calculate_duration_variance(waves)
                    consistency_factor = 1.0 / (1.0 + duration_variance)
                    
                    base_confidence = {
                        1.0: 0.60,
                        1.272: 0.50,
                        1.618: 0.40,
                        2.0: 0.30
                    }.get(multiplier, 0.25)
                    
                    adjusted_confidence = base_confidence * consistency_factor
                    
                    # Reduce confidence for past dates
                    if days_from_now < 0:
                        adjusted_confidence *= 0.5  # Past dates have lower relevance
                    
                    label = f"{multiplier}x Fibonacci Time"
                    projections[label] = {
                        'date': projected_date,
                        'days_from_now': days_from_now,
                        'multiplier': multiplier,
                        'confidence': round(adjusted_confidence, 2),
                        'avg_wave_duration': round(avg_duration, 1),
                        'is_past': days_from_now < 0
                    }
            
            return projections
            
        except Exception as e:
            logger.error(f"Error projecting cycle inflections: {e}", exc_info=True)
            return {}
    
    def _calculate_duration_variance(self, waves: List[Dict]) -> float:
        """
        Calculate variance in wave durations (consistency metric).
        
        Args:
            waves: List of wave data points
            
        Returns:
            Normalized variance (0 = perfect consistency, higher = more variable)
        """
        try:
            if len(waves) < 2:
                return 1.0
            
            durations = []
            for i in range(1, len(waves)):
                # Normalize dates to ensure timezone-naive comparison
                date1 = normalize_datetime(waves[i-1]['date'])
                date2 = normalize_datetime(waves[i]['date'])
                duration = (date2 - date1).days
                durations.append(duration)
            
            if not durations:
                return 1.0
            
            mean_duration = np.mean(durations)
            if mean_duration == 0:
                return 1.0
            
            variance = np.var(durations)
            # Normalize by mean to get coefficient of variation
            normalized_variance = np.sqrt(variance) / mean_duration
            
            return normalized_variance
            
        except Exception as e:
            logger.error(f"Error calculating duration variance: {e}")
            return 1.0
    
    def get_next_key_date(self, projections: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Get the most probable next inflection date.
        
        Args:
            projections: Dictionary of projected dates
            
        Returns:
            Most confident projection or None
        """
        try:
            if not projections:
                return None
            
            # Find projection with highest confidence
            best_projection = None
            highest_confidence = 0.0
            
            for label, data in projections.items():
                if data['confidence'] > highest_confidence:
                    highest_confidence = data['confidence']
                    best_projection = {
                        'label': label,
                        **data
                    }
            
            return best_projection
            
        except Exception as e:
            logger.error(f"Error getting next key date: {e}")
            return None

class IntegratedMarketAnalyzer:
    """Enhanced market analyzer using Kite Connect API with institutional-grade features"""
    
    def __init__(self, api_key, access_token=None, symbol="NIFTY 50", instrument_token=256265):
        self.symbol = symbol
        self.instrument_token = instrument_token
        self.data_provider = KiteDataProvider(api_key, access_token)
        self.data = None
        self.benchmark_data = None  # NIFTY 50 data for relative strength
        
        # Core analyzers
        self.lunar_analyzer = LunarCycleAnalyzer()
        self.gann_analyzer = None
        self.elliott_analyzer = None
        
        # NEW: Enhanced analyzers
        self.rs_analyzer = None  # Relative Strength vs NIFTY
        self.target_calculator = None  # Probabilistic targets
        self.cycle_projector = None  # Cycle projections
    
    def fetch_market_data(self, days=180):
        """
        Fetch historical market data for symbol and benchmark.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            True if successful, False otherwise
        """
        try:
            to_date = datetime.now()
            from_date = to_date - timedelta(days=days)
            
            logger.info(f"Fetching {self.symbol} data from {from_date.date()} to {to_date.date()}...")
            print(f"Fetching {self.symbol} data from {from_date.date()} to {to_date.date()}...")
            
            # Fetch symbol data
            self.data = self.data_provider.fetch_historical_data(
                instrument_token=self.instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if self.data is None or self.data.empty:
                logger.error("No data received for symbol")
                print("No data received")
                return False
            
            logger.info(f"Successfully fetched {len(self.data)} trading sessions for {self.symbol}")
            print(f"Successfully fetched {len(self.data)} trading sessions")
            
            # Initialize core analyzers
            self.gann_analyzer = GannAnalyzer(self.data)
            self.elliott_analyzer = ElliottWaveAnalyzer(self.data)
            
            # Fetch benchmark data (NIFTY 50) for relative strength analysis
            if config.enable_relative_strength and self.symbol != "NIFTY 50":
                logger.info("Fetching NIFTY 50 benchmark data for relative strength analysis...")
                
                self.benchmark_data = self.data_provider.fetch_historical_data(
                    instrument_token=config.nifty50_instrument_token,
                    from_date=from_date,
                    to_date=to_date,
                    interval="day"
                )
                
                if self.benchmark_data is not None and not self.benchmark_data.empty:
                    logger.info(f"Fetched {len(self.benchmark_data)} NIFTY 50 sessions for RS analysis")
                    print(f"✅ Fetched {len(self.benchmark_data)} NIFTY 50 sessions for RS analysis")
                    # Initialize RS analyzer
                    self.rs_analyzer = RelativeStrengthAnalyzer(self.data, self.benchmark_data)
                else:
                    logger.warning("Could not fetch benchmark data, RS analysis will be skipped")
                    self.rs_analyzer = None
            else:
                logger.info("Relative strength analysis disabled or symbol is NIFTY 50")
                self.rs_analyzer = None
                self.benchmark_data = None
            
            # Initialize probabilistic target calculator
            if config.enable_probabilistic_targets:
                self.target_calculator = ProbabilisticTargetCalculator()
            
            # Initialize cycle projector
            if config.enable_cycle_projection:
                self.cycle_projector = CycleProjectionAnalyzer()
            
            return True
                
        except Exception as e:
            logger.error(f"Error fetching market data: {e}", exc_info=True)
            print(f"Error fetching market data: {e}")
            return False
    
    def generate_combined_signals(self):
        """
        Generate comprehensive trading signals with institutional-grade enhancements.
        
        NEW FEATURES:
        - Sigmoid-based confidence scoring (non-linear, bounded 0-10)
        - Relative strength vs NIFTY 50 analysis
        - Probabilistic target zones
        - Cycle projection for timing
        
        Returns:
            List of signal dictionaries with enhanced metrics
        """
        if self.data is None:
            return []
        
        signals = []
        current_price = self.data['Close'].iloc[-1]
        current_date = self.data.index[-1]
        
        # Initialize signal components
        signal_type = "Hold"
        reasons = []
        
        # ==================================================================
        # 1. LUNAR ANALYSIS
        # ==================================================================
        lunar_phase = self.lunar_analyzer.get_lunar_phase(current_date)
        lunar_strength = self.lunar_analyzer.get_lunar_influence_strength(current_date)
        lunar_significant = self.lunar_analyzer.is_significant_lunar_period(current_date)
        
        # Normalize lunar strength to 0-10 scale for weighting
        lunar_score_normalized = min(lunar_strength / 2.5 * 10, 10)  # 2.5 is max lunar strength
        
        if lunar_significant:
            reasons.append(f"Significant lunar phase: {lunar_phase} (strength: {lunar_strength:.1f})")
        
        # ==================================================================
        # 2. GANN ANALYSIS
        # ==================================================================
        gann_signals = self.gann_analyzer.get_gann_signals(current_price)
        gann_strength = sum([s.get('strength', 0) for s in gann_signals])
        
        # Normalize Gann strength (typical max is ~3-4)
        gann_score_normalized = min(gann_strength / 4.0 * 10, 10)
        
        # NEW: Calculate Gann vote (strength-weighted)
        gann_buy_strength = sum([s['strength'] for s in gann_signals if s['signal'] == 'Support'])
        gann_sell_strength = sum([s['strength'] for s in gann_signals if s['signal'] == 'Resistance'])
        
        for gann_signal in gann_signals:
            reasons.append(f"Gann {gann_signal['signal']} at ₹{gann_signal['level']:.2f} ({gann_signal['type']})")
        
        # ==================================================================
        # 3. ELLIOTT WAVE ANALYSIS
        # ==================================================================
        elliott_pattern = self.elliott_analyzer.detect_wave_pattern()
        elliott_strength = 0
        wave_type = 'None'
        fibonacci_score = 0
        elliott_buy_strength = 0
        elliott_sell_strength = 0
        
        if elliott_pattern:
            elliott_strength = elliott_pattern['pattern_strength']
            wave_type = elliott_pattern.get('wave_type', 'Unknown')
            
            # Get Fibonacci relationship score
            fib_analysis = elliott_pattern.get('fibonacci_analysis', {})
            fibonacci_score = fib_analysis.get('fibonacci_score', 0)
            
            # Adjust for pattern type
            if wave_type == 'Corrective':
                elliott_strength *= 0.6
                reasons.append(f"Corrective Elliott Wave (Strength: {elliott_strength:.1f})")
            elif wave_type.startswith('Impulse'):
                reasons.append(f"Impulse Elliott Wave (Strength: {elliott_strength:.1f})")
            else:
                elliott_strength *= 0.7
                reasons.append(f"Elliott Wave pattern detected (Strength: {elliott_strength:.1f})")
            
            # NEW: Determine wave direction vote (strength-weighted)
            last_wave = elliott_pattern['waves'][-1]
            if last_wave['type'] == 'Peak':
                elliott_sell_strength = elliott_strength
                reasons.append(f"Wave completed at peak")
            else:
                elliott_buy_strength = elliott_strength
                reasons.append(f"Wave completed at trough")
        
        # Normalize Elliott strength (max is 5)
        elliott_score_normalized = min(elliott_strength / 5.0 * 10, 10)
        
        # NOTE: Fibonacci is now part of Elliott Wave scoring (not separate)
        # This avoids double-counting since Fibonacci ratios are used in Elliott pattern strength
        
        # ==================================================================
        # 4. RELATIVE STRENGTH ANALYSIS (NEW!)
        # ==================================================================
        rs_data = {}
        rs_score = 5.0  # Neutral default
        
        if self.rs_analyzer is not None:
            rs_data = self.rs_analyzer.analyze_relative_strength()
            rs_strength = rs_data.get('rs_strength', 0)
            rs_signal = rs_data.get('rs_signal', 'NEUTRAL')
            rs_action = rs_data.get('rs_action', 'N/A')
            
            # Convert RS strength (-2 to +2) to 0-10 scale
            # -2 = 0, 0 = 5, +2 = 10
            rs_score = (rs_strength + 2) / 4.0 * 10
            
            # Add to reasons
            if rs_signal != 'NEUTRAL':
                reasons.append(f"RS vs NIFTY: {rs_signal} ({rs_data.get('outperformance_pct', 0):.1f}%)")
                reasons.append(rs_action)
            
            # NEW: RS contributes to voting
            rs_buy_strength = max(0, rs_strength) if rs_strength > 0 else 0
            rs_sell_strength = max(0, -rs_strength) if rs_strength < 0 else 0
        else:
            rs_buy_strength = 0
            rs_sell_strength = 0
        
        # ==================================================================
        # SIGNAL DETERMINATION: Strength-Weighted Voting System
        # ==================================================================
        # Calculate total buy vs sell strength from all components
        # Adjusted weights to prioritize market context (RS) over patterns
        total_buy_strength = (
            gann_buy_strength * 1.0 +           # Gann support votes (base weight)
            elliott_buy_strength * 1.5 +        # Elliott wave votes (moderate weight)
            rs_buy_strength * 4.0               # RS votes (4x weight - DOMINANT!)
        )
        
        total_sell_strength = (
            gann_sell_strength * 1.0 +          # Gann resistance votes (base weight)
            elliott_sell_strength * 1.5 +       # Elliott wave votes (moderate weight)
            rs_sell_strength * 4.0              # RS votes (4x weight - DOMINANT!)
        )
        
        # Determine signal based on strength voting with RS priority
        strength_difference = total_buy_strength - total_sell_strength
        
        # ==================================================================
        # SIGNAL DETERMINATION LOGIC - BALANCED vs AGGRESSIVE MODE
        # ==================================================================
        
        if config.signal_mode == "balanced":
            # ============================================================
            # BALANCED MODE (DEFAULT) - Respects both RS and technicals
            # ============================================================
            # More sophisticated approach that considers both factors
            # Recommended for swing/position traders and risk-conscious users
            
            if self.rs_analyzer is not None and rs_data:
                rs_strength_val = rs_data.get('rs_strength', 0)
                
                # RS provides guidance when moderate-to-strong
                if rs_strength_val >= config.rs_moderate_override and strength_difference > config.technical_conflict_limit:
                    # Strong RS + acceptable technicals = Follow RS
                    signal_type = "Buy"
                    if strength_difference < 0:
                        reasons.append(f"🎯 RS-Guided BUY: Strong outperformance ({rs_strength_val:+.1f}) overrides mild technical weakness ({strength_difference:+.1f})")
                    else:
                        reasons.append(f"✅ RS-Confirmed BUY: Strong outperformance ({rs_strength_val:+.1f}) + bullish technicals ({strength_difference:+.1f})")
                
                elif rs_strength_val <= -config.rs_moderate_override and strength_difference < -config.technical_conflict_limit:
                    # Strong RS weakness + acceptable technicals = Follow RS
                    signal_type = "Sell"
                    if strength_difference > 0:
                        reasons.append(f"⚠️ RS-Guided SELL: Strong underperformance ({rs_strength_val:+.1f}) overrides mild technical strength ({strength_difference:+.1f})")
                    else:
                        reasons.append(f"❌ RS-Confirmed SELL: Strong underperformance ({rs_strength_val:+.1f}) + bearish technicals ({strength_difference:+.1f})")
                
                else:
                    # RS not decisive or conflict too strong - use pure voting
                    if strength_difference > config.balanced_buy_threshold:
                        signal_type = "Buy"
                        if rs_strength_val < 0:
                            reasons.append(f"📊 Technical BUY despite weak RS ({rs_strength_val:+.1f}): Strong technical signals ({strength_difference:+.1f})")
                    elif strength_difference < config.balanced_sell_threshold:
                        signal_type = "Sell"
                        if rs_strength_val > 0:
                            reasons.append(f"📊 Technical SELL despite strong RS ({rs_strength_val:+.1f}): Overwhelming technical warnings ({strength_difference:+.1f})")
                    else:
                        signal_type = "Hold"
                        if abs(rs_strength_val) > 1.0 and abs(strength_difference) > 1.0:
                            reasons.append(f"⚖️ HOLD: Conflicting signals - RS {rs_strength_val:+.1f} vs Technical {strength_difference:+.1f}")
            else:
                # No RS data - use pure technical voting
                if strength_difference > config.balanced_buy_threshold:
                    signal_type = "Buy"
                elif strength_difference < config.balanced_sell_threshold:
                    signal_type = "Sell"
                else:
                    signal_type = "Hold"
        
        else:
            # ============================================================
            # AGGRESSIVE MODE - RS dominates when strong
            # ============================================================
            # Pure momentum approach: Strong RS overrides almost everything
            # Recommended for pure momentum/trend traders with high risk tolerance
            
            if self.rs_analyzer is not None and rs_data:
                rs_strength_val = rs_data.get('rs_strength', 0)
                
                # STRONG RS (+/-2.0) gets override power (95th percentile)
                if rs_strength_val >= config.rs_strong_override:
                    # Force BUY unless sell strength is overwhelming
                    if total_sell_strength < config.overwhelming_opposition:
                        signal_type = "Buy"
                        if total_sell_strength > 2.0:
                            reasons.append(f"🔥 RS OVERRIDE: STRONG OUTPERFORMANCE ({rs_strength_val:+.1f}) dominates bearish technicals ({total_sell_strength:.1f})")
                    else:
                        signal_type = "Hold"
                        reasons.append(f"⚠️ Extreme conflict: Strong RS ({rs_strength_val:+.1f}) vs overwhelming sell signals ({total_sell_strength:.1f})")
                        
                elif rs_strength_val <= -config.rs_strong_override:
                    # Force SELL unless buy strength is overwhelming
                    if total_buy_strength < config.overwhelming_opposition:
                        signal_type = "Sell"
                        if total_buy_strength > 2.0:
                            reasons.append(f"⚠️ RS OVERRIDE: STRONG UNDERPERFORMANCE ({rs_strength_val:+.1f}) dominates bullish technicals ({total_buy_strength:.1f})")
                    else:
                        signal_type = "Hold"
                        reasons.append(f"⚠️ Extreme conflict: Weak RS ({rs_strength_val:+.1f}) vs overwhelming buy signals ({total_buy_strength:.1f})")
                        
                else:
                    # Moderate RS - use strength-weighted voting (lower thresholds)
                    if strength_difference > config.aggressive_buy_threshold:
                        signal_type = "Buy"
                    elif strength_difference < config.aggressive_sell_threshold:
                        signal_type = "Sell"
                    else:
                        signal_type = "Hold"
            else:
                # No RS data - use standard voting (stricter thresholds in aggressive mode)
                if strength_difference > 1.5:
                    signal_type = "Buy"
                elif strength_difference < -1.5:
                    signal_type = "Sell"
                else:
                    signal_type = "Hold"
        
        # Log voting breakdown for transparency and debugging
        logger.info(
            f"Signal voting [{config.signal_mode.upper()}] → {signal_type.upper()} | "
            f"Buy:{total_buy_strength:.2f} (G:{gann_buy_strength:.1f} E:{elliott_buy_strength:.1f} RS:{rs_buy_strength:.1f}) | "
            f"Sell:{total_sell_strength:.2f} (G:{gann_sell_strength:.1f} E:{elliott_sell_strength:.1f} RS:{rs_sell_strength:.1f}) | "
            f"Diff:{strength_difference:+.2f}"
        )
        
        # Add conflict warnings if signals disagree
        if total_buy_strength > 1.0 and total_sell_strength > 1.0:
            if abs(strength_difference) < 3.0:  # Close vote
                reasons.append(
                    f"⚠️ Mixed signals (Buy:{total_buy_strength:.1f} vs Sell:{total_sell_strength:.1f})"
                )
        
        # ==================================================================
        # 5. MOMENTUM ANALYSIS
        # ==================================================================
        # Calculate momentum score (RSI-based)
        if len(self.data) >= 14:
            delta = self.data['Close'].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = safe_divide(gain.iloc[-1], loss.iloc[-1], default=1.0)
            rsi = 100 - (100 / (1 + rs))
            
            # Normalize RSI to 0-10 scale (50 = neutral)
            momentum_score = rsi / 10.0
        else:
            momentum_score = 5.0  # Neutral
        
        # ==================================================================
        # 6. VOLUME ANALYSIS (NEW!)
        # ==================================================================
        # Calculate volume confirmation score
        volume_score = 5.0  # Neutral default
        
        if len(self.data) >= 20:
            try:
                # Calculate average volume over different periods
                avg_volume_20 = self.data['Volume'].iloc[-20:].mean()
                avg_volume_50 = self.data['Volume'].iloc[-50:].mean() if len(self.data) >= 50 else avg_volume_20
                current_volume = self.data['Volume'].iloc[-1]
                recent_avg_volume = self.data['Volume'].iloc[-5:].mean()
                
                # Volume surge scoring (institutional accumulation/distribution signal)
                volume_ratio_current = safe_divide(current_volume, avg_volume_20, default=1.0)
                volume_ratio_recent = safe_divide(recent_avg_volume, avg_volume_20, default=1.0)
                
                # Volume trend (increasing = bullish, decreasing = bearish)
                volume_trend = safe_divide(avg_volume_20, avg_volume_50, default=1.0)
                
                # Composite volume score
                # High volume on directional moves = confirmation
                # Low volume = weak conviction
                if volume_ratio_recent > 1.5:
                    volume_score = 8.0  # Strong volume surge (institutional activity)
                elif volume_ratio_recent > 1.2:
                    volume_score = 7.0  # Above average volume
                elif volume_ratio_recent > 0.8:
                    volume_score = 5.0  # Normal volume (neutral)
                elif volume_ratio_recent > 0.5:
                    volume_score = 4.0  # Below average (weak hands)
                else:
                    volume_score = 3.0  # Very low volume (lack of conviction)
                
                # Adjust for volume trend
                if volume_trend > 1.2:
                    volume_score += 0.5  # Increasing volume trend (bullish)
                elif volume_trend < 0.8:
                    volume_score -= 0.5  # Decreasing volume trend (bearish)
                
                # Clamp to 0-10 range
                volume_score = max(0.0, min(volume_score, 10.0))
                
            except Exception as e:
                logger.error(f"Error calculating volume score: {e}")
                volume_score = 5.0  # Neutral on error
        
        # ==================================================================
        # 7. SIGMOID-BASED CONFIDENCE SCORING
        # ==================================================================
        # Calculate weighted raw score using configured weights
        # NOTE: Fibonacci removed - it's already part of Elliott Wave (avoid double-counting)
        raw_score = (
            config.weight_elliott * elliott_score_normalized +
            config.weight_gann * gann_score_normalized +
            config.weight_momentum * momentum_score +
            config.weight_volume * volume_score
        )
        
        # Apply sigmoid normalization
        sigmoid_confidence = sigmoid_normalize(
            raw_score,
            steepness=config.sigmoid_steepness,
            midpoint=config.sigmoid_midpoint,
            scale=10.0
        )
        
        # Adjust for relative strength
        if self.rs_analyzer is not None:
            rs_adjustment = (rs_score - 5.0) / 10.0  # -0.5 to +0.5
            sigmoid_confidence += rs_adjustment
            sigmoid_confidence = max(0.0, min(sigmoid_confidence, 10.0))
        
        # Count confirmations for quality score
        confirmations = sum([
            lunar_significant,
            len(gann_signals) > 0,
            elliott_pattern is not None,
            self.rs_analyzer is not None and rs_data.get('trend_consistent', False)
        ])
        
        # ==================================================================
        # 7. PROBABILISTIC TARGETS (NEW!)
        # ==================================================================
        prob_targets = {}
        target_exits = []
        
        if config.enable_probabilistic_targets and elliott_pattern and self.target_calculator:
            wave_amplitude = self.target_calculator.calculate_wave_amplitude(
                elliott_pattern['waves']
            )
            
            if wave_amplitude > 0:
                direction = 'up' if signal_type == 'Buy' else 'down'
                prob_targets = self.target_calculator.calculate_targets(
                    current_price,
                    wave_amplitude,
                    direction
                )
                target_exits = self.target_calculator.get_recommended_exits(prob_targets)
                
                if prob_targets:
                    reasons.append(f"Probabilistic targets calculated ({len(prob_targets)} levels)")
        
        # ==================================================================
        # 8. CYCLE PROJECTION (NEW!)
        # ==================================================================
        cycle_projections = {}
        next_key_date = None
        
        if config.enable_cycle_projection and elliott_pattern and self.cycle_projector:
            cycle_projections = self.cycle_projector.project_cycle_inflections(
                elliott_pattern['waves']
            )
            next_key_date = self.cycle_projector.get_next_key_date(cycle_projections)
            
            if next_key_date:
                days_to_inflection = next_key_date.get('days_from_now', 0)
                if days_to_inflection > 0:
                    reasons.append(
                        f"Next projected inflection: {days_to_inflection} days "
                        f"(Confidence: {next_key_date.get('confidence', 0):.0%})"
                    )
                elif days_to_inflection < 0:
                    reasons.append(
                        f"Cycle projection passed {abs(days_to_inflection)} days ago - "
                        f"New pattern likely forming"
                    )
        
        # ==================================================================
        # 9. GENERATE SIGNAL
        # ==================================================================
        # Only generate signal if confidence is meaningful
        if sigmoid_confidence >= 3.0:  # Lowered threshold with sigmoid
            signal_context = self._determine_signal_context(
                current_price, signal_type, sigmoid_confidence
            )
            
            signals.append({
                # Basic info
                'Date': current_date,
                'Price': current_price,
                'Signal': signal_type,
                'Signal_Context': signal_context,
                'Strength': round(sigmoid_confidence, 1),
                'Reasons': reasons,
                
                # Original components
                'Lunar_Phase': lunar_phase,
                'Lunar_Strength': lunar_strength,
                'Gann_Strength': gann_strength,
                'Elliott_Strength': elliott_strength,
                'Wave_Type': wave_type,
                'Quality_Score': confirmations,
                
                # NEW: Relative Strength data
                'RS_Data': rs_data if rs_data else None,
                'RS_Signal': rs_data.get('rs_signal', 'N/A') if rs_data else 'N/A',
                'RS_Outperformance': rs_data.get('outperformance_pct', 0) if rs_data else 0,
                
                # NEW: Probabilistic targets
                'Prob_Targets': prob_targets,
                'Target_Exits': target_exits,
                
                # NEW: Cycle projections
                'Cycle_Projections': cycle_projections,
                'Next_Key_Date': next_key_date,
                
                # Component scores (for transparency)
                'Component_Scores': {
                    'elliott': round(elliott_score_normalized, 1),
                    'gann': round(gann_score_normalized, 1),
                    'momentum': round(momentum_score, 1),
                    'volume': round(volume_score, 1),
                    'rs': round(rs_score, 1) if rs_data else 5.0,
                    'raw_score': round(raw_score, 2),
                    'sigmoid_output': round(sigmoid_confidence, 1)
                },
                
                # Legacy components (for backward compatibility)
                'Components': {
                    'lunar_significant': lunar_significant,
                    'gann_signals': gann_signals,
                    'elliott_pattern': elliott_pattern is not None
                }
            })
        
        return signals
    
    def _determine_signal_context(self, current_price, signal_type, confidence):
        """Determine signal context based on trend analysis and confidence"""
        if self.data is None or len(self.data) < 50:
            return "Unknown"
        
        # Calculate trend indicators
        sma_20 = self.data['Close'].rolling(window=20).mean().iloc[-1]
        sma_50 = self.data['Close'].rolling(window=50).mean().iloc[-1]
        price_vs_sma20 = (current_price - sma_20) / sma_20 * 100
        price_vs_sma50 = (current_price - sma_50) / sma_50 * 100
        
        # Determine trend context
        if price_vs_sma20 > 2 and price_vs_sma50 > 2:
            trend_context = "Strong Uptrend"
        elif price_vs_sma20 > 0 and price_vs_sma50 > 0:
            trend_context = "Uptrend"
        elif price_vs_sma20 < -2 and price_vs_sma50 < -2:
            trend_context = "Strong Downtrend"
        elif price_vs_sma20 < 0 and price_vs_sma50 < 0:
            trend_context = "Downtrend"
        else:
            trend_context = "Sideways"
        
        # Determine signal context
        if confidence >= 8:
            if signal_type == "Buy" and "Uptrend" in trend_context:
                return "BUY for Trend"
            elif signal_type == "Sell" and "Downtrend" in trend_context:
                return "SELL for Trend"
            elif signal_type == "Buy" and "Sideways" in trend_context:
                return "BUY for Swing"
            elif signal_type == "Sell" and "Sideways" in trend_context:
                return "SELL for Swing"
            else:
                return f"{signal_type} (Counter-trend)"
        elif confidence >= 6:
            if "Sideways" in trend_context:
                return f"{signal_type} for Range"
            else:
                return f"{signal_type} (Weak)"
        else:
            return f"{signal_type} (Low Confidence)"
    
    def create_comprehensive_report(self):
        """Generate detailed analysis report"""
        if self.data is None:
            print("No data available. Please fetch market data first.")
            return
        
        signals = self.generate_combined_signals()
        
        print("="*70)
        print("ADVANCED MARKET ANALYSIS REPORT - KITE CONNECT")
        print("="*70)
        print(f"Symbol: {self.symbol}")
        print(f"Instrument Token: {self.instrument_token}")
        print(f"Analysis Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} IST")
        print(f"Data Period: {self.data.index[0].strftime('%Y-%m-%d')} to {self.data.index[-1].strftime('%Y-%m-%d')}")
        print(f"Total Trading Sessions: {len(self.data)}")
        print()
        
        # Current Market Status
        current_price = self.data['Close'].iloc[-1]
        prev_price = self.data['Close'].iloc[-2]
        high_52w = self.data['High'].max()
        low_52w = self.data['Low'].min()
        price_change = ((current_price - prev_price) / prev_price) * 100
        
        print("CURRENT MARKET STATUS:")
        print(f"Current Price: ₹{current_price:.2f}")
        print(f"Previous Close: ₹{prev_price:.2f}")
        print(f"Price Change: {price_change:+.2f}%")
        print(f"52-Week High: ₹{high_52w:.2f}")
        print(f"52-Week Low: ₹{low_52w:.2f}")
        print(f"Distance from 52W High: {((current_price - high_52w) / high_52w * 100):+.2f}%")
        print(f"Distance from 52W Low: {((current_price - low_52w) / low_52w * 100):+.2f}%")
        print()
        
        # Lunar Cycle Analysis
        today = datetime.now()
        lunar_phase = self.lunar_analyzer.get_lunar_phase(today)
        lunar_strength = self.lunar_analyzer.get_lunar_influence_strength(today)
        lunar_significant = self.lunar_analyzer.is_significant_lunar_period(today)
        
        print("LUNAR CYCLE ANALYSIS:")
        print(f"Current Phase: {lunar_phase}")
        print(f"Influence Strength: {lunar_strength}/3")
        print(f"Significant Period: {'Yes' if lunar_significant else 'No'}")
        
        # Next significant lunar events
        next_new_moon_days = None
        next_full_moon_days = None
        for i in range(1, 30):
            future_date = today + timedelta(days=i)
            phase = self.lunar_analyzer.get_lunar_phase(future_date)
            if phase == "New Moon" and next_new_moon_days is None:
                next_new_moon_days = i
            if phase == "Full Moon" and next_full_moon_days is None:
                next_full_moon_days = i
            if next_new_moon_days and next_full_moon_days:
                break
        
        if next_new_moon_days:
            print(f"Next New Moon: {next_new_moon_days} days")
        if next_full_moon_days:
            print(f"Next Full Moon: {next_full_moon_days} days")
        print()
        
        # Gann Theory Analysis
        print("GANN THEORY ANALYSIS:")
        gann_signals = self.gann_analyzer.get_gann_signals(current_price)
        square_levels = self.gann_analyzer.find_gann_squares(current_price)
        
        print(f"Current Gann Squares: {[f'₹{level:.0f}' for level in square_levels[:5]]}")
        
        nearest_support = max([level for level in square_levels if level < current_price], default=None)
        nearest_resistance = min([level for level in square_levels if level > current_price], default=None)
        
        if nearest_support:
            print(f"Nearest Support: ₹{nearest_support:.2f} ({((current_price - nearest_support) / current_price * 100):.2f}% below)")
        if nearest_resistance:
            print(f"Nearest Resistance: ₹{nearest_resistance:.2f} ({((nearest_resistance - current_price) / current_price * 100):.2f}% above)")
        
        if gann_signals:
            print("Active Gann Signals:")
            for signal in gann_signals:
                print(f"  - {signal['type']}: {signal['signal']} at ₹{signal['level']:.2f} (Strength: {signal['strength']})")
        else:
            print("No active Gann signals")
        print()
        
        # Enhanced Elliott Wave Analysis
        print("ENHANCED ELLIOTT WAVE ANALYSIS:")
        elliott_pattern = self.elliott_analyzer.detect_wave_pattern()
        
        if elliott_pattern:
            print(f"Pattern Detected (Strength: {elliott_pattern['pattern_strength']}/10)")
            print(f"Wave Type: {elliott_pattern.get('wave_type', 'Unknown')}")
            print(f"Wave Degree: {elliott_pattern.get('wave_degree', 'Unknown')}")
            print(f"Confidence Score: {elliott_pattern.get('confidence_score', 0):.1f}/10")
            print()
            
            print("Wave Structure:")
            for wave_name, wave_data in elliott_pattern['analysis'].items():
                print(f"  {wave_name}: ₹{wave_data['price']:.2f} ({wave_data['type']}) on {wave_data['date'].strftime('%Y-%m-%d')}")
                if 'move_size' in wave_data:
                    print(f"    Movement: {wave_data['direction']} ₹{wave_data['move_size']:.2f} over {wave_data['days']} days")
                if 'strength' in wave_data:
                    print(f"    Wave Strength: {wave_data['strength']}/6")
            
            # Enhanced Fibonacci analysis
            if 'fibonacci_analysis' in elliott_pattern and elliott_pattern['fibonacci_analysis']:
                fib_analysis = elliott_pattern['fibonacci_analysis']
                print()
                print("Fibonacci Relationship Analysis:")
                
                if 'w3_w1_ratio' in fib_analysis:
                    print(f"  Wave 3/Wave 1 Ratio: {fib_analysis['w3_w1_ratio']:.3f}")
                if 'w5_w1_ratio' in fib_analysis:
                    print(f"  Wave 5/Wave 1 Ratio: {fib_analysis['w5_w1_ratio']:.3f}")
                if 'w5_w3_ratio' in fib_analysis:
                    print(f"  Wave 5/Wave 3 Ratio: {fib_analysis['w5_w3_ratio']:.3f}")
                
                if 'fibonacci_matches' in fib_analysis and fib_analysis['fibonacci_matches']:
                    print("  Fibonacci Matches:")
                    for match in fib_analysis['fibonacci_matches']:
                        print(f"    ✓ {match}")
                
                print(f"  Fibonacci Score: {fib_analysis.get('fibonacci_score', 0)}/3")
            
            # Traditional Fibonacci levels
            waves = elliott_pattern['waves']
            if len(waves) >= 3:
                fib_levels = self.elliott_analyzer.calculate_fibonacci_levels(
                    waves[-1]['price'], waves[-3]['price']
                )
                print()
                print("Key Fibonacci Retracement Levels:")
                for ratio, level in list(fib_levels.items())[:5]:
                    distance = ((level - current_price) / current_price * 100)
                    print(f"  {ratio}: ₹{level:.2f} ({distance:+.2f}%)")
        else:
            print("No clear Elliott Wave pattern detected in recent data")
            print("Analyzing recent peaks and troughs with enhanced detection...")
            peaks, troughs = self.elliott_analyzer.enhanced_peak_trough_detection(self.data, min_strength=2)
            if peaks or troughs:
                recent_points = sorted((peaks + troughs)[-5:], key=lambda x: x['index'])
                for point in recent_points:
                    strength_info = f" (Strength: {point.get('strength', 0)}/6)" if 'strength' in point else ""
                    print(f"  {point['type']}: ₹{point['price']:.2f} on {point['date'].strftime('%Y-%m-%d')}{strength_info}")
        print()
        
        # Combined Analysis & Signals
        print("INTEGRATED TRADING SIGNALS:")
        if signals:
            for signal in signals:
                print(f"SIGNAL: {signal['Signal'].upper()}")
                print(f"Signal Context: {signal.get('Signal_Context', 'Standard')}")
                print(f"Confidence: {signal['Strength']}/10")
                print(f"Current Price: ₹{signal['Price']:.2f}")
                print(f"Lunar Phase: {signal['Lunar_Phase']}")
                
                # NEW: Show sigmoid scoring breakdown
                if 'Component_Scores' in signal:
                    scores = signal['Component_Scores']
                    print()
                    print("📊 SIGMOID CONFIDENCE SCORING:")
                    print(f"  Raw Score: {scores['raw_score']}")
                    print(f"  Final Confidence (Sigmoid): {scores['sigmoid_output']}/10")
                    print()
                    print("  Component Breakdown:")
                    print(f"    • Elliott Wave: {scores['elliott']}/10 (weight: {config.weight_elliott:.0%})")
                    print(f"    • Gann Theory: {scores['gann']}/10 (weight: {config.weight_gann:.0%})")
                    print(f"    • Momentum (RSI): {scores['momentum']}/10 (weight: {config.weight_momentum:.0%})")
                    print(f"    • Volume Confirmation: {scores['volume']}/10 (weight: {config.weight_volume:.0%})")
                    if 'rs' in scores:
                        print(f"    • Relative Strength: {scores['rs']}/10")
                
                # NEW: Show Relative Strength analysis
                if signal.get('RS_Data'):
                    rs_data = signal['RS_Data']
                    print()
                    print("📈 RELATIVE STRENGTH vs NIFTY 50:")
                    print(f"  Status: {signal['RS_Signal']}")
                    print(f"  Outperformance: {signal['RS_Outperformance']:.2f}%")
                    print(f"  RS Ratio: {rs_data['rs_ratio']:.4f}")
                    print(f"  RS Rank (20d): {rs_data['rs_rank']:.0%}")
                    print(f"  Trend Consistent: {'Yes ✓' if rs_data['trend_consistent'] else 'No'}")
                    print(f"  Action: {rs_data['rs_action']}")
                
                print()
                print("Signal Components (Legacy):")
                print(f"  • Lunar Strength: {signal['Lunar_Strength']}/3")
                print(f"  • Gann Strength: {signal['Gann_Strength']}")
                print(f"  • Elliott Strength: {signal['Elliott_Strength']}")
                
                # NEW: Show Probabilistic Targets
                if signal.get('Prob_Targets'):
                    print()
                    print("🎯 PROBABILISTIC PRICE TARGETS:")
                    for target_label, target_data in signal['Prob_Targets'].items():
                        print(f"  {target_label}:")
                        print(f"    Price: ₹{target_data['price']:.2f}")
                        print(f"    Probability: {target_data['probability']:.0%}")
                        print(f"    Distance: {target_data['distance_pct']:+.2f}%")
                    
                    # Show recommended exit strategy
                    if signal.get('Target_Exits'):
                        print()
                        print("  📋 Recommended Exit Strategy:")
                        for exit_rec in signal['Target_Exits']:
                            print(f"    {exit_rec['label']}: Exit {exit_rec['exit_percentage']:.0%} at ₹{exit_rec['price']:.2f}")
                
                # NEW: Show Cycle Projections
                if signal.get('Next_Key_Date'):
                    next_date = signal['Next_Key_Date']
                    print()
                    print("⏰ CYCLE PROJECTION (Time-based):")
                    
                    # Check if projection is in the past
                    if next_date.get('is_past', False):
                        print(f"  ⚠️ Last projected inflection was: {next_date['date'].strftime('%Y-%m-%d')} ({abs(next_date['days_from_now'])} days ago)")
                        print(f"  Status: CYCLE COMPLETED - New pattern likely forming")
                    else:
                        print(f"  Next Inflection: {next_date['date'].strftime('%Y-%m-%d')}")
                        print(f"  Days Away: {next_date['days_from_now']}")
                        print(f"  Fibonacci Multiplier: {next_date['multiplier']}x")
                        print(f"  Confidence: {next_date['confidence']:.0%}")
                    
                    print(f"  Avg Wave Duration: {next_date['avg_wave_duration']:.1f} days")
                    
                    # Show all projections
                    if signal.get('Cycle_Projections'):
                        future_projs = {k: v for k, v in signal['Cycle_Projections'].items() 
                                       if not v.get('is_past', False)}
                        past_projs = {k: v for k, v in signal['Cycle_Projections'].items() 
                                     if v.get('is_past', False)}
                        
                        if future_projs:
                            print()
                            print("  Future Projected Inflection Points:")
                            for proj_label, proj_data in future_projs.items():
                                print(f"    {proj_label}: {proj_data['date'].strftime('%Y-%m-%d')} ({proj_data['days_from_now']} days)")
                        
                        if past_projs:
                            print()
                            print("  Recently Completed Inflection Points:")
                            for proj_label, proj_data in past_projs.items():
                                print(f"    {proj_label}: {proj_data['date'].strftime('%Y-%m-%d')} ({abs(proj_data['days_from_now'])} days ago)")
                
                print()
                print("💡 Reasoning:")
                for i, reason in enumerate(signal['Reasons'], 1):
                    print(f"  {i}. {reason}")
                
                print()
                print("=" * 70)
                print("TRADING RECOMMENDATION:")
                if signal['Signal'] == 'Buy':
                    print("• Position: LONG")
                    print("• Entry: Current levels or on dips")
                    if nearest_support:
                        print(f"• Stop Loss: Below ₹{nearest_support:.2f}")
                    if nearest_resistance:
                        print(f"• Target: ₹{nearest_resistance:.2f}")
                elif signal['Signal'] == 'Sell':
                    print("• Position: SHORT")
                    print("• Entry: Current levels or on rallies")
                    if nearest_resistance:
                        print(f"• Stop Loss: Above ₹{nearest_resistance:.2f}")
                    if nearest_support:
                        print(f"• Target: ₹{nearest_support:.2f}")
                else:
                    print("• Position: HOLD")
                    print("• Wait for clearer signals")
                
                print(f"• Risk Level: {'High' if signal['Strength'] < 5 else 'Medium' if signal['Strength'] < 7 else 'Low'}")
        else:
            print("No significant signals generated at this time.")
            print("Recommendation: HOLD current positions and wait for clearer market direction.")
        
        print()
        print("MARKET OUTLOOK:")
        
        # Technical momentum
        sma_20 = self.data['Close'].rolling(20).mean().iloc[-1]
        sma_50 = self.data['Close'].rolling(50).mean().iloc[-1]
        
        if current_price > sma_20 > sma_50:
            trend = "BULLISH"
        elif current_price < sma_20 < sma_50:
            trend = "BEARISH"
        else:
            trend = "SIDEWAYS"
        
        print(f"Short-term Trend: {trend}")
        print(f"20-day SMA: ₹{sma_20:.2f}")
        print(f"50-day SMA: ₹{sma_50:.2f}")
        
        # Volatility analysis
        returns = self.data['Close'].pct_change().dropna()
        volatility = returns.std() * np.sqrt(252) * 100
        avg_volume = self.data['Volume'].mean()
        recent_volume = self.data['Volume'].iloc[-5:].mean()
        volume_ratio = recent_volume / avg_volume
        
        print(f"Annualized Volatility: {volatility:.1f}%")
        print(f"Volume Activity: {'High' if volume_ratio > 1.2 else 'Normal' if volume_ratio > 0.8 else 'Low'}")
        
        print()
        print("RISK MANAGEMENT:")
        print("• Position Size: Risk maximum 2% of capital per trade")
        print("• Use stop losses as indicated above")
        print("• Monitor lunar and Gann levels for exit signals")
        print("• Review positions during significant lunar phases")
        
        print()
        print("DISCLAIMER:")
        print("• This analysis combines traditional technical analysis with esoteric methods")
        print("• Past performance does not guarantee future results")
        print("• Markets can remain irrational longer than you can remain solvent")
        print("• Always consult with a qualified financial advisor")
        print("• Use proper risk management and position sizing")
        print("="*70)

def setup_kite_connection():
    """Helper function to setup Kite Connect"""
    print("Setting up Kite Connect API...")
    print()
    
    api_key = input("Enter your Kite Connect API Key: ").strip()
    
    if not api_key:
        print("API Key is required. Please get one from https://developers.kite.trade/")
        return None, None
    
    # Check if user has access token
    has_token = input("Do you have an access token? (y/n): ").lower().strip()
    
    if has_token == 'y':
        access_token = input("Enter your access token: ").strip()
        return api_key, access_token
    else:
        print("\nTo get an access token:")
        print("1. Go to the login URL that will be displayed")
        print("2. Login with your Kite credentials")
        print("3. Copy the 'request_token' from the redirect URL")
        print("4. Enter it below along with your API secret")
        
        kite_helper = KiteDataProvider(api_key)
        login_url = kite_helper.get_login_url()
        
        if login_url:
            print(f"\nLogin URL: {login_url}")
            print("\nAfter logging in, you'll be redirected to a URL like:")
            print("https://your-redirect-url/?request_token=XXXXXX&action=login&status=success")
            
            request_token = input("\nEnter the request_token from the URL: ").strip()
            api_secret = input("Enter your API secret: ").strip()
            
            if request_token and api_secret:
                access_token = kite_helper.set_access_token(request_token, api_secret)
                return api_key, access_token
        
        return api_key, None

def get_instrument_token():
    """Helper to get instrument token for different symbols"""
    print("\nSelect instrument:")
    print("1. NIFTY 50 (Default)")
    print("2. BANK NIFTY") 
    print("3. Custom symbol")
    
    choice = input("Enter choice (1-3): ").strip()
    
    instruments = {
        '1': {'name': 'NIFTY 50', 'token': 256265},
        '2': {'name': 'NIFTY BANK', 'token': 260105}
    }
    
    if choice in instruments:
        return instruments[choice]['name'], instruments[choice]['token']
    elif choice == '3':
        symbol = input("Enter trading symbol (e.g., RELIANCE, TCS): ").strip().upper()
        print(f"You'll need to find the instrument token for {symbol}")
        print("The script will attempt to find it automatically")
        return symbol, None
    else:
        return 'NIFTY 50', 256265

def create_token_mapping_file(api_key: str, access_token: str, 
                             symbols_list: List[str], 
                             output_file: Optional[Union[str, Path]] = None) -> Optional[Dict[str, int]]:
    """
    Create a mapping file of symbols to tokens to avoid repeated API calls.
    
    Args:
        api_key: Kite Connect API key
        access_token: Kite Connect access token
        symbols_list: List of trading symbols
        output_file: Path to output JSON file
        
    Returns:
        Dictionary mapping symbols to tokens, or None if error
    """
    try:
        if output_file is None:
            output_file = Path("token_mapping.json")
        else:
            output_file = Path(output_file)
        
        logger.info(f"Creating token mapping file for {len(symbols_list)} symbols...")
        print(f"🔧 Creating token mapping file for {len(symbols_list)} symbols...")
        
        data_provider = KiteDataProvider(api_key, access_token)
        token_mapping = {}
        
        # Get all instruments once
        instruments = data_provider.get_instruments()
        
        if instruments is not None:
            logger.info(f"Processing {len(instruments)} instruments...")
            print(f"✅ Processing {len(instruments)} instruments...")
            
            for symbol in symbols_list:
                symbol_clean = symbol.strip().upper()
                found = False
                
                # Try NSE first (most common)
                filtered = instruments[
                    (instruments['tradingsymbol'] == symbol_clean) & 
                    (instruments['exchange'] == 'NSE')
                ]
                
                if filtered.empty:
                    # Try with -EQ suffix (some symbols need it)
                    if not symbol_clean.endswith('-EQ'):
                        filtered = instruments[
                            (instruments['tradingsymbol'] == f"{symbol_clean}-EQ") & 
                            (instruments['exchange'] == 'NSE')
                        ]
                
                if filtered.empty:
                    # Try BSE as fallback
                    filtered = instruments[
                        (instruments['tradingsymbol'] == symbol_clean) & 
                        (instruments['exchange'] == 'BSE')
                    ]
                
                if not filtered.empty:
                    token_mapping[symbol_clean] = int(filtered.iloc[0]['instrument_token'])
                    logger.debug(f"{symbol_clean}: {int(filtered.iloc[0]['instrument_token'])}")
                    # Only print every 100th found symbol to reduce spam
                    if len(token_mapping) % 100 == 0:
                        print(f"✅ Mapped {len(token_mapping)} symbols...")
                else:
                    token_mapping[symbol_clean] = None
                    logger.debug(f"{symbol_clean}: Not found in NSE/BSE")
        
        # Save mapping to file
        with open(output_file, 'w') as f:
            json.dump(token_mapping, f, indent=2)
        
        logger.info(f"Token mapping saved to {output_file}")
        print(f"💾 Token mapping saved to {output_file}")
        return token_mapping
        
    except Exception as e:
        logger.error(f"Error creating token mapping: {e}", exc_info=True)
        print(f"❌ Error creating token mapping: {e}")
        return None

def load_token_mapping(mapping_file: Optional[Union[str, Path]] = None) -> Optional[Dict[str, int]]:
    """
    Load token mapping from file.
    
    Args:
        mapping_file: Path to token mapping JSON file
        
    Returns:
        Dictionary mapping symbols to tokens, or None if not found
    """
    try:
        if mapping_file is None:
            mapping_file = Path("token_mapping.json")
        else:
            mapping_file = Path(mapping_file)
            
        with open(mapping_file, 'r') as f:
            mapping = json.load(f)
        logger.info(f"Loaded token mapping with {len(mapping)} symbols from {mapping_file}")
        return mapping
    except FileNotFoundError:
        logger.warning(f"Token mapping file {mapping_file} not found")
        print(f"⚠️  Token mapping file {mapping_file} not found")
        return None
    except Exception as e:
        logger.error(f"Error loading token mapping: {e}", exc_info=True)
        print(f"❌ Error loading token mapping: {e}")
        return None

def run_scanner(api_key: str, access_token: str, 
                input_file: Optional[str] = None, 
                days: int = 180, 
                output_file: Optional[str] = None) -> Optional[pd.DataFrame]:
    """
    Run scanner mode to analyze multiple symbols from CSV input.
    
    Args:
        api_key: Kite Connect API key
        access_token: Kite Connect access token
        input_file: Path to input CSV file (default: data/MCAP-great2500.csv)
        days: Number of days of historical data (default: 180)
        output_file: Path to output CSV file (default: scanner_output_<date>.csv)
        
    Returns:
        DataFrame with analysis results, or None if error
    """
    try:
        # Set default paths using cross-platform Path
        if input_file is None:
            input_file = Path("data") / "MCAP-great2500.csv"
        else:
            input_file = Path(input_file)
            
        if output_file is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = Path(f"scanner_output_{timestamp}.csv")
        else:
            output_file = Path(output_file)
        
        logger.info(f"Starting scanner with input: {input_file}, output: {output_file}")
        
        # Read symbols from CSV
        symbols_df = pd.read_csv(input_file)
        
        # Validate required columns
        if 'Symbol' not in symbols_df.columns:
            print(f"❌ Error: 'Symbol' column not found in {input_file}")
            print("Required CSV format: Symbol")
            return
        
        results = []
        analyzer = IntegratedMarketAnalyzer(api_key, access_token)
        
        # Load or create token mapping
        token_mapping = load_token_mapping()
        if token_mapping is None:
            print("🔧 Creating token mapping file...")
            symbols_list = symbols_df['Symbol'].tolist()
            token_mapping = create_token_mapping_file(api_key, access_token, symbols_list)
            if token_mapping is None:
                print("❌ Failed to create token mapping. Exiting...")
                return None
        
        logger.info(f"Starting scanner analysis for {len(symbols_df)} symbols...")
        print("="*70)
        print(f"🔍 Starting scanner analysis for {len(symbols_df)} symbols...")
        
        # Fetch instruments ONCE for all dynamic lookups (avoid rate limiting)
        shared_instruments = None
        try:
            temp_provider = KiteDataProvider(api_key, access_token)
            shared_instruments = temp_provider.get_instruments()
            if shared_instruments is not None:
                logger.info(f"Shared instruments cache loaded ({len(shared_instruments)} instruments)")
            else:
                logger.warning("Could not load shared instruments - dynamic lookup will be disabled")
        except Exception as e:
            logger.error(f"Error loading shared instruments: {e}")
            shared_instruments = None
        
        def analyze_single_symbol(symbol_data: Tuple[int, str]) -> Dict[str, Any]:
            """
            Analyze a single symbol (to be used with parallel processing).
            
            Args:
                symbol_data: Tuple of (index, symbol)
                
            Returns:
                Dictionary with analysis results
            """
            index, symbol = symbol_data
            symbol = symbol.strip().upper()
            
            logger.info(f"Analyzing {symbol} ({index+1}/{len(symbols_df)})")
            # Only print every 50th symbol to reduce spam (still log all)
            if (index + 1) % 50 == 0 or index == 0:
                print(f"\n📊 Analyzing {symbol} ({index+1}/{len(symbols_df)})")
                print("-" * 50)
            
            # Get token from mapping (much faster than API calls)
            token = token_mapping.get(symbol)
            
            # Handle different token types
            if token is None:
                # Try fallback: dynamic lookup using SHARED instruments (avoids rate limiting!)
                logger.info(f"Symbol {symbol} not in mapping, trying dynamic lookup...")
                
                if shared_instruments is not None and not shared_instruments.empty:
                    # Use shared instruments cache (NO API CALL)
                    found_token = None
                    
                    # Try NSE first
                    filtered = shared_instruments[
                        (shared_instruments['tradingsymbol'] == symbol) & 
                        (shared_instruments['exchange'] == 'NSE')
                    ]
                    
                    if filtered.empty and not symbol.endswith('-EQ'):
                        # Try with -EQ suffix
                        filtered = shared_instruments[
                            (shared_instruments['tradingsymbol'] == f"{symbol}-EQ") & 
                            (shared_instruments['exchange'] == 'NSE')
                        ]
                    
                    if filtered.empty:
                        # Try BSE
                        filtered = shared_instruments[
                            (shared_instruments['tradingsymbol'] == symbol) & 
                            (shared_instruments['exchange'] == 'BSE')
                        ]
                    
                    if not filtered.empty:
                        found_token = int(filtered.iloc[0]['instrument_token'])
                        logger.info(f"Found {symbol} via dynamic lookup: {found_token}")
                        token = found_token
                
                if token is None:
                    # Still not found - invalid symbol
                    logger.warning(f"Symbol {symbol} not found in Kite Connect database (invalid/delisted)")
                    # Don't print for every missing symbol to reduce spam
                    return {
                        "Symbol": symbol,
                        "Price": 0,
                        "Signal": "ERROR",
                        "Confidence": 0,
                        "Reasons": "Symbol not found in Kite Connect (invalid or delisted)",
                        "Support/Target": "N/A",
                        "Lunar_Phase": "N/A",
                        "Gann_Levels": "N/A",
                        "Elliott_Pattern": "N/A"
                    }
            else:
                logger.info(f"Using token for {symbol}: {token} (from mapping)")
            
            # Only print token confirmation for found symbols to reduce spam
            if token and not isinstance(token, str):
                print(f"✅ Using token for {symbol}: {token}")
            
            # Create a new analyzer for this symbol (thread-safe)
            symbol_analyzer = IntegratedMarketAnalyzer(api_key, access_token)
            symbol_analyzer.symbol = symbol
            symbol_analyzer.instrument_token = token
            
            # Fetch market data with error handling
            try:
                if symbol_analyzer.fetch_market_data(days=days):
                    signals = symbol_analyzer.generate_combined_signals()
                    
                    if signals:
                        sig = signals[0]
                        
                        # Extract Gann levels for support/target
                        gann_levels = []
                        if 'Components' in sig and 'gann_signals' in sig['Components']:
                            for gann_sig in sig['Components']['gann_signals']:
                                gann_levels.append(f"{gann_sig['signal']}: {gann_sig['level']:.2f}")
                        
                        result = {
                            "Symbol": symbol,
                            "Price": sig['Price'],
                            "Signal": sig['Signal'],
                            "Confidence": sig['Strength'],
                            "Reasons": "; ".join(sig['Reasons']),
                            "Support/Target": "; ".join(gann_levels) if gann_levels else "N/A",
                            "Lunar_Phase": sig.get('Lunar_Phase', 'N/A'),
                            "Gann_Levels": len(sig.get('Components', {}).get('gann_signals', [])),
                            "Elliott_Pattern": "Yes" if sig.get('Components', {}).get('elliott_pattern', False) else "No"
                        }
                        
                        # Print enhanced summary for this symbol
                        wave_type = sig.get('Wave_Type', 'None')
                        quality_score = sig.get('Quality_Score', 0)
                        
                        print(f"✅ {symbol}: {sig['Signal']} (Confidence: {sig['Strength']}/10)")
                        print(f"   Price: ₹{sig['Price']:.2f} | Lunar: {sig.get('Lunar_Phase', 'N/A')}")
                        
                        # Show enhanced quality metrics
                        if wave_type != 'None':
                            print(f"   Elliott: {wave_type} | Quality: {quality_score}/3")
                        
                        if gann_levels:
                            print(f"   Gann: {'; '.join(gann_levels[:2])}")
                        
                        return result
                        
                    else:
                        result = {
                            "Symbol": symbol,
                            "Price": symbol_analyzer.data['Close'].iloc[-1] if symbol_analyzer.data is not None else 0,
                            "Signal": "HOLD",
                            "Confidence": 0,
                            "Reasons": "No significant signals detected",
                            "Support/Target": "N/A",
                            "Lunar_Phase": symbol_analyzer.lunar_analyzer.get_lunar_phase(datetime.now()),
                            "Gann_Levels": 0,
                            "Elliott_Pattern": "No"
                        }
                        print(f"⚠️  {symbol}: HOLD (No clear signals)")
                        return result
                else:
                    logger.warning(f"❌ Failed to fetch data for {symbol}")
                    print(f"❌ Failed to fetch data for {symbol}")
                    return {
                        "Symbol": symbol,
                        "Price": 0,
                        "Signal": "ERROR",
                        "Confidence": 0,
                        "Reasons": "Failed to fetch market data",
                        "Support/Target": "N/A",
                        "Lunar_Phase": "N/A",
                        "Gann_Levels": "N/A",
                        "Elliott_Pattern": "N/A"
                    }
            except Exception as e:
                logger.error(f"❌ Error analyzing {symbol}: {e}", exc_info=True)
                print(f"❌ Error analyzing {symbol}: {e}")
                return {
                    "Symbol": symbol,
                    "Price": 0,
                    "Signal": "ERROR",
                    "Confidence": 0,
                    "Reasons": f"Analysis error: {str(e)[:100]}",
                    "Support/Target": "N/A",
                    "Lunar_Phase": "N/A",
                    "Gann_Levels": "N/A",
                    "Elliott_Pattern": "N/A"
                }
        
        # Use parallel processing to analyze symbols
        symbols_to_analyze = [(idx, row['Symbol']) for idx, row in symbols_df.iterrows()]
        
        # Sequential processing for now (can enable parallel later)
        # Note: Kite API has rate limits, so parallel processing might hit limits
        # For production, consider implementing adaptive rate limiting
        results = []
        use_parallel = config.scanner_parallel_workers > 1 and len(symbols_to_analyze) > 5
        
        if use_parallel:
            logger.info(f"Using parallel processing with {config.scanner_parallel_workers} workers")
            with ThreadPoolExecutor(max_workers=config.scanner_parallel_workers) as executor:
                future_to_symbol = {
                    executor.submit(analyze_single_symbol, symbol_data): symbol_data[1] 
                    for symbol_data in symbols_to_analyze
                }
                
                for future in as_completed(future_to_symbol):
                    try:
                        result = future.result(timeout=config.scanner_timeout_seconds)
                        results.append(result)
                    except Exception as e:
                        symbol = future_to_symbol[future]
                        logger.error(f"Error in parallel analysis of {symbol}: {e}")
                        results.append({
                            "Symbol": symbol,
                            "Price": 0,
                            "Signal": "ERROR",
                            "Confidence": 0,
                            "Reasons": f"Timeout or error: {str(e)[:100]}",
                            "Support/Target": "N/A",
                            "Lunar_Phase": "N/A",
                            "Gann_Levels": "N/A",
                            "Elliott_Pattern": "N/A"
                        })
        else:
            logger.info("Using sequential processing (safer for API rate limits)")
            for symbol_data in symbols_to_analyze:
                result = analyze_single_symbol(symbol_data)
                results.append(result)
        
        # Export results to CSV
        results_df = pd.DataFrame(results)
        results_df.to_csv(output_file, index=False)
        
        logger.info(f"Scanner complete! Results saved to {output_file}")
        print("\n" + "="*70)
        print(f"✅ Scanner complete! Results saved to {output_file}")
        print("="*70)
        
        # Separate valid and invalid symbols
        valid_symbols = results_df[results_df['Signal'] != 'ERROR']
        invalid_symbols = results_df[results_df['Signal'] == 'ERROR']
        
        # Save invalid symbols to separate file
        if len(invalid_symbols) > 0:
            invalid_file = output_file.parent / f"invalid_symbols_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            invalid_symbols[['Symbol', 'Reasons']].to_csv(invalid_file, index=False)
            logger.info(f"Invalid symbols list saved to {invalid_file}")
            print(f"⚠️  Invalid symbols list saved to: {invalid_file}")
        
        # Print summary statistics
        signal_counts = valid_symbols['Signal'].value_counts()
        logger.info(f"Analyzed {len(results_df)} symbols, {len(valid_symbols)} successful, {len(invalid_symbols)} invalid")
        
        print("\n📈 SCANNER SUMMARY:")
        print(f"Total symbols processed: {len(results_df)}")
        print(f"✅ Valid symbols analyzed: {len(valid_symbols)}")
        print(f"❌ Invalid/delisted symbols: {len(invalid_symbols)}")
        
        if len(valid_symbols) > 0:
            print("\n📊 Signal distribution (valid symbols only):")
            for signal, count in signal_counts.items():
                percentage = (count / len(valid_symbols)) * 100
                print(f"  {signal}: {count} ({percentage:.1f}%)")
        
        # Show top signals by confidence
        if len(valid_symbols) > 0:
            top_signals = valid_symbols[valid_symbols['Confidence'] > 0].nlargest(5, 'Confidence')
            if not top_signals.empty:
                print("\n🎯 TOP SIGNALS BY CONFIDENCE:")
                for _, row in top_signals.iterrows():
                    print(f"  {row['Symbol']}: {row['Signal']} (Confidence: {row['Confidence']}/10)")
        
        # Show sample of invalid symbols with explanation
        if len(invalid_symbols) > 0:
            print(f"\n⚠️  INVALID SYMBOLS SUMMARY:")
            print(f"  Total invalid: {len(invalid_symbols)} ({(len(invalid_symbols)/len(results_df)*100):.1f}%)")
            print(f"  Reasons:")
            
            invalid_reasons = invalid_symbols['Reasons'].value_counts()
            for reason, count in invalid_reasons.items():
                print(f"    • {reason}: {count}")
            
            print(f"\n  💡 Common reasons for invalid symbols:")
            print(f"     • Symbol not listed on NSE/BSE (may be delisted)")
            print(f"     • Wrong symbol name in CSV (typo or old name)")
            print(f"     • Futures/Options only (not equity)")
            print(f"     • Suspended/temporarily unavailable")
            print(f"\n  📄 Full list saved to: {invalid_file if len(invalid_symbols) > 0 else 'N/A'}")
        
        return results_df
        
    except FileNotFoundError as e:
        logger.error(f"Input file '{input_file}' not found")
        print(f"❌ Error: Input file '{input_file}' not found.")
        print("Please create an input.csv file with a 'Symbol' column containing stock symbols.")
        return None
    except Exception as e:
        logger.error(f"Error running scanner: {e}", exc_info=True)
        print(f"❌ Error running scanner: {e}")
        return None

def main():
    """Enhanced main function with scanner mode support"""
    print("="*60)
    print("ADVANCED MARKET ANALYSIS SYSTEM")
    print("Lunar Cycles + Gann Theory + Elliott Waves")
    print("Powered by Kite Connect API")
    print("="*60)
    print()
    
    # Setup Kite connection
    api_key, access_token = setup_kite_connection()
    
    if not api_key:
        print("Cannot proceed without API key. Exiting...")
        return
    
    if not access_token:
        print("Cannot proceed without access token. Please complete the authentication process.")
        return
    
    # Choose analysis mode
    print("\nAnalysis Mode:")
    print("1. Single Symbol Analysis (Interactive)")
    print("2. Scanner Mode (Batch CSV Processing)")
    
    choice = input("Select mode (1-2): ").strip()
    
    if choice == '2':
        # Scanner mode
        input_file = input("Enter input CSV file path (default: input.csv): ").strip()
        if not input_file:
            input_file = "input.csv"
        
        output_file = input("Enter output CSV file path (default: scanner_output.csv): ").strip()
        if not output_file:
            output_file = "scanner_output.csv"
        
        days = input("Enter analysis period in days (default: 180): ").strip()
        try:
            days = int(days) if days else 180
        except ValueError:
            days = 180
        
        run_scanner(api_key, access_token, input_file, days, output_file)
        return
    
    # Single symbol analysis mode (original functionality)
    symbol, instrument_token = get_instrument_token()
    
    print(f"\nInitializing analysis for {symbol}...")
    
    # Initialize analyzer
    analyzer = IntegratedMarketAnalyzer(
        api_key=api_key,
        access_token=access_token,
        symbol=symbol,
        instrument_token=instrument_token
    )
    
    # Handle custom symbols
    if instrument_token is None:
        print(f"Finding instrument token for {symbol}...")
        found_token = analyzer.data_provider.find_instrument_token(symbol)
        if found_token:
            analyzer.instrument_token = found_token
            print(f"Found instrument token: {found_token}")
        else:
            print(f"Could not find instrument token for {symbol}")
            print("Please check the symbol or use the default NIFTY 50")
            return
    
    # Fetch data
    success = analyzer.fetch_market_data(days=180)
    
    if success:
        print("\n" + "="*60)
        print("GENERATING COMPREHENSIVE ANALYSIS...")
        print("="*60)
        
        # Generate comprehensive report
        analyzer.create_comprehensive_report()
        
        # Offer additional analysis
        print("\nAdditional Analysis Options:")
        print("1. Generate price chart")
        print("2. Export data to CSV")
        print("3. Show detailed Elliott Wave analysis")
        
        choice = input("Select option (1-3) or press Enter to exit: ").strip()
        
        if choice == '1':
            create_price_chart(analyzer)
        elif choice == '2':
            export_data(analyzer)
        elif choice == '3':
            detailed_elliott_analysis(analyzer)
    
    else:
        print("Failed to fetch market data. Please check:")
        print("• Your internet connection")
        print("• API key and access token validity")
        print("• Instrument token correctness")
        print("• Kite Connect subscription status")

def create_price_chart(analyzer):
    """Create and display price chart with analysis overlays"""
    try:
        plt.style.use('dark_background')
        fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(15, 12))
        
        # Price chart with moving averages
        ax1.plot(analyzer.data.index, analyzer.data['Close'], label=f'{analyzer.symbol} Close', color='white', linewidth=1.5)
        ax1.plot(analyzer.data.index, analyzer.data['Close'].rolling(20).mean(), label='20 SMA', color='orange', alpha=0.8)
        ax1.plot(analyzer.data.index, analyzer.data['Close'].rolling(50).mean(), label='50 SMA', color='cyan', alpha=0.8)
        
        # Add Gann levels
        current_price = analyzer.data['Close'].iloc[-1]
        square_levels = analyzer.gann_analyzer.find_gann_squares(current_price)
        
        for level in square_levels[:3]:
            ax1.axhline(y=level, color='yellow', linestyle='--', alpha=0.5, label=f'Gann Square {level:.0f}')
        
        ax1.set_title(f'{analyzer.symbol} - Advanced Technical Analysis', fontsize=14, color='white')
        ax1.set_ylabel('Price (₹)', color='white')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Volume chart
        colors = ['green' if analyzer.data['Close'].iloc[i] > analyzer.data['Open'].iloc[i] else 'red' 
                 for i in range(len(analyzer.data))]
        ax2.bar(analyzer.data.index, analyzer.data['Volume'], color=colors, alpha=0.7)
        ax2.set_title('Volume Analysis', fontsize=12, color='white')
        ax2.set_ylabel('Volume', color='white')
        ax2.grid(True, alpha=0.3)
        
        # RSI and momentum
        delta = analyzer.data['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        ax3.plot(analyzer.data.index, rsi, label='RSI', color='purple')
        ax3.axhline(y=70, color='red', linestyle='--', alpha=0.7, label='Overbought')
        ax3.axhline(y=30, color='green', linestyle='--', alpha=0.7, label='Oversold')
        ax3.fill_between(analyzer.data.index, 30, 70, alpha=0.1, color='gray')
        ax3.set_title('RSI Momentum', fontsize=12, color='white')
        ax3.set_ylabel('RSI', color='white')
        ax3.set_xlabel('Date', color='white')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        ax3.set_ylim(0, 100)
        
        plt.tight_layout()
        plt.show()
        
    except Exception as e:
        print(f"Error creating chart: {e}")
        print("Make sure matplotlib is installed: pip install matplotlib")

def export_data(analyzer):
    """Export analysis data to CSV"""
    try:
        filename = f"{analyzer.symbol}_analysis_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
        
        # Add analysis columns
        export_data = analyzer.data.copy()
        export_data['SMA_20'] = analyzer.data['Close'].rolling(20).mean()
        export_data['SMA_50'] = analyzer.data['Close'].rolling(50).mean()
        
        # Add lunar phases
        lunar_phases = []
        for date in analyzer.data.index:
            lunar_phases.append(analyzer.lunar_analyzer.get_lunar_phase(date))
        export_data['Lunar_Phase'] = lunar_phases
        
        # Export to CSV
        export_data.to_csv(filename)
        print(f"Data exported to: {filename}")
        
    except Exception as e:
        print(f"Error exporting data: {e}")

def detailed_elliott_analysis(analyzer):
    """Show detailed Elliott Wave analysis"""
    print("\n" + "="*50)
    print("DETAILED ELLIOTT WAVE ANALYSIS")
    print("="*50)
    
    elliott_pattern = analyzer.elliott_analyzer.detect_wave_pattern()
    
    if elliott_pattern:
        waves = elliott_pattern['waves']
        analysis = elliott_pattern['analysis']
        
        print(f"Pattern Strength: {elliott_pattern['pattern_strength']}/5")
        print(f"Completion Date: {elliott_pattern['completion_date'].strftime('%Y-%m-%d')}")
        print()
        
        print("Detailed Wave Analysis:")
        for i, (wave_name, wave_data) in enumerate(analysis.items()):
            print(f"\n{wave_name}:")
            print(f"  Price: ₹{wave_data['price']:.2f}")
            print(f"  Date: {wave_data['date'].strftime('%Y-%m-%d')}")
            print(f"  Type: {wave_data['type']}")
            
            if 'move_size' in wave_data:
                print(f"  Movement: {wave_data['direction']} ₹{wave_data['move_size']:.2f}")
                print(f"  Duration: {wave_data['days']} days")
                
                # Calculate move velocity
                if wave_data['days'] > 0:
                    velocity = wave_data['move_size'] / wave_data['days']
                    print(f"  Velocity: ₹{velocity:.2f}/day")
        
        # Fibonacci analysis between waves
        print("\nFibonacci Relationships:")
        if len(waves) >= 5:
            wave1_size = abs(waves[1]['price'] - waves[0]['price'])
            wave3_size = abs(waves[3]['price'] - waves[2]['price'])
            wave5_size = abs(waves[4]['price'] - waves[3]['price'])
            
            print(f"Wave 3 / Wave 1 ratio: {wave3_size/wave1_size:.3f}")
            print(f"Wave 5 / Wave 1 ratio: {wave5_size/wave1_size:.3f}")
            print(f"Wave 5 / Wave 3 ratio: {wave5_size/wave3_size:.3f}")
            
            # Check for common Fibonacci ratios
            ratios_to_check = [0.618, 1.0, 1.618, 2.618]
            print("\nFibonacci Ratio Matches:")
            
            for ratio in ratios_to_check:
                w3_w1_diff = abs((wave3_size/wave1_size) - ratio)
                w5_w1_diff = abs((wave5_size/wave1_size) - ratio)
                
                if w3_w1_diff < 0.1:
                    print(f"  Wave 3/Wave 1 ≈ {ratio} ✓")
                if w5_w1_diff < 0.1:
                    print(f"  Wave 5/Wave 1 ≈ {ratio} ✓")
    else:
        print("No clear Elliott Wave pattern detected.")
        
        # Show recent turning points anyway
        peaks, troughs = analyzer.elliott_analyzer.find_peaks_troughs()
        all_points = sorted((peaks + troughs)[-10:], key=lambda x: x['date'])
        
        print("\nRecent Turning Points:")
        for point in all_points:
            print(f"  {point['date'].strftime('%Y-%m-%d')}: ₹{point['price']:.2f} ({point['type']})")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nAnalysis interrupted by user. Goodbye!")
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        print("Please check your Kite Connect setup and try again.")