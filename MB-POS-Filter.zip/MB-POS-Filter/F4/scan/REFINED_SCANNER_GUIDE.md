# 🎯 Refined Scanner - Complete Guide

## What's New

After comprehensive backtesting and analysis, your scanner has been upgraded with data-driven optimizations!

---

## 📊 What Changed (and Why)

### 1. **New Market Regime Filter** ⭐
**File:** `market_regime_filter.py`

**What it does:**
- Checks Nifty 50 trend strength
- Analyzes price vs EMAs
- Monitors VIX (volatility)
- Determines if conditions are favorable

**Why:**
- Strategy works BEST in trending markets (2,139% in 2023)
- Struggles in consolidation (7-8% in recent months)
- Filter prevents trading in poor conditions

**Market Regimes:**
```
STRONG_TRENDING → Trade aggressively (best conditions)
TRENDING        → Trade normally (good conditions)
CONSOLIDATING   → Trade selectively (marginal)
WEAK            → Don't trade (poor conditions)
```

### 2. **Refined Scanner Logic** ⭐
**File:** `myscanner_refined.py`

**Changes:**
- ✅ BOUNCED_FROM_EMA checked FIRST (41% win rate)
- ✅ PULLBACK_TO_21_EMA kept (34.81% win rate)
- ❌ BETWEEN_21_55_EMA REMOVED (14.66% win rate)
- ✅ Quality filter (only ≥1)
- ✅ Market regime filter integrated
- ✅ Optimal R:R (4% SL / 8% Target)

### 3. **Optimal Risk/Reward** ⭐
**Configuration:** Moderate 2:1 (4% SL / 8% Target)

**Why:**
- Won in ALL 6 market regimes tested
- Best balance of returns (1,340%) vs risk (-32% DD)
- Higher win rate (41%) than alternatives
- Proven across bull, bear, and consolidation

---

## 🚀 How to Use

### Quick Start

```bash
cd MB-POS-Filter\F4\scan
python myscanner_refined.py
```

### What Happens

**Step 1: Market Regime Check**
```
📊 MARKET REGIME CHECK
================================================================================
Current Regime: TRENDING
Nifty: 24,500 (21 EMA: 24,200, 50 EMA: 23,800)
Trend Strength: 75/100
Recent Return (20d): 3.2%

✅ GOOD market conditions - Trade normally
```

**Step 2: If Conditions Good → Scans Symbols**
```
Processing 1/209: RELIANCE
  ✓ BOUNCED_FROM_EMA setup found (Quality: 2)

Processing 2/209: TCS
  ✓ PULLBACK_TO_21_EMA setup found (Quality: 1)

Processing 3/209: INFY
  ✗ No setup (21 EMA not above 55 EMA)
```

**Step 3: Results**
```
✅ SCAN COMPLETE
================================================================================
Market Regime: TRENDING
Setups found: 15
  - BOUNCED_FROM_EMA: 10
  - PULLBACK_TO_21_EMA: 5

Quality Distribution:
  - Quality 2 (Best): 10
  - Quality 1 (Good): 5

🎯 TOP 5 SETUPS:
1. RELIANCE - BOUNCED_FROM_EMA (Quality: 2)
   Price: ₹2,500 | Stop Loss: ₹2,400 | Target: ₹2,700
   Risk: ₹100 | Reward: ₹200 | 1:2
```

---

## 📋 Configuration Details

### Market Regime Filter Settings

```python
# In market_regime_filter.py
# You can customize these thresholds:

STRONG_TRENDING: trend_score ≥ 70 AND VIX < 15
TRENDING:        trend_score ≥ 50
CONSOLIDATING:   trend_score ≥ 30
WEAK:            trend_score < 30

# Trend score calculated from:
- Price above EMAs (40 points)
- EMA alignment (30 points)
- Recent momentum (20 points)
- Distance from 21 EMA (10 points)
```

### Scanner Settings

```python
# In myscanner_refined.py
self.stop_loss_pct = 0.04      # 4% stop loss
self.target_pct = 0.08         # 8% target (2:1 R:R)
self.min_quality_score = 1     # Quality filter

# Automatically raises to 2 in CONSOLIDATING market
```

---

## 🎯 Setup Types Explained

### 1. BOUNCED_FROM_EMA (Priority 1) ⭐
**Win Rate:** 41% | **Quality:** Always 2

**Criteria:**
- Price touched 10 or 21 EMA recently (last 5 days)
- Price now ABOVE 10 EMA
- Price showing upward momentum
- 21 EMA above 55 EMA (uptrend)

**Why it works:**
- Catches stocks AFTER the bounce
- Momentum already confirmed
- High probability of continuation

**Example:**
```
Day 1: Stock touches 21 EMA at ₹100
Day 2: Bounces to ₹102
Day 3: Continues to ₹104 ← SETUP TRIGGERS
```

### 2. PULLBACK_TO_21_EMA (Priority 2)
**Win Rate:** 34.81% | **Quality:** 0-2 (based on conditions)

**Criteria:**
- Price within 2% of 21 EMA
- 21 EMA above 55 EMA (uptrend)
- Bonus: Consolidation (+1) + Volume drying (+1)

**Why it works:**
- Classic support bounce at moving average
- Quality score improves with consolidation

**Example:**
```
Stock at ₹100, 21 EMA at ₹99
Within 2% → SETUP TRIGGERS
If consolidating + volume drying → Quality = 2
```

### 3. BETWEEN_21_55_EMA (REMOVED) ❌
**Win Rate:** 14.66% (terrible!)

**Why removed:**
- Only 1 in 7 trades win
- Dragged down overall performance
- "Deeper pullback" often turned into downtrend

---

## 📊 Expected Performance

### By Market Regime:

| Regime | Expected Return (6mo) | Win Rate | Should Trade? |
|--------|----------------------|----------|---------------|
| **Strong Trending** | 400-1,000% | 48-53% | ✅ YES - Aggressively |
| **Trending** | 100-300% | 38-45% | ✅ YES - Normally |
| **Consolidating** | 10-50% | 35-40% | ⚠️ Selectively |
| **Weak** | -10-20% | 30-38% | ❌ NO - Sit out |

### Overall (Mixed Regimes):
```
Expected Annual Return: 200-400%
Win Rate: 40-45%
Max Drawdown: 20-35%
Trades per Month: 20-40 (depending on market)
```

---

## 🔧 Customization Options

### 1. Adjust Risk/Reward

```python
# In myscanner_refined.py, change:
self.stop_loss_pct = 0.03  # 3% for tighter stops
self.target_pct = 0.06     # 6% for smaller targets

# Or more aggressive:
self.stop_loss_pct = 0.05  # 5%
self.target_pct = 0.10     # 10%
```

### 2. Adjust Quality Filter

```python
# Stricter (fewer but better setups):
self.min_quality_score = 2  # Only BOUNCED setups

# Looser (more setups):
self.min_quality_score = 0  # All setups
```

### 3. Override Market Regime Check

```python
# To scan regardless of market conditions:
# In myscanner_refined.py, comment out the regime check:

# should_trade = regime_filter.should_trade(regime)
# if not should_trade:
#     response = input("Continue anyway? (y/n): ")
#     ...
```

---

## 🎓 Understanding the Output

### CSV Columns

| Column | Description | Example |
|--------|-------------|---------|
| `Symbol` | Stock symbol | RELIANCE |
| `Setup_Type` | Type of setup | BOUNCED_FROM_EMA |
| `Quality_Score` | Quality (0-2) | 2 |
| `Current_Price` | Entry price | 2500.00 |
| `Stop_Loss` | Exit if hits | 2400.00 |
| `Target` | Exit if hits | 2700.00 |
| `Risk` | Loss if SL hits | 100.00 |
| `Reward` | Profit if target hits | 200.00 |
| `R:R` | Risk:Reward ratio | 1:2 |
| `Notes` | Setup details | ✓ Touched 21 EMA |

### Quality Scores

```
Quality 2 (Best):
- BOUNCED_FROM_EMA (always 2)
- PULLBACK with consolidation + volume drying

Quality 1 (Good):
- PULLBACK with consolidation OR volume drying

Quality 0 (Basic):
- PULLBACK without quality boosters
- Not recommended to trade
```

---

## 🚨 Important Warnings

### 1. Market Regime Dependency
```
⚠️  Strategy is TREND-FOLLOWING
    Works best in trending markets
    Struggles in consolidation
    
    Don't expect 600% returns if market is sideways!
```

### 2. Recent Performance Reality
```
⚠️  Last 6 months: Only 7-8% returns
    (Market was consolidating)
    
    This is NORMAL for this strategy
    Wait for next trend = PATIENCE!
```

### 3. Risk Management
```
⚠️  4% stop loss means you WILL lose 4%
    On ₹50,000 position = ₹2,000 loss
    
    NEVER move stop loss down!
    Accept the loss and move on
```

### 4. Don't Cherry-Pick
```
⚠️  Take EVERY signal that appears
    Don't skip setups you "don't like"
    
    System works over many trades
    Cherry-picking destroys edge
```

---

## 📈 Trading Workflow

### Daily Routine

**Morning (9:00 AM):**
```bash
1. Check market regime:
   python market_regime_filter.py
   
2. If favorable → Run scanner:
   python myscanner_refined.py
   
3. Review results CSV
```

**Market Open (9:15 AM):**
```
1. Place orders for Quality=2 setups first
2. Then Quality=1 setups
3. Set stop loss IMMEDIATELY
4. Set target order
```

**During Day:**
```
1. Monitor for stop loss/target hits
2. Don't interfere with trades
3. Let system work
```

**End of Day:**
```
1. Log all trades
2. Review what worked/didn't
3. Update spreadsheet
```

---

## 🎯 Testing Before Live

### Phase 1: Paper Trade (2-4 weeks)
```
✅ Run scanner daily
✅ Record all signals
✅ Track hypothetical P&L
✅ Compare with expectations
✅ Build confidence
```

### Phase 2: Small Live (1-2 months)
```
✅ Start with ₹1-2L capital
✅ Take EVERY signal
✅ Follow rules strictly
✅ Track performance
✅ Compare with backtest
```

### Phase 3: Scale Up (Month 3+)
```
✅ If performance matches expectations
✅ Gradually increase capital
✅ Max out at comfortable level
✅ Maintain discipline
```

---

## 🔍 Troubleshooting

### Problem: No Setups Found

**Possible Causes:**
- Market regime is WEAK or CONSOLIDATING
- No stocks in pullback/bounce
- Quality filter too strict

**Solutions:**
- Wait for better market conditions
- Check if Nifty is trending
- Lower quality filter temporarily

### Problem: Too Many Losses

**Possible Causes:**
- Trading in consolidating market
- Not following stop loss rules
- Cherry-picking setups

**Solutions:**
- Only trade in TRENDING regimes
- Follow stop loss mechanically
- Take every signal (or none)

### Problem: Targets Rarely Hit

**Possible Causes:**
- Market volatility too low
- Wrong market regime

**Solutions:**
- Consider lower targets (6% instead of 8%)
- Wait for better market conditions
- Use trailing stops

---

## 📚 Files Reference

| File | Purpose | When to Use |
|------|---------|-------------|
| `market_regime_filter.py` | Check market conditions | Before scanning |
| `myscanner_refined.py` | Find trading setups | Daily morning |
| `backtest_scanner.py` | Test strategy | Weekly/monthly validation |
| `compare_risk_reward_cached.py` | Optimize R:R | Monthly optimization |
| `market_regime_analysis.py` | Test robustness | Quarterly check |

---

## ✅ Pre-Launch Checklist

Before going live:

- [ ] Understand both setup types
- [ ] Know how to read market regime
- [ ] Tested on paper for 2-4 weeks
- [ ] Know your stop loss and target for each setup
- [ ] Have trading journal ready
- [ ] Comfortable with 4% losses
- [ ] Can handle 20-35% drawdown
- [ ] Will follow rules mechanically
- [ ] Won't cherry-pick setups
- [ ] Started with small capital (₹1-2L)

---

## 🚀 Quick Command Reference

```bash
# Check market regime
cd MB-POS-Filter\F4\scan
python market_regime_filter.py

# Run refined scanner
python myscanner_refined.py

# Run backtest (monthly)
python backtest_scanner.py

# Test different R:R ratios
python compare_risk_reward_cached.py

# Test across market regimes
python market_regime_analysis.py
```

---

## 💡 Final Tips

1. **Trust the Process**
   - System has edge (proven in backtest)
   - Works over many trades
   - Don't judge by single trades

2. **Market Regime is KEY**
   - Don't trade in WEAK/CONSOLIDATING
   - Best results in TRENDING markets
   - Patience = Profitability

3. **Quality > Quantity**
   - Quality 2 setups are gold
   - Quality 1 setups are good
   - Skip quality 0 in marginal markets

4. **Risk Management**
   - Never skip stop loss
   - Never move stop loss down
   - Position size = 5% of capital max

5. **Psychology**
   - Accept losses (they're part of system)
   - Don't revenge trade
   - Don't double up after losses
   - Follow rules mechanically

---

**You now have a data-driven, tested, and optimized trading system!**

Good luck! 🚀📈💰

---

*Last Updated: October 23, 2025*
*Version: Refined 2.0*
*Configuration: Moderate 2:1 (4% SL / 8% Target)*

