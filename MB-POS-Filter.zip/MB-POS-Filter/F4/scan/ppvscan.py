import pandas as pd
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import time
import os
import logging
from pandas.io.excel import ExcelWriter
import xlsxwriter
import numpy as np
from typing import Optional, Dict, List, Tuple

# =============================================================================
# CONFIGURATION PARAMETERS - Adjust these values as needed
# =============================================================================

# Data Configuration
DEFAULT_WEEKS_BACK = 13  # Number of weeks of historical data to fetch (gives 6 valid MA50 values)
MIN_WEEKS_FOR_CALCULATION = 13  # Minimum weeks required for calculations (to accommodate 21-week MA50)
MA_PERIOD_30 = 5  # MA period (9-week MA30 for short-term trends)
MA_PERIOD_50 = 11  # MA period (21-week MA50 for better trend analysis)

# Weinstein Stage Configuration
MA30_SLOPE_THRESHOLD = 0.2  # Threshold for MA30 slope classification
MA30_DECLINE_THRESHOLD = -0.2  # Threshold for MA30 decline

# Volume Bar Classification Configuration
BODY_THRESHOLD = 1.5  # Body length threshold multiplier
ATR_THRESHOLD = 1.0  # ATR threshold multiplier
ATR_PERIOD = 14  # ATR calculation period

# Volume Quality Configuration
OBV_TREND_THRESHOLD = 2.0  # OBV trend threshold for quality
VWAP_TREND_THRESHOLD = 0.5  # VWAP trend threshold
DISTRIBUTION_WARNING_THRESHOLD = 2  # Number of warnings for Stage 3

# Signal Generation Configuration
FILTER_STAGES = True  # Enable Weinstein Stage filtering
STRICT_PPV = False  # Use strict PPV criteria
BATCH_SIZE = 200  # Batch size for processing
REQUESTS_PER_SECOND = 3  # API rate limiting

# =============================================================================
# ENHANCED SIGNAL QUALITY COMPONENTS
# =============================================================================

"""
Enhanced Signal Quality Components for PPV Scanner
Improvements:
1. Clear Weinstein Stage logic with documented edge cases
2. Data-driven confidence scoring
3. Configurable OBV system with performance tracking
4. Simplified volume classification with clear criteria
"""

from dataclasses import dataclass, field

# =============================================================================
# ENHANCED CONFIGURATION CLASSES
# =============================================================================

@dataclass
class WeinsteinConfig:
    """Configuration for Weinstein Stage Analysis"""
    # Moving Average Periods
    ma_short_period: int = 5  # 9-week MA30 equivalent
    ma_long_period: int = 11  # 21-week MA50 equivalent
    
    # Stage Transition Thresholds (in %)
    rising_ma_threshold: float = 0.3  # MA rising if > 0.3% over 2 weeks
    flat_ma_range: Tuple[float, float] = (-0.2, 0.2)  # MA considered flat
    declining_ma_threshold: float = -0.3  # MA declining if < -0.3%
    
    # Price Position Thresholds (distance from MA in %)
    above_ma_threshold: float = 0.5  # Clearly above MA
    below_ma_threshold: float = -0.5  # Clearly below MA
    
    # Confidence Calculation Weights
    ma_slope_weight: float = 0.3
    price_position_weight: float = 0.3
    consistency_weight: float = 0.2
    volume_quality_weight: float = 0.2
    
    # Stage-specific minimum weeks for consistency
    min_weeks_consistency: int = 3


@dataclass
class OBVConfig:
    """Configuration for OBV Analysis"""
    # OBV Calculation Methods (enable/disable)
    use_traditional: bool = True
    use_weighted: bool = True
    use_intraday: bool = True
    
    # Composite OBV Weights (must sum to 1.0)
    traditional_weight: float = 0.4
    weighted_weight: float = 0.4
    intraday_weight: float = 0.2
    
    # Trend Detection
    trend_short_period: int = 3
    trend_long_period: int = 10
    strong_trend_threshold: float = 2.0  # % change
    
    # Quality Scoring
    alignment_window: int = 10
    min_quality_score: float = 40.0
    high_quality_score: float = 70.0
    
    # Divergence Detection
    divergence_lookback: int = 10
    min_divergence_periods: int = 2
    
    def validate_weights(self):
        """Ensure weights sum to 1.0"""
        total = self.traditional_weight + self.weighted_weight + self.intraday_weight
        if not np.isclose(total, 1.0):
            raise ValueError(f"OBV weights must sum to 1.0, got {total}")


@dataclass
class VolumeConfig:
    """Configuration for Volume Classification"""
    # PPV Detection
    ppv_lookback: int = 5  # Weeks to look back for highest down volume
    volume_ma_period: int = 10
    
    # Volume thresholds (multipliers)
    high_volume_threshold: float = 1.2  # 20% above average
    extreme_volume_threshold: float = 2.0  # 2x average
    
    # PPV Criteria
    use_strict_ppv: bool = False  # Single mode instead of dual
    ppv_obv_quality_min: float = 40.0
    ppv_require_vwap_rising: bool = True
    ppv_require_price_above_vwap: bool = True
    
    # Signal strength
    body_threshold: float = 1.5
    atr_threshold: float = 1.0
    atr_period: int = 14


# =============================================================================
# ENHANCED WEINSTEIN STAGE ANALYZER
# =============================================================================

class EnhancedWeinsteinStage:
    """
    Enhanced Weinstein Stage Analysis with:
    - Clear, non-overlapping stage definitions
    - Data-driven confidence scoring
    - Documented edge case handling
    """
    
    def __init__(self, config: WeinsteinConfig = None):
        self.config = config or WeinsteinConfig()
        
    def calculate_stages(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate Weinstein Stages with enhanced logic
        
        Stage Definitions (Priority Order):
        1. Stage 1 (Accumulation): Price below declining/flat MA
        2. Stage 4 (Markdown): Price below declining MA with momentum
        3. Stage 3 (Distribution): Price above flat/declining MA with warnings
        4. Stage 2 (Markup): Price above rising MA
        
        Edge Cases:
        - Price near MA (within 0.5%): Use MA slope as tiebreaker
        - MA slope near flat: Require 3-week consistency
        - Conflicting signals: Default to more conservative stage
        """
        if df is None or df.empty:
            return df
            
        df = df.copy()
        
        # Calculate MAs
        df['ma_short'] = df['close'].rolling(
            window=self.config.ma_short_period, 
            min_periods=self.config.ma_short_period
        ).mean()
        
        df['ma_long'] = df['close'].rolling(
            window=self.config.ma_long_period, 
            min_periods=self.config.ma_long_period
        ).mean()
        
        # Calculate MA slope (% change over 2 weeks)
        df['ma_slope'] = df['ma_short'].pct_change(periods=2) * 100
        df['ma_slope'] = df['ma_slope'].fillna(0)
        
        # Calculate price position relative to MA (%)
        df['price_vs_ma'] = ((df['close'] - df['ma_short']) / df['ma_short'] * 100)
        
        # Classify MA trend
        df['ma_trend'] = self._classify_ma_trend(df['ma_slope'])
        
        # Classify price position
        df['price_position'] = self._classify_price_position(df['price_vs_ma'])
        
        # Calculate stage consistency (how many weeks in current state)
        df['stage_consistency'] = self._calculate_consistency(
            df['ma_trend'], 
            df['price_position']
        )
        
        # Assign stages using clear priority logic
        df = self._assign_stages(df)
        
        # Calculate data-driven confidence scores
        df = self._calculate_confidence(df)
        
        return df
    
    def _classify_ma_trend(self, ma_slope: pd.Series) -> pd.Series:
        """
        Classify MA trend into: Rising, Flat, Declining
        """
        trend = pd.Series('Flat', index=ma_slope.index)
        
        trend[ma_slope > self.config.rising_ma_threshold] = 'Rising'
        trend[ma_slope < self.config.declining_ma_threshold] = 'Declining'
        
        # Edge case: Near threshold - require consistency
        # This is handled in stage assignment
        
        return trend
    
    def _classify_price_position(self, price_vs_ma: pd.Series) -> pd.Series:
        """
        Classify price position: Above, Near, Below MA
        """
        position = pd.Series('Near', index=price_vs_ma.index)
        
        position[price_vs_ma > self.config.above_ma_threshold] = 'Above'
        position[price_vs_ma < self.config.below_ma_threshold] = 'Below'
        
        return position
    
    def _calculate_consistency(self, ma_trend: pd.Series, 
                               price_position: pd.Series) -> pd.Series:
        """
        Calculate how many consecutive weeks the current state has held
        """
        # Combine trend and position into a state string
        state = ma_trend + '_' + price_position
        
        # Count consecutive occurrences
        consistency = pd.Series(0, index=state.index)
        
        current_state = None
        count = 0
        
        for i in range(len(state)):
            if state.iloc[i] == current_state:
                count += 1
            else:
                current_state = state.iloc[i]
                count = 1
            consistency.iloc[i] = count
        
        return consistency
    
    def _assign_stages(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Assign Weinstein stages using clear priority logic
        
        Priority order prevents ambiguity:
        1. Stage 4 (most bearish)
        2. Stage 1 (accumulation)
        3. Stage 3 (distribution warning)
        4. Stage 2 (most bullish)
        0. Unknown (insufficient data or edge cases)
        """
        df['weinstein_stage'] = 0  # Default unknown
        df['stage_name'] = 'Unknown'
        
        # Stage 4: Markdown (highest priority for bearish)
        # Price below declining MA with confirmation
        stage4_mask = (
            (df['price_position'] == 'Below') &
            (df['ma_trend'] == 'Declining') &
            (df['stage_consistency'] >= self.config.min_weeks_consistency)
        )
        df.loc[stage4_mask, 'weinstein_stage'] = 4
        df.loc[stage4_mask, 'stage_name'] = 'Markdown'
        
        # Stage 1: Accumulation
        # Price below MA, but MA not strongly declining
        stage1_mask = (
            (df['price_position'].isin(['Below', 'Near'])) &
            (df['ma_trend'].isin(['Flat', 'Declining'])) &
            (df['weinstein_stage'] == 0)  # Not already stage 4
        )
        df.loc[stage1_mask, 'weinstein_stage'] = 1
        df.loc[stage1_mask, 'stage_name'] = 'Accumulation'
        
        # Stage 3: Distribution
        # Price above MA but MA not rising (topping pattern)
        stage3_mask = (
            (df['price_position'].isin(['Above', 'Near'])) &
            (df['ma_trend'].isin(['Flat', 'Declining'])) &
            (df['stage_consistency'] >= 2) &  # At least 2 weeks
            (df['weinstein_stage'] == 0)
        )
        df.loc[stage3_mask, 'weinstein_stage'] = 3
        df.loc[stage3_mask, 'stage_name'] = 'Distribution'
        
        # Stage 2: Markup (default for bullish conditions)
        # Price above rising MA
        stage2_mask = (
            (df['price_position'].isin(['Above', 'Near'])) &
            (df['ma_trend'] == 'Rising') &
            (df['weinstein_stage'] == 0)
        )
        df.loc[stage2_mask, 'weinstein_stage'] = 2
        df.loc[stage2_mask, 'stage_name'] = 'Markup'
        
        return df
    
    def _calculate_confidence(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate data-driven confidence scores
        
        Factors:
        1. MA slope strength (stronger = higher confidence)
        2. Price distance from MA (further = higher confidence)
        3. Stage consistency (longer = higher confidence)
        4. Volume quality alignment (better = higher confidence)
        """
        df['stage_confidence'] = 50.0  # Base confidence
        
        # Factor 1: MA slope strength (0-30 points)
        ma_slope_score = (
            np.abs(df['ma_slope']).clip(0, 3.0) / 3.0 * 30 * 
            self.config.ma_slope_weight / self.config.ma_slope_weight
        )
        
        # Factor 2: Price position strength (0-30 points)
        price_position_score = (
            np.abs(df['price_vs_ma']).clip(0, 10.0) / 10.0 * 30 * 
            self.config.price_position_weight / self.config.price_position_weight
        )
        
        # Factor 3: Consistency (0-20 points)
        consistency_score = (
            df['stage_consistency'].clip(0, 10) / 10 * 20 * 
            self.config.consistency_weight / self.config.consistency_weight
        )
        
        # Combine scores
        df['stage_confidence'] = (
            50 +  # Base
            ma_slope_score * self.config.ma_slope_weight +
            price_position_score * self.config.price_position_weight +
            consistency_score * self.config.consistency_weight
        ).clip(0, 100)
        
        # Stage-specific adjustments
        # Stage 2 and 4 are clearest, stages 1 and 3 more ambiguous
        df.loc[df['weinstein_stage'] == 2, 'stage_confidence'] *= 1.1
        df.loc[df['weinstein_stage'] == 4, 'stage_confidence'] *= 1.1
        df.loc[df['weinstein_stage'] == 1, 'stage_confidence'] *= 0.9
        df.loc[df['weinstein_stage'] == 3, 'stage_confidence'] *= 0.85
        
        df['stage_confidence'] = df['stage_confidence'].clip(0, 95)
        
        return df


# =============================================================================
# SIMPLIFIED OBV ANALYZER
# =============================================================================

class SimplifiedOBV:
    """
    Simplified OBV with configurable methods and performance tracking
    """
    
    def __init__(self, config: OBVConfig = None):
        self.config = config or OBVConfig()
        self.config.validate_weights()
        self.performance_stats = {
            'traditional': [],
            'weighted': [],
            'intraday': []
        }
    
    def calculate(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate OBV using enabled methods and create composite
        """
        if df is None or df.empty:
            return df
            
        df = df.copy().sort_values('date')
        
        obv_methods = {}
        
        # Calculate each enabled method
        if self.config.use_traditional:
            df['obv_traditional'] = self._traditional_obv(df)
            obv_methods['traditional'] = df['obv_traditional']
        
        if self.config.use_weighted:
            df['obv_weighted'] = self._weighted_obv(df)
            obv_methods['weighted'] = df['obv_weighted']
        
        if self.config.use_intraday:
            df['obv_intraday'] = self._intraday_obv(df)
            obv_methods['intraday'] = df['obv_intraday']
        
        # Create composite OBV
        if obv_methods:
            df['obv'] = self._create_composite(obv_methods)
        else:
            df['obv'] = 0
        
        # Calculate trends
        df['obv_trend_short'] = df['obv'].pct_change(
            periods=self.config.trend_short_period
        ) * 100
        
        df['obv_trend_long'] = df['obv'].pct_change(
            periods=self.config.trend_long_period
        ) * 100
        
        # Use short-term trend as primary
        df['obv_trend'] = df['obv_trend_short']
        
        # Calculate quality score
        df = self._calculate_quality(df)
        
        # Detect divergences
        df = self._detect_divergences(df)
        
        return df
    
    def _traditional_obv(self, df: pd.DataFrame) -> pd.Series:
        """Standard OBV calculation"""
        obv = np.zeros(len(df))
        price_change = df['close'].diff()
        
        for i in range(1, len(df)):
            if price_change.iloc[i] > 0:
                obv[i] = obv[i-1] + df['volume'].iloc[i]
            elif price_change.iloc[i] < 0:
                obv[i] = obv[i-1] - df['volume'].iloc[i]
            else:
                obv[i] = obv[i-1]
        
        return pd.Series(obv, index=df.index)
    
    def _weighted_obv(self, df: pd.DataFrame) -> pd.Series:
        """OBV weighted by price change magnitude"""
        obv = np.zeros(len(df))
        price_change_pct = df['close'].pct_change()
        
        for i in range(1, len(df)):
            change = price_change_pct.iloc[i]
            volume = df['volume'].iloc[i]
            
            if not np.isnan(change):
                weight = min(abs(change) * 100 + 1, 2.0)  # Cap at 2x
                obv[i] = obv[i-1] + (np.sign(change) * volume * weight)
            else:
                obv[i] = obv[i-1]
        
        return pd.Series(obv, index=df.index)
    
    def _intraday_obv(self, df: pd.DataFrame) -> pd.Series:
        """OBV considering body-to-range ratio"""
        obv = np.zeros(len(df))
        
        body = abs(df['close'] - df['open'])
        range_val = df['high'] - df['low']
        body_ratio = body / (range_val + 1e-8)
        direction = np.sign(df['close'] - df['open'])
        
        for i in range(1, len(df)):
            volume_allocation = df['volume'].iloc[i] * (0.5 + 0.5 * body_ratio.iloc[i])
            obv[i] = obv[i-1] + (direction.iloc[i] * volume_allocation)
        
        return pd.Series(obv, index=df.index)
    
    def _create_composite(self, obv_methods: Dict[str, pd.Series]) -> pd.Series:
        """Create weighted composite of OBV methods"""
        composite = pd.Series(0, index=list(obv_methods.values())[0].index)
        
        weights = {
            'traditional': self.config.traditional_weight,
            'weighted': self.config.weighted_weight,
            'intraday': self.config.intraday_weight
        }
        
        for method, series in obv_methods.items():
            if method in weights:
                composite += series * weights[method]
        
        return composite
    
    def _calculate_quality(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate OBV quality score based on price-volume alignment"""
        obv_change = df['obv'].diff()
        price_change = df['close'].diff()
        
        # Alignment: both positive or both negative
        alignment = np.where(
            (price_change > 0) & (obv_change > 0), 1,
            np.where(
                (price_change < 0) & (obv_change < 0), 1,
                np.where(
                    (price_change == 0) | (obv_change == 0), 0,
                    -1
                )
            )
        )
        
        alignment_series = pd.Series(alignment, index=df.index)
        
        # Rolling alignment percentage
        df['obv_quality_score'] = (
            alignment_series.rolling(
                window=self.config.alignment_window, 
                min_periods=1
            ).mean() * 50 + 50  # Scale to 0-100
        )
        
        return df
    
    def _detect_divergences(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Detect bullish and bearish divergences between price and OBV
        
        Classic divergence patterns:
        - Bullish divergence: Price makes lower low, OBV makes higher low
        - Bearish divergence: Price makes higher high, OBV makes lower high
        
        Uses a rolling window approach to find local extremes and compare them.
        """
        lookback = self.config.divergence_lookback
        
        # Initialize divergence columns
        df['obv_bullish_divergence'] = 0
        df['obv_bearish_divergence'] = 0
        
        if len(df) < lookback * 3:  # Need more data for meaningful divergences
            return df
        
        # Find local lows and highs using rolling windows
        # A point is a low if it's the minimum in its window
        # A point is a high if it's the maximum in its window
        price_is_low = df['close'] == df['close'].rolling(window=lookback, center=True, min_periods=1).min()
        price_is_high = df['close'] == df['close'].rolling(window=lookback, center=True, min_periods=1).max()
        
        obv_is_low = df['obv'] == df['obv'].rolling(window=lookback, center=True, min_periods=1).min()
        obv_is_high = df['obv'] == df['obv'].rolling(window=lookback, center=True, min_periods=1).max()
        
        # Get indices of price and OBV extremes
        price_lows = df.index[price_is_low].tolist()
        price_highs = df.index[price_is_high].tolist()
        obv_lows = df.index[obv_is_low].tolist()
        obv_highs = df.index[obv_is_high].tolist()
        
        # Detect bullish divergence: Compare recent price lows with OBV lows
        # Look for lower price lows but higher OBV lows
        if len(price_lows) >= 2 and len(obv_lows) >= 2:
            for i in range(len(price_lows) - 1):
                idx1 = price_lows[i]
                idx2 = price_lows[i + 1]
                
                # Check if we have corresponding OBV lows near these price lows
                obv_near_1 = [idx for idx in obv_lows if abs(idx - idx1) <= lookback]
                obv_near_2 = [idx for idx in obv_lows if abs(idx - idx2) <= lookback]
                
                if obv_near_1 and obv_near_2:
                    price_val_1 = df.loc[idx1, 'close']
                    price_val_2 = df.loc[idx2, 'close']
                    obv_val_1 = df.loc[obv_near_1[0], 'obv']
                    obv_val_2 = df.loc[obv_near_2[0], 'obv']
                    
                    # Bullish divergence: Price lower low, OBV higher low
                    if price_val_2 < price_val_1 and obv_val_2 > obv_val_1:
                        df.loc[idx2, 'obv_bullish_divergence'] = 1
        
        # Detect bearish divergence: Compare recent price highs with OBV highs
        # Look for higher price highs but lower OBV highs
        if len(price_highs) >= 2 and len(obv_highs) >= 2:
            for i in range(len(price_highs) - 1):
                idx1 = price_highs[i]
                idx2 = price_highs[i + 1]
                
                # Check if we have corresponding OBV highs near these price highs
                obv_near_1 = [idx for idx in obv_highs if abs(idx - idx1) <= lookback]
                obv_near_2 = [idx for idx in obv_highs if abs(idx - idx2) <= lookback]
                
                if obv_near_1 and obv_near_2:
                    price_val_1 = df.loc[idx1, 'close']
                    price_val_2 = df.loc[idx2, 'close']
                    obv_val_1 = df.loc[obv_near_1[0], 'obv']
                    obv_val_2 = df.loc[obv_near_2[0], 'obv']
                    
                    # Bearish divergence: Price higher high, OBV lower high
                    if price_val_2 > price_val_1 and obv_val_2 < obv_val_1:
                        df.loc[idx2, 'obv_bearish_divergence'] = 1
        
        return df


# =============================================================================
# SIMPLIFIED VOLUME CLASSIFIER
# =============================================================================

class SimplifiedVolumeClassifier:
    """
    Simplified volume classification with single PPV mode
    """
    
    def __init__(self, config: VolumeConfig = None):
        self.config = config or VolumeConfig()
    
    def classify(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Classify volume bars into PPV, Green, Red, Grey
        
        Clear Priority:
        1. PPV: Up day with volume > highest recent down volume + quality filters
        2. Green: Up day with above-average volume
        3. Red: Down day with above-average volume
        4. Grey: Everything else
        """
        if df is None or df.empty:
            return df
            
        df = df.copy()
        
        # Basic calculations
        df['volume_ma'] = df['volume'].rolling(
            window=self.config.volume_ma_period, 
            min_periods=1
        ).mean()
        
        df['is_up'] = df['close'] > df['open']
        df['is_down'] = df['close'] < df['open']
        
        # Calculate highest down volume in lookback period
        df['highest_down_vol'] = self._calculate_highest_down_volume(df)
        
        # Classify bars
        df['bar_type'] = 0  # Default: Grey
        
        # PPV: Most restrictive
        ppv_base = (
            df['is_up'] & 
            (df['volume'] > df['highest_down_vol'])
        )
        
        if self.config.use_strict_ppv:
            # Strict: All quality filters required
            ppv_quality = (
                (df['obv_trend'] > 0) &
                (df['obv_quality_score'] > self.config.ppv_obv_quality_min)
            )
            if self.config.ppv_require_vwap_rising:
                ppv_quality = ppv_quality & (df['vwap_trend'] > 0)
            if self.config.ppv_require_price_above_vwap:
                ppv_quality = ppv_quality & (df['close'] > df['vwap'])
            
            ppv_mask = ppv_base & ppv_quality
        else:
            # Relaxed: Base condition only
            ppv_mask = ppv_base
        
        df.loc[ppv_mask, 'bar_type'] = 1
        
        # Green: Up with volume (not already PPV)
        green_mask = (
            df['is_up'] & 
            (df['volume'] > df['volume_ma']) &
            (df['bar_type'] == 0)
        )
        df.loc[green_mask, 'bar_type'] = 3
        
        # Red: Down with volume
        red_mask = (
            df['is_down'] & 
            (df['volume'] > df['volume_ma'])
        )
        df.loc[red_mask, 'bar_type'] = 2
        
        # Create flags
        df['is_ppv'] = (df['bar_type'] == 1)
        df['is_green'] = (df['bar_type'] == 3)
        df['is_red'] = (df['bar_type'] == 2)
        df['is_grey'] = (df['bar_type'] == 0)
        
        return df
    
    def _calculate_highest_down_volume(self, df: pd.DataFrame) -> pd.Series:
        """Calculate highest down volume in lookback period"""
        highest = pd.Series(0.0, index=df.index)
        down_weeks = df[df['is_down']].copy()
        
        if not down_weeks.empty:
            down_vol_rolling = down_weeks['volume'].rolling(
                window=self.config.ppv_lookback, 
                min_periods=1
            ).max()
            
            highest.loc[down_weeks.index] = down_vol_rolling
            # Forward fill to propagate values, then fill remaining zeros
            highest = highest.replace(0, np.nan).ffill().fillna(0)
        
        return highest


# =============================================================================
# INTEGRATION FUNCTION
# =============================================================================

def integrate_enhanced_analysis(df: pd.DataFrame,
                                weinstein_config: WeinsteinConfig = None,
                                obv_config: OBVConfig = None,
                                volume_config: VolumeConfig = None) -> pd.DataFrame:
    """
    Main integration function to replace existing analysis
    
    Usage:
        df = integrate_enhanced_analysis(df)
        
    Or with custom configs:
        weinstein_cfg = WeinsteinConfig(rising_ma_threshold=0.5)
        obv_cfg = OBVConfig(use_intraday=False, traditional_weight=0.6, weighted_weight=0.4)
        volume_cfg = VolumeConfig(use_strict_ppv=True, ppv_lookback=7)
        
        df = integrate_enhanced_analysis(df, weinstein_cfg, obv_cfg, volume_cfg)
    """
    if df is None or df.empty:
        return df
    
    # Initialize analyzers
    weinstein = EnhancedWeinsteinStage(weinstein_config)
    obv = SimplifiedOBV(obv_config)
    volume = SimplifiedVolumeClassifier(volume_config)
    
    # Calculate VWAP (needed for volume classification)
    df['typical_price'] = (df['high'] + df['low'] + df['close']) / 3
    df['vwap'] = (
        (df['typical_price'] * df['volume']).rolling(window=10, min_periods=1).sum() / 
        df['volume'].rolling(window=10, min_periods=1).sum()
    )
    df['vwap_trend'] = df['vwap'].pct_change(periods=3) * 100
    
    # Run analysis pipeline
    df = weinstein.calculate_stages(df)
    df = obv.calculate(df)
    df = volume.classify(df)
    
    return df

# =============================================================================

# Set up logging with more detailed format
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ppv_scanner.log'),
        logging.StreamHandler()
    ]
)

class PPVScanner:
    def __init__(self, api_key: str, access_token: str):
        self.api_key = api_key
        self.access_token = access_token
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Rate limiting parameters (using configurable values)
        self.REQUESTS_PER_SECOND = REQUESTS_PER_SECOND
        self.SLEEP_TIME = 1.0 / (self.REQUESTS_PER_SECOND - 0.5)
        self.BATCH_SIZE = BATCH_SIZE
        
        # Cache
        self.instruments_cache = None
        
    def load_instruments_cache(self) -> pd.DataFrame:
        """Load and cache NSE instruments"""
        if self.instruments_cache is None:
            try:
                logging.info("Fetching NSE instruments list...")
                instruments = self.kite.instruments("NSE")
                self.instruments_cache = pd.DataFrame(instruments)
                logging.info(f"Cached {len(self.instruments_cache)} instruments.")
            except Exception as e:
                logging.error(f"Failed to fetch instruments: {e}")
                raise
        return self.instruments_cache

    def fetch_historical_data(self, symbol: str, weeks_back: int = DEFAULT_WEEKS_BACK, retries: int = 3) -> Optional[pd.DataFrame]:
        """Fetch historical data with improved error handling"""
        instruments_df = self.load_instruments_cache()
        
        for attempt in range(retries):
            try:
                # More robust symbol matching
                matching_instruments = instruments_df[
                    instruments_df["tradingsymbol"] == symbol
                ]
                
                if matching_instruments.empty:
                    logging.warning(f"No instrument found for {symbol}")
                    return None
                
                token = matching_instruments["instrument_token"].iloc[0]
                end_date = datetime.now()
                start_date = end_date - timedelta(weeks=weeks_back)

                data = self.kite.historical_data(
                    instrument_token=token,
                    from_date=start_date,
                    to_date=end_date,
                    interval="week"
                )
                
                if not data:
                    logging.warning(f"No data returned for {symbol}")
                    return None
                
                df = pd.DataFrame(data)
                df['tradingsymbol'] = symbol
                
                # Validate data quality
                if self._validate_data_quality(df, symbol):
                    logging.info(f"Fetched {len(df)} weeks of data for {symbol}")
                    time.sleep(self.SLEEP_TIME)
                    return df
                else:
                    return None
                    
            except Exception as e:
                if "Too many requests" in str(e) or "rate limit" in str(e).lower():
                    wait_time = 5 * (attempt + 1)  # Exponential backoff
                    logging.warning(f"Rate limit hit for {symbol}. Waiting {wait_time}s...")
                    time.sleep(wait_time)
                else:
                    logging.error(f"Error fetching data for {symbol}: {e}")
                    break
                    
        logging.error(f"Failed to fetch data for {symbol} after {retries} attempts")
        return None

    def _validate_data_quality(self, df: pd.DataFrame, symbol: str) -> bool:
        """Validate data quality before processing"""
        if df.empty:
            logging.warning(f"Empty dataframe for {symbol}")
            return False
            
        required_columns = ['open', 'high', 'low', 'close', 'volume', 'date']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            logging.warning(f"Missing columns for {symbol}: {missing_columns}")
            return False
            
        # Check for reasonable data ranges
        if (df['volume'] < 0).any():
            logging.warning(f"Negative volume detected for {symbol}")
            return False
            
        if (df[['open', 'high', 'low', 'close']] <= 0).any().any():
            logging.warning(f"Non-positive prices detected for {symbol}")
            return False
            
        return True

    def calculate_weinstein_stage(self, df: pd.DataFrame, 
                                  strict_ppv: bool = STRICT_PPV,
                                  weinstein_config: WeinsteinConfig = None,
                                  obv_config: OBVConfig = None,
                                  volume_config: VolumeConfig = None) -> pd.DataFrame:
        """
        Enhanced Weinstein Stage calculation using new integrate_enhanced_analysis
        This method now calls the improved analysis pipeline with clearer logic
        
        Args:
            df: DataFrame with OHLCV data
            strict_ppv: If True, use strict PPV criteria (all quality filters required)
                       If False, use relaxed PPV criteria (base condition only)
                       Note: Ignored if volume_config is provided
            weinstein_config: Optional custom WeinsteinConfig for advanced users
            obv_config: Optional custom OBVConfig for advanced users
            volume_config: Optional custom VolumeConfig for advanced users
        
        Returns:
            DataFrame with Weinstein stages, OBV, and volume classification
            
        Example (Advanced Usage):
            # Custom configs for more aggressive trading
            weinstein_cfg = WeinsteinConfig(
                rising_ma_threshold=0.2,  # Lower threshold for faster signals
                min_weeks_consistency=2
            )
            obv_cfg = OBVConfig(
                use_traditional=True,
                use_weighted=False,  # Simplify to traditional only
                use_intraday=False
            )
            volume_cfg = VolumeConfig(
                use_strict_ppv=True,
                ppv_lookback=7,
                ppv_obv_quality_min=50.0
            )
            df = scanner.calculate_weinstein_stage(df, 
                weinstein_config=weinstein_cfg,
                obv_config=obv_cfg,
                volume_config=volume_cfg)
        """
        if df is None or df.empty:
            return df
            
        # If insufficient data for MA calculation, add default columns for all expected outputs
        if len(df) < MIN_WEEKS_FOR_CALCULATION:
            symbol = df['tradingsymbol'].iloc[0] if 'tradingsymbol' in df.columns else 'Unknown'
            logging.warning(f"Insufficient data for Weinstein Stage calculation for {symbol} ({len(df)} weeks, need {MIN_WEEKS_FOR_CALCULATION}+)")
            
            # Weinstein stage columns
            df['weinstein_stage'] = 0  # Unknown stage
            df['stage_name'] = 'Unknown'
            df['stage_confidence'] = 0
            df['ma30'] = np.nan
            df['ma50'] = np.nan
            df['ma_short'] = np.nan
            df['ma_long'] = np.nan
            df['ma30_slope'] = 0
            df['ma_slope'] = 0
            df['trend_strength'] = 0
            df['price_vs_ma30_pct'] = 0
            df['price_vs_ma50_pct'] = 0
            
            # OBV columns
            df['obv'] = 0
            df['obv_trend'] = 0
            df['obv_trend_short'] = 0
            df['obv_trend_long'] = 0
            df['obv_quality_score'] = 50.0
            df['obv_bullish_divergence'] = 0
            df['obv_bearish_divergence'] = 0
            
            # VWAP columns
            df['typical_price'] = (df['high'] + df['low'] + df['close']) / 3
            df['vwap'] = df['close']  # Fallback to close price
            df['vwap_trend'] = 0
            df['price_above_vwap'] = True
            df['vwap_rising'] = False
            
            # Volume bar classification columns
            df['bar_type'] = 0
            df['is_ppv'] = False
            df['is_green'] = False
            df['is_red'] = False
            df['is_grey'] = True
            
            # Distribution warnings
            df['distribution_warnings'] = 0
            df['vwap_declining'] = False
            df['obv_declining'] = False
            df['vwap_not_rising'] = True
            df['price_below_vwap'] = False
            
            return df
        
        df = df.copy()
        
        # Use custom configs if provided, otherwise create defaults
        if weinstein_config is None:
            weinstein_config = WeinsteinConfig(
                ma_short_period=MA_PERIOD_30,
                ma_long_period=MA_PERIOD_50,
                rising_ma_threshold=MA30_SLOPE_THRESHOLD,
                declining_ma_threshold=MA30_DECLINE_THRESHOLD
            )
        
        if obv_config is None:
            obv_config = OBVConfig()
        
        if volume_config is None:
            volume_config = VolumeConfig(use_strict_ppv=strict_ppv)
        
        # Run the integrated enhanced analysis
        df = integrate_enhanced_analysis(df, weinstein_config, obv_config, volume_config)
        
        # Add backward compatibility columns - map new names to legacy names
        df['ma30'] = df['ma_short']  # Map ma_short to ma30
        df['ma50'] = df['ma_long']   # Map ma_long to ma50
        df['ma30_slope'] = df['ma_slope']  # Map ma_slope to ma30_slope
        
        # Calculate legacy metrics for compatibility
        df['trend_strength'] = abs(df['ma_slope'])
        df['price_vs_ma30_pct'] = ((df['close'] - df['ma_short']) / (df['ma_short'] + 1e-8) * 100)
        df['price_vs_ma50_pct'] = ((df['close'] - df['ma_long']) / (df['ma_long'] + 1e-8) * 100)
        
        # Add convenience flags (these columns already exist from integrate_enhanced_analysis)
        # Just ensure they're available for backward compatibility
        if 'price_above_vwap' not in df.columns:
            df['price_above_vwap'] = df['close'] > df['vwap']
        if 'vwap_rising' not in df.columns:
            df['vwap_rising'] = df['vwap_trend'] > 0
        
        # Calculate distribution warnings for informational purposes only
        # NOTE: The new EnhancedWeinsteinStage doesn't use these for stage classification
        # This is kept for legacy output compatibility and informational value
        df['distribution_warnings'] = 0
        df['vwap_declining'] = df['vwap_trend'] < -0.5
        df.loc[df['vwap_declining'], 'distribution_warnings'] += 1
        df['obv_declining'] = df['obv_trend'] < -OBV_TREND_THRESHOLD
        df.loc[df['obv_declining'], 'distribution_warnings'] += 1
        df['vwap_not_rising'] = df['vwap_trend'] <= VWAP_TREND_THRESHOLD
        df.loc[df['vwap_not_rising'], 'distribution_warnings'] += 1
        df['price_below_vwap'] = df['close'] < df['vwap']
        df.loc[df['price_below_vwap'], 'distribution_warnings'] += 1
        
        # Debug logging for enhanced stage calculation
        if len(df) >= MIN_WEEKS_FOR_CALCULATION:
            symbol = df['tradingsymbol'].iloc[0] if 'tradingsymbol' in df.columns else 'Unknown'
            current_ma30_slope = df['ma30_slope'].iloc[-1]
            current_price = df['close'].iloc[-1]
            current_ma30 = df['ma30'].iloc[-1]
            current_stage = df['weinstein_stage'].iloc[-1]
            current_confidence = df['stage_confidence'].iloc[-1]
            current_warnings = df['distribution_warnings'].iloc[-1]
            obv_trend = df['obv_trend'].iloc[-1]
            vwap_trend = df['vwap_trend'].iloc[-1]
            price_above_vwap = df['price_above_vwap'].iloc[-1]
            vwap_rising = df['vwap_rising'].iloc[-1]
            
            logging.info(f"  -> {symbol} Enhanced Stage Debug:")
            logging.info(f"     MA30_slope={current_ma30_slope:.2f}%, Price={current_price:.2f}, MA30={current_ma30:.2f}")
            logging.info(f"     Stage={current_stage} ({df['stage_name'].iloc[-1]}) - Confidence: {current_confidence:.1f}%")
            logging.info(f"     Distribution Warnings: {current_warnings}/4")
            logging.info(f"     OBV_trend={obv_trend:.2f}%, VWAP_trend={vwap_trend:.2f}%")
            logging.info(f"     Price_above_VWAP={price_above_vwap}, VWAP_rising={vwap_rising}")
        
        return df

    def analyze_stock(self, df: pd.DataFrame,
                           filter_stages: bool = FILTER_STAGES,
                           strict_ppv: bool = STRICT_PPV) -> Optional[pd.DataFrame]:
        """
        Complete stock analysis pipeline
        
        Performs all analysis in one pass:
        1. Data cleaning and validation
        2. Weinstein Stage calculation
        3. OBV calculation and divergence detection
        4. Volume bar classification (PPV/Green/Red/Grey)
        5. ATR and volatility analysis
        6. Signal generation
        
        Returns: Fully analyzed DataFrame with all metrics
        """
        if df is None or df.empty:
            return None
        
        df = df.copy()  # Avoid modifying original dataframe
        
        # Convert and clean date
        df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
        df = df.sort_values('date').reset_index(drop=True)
        
        # Clean and validate data
        numeric_columns = ['open', 'high', 'low', 'close', 'volume']
        for col in numeric_columns:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Convert volume to float early to avoid dtype warnings
        df['volume'] = df['volume'].astype(float)
        
        # Handle missing values
        df = df.dropna(subset=numeric_columns)
        if df.empty:
            logging.warning(f"No valid data after cleaning")
            return None
        
        # Ensure volume is positive
        df['volume'] = df['volume'].replace(0, 0.001)
        df.loc[df['volume'] < 0, 'volume'] = 0.001
        
        # Run complete analysis: Weinstein + OBV + Volume Classification
        # This is the ONLY place where volume classification happens
        # Pass through the strict_ppv parameter
        df = self.calculate_weinstein_stage(df, strict_ppv=strict_ppv)
        
        # Calculate technical indicators for signal generation
        df['body_length'] = abs(df['close'] - df['open'])
        df['body_length_ma10'] = df['body_length'].rolling(window=10, min_periods=1).mean()
        
        # Calculate True Range and ATR
        df['prev_close'] = df['close'].shift(1)
        df['tr'] = np.maximum(
            df['high'] - df['low'],
            np.maximum(
                abs(df['high'] - df['prev_close']),
                abs(df['low'] - df['prev_close'])
            )
        )
        df['atr'] = df['tr'].rolling(window=ATR_PERIOD, min_periods=1).mean()
        
        # Calculate volatility compression analysis
        df['atr_ma20'] = df['atr'].rolling(window=20, min_periods=1).mean()
        df['atr_ma50'] = df['atr'].rolling(window=MA_PERIOD_50, min_periods=1).mean()
        
        # Volatility compression ratio (lower = more compressed)
        df['volatility_compression'] = df['atr'] / (df['atr_ma20'] + 1e-8)
        df['volatility_compression_50'] = df['atr'] / (df['atr_ma50'] + 1e-8)
        
        # Identify low volatility periods (compression)
        df['low_volatility'] = df['volatility_compression'] < 0.8  # ATR below 80% of 20-week average
        df['extreme_compression'] = df['volatility_compression'] < 0.6  # ATR below 60% of 20-week average
        
        # Volatility breakout strength (higher ATR from compressed base)
        df['volatility_breakout'] = df['atr'] / (df['atr_ma50'] + 1e-8)  # Current ATR vs 50-week average
        
        # Add convenience flags
        df['is_up_day'] = df['close'] > df['open']
        df['is_down_day'] = df['close'] < df['open']
        
        # Check if OBV data exists (may be missing for insufficient data)
        if 'obv_trend' in df.columns:
            df['obv_positive_trend'] = df['obv_trend'] > 0
        else:
            df['obv_positive_trend'] = False
        
        # Enhanced long signal with Weinstein Stage filtering
        base_signal_condition = (
            df['is_up_day'] & 
            (df['is_ppv'] | df['is_green']) & 
            (df['body_length'] > BODY_THRESHOLD * df['body_length_ma10']) & 
            (df['tr'] > ATR_THRESHOLD * df['atr']) &
            (df['close'] > df['open'])  # Additional confirmation
        )
        
        # Apply stage filtering if enabled
        if filter_stages and 'weinstein_stage' in df.columns:
            # Only allow signals in Stage 2 (Markup) and Stage 3 (Distribution)
            # Filter out Stage 1 (Accumulation) and Stage 4 (Markdown)
            stage_filter = (df['weinstein_stage'].isin([2, 3]))
            df['long_signal'] = (base_signal_condition & stage_filter).astype(int)
        else:
            df['long_signal'] = base_signal_condition.astype(int)
        
        # Enhanced signal strength with volatility scaling
        df['signal_strength'] = 0.0
        signal_weeks = df['long_signal'] == 1
        if signal_weeks.any():
            # Base signal strength (volume and body length)
            volume_ma10 = df['volume'].rolling(window=10, min_periods=1).mean()
            base_strength = (
                (df.loc[signal_weeks, 'volume'] / (volume_ma10.loc[signal_weeks] + 1e-8)) * 
                (df.loc[signal_weeks, 'body_length'] / (df.loc[signal_weeks, 'body_length_ma10'] + 1e-8))
            )
            
            # Volatility scaling factor
            # Higher multiplier for breakouts from low volatility bases
            volatility_multiplier = np.where(
                df.loc[signal_weeks, 'extreme_compression'], 2.0,  # 2x for extreme compression
                np.where(
                    df.loc[signal_weeks, 'low_volatility'], 1.5,  # 1.5x for low volatility
                    1.0  # 1x for normal volatility
                )
            )
            
            # ATR breakout bonus (higher ATR from compressed base)
            atr_breakout_bonus = np.maximum(1.0, df.loc[signal_weeks, 'volatility_breakout'])
            
            # Final signal strength
            df.loc[signal_weeks, 'signal_strength'] = (
                base_strength * volatility_multiplier * atr_breakout_bonus
            )
        
        # Log statistics
        symbol = df['tradingsymbol'].iloc[0] if 'tradingsymbol' in df.columns else 'Unknown'
        current_stage = df['stage_name'].iloc[-1] if 'stage_name' in df.columns else 'Unknown'
        obv_trend = df['obv_trend'].iloc[-1] if 'obv_trend' in df.columns else 0
        obv_quality_score = df['obv_quality_score'].iloc[-1] if 'obv_quality_score' in df.columns else 0
        vwap_trend = df['vwap_trend'].iloc[-1] if 'vwap_trend' in df.columns else 0
        volatility_compression = df['volatility_compression'].iloc[-1] if 'volatility_compression' in df.columns else 1.0
        extreme_compression = df['extreme_compression'].iloc[-1] if 'extreme_compression' in df.columns else False
        
        stats = {
            'PPV': int(df['is_ppv'].sum()),
            'Green': int(df['is_green'].sum()),
            'Red': int(df['is_red'].sum()),
            'Grey': int(df['is_grey'].sum()),
            'Long_Signals': int(df['long_signal'].sum()),
            'Current_Stage': current_stage,
            'OBV_Trend': round(float(obv_trend), 1),
            'OBV_Quality': round(float(obv_quality_score), 1),
            'VWAP_Trend': round(float(vwap_trend), 1),
            'Vol_Compression': round(float(volatility_compression), 2),
            'Extreme_Comp': bool(extreme_compression),
            'Avg_ATR': round(float(df['atr'].mean()), 2)
        }
        
        logging.info(f"Analyzed {symbol}: " + 
                    ", ".join([f"{k}={v}" for k, v in stats.items()]))
        
        # Debug logging for signal analysis
        if df['long_signal'].sum() > 0:
            logging.info(f"  -> {symbol} has {df['long_signal'].sum()} long signals")
        elif df['is_ppv'].sum() > 0 or df['is_green'].sum() > 0:
            logging.info(f"  -> {symbol} has {df['is_ppv'].sum()} PPV + {df['is_green'].sum()} Green bars but no signals")
        if 'weinstein_stage' in df.columns:
            stage_counts = df['weinstein_stage'].value_counts()
            logging.info(f"  -> {symbol} stage distribution: {dict(stage_counts)}")
        
        return df

    def process_summary_data(self, df: pd.DataFrame, filter_stages: bool = FILTER_STAGES, strict_ppv: bool = STRICT_PPV) -> Optional[Dict]:
        """
        Process summary statistics with additional metrics
        
        Note: This method can accept either raw or pre-analyzed dataframes.
        If the dataframe doesn't have analysis columns, it will analyze first.
        For efficiency in batch processing, prefer using _extract_summary() with pre-analyzed data.
        """
        if df is None or df.empty:
            return None
        
        # Check if already analyzed (has required columns)
        if 'weinstein_stage' not in df.columns:
            # Not analyzed yet, run analysis
            df = self.analyze_stock(df, filter_stages=filter_stages, strict_ppv=strict_ppv)
            if df is None or df.empty:
                return None
        
        return self._extract_summary(df)
    
    def _extract_summary(self, df: pd.DataFrame) -> Optional[Dict]:
        """
        Extract summary statistics from already-analyzed dataframe
        
        This method assumes the dataframe has already been analyzed by analyze_stock().
        Use this for efficiency when you've already analyzed the data.
        """
        if df is None or df.empty:
            return None
            
        # Determine last bar type
        last_bar_type_map = {1: "PPV", 2: "Red", 3: "Green", 0: "Grey"}
        last_bar_type = last_bar_type_map.get(df['bar_type'].iloc[-1], "Unknown")
        
        # Get current Weinstein Stage information
        current_stage = df['weinstein_stage'].iloc[-1] if 'weinstein_stage' in df.columns else 0
        current_stage_name = df['stage_name'].iloc[-1] if 'stage_name' in df.columns else 'Unknown'
        stage_confidence = df['stage_confidence'].iloc[-1] if 'stage_confidence' in df.columns else 0
        distribution_warnings = df['distribution_warnings'].iloc[-1] if 'distribution_warnings' in df.columns else 0
        ma30_slope = df['ma30_slope'].iloc[-1] if 'ma30_slope' in df.columns else 0
        price_vs_ma30 = df['price_vs_ma30_pct'].iloc[-1] if 'price_vs_ma30_pct' in df.columns else 0
        price_vs_ma50 = df['price_vs_ma50_pct'].iloc[-1] if 'price_vs_ma50_pct' in df.columns else 0
        
        # Get Enhanced OBV quality metrics
        obv_trend = df['obv_trend'].iloc[-1] if 'obv_trend' in df.columns else 0
        obv_quality_score = df['obv_quality_score'].iloc[-1] if 'obv_quality_score' in df.columns else 0
        obv_bullish_divergence = df['obv_bullish_divergence'].iloc[-1] if 'obv_bullish_divergence' in df.columns else 0
        obv_bearish_divergence = df['obv_bearish_divergence'].iloc[-1] if 'obv_bearish_divergence' in df.columns else 0
        vwap_trend = df['vwap_trend'].iloc[-1] if 'vwap_trend' in df.columns else 0
        price_vs_vwap = df['price_above_vwap'].iloc[-1] if 'price_above_vwap' in df.columns else False
        vwap_rising = df['vwap_rising'].iloc[-1] if 'vwap_rising' in df.columns else False
        
        # Get volatility metrics
        volatility_compression = df['volatility_compression'].iloc[-1] if 'volatility_compression' in df.columns else 1.0
        volatility_breakout = df['volatility_breakout'].iloc[-1] if 'volatility_breakout' in df.columns else 1.0
        low_volatility = df['low_volatility'].iloc[-1] if 'low_volatility' in df.columns else False
        extreme_compression = df['extreme_compression'].iloc[-1] if 'extreme_compression' in df.columns else False
        
        # Calculate additional metrics
        recent_df = df.tail(5)  # Last 5 weeks
        recent_signals = recent_df['long_signal'].sum()
        
        # Price momentum
        price_change_pct = ((df['close'].iloc[-1] - df['close'].iloc[0]) / df['close'].iloc[0]) * 100
        
        # Volume trend
        recent_volume_avg = df['volume'].tail(5).mean()
        overall_volume_avg = df['volume'].mean()
        volume_trend = (recent_volume_avg / overall_volume_avg - 1) * 100
        
        return {
            'Symbol': df['tradingsymbol'].iloc[0],
            'Last_Close': round(df['close'].iloc[-1], 2),
            'Price_Change_Pct': round(price_change_pct, 2),
            'Avg_Volume': int(df['volume'].mean()),
            'Volume_Trend_Pct': round(volume_trend, 2),
            'PPV_Count': int(df['is_ppv'].sum()),
            'Green_Bar_Count': int(df['is_green'].sum()),
            'Red_Bar_Count': int(df['is_red'].sum()),
            'Grey_Bar_Count': int(df['is_grey'].sum()),
            'Long_Signal_Count': int(df['long_signal'].sum()),
            'Recent_Signals_5w': int(recent_signals),
            'Last_Bar_Type': last_bar_type,
            'Last_Long_Signal': int(df['long_signal'].iloc[-1]),
            'Max_Signal_Strength': round(df['signal_strength'].max(), 2) if df['signal_strength'].max() > 0 else 0,
            'Avg_ATR': round(df['atr'].mean(), 2),
            'Current_Stage': current_stage_name,
            'Stage_Number': int(current_stage),
            'Stage_Confidence': round(stage_confidence, 1),
            'Distribution_Warnings': int(distribution_warnings),
            'MA30_Slope_Pct': round(ma30_slope, 2),
            'Price_vs_MA30_Pct': round(price_vs_ma30, 2),
            'Price_vs_MA50_Pct': round(price_vs_ma50, 2),
            'OBV_Trend_Pct': round(obv_trend, 2),
            'OBV_Quality_Score': round(obv_quality_score, 1),
            'OBV_Bullish_Divergence': bool(obv_bullish_divergence),
            'OBV_Bearish_Divergence': bool(obv_bearish_divergence),
            'VWAP_Trend_Pct': round(vwap_trend, 2),
            'Price_Above_VWAP': bool(price_vs_vwap),
            'VWAP_Rising': bool(vwap_rising),
            'Volatility_Compression': round(volatility_compression, 2),
            'Volatility_Breakout': round(volatility_breakout, 2),
            'Low_Volatility': bool(low_volatility),
            'Extreme_Compression': bool(extreme_compression)
        }

    def process_day_wise_data(self, df: pd.DataFrame, filter_stages: bool = FILTER_STAGES, strict_ppv: bool = STRICT_PPV) -> Optional[pd.DataFrame]:
        """
        Process day-wise data with improved pivot structure
        
        Note: This method can accept either raw or pre-analyzed dataframes.
        If the dataframe doesn't have analysis columns, it will analyze first.
        For efficiency in batch processing, prefer using _extract_day_wise() with pre-analyzed data.
        """
        if df is None or df.empty:
            return None
        
        # Check if already analyzed (has required columns)
        if 'weinstein_stage' not in df.columns:
            # Not analyzed yet, run analysis
            df = self.analyze_stock(df, filter_stages=filter_stages, strict_ppv=strict_ppv)
            if df is None or df.empty:
                return None
        
        return self._extract_day_wise(df)
    
    def _extract_day_wise(self, df: pd.DataFrame) -> Optional[pd.DataFrame]:
        """
        Extract day-wise pivot from already-analyzed dataframe
        
        This method assumes the dataframe has already been analyzed by analyze_stock().
        Use this for efficiency when you've already analyzed the data.
        """
        if df is None or df.empty:
            return None
        
        # Create pivot table with multiple metrics including stage, volume quality, and volatility information
        try:
            pivot_data = df.pivot_table(
                index='tradingsymbol', 
                columns='date', 
                values=['bar_type', 'long_signal', 'signal_strength', 'weinstein_stage', 'obv_trend', 'vwap_trend', 'volatility_compression', 'volatility_breakout'],
                fill_value=0
            )
            return pivot_data
        except Exception as e:
            logging.error(f"Error creating pivot table: {e}")
            return None

    def scan_stocks(self, input_csv: str, weeks_back: int = DEFAULT_WEEKS_BACK, filter_stages: bool = FILTER_STAGES, strict_ppv: bool = STRICT_PPV) -> Tuple[List[Dict], List[pd.DataFrame]]:
        """Main scanning function"""
        if not os.path.exists(input_csv):
            logging.error(f"Input file {input_csv} not found!")
            return [], []
        
        try:
            symbols_df = pd.read_csv(input_csv)
        except Exception as e:
            logging.error(f"Error reading CSV file: {e}")
            return [], []
        
        if "Symbol" not in symbols_df.columns:
            logging.error("'Symbol' column not found in CSV!")
            return [], []
        
        symbols = symbols_df["Symbol"].unique().tolist()  # Remove duplicates
        summary_results = []
        day_wise_dfs = []
        total_symbols = len(symbols)
        
        logging.info(f"Starting scan of {total_symbols} symbols...")
        
        # Process in batches
        for batch_start in range(0, total_symbols, self.BATCH_SIZE):
            batch_end = min(batch_start + self.BATCH_SIZE, total_symbols)
            batch_symbols = symbols[batch_start:batch_end]
            
            logging.info(f"Processing batch {batch_start+1}-{batch_end} of {total_symbols} symbols...")
            
            for i, symbol in enumerate(batch_symbols):
                global_idx = batch_start + i + 1
                logging.info(f"Processing {symbol} ({global_idx}/{total_symbols})...")
                
                df = self.fetch_historical_data(symbol, weeks_back)
                
                if df is not None:
                    # Analyze stock ONCE (this is the expensive operation)
                    analyzed_df = self.analyze_stock(df, filter_stages=filter_stages, strict_ppv=strict_ppv)
                    
                    if analyzed_df is not None:
                        # Extract summary from already-analyzed data (fast)
                        summary_result = self._extract_summary(analyzed_df)
                        if summary_result:
                            summary_results.append(summary_result)
                        
                        # Extract day-wise from already-analyzed data (fast)
                        day_wise_result = self._extract_day_wise(analyzed_df)
                        if day_wise_result is not None:
                            day_wise_dfs.append(day_wise_result)
            
            # Pause between batches
            if batch_end < total_symbols:
                logging.info("Pausing between batches...")
                time.sleep(5)
        
        logging.info(f"Scan completed. Processed {len(summary_results)} symbols successfully.")
        return summary_results, day_wise_dfs

    def save_results(self, summary_results: List[Dict], day_wise_dfs: List[pd.DataFrame]) -> str:
        """Save results to Excel with enhanced formatting"""
        if not summary_results and not day_wise_dfs:
            logging.warning("No data to save.")
            return ""
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = f'ppv_stock_scan_results_{timestamp}.xlsx'
        
        try:
            with ExcelWriter(output_file, engine='xlsxwriter') as writer:
                workbook = writer.book
                
                # Define formats
                header_format = workbook.add_format({
                    'bold': True, 'bg_color': '#4472C4', 'font_color': 'white',
                    'border': 1, 'align': 'center'
                })
                
                # Summary sheet
                if summary_results:
                    summary_df = pd.DataFrame(summary_results)
                    
                    # Sort by stage (prefer Stage 2 and 3), then recent signals and long signal count
                    summary_df = summary_df.sort_values([
                        'Stage_Number', 'Recent_Signals_5w', 'Long_Signal_Count', 'Max_Signal_Strength'
                    ], ascending=[True, False, False, False])
                    
                    summary_df.to_excel(writer, sheet_name='Summary', index=False)
                    
                    # Format summary sheet
                    summary_worksheet = writer.sheets['Summary']
                    summary_worksheet.set_row(0, 20, header_format)
                    
                    # Auto-adjust column widths
                    for i, col in enumerate(summary_df.columns):
                        max_length = max(len(str(col)), summary_df[col].astype(str).str.len().max())
                        summary_worksheet.set_column(i, i, min(max_length + 2, 15))
                
                # Day-wise sheet
                if day_wise_dfs:
                    day_wise_combined = pd.concat(day_wise_dfs, axis=0)
                    day_wise_combined.to_excel(writer, sheet_name='Day_Wise')
                    
                    # Apply conditional formatting
                    self._apply_day_wise_formatting(writer, day_wise_combined)
            
            logging.info(f"Results saved to {output_file}")
            return output_file
            
        except Exception as e:
            logging.error(f"Error saving results: {e}")
            return ""

    def _apply_day_wise_formatting(self, writer, day_wise_df):
        """Apply conditional formatting to day-wise sheet"""
        try:
            workbook = writer.book
            worksheet = writer.sheets['Day_Wise']
            
            # Define formats
            formats = {
                'ppv': workbook.add_format({'bg_color': '#ADD8E6'}),      # Light blue
                'red': workbook.add_format({'bg_color': '#FF6347'}),      # Red
                'green': workbook.add_format({'bg_color': '#90EE90'}),    # Light green
                'grey': workbook.add_format({'bg_color': '#D3D3D3'}),     # Light grey
                'signal': workbook.add_format({'bold': True, 'border': 1, 'bg_color': '#FFFF00'}),  # Yellow
                'stage1': workbook.add_format({'bg_color': '#FFE4B5'}),   # Moccasin - Accumulation
                'stage2': workbook.add_format({'bg_color': '#98FB98'}),   # Pale green - Markup
                'stage3': workbook.add_format({'bg_color': '#F0E68C'}),   # Khaki - Distribution
                'stage4': workbook.add_format({'bg_color': '#FFB6C1'})    # Light pink - Markdown
            }
            
            num_rows = day_wise_df.shape[0]
            
            # Get column ranges based on multi-index structure
            if hasattr(day_wise_df.columns, 'levels'):
                num_dates = len(day_wise_df.columns.levels[1])
                
                # Apply formatting for bar_type columns
                bar_type_start = 1
                bar_type_end = bar_type_start + num_dates - 1
                
                for value, color_format in [(1, 'ppv'), (2, 'red'), (3, 'green'), (0, 'grey')]:
                    worksheet.conditional_format(
                        1, bar_type_start, num_rows, bar_type_end,
                        {'type': 'cell', 'criteria': '==', 'value': value, 'format': formats[color_format]}
                    )
                
                # Apply formatting for long_signal columns
                signal_start = bar_type_end + 1
                signal_end = signal_start + num_dates - 1
                
                worksheet.conditional_format(
                    1, signal_start, num_rows, signal_end,
                    {'type': 'cell', 'criteria': '==', 'value': 1, 'format': formats['signal']}
                )
                
                # Apply formatting for weinstein_stage columns
                stage_start = signal_end + 1
                stage_end = stage_start + num_dates - 1
                
                for stage, color_format in [(1, 'stage1'), (2, 'stage2'), (3, 'stage3'), (4, 'stage4')]:
                    worksheet.conditional_format(
                        1, stage_start, num_rows, stage_end,
                        {'type': 'cell', 'criteria': '==', 'value': stage, 'format': formats[color_format]}
                    )
                
        except Exception as e:
            logging.error(f"Error applying formatting: {e}")

def main():
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "iTC1DHqzLnRftYGHTHKYqq9C5XXOtc0l"
    INPUT_CSV = "data\\MCAP-great2500.csv"
    
    # Initialize scanner
    scanner = PPVScanner(API_KEY, ACCESS_TOKEN)
    
    # Run scan with configurable parameters
    summary_results, day_wise_dfs = scanner.scan_stocks(INPUT_CSV, weeks_back=DEFAULT_WEEKS_BACK, filter_stages=FILTER_STAGES, strict_ppv=STRICT_PPV)
    
    # Save results
    if summary_results or day_wise_dfs:
        output_file = scanner.save_results(summary_results, day_wise_dfs)
        if output_file:
            print(f"\n{'='*50}")
            print(f"SCAN COMPLETED SUCCESSFULLY!")
            print(f"Results saved to: {output_file}")
            print(f"Total symbols processed: {len(summary_results)}")
            if summary_results:
                signals_found = sum(1 for r in summary_results if r['Last_Long_Signal'] == 1)
                stage2_count = sum(1 for r in summary_results if r['Stage_Number'] == 2)
                stage3_count = sum(1 for r in summary_results if r['Stage_Number'] == 3)
                print(f"Stocks with current long signals: {signals_found}")
                print(f"Stocks in Stage 2 (Markup): {stage2_count}")
                print(f"Stocks in Stage 3 (Distribution): {stage3_count}")
                print(f"Note: Signals filtered to only show Stage 2 & 3 stocks")
            print(f"{'='*50}")
    else:
        print("No data was processed successfully.")

if __name__ == "__main__":
    main()