import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import pandas_ta as ta # Make sure pandas_ta is installed: pip install pandas_ta
from datetime import datetime, timedelta
import openpyxl
from openpyxl.styles import PatternFill, Font
import logging
import os
import pickle
import time # Import time for potential delays

# ==============================================================================
# Configuration
# ==============================================================================

# --- Logging Setup ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Kite Connect API Credentials ---
# IMPORTANT: Replace with your actual credentials.
# Consider using environment variables or a secure config file instead of hardcoding.
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "u7rj2D6CmkVVmahVO5ywn8p8GfRD1ZGX"

# --- Date Range ---
# Defines the period for which the MBI analysis will be performed
ANALYSIS_DAYS = 30
# Defines the lookback period needed for indicators (52 weeks + buffer for EMA)
LOOKBACK_DAYS = 370 # Approx 1 year + buffer for 200 EMA calculation

# --- Caching Setup ---
CACHE_DIR = "MBI_Cache"
INSTRUMENTS_CACHE_FILE = os.path.join(CACHE_DIR, "nse_instruments.pkl")
HISTORICAL_CACHE_DIR = os.path.join(CACHE_DIR, "historical_prefetched") # Cache dir for prefetched data
os.makedirs(HISTORICAL_CACHE_DIR, exist_ok=True)
os.makedirs(CACHE_DIR, exist_ok=True) # Ensure base cache dir exists

# --- Custom Universe ---
# Path to your CSV file containing stock symbols. Must have a 'Symbol' column.
# Use os.path.join for cross-platform compatibility.
UNIVERSE_CSV = os.path.join("data", "MCAP7000.csv")

# --- Excel Output ---
EXCEL_FILE = "mbi_sheet_optimized.xlsx"

# --- API Call Delay ---
# Optional delay between historical data API calls to avoid hitting rate limits strictly
API_DELAY_SECONDS = 0.3 # Adjust as needed (e.g., 0.3 to 0.5)

# ==============================================================================
# Helper Functions
# ==============================================================================

def load_nse_instruments(kite_instance):
    """Loads NSE instruments from cache or fetches from API."""
    if os.path.exists(INSTRUMENTS_CACHE_FILE):
        try:
            with open(INSTRUMENTS_CACHE_FILE, "rb") as f:
                instruments = pickle.load(f)
            logger.info(f"Loaded NSE instruments from cache: {INSTRUMENTS_CACHE_FILE}")
            # Quick validation: check if it's a list and has expected keys
            if isinstance(instruments, list) and len(instruments) > 0 and 'instrument_token' in instruments[0]:
                 return instruments
            else:
                 logger.warning("Cached instruments file seems invalid. Refetching.")
                 os.remove(INSTRUMENTS_CACHE_FILE) # Remove invalid cache
        except Exception as e:
             logger.error(f"Error loading instruments from cache: {e}. Refetching.")
             if os.path.exists(INSTRUMENTS_CACHE_FILE):
                 os.remove(INSTRUMENTS_CACHE_FILE) # Remove potentially corrupted cache

    logger.info("Fetching NSE instruments from Kite API...")
    try:
        instruments = kite_instance.instruments(exchange="NSE")
        with open(INSTRUMENTS_CACHE_FILE, "wb") as f:
            pickle.dump(instruments, f)
        logger.info(f"Cached NSE instruments to {INSTRUMENTS_CACHE_FILE}")
        return instruments
    except Exception as e:
        logger.error(f"Failed to fetch NSE instruments from API: {e}")
        raise # Reraise exception as this is critical

def load_universe_symbols():
    """Loads stock symbols from the custom universe CSV file."""
    if not os.path.exists(UNIVERSE_CSV):
        logger.error(f"Universe CSV not found: {UNIVERSE_CSV}")
        raise FileNotFoundError(f"Universe CSV not found: {UNIVERSE_CSV}")
    try:
        df = pd.read_csv(UNIVERSE_CSV)
        if 'Symbol' not in df.columns:
            logger.error("Universe CSV must have a 'Symbol' column.")
            raise ValueError("Universe CSV must have a 'Symbol' column.")
        symbols = df['Symbol'].unique().tolist()
        logger.info(f"Loaded {len(symbols)} unique symbols from {UNIVERSE_CSV}")
        return symbols
    except Exception as e:
        logger.error(f"Error reading Universe CSV {UNIVERSE_CSV}: {e}")
        raise

def get_historical_data_cached(kite_instance, symbol, token, from_date, to_date, interval="day"):
    """Fetches historical data using caching, adapted for pre-fetching larger chunks."""
    # Use a consistent date format for filenames
    from_date_str = from_date.strftime('%Y%m%d')
    to_date_str = to_date.strftime('%Y%m%d')
    cache_file = os.path.join(HISTORICAL_CACHE_DIR, f"{symbol}_{token}_{from_date_str}_{to_date_str}_{interval}.pkl")

    if os.path.exists(cache_file):
        try:
            with open(cache_file, "rb") as f:
                data = pickle.load(f)
            logger.info(f"Loading historical data for {symbol} ({from_date_str}-{to_date_str}) from cache.")
             # Basic validation
            if isinstance(data, list):
                 return data
            else:
                 logger.warning(f"Invalid data format in cache file {cache_file}. Refetching.")
                 os.remove(cache_file)
        except Exception as e:
            logger.warning(f"Could not load {symbol} from cache file {cache_file}: {e}. Refetching.")
            if os.path.exists(cache_file):
                os.remove(cache_file)

    logger.info(f"Fetching historical data for {symbol} ({from_date_str}-{to_date_str}) from Kite API...")
    try:
        # Add delay before API call
        time.sleep(API_DELAY_SECONDS)
        data = kite_instance.historical_data(
            instrument_token=token,
            from_date=from_date,
            to_date=to_date,
            interval=interval
        )
        # Save to cache only if data is not empty
        if data:
             with open(cache_file, "wb") as f:
                 pickle.dump(data, f)
             logger.info(f"Cached historical data for {symbol} to {cache_file}")
        else:
             logger.info(f"No data returned for {symbol} ({from_date_str}-{to_date_str}). Not caching.")
        return data
    except Exception as e:
        logger.error(f"Error fetching historical data for {symbol} (Token: {token}): {e}")
        return [] # Return empty list on error

# ==============================================================================
# Main Execution
# ==============================================================================

def run_mbi_analysis():
    logger.info("Starting MBI Analysis Script")

    # --- Initialize Kite Connect ---
    try:
        kite = KiteConnect(api_key=API_KEY)
        # You might need to handle login flow here if ACCESS_TOKEN is expired
        # For simplicity, assuming ACCESS_TOKEN is valid.
        kite.set_access_token(ACCESS_TOKEN)
        logger.info("Kite Connect initialized.")
        # Verify connection (optional)
        # profile = kite.profile()
        # logger.info(f"Connected as {profile.get('user_id')}")
    except Exception as e:
        logger.error(f"Kite Connect initialization failed: {e}")
        return # Exit if connection fails

    # --- Define Date Ranges ---
    end_date = datetime.now().date()
    analysis_start_date = end_date - timedelta(days=ANALYSIS_DAYS)
    overall_start_date = analysis_start_date - timedelta(days=LOOKBACK_DAYS)
    logger.info(f"Analysis period: {analysis_start_date} to {end_date}")
    logger.info(f"Required historical data range: {overall_start_date} to {end_date}")

    # --- Load Instruments and Universe ---
    try:
        instruments = load_nse_instruments(kite)
        instruments_df = pd.DataFrame(instruments)
        # Filter for NSE Equity instruments
        equity_instruments = instruments_df[
            (instruments_df["segment"] == "NSE") &
            (instruments_df["instrument_type"] == "EQ")
        ].copy()
        logger.info(f"Found {len(equity_instruments)} NSE Equity instruments.")

        # Load custom universe symbols
        custom_symbols = load_universe_symbols()

        # Filter equity instruments based on the custom universe
        equity_instruments = equity_instruments[equity_instruments["tradingsymbol"].isin(custom_symbols)]
        logger.info(f"Filtered down to {len(equity_instruments)} instruments based on {UNIVERSE_CSV}.")

        if equity_instruments.empty:
             logger.error("No matching instruments found for the symbols in the universe file. Exiting.")
             return

        instrument_map = equity_instruments.set_index('instrument_token')['tradingsymbol'].to_dict()
        stock_symbols = equity_instruments["tradingsymbol"].tolist()
        instrument_tokens = equity_instruments["instrument_token"].tolist()

    except Exception as e:
        logger.error(f"Error during instrument/universe loading: {e}")
        return

    # --- Pre-fetch All Required Historical Data ---
    logger.info("--- Starting Historical Data Pre-fetching ---")
    all_historical_data = {}
    fetch_count = 0
    total_instruments = len(equity_instruments)

    for token, symbol in instrument_map.items():
        fetch_count += 1
        logger.info(f"Fetching data for {symbol} ({token}) [{fetch_count}/{total_instruments}]...")
        data_list = get_historical_data_cached(kite, symbol, token, overall_start_date, end_date)

        if data_list:
            df = pd.DataFrame(data_list)
            try:
                # Convert date, remove timezone, set index
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                df.set_index('date', inplace=True)
                # Ensure correct data types for calculations
                for col in ['open', 'high', 'low', 'close', 'volume']:
                    if col in df.columns:
                         df[col] = pd.to_numeric(df[col], errors='coerce')
                df.dropna(subset=['open', 'high', 'low', 'close'], inplace=True) # Drop rows where OHLC is invalid
                if not df.empty:
                     all_historical_data[token] = df
                else:
                     logger.warning(f"DataFrame empty for {symbol} after type conversion/dropna.")
            except Exception as e:
                 logger.error(f"Error processing DataFrame for {symbol}: {e}")
        else:
            logger.warning(f"No historical data returned or loaded from cache for {symbol}.")

    logger.info(f"--- Finished Pre-fetching. Successfully loaded data for {len(all_historical_data)} out of {total_instruments} instruments ---")

    if not all_historical_data:
        logger.error("No historical data could be fetched for any stock in the universe. Cannot proceed.")
        return

    # --- Initialize MBI Results Lists ---
    dates = []
    fifty_two_wk_highs = []
    fifty_two_wk_lows = []
    up_4_5 = []
    down_4_5 = []
    above_10_ema = []
    above_20_ema = []
    above_50_ema = []
    above_200_ema = []
    ratio_4_5 = []
    day_colors = []

    # --- Excel Formatting Setup ---
    green_fill = PatternFill(start_color="00FF00", end_color="00FF00", fill_type="solid")
    red_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
    orange_fill = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
    black_font = Font(color="000000")
    white_font = Font(color="FFFFFF") # For dark fills

    # --- Main Daily Analysis Loop ---
    logger.info("--- Starting Daily MBI Calculation Loop ---")
    current_date = analysis_start_date
    while current_date <= end_date:
        current_date_str = current_date.strftime('%Y-%m-%d')
        logger.info(f"Processing data for {current_date_str}...")
        # Convert current_date to datetime for comparison with index
        current_date_dt = pd.to_datetime(current_date)

        # Initialize daily counters
        day_52wk_high_count = 0
        day_52wk_low_count = 0
        day_up_4_5_count = 0
        day_down_4_5_count = 0
        day_above_10_ema_count = 0
        day_above_20_ema_count = 0
        day_above_50_ema_count = 0
        day_above_200_ema_count = 0
        total_stocks_processed_today = 0 # Track stocks with data for the day

        # Check if it's likely a non-trading day (heuristic: check first few stocks)
        is_trading_day = False
        check_limit = min(5, len(all_historical_data)) # Check up to 5 stocks
        checked_tokens = 0
        for token, df in all_historical_data.items():
             if checked_tokens >= check_limit: break
             if not df[df.index.date == current_date].empty:
                  is_trading_day = True
                  break
             checked_tokens += 1

        if not is_trading_day and len(all_historical_data)>0:
             logger.info(f"Skipping {current_date_str} - likely a non-trading day (no data found in sample).")
             current_date += timedelta(days=1)
             continue

        # --- Inner loop through stocks for the current day ---
        for token in instrument_tokens:
            if token not in all_historical_data:
                continue # Skip if data wasn't pre-fetched

            full_stock_df = all_historical_data[token]

            # Slice the DataFrame to include data ONLY up to the current date
            data_upto_current_date = full_stock_df[full_stock_df.index <= current_date_dt].copy()

            if data_upto_current_date.empty:
                continue # No data available for this stock up to this date

            # Get the data for the specific current day
            stock_data_today = data_upto_current_date[data_upto_current_date.index.date == current_date]

            if stock_data_today.empty:
                continue # Stock didn't trade today

            total_stocks_processed_today += 1
            latest_row = stock_data_today.iloc[-1] # Get the row for the current day

            # --- Calculations ---
            try:
                # 52-week high/low calculation
                lookback_52w_start = current_date_dt - timedelta(days=365)
                # Ensure we use data_upto_current_date for lookback ending today
                data_last_52_weeks = data_upto_current_date[data_upto_current_date.index >= lookback_52w_start]

                if not data_last_52_weeks.empty:
                    fifty_two_wk_high = data_last_52_weeks["high"].max()
                    fifty_two_wk_low = data_last_52_weeks["low"].min()

                    current_high = latest_row["high"]
                    current_low = latest_row["low"]

                    # Check if today's high/low breached the 52-week boundaries
                    if pd.notna(current_high) and pd.notna(fifty_two_wk_high) and current_high >= fifty_two_wk_high:
                        day_52wk_high_count += 1
                    if pd.notna(current_low) and pd.notna(fifty_two_wk_low) and current_low <= fifty_two_wk_low:
                        day_52wk_low_count += 1

                # Percentage change calculation
                current_close = latest_row["close"]
                current_open = latest_row["open"]
                if pd.notna(current_open) and pd.notna(current_close) and current_open != 0:
                    percent_change = ((current_close - current_open) / current_open) * 100
                    if percent_change >= 4.5:
                        day_up_4_5_count += 1
                    elif percent_change <= -4.5:
                        day_down_4_5_count += 1

                # EMA Calculation (using pandas_ta on the slice ending today)
                # Calculate EMAs - append=True modifies the DataFrame slice directly
                data_upto_current_date.ta.ema(length=10, append=True, col="EMA_10")
                data_upto_current_date.ta.ema(length=20, append=True, col="EMA_20")
                data_upto_current_date.ta.ema(length=50, append=True, col="EMA_50")
                data_upto_current_date.ta.ema(length=200, append=True, col="EMA_200")

                # Get the EMA values for the current day (last row of the slice)
                emas_today = data_upto_current_date.iloc[-1]

                if pd.notna(emas_today.get("EMA_10")) and pd.notna(current_close) and current_close > emas_today["EMA_10"]:
                    day_above_10_ema_count += 1
                if pd.notna(emas_today.get("EMA_20")) and pd.notna(current_close) and current_close > emas_today["EMA_20"]:
                    day_above_20_ema_count += 1
                if pd.notna(emas_today.get("EMA_50")) and pd.notna(current_close) and current_close > emas_today["EMA_50"]:
                    day_above_50_ema_count += 1
                if pd.notna(emas_today.get("EMA_200")) and pd.notna(current_close) and current_close > emas_today["EMA_200"]:
                    day_above_200_ema_count += 1

            except Exception as e:
                 symbol = instrument_map.get(token, str(token))
                 logger.warning(f"Could not calculate indicators for {symbol} on {current_date_str}: {e}")
                 # Optionally decrement total_stocks_processed_today if calculation fails critically
                 # total_stocks_processed_today -= 1 # Uncomment if a calc failure invalidates the stock for the day

        # --- Aggregation and Scoring for the day ---
        if total_stocks_processed_today == 0:
            logger.warning(f"No stocks processed for {current_date_str}. Skipping aggregation for this day.")
            current_date += timedelta(days=1)
            continue # Skip appending results for this day

        # Calculate percentages
        up_4_5_percent = (day_up_4_5_count / total_stocks_processed_today) * 100
        down_4_5_percent = (day_down_4_5_count / total_stocks_processed_today) * 100
        above_10_ema_percent = (day_above_10_ema_count / total_stocks_processed_today) * 100
        above_20_ema_percent = (day_above_20_ema_count / total_stocks_processed_today) * 100
        above_50_ema_percent = (day_above_50_ema_count / total_stocks_processed_today) * 100
        above_200_ema_percent = (day_above_200_ema_count / total_stocks_processed_today) * 100

        # Calculate 4.5R ratio
        ratio_4_5_value = (day_up_4_5_count / day_down_4_5_count) * 100 if day_down_4_5_count > 0 else 9999

        # Scoring for day color
        score = 0
        if day_52wk_low_count > day_52wk_high_count: score -= 1
        else: score += 1

        if up_4_5_percent > down_4_5_percent: score += 1
        else: score -= 1

        if ratio_4_5_value > 400: score += 1
        elif ratio_4_5_value < 50: score -= 1

        # Thresholds based on *percentage* of stocks above EMA
        if above_10_ema_percent < 15: score += 1
        if above_20_ema_percent < 20: score += 1
        if above_50_ema_percent < 25: score += 1
        if above_200_ema_percent < 25: score += 1

        # Determine day color
        if score >= 3: day_color = "green"
        elif score <= -3: day_color = "red"
        else: day_color = "white"

        # Append data to lists
        dates.append(current_date)
        fifty_two_wk_highs.append(day_52wk_high_count)
        fifty_two_wk_lows.append(day_52wk_low_count)
        up_4_5.append(round(up_4_5_percent, 1))
        down_4_5.append(round(down_4_5_percent, 1))
        above_10_ema.append(round(above_10_ema_percent, 1))
        above_20_ema.append(round(above_20_ema_percent, 1))
        above_50_ema.append(round(above_50_ema_percent, 1))
        above_200_ema.append(round(above_200_ema_percent, 1))
        ratio_4_5.append(round(ratio_4_5_value, 1))
        day_colors.append(day_color)

        current_date += timedelta(days=1) # Move to the next day

    logger.info("--- Finished Daily MBI Calculation Loop ---")

    # --- Create DataFrame and Export to Excel ---
    if not dates:
         logger.warning("No data processed for any date in the analysis range. Excel file will not be generated.")
         return

    mbi_df = pd.DataFrame({
        "Date": dates,
        "52Wk H": fifty_two_wk_highs,
        "52Wk L": fifty_two_wk_lows,
        "4.5% +": up_4_5,
        "4.5% -": down_4_5,
        "10+ %": above_10_ema, # Updated header to reflect percentage
        "20+ %": above_20_ema, # Updated header
        "50+ %": above_50_ema, # Updated header
        "200+ %": above_200_ema,# Updated header
        "4.5R": ratio_4_5,
        "Day Color": day_colors
    })
    mbi_df['Date'] = pd.to_datetime(mbi_df['Date']).dt.strftime('%Y-%m-%d') # Format date for Excel

    logger.info(f"Exporting results to {EXCEL_FILE}...")
    try:
        mbi_df.to_excel(EXCEL_FILE, index=False, engine="openpyxl")

        # Apply formatting
        wb = openpyxl.load_workbook(EXCEL_FILE)
        ws = wb.active

        # Apply color formatting - Adjust column letters based on DataFrame headers
        # A=Date, B=52Wk H, C=52Wk L, D=4.5%+, E=4.5%-, F=10+%, G=20+%, H=50+%, I=200+%, J=4.5R, K=Day Color
        for row_idx in range(2, ws.max_row + 1):
            # Color for 52Wk L (Column C) based on 52Wk H (Column B)
            try: # Add try-except for potential None values if data was missing
                val_c = ws[f"C{row_idx}"].value
                val_b = ws[f"B{row_idx}"].value
                if val_c is not None and val_b is not None and val_c > val_b:
                    ws[f"C{row_idx}"].fill = red_fill
                    ws[f"C{row_idx}"].font = white_font # Make text readable on red

                # Color for 4.5R (Column J)
                ratio_value = ws[f"J{row_idx}"].value
                if ratio_value is not None:
                    if ratio_value > 400: ws[f"J{row_idx}"].fill = orange_fill
                    elif 200 <= ratio_value <= 400: ws[f"J{row_idx}"].fill = green_fill
                    elif ratio_value < 50:
                         ws[f"J{row_idx}"].fill = red_fill
                         ws[f"J{row_idx}"].font = white_font # Make text readable on red

                # Color for EMA Percentages (Columns F, G, H, I)
                ema_cols_thresholds = {'F': 15, 'G': 20, 'H': 25, 'I': 25}
                ema_cols_low_bands = {'F': 10, 'G': 15, 'H': 20, 'I': 20} # Lower band for orange trigger
                for col, threshold in ema_cols_thresholds.items():
                     cell = ws[f"{col}{row_idx}"]
                     val = cell.value
                     if val is not None:
                          if val < threshold:
                               # If below threshold, check if it's also below the lower band for orange
                               if val < ema_cols_low_bands[col]:
                                    cell.fill = orange_fill # Very low % = orange
                               else:
                                    cell.fill = green_fill # Low % but not extremely low = green

                # Color for the entire row based on Day Color (Column K)
                day_color_val = ws[f"K{row_idx}"].value
                row_fill = None
                row_font = black_font # Default font
                if day_color_val == "green":
                    row_fill = green_fill
                elif day_color_val == "red":
                    row_fill = red_fill
                    row_font = white_font # Use white font on red background

                if row_fill:
                    for col_letter_idx in range(1, 11): # Columns A to J (index 1 to 10)
                         col_letter = openpyxl.utils.get_column_letter(col_letter_idx)
                         ws[f"{col_letter}{row_idx}"].fill = row_fill
                         ws[f"{col_letter}{row_idx}"].font = row_font

                    # Check for trend change (black text override on colored background)
                    if row_idx > 2:
                         prev_day_color_val = ws[f"K{row_idx-1}"].value
                         if prev_day_color_val != day_color_val and day_color_val != "white": # Only apply if changing to red/green
                              for col_letter_idx in range(1, 11):
                                   col_letter = openpyxl.utils.get_column_letter(col_letter_idx)
                                   # Override font to black to signify change
                                   ws[f"{col_letter}{row_idx}"].font = black_font
            except Exception as format_e:
                 logger.warning(f"Error applying formatting to row {row_idx}: {format_e}")


        wb.save(EXCEL_FILE)
        logger.info(f"Formatted MBI sheet saved as {EXCEL_FILE}")

    except Exception as e:
        logger.error(f"Error during Excel export or formatting: {e}")

    logger.info("MBI Analysis Script Finished")

# ==============================================================================
# Run the Analysis
# ==============================================================================
if __name__ == "__main__":
    run_mbi_analysis()