"""
Enhanced Elliott Wave Scanner (Kite Connect) - Production Version
FIXED: Now properly handles high R:R trades even with broken Fibs
Philosophy: Risk/Reward ratio is primary, Fibonacci levels are secondary guidelines

Critical Improvements:
1. Wave 3 extension validation (must be strongest)
2. Wave 2/4 alternation checks
3. Proper handling of broken Fibs with context (failed vs larger degree wave)
4. Wave-by-wave volume progression analysis
5. Stop loss and invalidation level calculation
6. Risk/reward ratio as PRIMARY filter (>= 2.5:1)
7. Wave degree classification
8. Enhanced corrective pattern types (zigzag, flat, triangle)
9. True multi-timeframe alignment
10. Pragmatic quality thresholds focused on tradeable setups

Author: Enhanced Production Version - Fixed
"""

import os
import json
import math
import time
import pickle
import logging
import sys
from pathlib import Path
from functools import wraps
from datetime import datetime, date, timedelta
from enum import Enum
from typing import Dict, List, Tuple, Optional

import pandas as pd
import numpy as np
from tqdm import tqdm

# 3rd-party libs
from kiteconnect import KiteConnect
import ta
try:
    import talib
    TA_LIB = True
except Exception:
    TA_LIB = False
    print("Warning: TA-Lib not available, using 'ta' library for ATR calculation")

# -----------------------
# LOGGING SETUP - UTF-8 FIX
# -----------------------
# Force UTF-8 encoding for console output on Windows
if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except:
        pass

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('elliott_scanner_enhanced.log', encoding='utf-8'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# -----------------------
# ENUMS FOR WAVE CLASSIFICATION
# -----------------------
class WaveDegree(Enum):
    """Elliott Wave degree classification"""
    SUBMICRO = "Submicro"
    MICRO = "Micro"
    MINUETTE = "Minuette"
    MINUTE = "Minute"
    MINOR = "Minor"
    INTERMEDIATE = "Intermediate"
    PRIMARY = "Primary"

class CorrectiveType(Enum):
    """Types of corrective patterns"""
    ZIGZAG = "Zigzag"
    FLAT = "Flat"
    TRIANGLE = "Triangle"
    COMPLEX = "Complex"
    UNKNOWN = "Unknown"

class PatternValidity(Enum):
    """Pattern quality assessment"""
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"
    INVALID = "Invalid"

# -----------------------
# CONFIG
# -----------------------
API_KEY = os.getenv("KITE_API_KEY", "3bi2yh8g830vq3y6")
ACCESS_TOKEN = os.getenv("KITE_ACCESS_TOKEN", "5r9HfVYn8RyC8fj1L4x1brzLSs7ejYHw")
UNIVERSE_FILE = "data\\MCAP-great2500.csv"
OUTPUT_FILE = f"elliott_enhanced_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
CACHE_FILE = "instruments_cache.pkl"
CACHE_EXPIRY_HOURS = 24

# Analysis params
PIVOT_LEFT = 5
LOOKBACK_DAYS = 377
TIMEFRAME = "day"
MIN_AMP_MULT = 0.25
FIB_LEVELS = [0.382, 0.5, 0.618, 0.764, 0.854]
FIB_EXTENSION_LEVELS = [1.0, 1.272, 1.618, 2.0, 2.618]
MAX_RESULTS = None

# Wave validation thresholds
WAVE3_MIN_EXTENSION = 1.2
WAVE3_IDEAL_EXTENSION = 1.618
WAVE5_MAX_EXTENSION = 1.0
MIN_WAVE_ALTERNATION = 0.3

# Risk management - PRIMARY FILTER
MIN_RISK_REWARD = 2.5  # Minimum R:R ratio
EXCEPTIONAL_RISK_REWARD = 5.0  # Exceptional R:R (overrides Fib concerns)
STOP_LOSS_MULT = 1.5

# Pattern age
MAX_PATTERN_AGE_DAYS = {
    "day": 45,
    "60minute": 10,
    "week": 180
}

# Multi-timeframe
TIMEFRAMES = ["day", "week"]
TIMEFRAME_ALIGNMENT_THRESHOLD = 0.7

# Volume validation
WAVE3_MIN_VOLUME_MULT = 1.3
WAVE5_MAX_VOLUME_MULT = 0.9

# Rate limiting
CALLS_PER_SECOND = 2.5
REQUEST_TIMEOUT = 30
MAX_RETRIES = 3
RETRY_DELAY = 2

# -----------------------
# RATE LIMITER
# -----------------------
class RateLimiter:
    def __init__(self, calls_per_second):
        self.min_interval = 1.0 / calls_per_second
        self.last_called = 0.0
    
    def wait(self):
        elapsed = time.time() - self.last_called
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_called = time.time()

rate_limiter = RateLimiter(CALLS_PER_SECOND)

def rate_limited(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        rate_limiter.wait()
        return func(*args, **kwargs)
    return wrapper

# -----------------------
# KITE INIT & CACHING
# -----------------------
kite = None
INSTRUMENTS_CACHE = {}

def init_kite():
    global kite
    if API_KEY == "your_api_key_here" or ACCESS_TOKEN == "your_access_token_here":
        raise ValueError("Please set KITE_API_KEY and KITE_ACCESS_TOKEN environment variables")
    
    try:
        kite = KiteConnect(api_key=API_KEY)
        kite.set_access_token(ACCESS_TOKEN)
        logger.info("Kite Connect initialized successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to initialize Kite Connect: {e}")
        raise

def load_instruments_cache():
    global INSTRUMENTS_CACHE
    cache_path = Path(CACHE_FILE)
    
    if cache_path.exists():
        cache_age = time.time() - cache_path.stat().st_mtime
        if cache_age < (CACHE_EXPIRY_HOURS * 3600):
            try:
                with open(cache_path, 'rb') as f:
                    INSTRUMENTS_CACHE = pickle.load(f)
                logger.info(f"Loaded {len(INSTRUMENTS_CACHE)} instruments from cache")
                return
            except Exception as e:
                logger.warning(f"Failed to load cache: {e}, fetching fresh data")
    
    fetch_instruments_cache()

@rate_limited
def fetch_instruments_cache():
    global INSTRUMENTS_CACHE
    logger.info("Fetching instruments list from Kite...")
    INSTRUMENTS_CACHE = {}
    
    for exchange in ["NSE", "BSE"]:
        try:
            instruments = kite.instruments(exchange)
            for inst in instruments:
                symbol = inst["tradingsymbol"].upper()
                if symbol not in INSTRUMENTS_CACHE or exchange == "NSE":
                    INSTRUMENTS_CACHE[symbol] = {
                        "token": inst["instrument_token"],
                        "exchange": exchange,
                        "name": inst.get("name", ""),
                        "segment": inst.get("segment", "")
                    }
            logger.info(f"Loaded {len(instruments)} instruments from {exchange}")
        except Exception as e:
            logger.error(f"Failed to fetch instruments from {exchange}: {e}")
    
    try:
        with open(CACHE_FILE, 'wb') as f:
            pickle.dump(INSTRUMENTS_CACHE, f)
        logger.info(f"Cached {len(INSTRUMENTS_CACHE)} instruments to {CACHE_FILE}")
    except Exception as e:
        logger.warning(f"Failed to save cache: {e}")

def get_instrument_token(tradingsymbol):
    info = INSTRUMENTS_CACHE.get(tradingsymbol.upper())
    if info:
        return info["token"], info["exchange"]
    return None, None

# -----------------------
# DATA FETCHING
# -----------------------
@rate_limited
def fetch_history(trading_symbol, interval=TIMEFRAME, days=LOOKBACK_DAYS, retries=MAX_RETRIES):
    token, exchange = get_instrument_token(trading_symbol)
    if token is None:
        raise ValueError(f"Instrument not found: {trading_symbol}")
    
    to_dt = date.today()
    from_dt = to_dt - timedelta(days=int(days * 1.5))
    
    for attempt in range(retries):
        try:
            raw = kite.historical_data(token, from_dt, to_dt, interval, continuous=False)
            if not raw:
                logger.warning(f"No data returned for {trading_symbol}")
                return pd.DataFrame()
            
            df = pd.DataFrame(raw)
            df = df.rename(columns={"date": "datetime"})
            df["datetime"] = pd.to_datetime(df["datetime"])
            df = df.sort_values("datetime").reset_index(drop=True)
            return df[["datetime", "open", "high", "low", "close", "volume"]]
        except Exception as e:
            logger.warning(f"Attempt {attempt + 1}/{retries} failed for {trading_symbol}: {e}")
            if attempt < retries - 1:
                time.sleep(RETRY_DELAY * (attempt + 1))
            else:
                raise
    return pd.DataFrame()

# -----------------------
# TECHNICAL INDICATORS
# -----------------------
def atr_series(df, length):
    if TA_LIB:
        atr = pd.Series(
            talib.ATR(df["high"].values, df["low"].values, df["close"].values, timeperiod=length),
            index=df.index
        )
    else:
        atr = ta.volatility.AverageTrueRange(
            high=df["high"], low=df["low"], close=df["close"], window=length
        ).average_true_range()
    return atr

def zigzag_pivots(df, left=PIVOT_LEFT):
    pivots = []
    n = len(df)
    highs = df["high"].values
    lows = df["low"].values
    
    for i in range(left, n - left):
        window_h = highs[i - left: i + left + 1]
        window_l = lows[i - left: i + left + 1]
        
        is_pivot_high = highs[i] == window_h.max()
        is_pivot_low = lows[i] == window_l.min()
        
        if is_pivot_high and is_pivot_low:
            if not pivots or pivots[-1][2] == "L":
                pivots.append((i, float(highs[i]), "H"))
            else:
                pivots.append((i, float(lows[i]), "L"))
        elif is_pivot_high:
            if not pivots or pivots[-1][2] == "L":
                pivots.append((i, float(highs[i]), "H"))
        elif is_pivot_low:
            if not pivots or pivots[-1][2] == "H":
                pivots.append((i, float(lows[i]), "L"))
    
    return pivots

def last_n_pivots(pivots, n=6):
    return pivots[-n:] if len(pivots) >= n else []

# -----------------------
# WAVE DEGREE CLASSIFICATION
# -----------------------
def classify_wave_degree(df, pivot_indices, timeframe="day"):
    if len(pivot_indices) < 2:
        return WaveDegree.MICRO
    
    durations = []
    for i in range(1, len(pivot_indices)):
        idx1, idx2 = pivot_indices[i-1], pivot_indices[i]
        if idx1 < len(df) and idx2 < len(df):
            date1 = df['datetime'].iloc[idx1]
            date2 = df['datetime'].iloc[idx2]
            duration_days = (date2 - date1).days
            durations.append(duration_days)
    
    if not durations:
        return WaveDegree.MICRO
    
    avg_duration = np.mean(durations)
    
    if timeframe == "day":
        if avg_duration < 5:
            return WaveDegree.SUBMICRO
        elif avg_duration < 15:
            return WaveDegree.MICRO
        elif avg_duration < 30:
            return WaveDegree.MINUETTE
        elif avg_duration < 60:
            return WaveDegree.MINUTE
        elif avg_duration < 120:
            return WaveDegree.MINOR
        else:
            return WaveDegree.INTERMEDIATE
    elif timeframe == "week":
        if avg_duration < 30:
            return WaveDegree.MINUTE
        elif avg_duration < 90:
            return WaveDegree.MINOR
        elif avg_duration < 180:
            return WaveDegree.INTERMEDIATE
        else:
            return WaveDegree.PRIMARY
    else:
        return WaveDegree.MICRO

# -----------------------
# ENHANCED VOLUME ANALYSIS
# -----------------------
def analyze_wave_volumes(df, wave_indices):
    if len(wave_indices) < 6:
        return {
            "wave3_volume_ok": False,
            "wave5_divergence": False,
            "volume_score": 0,
            "details": "Insufficient waves"
        }
    
    try:
        volumes = []
        for i in range(len(wave_indices) - 1):
            start_idx = wave_indices[i]
            end_idx = wave_indices[i + 1]
            if start_idx < len(df) and end_idx < len(df):
                wave_vol = df['volume'].iloc[start_idx:end_idx + 1].mean()
                volumes.append(wave_vol)
        
        if len(volumes) < 5:
            return {
                "wave3_volume_ok": False,
                "wave5_divergence": False,
                "volume_score": 0,
                "details": "Insufficient volume data"
            }
        
        avg_volume = np.mean(volumes)
        wave3_vol = volumes[2]
        wave5_vol = volumes[4]
        
        wave3_ok = wave3_vol >= (avg_volume * WAVE3_MIN_VOLUME_MULT)
        wave5_divergence = wave5_vol < (avg_volume * WAVE5_MAX_VOLUME_MULT)
        
        score = 0
        if wave3_ok:
            score += 15
        if volumes[2] == max(volumes[:3]):
            score += 10
        if wave5_divergence:
            score -= 5
        
        return {
            "wave3_volume_ok": wave3_ok,
            "wave5_divergence": wave5_divergence,
            "volume_score": score,
            "wave3_vs_avg": wave3_vol / avg_volume if avg_volume > 0 else 0,
            "wave5_vs_avg": wave5_vol / avg_volume if avg_volume > 0 else 0,
            "details": f"W3:{wave3_vol/avg_volume:.2f}x W5:{wave5_vol/avg_volume:.2f}x"
        }
    except (IndexError, KeyError, ZeroDivisionError) as e:
        logger.warning(f"Error in volume analysis: {e}")
        return {
            "wave3_volume_ok": False,
            "wave5_divergence": False,
            "volume_score": 0,
            "details": f"Error: {e}"
        }

# -----------------------
# WAVE ALTERNATION CHECK
# -----------------------
def check_wave_alternation(wave2_retracement, wave4_retracement):
    if wave2_retracement == 0 or wave4_retracement == 0:
        return False, 0
    
    diff_ratio = abs(wave2_retracement - wave4_retracement) / max(wave2_retracement, wave4_retracement)
    alternation_ok = diff_ratio >= MIN_WAVE_ALTERNATION
    
    return alternation_ok, diff_ratio

# -----------------------
# ENHANCED IMPULSE DETECTION
# -----------------------
def compute_enhanced_impulse(last6, df, atr_val, min_amp_mult=MIN_AMP_MULT):
    if len(last6) < 6:
        return None
    
    try:
        idx = [p[0] for p in last6]
        price = [p[1] for p in last6]
        
        if len(price) < 6:
            return None
        
        W1 = price[1] - price[0]
        W2 = price[2] - price[1]
        W3 = price[3] - price[2]
        W4 = price[4] - price[3]
        W5 = price[5] - price[4]
        
        min_amp = atr_val * min_amp_mult
        amp_ok = (abs(W1) >= min_amp) and (abs(W3) >= min_amp) and (abs(W5) >= min_amp)
        
        if not amp_ok:
            return None
        
        bullish_geo = (price[5] > price[3] > price[1]) and (price[4] > price[2])
        bearish_geo = (price[5] < price[3] < price[1]) and (price[4] < price[2])
        
        if not (bullish_geo or bearish_geo):
            return None
        
        is_bullish = bullish_geo
        
        # CRITICAL RULES
        if abs(W3) < abs(W1) and abs(W3) < abs(W5):
            return None
        
        if is_bullish and price[2] <= price[0]:
            return None
        if not is_bullish and price[2] >= price[0]:
            return None
        
        if is_bullish and price[4] <= price[1]:
            return None
        if not is_bullish and price[4] >= price[1]:
            return None
        
        wave3_extension = abs(W3) / abs(W1) if abs(W1) > 0 else 0
        wave3_extended = wave3_extension >= WAVE3_MIN_EXTENSION
        
        if not wave3_extended:
            return None
        
        wave5_ratio = abs(W5) / abs(W3) if abs(W3) > 0 else 0
        wave5_reasonable = wave5_ratio <= WAVE5_MAX_EXTENSION
        
        wave2_retracement = abs(W2) / abs(W1) if abs(W1) > 0 else 0
        wave4_retracement = abs(W4) / abs(W3) if abs(W3) > 0 else 0
        
        alternation_ok, alternation_ratio = check_wave_alternation(
            wave2_retracement, wave4_retracement
        )
        
        volume_analysis = analyze_wave_volumes(df, idx)
        
        quality_score = 0
        quality_factors = []
        
        if wave3_extension >= WAVE3_IDEAL_EXTENSION:
            quality_score += 20
            quality_factors.append("Ideal Wave 3 extension")
        elif wave3_extended:
            quality_score += 10
            quality_factors.append("Good Wave 3 extension")
        
        if wave5_reasonable:
            quality_score += 10
            quality_factors.append("Wave 5 proportional")
        
        if alternation_ok:
            quality_score += 15
            quality_factors.append("Good alternation")
        
        if volume_analysis["wave3_volume_ok"]:
            quality_score += 15
            quality_factors.append("Strong Wave 3 volume")
        
        if quality_score >= 40:
            validity = PatternValidity.HIGH
        elif quality_score >= 25:
            validity = PatternValidity.MEDIUM
        else:
            validity = PatternValidity.LOW
        
        return {
            "type": "Impulse",
            "dir": "Bullish" if is_bullish else "Bearish",
            "idx": idx,
            "price": price,
            "W": (W1, W2, W3, W4, W5),
            "wave3_extension": wave3_extension,
            "wave5_ratio": wave5_ratio,
            "wave2_retracement": wave2_retracement,
            "wave4_retracement": wave4_retracement,
            "alternation_ok": alternation_ok,
            "alternation_ratio": alternation_ratio,
            "volume_analysis": volume_analysis,
            "quality_score": quality_score,
            "quality_factors": quality_factors,
            "validity": validity.value,
            "score_base": 60 + quality_score
        }
        
    except (IndexError, KeyError, ZeroDivisionError) as e:
        logger.warning(f"Error in impulse pattern detection: {e}")
        return None

# -----------------------
# CORRECTIVE PATTERN TYPES
# -----------------------
def classify_corrective_type(wave_a, wave_b, wave_c, price_a, price_b, price_c):
    try:
        ab_ratio = abs(wave_b) / abs(wave_a) if abs(wave_a) > 0 else 0
        bc_ratio = abs(wave_c) / abs(wave_a) if abs(wave_a) > 0 else 0
        
        if 0.38 <= ab_ratio <= 0.62 and bc_ratio >= 1.0:
            return CorrectiveType.ZIGZAG
        
        if 0.8 <= ab_ratio <= 1.2 and 0.8 <= bc_ratio <= 1.2:
            return CorrectiveType.FLAT
        
        if ab_ratio > 0.6 and bc_ratio < ab_ratio:
            return CorrectiveType.TRIANGLE
        
        return CorrectiveType.UNKNOWN
        
    except (ZeroDivisionError, TypeError) as e:
        return CorrectiveType.UNKNOWN

def compute_enhanced_corrective(pivots, impulse, df):
    if impulse is None or len(pivots) < 9:
        return None
    
    try:
        last3 = pivots[-3:]
        if len(last3) < 3:
            return None
        
        idx3 = [p[0] for p in last3]
        price3 = [p[1] for p in last3]
        
        if len(price3) < 3:
            return None
        
        wave_a = price3[1] - price3[0]
        wave_b = price3[2] - price3[1]
        wave_c_potential = price3[2]
        
        impulse_start = impulse["price"][0]
        impulse_end = impulse["price"][-1]
        impulse_range = abs(impulse_end - impulse_start)
        
        is_bullish_impulse = impulse["dir"] == "Bullish"
        
        if is_bullish_impulse:
            if price3[0] < impulse_end:
                return None
            
            fib_382 = impulse_end - (impulse_range * 0.382)
            fib_618 = impulse_end - (impulse_range * 0.618)
            
            if price3[2] < fib_618:
                validity = PatternValidity.LOW
            elif price3[2] < fib_382:
                validity = PatternValidity.MEDIUM
            else:
                validity = PatternValidity.HIGH
            
            corrective_dir = "Bearish"
        
        else:
            if price3[0] > impulse_end:
                return None
            
            fib_382 = impulse_end + (impulse_range * 0.382)
            fib_618 = impulse_end + (impulse_range * 0.618)
            
            if price3[2] > fib_618:
                validity = PatternValidity.LOW
            elif price3[2] > fib_382:
                validity = PatternValidity.MEDIUM
            else:
                validity = PatternValidity.HIGH
            
            corrective_dir = "Bullish"
        
        corrective_type = classify_corrective_type(
            wave_a, wave_b, wave_c_potential,
            price3[0], price3[1], price3[2]
        )
        
        quality_score = 0
        if validity == PatternValidity.HIGH:
            quality_score = 30
        elif validity == PatternValidity.MEDIUM:
            quality_score = 20
        else:
            quality_score = 10
        
        if corrective_type != CorrectiveType.UNKNOWN:
            quality_score += 15
        
        return {
            "type": "Corrective",
            "corrective_type": corrective_type.value,
            "dir": corrective_dir,
            "idx": idx3,
            "price": price3,
            "validity": validity.value,
            "quality_score": quality_score,
            "score_base": 50 + quality_score,
            "wave_a": wave_a,
            "wave_b": wave_b
        }
        
    except (IndexError, KeyError, ZeroDivisionError) as e:
        logger.warning(f"Error in corrective pattern detection: {e}")
        return None

# -----------------------
# FIBONACCI ANALYSIS
# -----------------------
def compute_fib_targets(impulse, fib_levels=FIB_LEVELS, fib_extensions=FIB_EXTENSION_LEVELS):
    if impulse is None:
        return {}
    
    last0 = impulse["price"][0]
    last6 = impulse["price"][-1]
    diff = abs(last6 - last0)
    is_bullish = impulse["dir"] == "Bullish"
    
    fibs = {}
    for f in fib_levels:
        price = last6 + ((-1 if is_bullish else 1) * diff * f)
        fibs[f] = price
    
    fib_exts = {}
    for f in fib_extensions:
        price = last6 + ((1 if is_bullish else -1) * diff * (f - 1.0))
        fib_exts[f] = price
    
    return {
        "last0": last0,
        "last6": last6,
        "diff": diff,
        "fibs": fibs,
        "fib_extensions": fib_exts
    }

def analyze_fib_breaks(df, fib_info, last_pivot_idx, is_bullish):
    if not fib_info or last_pivot_idx >= len(df):
        return {
            "retracements_broken": {},
            "extensions_broken": {},
            "all_retracements_broken": False,
            "interpretation": "No Fibonacci data"
        }
    
    retracements_broken = {}
    extensions_broken = {}
    
    for level, price in fib_info.get("fibs", {}).items():
        broken = fib_broken_since(df, price, last_pivot_idx, is_bullish)
        retracements_broken[level] = broken
    
    for level, price in fib_info.get("fib_extensions", {}).items():
        broken = fib_broken_since(df, price, last_pivot_idx, is_bullish)
        extensions_broken[level] = broken
    
    all_retracements_broken = all(retracements_broken.values()) if retracements_broken else False
    
    if all_retracements_broken:
        interpretation = "FIB_BROKEN - May indicate failed pattern OR larger degree wave starting"
    elif any(extensions_broken.values()):
        interpretation = "EXTENSION - Strong momentum continuing"
    else:
        interpretation = "NORMAL - Within expected range"
    
    return {
        "retracements_broken": retracements_broken,
        "extensions_broken": extensions_broken,
        "all_retracements_broken": all_retracements_broken,
        "interpretation": interpretation
    }

def fib_broken_since(df, fib_price, last6_index, is_bullish):
    n = len(df)
    for i in range(last6_index, n):
        if is_bullish and df["high"].iat[i] > fib_price:
            return True
        if not is_bullish and df["low"].iat[i] < fib_price:
            return True
    return False

# -----------------------
# RISK MANAGEMENT - PRIMARY FILTER
# -----------------------
def calculate_stop_loss_and_targets(impulse, df, atr_val, current_price):
    if not impulse or not impulse.get("price") or not impulse.get("idx"):
        return None
    
    try:
        is_bullish = impulse["dir"] == "Bullish"
        prices = impulse["price"]
        
        if is_bullish:
            stop_loss = prices[4] - (atr_val * STOP_LOSS_MULT)
            invalidation = prices[1]
            
            wave_range = abs(prices[5] - prices[0])
            target_1 = prices[5] + (wave_range * 0.618)
            target_2 = prices[5] + (wave_range * 1.0)
            target_3 = prices[5] + (wave_range * 1.618)
            
        else:
            stop_loss = prices[4] + (atr_val * STOP_LOSS_MULT)
            invalidation = prices[1]
            
            wave_range = abs(prices[5] - prices[0])
            target_1 = prices[5] - (wave_range * 0.618)
            target_2 = prices[5] - (wave_range * 1.0)
            target_3 = prices[5] - (wave_range * 1.618)
        
        risk = abs(current_price - stop_loss)
        if risk <= 0:
            return None
        
        reward_1 = abs(target_1 - current_price)
        reward_2 = abs(target_2 - current_price)
        reward_3 = abs(target_3 - current_price)
        
        rr_1 = reward_1 / risk
        rr_2 = reward_2 / risk
        rr_3 = reward_3 / risk
        
        # PRIMARY FILTER: R:R ratio determines validity
        setup_valid = rr_1 >= MIN_RISK_REWARD
        
        return {
            "stop_loss": stop_loss,
            "invalidation": invalidation,
            "target_1": target_1,
            "target_2": target_2,
            "target_3": target_3,
            "risk": risk,
            "reward_1": reward_1,
            "reward_2": reward_2,
            "reward_3": reward_3,
            "rr_1": rr_1,
            "rr_2": rr_2,
            "rr_3": rr_3,
            "setup_valid": setup_valid,
            "risk_pct": (risk / current_price) * 100 if current_price > 0 else 0
        }
        
    except (IndexError, KeyError, ZeroDivisionError) as e:
        logger.warning(f"Error calculating risk management: {e}")
        return None

# -----------------------
# MULTI-TIMEFRAME ALIGNMENT
# -----------------------
def check_mtf_alignment(mtf_results):
    if len(mtf_results) < 2:
        return {
            "aligned": False,
            "alignment_score": 0,
            "details": "Insufficient timeframes"
        }
    
    directions = []
    pattern_types = []
    
    for tf, data in mtf_results.items():
        if data.get("impulse"):
            directions.append(data["impulse"]["dir"])
            pattern_types.append("Impulse")
        elif data.get("corrective"):
            directions.append(data["corrective"]["dir"])
            pattern_types.append("Corrective")
    
    if not directions:
        return {
            "aligned": False,
            "alignment_score": 0,
            "details": "No patterns found"
        }
    
    direction_agreement = directions.count(directions[0]) / len(directions)
    pattern_agreement = pattern_types.count(pattern_types[0]) / len(pattern_types)
    
    alignment_score = (direction_agreement * 0.7 + pattern_agreement * 0.3) * 100
    aligned = alignment_score >= (TIMEFRAME_ALIGNMENT_THRESHOLD * 100)
    
    return {
        "aligned": aligned,
        "alignment_score": alignment_score,
        "direction_agreement": direction_agreement,
        "pattern_agreement": pattern_agreement,
        "details": f"{len(mtf_results)} timeframes, {direction_agreement*100:.0f}% directional agreement"
    }

def multi_timeframe_analysis(symbol, timeframes=TIMEFRAMES):
    results = {}
    
    for tf in timeframes:
        try:
            df = fetch_history(symbol, interval=tf, days=LOOKBACK_DAYS)
            if df is None or df.empty:
                continue
            
            df = df.reset_index(drop=True)
            atr = atr_series(df, PIVOT_LEFT)
            atr_val = float(atr.iloc[-1]) if not atr.isnull().all() else 0.0
            
            piv = zigzag_pivots(df, left=PIVOT_LEFT)
            if len(piv) >= 6:
                last6 = last_n_pivots(piv, 6)
                impulse = compute_enhanced_impulse(last6, df, atr_val, min_amp_mult=MIN_AMP_MULT)
                
                corrective = None
                if impulse:
                    corrective = compute_enhanced_corrective(piv, impulse, df)
                
                results[tf] = {
                    "impulse": impulse,
                    "corrective": corrective,
                    "atr": atr_val
                }
        except Exception as e:
            logger.warning(f"MTF analysis failed for {symbol} on {tf}: {e}")
            continue
    
    return results

# -----------------------
# PATTERN AGE VALIDATION
# -----------------------
def is_pattern_too_old(df, impulse, timeframe=TIMEFRAME):
    if impulse is None or not impulse.get("idx"):
        return True
    
    try:
        max_age = MAX_PATTERN_AGE_DAYS.get(timeframe, 45)
        last_pivot_idx = impulse["idx"][-1]
        last_pivot_date = df['datetime'].iloc[last_pivot_idx].date()
        days_since_pivot = (date.today() - last_pivot_date).days
        
        return days_since_pivot > max_age
    except (IndexError, KeyError, AttributeError) as e:
        logger.warning(f"Error calculating pattern age: {e}")
        return True

# -----------------------
# TRADE RECOMMENDATION ENGINE
# -----------------------
def generate_trade_recommendation(impulse, fib_analysis, risk_mgmt, mtf_alignment, current_price):
    """Generate actionable trade recommendation - R:R is PRIMARY filter"""
    
    # FIRST: Check R:R ratio (primary filter)
    if not risk_mgmt or not risk_mgmt.get("setup_valid"):
        return "NO TRADE - Risk/reward ratio insufficient (< 2.5:1)"
    
    rr1 = risk_mgmt.get("rr_1", 0)
    
    # SECOND: Check Fibonacci interpretation
    if fib_analysis.get("all_retracements_broken"):
        # Exceptional R:R overrides Fib concerns
        if rr1 >= EXCEPTIONAL_RISK_REWARD:
            return (f"ADVANCED TRADE - Fibs broken but exceptional R:R {rr1:.1f}:1 | "
                   f"May be larger degree wave | Use 50% position size")
        else:
            return f"CAUTION - Fibs broken, R:R {rr1:.1f}:1 | Pattern may have failed | Risk-tolerant only"
    
    # THIRD: Check MTF alignment
    direction = impulse.get("dir")
    stop = risk_mgmt.get("stop_loss")
    target1 = risk_mgmt.get("target_1")
    
    if direction == "Bullish":
        entry_rec = f"BUY near {current_price:.2f}"
    else:
        entry_rec = f"SELL near {current_price:.2f}"
    
    rec = f"{entry_rec} | Stop: {stop:.2f} | Target: {target1:.2f} | R:R {rr1:.1f}:1"
    
    if mtf_alignment.get("aligned"):
        rec += " | HIGH CONVICTION - MTF Aligned"
    else:
        rec += " | CAUTION - Single timeframe only"
    
    return rec

def generate_analysis_notes(impulse, fib_analysis, risk_mgmt):
    """Generate detailed analysis notes"""
    notes = []
    
    if impulse.get("wave3_extension", 0) >= WAVE3_IDEAL_EXTENSION:
        notes.append("Strong Wave 3 extension (ideal)")
    
    if impulse.get("alternation_ok"):
        notes.append("Good Wave 2/4 alternation")
    
    if impulse.get("volume_analysis", {}).get("wave3_volume_ok"):
        notes.append("Wave 3 volume confirms strength")
    
    if impulse.get("volume_analysis", {}).get("wave5_divergence"):
        notes.append("WARNING: Wave 5 volume divergence (potential weakness)")
    
    if fib_analysis.get("interpretation"):
        notes.append(f"Fib: {fib_analysis['interpretation']}")
    
    if risk_mgmt:
        rr = risk_mgmt.get("rr_1", 0)
        if rr >= EXCEPTIONAL_RISK_REWARD:
            notes.append(f"Exceptional R:R {rr:.1f}:1")
        elif rr >= MIN_RISK_REWARD:
            notes.append(f"Good R:R {rr:.1f}:1")
    
    return " | ".join(notes) if notes else "Standard Elliott Wave pattern"

# -----------------------
# MAIN ANALYSIS FUNCTION - FIXED
# -----------------------
def analyze_symbol(symbol):
    """Comprehensive symbol analysis - R:R is PRIMARY filter, Fibs are SECONDARY"""
    try:
        df = fetch_history(symbol, interval=TIMEFRAME, days=LOOKBACK_DAYS)
    except Exception as e:
        logger.error(f"{symbol}: Fetch error - {e}")
        return {"Symbol": symbol, "Error": f"FetchError: {e}"}
    
    if df is None or df.empty:
        return {"Symbol": symbol, "Error": "NoData"}
    
    df = df.reset_index(drop=True)
    current_price = df["close"].iloc[-1]
    
    atr = atr_series(df, PIVOT_LEFT)
    atr_val = float(atr.iloc[-1]) if not atr.isnull().all() else 0.0
    
    piv = zigzag_pivots(df, left=PIVOT_LEFT)
    
    if len(piv) < 6:
        return {
            "Symbol": symbol,
            "Signal": "None",
            "Direction": "NA",
            "Confidence": 0,
            "Current_Price": current_price,
            "Pattern_Validity": "Insufficient_Data",
            "Wave_Degree": "Unknown",
            "Setup_Valid": False,
            "Notes": f"Only {len(piv)} pivots found, need at least 6"
        }
    
    last6 = last_n_pivots(piv, 6)
    impulse = compute_enhanced_impulse(last6, df, atr_val, min_amp_mult=MIN_AMP_MULT)
    
    pattern_too_old = is_pattern_too_old(df, impulse, TIMEFRAME)
    wave_degree = classify_wave_degree(df, [p[0] for p in last6], TIMEFRAME)
    
    mtf_results = multi_timeframe_analysis(symbol, TIMEFRAMES)
    mtf_alignment = check_mtf_alignment(mtf_results)
    
    fib_info = compute_fib_targets(impulse, FIB_LEVELS, FIB_EXTENSION_LEVELS) if impulse else {}
    fib_analysis = {}
    if fib_info and impulse:
        try:
            last_pivot_idx = last6[-1][0]
            is_bullish = impulse["dir"] == "Bullish"
            fib_analysis = analyze_fib_breaks(df, fib_info, last_pivot_idx, is_bullish)
        except Exception as e:
            logger.warning(f"Fib analysis error for {symbol}: {e}")
    
    # CRITICAL: Calculate R:R FIRST, before any filtering
    risk_mgmt = calculate_stop_loss_and_targets(impulse, df, atr_val, current_price) if impulse else None
    
    corrective = compute_enhanced_corrective(piv, impulse, df) if impulse else None
    
    # ---- IMPULSE DETECTED ----
    if impulse and not pattern_too_old:
        score = impulse.get("score_base", 60)
        
        # MTF alignment bonus
        if mtf_alignment["aligned"]:
            score += 20
        
        # R:R bonus/penalty - PRIMARY CONSIDERATION
        if risk_mgmt and risk_mgmt["setup_valid"]:
            rr = risk_mgmt.get("rr_1", 0)
            if rr >= EXCEPTIONAL_RISK_REWARD:
                score += 20  # Exceptional R:R
            else:
                score += 10  # Good R:R
        else:
            score -= 20  # Poor R:R is serious
        
        # Fib penalty - SECONDARY consideration
        if fib_analysis.get("all_retracements_broken"):
            if risk_mgmt and risk_mgmt.get("rr_1", 0) >= EXCEPTIONAL_RISK_REWARD:
                score -= 5  # Minor penalty if R:R is exceptional
            else:
                score -= 15  # Moderate penalty otherwise
        
        score = max(0, min(100, score))
        
        # ALLOW pattern if R:R is valid, even with low score
        # This is the KEY FIX
        result = {
            "Symbol": symbol,
            "Signal": "Impulse",
            "Direction": impulse["dir"],
            "Confidence": score,
            "Pattern_Validity": impulse.get("validity", "Unknown"),
            "Wave_Degree": wave_degree.value,
            "Current_Price": current_price,
            
            "Wave3_Extension": f"{impulse.get('wave3_extension', 0):.2f}x",
            "Wave5_Ratio": f"{impulse.get('wave5_ratio', 0):.2f}x",
            "Alternation_OK": impulse.get("alternation_ok", False),
            "Alternation_Ratio": f"{impulse.get('alternation_ratio', 0):.2f}",
            
            "Wave3_Volume_OK": impulse.get("volume_analysis", {}).get("wave3_volume_ok", False),
            "Wave5_Divergence": impulse.get("volume_analysis", {}).get("wave5_divergence", False),
            "Volume_Details": impulse.get("volume_analysis", {}).get("details", ""),
            
            "Quality_Factors": ", ".join(impulse.get("quality_factors", [])),
            
            "MTF_Aligned": mtf_alignment["aligned"],
            "MTF_Score": f"{mtf_alignment['alignment_score']:.0f}%",
            "MTF_Details": mtf_alignment["details"],
            
            "Fib_Interpretation": fib_analysis.get("interpretation", "Unknown"),
            "All_Fibs_Broken": fib_analysis.get("all_retracements_broken", False),
            "Fib_0.382": fib_info.get("fibs", {}).get(0.382),
            "Fib_0.5": fib_info.get("fibs", {}).get(0.5),
            "Fib_0.618": fib_info.get("fibs", {}).get(0.618),
            "Fib_Ext_1.618": fib_info.get("fib_extensions", {}).get(1.618),
            "Fib_Ext_2.618": fib_info.get("fib_extensions", {}).get(2.618),
            
            "Stop_Loss": risk_mgmt["stop_loss"] if risk_mgmt else None,
            "Invalidation_Level": risk_mgmt["invalidation"] if risk_mgmt else None,
            "Target_1": risk_mgmt["target_1"] if risk_mgmt else None,
            "Target_2": risk_mgmt["target_2"] if risk_mgmt else None,
            "Target_3": risk_mgmt["target_3"] if risk_mgmt else None,
            "Risk_Reward_T1": f"{risk_mgmt['rr_1']:.2f}:1" if risk_mgmt else "N/A",
            "Risk_Reward_T2": f"{risk_mgmt['rr_2']:.2f}:1" if risk_mgmt else "N/A",
            "Risk_Reward_T3": f"{risk_mgmt['rr_3']:.2f}:1" if risk_mgmt else "N/A",
            "Risk_Percent": f"{risk_mgmt['risk_pct']:.2f}%" if risk_mgmt else "N/A",
            "Setup_Valid": risk_mgmt["setup_valid"] if risk_mgmt else False,
            
            "Trade_Recommendation": generate_trade_recommendation(
                impulse, fib_analysis, risk_mgmt, mtf_alignment, current_price
            ),
            
            "Notes": generate_analysis_notes(impulse, fib_analysis, risk_mgmt)
        }
        
        return result
    
    # ---- CORRECTIVE DETECTED ----
    if corrective and not pattern_too_old:
        score = corrective.get("score_base", 50)
        
        if mtf_alignment["aligned"]:
            score += 15
        
        score = max(0, min(100, score))
        
        return {
            "Symbol": symbol,
            "Signal": "Corrective",
            "Direction": corrective["dir"],
            "Confidence": score,
            "Pattern_Validity": corrective.get("validity", "Unknown"),
            "Corrective_Type": corrective.get("corrective_type", "Unknown"),
            "Wave_Degree": wave_degree.value,
            "Current_Price": current_price,
            "Setup_Valid": False,
            
            "MTF_Aligned": mtf_alignment["aligned"],
            "MTF_Score": f"{mtf_alignment['alignment_score']:.0f}%",
            
            "Trade_Recommendation": "WAIT - Monitor for completion of correction, then watch for impulse reversal",
            
            "Notes": f"Corrective {corrective.get('corrective_type')} pattern - Wait for completion before entry"
        }
    
    # ---- NO VALID PATTERN ----
    return {
        "Symbol": symbol,
        "Signal": "None",
        "Direction": "NA",
        "Confidence": 0,
        "Current_Price": current_price,
        "Pattern_Validity": "Old_Pattern" if pattern_too_old else "No_Pattern",
        "Wave_Degree": wave_degree.value,
        "Setup_Valid": False,
        "Notes": "Pattern too old or no valid Elliott Wave structure detected"
    }

# -----------------------
# SCANNER - FIXED OUTPUT LOGIC
# -----------------------
def run_scanner():
    """Main scanner with corrected filtering logic"""
    logger.info("=" * 60)
    logger.info("ENHANCED ELLIOTT WAVE SCANNER - PRODUCTION VERSION")
    logger.info("=" * 60)
    
    init_kite()
    load_instruments_cache()
    
    if not Path(UNIVERSE_FILE).exists():
        logger.error(f"Universe file not found: {UNIVERSE_FILE}")
        return
    
    uni = pd.read_csv(UNIVERSE_FILE)
    if "Symbol" not in uni.columns:
        logger.error("Universe file must contain 'Symbol' column")
        return
    
    symbols = list(uni["Symbol"].astype(str).str.strip().unique())
    
    if MAX_RESULTS:
        symbols = symbols[:MAX_RESULTS]
        logger.info(f"Limited to first {MAX_RESULTS} symbols for testing")
    
    logger.info(f"Scanning {len(symbols)} symbols...")
    logger.info(f"Timeframes: {TIMEFRAMES}")
    logger.info(f"Min R:R Ratio: {MIN_RISK_REWARD}:1 (PRIMARY FILTER)")
    logger.info(f"Exceptional R:R: {EXCEPTIONAL_RISK_REWARD}:1 (overrides Fib concerns)")
    
    rows = []
    for symbol in tqdm(symbols, desc="Scanning"):
        try:
            result = analyze_symbol(symbol)
            rows.append(result)
        except Exception as e:
            logger.error(f"{symbol}: Error - {e}")
            rows.append({"Symbol": symbol, "Error": str(e)})
    
    df_out = pd.DataFrame(rows)
    df_out.to_csv(OUTPUT_FILE, index=False, encoding='utf-8')
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # CONSERVATIVE TRADES: Good R:R + No broken Fibs
    conservative = df_out[
        (df_out['Signal'] == 'Impulse') &
        (df_out['Setup_Valid'] == True) &
        (df_out['All_Fibs_Broken'] == False) &
        (df_out['Pattern_Validity'].isin(['High', 'Medium']))
    ].copy()
    
    # AGGRESSIVE TRADES: Good R:R + Broken Fibs (may be larger degree wave)
    aggressive = df_out[
        (df_out['Signal'] == 'Impulse') &
        (df_out['Setup_Valid'] == True) &
        (df_out['All_Fibs_Broken'] == True) &
        (df_out['Pattern_Validity'].isin(['High', 'Medium']))
    ].copy()
    
    # MTF Confirmed
    mtf_confirmed = df_out[
        (df_out['MTF_Aligned'] == True) &
        (df_out['Setup_Valid'] == True)
    ].copy()
    
    # Save files
    if not conservative.empty:
        cons_file = f"elliott_CONSERVATIVE_{timestamp}.csv"
        conservative = conservative.sort_values('Confidence', ascending=False)
        conservative.to_csv(cons_file, index=False, encoding='utf-8')
        logger.info(f"[CONSERVATIVE] {len(conservative)} safe setups -> {cons_file}")
    
    if not aggressive.empty:
        agg_file = f"elliott_AGGRESSIVE_{timestamp}.csv"
        aggressive = aggressive.sort_values('Confidence', ascending=False)
        aggressive.to_csv(agg_file, index=False, encoding='utf-8')
        logger.info(f"[AGGRESSIVE] {len(aggressive)} high R:R broken Fib -> {agg_file}")
    
    if not mtf_confirmed.empty:
        mtf_file = f"elliott_MTF_CONFIRMED_{timestamp}.csv"
        mtf_confirmed = mtf_confirmed.sort_values('Confidence', ascending=False)
        mtf_confirmed.to_csv(mtf_file, index=False, encoding='utf-8')
        logger.info(f"[MTF] {len(mtf_confirmed)} multi-timeframe aligned -> {mtf_file}")
    
    # Summary
    logger.info("=" * 60)
    logger.info("SCAN COMPLETE - SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Total scanned: {len(symbols)}")
    logger.info(f"[CONSERVATIVE] Safe trades (no Fib break): {len(conservative)}")
    logger.info(f"[AGGRESSIVE] High R:R (Fib broken): {len(aggressive)}")
    logger.info(f"[MTF] Multi-timeframe confirmed: {len(mtf_confirmed)}")
    logger.info(f"[ALL IMPULSES] Total: {len(df_out[df_out['Signal'] == 'Impulse'])}")
    logger.info(f"[CORRECTIVE] Patterns: {len(df_out[df_out['Signal'] == 'Corrective'])}")
    logger.info(f"[NONE] No pattern: {len(df_out[df_out['Signal'] == 'None'])}")
    logger.info(f"\n[OUTPUT] Main file: {OUTPUT_FILE}")
    logger.info("=" * 60)
    
    # Print recommendations
    if not conservative.empty:
        logger.info("\n[TOP 5] CONSERVATIVE TRADES:")
        logger.info("=" * 60)
        for idx, row in conservative.head(5).iterrows():
            logger.info(f"\n{row['Symbol']}: {row['Direction']} Impulse")
            logger.info(f"  Confidence: {row['Confidence']}")
            logger.info(f"  {row['Trade_Recommendation']}")
            logger.info(f"  {row['Notes']}")
    
    if not aggressive.empty:
        logger.info("\n[TOP 5] AGGRESSIVE TRADES (Broken Fibs):")
        logger.info("=" * 60)
        logger.info("WARNING: These have broken Fibonacci levels")
        logger.info("May indicate failed pattern OR larger degree wave starting")
        logger.info("Use reduced position size (50%) and tight stops\n")
        for idx, row in aggressive.head(5).iterrows():
            logger.info(f"{row['Symbol']}: {row['Direction']} | {row['Trade_Recommendation']}")
    
    logger.info("=" * 60)

if __name__ == "__main__":
    run_scanner()