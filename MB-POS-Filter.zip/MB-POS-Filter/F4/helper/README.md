# Helper Utilities

## Overview
This directory contains utility scripts for data enrichment and web scraping.

---

## 📊 sector-marketcap-scraper.py

**Unified Best-in-Class Scraper for Screener.in**

### Purpose
Extracts sector hierarchy and market capitalization data from screener.in for a list of stock symbols.

### Features
✅ **Sector Hierarchy** - Extracts 4-level breadcrumb trail (e.g., Financials → Banks → Private Banks → Large Banks)  
✅ **Market Capitalization** - Extracts current market cap in Crores  
✅ **Rate Limited** - Random delay (1.5-2.5s) to prevent IP blocking  
✅ **Robust Error Handling** - Continues on failures, logs all errors  
✅ **Progress Tracking** - Real-time progress updates  
✅ **Timestamped Outputs** - Each run creates a new timestamped CSV  
✅ **Smart Symbol Detection** - Case-insensitive, handles duplicates  
✅ **Detailed Logging** - Console + file logging for troubleshooting  

---

### Configuration

Edit these variables in the script:

```python
# Input/Output
INPUT_CSV = "../../../data/Nifty50stocks.csv"  # Your stock list
OUTPUT_DIR = "./output"                         # Output directory

# Scraping Settings
DELAY_RANGE = (1.5, 2.5)  # Random delay between requests (seconds)
TIMEOUT = 15               # Request timeout (seconds)
```

---

### Input Format

**Required CSV structure:**
```csv
Symbol
RELIANCE
TCS
INFY
HDFCBANK
```

**Note**: Symbol column name is case-insensitive.

---

### Output Format

**Generated CSV structure:**
```csv
Symbol,Market_Cap_Crores,Sector_Level_1,Sector_Level_2,Sector_Level_3,Sector_Level_4,Status,Scraped_At
RELIANCE,1532000.45,Materials,Oil & Gas,Refineries,Petroleum Products,Success,2025-10-22 14:30:15
TCS,1287000.00,Information Technology,Software,IT Services,Software Products,Success,2025-10-22 14:30:18
HDFCBANK,985000.23,Financials,Banks,Private Banks,Large Private Banks,Success,2025-10-22 14:30:21
```

**Output Columns:**
- `Symbol` - Stock symbol
- `Market_Cap_Crores` - Market capitalization in Crores
- `Sector_Level_1` - Broadest sector category
- `Sector_Level_2` - Industry group
- `Sector_Level_3` - Sub-industry
- `Sector_Level_4` - Specific category (if available)
- `Status` - "Success" or error message
- `Scraped_At` - Timestamp of scraping

---

### Usage

#### Basic Usage
```bash
cd C:\nihil\finance_ai_ws\MB-POS-Filter\F4\helper
python sector-marketcap-scraper.py
```

#### What Happens
1. Reads symbols from `INPUT_CSV`
2. Scrapes each symbol from screener.in
3. Extracts sector hierarchy + market cap
4. Saves to `output/sector_marketcap_YYYYMMDD_HHMMSS.csv`
5. Displays summary statistics

---

### Example Output

```
============================================================
🚀 UNIFIED SECTOR & MARKET CAP SCRAPER
============================================================

📥 Loaded input file: ../../../data/Nifty50stocks.csv
📋 Preview symbols: ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK', ...]
📊 Total unique symbols: 50

============================================================
Progress: [1/50] - 2.0%
============================================================
🔍 Fetching RELIANCE from https://www.screener.in/company/RELIANCE/
  ✓ Found 4 sector levels for RELIANCE
  ✓ Market Cap for RELIANCE: ₹1,532,000.45 Cr
✅ Successfully scraped RELIANCE

============================================================
Progress: [2/50] - 4.0%
============================================================
🔍 Fetching TCS from https://www.screener.in/company/TCS/
  ✓ Found 4 sector levels for TCS
  ✓ Market Cap for TCS: ₹1,287,000.00 Cr
✅ Successfully scraped TCS

...

============================================================
📈 SCRAPING SUMMARY
============================================================
Total symbols: 50
Successful: 48 (96.0%)
Failed: 2

============================================================
✅ SCRAPING COMPLETED
============================================================
📁 Output file: output/sector_marketcap_20251022_143015.csv
📊 Total records: 50

📋 First 5 results:
Symbol    Market_Cap_Crores  Sector_Level_1           Sector_Level_2  ...
RELIANCE      1532000.45     Materials                Oil & Gas       ...
TCS           1287000.00     Information Technology   Software        ...
INFY           765000.23     Information Technology   Software        ...
HDFCBANK       985000.45     Financials               Banks           ...
ICICIBANK      845000.12     Financials               Banks           ...

📊 Top Sector Distribution:
Financials                45
Information Technology    25
Materials                 15
Energy                    10
Consumer Discretionary     5

💰 Market Cap Statistics:
  Average: ₹456,789.23 Cr
  Median:  ₹234,567.89 Cr
  Max:     ₹1,532,000.45 Cr
  Min:     ₹12,345.67 Cr

✨ Done!
```

---

### Logging

**Log File**: `sector_marketcap_scraper.log`

All scraping activity is logged to both console and file, including:
- Progress updates
- Successful scrapes
- Failed requests
- Error messages
- Summary statistics

---

### Error Handling

The scraper handles common errors gracefully:

1. **Network Errors** - Logs error, continues with next symbol
2. **Timeout Errors** - Logs timeout, continues with next symbol
3. **Missing Data** - Sets appropriate default values (0.0 for market cap, None for missing sectors)
4. **Invalid Symbols** - Logs warning, marks as failed

**Failed symbols** are marked in the `Status` column with the error message.

---

### Tips

1. **First Run**: Test with a small sample (5-10 stocks) to verify everything works
2. **Large Lists**: For 500+ stocks, expect ~20-30 minutes runtime (due to rate limiting)
3. **Rate Limits**: Don't reduce delay below 1.5s to avoid IP blocking
4. **Network Issues**: If many failures, check internet connection and try again later
5. **Resuming**: No resume feature - re-run will scrape all symbols again

---

### Use Cases

✅ **Enriching Stock Lists**
   - Add sector and market cap data to your Nifty 50 list
   - Use with `sector-copy.py` to merge with existing data

✅ **Sector Analysis**
   - Identify sector distribution in your universe
   - Filter stocks by sector for sector rotation strategies

✅ **Market Cap Filtering**
   - Create large-cap, mid-cap, small-cap lists
   - Filter by market cap thresholds

✅ **Data Validation**
   - Verify sector classifications
   - Check if market caps are current

---

## 📝 sector-copy.py

**Data Merger Utility**

### Purpose
Merges scraped sector/fundamental data with your existing stock lists.

### Usage
```python
# Edit these paths in the script:
file1 = "data/Stage2Shortlist.csv"           # Your stock list (has 'Symbol')
file2 = "data/Sector-MCAP-output.csv"        # Scraped data (has 'symbol', Sector, etc.)

# Run:
python sector-copy.py
```

### Output
Creates `symbols_enriched.csv` with merged data.

---

## 🔗 Workflow

**Complete enrichment workflow:**

```bash
# Step 1: Scrape sector + market cap data
cd C:\nihil\finance_ai_ws\MB-POS-Filter\F4\helper
python sector-marketcap-scraper.py

# Step 2: Merge with your stock list
python sector-copy.py

# Result: symbols_enriched.csv with all data combined
```

---

## 📚 Related Files

| Script | Location | Purpose |
|--------|----------|---------|
| **sector-marketcap-scraper.py** | `F4/helper/` | Main scraper (sector + market cap) |
| **sector-copy.py** | `helper/` | Data merger utility |
| **advanced_screener_scraper.py** | `F4/fun/screener-scrapper/` | Full fundamentals scraper |

---

## 🛠 Troubleshooting

### Issue: "Input file not found"
**Solution**: Update `INPUT_CSV` path in the script

### Issue: "Symbol column not found"
**Solution**: Ensure your CSV has a 'Symbol' column (case-insensitive)

### Issue: Many failed scrapes
**Solution**: 
- Check internet connection
- Verify symbols are valid NSE symbols
- Try again later (screener.in might be down)

### Issue: Script is slow
**Solution**: This is normal! Rate limiting prevents IP blocking. For 50 stocks, expect ~2-3 minutes.

---

## 📖 Version History

**v1.0.0** (2025-10-22)
- Initial unified version
- Combined sector hierarchy + market cap extraction
- Robust error handling and logging
- Progress tracking and statistics

---

**Best Practices:**
1. Always test with small sample first
2. Run during off-peak hours for large lists
3. Keep scraped data timestamped for tracking
4. Review log file if errors occur
5. Don't modify rate limiting settings

