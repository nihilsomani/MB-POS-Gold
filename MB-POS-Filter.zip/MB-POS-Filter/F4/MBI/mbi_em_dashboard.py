"""
MBI EM Dashboard
================
Main orchestrator for Market Breadth Intelligence with Pocket Pivot EM analysis.

Coordinates:
- Historical data fetching
- Pocket Pivot detection  
- Follow-through tracking
- EM calculation
- Breadth metrics
- Regime classification
- Excel output with formatting
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import logging
import os
import pickle
import time
from pathlib import Path

# Import our custom modules
from pocket_pivot_detector import PocketPivotDetector, PocketPivotSignal
from followthrough_tracker import FollowThroughTracker
from em_calculator import EMCalculator
from breadth_metrics import BreadthMetricsCalculator
from regime_classifier_v3 import TrendBasedRegimeClassifierV3

# Import index fetcher with error handling
try:
    from index_data_fetcher import IndexDataFetcher
    INDEX_FETCHER_AVAILABLE = True
    print("DEBUG: IndexDataFetcher imported at top level successfully")
except Exception as e:
    INDEX_FETCHER_AVAILABLE = False
    IndexDataFetcher = None
    print(f"ERROR: Failed to import IndexDataFetcher at top level: {e}")
    import traceback
    traceback.print_exc()

logger = logging.getLogger(__name__)


class MBIEMDashboard:
    """
    Main dashboard for MBI EM analysis.
    
    Configuration:
    - api_key: KiteConnect API key
    - access_token: KiteConnect access token
    - universe_csv: Path to CSV with stock symbols
    - analysis_days: Days to analyze (default: 30)
    - lookback_days: Historical data needed (default: 370)
    - cache_dir: Directory for caching data
    - api_delay: Delay between API calls (default: 0.3)
    """
    
    def __init__(
        self,
        api_key: str,
        access_token: str,
        universe_csv: str = "data/MCAP7000.csv",
        analysis_days: int = 30,
        lookback_days: int = 370,
        cache_dir: str = "MBI_EM_Cache",
        api_delay: float = 0.3
    ):
        self.api_key = api_key
        self.access_token = access_token
        self.universe_csv = universe_csv
        self.analysis_days = analysis_days
        self.lookback_days = lookback_days
        self.cache_dir = cache_dir
        self.api_delay = api_delay
        
        # Create cache directories
        self.instruments_cache = os.path.join(cache_dir, "nse_instruments.pkl")
        self.historical_cache_dir = os.path.join(cache_dir, "historical")
        os.makedirs(self.historical_cache_dir, exist_ok=True)
        os.makedirs(cache_dir, exist_ok=True)
        
        # Initialize Kite Connect
        self.kite = None
        self._initialize_kite()
        
        # Initialize analysis modules
        self.ppd_detector = PocketPivotDetector()
        self.ft_tracker = FollowThroughTracker()
        self.em_calculator = EMCalculator()
        self.breadth_calculator = BreadthMetricsCalculator()
        
        # Note: index_fetcher already initialized in _initialize_kite() above
        # Don't reset it here!
        
        # Initialize V3 regime classifier (index-aware, reads from config.py)
        self.regime_classifier = TrendBasedRegimeClassifierV3()
        
        logger.info("MBI EM Dashboard initialized (V3 - Index-Aware)")
    
    def _initialize_kite(self):
        """Initialize KiteConnect instance"""
        try:
            self.kite = KiteConnect(api_key=self.api_key)
            self.kite.set_access_token(self.access_token)
            logger.info("KiteConnect initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize KiteConnect: {e}")
            raise
        
        # Initialize index fetcher separately with error handling
        logger.info(f"DEBUG: INDEX_FETCHER_AVAILABLE = {INDEX_FETCHER_AVAILABLE}")
        logger.info(f"DEBUG: Attempting to initialize IndexDataFetcher with cache_dir={self.cache_dir}")
        
        if not INDEX_FETCHER_AVAILABLE:
            logger.error("IndexDataFetcher import failed at top level - V3 disabled")
            self.index_fetcher = None
            # Don't return - continue with other initializations
        else:
            try:
                self.index_fetcher = IndexDataFetcher(
                    kite=self.kite,
                    cache_dir=self.cache_dir
                )
                logger.info("SUCCESS: Index data fetcher initialized with caching")
                logger.info(f"DEBUG: index_fetcher type = {type(self.index_fetcher)}")
            except Exception as e:
                logger.error(f"FAILED to initialize index fetcher: {e}")
                logger.exception("Full traceback:")
                self.index_fetcher = None  # Explicitly set to None
    
    def load_instruments(self) -> pd.DataFrame:
        """Load NSE instruments from cache or API"""
        if os.path.exists(self.instruments_cache):
            try:
                with open(self.instruments_cache, "rb") as f:
                    instruments = pickle.load(f)
                logger.info(f"Loaded instruments from cache")
                return pd.DataFrame(instruments)
            except Exception as e:
                logger.warning(f"Error loading instruments cache: {e}")
        
        logger.info("Fetching instruments from KiteConnect API...")
        instruments = self.kite.instruments(exchange="NSE")
        
        with open(self.instruments_cache, "wb") as f:
            pickle.dump(instruments, f)
        
        logger.info(f"Cached {len(instruments)} instruments")
        return pd.DataFrame(instruments)
    
    def load_universe_symbols(self) -> List[str]:
        """Load stock symbols from universe CSV"""
        logger.info(f"DEBUG: Looking for universe CSV at: {self.universe_csv}")
        logger.info(f"DEBUG: Current working directory: {os.getcwd()}")
        logger.info(f"DEBUG: File exists check: {os.path.exists(self.universe_csv)}")
        
        if not os.path.exists(self.universe_csv):
            raise FileNotFoundError(f"Universe CSV not found: {self.universe_csv}")
        
        df = pd.read_csv(self.universe_csv)
        if 'Symbol' not in df.columns:
            raise ValueError("Universe CSV must have a 'Symbol' column")
        
        symbols = df['Symbol'].unique().tolist()
        logger.info(f"Loaded {len(symbols)} symbols from {self.universe_csv}")
        return symbols
    
    def get_historical_data_cached(
        self,
        symbol: str,
        token: int,
        from_date: datetime,
        to_date: datetime,
        interval: str = "day"
    ) -> List[Dict]:
        """Fetch historical data with caching"""
        from_str = from_date.strftime('%Y%m%d')
        to_str = to_date.strftime('%Y%m%d')
        cache_file = os.path.join(
            self.historical_cache_dir,
            f"{symbol}_{token}_{from_str}_{to_str}_{interval}.pkl"
        )
        
        if os.path.exists(cache_file):
            try:
                with open(cache_file, "rb") as f:
                    data = pickle.load(f)
                logger.debug(f"Loaded {symbol} from cache")
                return data
            except Exception as e:
                logger.warning(f"Cache read error for {symbol}: {e}")
        
        logger.debug(f"Fetching {symbol} from API...")
        try:
            time.sleep(self.api_delay)
            data = self.kite.historical_data(
                instrument_token=token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            if data:
                with open(cache_file, "wb") as f:
                    pickle.dump(data, f)
            
            return data
        except Exception as e:
            logger.error(f"Error fetching {symbol}: {e}")
            return []
    
    def prefetch_all_data(
        self,
        symbols: List[str],
        instruments_df: pd.DataFrame,
        start_date: datetime,
        end_date: datetime
    ) -> Dict[str, pd.DataFrame]:
        """Pre-fetch historical data for all stocks"""
        logger.info(f"Pre-fetching data for {len(symbols)} symbols...")
        
        # Filter instruments to our universe
        equity_instruments = instruments_df[
            (instruments_df["segment"] == "NSE") &
            (instruments_df["instrument_type"] == "EQ") &
            (instruments_df["tradingsymbol"].isin(symbols))
        ].copy()
        
        logger.info(f"Found {len(equity_instruments)} instruments to fetch")
        
        all_data = {}
        for idx, row in equity_instruments.iterrows():
            symbol = row['tradingsymbol']
            token = row['instrument_token']
            
            logger.info(f"[{len(all_data)+1}/{len(equity_instruments)}] Fetching {symbol}...")
            
            data_list = self.get_historical_data_cached(symbol, token, start_date, end_date)
            
            if data_list:
                df = pd.DataFrame(data_list)
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                df.set_index('date', inplace=True)
                
                # Ensure numeric types
                for col in ['open', 'high', 'low', 'close', 'volume']:
                    if col in df.columns:
                        df[col] = pd.to_numeric(df[col], errors='coerce')
                
                df.dropna(subset=['open', 'high', 'low', 'close'], inplace=True)
                
                if not df.empty:
                    all_data[symbol] = df
        
        logger.info(f"Successfully loaded data for {len(all_data)} symbols")
        return all_data
    
    def run_analysis(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> pd.DataFrame:
        """
        Run complete MBI EM analysis.
        
        Returns:
            DataFrame with daily MBI metrics including EM
        """
        # Set date range
        if end_date is None:
            end_date = datetime.now().date()
        if start_date is None:
            start_date = end_date - timedelta(days=self.analysis_days)
        
        # Convert to datetime objects
        if isinstance(end_date, datetime):
            end_date = end_date.date()
        if isinstance(start_date, datetime):
            start_date = start_date.date()
        
        # Calculate overall data range needed
        overall_start = start_date - timedelta(days=self.lookback_days)
        
        logger.info(f"Analysis period: {start_date} to {end_date}")
        logger.info(f"Data fetch period: {overall_start} to {end_date}")
        
        # Load instruments and universe
        instruments_df = self.load_instruments()
        universe_symbols = self.load_universe_symbols()
        
        # Pre-fetch all historical data
        stock_data = self.prefetch_all_data(
            universe_symbols,
            instruments_df,
            datetime.combine(overall_start, datetime.min.time()),
            datetime.combine(end_date, datetime.max.time())
        )
        
        if not stock_data:
            raise ValueError("No stock data could be fetched")
        
        # FETCH INDEX DATA (with caching!) - V3 feature
        logger.info(f"DEBUG: index_fetcher is {'available' if self.index_fetcher is not None else 'None'}")
        
        if self.index_fetcher is not None:
            logger.info("Fetching Nifty 500 index data (cached)...")
            logger.info(f"DEBUG: Fetching for period {overall_start} to {end_date}")
            try:
                index_data = self.index_fetcher.fetch_index_data(
                    start_date=datetime.combine(overall_start, datetime.min.time()),
                    end_date=datetime.combine(end_date, datetime.max.time())
                )
                
                logger.info(f"DEBUG: fetch_index_data returned: type={type(index_data)}, len={len(index_data) if index_data is not None else 'None'}")
                
                if index_data is None or len(index_data) == 0:
                    logger.warning("Failed to fetch index data - continuing without index confirmation")
                    logger.warning("DEBUG: index_data is None or empty")
                    index_data = pd.DataFrame()  # Empty DF, will use 'unknown' trend
                else:
                    logger.info(f"SUCCESS: Fetched {len(index_data)} days of index data (cached)")
                    logger.info(f"DEBUG: Index data date range: {index_data.index.min()} to {index_data.index.max()}")
            except Exception as e:
                logger.error(f"EXCEPTION while fetching index data: {e}")
                logger.exception("Full traceback:")
                index_data = pd.DataFrame()
        else:
            logger.warning("WARNING: Index fetcher is None - V3 features disabled")
            logger.warning("Check initialization logs for index_fetcher setup errors")
            index_data = pd.DataFrame()  # Empty DF, will use 'unknown' trend
        
        # PRE-DETECT ALL POCKET PIVOTS (Bulk mode with disk caching!)
        logger.info("Pre-detecting pocket pivots for entire period (optimized)...")
        
        # Calculate extended range (need lookback buffer)
        extended_start = start_date - timedelta(days=self.em_calculator.lookback_days + 5)
        
        # Use optimized bulk detection with disk caching (100x faster!)
        try:
            from pocket_pivot_detector_optimized import OptimizedPocketPivotDetector
            logger.info("Using optimized PPD detector (vectorized + cached)...")
            optimized_detector = OptimizedPocketPivotDetector()
            ppd_cache = optimized_detector.detect_bulk(
                stock_data,
                datetime.combine(extended_start, datetime.min.time()),
                datetime.combine(end_date, datetime.max.time())
            )
            logger.info(f"Bulk PPD detection complete ({len(ppd_cache)} dates with PPDs)")
        except Exception as e:
            logger.warning(f"Optimized detector failed ({e}), falling back to standard detection")
            # Fallback to standard method if optimized fails
            logger.info("Pre-detecting PPDs using standard method...")
            ppd_cache = {}
            cache_date = extended_start
            while cache_date <= end_date:
                cache_dt = datetime.combine(cache_date, datetime.min.time())
                ppds = self.ppd_detector.detect_for_universe(stock_data, cache_dt)
                if ppds:
                    ppd_cache[cache_date] = ppds
                cache_date += timedelta(days=1)
            logger.info(f"Pre-detected PPDs for {len(ppd_cache)} dates (standard mode)")
        
        # Process each day in analysis window
        logger.info("Starting daily analysis loop...")
        results = []
        
        current_date = start_date
        while current_date <= end_date:
            logger.info(f"Processing {current_date}...")
            
            # Check if it's a trading day
            is_trading_day = self._is_trading_day(stock_data, current_date)
            if not is_trading_day:
                logger.info(f"Skipping {current_date} - non-trading day")
                current_date += timedelta(days=1)
                continue
            
            # Get cached PPDs for current date
            current_dt = datetime.combine(current_date, datetime.min.time())
            ppds = ppd_cache.get(current_date, [])
            logger.info(f"Found {len(ppds)} pocket pivots on {current_date}")
            
            # Track follow-through for PPDs from past 10 days (use cache!)
            lookback_start = current_date - timedelta(days=self.em_calculator.lookback_days)
            all_recent_ppds = []
            
            # Collect all PPDs from lookback window (from cache)
            check_date = lookback_start
            while check_date <= current_date:
                date_ppds = ppd_cache.get(check_date, [])
                
                # Convert symbol strings to PocketPivotSignal objects if needed
                for ppd in date_ppds:
                    if isinstance(ppd, str):
                        # Optimized detector returns symbol strings, need to reconstruct PPD with actual prices
                        from pocket_pivot_detector import PocketPivotSignal
                        symbol = ppd
                        
                        # Get actual price data for this symbol on this date
                        if symbol in stock_data:
                            df = stock_data[symbol]
                            check_dt = datetime.combine(check_date, datetime.min.time())
                            
                            # Find the row for this date
                            if check_dt in df.index:
                                row = df.loc[check_dt]
                                
                                ppd_obj = PocketPivotSignal(
                                    symbol=symbol,
                                    date=check_dt,
                                    open_price=float(row['open']),
                                    close_price=float(row['close']),
                                    high_price=float(row['high']),
                                    low_price=float(row['low']),
                                    volume=int(row['volume']),
                                    percent_gain=((row['close'] - row['open']) / row['open']) * 100,
                                    volume_vs_avg=1.5,  # Minimum threshold (actual calc not needed for tracking)
                                    volume_percentile=75.0,
                                    volume_vs_red_days=1.0
                                )
                                all_recent_ppds.append(ppd_obj)
                            else:
                                logger.debug(f"No data for {symbol} on {check_date}, skipping")
                        else:
                            logger.debug(f"Symbol {symbol} not in stock_data, skipping")
                    else:
                        # Already a PPD object
                        all_recent_ppds.append(ppd)
                
                check_date += timedelta(days=1)
            
            logger.info(f"Found {len(all_recent_ppds)} PPDs in lookback window")
            
            # Track follow-through for all recent PPDs
            if all_recent_ppds:
                tracked_ppds = self.ft_tracker.track_multiple_ppds(
                    all_recent_ppds,
                    stock_data,
                    max_lookforward_days=10
                )
            else:
                tracked_ppds = []
            
            # Calculate EM
            em_score, em_metadata = self.em_calculator.calculate_em(current_dt, tracked_ppds)
            
            # Calculate breadth metrics
            breadth = self.breadth_calculator.calculate_metrics_for_date(stock_data, current_dt)
            
            # Get index data for current date (fast lookup from cached DataFrame)
            if len(index_data) > 0 and self.index_fetcher is not None:
                index_info = self.index_fetcher.get_trend_for_date(index_data, current_dt)
            else:
                index_info = {
                    'close': None, 'trend': 'unknown', 
                    'pct_change_1d': 0, 'pct_change_5d': 0,
                    'trend_strength': 0, 'is_rising': False, 'is_falling': False
                }
            
            # Store results (regime classification done after calculating all changes)
            results.append({
                'date': current_date,
                '4.5r': breadth.ratio_4_5,
                'up_4.5': breadth.up_4_5_count,
                'down_4.5': breadth.down_4_5_count,
                '20sma': breadth.sma_20_breadth,
                '50sma': breadth.sma_50_breadth,
                '52WH': breadth.high_52w_count,
                '52WL': breadth.low_52w_count,
                'EM': em_score,
                'EM_valid': em_metadata.get('valid', False),
                'EM_ppd_count': em_metadata.get('ppd_count', 0),
                # Index data (NEW in V3!)
                'index_close': index_info.get('close'),
                'index_trend': index_info.get('trend', 'unknown'),
                'index_chng_1d': index_info.get('pct_change_1d', 0),
                'index_chng_5d': index_info.get('pct_change_5d', 0)
            })
            
            current_date += timedelta(days=1)
        
        # Convert to DataFrame
        df = pd.DataFrame(results)
        
        # Calculate changes (1-day, 3-day, 5-day)
        df['4.5r_chng'] = df['4.5r'].diff()
        df['20sma_chng'] = df['20sma'].diff()
        df['50sma_chng'] = df['50sma'].diff()
        df['EM_chng'] = df['EM'].diff()
        df['EM_chng_3d'] = df['EM'].diff(3)  # 3-day change
        df['EM_chng_5d'] = df['EM'].diff(5)  # 5-day change
        
        # Apply V3 index-aware regime classification
        logger.info("Applying V3 index-aware regime classification...")
        regime_results = []
        
        # Anti-whipsaw state tracking
        from config import (
            MIN_HOLD_DAYS_BULLISH, MIN_HOLD_DAYS_BEARISH,
            MAX_POSITION_CHANGE_PER_DAY, REQUIRE_EXIT_CONFIRMATION,
            CRASH_EXIT_THRESHOLD, ENABLE_POSITION_SMOOTHING
        )
        
        prev_position = 0.0
        prev_regime = None
        last_entry_idx = None
        last_exit_idx = None
        consecutive_weak_days = 0
        
        for idx, row in df.iterrows():
            regime_class = self.regime_classifier.classify(
                em_score=row['EM'],
                em_change_1d=row['EM_chng'] if pd.notna(row['EM_chng']) else None,
                em_change_3d=row['EM_chng_3d'] if pd.notna(row['EM_chng_3d']) else None,
                em_change_5d=row['EM_chng_5d'] if pd.notna(row['EM_chng_5d']) else None,
                index_trend=row.get('index_trend', 'unknown'),
                index_pct_change_5d=row.get('index_chng_5d', 0)
            )
            
            # Get raw classification
            raw_position = regime_class.position_size
            raw_regime = regime_class.regime.value
            em_chng_3d = row['EM_chng_3d'] if pd.notna(row['EM_chng_3d']) else 0
            
            # ======= ANTI-WHIPSAW LOGIC =======
            
            # Get index trend for crash confirmation
            index_trend = row.get('index_trend', 'unknown')
            index_chng_5d = row.get('index_chng_5d', 0) if pd.notna(row.get('index_chng_5d', 0)) else 0
            
            # Rule 1: Index-Confirmed Crash Exit (intelligent, data-driven!)
            # KEY INSIGHT: EM crash + Index strong = Narrow rally (reduce, don't exit)
            #              EM crash + Index weak = Real crash (exit all)
            if em_chng_3d <= CRASH_EXIT_THRESHOLD:
                # Check index confirmation
                if index_trend == 'falling' or index_chng_5d < -1.0:
                    # REAL CRASH: Both EM and Index are weak
                    final_position = 0.0
                    last_exit_idx = idx
                    action_override = "EXIT ALL - EM + Index both crashing! (Real crash)"
                elif index_trend == 'rising' and index_chng_5d > 0:
                    # NARROW RALLY: EM crashed but index strong (large caps leading)
                    # Reduce to 50% instead of exiting (individual stocks harder to pick)
                    final_position = 0.5
                    # Don't set last_exit_idx (allow re-entry if EM recovers)
                    action_override = "REDUCE to 50% - EM correction (index still strong - narrow rally)"
                else:
                    # Index neutral/flat - unclear situation, be cautious
                    final_position = 0.3
                    action_override = "REDUCE to 30% - EM crash + index neutral (caution)"
                
            # Rule 2: Minimum Hold Period After Exit (bearish)
            elif last_exit_idx is not None and (idx - last_exit_idx) < MIN_HOLD_DAYS_BEARISH:
                final_position = 0.0
                action_override = f"STAY OUT - Min hold period ({idx - last_exit_idx}/{MIN_HOLD_DAYS_BEARISH} days)"
                
            # Rule 3: Minimum Hold Period After Entry (bullish)
            elif last_entry_idx is not None and prev_position > 0 and raw_position < prev_position:
                days_since_entry = idx - last_entry_idx
                if days_since_entry < MIN_HOLD_DAYS_BULLISH:
                    final_position = prev_position  # Hold current position
                    action_override = f"HOLD - Min hold period ({days_since_entry}/{MIN_HOLD_DAYS_BULLISH} days)"
                else:
                    # Can exit now
                    final_position = raw_position
                    action_override = None
            
            # Rule 4: Position Change Smoothing
            elif ENABLE_POSITION_SMOOTHING and abs(raw_position - prev_position) > MAX_POSITION_CHANGE_PER_DAY:
                # Limit position change to max allowed
                if raw_position > prev_position:
                    # Increasing position
                    final_position = min(raw_position, prev_position + MAX_POSITION_CHANGE_PER_DAY)
                    action_override = f"GRADUAL ENTRY - Increasing position smoothly ({final_position:.0%})"
                else:
                    # Decreasing position
                    final_position = max(raw_position, prev_position - MAX_POSITION_CHANGE_PER_DAY)
                    action_override = f"GRADUAL EXIT - Decreasing position smoothly ({final_position:.0%})"
            
            # Rule 5: Exit Confirmation (require 2 weak days)
            elif REQUIRE_EXIT_CONFIRMATION and prev_position > 0 and raw_position == 0:
                # Check if this is consecutive weak signal
                if prev_position > 0 and consecutive_weak_days < 1:
                    # First weak day, don't exit yet
                    final_position = prev_position
                    consecutive_weak_days += 1
                    action_override = "WATCH - Waiting for exit confirmation (1/2 days)"
                else:
                    # Second consecutive weak day, exit confirmed
                    final_position = 0.0
                    consecutive_weak_days = 0
                    action_override = "EXIT CONFIRMED - 2 consecutive weak days"
                    last_exit_idx = idx
            
            else:
                # No anti-whipsaw rules apply, use raw position
                final_position = raw_position
                action_override = None
                consecutive_weak_days = 0  # Reset counter
            
            # Track entry/exit
            if final_position > 0 and prev_position == 0:
                last_entry_idx = idx
            
            # Update action if overridden
            if action_override:
                final_action = action_override
            else:
                final_action = regime_class.trading_action
            
            # Generate multi-timeframe signals
            try:
                from timeframe_analyzer import analyze_timeframes
                tf_signals = analyze_timeframes(
                    em_score=row['EM'],
                    em_trend=regime_class.em_trend,
                    em_chng_5d=row['EM_chng_5d'] if pd.notna(row['EM_chng_5d']) else None,
                    market_type=regime_class.market_type.value,
                    index_trend=row.get('index_trend', 'unknown'),
                    index_chng_5d=row.get('index_chng_5d', 0),
                    divergence_warning=regime_class.divergence_warning,
                    regime=raw_regime
                )
            except Exception as e:
                logger.warning(f"Timeframe analysis failed: {e}, using defaults")
                tf_signals = {
                    "short": None, "medium": None, "long": None, "very_long": None
                }
            
            regime_results.append({
                'regime': raw_regime,
                'market_type': regime_class.market_type.value,
                'em_trend': regime_class.em_trend,
                'position_size': final_position,  # Use smoothed position
                'trading_action': final_action,  # Use overridden action if applicable
                'regime_confidence': regime_class.confidence,
                'divergence_warning': regime_class.divergence_warning,
                # Multi-timeframe signals (NEW!)
                'signal_2_5d': str(tf_signals['short']) if tf_signals['short'] else 'N/A',
                'signal_5_10d': str(tf_signals['medium']) if tf_signals['medium'] else 'N/A',
                'signal_10_21d': str(tf_signals['long']) if tf_signals['long'] else 'N/A',
                'signal_21plus': str(tf_signals['very_long']) if tf_signals['very_long'] else 'N/A',
                'reason_2_5d': tf_signals['short'].reason if tf_signals['short'] else '',
                'reason_5_10d': tf_signals['medium'].reason if tf_signals['medium'] else '',
                'reason_10_21d': tf_signals['long'].reason if tf_signals['long'] else '',
                'reason_21plus': tf_signals['very_long'].reason if tf_signals['very_long'] else ''
            })
            
            # Update state for next iteration
            prev_position = final_position
            prev_regime = raw_regime
        
        # Add regime columns to DataFrame
        regime_df = pd.DataFrame(regime_results)
        df = pd.concat([df, regime_df], axis=1)
        
        logger.info(f"Analysis complete. Processed {len(df)} trading days")
        
        return df
    
    def _is_trading_day(self, stock_data: Dict[str, pd.DataFrame], date: datetime.date) -> bool:
        """Check if date is a trading day by sampling stocks"""
        check_limit = min(5, len(stock_data))
        checked = 0
        
        for symbol, df in stock_data.items():
            if checked >= check_limit:
                break
            if not df[df.index.date == date].empty:
                return True
            checked += 1
        
        return False
    
    def save_to_excel(
        self,
        df: pd.DataFrame,
        output_file: str = "mbi_em_dashboard_{timestamp}.xlsx"
    ) -> str:
        """
        Save results to Excel with formatting.
        Applies color coding via excel_formatter.py
        """
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = output_file.format(timestamp=timestamp)
        
        # Prepare display DataFrame with V3 columns
        columns_to_include = [
            'date', 
            'index_close', 'index_trend', 'index_chng_5d',  # V3: Index data
            '4.5r', '4.5r_chng', '20sma', '20sma_chng',
            '50sma', '50sma_chng', '52WH', '52WL', 
            'EM', 'EM_chng', 'EM_chng_3d', 'EM_chng_5d',
            'em_trend', 'market_type', 'divergence_warning',  # V3: Market type & divergence
            'position_size', 'regime', 'trading_action'
        ]
        
        # Add V3.3 timeframe columns if they exist
        timeframe_cols = [
            'signal_2_5d', 'reason_2_5d',
            'signal_5_10d', 'reason_5_10d', 
            'signal_10_21d', 'reason_10_21d',
            'signal_21plus', 'reason_21plus'
        ]
        for col in timeframe_cols:
            if col in df.columns:
                columns_to_include.append(col)
        
        display_df = df[columns_to_include].copy()
        
        # Format date
        display_df['date'] = pd.to_datetime(display_df['date']).dt.strftime('%Y-%m-%d')
        
        # Round numeric columns (safe rounding - check dtype first)
        numeric_cols = ['4.5r', '20sma', '50sma', 'EM', 'index_close']
        for col in numeric_cols:
            if col in display_df.columns:
                # Only round if column is numeric
                if pd.api.types.is_numeric_dtype(display_df[col]):
                    display_df[col] = display_df[col].round(1)
        
        change_cols = ['4.5r_chng', '20sma_chng', '50sma_chng', 'EM_chng', 'EM_chng_3d', 'EM_chng_5d', 'index_chng_5d']
        for col in change_cols:
            if col in display_df.columns:
                # Only round if column is numeric
                if pd.api.types.is_numeric_dtype(display_df[col]):
                    display_df[col] = display_df[col].round(2)
        
        # Format position_size as percentage (safe)
        if 'position_size' in display_df.columns:
            if pd.api.types.is_numeric_dtype(display_df['position_size']):
                display_df['position_size'] = (display_df['position_size'] * 100).round(0).astype(str) + '%'
        
        # Format divergence warning as Yes/No (safe)
        if 'divergence_warning' in display_df.columns:
            display_df['divergence_warning'] = display_df['divergence_warning'].map({True: 'YES', False: 'No'})
        
        # Save to Excel (basic)
        display_df.to_excel(output_file, index=False, engine='openpyxl')
        logger.info(f"Saved basic Excel to {output_file}")
        
        # Apply color formatting
        try:
            from excel_formatter import ExcelFormatter
            formatter = ExcelFormatter()
            formatter.format_workbook(output_file)
            logger.info(f"Applied color formatting to {output_file}")
        except Exception as e:
            logger.warning(f"Could not apply formatting: {e}")
        
        return output_file


# ==============================================================================
# Main Execution
# ==============================================================================

def main():
    """Run MBI EM Dashboard analysis"""
    # Configure logging to BOTH console AND file
    log_file = 'mbi_em_dashboard_debug.log'
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file, mode='w', encoding='utf-8'),  # File (overwrite each run)
            logging.StreamHandler()  # Console
        ]
    )
    logger.info(f"Logging to file: {log_file}")
    
    print(f"\n{'='*80}")
    print(f"MBI EM DASHBOARD - Pocket Pivot Follow-Through Analysis")
    print(f"{'='*80}\n")
    
    # Configuration - Import from config.py
    try:
        from config import (API_KEY, ACCESS_TOKEN, UNIVERSE_CSV, 
                           ANALYSIS_DAYS, LOOKBACK_DAYS,
                           ANALYSIS_START_DATE, ANALYSIS_END_DATE)
    except ImportError as e:
        logger.error(f"Failed to import from config.py: {e}")
        logger.error("Please ensure config.py exists with API_KEY, ACCESS_TOKEN, etc.")
        raise
    
    # Initialize dashboard
    dashboard = MBIEMDashboard(
        api_key=API_KEY,
        access_token=ACCESS_TOKEN,
        universe_csv=UNIVERSE_CSV,
        analysis_days=ANALYSIS_DAYS,      # From config.py
        lookback_days=LOOKBACK_DAYS        # From config.py
    )
    
    # DEBUG: Check if index_fetcher survived initialization
    logger.info(f"DEBUG POST-INIT: dashboard.index_fetcher = {dashboard.index_fetcher}")
    logger.info(f"DEBUG POST-INIT: Type = {type(dashboard.index_fetcher) if dashboard.index_fetcher else 'None'}")
    
    # Run analysis
    try:
        # Use specific dates from config.py if provided
        if ANALYSIS_START_DATE and ANALYSIS_END_DATE:
            from datetime import datetime
            start_date = datetime.strptime(ANALYSIS_START_DATE, '%Y-%m-%d')
            end_date = datetime.strptime(ANALYSIS_END_DATE, '%Y-%m-%d')
            logger.info(f"Using specific dates from config.py: {ANALYSIS_START_DATE} to {ANALYSIS_END_DATE}")
            results_df = dashboard.run_analysis(start_date=start_date, end_date=end_date)
        else:
            # Use automatic calculation (today minus ANALYSIS_DAYS)
            logger.info(f"Using automatic date range: last {ANALYSIS_DAYS} days")
            results_df = dashboard.run_analysis()
        
        # Display summary
        print(f"\n{'='*80}")
        print(f"ANALYSIS SUMMARY")
        print(f"{'='*80}\n")
        print(results_df[['date', 'EM', 'regime', 'trading_action']].tail(10).to_string(index=False))
        
        # Save to Excel
        output_file = dashboard.save_to_excel(results_df)
        print(f"\n[OK] Results saved to: {output_file}\n")
        
    except Exception as e:
        logger.error(f"Analysis failed: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()

