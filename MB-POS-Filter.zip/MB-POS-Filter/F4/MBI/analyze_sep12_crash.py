"""
Analyze Sep 12, 2023 "Crash" - Was it real?
"""

import pandas as pd

df = pd.read_excel("../../../mbi_em_dashboard_20251105_150843.xlsx")
df['date'] = pd.to_datetime(df['date'])

# Sep 1-30, 2023
sep_data = df[(df['date'] >= '2023-09-01') & (df['date'] <= '2023-09-30')].copy()

print("\n" + "="*80)
print("SEPTEMBER 2023 CRASH ANALYSIS - Was Sep 12 a Real Crash?")
print("="*80 + "\n")

print("Full Timeline:")
print("-" * 80)
print(f"{'Date':<12} {'Index':>8} {'Trend':>8} {'EM':>6} {'EM_chng_3d':>10} {'EM_Trend':>10} {'Position':>10}")
print("-" * 80)

for idx, row in sep_data.iterrows():
    date_str = row['date'].strftime('%Y-%m-%d')
    index_val = row.get('index_close', 0)
    index_trend = row.get('index_trend', 'unknown')
    em = row['EM']
    em_chng_3d = row.get('EM_chng_3d', 0)
    em_trend = row['em_trend']
    pos = row.get('position_size', 'N/A')
    
    marker = ""
    if em_chng_3d <= -10:
        marker = " <-- CRASH SIGNAL"
    elif em > 70 and em_trend == 'declining':
        marker = " <-- V3.4 WARNING"
    
    print(f"{date_str:<12} {index_val:8.1f} {index_trend:>8s} {em:6.1f}% {em_chng_3d:9.1f}% {em_trend:>10s} {str(pos):>10s}{marker}")

print("\n" + "="*80)
print("ANALYSIS")
print("="*80 + "\n")

# Check what happened after Sep 12
sep_12_idx = sep_data[sep_data['date'] == '2023-09-12'].index[0]
after_crash = df[df['date'] > '2023-09-12'].head(10)

print("What happened AFTER Sep 12 'crash':")
print()
print(f"{'Date':<12} {'Index':>8} {'Index Chng':>11} {'EM':>6} {'EM_Trend':>10}")
print("-" * 60)

prev_index = sep_data[sep_data['date'] == '2023-09-12'].iloc[0]['index_close']
for idx, row in after_crash.iterrows():
    date_str = row['date'].strftime('%Y-%m-%d')
    index_val = row.get('index_close', 0)
    index_chng = ((index_val - prev_index) / prev_index * 100)
    em = row['EM']
    em_trend = row['em_trend']
    
    print(f"{date_str:<12} {index_val:8.1f} {index_chng:+10.2f}% {em:6.1f}% {em_trend:>10s}")
    prev_index = index_val

print("\n" + "="*80)
print("CONCLUSION")
print("="*80 + "\n")

# Was it a real crash?
sep_12_em = sep_data[sep_data['date'] == '2023-09-12'].iloc[0]['EM']
peak_em = sep_data['EM'].max()
em_drop = peak_em - sep_12_em

after_low = after_crash.head(10)['EM'].min()
after_recovery = after_crash.head(10)['EM'].max()

print(f"Sep 1-12 EM drop: {peak_em:.1f}% -> {sep_12_em:.1f}% ({em_drop:.1f}% decline)")
print(f"Next 10 days EM range: {after_low:.1f}% to {after_recovery:.1f}%")
print()

if after_low > 40:
    print("[FALSE ALARM] EM didn't collapse below 40%")
    print("  Index kept rising (17460 -> 17600+)")
    print("  This was a correction, not a crash")
    print("  Exiting was WRONG - missed the continued rally")
else:
    print("[REAL CRASH] EM collapsed below 40%")
    print("  Exiting was correct")

print()
print("This is exactly why:")
print("  - Crash detection at -12% might be too sensitive")
print("  - Need index confirmation (not just EM alone)")
print("  - Sep 12: EM crashed but index rising = FALSE crash signal")
print()

