"""
Follow-Through Tracker
======================
Tracks whether Pocket Pivot signals result in sustained upward momentum.

Uses multi-tier success criteria:
- Tier 1 (60%): Price persistence above PPD high
- Tier 2 (30%): Gain magnitude from PPD close
- Tier 3 (10%): Trend confirmation via 20 EMA
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Optional
from datetime import datetime, timedelta
import logging

from pocket_pivot_detector import PocketPivotSignal

logger = logging.getLogger(__name__)


class FollowThroughTracker:
    """
    Tracks follow-through success/failure of Pocket Pivot signals.
    
    Configuration:
    - lookback_days: How many days forward to check (default: 5)
    - success_days_required: Days above PPD high needed (default: 3)
    - gain_target_percent: % gain target from PPD close (default: 3.0)
    - trend_days_required: Days above 20 EMA needed (default: 5)
    - success_threshold: Composite score threshold for success (default: 0.65)
    """
    
    def __init__(
        self,
        lookback_days: int = 5,
        success_days_required: int = 3,
        gain_target_percent: float = 3.0,
        trend_days_required: int = 5,
        success_threshold: float = 0.65
    ):
        self.lookback_days = lookback_days
        self.success_days_required = success_days_required
        self.gain_target_percent = gain_target_percent
        self.trend_days_required = trend_days_required
        self.success_threshold = success_threshold
        
        logger.info(f"FollowThroughTracker initialized: lookback={lookback_days}d, "
                   f"gain_target={gain_target_percent}%, threshold={success_threshold}")
    
    def calculate_ema(self, series: pd.Series, period: int) -> pd.Series:
        """Calculate exponential moving average"""
        return series.ewm(span=period, adjust=False, min_periods=period).mean()
    
    def track_follow_through(
        self,
        ppd: PocketPivotSignal,
        stock_df: pd.DataFrame,
        max_lookforward_days: int = 10
    ) -> float:
        """
        Track follow-through for a single Pocket Pivot signal.
        
        Args:
            ppd: PocketPivotSignal to track
            stock_df: DataFrame with full OHLCV data (indexed by date)
            max_lookforward_days: Maximum days to look forward
        
        Returns:
            Composite follow-through score (0.0 to 1.0)
        """
        # Normalize PPD date for comparison
        ppd_date = pd.to_datetime(ppd.date).tz_localize(None)
        
        # Get data AFTER the PPD
        future_data = stock_df[stock_df.index > ppd_date].head(max_lookforward_days)
        
        if future_data.empty:
            logger.debug(f"No future data available for {ppd.symbol} after {ppd_date}")
            return 0.0
        
        # Get data needed for EMA calculation (need history before PPD too)
        full_data = stock_df[stock_df.index <= ppd_date].tail(50)  # Last 50 days including PPD
        full_data = pd.concat([full_data, future_data])
        
        # Calculate 20 EMA if we have enough data
        if len(full_data) >= 20:
            full_data['ema_20'] = self.calculate_ema(full_data['close'], 20)
        else:
            full_data['ema_20'] = np.nan
        
        # Re-slice to just future data
        future_data = full_data[full_data.index > ppd_date].head(max_lookforward_days)
        
        # ===== Tier 1: Price Persistence (60% weight) =====
        days_above_ppd_high = (future_data['close'] > ppd.high_price).sum()
        total_days_checked = min(len(future_data), self.lookback_days)
        
        if total_days_checked == 0:
            tier1_score = 0.0
        else:
            tier1_score = min(1.0, days_above_ppd_high / self.success_days_required)
        
        # ===== Tier 2: Gain Magnitude (30% weight) =====
        if ppd.close_price > 0:
            max_gain_pct = ((future_data['high'].max() - ppd.close_price) / ppd.close_price) * 100
            tier2_score = min(1.0, max_gain_pct / self.gain_target_percent)
        else:
            logger.warning(f"Invalid close_price for {ppd.symbol} on {ppd.date}, skipping gain calculation")
            tier2_score = 0.0
        
        # ===== Tier 3: Trend Confirmation (10% weight) =====
        if 'ema_20' in future_data.columns and not future_data['ema_20'].isna().all():
            days_above_ema = (future_data['close'] > future_data['ema_20']).sum()
            tier3_score = min(1.0, days_above_ema / self.trend_days_required)
        else:
            tier3_score = 0.0
        
        # ===== Composite Score =====
        composite_score = (tier1_score * 0.6) + (tier2_score * 0.3) + (tier3_score * 0.1)
        
        logger.debug(
            f"{ppd.symbol} on {ppd_date.strftime('%Y-%m-%d')}: "
            f"T1={tier1_score:.2f} T2={tier2_score:.2f} T3={tier3_score:.2f} "
            f"-> Composite={composite_score:.2f}"
        )
        
        return composite_score
    
    def evaluate_success(self, score: float) -> bool:
        """Determine if a follow-through score represents success"""
        return score >= self.success_threshold
    
    def track_multiple_ppds(
        self,
        ppds: List[PocketPivotSignal],
        stock_data: Dict[str, pd.DataFrame],
        max_lookforward_days: int = 10
    ) -> List[PocketPivotSignal]:
        """
        Track follow-through for multiple PPDs and update them in place.
        
        Args:
            ppds: List of PocketPivotSignals to track
            stock_data: Dict mapping symbol -> DataFrame with OHLCV data
            max_lookforward_days: Maximum days to look forward
        
        Returns:
            List of PPDs with follow_through_score and is_success populated
        """
        tracked_ppds = []
        
        for ppd in ppds:
            # Get stock data
            if ppd.symbol not in stock_data:
                logger.warning(f"No data available for {ppd.symbol}, skipping follow-through tracking")
                continue
            
            stock_df = stock_data[ppd.symbol]
            
            # Calculate follow-through score
            score = self.track_follow_through(ppd, stock_df, max_lookforward_days)
            
            # Update PPD object
            ppd.follow_through_score = score
            ppd.is_success = self.evaluate_success(score)
            
            tracked_ppds.append(ppd)
        
        # Log summary
        success_count = sum(1 for p in tracked_ppds if p.is_success)
        logger.info(
            f"Tracked {len(tracked_ppds)} PPDs: {success_count} successes "
            f"({success_count/len(tracked_ppds)*100:.1f}% success rate)"
        )
        
        return tracked_ppds
    
    def get_success_rate(self, ppds: List[PocketPivotSignal]) -> float:
        """
        Calculate success rate for a list of tracked PPDs.
        
        Args:
            ppds: List of PocketPivotSignals with follow-through tracking completed
        
        Returns:
            Success rate as percentage (0-100)
        """
        if not ppds:
            return 0.0
        
        # Filter to only PPDs that have been tracked
        tracked = [p for p in ppds if p.is_success is not None]
        
        if not tracked:
            return 0.0
        
        success_count = sum(1 for p in tracked if p.is_success)
        return (success_count / len(tracked)) * 100
    
    def get_statistics(self, ppds: List[PocketPivotSignal]) -> Dict:
        """Get detailed statistics for tracked PPDs"""
        tracked = [p for p in ppds if p.follow_through_score is not None]
        
        if not tracked:
            return {
                'total_ppds': 0,
                'tracked_ppds': 0,
                'success_count': 0,
                'failure_count': 0,
                'success_rate': 0.0,
                'avg_score': 0.0,
                'avg_success_score': 0.0,
                'avg_failure_score': 0.0
            }
        
        successes = [p for p in tracked if p.is_success]
        failures = [p for p in tracked if not p.is_success]
        
        return {
            'total_ppds': len(ppds),
            'tracked_ppds': len(tracked),
            'success_count': len(successes),
            'failure_count': len(failures),
            'success_rate': (len(successes) / len(tracked)) * 100,
            'avg_score': np.mean([p.follow_through_score for p in tracked]),
            'avg_success_score': np.mean([p.follow_through_score for p in successes]) if successes else 0.0,
            'avg_failure_score': np.mean([p.follow_through_score for p in failures]) if failures else 0.0,
            'best_performers': sorted(
                [(p.symbol, p.follow_through_score) for p in successes],
                key=lambda x: x[1],
                reverse=True
            )[:5]
        }


# ==============================================================================
# Testing / Example Usage
# ==============================================================================

if __name__ == "__main__":
    from pocket_pivot_detector import PocketPivotDetector
    
    # Configure logging for testing
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Create sample data with a pocket pivot and follow-through
    dates = pd.date_range('2024-01-01', periods=30, freq='D')
    sample_data = pd.DataFrame({
        'open': [100] * 30,
        'high': [105] * 30,
        'low': [95] * 30,
        'close': [100] * 30,
        'volume': [2000000] * 30
    }, index=dates)
    
    # Day 10: Pocket Pivot (+5% with high volume)
    ppd_date = dates[10]
    sample_data.loc[ppd_date, 'open'] = 100
    sample_data.loc[ppd_date, 'close'] = 105
    sample_data.loc[ppd_date, 'high'] = 106
    sample_data.loc[ppd_date, 'volume'] = 8000000
    
    # Days 11-15: Follow-through (prices stay above 105)
    for i in range(11, 16):
        sample_data.loc[dates[i], 'close'] = 107 + i  # Trending up
        sample_data.loc[dates[i], 'high'] = 109 + i
    
    # Detect pocket pivot
    detector = PocketPivotDetector()
    ppds = detector.detect_pocket_pivots(sample_data, "TEST", target_date=ppd_date)
    
    print(f"\n{'='*80}")
    print(f"FOLLOW-THROUGH TRACKER TEST")
    print(f"{'='*80}\n")
    print(f"Detected {len(ppds)} pocket pivot(s)\n")
    
    # Track follow-through
    tracker = FollowThroughTracker()
    tracked_ppds = tracker.track_multiple_ppds(ppds, {"TEST": sample_data})
    
    for ppd in tracked_ppds:
        status = "✅ SUCCESS" if ppd.is_success else "❌ FAILURE"
        print(f"  {ppd.symbol} on {ppd.date.strftime('%Y-%m-%d')}")
        print(f"    Score: {ppd.follow_through_score:.2f} -> {status}")
    
    # Statistics
    stats = tracker.get_statistics(tracked_ppds)
    print(f"\nStatistics:")
    print(f"  Success Rate: {stats['success_rate']:.1f}%")
    print(f"  Average Score: {stats['avg_score']:.2f}")
    print(f"  Successes: {stats['success_count']} | Failures: {stats['failure_count']}")

