"""
Excel Formatter for MBI EM Dashboard V3
========================================
Applies conditional formatting with index-aware enhancements.

Color Coding:
- EM < 12: Red background (bear control)
- EM 12-18: Yellow background (early momentum)
- EM 18-40: Green background (healthy)
- EM 40-60: Dark green background (strong)
- EM > 60: Blue background (extreme)
- Change columns: Green (positive), Red (negative)
- Index trend: Green (rising), Red (falling), Gray (flat)
- Divergence warning: Red highlight when YES
- Market type: Color-coded by quality
"""

import pandas as pd
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from typing import Optional
import logging

logger = logging.getLogger(__name__)


class ExcelFormatter:
    """
    Formats MBI EM Dashboard Excel output with conditional formatting.
    """
    
    def __init__(self):
        # Define color fills
        self.black_fill = PatternFill(start_color="000000", end_color="000000", fill_type="solid")
        self.red_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
        self.orange_fill = PatternFill(start_color="FFA500", end_color="FFA500", fill_type="solid")
        self.yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
        self.green_fill = PatternFill(start_color="00FF00", end_color="00FF00", fill_type="solid")
        self.light_green_fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
        self.light_red_fill = PatternFill(start_color="FFB6C1", end_color="FFB6C1", fill_type="solid")
        self.blue_fill = PatternFill(start_color="87CEEB", end_color="87CEEB", fill_type="solid")
        
        # Define fonts
        self.white_font = Font(color="FFFFFF", bold=True)
        self.black_font = Font(color="000000")
        self.bold_font = Font(bold=True)
        
        # Define borders
        thin_border = Side(border_style="thin", color="000000")
        self.border = Border(left=thin_border, right=thin_border, top=thin_border, bottom=thin_border)
        
        logger.info("ExcelFormatter initialized")
    
    def format_workbook(
        self,
        excel_file: str,
        output_file: Optional[str] = None
    ) -> str:
        """
        Apply formatting to an existing Excel file.
        
        Args:
            excel_file: Path to input Excel file
            output_file: Path to output file (if None, overwrites input)
        
        Returns:
            Path to formatted file
        """
        if output_file is None:
            output_file = excel_file
        
        logger.info(f"Formatting {excel_file}...")
        
        # Load workbook
        wb = openpyxl.load_workbook(excel_file)
        ws = wb.active
        
        # Apply formatting
        self._format_header(ws)
        self._format_data_rows(ws)
        self._adjust_column_widths(ws)
        
        # Save
        wb.save(output_file)
        logger.info(f"Formatted workbook saved to {output_file}")
        
        return output_file
    
    def _format_header(self, ws):
        """Format header row"""
        for cell in ws[1]:
            cell.fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            cell.font = Font(color="FFFFFF", bold=True)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = self.border
    
    def _format_data_rows(self, ws):
        """Apply conditional formatting to data rows"""
        # Get column indices (assuming standard layout)
        col_mapping = self._get_column_mapping(ws)
        
        for row_idx in range(2, ws.max_row + 1):
            try:
                # Get EM value
                em_col = col_mapping.get('EM')
                if em_col:
                    em_value = ws[f"{em_col}{row_idx}"].value
                    
                    if em_value is not None and not isinstance(em_value, str):
                        # Format EM cell based on value
                        em_cell = ws[f"{em_col}{row_idx}"]
                        fill, font = self._get_em_formatting(em_value)
                        em_cell.fill = fill
                        em_cell.font = font
                        em_cell.alignment = Alignment(horizontal="right")
                        em_cell.border = self.border
                
                # Format change columns (green/red) - including new 3d/5d changes
                change_cols = ['4.5r_chng', '20sma_chng', '50sma_chng', 'EM_chng', 'EM_chng_3d', 'EM_chng_5d']
                for col_name in change_cols:
                    col_letter = col_mapping.get(col_name)
                    if col_letter:
                        cell = ws[f"{col_letter}{row_idx}"]
                        value = cell.value
                        
                        if value is not None and not isinstance(value, str):
                            if value > 0:
                                cell.fill = self.light_green_fill
                                cell.font = self.black_font
                            elif value < 0:
                                cell.fill = self.light_red_fill
                                cell.font = self.black_font
                        
                        cell.alignment = Alignment(horizontal="right")
                        cell.border = self.border
                
                # Format 4.5r based on extreme values
                ratio_col = col_mapping.get('4.5r')
                if ratio_col:
                    ratio_cell = ws[f"{ratio_col}{row_idx}"]
                    ratio_value = ratio_cell.value
                    
                    if ratio_value is not None and not isinstance(ratio_value, str):
                        if ratio_value > 400:
                            ratio_cell.fill = self.orange_fill
                        elif ratio_value < 50:
                            ratio_cell.fill = self.red_fill
                            ratio_cell.font = self.white_font
                        elif 200 <= ratio_value <= 400:
                            ratio_cell.fill = self.green_fill
                    
                    ratio_cell.alignment = Alignment(horizontal="right")
                    ratio_cell.border = self.border
                
                # Format SMA breadth percentages
                for sma_col_name in ['20sma', '50sma']:
                    col_letter = col_mapping.get(sma_col_name)
                    if col_letter:
                        cell = ws[f"{col_letter}{row_idx}"]
                        value = cell.value
                        
                        if value is not None and not isinstance(value, str):
                            if value < 15:  # Very low
                                cell.fill = self.orange_fill
                            elif value < 25:  # Low
                                cell.fill = self.light_green_fill
                        
                        cell.alignment = Alignment(horizontal="right")
                        cell.border = self.border
                
                # Format 52W high/low comparison
                wh_col = col_mapping.get('52WH')
                wl_col = col_mapping.get('52WL')
                if wh_col and wl_col:
                    wh_value = ws[f"{wh_col}{row_idx}"].value
                    wl_value = ws[f"{wl_col}{row_idx}"].value
                    
                    if (wh_value is not None and wl_value is not None and 
                        not isinstance(wh_value, str) and not isinstance(wl_value, str)):
                        if wl_value > wh_value:
                            ws[f"{wl_col}{row_idx}"].fill = self.red_fill
                            ws[f"{wl_col}{row_idx}"].font = self.white_font
                
                # Format regime column (updated for V2 classifier regimes)
                regime_col = col_mapping.get('regime')
                if regime_col:
                    regime_cell = ws[f"{regime_col}{row_idx}"]
                    regime_value = regime_cell.value
                    
                    if regime_value:
                        # V2 Classifier regimes
                        if "Bear" in str(regime_value) or "Deteriorating" in str(regime_value):
                            regime_cell.fill = self.red_fill
                            regime_cell.font = self.white_font
                        elif "Repair" in str(regime_value):
                            regime_cell.fill = self.orange_fill
                        elif "Early" in str(regime_value):
                            regime_cell.fill = self.yellow_fill
                        elif "Healthy" in str(regime_value):
                            regime_cell.fill = self.green_fill
                        elif "Strong Bullish" in str(regime_value):
                            # Dark green for Strong Bullish (best zone!)
                            regime_cell.fill = PatternFill(start_color="006400", end_color="006400", fill_type="solid")
                            regime_cell.font = self.white_font
                        elif "Extreme Bullish" in str(regime_value):
                            # Blue for Extreme
                            regime_cell.fill = self.blue_fill
                        elif "Euphoria" in str(regime_value):
                            regime_cell.fill = self.blue_fill
                    
                    regime_cell.alignment = Alignment(horizontal="center")
                    regime_cell.border = self.border
                
                # Format em_trend column (rising/stable/declining/crashing)
                trend_col = col_mapping.get('em_trend')
                if trend_col:
                    trend_cell = ws[f"{trend_col}{row_idx}"]
                    trend_value = trend_cell.value
                    
                    if trend_value:
                        if "rising" in str(trend_value).lower():
                            trend_cell.fill = self.light_green_fill
                            trend_cell.font = self.black_font
                        elif "stable" in str(trend_value).lower():
                            trend_cell.font = self.black_font
                        elif "declining" in str(trend_value).lower():
                            trend_cell.fill = self.light_red_fill
                            trend_cell.font = self.black_font
                        elif "crashing" in str(trend_value).lower():
                            trend_cell.fill = self.red_fill
                            trend_cell.font = self.white_font
                    
                    trend_cell.alignment = Alignment(horizontal="center")
                    trend_cell.border = self.border
                
                # Format position_size column
                pos_col = col_mapping.get('position_size')
                if pos_col:
                    pos_cell = ws[f"{pos_col}{row_idx}"]
                    pos_value = str(pos_cell.value).replace('%', '') if pos_cell.value else None
                    
                    if pos_value:
                        try:
                            pos_num = float(pos_value)
                            if pos_num == 0:
                                pos_cell.fill = self.red_fill
                                pos_cell.font = self.white_font
                            elif pos_num >= 100:
                                pos_cell.fill = self.light_green_fill
                            elif pos_num >= 50:
                                pos_cell.fill = self.yellow_fill
                        except:
                            pass
                    
                    pos_cell.alignment = Alignment(horizontal="center")
                    pos_cell.border = self.border
                
                # Format timeframe signal columns (NEW!)
                signal_cols = ['signal_2_5d', 'signal_5_10d', 'signal_10_21d', 'signal_21plus']
                for sig_col in signal_cols:
                    col_letter = col_mapping.get(sig_col)
                    if col_letter:
                        cell = ws[f"{col_letter}{row_idx}"]
                        value = str(cell.value) if cell.value else ''
                        
                        # Color code based on action
                        if 'BUY (HIGH)' in value:
                            cell.fill = PatternFill(start_color="006400", end_color="006400", fill_type="solid")
                            cell.font = self.white_font
                        elif 'BUY (MEDIUM)' in value:
                            cell.fill = self.light_green_fill
                            cell.font = self.black_font
                        elif 'BUY (LOW)' in value:
                            cell.fill = PatternFill(start_color="CCFFCC", end_color="CCFFCC", fill_type="solid")
                            cell.font = self.black_font
                        elif 'HOLD' in value:
                            cell.fill = PatternFill(start_color="FFFF99", end_color="FFFF99", fill_type="solid")
                            cell.font = self.black_font
                        elif 'SELL' in value:
                            cell.fill = self.light_red_fill
                            cell.font = self.black_font
                        elif 'AVOID' in value:
                            cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                            cell.font = self.black_font
                        
                        cell.alignment = Alignment(horizontal="center")
                        cell.border = self.border
                
                # Format index_trend column (V3)
                idx_trend_col = col_mapping.get('index_trend')
                if idx_trend_col:
                    idx_trend_cell = ws[f"{idx_trend_col}{row_idx}"]
                    idx_trend_value = idx_trend_cell.value
                    
                    if idx_trend_value:
                        if "rising" in str(idx_trend_value).lower():
                            idx_trend_cell.fill = self.light_green_fill
                            idx_trend_cell.font = self.black_font
                        elif "falling" in str(idx_trend_value).lower():
                            idx_trend_cell.fill = self.light_red_fill
                            idx_trend_cell.font = self.black_font
                        elif "flat" in str(idx_trend_value).lower():
                            idx_trend_cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    
                    idx_trend_cell.alignment = Alignment(horizontal="center")
                    idx_trend_cell.border = self.border
                
                # Format market_type column (V3)
                mkt_type_col = col_mapping.get('market_type')
                if mkt_type_col:
                    mkt_type_cell = ws[f"{mkt_type_col}{row_idx}"]
                    mkt_type_value = mkt_type_cell.value
                    
                    if mkt_type_value:
                        if "Broad Rally" in str(mkt_type_value):
                            # Best signal - Dark green
                            mkt_type_cell.fill = PatternFill(start_color="006400", end_color="006400", fill_type="solid")
                            mkt_type_cell.font = self.white_font
                        elif "Recovery" in str(mkt_type_value):
                            # Good signal - Green
                            mkt_type_cell.fill = self.green_fill
                        elif "Narrow Rally" in str(mkt_type_value):
                            # Fragile - Yellow
                            mkt_type_cell.fill = self.yellow_fill
                        elif "Divergence" in str(mkt_type_value):
                            # Warning - Orange
                            mkt_type_cell.fill = self.orange_fill
                        elif "Broad Decline" in str(mkt_type_value):
                            # Avoid - Red
                            mkt_type_cell.fill = self.red_fill
                            mkt_type_cell.font = self.white_font
                        elif "Consolidation" in str(mkt_type_value):
                            # Neutral - Gray
                            mkt_type_cell.fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
                    
                    mkt_type_cell.alignment = Alignment(horizontal="center")
                    mkt_type_cell.border = self.border
                
                # Format divergence_warning column (V3)
                div_col = col_mapping.get('divergence_warning')
                if div_col:
                    div_cell = ws[f"{div_col}{row_idx}"]
                    div_value = div_cell.value
                    
                    if div_value and "YES" in str(div_value).upper():
                        # Red highlight for divergence warning
                        div_cell.fill = self.red_fill
                        div_cell.font = self.white_font
                    
                    div_cell.alignment = Alignment(horizontal="center")
                    div_cell.border = self.border
                
                # Apply borders to all cells in row
                for col_idx in range(1, ws.max_column + 1):
                    cell = ws[f"{get_column_letter(col_idx)}{row_idx}"]
                    cell.border = self.border
                
            except Exception as e:
                logger.warning(f"Error formatting row {row_idx}: {e}")
    
    def _get_em_formatting(self, em_value: float) -> tuple:
        """Get fill and font for EM value"""
        if em_value < 10:
            return self.black_fill, self.white_font
        elif em_value < 12:
            return self.red_fill, self.white_font
        elif em_value < 15:
            return self.orange_fill, self.black_font
        elif em_value < 18:
            return self.yellow_fill, self.black_font
        elif em_value < 25:
            return self.green_fill, self.black_font
        else:
            return self.blue_fill, self.black_font
    
    def _get_column_mapping(self, ws) -> dict:
        """Map column names to letters"""
        mapping = {}
        for col_idx in range(1, ws.max_column + 1):
            col_letter = get_column_letter(col_idx)
            header_value = ws[f"{col_letter}1"].value
            if header_value:
                mapping[header_value] = col_letter
        return mapping
    
    def _adjust_column_widths(self, ws):
        """Auto-adjust column widths"""
        for col_idx in range(1, ws.max_column + 1):
            col_letter = get_column_letter(col_idx)
            
            # Get max width in column
            max_width = 10
            for row_idx in range(1, min(ws.max_row + 1, 100)):  # Check first 100 rows
                cell = ws[f"{col_letter}{row_idx}"]
                if cell.value:
                    cell_width = len(str(cell.value))
                    max_width = max(max_width, cell_width)
            
            # Set width (with some padding)
            ws.column_dimensions[col_letter].width = min(max_width + 2, 30)


# ==============================================================================
# Testing / Example Usage
# ==============================================================================

if __name__ == "__main__":
    import pandas as pd
    from datetime import datetime, timedelta
    
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    print(f"\n{'='*80}")
    print(f"EXCEL FORMATTER TEST")
    print(f"{'='*80}\n")
    
    # Create sample data
    dates = [(datetime.now() - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(10, 0, -1)]
    sample_data = {
        'date': dates,
        '4.5r': [150, 250, 450, 30, 180, 300, 400, 60, 220, 350],
        '4.5r_chng': [10, -20, 50, -30, 15, -5, 25, -40, 12, 18],
        '20sma': [45, 52, 60, 25, 48, 55, 68, 20, 50, 62],
        '20sma_chng': [5, -3, 8, -10, 4, -2, 7, -12, 6, 9],
        '50sma': [48, 55, 62, 28, 50, 58, 70, 22, 52, 65],
        '50sma_chng': [4, -2, 7, -9, 3, -1, 6, -10, 5, 8],
        '52WH': [15, 20, 35, 5, 18, 25, 40, 3, 22, 38],
        '52WL': [25, 18, 10, 45, 22, 15, 8, 50, 16, 12],
        'EM': [8.5, 11.2, 14.8, 9.1, 16.5, 19.8, 22.5, 7.8, 17.2, 21.0],
        'EM_chng': [0.5, -1.2, 2.5, -3.0, 1.8, -0.5, 2.2, -4.1, 1.5, 2.8],
        'regime': ['Bear Control', 'Bear Control', 'Repair Zone', 'Bear Control', 
                   'Early Momentum', 'Healthy Bullish', 'Healthy Bullish', 'Bear Control',
                   'Early Momentum', 'Healthy Bullish'],
        'trading_action': ['Cash', 'Cash', 'Observe', 'Cash', 'Selective', 
                          'Full Exposure', 'Full Exposure', 'Cash', 'Selective', 'Full Exposure']
    }
    
    df = pd.DataFrame(sample_data)
    
    # Save to Excel
    test_file = "test_mbi_em_formatting.xlsx"
    df.to_excel(test_file, index=False, engine='openpyxl')
    print(f"Created test file: {test_file}")
    
    # Apply formatting
    formatter = ExcelFormatter()
    formatted_file = formatter.format_workbook(test_file, "test_mbi_em_formatted.xlsx")
    
    print(f"\n✅ Formatted file created: {formatted_file}")
    print("\nOpen the file to see:")
    print("  - EM column colored by regime (black/red/orange/yellow/green/blue)")
    print("  - Change columns in green (positive) / red (negative)")
    print("  - 4.5R highlighted for extreme values")
    print("  - SMA breadth highlighted when low")
    print("  - Regime column color-coded")

