"""
Crash Pattern Analyzer - Statistical Validation
================================================
Analyzes historical data to validate crash warning patterns.

Usage:
    python crash_pattern_analyzer.py

Reads: MBI_EM_Backtest_Results/backtest_results.xlsx
Outputs: Statistical analysis of crash patterns
"""

import pandas as pd
import numpy as np
from datetime import timedelta

print("\n" + "="*80)
print("CRASH PATTERN ANALYZER - Statistical Validation")
print("="*80 + "\n")

# Load data
excel_file = "../../../MBI_EM_Backtest_Results/backtest_results.xlsx"
print(f"Loading: {excel_file}\n")

df = pd.read_excel(excel_file)
df['date'] = pd.to_datetime(df['date'])

print(f"Loaded {len(df)} trading days")
print(f"Date range: {df['date'].min().strftime('%Y-%m-%d')} to {df['date'].max().strftime('%Y-%m-%d')}\n")

# =============================================================================
# 1. FIND ALL CRASH EVENTS
# =============================================================================

print("="*80)
print("1. CRASH EVENT IDENTIFICATION")
print("="*80 + "\n")

# Define crash as EM_chng_3d < -10
crashes = df[df['EM_chng_3d'] <= -10].copy()

print(f"Total crash events (EM_chng_3d <= -10): {len(crashes)}\n")

if len(crashes) > 0:
    print("Crash Dates and Magnitude:")
    print("-" * 60)
    for idx, row in crashes.iterrows():
        print(f"{row['date'].strftime('%Y-%m-%d')}: EM {row['EM']:.1f}%, "
              f"EM_chng_3d = {row['EM_chng_3d']:.1f}%, "
              f"Trend: {row['em_trend']}")
    print()

# =============================================================================
# 2. EM EXHAUSTION PATTERN (EM > 65%)
# =============================================================================

print("="*80)
print("2. EM EXHAUSTION PATTERN VALIDATION (EM > 65%)")
print("="*80 + "\n")

# Find all instances where EM > 65%
exhaustion_events = df[df['EM'] > 65].copy()
print(f"Total times EM exceeded 65%: {len(exhaustion_events)}\n")

if len(exhaustion_events) > 0:
    # Check how many led to crashes within next 5 days
    crash_after_exhaustion = 0
    
    for idx in exhaustion_events.index:
        date = df.loc[idx, 'date']
        # Look ahead 5 days
        future_mask = (df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=5))
        future_data = df[future_mask]
        
        # Check if any crash in next 5 days
        if len(future_data) > 0 and (future_data['EM_chng_3d'] <= -10).any():
            crash_after_exhaustion += 1
    
    reliability = (crash_after_exhaustion / len(exhaustion_events)) * 100 if len(exhaustion_events) > 0 else 0
    
    print(f"EM >65% events: {len(exhaustion_events)}")
    print(f"Led to crash within 5 days: {crash_after_exhaustion}")
    print(f"Reliability: {reliability:.1f}%\n")
    
    if reliability >= 50:
        print(f"[RECOMMEND] EM >65% is a reliable warning (>50% accuracy)")
        print(f"            Implement: Signal SELL when EM >65%")
    else:
        print(f"[SKIP] EM >65% is not reliable enough (<50% accuracy)")
    print()

# =============================================================================
# 3. PEAK ROLLOVER PATTERN (2 Days Declining from Peak)
# =============================================================================

print("="*80)
print("3. PEAK ROLLOVER PATTERN VALIDATION")
print("="*80 + "\n")

# Find local EM peaks and check if 2-day decline leads to crash
peak_rollovers = 0
rollover_crashes = 0

for i in range(2, len(df) - 5):
    # Check if this is a local peak (higher than previous and next day)
    if (df.loc[i, 'EM'] > df.loc[i-1, 'EM'] and 
        df.loc[i, 'EM'] > df.loc[i+1, 'EM'] and
        df.loc[i, 'EM'] > 60):  # Only check significant peaks
        
        # Check if next 2 days are declining
        day1_decline = df.loc[i+1, 'EM'] < df.loc[i, 'EM']
        day2_decline = df.loc[i+2, 'EM'] < df.loc[i+1, 'EM']
        
        if day1_decline and day2_decline:
            peak_rollovers += 1
            peak_date = df.loc[i, 'date']
            
            # Check if crash occurs in next 5 days
            future_mask = (df['date'] > peak_date) & (df['date'] <= peak_date + pd.Timedelta(days=7))
            future_data = df[future_mask]
            
            if len(future_data) > 0 and (future_data['EM_chng_3d'] <= -10).any():
                rollover_crashes += 1
                print(f"CRASH: {peak_date.strftime('%Y-%m-%d')} EM {df.loc[i, 'EM']:.1f}% -> "
                      f"{df.loc[i+1, 'EM']:.1f}% -> {df.loc[i+2, 'EM']:.1f}% (rollover)")

reliability_rollover = (rollover_crashes / peak_rollovers * 100) if peak_rollovers > 0 else 0

print(f"\nPeak rollover events (EM >60% then 2 days declining): {peak_rollovers}")
print(f"Led to crash within 7 days: {rollover_crashes}")
print(f"Reliability: {reliability_rollover:.1f}%\n")

if reliability_rollover >= 60:
    print(f"[RECOMMEND] Peak rollover is highly reliable (>60%)")
    print(f"            Implement: Exit when EM peaks and declines 2 consecutive days")
else:
    print(f"[SKIP] Peak rollover reliability too low")
print()

# =============================================================================
# 4. PARABOLIC MOVE PATTERN (>20% in 5 days)
# =============================================================================

print("="*80)
print("4. PARABOLIC MOVE PATTERN VALIDATION (EM +20% in 5d)")
print("="*80 + "\n")

parabolic_events = df[df['EM_chng_5d'] > 20].copy()
print(f"Parabolic move events (EM_chng_5d > 20%): {len(parabolic_events)}\n")

if len(parabolic_events) > 0:
    parabolic_crashes = 0
    
    for idx in parabolic_events.index:
        date = df.loc[idx, 'date']
        # Look ahead 7 days
        future_mask = (df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=7))
        future_data = df[future_mask]
        
        if len(future_data) > 0 and (future_data['EM_chng_3d'] <= -10).any():
            parabolic_crashes += 1
            print(f"CRASH after parabolic: {date.strftime('%Y-%m-%d')} "
                  f"EM_chng_5d = +{df.loc[idx, 'EM_chng_5d']:.1f}%")
    
    reliability_para = (parabolic_crashes / len(parabolic_events) * 100) if len(parabolic_events) > 0 else 0
    
    print(f"\nParabolic events: {len(parabolic_events)}")
    print(f"Led to crash within 7 days: {parabolic_crashes}")
    print(f"Reliability: {reliability_para:.1f}%\n")
    
    if reliability_para >= 50:
        print(f"[RECOMMEND] Parabolic moves are concerning (>50%)")
        print(f"            Implement: Warning when EM_chng_5d > 20%")
    else:
        print(f"[SKIP] Parabolic moves can sustain")
    print()

# =============================================================================
# 5. TIMEFRAME SIGNAL QUALITY (10-21 Day Focus)
# =============================================================================

print("="*80)
print("5. TIMEFRAME SIGNAL QUALITY (10-21 DAY FOCUS)")
print("="*80 + "\n")

if 'signal_10_21d' in df.columns and 'fwd_return_10d' in df.columns:
    # BUY signals
    buy_high = df[df['signal_10_21d'].str.contains('BUY \\(HIGH\\)', na=False)]
    buy_med = df[df['signal_10_21d'].str.contains('BUY \\(MEDIUM\\)', na=False)]
    sell_high = df[df['signal_10_21d'].str.contains('SELL \\(HIGH\\)', na=False)]
    sell_med = df[df['signal_10_21d'].str.contains('SELL \\(MEDIUM\\)', na=False)]
    
    print("10-21 Day Signal Performance:\n")
    
    if len(buy_high) > 0:
        avg_ret = buy_high['fwd_return_10d'].mean()
        win_rate = (buy_high['fwd_return_10d'] > 0).sum() / len(buy_high) * 100
        print(f"BUY (HIGH):   {len(buy_high):3d} signals, {avg_ret:+.2f}% avg, {win_rate:.0f}% win rate")
    
    if len(buy_med) > 0:
        avg_ret = buy_med['fwd_return_10d'].mean()
        win_rate = (buy_med['fwd_return_10d'] > 0).sum() / len(buy_med) * 100
        print(f"BUY (MEDIUM): {len(buy_med):3d} signals, {avg_ret:+.2f}% avg, {win_rate:.0f}% win rate")
    
    if len(sell_high) > 0:
        avg_ret = sell_high['fwd_return_10d'].mean()
        win_rate = (sell_high['fwd_return_10d'] > 0).sum() / len(sell_high) * 100
        print(f"SELL (HIGH):  {len(sell_high):3d} signals, {avg_ret:+.2f}% avg, {win_rate:.0f}% win rate")
        print(f"              (Should be negative if sell signals are good)\n")
    
    if len(sell_med) > 0:
        avg_ret = sell_med['fwd_return_10d'].mean()
        print(f"SELL (MEDIUM): {len(sell_med):3d} signals, {avg_ret:+.2f}% avg")
    
    print()
else:
    print("  [!] Timeframe signal columns not found in backtest\n")

# =============================================================================
# 6. PRE-CRASH CONDITIONS (5 Days Before Each Crash)
# =============================================================================

print("="*80)
print("6. COMMON CONDITIONS 5 DAYS BEFORE CRASHES")
print("="*80 + "\n")

if len(crashes) > 0:
    pre_crash_stats = {
        'EM_above_65': 0,
        'EM_above_60': 0,
        'EM_declining': 0,
        'divergence_warning': 0,
        'broad_rally': 0
    }
    
    print("Analyzing 5 days before each crash...\n")
    
    for crash_idx in crashes.index:
        crash_date = df.loc[crash_idx, 'date']
        
        # Get 5 days before crash
        pre_crash_mask = ((df['date'] < crash_date) & 
                         (df['date'] >= crash_date - pd.Timedelta(days=7)))
        pre_crash_data = df[pre_crash_mask]
        
        if len(pre_crash_data) > 0:
            # Check conditions
            if (pre_crash_data['EM'] > 65).any():
                pre_crash_stats['EM_above_65'] += 1
            if (pre_crash_data['EM'] > 60).any():
                pre_crash_stats['EM_above_60'] += 1
            if (pre_crash_data['em_trend'] == 'declining').any():
                pre_crash_stats['EM_declining'] += 1
            if (pre_crash_data['divergence_warning'].astype(str).str.upper().isin(['YES', 'TRUE'])).any():
                pre_crash_stats['divergence_warning'] += 1
            if (pre_crash_data['market_type'] == 'Broad Rally').any():
                pre_crash_stats['broad_rally'] += 1
    
    total_crashes = len(crashes)
    print("Common Conditions in 5 Days Before Crash:\n")
    print(f"EM was above 65%:         {pre_crash_stats['EM_above_65']:2d} / {total_crashes} ({pre_crash_stats['EM_above_65']/total_crashes*100:.0f}%)")
    print(f"EM was above 60%:         {pre_crash_stats['EM_above_60']:2d} / {total_crashes} ({pre_crash_stats['EM_above_60']/total_crashes*100:.0f}%)")
    print(f"EM was declining:         {pre_crash_stats['EM_declining']:2d} / {total_crashes} ({pre_crash_stats['EM_declining']/total_crashes*100:.0f}%)")
    print(f"Divergence warning:       {pre_crash_stats['divergence_warning']:2d} / {total_crashes} ({pre_crash_stats['divergence_warning']/total_crashes*100:.0f}%)")
    print(f"Was in Broad Rally:       {pre_crash_stats['broad_rally']:2d} / {total_crashes} ({pre_crash_stats['broad_rally']/total_crashes*100:.0f}%)")
    print()

# =============================================================================
# 7. FALSE POSITIVE ANALYSIS
# =============================================================================

print("="*80)
print("7. FALSE POSITIVE RATES")
print("="*80 + "\n")

# EM > 65% false positive rate
em_65_events = df[df['EM'] > 65].copy()
em_65_no_crash = 0

if len(em_65_events) > 0:
    for idx in em_65_events.index:
        date = df.loc[idx, 'date']
        future_mask = (df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=5))
        future_data = df[future_mask]
        
        if len(future_data) > 0 and not (future_data['EM_chng_3d'] <= -10).any():
            em_65_no_crash += 1
    
    fp_rate_65 = (em_65_no_crash / len(em_65_events) * 100) if len(em_65_events) > 0 else 0
    
    print(f"EM >65% Analysis:")
    print(f"  Total occurrences: {len(em_65_events)}")
    print(f"  Did NOT crash in 5 days: {em_65_no_crash}")
    print(f"  False positive rate: {fp_rate_65:.1f}%")
    
    if fp_rate_65 < 30:
        print(f"  [EXCELLENT] Low false positives - reliable signal!")
    elif fp_rate_65 < 50:
        print(f"  [GOOD] Acceptable false positive rate")
    else:
        print(f"  [CAUTION] High false positives - signal too noisy")
    print()

# =============================================================================
# 8. SIGNAL RECOMMENDATIONS
# =============================================================================

print("="*80)
print("8. RECOMMENDATIONS BASED ON DATA")
print("="*80 + "\n")

recommendations = []

# EM Exhaustion
if 'reliability' in locals() and reliability >= 50:
    recommendations.append(
        f"1. EM EXHAUSTION (>65%): IMPLEMENT\n"
        f"   Reliability: {reliability:.1f}%\n"
        f"   Action: Signal SELL for all timeframes when EM >65%"
    )
elif 'reliability' in locals():
    recommendations.append(
        f"1. EM EXHAUSTION (>65%): SKIP\n"
        f"   Reliability: {reliability:.1f}% (too low)"
    )

# Peak Rollover
if 'reliability_rollover' in locals() and reliability_rollover >= 60:
    recommendations.append(
        f"2. PEAK ROLLOVER: IMPLEMENT\n"
        f"   Reliability: {reliability_rollover:.1f}%\n"
        f"   Action: Exit when EM peaks and declines 2 consecutive days"
    )
elif 'reliability_rollover' in locals():
    recommendations.append(
        f"2. PEAK ROLLOVER: CAUTION\n"
        f"   Reliability: {reliability_rollover:.1f}% (moderate)"
    )

# Parabolic Moves
if 'reliability_para' in locals() and reliability_para >= 50:
    recommendations.append(
        f"3. PARABOLIC MOVES (>20% in 5d): IMPLEMENT WARNING\n"
        f"   Reliability: {reliability_para:.1f}%\n"
        f"   Action: Reduce position by 30-50% when detected"
    )

# Print recommendations
if recommendations:
    for rec in recommendations:
        print(rec)
        print()
else:
    print("Need more data or check data quality")

print("="*80)
print("ANALYSIS COMPLETE")
print("="*80)
print()
print("Next step: Based on recommendations above, implement high-reliability fixes")
print()

