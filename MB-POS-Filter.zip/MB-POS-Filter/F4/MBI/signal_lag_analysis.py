"""
Signal Lag Analysis
===================
Compares our trading signals with actual index movement to detect lag.
"""

import pandas as pd
import numpy as np

print("\n" + "="*80)
print("SIGNAL LAG ANALYSIS - August to October 2025")
print("="*80 + "\n")

# Load our dashboard data
df = pd.read_excel("../../../mbi_em_dashboard_20251105_150843.xlsx")
df['date'] = pd.to_datetime(df['date'])

# Focus on Aug-Oct 2025
analysis_period = df[(df['date'] >= '2025-08-01') & (df['date'] <= '2025-10-31')].copy()

print(f"Analyzing {len(analysis_period)} days (Aug 1 - Oct 31, 2025)\n")

# =============================================================================
# 1. INDEX TURNING POINTS VS OUR SIGNALS
# =============================================================================

print("="*80)
print("1. INDEX TURNING POINTS VS OUR SIGNALS")
print("="*80 + "\n")

print("August 2025 Analysis:")
print("-" * 80)

aug_data = analysis_period[analysis_period['date'].dt.month == 8].copy()

for idx, row in aug_data.iterrows():
    date_str = row['date'].strftime('%b %d')
    index_close = row.get('index_close', 0)
    index_trend = row.get('index_trend', 'unknown')
    signal_10_21 = row.get('signal_10_21d', 'N/A')[:20]
    pos_size = row.get('position_size', 'N/A')
    
    print(f"{date_str}: Index {index_close:7.1f} ({index_trend:7s}) "
          f"EM {row['EM']:5.1f}% {row['em_trend']:10s} "
          f"{signal_10_21:20s} Pos: {pos_size}")

print("\n" + "="*80)
print()

print("September 2025 Analysis:")
print("-" * 80)

sep_data = analysis_period[analysis_period['date'].dt.month == 9].copy()

for idx, row in sep_data.iterrows():
    date_str = row['date'].strftime('%b %d')
    index_close = row.get('index_close', 0)
    index_trend = row.get('index_trend', 'unknown')
    signal_10_21 = row.get('signal_10_21d', 'N/A')[:20]
    pos_size = row.get('position_size', 'N/A')
    
    print(f"{date_str}: Index {index_close:7.1f} ({index_trend:7s}) "
          f"EM {row['EM']:5.1f}% {row['em_trend']:10s} "
          f"{signal_10_21:20s} Pos: {pos_size}")

print("\n" + "="*80)
print()

print("October 2025 Analysis:")
print("-" * 80)

oct_data = analysis_period[analysis_period['date'].dt.month == 10].copy()

for idx, row in oct_data.iterrows():
    date_str = row['date'].strftime('%b %d')
    index_close = row.get('index_close', 0)
    index_trend = row.get('index_trend', 'unknown')
    signal_10_21 = row.get('signal_10_21d', 'N/A')[:20]
    pos_size = row.get('position_size', 'N/A')
    
    print(f"{date_str}: Index {index_close:7.1f} ({index_trend:7s}) "
          f"EM {row['EM']:5.1f}% {row['em_trend']:10s} "
          f"{signal_10_21:20s} Pos: {pos_size}")

print("\n" + "="*80)
print()

# =============================================================================
# 2. LAG DETECTION
# =============================================================================

print("="*80)
print("2. LAG DETECTION - Index Turn vs Signal Turn")
print("="*80 + "\n")

# Find index trend changes
prev_trend = None
for idx, row in analysis_period.iterrows():
    curr_trend = row.get('index_trend', 'unknown')
    if prev_trend and curr_trend != prev_trend and curr_trend != 'flat':
        date = row['date'].strftime('%Y-%m-%d')
        signal = row.get('signal_10_21d', 'N/A')
        em_trend = row['em_trend']
        
        print(f"{date}: Index turned {curr_trend}")
        print(f"  Our signal: {signal}")
        print(f"  EM trend: {em_trend}")
        print(f"  Position: {row.get('position_size', 'N/A')}")
        print()
    
    prev_trend = curr_trend

# =============================================================================
# 3. ENTRY/EXIT TIMING ANALYSIS
# =============================================================================

print("="*80)
print("3. ENTRY/EXIT TIMING VS INDEX")
print("="*80 + "\n")

# Find our position changes
prev_pos = None
for idx, row in analysis_period.iterrows():
    curr_pos = row.get('position_size', 0)
    
    # Convert position to numeric if it's a string
    if isinstance(curr_pos, str):
        curr_pos = float(curr_pos.replace('%', '')) / 100
    
    # Detect position changes
    if prev_pos is not None and abs(curr_pos - prev_pos) > 0.1:
        date = row['date'].strftime('%Y-%m-%d')
        index_close = row.get('index_close', 0)
        index_trend = row.get('index_trend', 'unknown')
        
        if curr_pos > prev_pos:
            print(f"{date}: INCREASED position {prev_pos:.0%} -> {curr_pos:.0%}")
        else:
            print(f"{date}: DECREASED position {prev_pos:.0%} -> {curr_pos:.0%}")
        
        print(f"  Index: {index_close:.1f} ({index_trend})")
        print(f"  EM: {row['EM']:.1f}% ({row['em_trend']})")
        print(f"  Signal: {row.get('signal_10_21d', 'N/A')}")
        print()
    
    prev_pos = curr_pos

print("="*80)
print("SUMMARY")
print("="*80 + "\n")

print("Check above:")
print("  - Do our position changes happen AFTER index trend changes?")
print("  - How many days lag between index turn and our signal?")
print("  - Are we entering too late? Exiting too late?")
print()

