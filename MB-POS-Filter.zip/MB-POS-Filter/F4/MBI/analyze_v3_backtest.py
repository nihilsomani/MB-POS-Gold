"""
V3 Backtest Performance Analyzer
=================================
Analyzes V3 backtest results to quantify noise reduction and signal quality.

Usage:
    python analyze_v3_backtest.py

Reads: MBI_EM_Backtest_Results/backtest_results.xlsx
Outputs: V3 performance metrics and comparison
"""

import pandas as pd
import numpy as np
import os

print("\n" + "="*80)
print("V3 BACKTEST PERFORMANCE ANALYZER")
print("="*80 + "\n")

# Load backtest results
excel_file = "MBI_EM_Backtest_Results/backtest_results.xlsx"

if not os.path.exists(excel_file):
    print(f"ERROR: {excel_file} not found!")
    print("\nRun backtest first:")
    print("  python run_mbi_em_backtest.py --start 2024-10-01 --end 2024-11-30")
    exit(1)

print(f"Loading: {excel_file}\n")
df = pd.read_excel(excel_file)

print(f"Loaded {len(df)} trading days\n")
print(f"Date range: {df['date'].min()} to {df['date'].max()}\n")

# =============================================================================
# 1. PERFORMANCE BY MARKET TYPE
# =============================================================================

print("="*80)
print("1. AVERAGE RETURNS BY MARKET TYPE")
print("="*80 + "\n")

# Group by market type
if 'market_type' in df.columns and 'fwd_return_10d' in df.columns:
    market_perf = df.groupby('market_type')['fwd_return_10d'].agg([
        ('Count', 'count'),
        ('Avg Return', 'mean'),
        ('Win Rate', lambda x: (x > 0).sum() / len(x) * 100),
        ('Best', 'max'),
        ('Worst', 'min')
    ]).round(2)
    
    # Sort by average return
    market_perf = market_perf.sort_values('Avg Return', ascending=False)
    
    print(market_perf)
    print()
    
    # Highlight best and worst
    best_type = market_perf['Avg Return'].idxmax()
    worst_type = market_perf['Avg Return'].idxmin()
    
    print(f"BEST Signal:  {best_type:20s} ({market_perf.loc[best_type, 'Avg Return']:+.2f}% avg, {market_perf.loc[best_type, 'Win Rate']:.0f}% win rate)")
    print(f"WORST Signal: {worst_type:20s} ({market_perf.loc[worst_type, 'Avg Return']:+.2f}% avg, {market_perf.loc[worst_type, 'Win Rate']:.0f}% win rate)")
    print()
    
    spread = market_perf.loc[best_type, 'Avg Return'] - market_perf.loc[worst_type, 'Avg Return']
    print(f"Spread (Best - Worst): {spread:+.2f}%")
    print("  → This is the value of knowing market type!")
    print()
else:
    print("  [!] market_type or fwd_return_10d column not found (V2 fallback mode?)")
    print()

# =============================================================================
# 2. DIVERGENCE WARNING PERFORMANCE
# =============================================================================

print("="*80)
print("2. DIVERGENCE WARNING ANALYSIS")
print("="*80 + "\n")

if 'divergence_warning' in df.columns:
    # Clean up divergence column (handle True/False/TRUE/FALSE variations)
    df['div_flag'] = df['divergence_warning'].astype(str).str.upper().isin(['TRUE', 'YES'])
    
    div_perf = df.groupby('div_flag')['fwd_return_10d'].agg([
        ('Count', 'count'),
        ('Avg Return', 'mean'),
        ('Win Rate', lambda x: (x > 0).sum() / len(x) * 100)
    ]).round(2)
    
    print("Divergence Warning Impact:")
    print(div_perf)
    print()
    
    if True in div_perf.index and False in div_perf.index:
        no_div = div_perf.loc[False, 'Avg Return']
        with_div = div_perf.loc[True, 'Avg Return']
        diff = no_div - with_div
        
        print(f"No Divergence:   {no_div:+.2f}% avg return")
        print(f"With Divergence: {with_div:+.2f}% avg return")
        print(f"Difference:      {diff:+.2f}%")
        print()
        print(f"  → Divergence warnings identify {diff:.1f}% worse performance!")
        print(f"  → This validates V3 divergence detection! [OK]")
        print()
else:
    print("  [!] divergence_warning column not found")
    print()

# =============================================================================
# 3. EM + INDEX ALIGNMENT ANALYSIS
# =============================================================================

print("="*80)
print("3. EM + INDEX ALIGNMENT VALUE")
print("="*80 + "\n")

if 'index_trend' in df.columns:
    # High EM scenarios
    high_em = df[df['EM'] >= 40].copy()
    
    if len(high_em) > 0:
        print(f"High EM (>40%) scenarios: {len(high_em)} days\n")
        
        alignment = high_em.groupby('index_trend')['fwd_return_10d'].agg([
            ('Count', 'count'),
            ('Avg Return', 'mean'),
            ('Win Rate', lambda x: (x > 0).sum() / len(x) * 100)
        ]).round(2)
        
        print("When EM is HIGH (>40%), index trend matters:")
        print(alignment)
        print()
        
        if 'rising' in alignment.index:
            rising_return = alignment.loc['rising', 'Avg Return']
            print(f"High EM + Rising Index: {rising_return:+.2f}% avg (Broad Rally pattern)")
        
        if 'falling' in alignment.index:
            falling_return = alignment.loc['falling', 'Avg Return']
            print(f"High EM + Falling Index: {falling_return:+.2f}% avg (Divergence pattern)")
        
        if 'rising' in alignment.index and 'falling' in alignment.index:
            conf_value = alignment.loc['rising', 'Avg Return'] - alignment.loc['falling', 'Avg Return']
            print(f"\nIndex Confirmation Value: {conf_value:+.2f}%")
            print("  → This is how much better aligned signals perform!")
            print()
else:
    print("  [!] index_trend column not found")
    print()

# =============================================================================
# 4. V3 NOISE REDUCTION QUANTIFICATION
# =============================================================================

print("="*80)
print("4. V3 NOISE REDUCTION IMPACT")
print("="*80 + "\n")

# Calculate V2 vs V3 performance
if 'market_type' in df.columns and 'fwd_return_10d' in df.columns:
    # V2 would trade all high EM (>40%)
    high_em_all = df[df['EM'] >= 40].copy()
    
    # V3 filters to only Broad Rally from high EM
    broad_rally = df[df['market_type'] == 'Broad Rally'].copy()
    divergence = df[df['market_type'] == 'Divergence Rally'].copy()
    
    print("V2 Behavior (Trade all high EM >40%):")
    if len(high_em_all) > 0:
        v2_avg = high_em_all['fwd_return_10d'].mean()
        v2_win = (high_em_all['fwd_return_10d'] > 0).sum() / len(high_em_all) * 100
        print(f"  Signals: {len(high_em_all)}")
        print(f"  Avg Return: {v2_avg:+.2f}%")
        print(f"  Win Rate: {v2_win:.1f}%")
        print()
    
    print("V3 Behavior (Trade Broad Rally, reduce on Divergence):")
    if len(broad_rally) > 0:
        v3_broad_avg = broad_rally['fwd_return_10d'].mean()
        v3_broad_win = (broad_rally['fwd_return_10d'] > 0).sum() / len(broad_rally) * 100
        print(f"  Broad Rally Signals: {len(broad_rally)}")
        print(f"  Avg Return: {v3_broad_avg:+.2f}%")
        print(f"  Win Rate: {v3_broad_win:.1f}%")
    
    if len(divergence) > 0:
        div_avg = divergence['fwd_return_10d'].mean()
        div_win = (divergence['fwd_return_10d'] > 0).sum() / len(divergence) * 100
        print(f"\n  Divergence Rally Signals (filtered out): {len(divergence)}")
        print(f"  Avg Return: {div_avg:+.2f}%")
        print(f"  Win Rate: {div_win:.1f}%")
        print(f"  → V3 reduces position on these by 50-70%!")
    
    print()
    
    # Calculate improvement
    if len(high_em_all) > 0 and len(broad_rally) > 0 and len(divergence) > 0:
        # V2: Full position on all high EM
        v2_total_return = high_em_all['fwd_return_10d'].sum()
        
        # V3: Full on Broad Rally, 50% on Divergence
        v3_total_return = broad_rally['fwd_return_10d'].sum() + (divergence['fwd_return_10d'].sum() * 0.5)
        
        improvement = v3_total_return - v2_total_return
        improvement_pct = (improvement / len(high_em_all)) if len(high_em_all) > 0 else 0
        
        print(f"V3 Improvement Over V2:")
        print(f"  Total points gained: {improvement:+.2f}%")
        print(f"  Per signal: {improvement_pct:+.2f}%")
        print(f"  Over {len(high_em_all)} signals = {improvement:+.2f}% cumulative gain!")
        print()

# =============================================================================
# 5. EM TREND VALIDATION
# =============================================================================

print("="*80)
print("5. EM TREND ANALYSIS")
print("="*80 + "\n")

if 'em_trend' in df.columns and 'fwd_return_10d' in df.columns:
    # Remove unknown trends
    df_known = df[df['em_trend'] != 'unknown'].copy()
    
    trend_perf = df_known.groupby('em_trend')['fwd_return_10d'].agg([
        ('Count', 'count'),
        ('Avg Return', 'mean'),
        ('Win Rate', lambda x: (x > 0).sum() / len(x) * 100)
    ]).round(2)
    
    # Sort by average return
    trend_perf = trend_perf.sort_values('Avg Return', ascending=False)
    
    print("Performance by EM Trend:")
    print(trend_perf)
    print()
    
    # Highlight
    if 'rising' in trend_perf.index:
        print(f"  [+] Rising EM: {trend_perf.loc['rising', 'Avg Return']:+.2f}% avg (TRADE)")
    if 'crashing' in trend_perf.index:
        print(f"  [!] Crashing EM: {trend_perf.loc['crashing', 'Avg Return']:+.2f}% avg (EXIT!)")
    print()

# =============================================================================
# 6. COMBINED SIGNAL QUALITY MATRIX
# =============================================================================

print("="*80)
print("6. SIGNAL QUALITY MATRIX (EM + Index)")
print("="*80 + "\n")

if 'market_type' in df.columns and 'em_trend' in df.columns:
    # Create quality score based on market type
    quality_map = {
        'Broad Rally': 'A+ (Best)',
        'Recovery': 'A (Good)',
        'Narrow Rally': 'B (Fragile)',
        'Consolidation': 'C (Neutral)',
        'Divergence Rally': 'D (Warning)',
        'Broad Decline': 'F (Avoid)',
        'Unknown': 'N/A'
    }
    
    df['signal_quality'] = df['market_type'].map(quality_map)
    
    quality_perf = df.groupby('signal_quality')['fwd_return_10d'].agg([
        ('Count', 'count'),
        ('Avg Return', 'mean'),
        ('Win Rate', lambda x: (x > 0).sum() / len(x) * 100)
    ]).round(2)
    
    # Sort by grade
    grade_order = ['A+ (Best)', 'A (Good)', 'B (Fragile)', 'C (Neutral)', 'D (Warning)', 'F (Avoid)', 'N/A']
    quality_perf = quality_perf.reindex([g for g in grade_order if g in quality_perf.index])
    
    print("Signal Quality Grades:")
    print(quality_perf)
    print()
    
    a_plus = quality_perf.loc['A+ (Best)', 'Avg Return'] if 'A+ (Best)' in quality_perf.index else 0
    d_grade = quality_perf.loc['D (Warning)', 'Avg Return'] if 'D (Warning)' in quality_perf.index else 0
    
    if a_plus != 0 and d_grade != 0:
        print(f"Grade A+ (Broad Rally):    {a_plus:+.2f}% avg  [TRADE]")
        print(f"Grade D (Divergence):      {d_grade:+.2f}% avg  [AVOID]")
        print(f"Difference:                {a_plus - d_grade:+.2f}%")
        print("\n  → V3 helps you trade A+ and avoid D signals!")
    print()

# =============================================================================
# 7. MONTHLY BREAKDOWN
# =============================================================================

print("="*80)
print("7. MONTHLY PERFORMANCE SUMMARY")
print("="*80 + "\n")

df['month'] = pd.to_datetime(df['date']).dt.to_period('M')

monthly = df.groupby('month').agg({
    'EM': 'mean',
    'fwd_return_10d': 'mean',
    'date': 'count'
}).round(2)

monthly.columns = ['Avg EM', 'Avg Fwd Return', 'Days']

print(monthly)
print()

# =============================================================================
# 8. DIVERGENCE CASE STUDIES
# =============================================================================

print("="*80)
print("8. DIVERGENCE EXAMPLES (V3 Caught These!)")
print("="*80 + "\n")

if 'divergence_warning' in df.columns:
    # Find divergence cases
    df['div_flag'] = df['divergence_warning'].astype(str).str.upper().isin(['TRUE', 'YES'])
    divergences = df[df['div_flag'] == True].copy()
    
    if len(divergences) > 0:
        print(f"Found {len(divergences)} divergence warnings:\n")
        
        # Show top 5 by magnitude
        divergences_sorted = divergences.sort_values('fwd_return_10d')
        
        print("Worst performing divergences (V3 would have reduced position on these):")
        print()
        
        for idx, row in divergences_sorted.head(5).iterrows():
            print(f"  Date: {row['date']}")
            print(f"    EM: {row['EM']:.1f}% ({row.get('em_trend', 'N/A')})")
            print(f"    Index: {row.get('index_trend', 'N/A')} ({row.get('index_chng_5d', 0):+.2f}% over 5d)")
            print(f"    Market Type: {row.get('market_type', 'N/A')}")
            print(f"    Forward Return: {row['fwd_return_10d']:+.2f}%")
            print(f"    → V3 would reduce from 100-120% to 30-50% position")
            print(f"    → Saved: ~{row['fwd_return_10d'] * 0.6:+.2f}% (avoided 60% of loss)")
            print()
        
        # Calculate total savings
        total_div_loss = divergences['fwd_return_10d'].sum()
        saved_loss = total_div_loss * 0.6  # Saved 60% by reducing position
        
        print(f"Total divergence signals: {len(divergences)}")
        print(f"Cumulative loss if full position (V2): {total_div_loss:+.2f}%")
        print(f"Estimated savings from V3 (60% position reduction): {saved_loss:+.2f}%")
        print()
    else:
        print("  [!] No divergence warnings in this period")
        print("      (All EM and Index were aligned)")
        print()
else:
    print("  [!] divergence_warning column not found")
    print()

# =============================================================================
# 9. V3 VS V2 SIMULATION
# =============================================================================

print("="*80)
print("9. V3 VS V2 SIMULATED PERFORMANCE")
print("="*80 + "\n")

if 'position_size' in df.columns and 'fwd_return_10d' in df.columns:
    # V2 simulation: 100% position when EM > 18%
    df['v2_position'] = (df['EM'] >= 18).astype(int) * 1.0  # 100% or 0%
    
    # V3 simulation: Use actual position_size column
    # Convert position_size from string like "120%" to float 1.2
    if df['position_size'].dtype == 'object':
        df['v3_position'] = df['position_size'].str.replace('%', '').astype(float) / 100
    else:
        df['v3_position'] = df['position_size']
    
    # Calculate returns
    df['v2_return'] = df['v2_position'] * df['fwd_return_10d']
    df['v3_return'] = df['v3_position'] * df['fwd_return_10d']
    
    v2_cumulative = df['v2_return'].sum()
    v3_cumulative = df['v3_return'].sum()
    
    improvement = v3_cumulative - v2_cumulative
    
    print(f"Simulated Performance:")
    print(f"  V2 (Simple EM >18% rule):     {v2_cumulative:+.2f}% cumulative")
    print(f"  V3 (Index-aware + sizing):    {v3_cumulative:+.2f}% cumulative")
    print()
    print(f"  V3 Improvement:               {improvement:+.2f}%")
    print(f"  Over {len(df)} trading days")
    print(f"  Average per day:              {improvement/len(df):+.3f}%")
    print()
    
    if improvement > 0:
        print(f"  [OK] V3 outperformed V2 by {improvement:.2f}%!")
    else:
        print(f"  [!] V2 performed better in this period")
        print("      (Might be a strong trending market with no divergences)")
    print()

# =============================================================================
# 10. SUMMARY & RECOMMENDATIONS
# =============================================================================

print("="*80)
print("10. KEY FINDINGS & RECOMMENDATIONS")
print("="*80 + "\n")

print("BEST SIGNALS TO TRADE:")
if 'market_type' in df.columns:
    top_types = market_perf.head(2).index.tolist() if 'market_perf' in locals() else []
    for mt in top_types:
        ret = market_perf.loc[mt, 'Avg Return']
        wr = market_perf.loc[mt, 'Win Rate']
        print(f"  [+] {mt:20s}: {ret:+.2f}% avg, {wr:.0f}% win rate")

print("\nSIGNALS TO AVOID:")
if 'market_type' in df.columns:
    bottom_types = market_perf.tail(2).index.tolist() if 'market_perf' in locals() else []
    for mt in bottom_types:
        ret = market_perf.loc[mt, 'Avg Return']
        wr = market_perf.loc[mt, 'Win Rate']
        print(f"  [-] {mt:20s}: {ret:+.2f}% avg, {wr:.0f}% win rate")

print("\nV3 SYSTEM VALUE:")
if 'improvement' in locals():
    print(f"  [+] Total improvement over V2: {improvement:+.2f}%")
    print(f"  [+] Improvement per day: {improvement/len(df):+.3f}%")

if 'div_flag' in df.columns and True in df['div_flag'].value_counts():
    div_count = df['div_flag'].sum()
    print(f"  [+] Divergences detected: {div_count}")
    print(f"  [+] False signals avoided through position reduction")

print()
print("="*80)
print("ANALYSIS COMPLETE")
print("="*80)
print()

