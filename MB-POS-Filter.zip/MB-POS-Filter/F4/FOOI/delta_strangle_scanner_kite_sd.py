#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Enhanced Delta Strangle Scanner with Advanced Greeks Calculations
===============================================================

This script implements two options strategies:
1. Equal-Delta Strangle: Finds CE/PE pairs with matching delta magnitudes
2. Supply/Demand Writing: Writes options at supply/demand zones with ATR buffers

Enhanced Features:
- Complete Greeks calculations (Delta, Gamma, Theta, Vega, Rho)
- Theta per day calculation for better time decay analysis
- Trading-day adjusted theta (weekend/holiday aware)
- Rho calculation for interest rate sensitivity
- Comprehensive Greeks output in CSV results
- Enhanced logging with Greeks values
- Fast Newton-Raphson IV calculation (~50% faster than bisection)
- Dynamic Delta Targeting based on DTE (Days to Expiry)
- Performance optimizations with Greeks caching and centralized calculations
- Calculation accuracy improvements with edge case protection
- Combined strangle-level metrics (Total Theta, Total Vega, Breakevens, ROM)
- Fixed theta scaling (no more double division by 365/252)
- Black-76 with futures pricing (dividend-adjusted, robust IV calculation)
- Mid-price support from market depth when available
- Robust IV calculation with guaranteed convergence

CRITICAL - Pricing Model Consistency (v2.0):
============================================
This version fixes the Black-76 vs Black-Scholes inconsistency:
- Black-76 Model: Uses FUTURES price (F) which already includes cost-of-carry
  * No dividend adjustment needed
  * Greeks calculated with futures as underlying
  * IV solved using futures price
- Black-Scholes Model: Uses EQUITY SPOT price (S) 
  * Requires dividend yield for forward price calculation
  * Greeks calculated with equity spot as underlying
  * IV solved using equity spot price

Configuration via ENABLE_BLACK76_FUTURES flag:
- True: All calculations use FUTURES price consistently
- False: All calculations use EQUITY SPOT price consistently
Never mix futures and equity spot in the same calculation!

Author: Enhanced with advanced options analytics
"""

import os
import math
import time
import glob
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict, Tuple

import pandas as pd
from kiteconnect import KiteConnect

# =================== CONFIG ===================
SYMBOLS = ["360ONE","ABB","APLAPOLLO","AUBANK","ADANIENSOL","ADANIENT","ADANIGREEN","ADANIPORTS","ATGL","ABCAPITAL","ABFRL","ALKEM","AMBER","AMBUJACEM","ANGELONE","APOLLOHOSP","ASHOKLEY","ASIANPAINT","ASTRAL","AUROPHARMA","DMART","AXISBANK","BSE","BAJAJ-AUTO","BAJFINANCE","BAJAJFINSV","BANDHANBNK","BANKBARODA","BANKINDIA","BDL","BEL","BHARATFORG","BHEL","BPCL","BHARTIARTL","BIOCON","BLUESTARCO","BOSCHLTD","BRITANNIA","CESC","CGPOWER","CANBK","CDSL","CHOLAFIN","CIPLA","COALINDIA","COFORGE","COLPAL","CAMS","CONCOR","CROMPTON","CUMMINSIND","CYIENT","DLF","DABUR","DALBHARAT","DELHIVERY","DIVISLAB","DIXON","DRREDDY","ETERNAL","EICHERMOT","EXIDEIND","NYKAA","FORTIS","GAIL","GMRAIRPORT","GLENMARK","GODREJCP","GODREJPROP","GRANULES","GRASIM","HCLTECH","HDFCAMC","HDFCBANK","HDFCLIFE","HFCL","HAVELLS","HEROMOTOCO","HINDALCO","HAL","HINDPETRO","HINDUNILVR","HINDZINC","HUDCO","ICICIBANK","ICICIGI","ICICIPRULI","IDFCFIRSTB","IIFL","IRB","ITC","INDIANB","IEX","IOC","IRCTC","IRFC","IREDA","IGL","INDUSTOWER","INDUSINDBK","NAUKRI","INFY","INOXWIND","INDIGO","JSWENERGY","JSWSTEEL","JSL","JINDALSTEL","JIOFIN","JUBLFOOD","KEI","KPITTECH","KALYANKJIL","KAYNES","KFINTECH","KOTAKBANK","LTF","LICHSGFIN","LTIM","LT","LAURUSLABS","LICI","LODHA","LUPIN","M&M","MANAPPURAM","MANKIND","MARICO","MARUTI","MFSL","MAXHEALTH","MAZDOCK","MPHASIS","MCX","MUTHOOTFIN","NBCC","NCC","NHPC","NMDC","NTPC","NATIONALUM","NESTLEIND","NUVAMA","OBEROIRLTY","ONGC","OIL","PAYTM","OFSS","POLICYBZR","PGEL","PIIND","PNBHOUSING","PAGEIND","PATANJALI","PERSISTENT","PETRONET","PIDILITIND","PPLPHARMA","POLYCAB","POONAWALLA","PFC","POWERGRID","PRESTIGE","PNB","RBLBANK","RECLTD","RVNL","RELIANCE","SBICARD","SBILIFE","SHREECEM","SJVN","SRF","MOTHERSON","SHRIRAMFIN","SIEMENS","SOLARINDS","SONACOMS","SBIN","SAIL","SUNPHARMA","SUPREMEIND","SUZLON","SYNGENE","TATACONSUM","TITAGARH","TVSMOTOR","TATACHEM","TCS","TATAELXSI","TATAMOTORS","TATAPOWER","TATASTEEL","TATATECH","TECHM","FEDERALBNK","INDHOTEL","PHOENIXLTD","TITAN","TORNTPHARM","TORNTPOWER","TRENT","TIINDIA","UNOMINDA","UPL","ULTRACEMCO","UNIONBANK","UNITDSPR","VBL","VEDL","VOLTAS","WIPRO","ZYDUSLIFE"]
#SYMBOLS = ["ZYDUSLIFE"]
EXPIRY = "2025-11-25"  # e.g., "2025-08-28"; if None → nearest expiry per symbol
RISK_FREE_RATE = 0.065
TARGET_ABS_DELTA = 0.20  # 0.2 delta strangle (5-6% OTM each side)
MIN_OI_LAKH = 0.2
SCAN_PAUSE_SEC = 0.5

# Supply/Demand writing config
ATR_LOOKBACK = 21
SWING_WINDOW = 11               # pivot window for swing high/low
ATR_BUFFER_MULT = 1.0          # strikes at least +/- this many ATR from zone
MAX_HISTORY_DAYS = 55         # days of candles to fetch for zones/ATR

# Enhanced zone validation config
MAX_ZONE_DISTANCE_ATR = 3.0    # maximum distance zones can be from current price (in ATR)
MIN_ZONE_SEPARATION_ATR = 1.0  # minimum separation between supply and demand zones (in ATR)

# Progressive relaxation config
# CRITICAL: Too much relaxation defeats supply/demand zone strategy!
# At level 4 (0.2 ATR buffer), you're essentially AT the zone (no protection)
# At 0.2x OI, you're accepting illiquid garbage
# Professional approach: If you can't find good strikes → SKIP the symbol
ENABLE_PROGRESSIVE_RELAXATION = True  # enable progressive barrier relaxation
MAX_RELAXATION_LEVELS = 2      # maximum relaxation attempts (0=strict, 1=one retry, 2=two retries)
RELAXATION_STEP = 0.15         # step size for ATR multiplier reduction (15% per level)
RELAXATION_OI_STEP = 0.20      # step size for OI requirement reduction (20% per level)
MIN_ATR_BUFFER_FACTOR = 0.70   # never go below 70% of intended ATR buffer (maintain zone protection)
MIN_OI_FACTOR = 0.60           # never go below 60% of minimum OI (maintain liquidity)

# Risk Zone Warning Configuration
RISK_ZONE_SPOT_PERCENT = 5.0   # Warning if strike is within X% of spot
RISK_ZONE_GAMMA_THRESHOLD = 0.01  # Warning if gamma > threshold (high curvature risk) - LEGACY: now uses dynamic threshold
RISK_ZONE_THETA_THRESHOLD = -0.05  # Warning if theta per day < threshold (high time decay)
RISK_ZONE_VEGA_THRESHOLD = 0.5     # Warning if vega > threshold (high volatility sensitivity)
SHOW_DETAILED_RISK_WARNINGS = True  # Set to True for debugging dynamic gamma threshold

# Dynamic Gamma Threshold Configuration
ENABLE_DYNAMIC_GAMMA_THRESHOLD = True  # Enable dynamic gamma threshold based on underlying price
DYNAMIC_GAMMA_SCALING_FACTOR = 100     # Factor for dynamic threshold: 1 / (factor * spot)
MIN_GAMMA_THRESHOLD = 0.0001           # Minimum threshold floor for very low-priced instruments
MAX_GAMMA_THRESHOLD = 0.05             # Maximum threshold ceiling for very high-priced instruments

# Dynamic threshold explanation:
# - Higher-priced instruments (e.g., NIFTY at 22,000) get tighter gamma controls
# - Lower-priced instruments (e.g., stocks at 100) get standard controls
# - Formula: threshold = 1 / (100 * spot_price) with bounds [0.005, 0.05]
# - Set ENABLE_DYNAMIC_GAMMA_THRESHOLD = False to use legacy fixed threshold

# Risk Profiling Configuration
# RISK_PROFILE modes:
#   - "DEFAULT": Buyer-style caution (fast decay considered risky)
#   - "SELLER":  Seller-aligned (slow decay is risky; fast decay may be a mild benefit)
RISK_PROFILE = "SELLER"

# Seller-aligned tuning knobs (used when RISK_PROFILE == "SELLER")
SELLER_SLOW_THETA_THRESHOLD = -0.02   # theta/day above this (less negative) => slow decay
SELLER_FAST_THETA_THRESHOLD = -0.10   # theta/day below this (more negative) => fast decay
RISK_PENALTY_SLOW_THETA = 1           # add to risk when decay is slow
RISK_BONUS_FAST_THETA = 1             # subtract from risk (capped at 1 bucket drop)

# Assignment/Liquidity risk via near-ATM delta band (seller-specific)
RISK_DELTA_ATM_LOWER = 0.35
RISK_DELTA_ATM_UPPER = 0.65
ASSIGNMENT_RISK_POINTS = 3            # High priority for assignment/liquidity risk

# Graduated Delta Scoring Configuration (NEW - replaces binary delta check)
ENABLE_GRADUATED_DELTA_SCORING = True  # Enable graduated delta risk scoring
GRADUATED_DELTA_PEAK_RANGE = (0.48, 0.52)    # Peak risk: 0.48 <= |delta| <= 0.52
GRADUATED_DELTA_HIGH_RANGE = (0.45, 0.55)    # High risk: 0.45 <= |delta| <= 0.55  
GRADUATED_DELTA_MODERATE_RANGE = (0.40, 0.60)  # Moderate risk: 0.40 <= |delta| <= 0.60
GRADUATED_DELTA_LIGHT_RANGE = (0.35, 0.65)    # Light risk: 0.35 <= |delta| <= 0.65

# Graduated Delta Risk Scores
GRADUATED_DELTA_PEAK_SCORE = 4        # Peak risk (true ATM)
GRADUATED_DELTA_HIGH_SCORE = 3        # High risk (near ATM)
GRADUATED_DELTA_MODERATE_SCORE = 2    # Moderate risk
GRADUATED_DELTA_LIGHT_SCORE = 1       # Light risk

# Risk Score Weighting (seller-prioritized)
RISK_WEIGHT_GAMMA = 4                 # Highest priority: gamma explosion risk
RISK_WEIGHT_ATM_DELTA = 4             # High priority: assignment/liquidity risk
RISK_WEIGHT_SLOW_THETA = 1            # Medium priority: slow profit accumulation
RISK_WEIGHT_VEGA = 1                  # Lower priority: volatility sensitivity
RISK_WEIGHT_PROXIMITY_FALLBACK = 1    # Light penalty only when delta not assessed

# Vega normalization threshold (as % of option price)
VEGA_NORMALIZED_THRESHOLD = 0.15      # vega > 15% of option price triggers warning

# Trading Day Adjusted Theta Configuration
ENABLE_TRADING_DAY_THETA = True     # Use trading days instead of calendar days for theta
SHOW_THETA_COMPARISON = True        # Show both calendar and trading day theta values

# IV Calculation Edge Case Protection
ENABLE_IV_EDGE_CASE_PROTECTION = True  # Protect against deep ITM/OTM unrealistic IV
MAX_PRICE_DEVIATION_TICKS = 5          # Maximum price deviation in tick sizes

# Black-76 with Futures Configuration
# CRITICAL: Black-76 and Black-Scholes are DIFFERENT models:
#   - Black-76: Uses FUTURES price (F) - already includes cost-of-carry, no dividend adjustment needed
#   - Black-Scholes: Uses SPOT price (S) - requires dividend yield for forward price calculation
# When ENABLE_BLACK76_FUTURES=True, all calculations use FUTURES as the underlying
# When ENABLE_BLACK76_FUTURES=False, all calculations use EQUITY SPOT as the underlying
ENABLE_BLACK76_FUTURES = True          # Use Black-76 with futures instead of Black-Scholes
BLACK76_RISK_FREE_RATE = 0.065         # Risk-free rate for Black-76 (6.5% for INR)
BLACK76_USE_MID_PRICE = True           # Use (bid+ask)/2 if available, else LTP
BLACK76_FALLBACK_TO_BS = True          # Fallback to Black-Scholes if Black-76 fails
BLACK_SCHOLES_DIVIDEND_YIELD = 0.01    # Dividend yield for Black-Scholes cost-of-carry (1% default)

# Real Market IV Data Integration Configuration
ENABLE_MARKET_IV_DATA = True           # Use real ATM IV from CSV screener data
MARKET_IV_DATA_PATH = r"C:\nihil\finance_ai_ws"  # Path to options_screener CSV files
MARKET_IV_USE_LATEST = True            # Auto-detect latest CSV file
MARKET_IV_FALLBACK_DEFAULT = 0.30      # Fallback IV if symbol not found in CSV (30%)
MARKET_IV_MAX_AGE_HOURS = 24           # Maximum age of IV data before considering stale (hours)
MARKET_IV_ATM_RANGE_PCT = 5.0          # Only use ATM IV for strikes within X% (expanded to 5% for better coverage)
ENABLE_IV_PERCENTILE_ANALYSIS = True   # Add IV percentile to risk assessment
IV_PERCENTILE_LOW_THRESHOLD = 25       # Low IV environment (risky for sellers)
IV_PERCENTILE_HIGH_THRESHOLD = 75      # High IV environment (favorable for sellers)
ENABLE_PCR_ANALYSIS = True             # Use Put-Call Ratio for sentiment analysis
ENABLE_MAX_PAIN_AWARENESS = True       # Show Max Pain proximity in analysis

# Market Liquidity Validation Configuration
ENABLE_LIQUIDITY_VALIDATION = False     # Enable market liquidity validation
VALIDATION_STRATEGY = "MONTHLY_WRITING" # "MONTHLY_WRITING" or "INTRADAY_SCALPING"
MIN_LIQUIDITY_SCORE = 50               # Minimum liquidity score (0-100) for option selection
MIN_EXECUTION_SCORE = 60               # Minimum execution score for monthly writing
ENABLE_ADAPTIVE_SCORING = True         # Automatically adjust criteria based on market status
ENABLE_STRATEGIC_ANALYSIS = True       # Enable strategic monthly writing analysis
REJECT_EXTREME_SPREADS = True          # Reject options with >50% bid-ask spreads
REJECT_LOW_VOLUME = True               # Reject options with zero recent volume
REJECT_LOW_OI = True                   # Reject options with very low open interest

# Risk Scoring (summary):
# Common to both profiles:
#   - Vega > 15% of option price: +1 point (LOWER risk, normalized)
# DEFAULT profile (buyer-style):
#   - Theta/day < -0.05: +2 points (MEDIUM risk)  [fast decay treated as risky]
#   - Gamma > dynamic_threshold: +2 points (MEDIUM risk) [dynamic threshold = 1/(100*spot)]
#   - Strike within 5% of spot: +3 points (HIGH risk)
# SELLER profile (weighted priorities, NO double-counting):
#   - Enhanced gamma risk with DTE multipliers (HIGHEST priority: time-sensitive gamma explosion risk):
#     * Base: +4 points for gamma > dynamic_threshold
#     * DTE ≤3 days: +6 points (2.0x multiplier - gamma explosion zone)
#     * DTE ≤7 days: +6 points (1.5x multiplier - weekly options)
#     * DTE ≤15 days: +5 points (1.2x multiplier - bi-weekly options)
#     * DTE >15 days: +4 points (1.0x multiplier - monthly+ options)
#   - Graduated delta scoring (HIGHEST priority: assignment/liquidity risk):
#     * 0.48 ≤ |delta| ≤ 0.52: +4 points (PEAK risk - true ATM)
#     * 0.45 ≤ |delta| ≤ 0.55: +3 points (HIGH risk - near ATM)
#     * 0.40 ≤ |delta| ≤ 0.60: +2 points (MODERATE risk)
#     * 0.35 ≤ |delta| ≤ 0.65: +1 point (LIGHT risk)
#   - Proximity fallback: +1 point ONLY if delta risk not already assessed
#   - Slow decay (theta/day > -0.02): +1 point (MEDIUM priority: slow profit accumulation)
#   - Very fast decay (theta/day < -0.10): -1 point bonus (capped at 1 bucket drop)
# Risk Levels: 🔴 HIGH (5+), 🟡 MEDIUM (3-4), 🟢 LOW (1-2), ✅ SAFE (0)

# Dynamic Delta Targeting Configuration
ENABLE_DYNAMIC_DELTA = True          # Enable/disable dynamic delta targeting
BASE_DELTA_TARGET = 0.18             # Base delta target for monthly options
MIN_DELTA_TARGET = 0.05              # Minimum delta for ultra-short-dated (0-3 DTE = 95%+ OTM, gamma explosion zone)
MAX_DELTA_TARGET = 0.25              # Maximum delta for long-dated options (>90 DTE, safe from gamma)
DTE_SCALING_FACTOR = 0.3             # How much to scale with DTE (legacy - not used in corrected logic)
FORCE_EXIT_ULTRA_SHORT = False       # If True, returns None for 0-3 DTE (forces position exit)

# DTE Multiplier Configuration (NEW - time-sensitive risk assessment)
ENABLE_DTE_MULTIPLIER = True           # Enable DTE-based risk multipliers
DTE_MULTIPLIER_3_DAYS = 2.0           # Double risk for 3 days or less (gamma explosion zone)
DTE_MULTIPLIER_7_DAYS = 1.5           # 50% higher risk for 7 days or less
DTE_MULTIPLIER_15_DAYS = 1.2          # 20% higher risk for 15 days or less
DTE_MULTIPLIER_NORMAL = 1.0           # Normal risk for 15+ days
MAX_DTE_ADJUSTED_SCORE = 6            # Maximum risk score after DTE adjustment

# Enhanced Theta Risk Configuration (NEW - bi-directional risk detection)
ENABLE_ENHANCED_THETA_RISK = True      # Enable enhanced theta risk assessment
THETA_WHIPSAW_RISK_7_DAYS = 2         # Risk points for rapid decay near expiry (≤7 days)
THETA_WHIPSAW_RISK_15_DAYS = 1        # Risk points for fast decay in bi-weekly (≤15 days)
THETA_SLOW_DECAY_RISK = 1             # Risk points for slow decay (capital efficiency)

# Output files
OUTPUT_CSV_EQUAL_DELTA = f"kite_equal_delta_strangles_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
OUTPUT_CSV_SD_WRITING = f"kite_supply_demand_writing_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"


# ===============================================

IST = timezone(timedelta(hours=5, minutes=30))

# ------------------ KITE SESSION ------------------
def kite_session():
    api_key = "3bi2yh8g830vq3y6"
    access_token = "YitEzaTwOIBQGUcxii2baV03hfLwsloR"
    if not api_key or not access_token:
        raise RuntimeError("Set KITE_API_KEY and KITE_ACCESS_TOKEN env vars before running.")
    kite = KiteConnect(api_key=api_key)
    kite.set_access_token(access_token)
    return kite

# ------------------ DATE HELPERS ------------------
def is_trading_day(date: datetime) -> bool:
    """
    Check if a date is a trading day (Monday-Friday, excluding major Indian holidays)
    Note: This is a simplified version. For production, consider using a proper holiday calendar
    """
    # Monday = 0, Sunday = 6
    if date.weekday() >= 5:  # Saturday or Sunday
        return False
    
    # Major Indian market holidays (simplified - you can expand this)
    major_holidays = [
        "2025-01-26",  # Republic Day
        "2025-03-25",  # Holi
        "2025-04-14",  # Dr Ambedkar Jayanti
        "2025-05-01",  # Maharashtra Day
        "2025-08-15",  # Independence Day
        "2025-10-02",  # Gandhi Jayanti
        "2025-11-14",  # Diwali
        "2025-12-25",  # Christmas
    ]
    
    date_str = date.strftime("%Y-%m-%d")
    if date_str in major_holidays:
        return False
    
    return True

def count_trading_days_to_expiry(expiry_ist: datetime, now_ist: Optional[datetime] = None) -> int:
    """
    Count actual trading days to expiry (excluding weekends and holidays)
    """
    if hasattr(expiry_ist, "to_pydatetime"):
        expiry_ist = expiry_ist.to_pydatetime()
    expiry_ist = expiry_ist.replace(hour=15, minute=30, second=0, microsecond=0, tzinfo=IST)
    now = now_ist or datetime.now(IST)
    
    # Ensure we're working with dates only
    expiry_date = expiry_ist.date()
    now_date = now.date()
    
    trading_days = 0
    current_date = now_date
    
    while current_date < expiry_date:
        if is_trading_day(datetime.combine(current_date, datetime.min.time())):
            trading_days += 1
        current_date += timedelta(days=1)
    
    return max(trading_days, 1)  # Minimum 1 trading day

def year_fraction_to_expiry(expiry_ist: datetime, now_ist: Optional[datetime] = None) -> float:
    if hasattr(expiry_ist, "to_pydatetime"):
        expiry_ist = expiry_ist.to_pydatetime()
    expiry_ist = expiry_ist.replace(hour=15, minute=30, second=0, microsecond=0, tzinfo=IST)
    now = now_ist or datetime.now(IST)
    days = (expiry_ist - now).total_seconds() / (24 * 3600)
    return max(days / 365.0, 1e-6)

def nearest_expiry_for_symbol(df_ins: pd.DataFrame, symbol: str) -> Optional[datetime]:
    fno = df_ins[(df_ins["segment"] == "NFO-OPT") & (df_ins["name"] == symbol)]
    if fno.empty:
        return None
    exps = sorted(set(fno["expiry"].tolist()))
    if not exps:
        return None
    exp_dt = exps[0]
    if hasattr(exp_dt, "to_pydatetime"):
        exp_dt = exp_dt.to_pydatetime()
    elif not isinstance(exp_dt, datetime):
        exp_dt = datetime.fromtimestamp(pd.Timestamp(exp_dt).timestamp())
    return exp_dt

# ------------------ MARKET IV DATA INTEGRATION ------------------
def load_market_iv_data(csv_path: str = None) -> Optional[Tuple[pd.DataFrame, str]]:
    """
    Load real market IV data from options screener CSV files with staleness checking.
    
    Args:
        csv_path: Specific CSV file path, or None to auto-detect latest
    
    Returns:
        Tuple of (DataFrame, csv_path) with columns: Instrument, FuturePrice, ATMIV, etc.
        Returns (None, None) if data cannot be loaded
    """
    try:
        if csv_path is None and MARKET_IV_USE_LATEST:
            # Auto-detect latest CSV file
            pattern = os.path.join(MARKET_IV_DATA_PATH, "options_screener_*.csv")
            csv_files = glob.glob(pattern)
            if not csv_files:
                print(f"[MARKET-IV] No CSV files found at {pattern}")
                return None, None
            # Sort by modification time to get latest
            csv_path = max(csv_files, key=os.path.getmtime)
            
            # Check data age
            csv_mod_time = os.path.getmtime(csv_path)
            data_age_hours = (time.time() - csv_mod_time) / 3600
            
            if data_age_hours > MARKET_IV_MAX_AGE_HOURS:
                print(f"[MARKET-IV] ⚠️  WARNING: IV data is {data_age_hours:.1f} hours old (stale)")
                print(f"[MARKET-IV] Data from: {os.path.basename(csv_path)}")
                print(f"[MARKET-IV] Recommend: Update CSV file or calculated IV will be used")
            else:
                print(f"[MARKET-IV] Using latest IV data: {os.path.basename(csv_path)} "
                      f"({data_age_hours:.1f} hours old)")
        elif csv_path is None:
            print(f"[MARKET-IV] No CSV path specified and auto-detect disabled")
            return None, None
        
        # Load CSV
        df = pd.read_csv(csv_path)
        
        # Validate required columns
        required_cols = ['Instrument', 'ATMIV']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            print(f"[MARKET-IV] Missing required columns: {missing_cols}")
            return None, None
        
        # Convert Instrument to uppercase for matching
        df['Instrument'] = df['Instrument'].str.upper()
        
        # Convert numeric columns
        numeric_cols = ['FuturePrice', 'FuturePercentChange', 'ATMIV', 'ATMIVChange', 
                       'IVPercentile', 'PCR', 'MaxPain']
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        print(f"[MARKET-IV] Loaded IV data for {len(df)} instruments")
        return df, csv_path
        
    except Exception as e:
        print(f"[MARKET-IV] Error loading IV data: {e}")
        return None, None

def get_symbol_market_iv_data(symbol: str, iv_data: pd.DataFrame = None, csv_path: str = None) -> Dict:
    """
    Get market IV data for a specific symbol.
    
    Args:
        symbol: Symbol name (e.g., "SBIN", "NIFTY")
        iv_data: Pre-loaded IV DataFrame, or None to load fresh
    
    Returns:
        Dict with keys: atm_iv, iv_percentile, pcr, max_pain, future_price
        Returns dict with default values if symbol not found
    """
    default_result = {
        'atm_iv': MARKET_IV_FALLBACK_DEFAULT,
        'iv_percentile': None,
        'pcr': None,
        'max_pain': None,
        'future_price': None,
        'data_available': False
    }
    
    if not ENABLE_MARKET_IV_DATA:
        return default_result
    
    if iv_data is None:
        iv_data, csv_path = load_market_iv_data()
        if iv_data is None:
            return default_result
    
    # Check data staleness if we have the CSV path
    if csv_path:
        csv_mod_time = os.path.getmtime(csv_path)
        data_age_hours = (time.time() - csv_mod_time) / 3600
        if data_age_hours > MARKET_IV_MAX_AGE_HOURS:
            # Data is stale - mark as unavailable but continue for other fields
            default_result['data_stale'] = True
            default_result['data_age_hours'] = data_age_hours
    
    # Try to find symbol
    symbol_upper = symbol.upper()
    symbol_data = iv_data[iv_data['Instrument'] == symbol_upper]
    
    if symbol_data.empty:
        print(f"[MARKET-IV] Symbol {symbol} not found in IV data, using fallback IV={MARKET_IV_FALLBACK_DEFAULT}")
        return default_result
    
    row = symbol_data.iloc[0]
    
    result = {
        'atm_iv': row.get('ATMIV', MARKET_IV_FALLBACK_DEFAULT) if pd.notna(row.get('ATMIV')) else MARKET_IV_FALLBACK_DEFAULT,
        'iv_percentile': row.get('IVPercentile') if pd.notna(row.get('IVPercentile')) else None,
        'pcr': row.get('PCR') if pd.notna(row.get('PCR')) else None,
        'max_pain': row.get('MaxPain') if pd.notna(row.get('MaxPain')) else None,
        'future_price': row.get('FuturePrice') if pd.notna(row.get('FuturePrice')) else None,
        'atm_iv_change': row.get('ATMIVChange') if pd.notna(row.get('ATMIVChange')) else None,
        'data_available': True
    }
    
    # Format PCR display (handle None values)
    pcr_display = f"{result['pcr']:.2f}" if result['pcr'] is not None else "N/A"
    print(f"[MARKET-IV] {symbol}: ATM IV={result['atm_iv']:.1f}%, "
          f"IV Percentile={result['iv_percentile']}, PCR={pcr_display}")
    
    return result

def interpolate_iv_with_skew(atm_iv: float, strike_distance_pct: float) -> float:
    """
    Interpolate IV for non-ATM strikes using volatility skew model.
    
    Typical equity options exhibit volatility skew where OTM options have higher IV.
    This function applies a simplified skew adjustment based on strike distance from ATM.
    
    Args:
        atm_iv: ATM implied volatility (decimal, e.g., 0.30 for 30%)
        strike_distance_pct: Absolute distance from ATM as percentage (e.g., 5.0 for 5%)
    
    Returns:
        Interpolated IV adjusted for skew (decimal)
    
    Notes:
        - Typical skew: ~1% IV increase per 5% OTM distance
        - Skew adjustment: 0.2% per 1% OTM (0.002 per 1% distance)
        - Example: 5% OTM with 30% ATM IV → 30% + (5 * 0.2%) = 31% IV
    """
    skew_adjustment = strike_distance_pct * 0.002  # 0.2% per 1% OTM (0.002 in decimal)
    interpolated_iv = atm_iv + skew_adjustment
    return interpolated_iv

# ------------------ UTILITY FUNCTIONS ------------------
def calculate_oi_change_percent(current_oi, prev_oi):
    """
    Centralized OI change percentage calculation
    """
    if not prev_oi or prev_oi <= 0:
        return 0.0
    return ((current_oi - prev_oi) / prev_oi) * 100.0

def format_oi_display(oi_lakh, oi_change_pct=None):
    """
    Centralized OI display formatting
    """
    base = f"{oi_lakh:.2f}L"
    if oi_change_pct is not None:
        change_symbol = "📈" if oi_change_pct > 0 else "📉" if oi_change_pct < 0 else "➡️"
        return f"{base} {change_symbol}{abs(oi_change_pct):.1f}%"
    return base

# ------------------ DYNAMIC DELTA TARGETING ------------------
def calculate_dynamic_delta_target(dte_days, base_delta=0.18):
    """
    Calculate dynamic delta target based on days to expiry (PROFESSIONAL GAMMA-RISK ADJUSTED)
    
    CRITICAL LOGIC FOR OPTION SELLERS:
    - Ultra-short (≤3 DTE): EXTREME caution → 0.05-0.08 delta (95%+ OTM) OR exit positions
    - Short-dated (4-7 DTE): LOWER delta → Far OTM to avoid gamma explosion (0.08-0.12)
    - Medium-dated (30 DTE): Base delta → Standard monthly options (0.18)
    - Long-dated (≥60 DTE): HIGHER delta → Closer to ATM is safe (0.20-0.25)
    
    Gamma Risk Reality (Professional Behavior):
    - 0-3 DTE: Most pros CLOSE positions entirely (gamma explosion zone)
    - 4-7 DTE: Those who hold use 0.08-0.12 delta MAX (88-92% OTM)
    - 8-14 DTE: Still cautious, 0.12-0.15 delta (85-88% OTM)
    - 30+ DTE: Gamma is manageable, can use standard deltas
    
    Why 0.10 delta at 3 DTE is dangerous:
    - 1-2% adverse move can swing delta from 0.10 → 0.40+ overnight
    - Assignment risk jumps from 10% → 60%+ in hours
    - Professional sellers either exit or use 0.05-0.08 delta (95%+ OTM)
    
    Args:
        dte_days: Days to expiry
        base_delta: Base delta target for monthly options (default 0.18)
    
    Returns:
        float: Adjusted delta target (professional gamma-risk optimized)
        None: If FORCE_EXIT_ULTRA_SHORT=True and dte_days ≤ 3
    """
    if not ENABLE_DYNAMIC_DELTA:
        return base_delta
    
    # PROFESSIONAL LOGIC: Ultra-conservative for short-dated, aggressive for long-dated
    if dte_days <= 3:  # Ultra-short (0-3 DTE) - EXTREME GAMMA EXPLOSION ZONE
        # PROFESSIONAL BEHAVIOR: Most close positions here
        if FORCE_EXIT_ULTRA_SHORT:
            return None  # Force exit - don't allow new positions in gamma explosion zone
        # For those who absolutely must hold: Go VERY far OTM
        return max(MIN_DELTA_TARGET, base_delta * 0.28)  # ~0.05 (95%+ OTM probability)
    
    elif dte_days <= 7:  # Weekly options (4-7 DTE) - HIGH gamma risk
        # Professional sellers: 0.08-0.12 delta maximum
        return max(MIN_DELTA_TARGET, base_delta * 0.50)  # ~0.09 (91% OTM probability)
    
    elif dte_days <= 14:  # Bi-weekly (8-14 DTE) - Moderate gamma risk
        # Still cautious territory
        return max(MIN_DELTA_TARGET, base_delta * 0.67)  # ~0.12 (88% OTM probability)
    
    elif dte_days <= 21:  # 3-week (15-21 DTE) - Transitioning to safety
        # Slightly farther OTM than monthly
        return base_delta * 0.83  # ~0.15 (85% OTM probability)
    
    elif dte_days <= 30:  # Monthly (22-30 DTE) - Standard baseline
        return base_delta  # 0.18 (82% OTM probability)
    
    elif dte_days <= 45:  # 6-week (31-45 DTE) - LOW gamma risk
        # Starting to go closer to ATM
        return base_delta * 1.06  # ~0.19 (81% OTM probability)
    
    elif dte_days <= 60:  # Bi-monthly (46-60 DTE) - LOW gamma risk
        # Can go closer to ATM safely
        return min(MAX_DELTA_TARGET, base_delta * 1.11)  # ~0.20 (80% OTM probability)
    
    elif dte_days <= 90:  # Quarterly (61-90 DTE) - VERY low gamma risk
        # Closer to ATM is safe, better premium collection
        return min(MAX_DELTA_TARGET, base_delta * 1.22)  # ~0.22 (78% OTM probability)
    
    else:  # Long-term (>90 DTE) - Minimal gamma risk
        # Maximum safe delta for best premium/margin efficiency
        return min(MAX_DELTA_TARGET, base_delta * 1.39)  # ~0.25 (75% OTM probability)

def calculate_smooth_dynamic_delta(dte_days, base_delta=0.18):
    """
    Smooth dynamic delta scaling using mathematical function
    """
    if not ENABLE_DYNAMIC_DELTA:
        return base_delta
        
    # Exponential decay with minimum and maximum bounds
    scale_factor = 1.0 + DTE_SCALING_FACTOR * (1 - math.exp(-dte_days / 30.0))
    
    # Clamp between MIN_DELTA_TARGET and MAX_DELTA_TARGET
    target_delta = base_delta * scale_factor
    return max(MIN_DELTA_TARGET, min(MAX_DELTA_TARGET, target_delta))

# ------------------ BLACK-SCHOLES ------------------
def _norm_cdf(x): return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))
def _norm_pdf(x): return (1.0 / math.sqrt(2.0 * math.pi)) * math.exp(-0.5 * x * x)

def bs_price(opt, S, K, r, sigma, t):
    if sigma <= 0 or t <= 0 or S <= 0 or K <= 0:
        return 0.0
    d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * t) / (sigma * math.sqrt(t))
    d2 = d1 - sigma * math.sqrt(t)
    return (S * _norm_cdf(d1) - K * math.exp(-r * t) * _norm_cdf(d2)) if opt.upper() == "C" else \
           (K * math.exp(-r * t) * _norm_cdf(-d2) - S * _norm_cdf(-d1))

def bs_delta(opt, S, K, r, sigma, t):
    d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * t) / (sigma * math.sqrt(t))
    return _norm_cdf(d1) if opt.upper() == "C" else _norm_cdf(d1) - 1.0

def bs_gamma(S, K, r, sigma, t):
    d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * t) / (sigma * math.sqrt(t))
    return _norm_pdf(d1) / (S * sigma * math.sqrt(t))

def bs_theta(opt, S, K, r, sigma, t):
    d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * t) / (sigma * math.sqrt(t))
    d2 = d1 - sigma * math.sqrt(t)
    term1 = -(S * _norm_pdf(d1) * sigma) / (2.0 * math.sqrt(t))
    theta_annual = term1 - r * K * math.exp(-r * t) * _norm_cdf(d2) if opt.upper() == "C" else \
                   term1 + r * K * math.exp(-r * t) * _norm_cdf(-d2)
    return theta_annual  # Return annual theta (this is what we need for proper scaling)

def bs_vega(S, K, r, sigma, t):
    d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * t) / (sigma * math.sqrt(t))
    return S * _norm_pdf(d1) * math.sqrt(t) / 100.0

# Enhanced Greeks Calculations
def bs_rho(opt, S, K, r, sigma, t):
    """Calculate Rho - sensitivity to interest rate changes"""
    d2 = (math.log(S/K) + (r - 0.5*sigma**2)*t) / (sigma*math.sqrt(t))
    if opt.upper() == "C":
        return K * t * math.exp(-r*t) * _norm_cdf(d2) / 100.0
    else:
        return -K * t * math.exp(-r*t) * _norm_cdf(-d2) / 100.0

# ------------------ BLACK-76 GREEKS ------------------
def black76_delta(F, K, r, T, sigma, is_call=True):
    """Black-76 delta using futures price"""
    if sigma<=0 or T<=0 or F<=0 or K<=0: 
        return float('nan')
    vol = sigma*math.sqrt(T)
    d1 = (math.log(F/K) + 0.5*vol*vol) / vol
    df = math.exp(-r*T)
    if is_call:
        return df * _ncdf(d1)
    else:
        return df * (_ncdf(d1) - 1.0)

def black76_gamma(F, K, r, T, sigma):
    """Black-76 gamma using futures price"""
    if sigma<=0 or T<=0 or F<=0 or K<=0: 
        return float('nan')
    vol = sigma*math.sqrt(T)
    d1 = (math.log(F/K) + 0.5*vol*vol) / vol
    df = math.exp(-r*T)
    return df * _nd(d1) / (F * sigma * math.sqrt(T))

def black76_theta(F, K, r, T, sigma, is_call=True):
    """Black-76 theta using futures price"""
    if sigma<=0 or T<=0 or F<=0 or K<=0: 
        return float('nan')
    vol = sigma*math.sqrt(T)
    d1 = (math.log(F/K) + 0.5*vol*vol) / vol
    d2 = d1 - vol
    df = math.exp(-r*T)
    
    # Theta calculation
    term1 = -(F * _nd(d1) * sigma) / (2.0 * math.sqrt(T))
    if is_call:
        theta_annual = term1 - r * df * (F * _ncdf(d1) - K * _ncdf(d2))
    else:
        theta_annual = term1 - r * df * (K * _ncdf(-d2) - F * _ncdf(-d1))
    
    return theta_annual

def black76_vega(F, K, r, T, sigma):
    """Black-76 vega using futures price"""
    if sigma<=0 or T<=0 or F<=0 or K<=0: 
        return float('nan')
    vol = sigma*math.sqrt(T)
    d1 = (math.log(F/K) + 0.5*vol*vol) / vol
    df = math.exp(-r*T)
    return df * F * _nd(d1) * math.sqrt(T) / 100.0

def black76_rho(F, K, r, T, sigma, is_call=True):
    """Black-76 rho using futures price"""
    if sigma<=0 or T<=0 or F<=0 or K<=0: 
        return float('nan')
    vol = sigma*math.sqrt(T)
    d1 = (math.log(F/K) + 0.5*vol*vol) / vol
    d2 = d1 - vol
    df = math.exp(-r*T)
    
    if is_call:
        return df * T * (F * _ncdf(d1) - K * _ncdf(d2)) / 100.0
    else:
        return df * T * (K * _ncdf(-d2) - F * _ncdf(-d1)) / 100.0

def bs_theta_per_day(opt, S, K, r, sigma, t, trading_days=None):
    """
    Return annual theta (for proper scaling in main logic)
    """
    return bs_theta(opt, S, K, r, sigma, t)  # Return annual theta

# Note: bs_theta_per_trading_day function removed - redundant with bs_theta_per_day
# bs_theta_per_day already handles trading days correctly when trading_days parameter is provided

def calculate_all_greeks(opt, S, K, r, sigma, t, trading_days=None, q=0.0):
    """
    Calculate all major Greeks using Black-Scholes model with EQUITY SPOT price.
    
    CRITICAL: Black-Scholes model assumes S is the EQUITY SPOT price. For accurate 
    forward price calculation, dividend yield (q) should be provided.
    Forward price F = S * exp((r-q)*t)
    
    Args:
        opt: "C" for call, "P" for put
        S: EQUITY SPOT price (not futures!)
        K: Strike price
        r: Risk-free rate (annualized)
        sigma: Implied volatility (annualized)
        t: Time to expiry (years)
        trading_days: Optional trading days to expiry
        q: Continuous dividend yield (default 0.0)
    
    Returns:
        dict: All Greeks (delta, gamma, theta, vega, rho)
    
    Note: Current Black-Scholes implementation doesn't explicitly use q in Greeks.
    For dividend-adjusted calculations, use Black-76 with futures instead.
    """
    theta_annual = bs_theta_per_day(opt, S, K, r, sigma, t, trading_days)
    
    # Scale theta properly here
    CALENDAR_DAYS_PER_YEAR = 365.0
    TRADING_DAYS_PER_YEAR = 252.0
    
    theta_per_day = theta_annual / CALENDAR_DAYS_PER_YEAR
    theta_per_trading_day = theta_annual / TRADING_DAYS_PER_YEAR
    
    return {
        'delta': bs_delta(opt, S, K, r, sigma, t),
        'gamma': bs_gamma(S, K, r, sigma, t),
        'theta': theta_annual,                        # Annual theta
        'theta_per_day': theta_per_day,               # Calendar day theta (annual/365)
        'theta_per_trading_day': theta_per_trading_day, # Trading day theta (annual/252)
        'vega': bs_vega(S, K, r, sigma, t),
        'rho': bs_rho(opt, S, K, r, sigma, t)
    }

def calculate_black76_greeks(opt_type, F, strike, r, sigma, t, trading_days=None):
    """
    Calculate all major Greeks using Black-76 model with FUTURES price.
    
    CRITICAL: Black-76 model assumes F is the FUTURES/FORWARD price, which already 
    incorporates cost-of-carry (interest rates and dividends). Do NOT pass equity 
    spot price to this function.
    
    Args:
        opt_type: "C" for call, "P" for put
        F: FUTURES price (not equity spot!)
        strike: Strike price
        r: Risk-free rate (annualized)
        sigma: Implied volatility (annualized)
        t: Time to expiry (years)
        trading_days: Optional trading days to expiry
    
    Returns:
        dict: All Greeks (delta, gamma, theta, vega, rho)
    """
    # F is already the futures price - no conversion needed
    is_call = (opt_type == "C")
    theta_annual = black76_theta(F, strike, r, t, sigma, is_call)
    
    # Scale theta properly
    CALENDAR_DAYS_PER_YEAR = 365.0
    TRADING_DAYS_PER_YEAR = 252.0
    
    theta_per_day = theta_annual / CALENDAR_DAYS_PER_YEAR
    theta_per_trading_day = theta_annual / TRADING_DAYS_PER_YEAR
    
    return {
        'delta': black76_delta(F, strike, r, t, sigma, is_call),
        'gamma': black76_gamma(F, strike, r, t, sigma),
        'theta': theta_annual,                        # Annual theta
        'theta_per_day': theta_per_day,               # Calendar day theta
        'theta_per_trading_day': theta_per_trading_day, # Trading day theta
        'vega': black76_vega(F, strike, r, t, sigma),
        'rho': black76_rho(F, strike, r, t, sigma, is_call)
    }

# REMOVED: Greeks caching (was useless due to per-strike IV differences and single-symbol scope)
# Each strike has unique IV due to volatility skew → no cache hits
# Cache is discarded after each symbol → 0% reuse
# Greeks calculation is fast (~0.3ms) vs API calls (500ms bottleneck)
# Complexity without benefit → removed for code clarity

def calculate_graduated_delta_risk_score(delta_abs):
    """
    Calculate graduated delta risk score based on delta magnitude.
    
    Args:
        delta_abs: Absolute value of delta (0.0 to 1.0)
        
    Returns:
        tuple: (risk_score, risk_level, description)
        
    Graduated scoring system:
    - 0.48 <= |delta| <= 0.52: +4 points (PEAK risk - true ATM)
    - 0.45 <= |delta| <= 0.55: +3 points (HIGH risk - near ATM)  
    - 0.40 <= |delta| <= 0.60: +2 points (MODERATE risk)
    - 0.35 <= |delta| <= 0.65: +1 point (LIGHT risk)
    - Outside ranges: 0 points (SAFE)
    """
    if not ENABLE_GRADUATED_DELTA_SCORING:
        # Fallback to legacy binary scoring
        if GRADUATED_DELTA_LIGHT_RANGE[0] <= delta_abs <= GRADUATED_DELTA_LIGHT_RANGE[1]:
            return RISK_WEIGHT_ATM_DELTA, "HIGH", f"Near-ATM delta: {delta_abs:.2f}"
        return 0, "SAFE", ""
    
    # Graduated scoring with priority order (most restrictive first)
    if GRADUATED_DELTA_PEAK_RANGE[0] <= delta_abs <= GRADUATED_DELTA_PEAK_RANGE[1]:
        return GRADUATED_DELTA_PEAK_SCORE, "PEAK", f"Peak ATM delta: {delta_abs:.2f} (highest assignment risk)"
    elif GRADUATED_DELTA_HIGH_RANGE[0] <= delta_abs <= GRADUATED_DELTA_HIGH_RANGE[1]:
        return GRADUATED_DELTA_HIGH_SCORE, "HIGH", f"High ATM delta: {delta_abs:.2f} (high assignment risk)"
    elif GRADUATED_DELTA_MODERATE_RANGE[0] <= delta_abs <= GRADUATED_DELTA_MODERATE_RANGE[1]:
        return GRADUATED_DELTA_MODERATE_SCORE, "MODERATE", f"Moderate ATM delta: {delta_abs:.2f} (moderate assignment risk)"
    elif GRADUATED_DELTA_LIGHT_RANGE[0] <= delta_abs <= GRADUATED_DELTA_LIGHT_RANGE[1]:
        return GRADUATED_DELTA_LIGHT_SCORE, "LIGHT", f"Light ATM delta: {delta_abs:.2f} (light assignment risk)"
    else:
        return 0, "SAFE", f"Safe delta: {delta_abs:.2f} (outside ATM ranges)"

def test_graduated_delta_scoring():
    """
    Test function to demonstrate graduated delta scoring system
    """
    print("\n🧪 TESTING GRADUATED DELTA SCORING SYSTEM:")
    print("=" * 60)
    
    test_deltas = [0.30, 0.35, 0.40, 0.45, 0.48, 0.50, 0.52, 0.55, 0.60, 0.65, 0.70]
    
    for delta in test_deltas:
        score, risk_level, description = calculate_graduated_delta_risk_score(delta)
        print(f"Delta: {delta:5.2f} → {risk_level:8} (+{score} points) - {description}")
    
    print("\n📊 RISK LEVEL MAPPING:")
    print("🔴 PEAK (4 points): True ATM options - highest assignment risk")
    print("🟠 HIGH (3 points): Near ATM options - high assignment risk")
    print("🟡 MODERATE (2 points): Moderately risky options")
    print("🟢 LIGHT (1 point): Lightly risky options")
    print("✅ SAFE (0 points): Safe from assignment risk")
    
    print("\n💡 BENEFITS:")
    print("• More nuanced risk assessment than binary 0.35-0.65 check")
    print("• True ATM (0.48-0.52) gets highest penalty")
    print("• Graduated penalties encourage better strike selection")
    print("• Maintains backward compatibility with legacy system")

def test_dte_multiplier_system():
    """
    Test function to demonstrate DTE multiplier system
    """
    print("\n⏰ TESTING DTE MULTIPLIER SYSTEM:")
    print("=" * 60)
    
    # Test DTE multipliers
    test_dtes = [1, 3, 5, 7, 10, 15, 20, 30]
    
    print("📊 DTE Multiplier Values:")
    for dte in test_dtes:
        multiplier = calculate_dte_multiplier(dte)
        if dte <= 3:
            risk_level = "🔴 EXPLOSION"
        elif dte <= 7:
            risk_level = "🟠 WEEKLY"
        elif dte <= 15:
            risk_level = "🟡 BI-WEEKLY"
        else:
            risk_level = "🟢 MONTHLY+"
        print(f"  {dte:2d} days → {multiplier:3.1f}x multiplier {risk_level}")
    
    # Test enhanced gamma risk calculation
    print(f"\n🧮 Enhanced Gamma Risk Examples (NIFTY @ 22,000):")
    base_threshold = 1 / (100 * 22000)  # 0.000045
    
    test_gammas = [0.00003, 0.00004, 0.00005, 0.00006, 0.00008]
    test_dtes = [2, 5, 10, 25]
    
    for gamma in test_gammas:
        print(f"\n  Gamma: {gamma:.6f} (base threshold: {base_threshold:.6f})")
        for dte in test_dtes:
            score, description = calculate_enhanced_gamma_risk(gamma, 22000, dte)
            if score > 0:
                multiplier = calculate_dte_multiplier(dte)
                print(f"    DTE {dte:2d} days: +{score} points (multiplier: {multiplier:.1f}x)")
            else:
                print(f"    DTE {dte:2d} days: SAFE (0 points)")
    
    print(f"\n💡 BENEFITS:")
    print("• Time-sensitive risk assessment - closer expiry = higher risk")
    print("• Gamma explosion zone (≤3 days) gets double penalty")
    print("• Weekly options (≤7 days) get 50% higher penalty")
    print("• Monthly+ options get normal assessment")
    print("• Prevents over-trading dangerous short-dated options")

def test_enhanced_theta_risk_system():
    """
    Test function to demonstrate enhanced theta risk system
    """
    print("\n⏰ TESTING ENHANCED THETA RISK SYSTEM:")
    print("=" * 60)
    
    if not ENABLE_ENHANCED_THETA_RISK:
        print("❌ Enhanced Theta Risk system is DISABLED")
        return
    
    print("✅ Enhanced Theta Risk system is ENABLED")
    
    # Test theta risk scenarios
    test_scenarios = [
        {"dte": 3, "theta": -0.08, "expected": "Whipsaw Risk"},
        {"dte": 3, "theta": -0.02, "expected": "Slow Decay Risk"},
        {"dte": 3, "theta": -0.03, "expected": "Safe"},
        {"dte": 10, "theta": -0.10, "expected": "Moderate Whipsaw"},
        {"dte": 10, "theta": -0.003, "expected": "Slow Decay Risk"},
        {"dte": 10, "theta": -0.05, "expected": "Safe"},
        {"dte": 25, "theta": -0.003, "expected": "Slow Decay Risk"},
        {"dte": 25, "theta": -0.01, "expected": "Safe"},
    ]
    
    print("\n📊 Theta Risk Assessment Examples:")
    for scenario in test_scenarios:
        dte = scenario["dte"]
        theta = scenario["theta"]
        expected = scenario["expected"]
        
        score, warnings = calculate_enhanced_theta_risk(theta, dte)
        
        if score > 0:
            risk_level = "⚠️ RISK"
            risk_info = f"+{score} points: {', '.join(warnings)}"
        else:
            risk_level = "✅ SAFE"
            risk_info = "No risk factors"
        
        print(f"  DTE {dte:2d} days, θ={theta:6.3f}: {risk_level}")
        print(f"    {risk_info}")
        print(f"    Expected: {expected}")
        print()
    
    print(f"\n💡 ENHANCED THETA RISK FEATURES:")
    print("• Bi-directional risk detection - both too fast AND too slow")
    print("• DTE-sensitive thresholds - near expiry gets tighter control")
    print("• Whipsaw risk detection - fast theta + high gamma = dangerous")
    print("• Capital efficiency monitoring - slow decay = stuck capital")
    print("• Optimal theta ranges for each DTE category")

def calculate_dte_multiplier(days_to_expiry):
    """
    Calculate DTE-based risk multiplier for time-sensitive risk assessment.
    
    Args:
        days_to_expiry: Days to expiry (float)
        
    Returns:
        float: Risk multiplier (1.0 to 2.0)
        
    Multiplier logic:
    - ≤3 days: 2.0x (gamma explosion zone - double risk)
    - ≤7 days: 1.5x (weekly options - 50% higher risk)
    - ≤15 days: 1.2x (bi-weekly options - 20% higher risk)
    - >15 days: 1.0x (monthly+ options - normal risk)
    """
    if not ENABLE_DTE_MULTIPLIER:
        return 1.0
        
    if days_to_expiry <= 3:
        return DTE_MULTIPLIER_3_DAYS      # 2.0x - gamma explosion zone
    elif days_to_expiry <= 7:
        return DTE_MULTIPLIER_7_DAYS      # 1.5x - weekly options
    elif days_to_expiry <= 15:
        return DTE_MULTIPLIER_15_DAYS     # 1.2x - bi-weekly options
    else:
        return DTE_MULTIPLIER_NORMAL      # 1.0x - monthly+ options

def calculate_enhanced_gamma_risk(gamma_val, spot, days_to_expiry):
    """
    Calculate enhanced gamma risk with DTE sensitivity.
    
    Args:
        gamma_val: Gamma value from greeks
        spot: Current spot price
        days_to_expiry: Days to expiry
        
    Returns:
        tuple: (adjusted_risk_score, risk_description)
        
    Enhanced logic:
    - Base gamma threshold from dynamic calculation
    - DTE multiplier adjusts threshold (closer expiry = tighter control)
    - Risk score adjusted by DTE multiplier (capped at MAX_DTE_ADJUSTED_SCORE)
    """
    if not ENABLE_DTE_MULTIPLIER:
        # Fallback to legacy gamma assessment
        dynamic_threshold = calculate_dynamic_gamma_threshold(spot)
        if gamma_val > dynamic_threshold:
            return RISK_WEIGHT_GAMMA, f"High gamma: {gamma_val:.6f} > {dynamic_threshold:.6f}"
        return 0, ""
    
    # Calculate base dynamic threshold
    base_threshold = calculate_dynamic_gamma_threshold(spot)
    
    # Apply DTE multiplier to threshold (closer expiry = lower threshold)
    dte_multiplier = calculate_dte_multiplier(days_to_expiry)
    adjusted_threshold = base_threshold / dte_multiplier
    
    if gamma_val > adjusted_threshold:
        # Base gamma risk score
        base_score = RISK_WEIGHT_GAMMA  # 4 points
        
        # Apply DTE multiplier to risk score (closer expiry = higher score)
        dte_adjusted_score = min(base_score * dte_multiplier, MAX_DTE_ADJUSTED_SCORE)
        
        risk_description = (
            f"Time-sensitive gamma risk: {gamma_val:.6f} > {adjusted_threshold:.6f} "
            f"(DTE: {days_to_expiry:.1f} days, multiplier: {dte_multiplier:.1f}x)"
        )
        
        return int(dte_adjusted_score), risk_description
    
    return 0, ""

def calculate_enhanced_theta_risk(theta_day, days_to_expiry):
    """
    Enhanced theta risk assessment - bi-directional risk detection.
    
    Args:
        theta_day: Theta per day value
        days_to_expiry: Days to expiry
    
    Returns:
        tuple: (risk_score, list_of_warnings)
    """
    if not ENABLE_ENHANCED_THETA_RISK:
        # Fallback to legacy theta assessment
        if theta_day > -0.005:  # Capital efficiency risk
            return THETA_SLOW_DECAY_RISK, [f"Slow time decay: {theta_day:.3f} - capital stuck"]
        return 0, []
    
    risk_score = 0
    warnings = []
    
    if days_to_expiry <= 7:  # Near expiry (gamma explosion zone)
        if theta_day < -0.05:  # Very fast decay - WHIPSAW RISK
            risk_score += THETA_WHIPSAW_RISK_7_DAYS
            warnings.append(f"Rapid theta decay: {theta_day:.3f} - whipsaw risk near expiry")
        elif theta_day > -0.01:  # Too slow near expiry - capital inefficiency
            risk_score += THETA_SLOW_DECAY_RISK
            warnings.append(f"Unusually slow decay near expiry: {theta_day:.3f}")
        # Optimal range: -0.05 to -0.01 (0 points)
        
    elif days_to_expiry <= 15:  # Bi-weekly options
        if theta_day < -0.08:  # Very fast decay - moderate whipsaw risk
            risk_score += THETA_WHIPSAW_RISK_15_DAYS
            warnings.append(f"Fast theta decay: {theta_day:.3f} - moderate whipsaw risk")
        elif theta_day > -0.005:  # Too slow - capital efficiency risk
            risk_score += THETA_SLOW_DECAY_RISK
            warnings.append(f"Slow time decay: {theta_day:.3f} - capital stuck")
        # Optimal range: -0.08 to -0.005 (0 points)
        
    else:  # Monthly+ options (normal timeline)
        if theta_day > -0.005:  # Capital efficiency risk
            risk_score += THETA_SLOW_DECAY_RISK
            warnings.append(f"Slow time decay: {theta_day:.3f} - capital stuck")
        # Optimal range: < -0.005 (0 points)
    
    return risk_score, warnings

def calculate_risk_zone_warnings(spot, strike, greeks, option_price=None, days_to_expiry=None, iv_percentile=None, pcr=None):
    """
    Calculate risk zone warnings based on multiple risk factors
    
    Args:
        spot: Current spot price
        strike: Option strike price
        greeks: Dictionary of option Greeks
        option_price: Option price for vega normalization (optional)
        days_to_expiry: Days to expiry for DTE-sensitive risk assessment (optional)
        iv_percentile: IV percentile from market data (0-100, optional)
        pcr: Put-Call Ratio from market data (optional)
    
    Returns:
        dict: Risk warnings and overall risk score
    """
    try:
        print(f"  [DEBUG] calculate_risk_zone_warnings called with:")
        print(f"    spot: {spot} (type: {type(spot)})")
        print(f"    strike: {strike} (type: {type(strike)})")
        print(f"    greeks: {greeks}")
        print(f"    option_price: {option_price}")
        print(f"    days_to_expiry: {days_to_expiry}")
        
        warnings = []
        risk_score = 0
        
        # 1. Graduated Delta-based proximity risk (primary measure, replaces spot distance)
        # PREVENTS DOUBLE-COUNTING: Delta risk and proximity risk are essentially the same
        # for ATM options, so we only apply proximity penalty if delta wasn't already assessed
        delta_abs = abs(greeks.get('delta', 0.0))
        delta_risk_applied = False
        
        if RISK_PROFILE == "SELLER":
            # For sellers, use graduated delta scoring for more nuanced risk assessment
            delta_score, delta_risk_level, delta_description = calculate_graduated_delta_risk_score(delta_abs)
            
            if delta_score > 0:
                warnings.append(delta_description)
                risk_score += delta_score
                delta_risk_applied = True
                
                # Debug: Log graduated delta scoring details
                if SHOW_DETAILED_RISK_WARNINGS:
                    print(f"  [DEBUG] Graduated delta scoring: {delta_abs:.3f} → {delta_risk_level} (+{delta_score} points)")
            
            # Only apply proximity penalty if delta risk wasn't already assessed
            # This prevents double-counting the same ATM risk
            if not delta_risk_applied:
                spot_distance_pct = abs(strike - spot) / spot * 100
                if spot_distance_pct <= RISK_ZONE_SPOT_PERCENT:
                    warnings.append(f"Strike within {spot_distance_pct:.1f}% of spot (proximity fallback)")
                    risk_score += RISK_WEIGHT_PROXIMITY_FALLBACK
            else:
                # Delta already assessed, just log proximity for info
                spot_distance_pct = abs(strike - spot) / spot * 100
                if spot_distance_pct <= RISK_ZONE_SPOT_PERCENT:
                    warnings.append(f"Strike within {spot_distance_pct:.1f}% of spot (delta already assessed)")
        else:
            # DEFAULT profile: use original spot distance logic
            spot_distance_pct = abs(strike - spot) / spot * 100
            if spot_distance_pct <= RISK_ZONE_SPOT_PERCENT:
                warnings.append(f"Strike within {spot_distance_pct:.1f}% of spot")
                risk_score += 3  # Original weight for backward compatibility
        
        # 2. Gamma threshold (curvature risk) - highest priority for sellers
        # Use enhanced DTE-sensitive gamma risk assessment when available
        gamma_val = greeks.get('gamma', 0)
        
        # Ensure gamma_val is numeric
        try:
            gamma_val = float(gamma_val) if gamma_val is not None else 0.0
        except (ValueError, TypeError):
            gamma_val = 0.0
            if SHOW_DETAILED_RISK_WARNINGS:
                print(f"  [WARNING] Invalid gamma value: {greeks.get('gamma')}, using 0.0")
        
        # Enhanced gamma risk assessment with DTE sensitivity
        if ENABLE_DTE_MULTIPLIER and days_to_expiry is not None:
            # Use enhanced DTE-sensitive gamma risk assessment
            gamma_score, gamma_description = calculate_enhanced_gamma_risk(gamma_val, spot, days_to_expiry)
            
            if gamma_score > 0:
                warnings.append(gamma_description)
                risk_score += gamma_score
                
                if SHOW_DETAILED_RISK_WARNINGS:
                    print(f"  [DEBUG] Enhanced gamma risk: +{gamma_score} points - {gamma_description}")
            else:
                if SHOW_DETAILED_RISK_WARNINGS:
                    print(f"  [DEBUG] Enhanced gamma risk: SAFE (0 points)")
        else:
            # Fallback to legacy gamma assessment
            try:
                spot_price = float(spot) if spot is not None else 0.0
                if spot_price <= 0:
                    if SHOW_DETAILED_RISK_WARNINGS:
                        print(f"  [WARNING] Invalid spot price: {spot}, using legacy threshold")
                    dynamic_gamma_threshold = RISK_ZONE_GAMMA_THRESHOLD
                else:
                    dynamic_gamma_threshold = calculate_dynamic_gamma_threshold(spot_price)
            except (ValueError, TypeError):
                if SHOW_DETAILED_RISK_WARNINGS:
                    print(f"  [WARNING] Invalid spot price type: {type(spot)}, using legacy threshold")
                dynamic_gamma_threshold = RISK_ZONE_GAMMA_THRESHOLD
            
            # Debug: Log gamma calculation for troubleshooting
            if SHOW_DETAILED_RISK_WARNINGS:
                print(f"  [DEBUG] Legacy gamma check: {gamma_val:.6f} vs {dynamic_gamma_threshold:.6f} (spot: {spot_price if 'spot_price' in locals() else spot})")
            
            if gamma_val > dynamic_gamma_threshold:
                warnings.append(f"High gamma: {gamma_val:.6f} > {dynamic_gamma_threshold:.6f} (dynamic threshold)")
                risk_score += RISK_WEIGHT_GAMMA
        
        # 3. Enhanced Theta Risk Assessment - Bi-directional risk detection
        theta_day = greeks.get('theta_per_day', 0.0)
        
        if ENABLE_DTE_MULTIPLIER and days_to_expiry is not None:
            # Enhanced bi-directional theta risk with DTE sensitivity
            theta_score, theta_warnings = calculate_enhanced_theta_risk(theta_day, days_to_expiry)
            
            if theta_score > 0:
                warnings.extend(theta_warnings)
                risk_score += theta_score
                
                if SHOW_DETAILED_RISK_WARNINGS:
                    print(f"  [DEBUG] Enhanced theta risk: +{theta_score} points - {', '.join(theta_warnings)}")
            else:
                if SHOW_DETAILED_RISK_WARNINGS:
                    print(f"  [DEBUG] Enhanced theta risk: SAFE (0 points)")
        else:
            # Fallback to legacy theta assessment
            if RISK_PROFILE == "SELLER":
                # For sellers, slow decay is a risk; very fast decay can be mildly beneficial
                if theta_day > SELLER_SLOW_THETA_THRESHOLD:
                    warnings.append(f"Slow time decay: {theta_day:.4f}")
                    risk_score += RISK_WEIGHT_SLOW_THETA
            else:
                # DEFAULT profile (buyer-style): fast decay considered risky
                if theta_day < RISK_ZONE_THETA_THRESHOLD:
                    warnings.append(f"High time decay: {theta_day:.4f}")
                    risk_score += 2  # Original weight for backward compatibility
        
        # 4. Vega threshold (volatility risk) - normalized by option price if available
        vega_val = greeks.get('vega', 0)
        if option_price and option_price > 0:
            # Normalize vega as percentage of option price
            vega_pct = vega_val / option_price
            if vega_pct > VEGA_NORMALIZED_THRESHOLD:
                warnings.append(f"High normalized vega: {vega_pct:.1%} of option price")
                risk_score += RISK_WEIGHT_VEGA
        else:
            # Fallback to absolute vega threshold
            if vega_val > RISK_ZONE_VEGA_THRESHOLD:
                warnings.append(f"High vega: {vega_val:.4f}")
                risk_score += RISK_WEIGHT_VEGA
        
        # 5. IV Percentile Analysis (for option sellers)
        if ENABLE_IV_PERCENTILE_ANALYSIS and iv_percentile is not None:
            if iv_percentile < IV_PERCENTILE_LOW_THRESHOLD:
                # Low IV environment - risky for sellers (poor premium)
                warnings.append(f"Low IV environment: {iv_percentile}th percentile (unfavorable for sellers)")
                risk_score += 2  # Moderate risk - bad timing for selling
            elif iv_percentile > IV_PERCENTILE_HIGH_THRESHOLD:
                # High IV environment - favorable for sellers (good premium)
                # This is GOOD for sellers, so we can reduce risk slightly
                risk_score = max(0, risk_score - 1)  # Small bonus, capped at 0
                warnings.append(f"High IV environment: {iv_percentile}th percentile (favorable for sellers)")
            
            if SHOW_DETAILED_RISK_WARNINGS and iv_percentile is not None:
                print(f"  [DEBUG] IV Percentile analysis: {iv_percentile}th percentile")
        
        # 6. PCR (Put-Call Ratio) Sentiment Analysis
        if ENABLE_PCR_ANALYSIS and pcr is not None:
            # PCR interpretation for sellers:
            # - Very high PCR (>1.5): Excessive put buying, possible bearish overreaction
            # - Very low PCR (<0.5): Excessive call buying, possible bullish overreaction
            # - Moderate PCR (0.7-1.3): Balanced market
            if pcr > 1.5:
                warnings.append(f"Bearish sentiment (PCR={pcr:.2f}) - potential put overpricing")
            elif pcr < 0.5:
                warnings.append(f"Bullish sentiment (PCR={pcr:.2f}) - potential call overpricing")
            
            if SHOW_DETAILED_RISK_WARNINGS and pcr is not None:
                print(f"  [DEBUG] PCR analysis: {pcr:.2f}")
        
        # Determine overall risk level
        if risk_score >= 5:
            risk_level = "HIGH"
            risk_color = "🔴"
        elif risk_score >= 3:
            risk_level = "MEDIUM"
            risk_color = "🟡"
        elif risk_score >= 1:
            risk_level = "LOW"
            risk_color = "🟢"
        else:
            risk_level = "SAFE"
            risk_color = "✅"
        
        return {
            'warnings': warnings,
            'risk_score': risk_score,
            'risk_level': risk_level,
            'risk_color': risk_color,
            'spot_distance_pct': spot_distance_pct if 'spot_distance_pct' in locals() else 0.0,
            'risk_summary': f"{risk_color} {risk_level} ({risk_score})",
            'iv_percentile': iv_percentile,
            'pcr': pcr
        }
    except Exception as e:
        # Return safe defaults if calculation fails
        return {
            'warnings': [f"Risk calculation error: {e}"],
            'risk_score': 0,
            'risk_level': "UNKNOWN",
            'risk_color': "❓",
            'spot_distance_pct': 0.0,
            'risk_summary': "❓ UNKNOWN (0)"
        }

def display_detailed_risk_warnings(spot, strike, greeks, risk_assessment, option_type):
    """
    Display detailed risk warnings for an option
    """
    try:
        print(f"\n[{option_type}] Risk Analysis for Strike {strike}:")
        print(f"  Spot Distance: {risk_assessment.get('spot_distance_pct', 0):.2f}% from spot {spot}")
        print(f"  Risk Level: {risk_assessment.get('risk_summary', 'Unknown')}")
        
        if risk_assessment.get('warnings'):
            print(f"  Risk Factors:")
            for warning in risk_assessment['warnings']:
                print(f"    ⚠️  {warning}")
        else:
            print(f"  ✅ No significant risk factors detected")
        
        print(f"  Greeks Profile:")
        delta_val = greeks.get('delta', 0.0)
        gamma_val = greeks.get('gamma', 0.0)
        theta_day = greeks.get('theta_per_day', 0.0)
        vega_val = greeks.get('vega', 0.0)

        # Flags according to current risk profile
        try:
            spot_price = float(spot) if spot is not None else 0.0
            if spot_price > 0:
                dynamic_gamma_threshold = calculate_dynamic_gamma_threshold(spot_price)
            else:
                dynamic_gamma_threshold = RISK_ZONE_GAMMA_THRESHOLD
        except (ValueError, TypeError):
            dynamic_gamma_threshold = RISK_ZONE_GAMMA_THRESHOLD
            
        gamma_flag = '⚠️' if gamma_val > dynamic_gamma_threshold else ''
        if RISK_PROFILE == "SELLER":
            theta_flag = '⚠️' if theta_day > SELLER_SLOW_THETA_THRESHOLD else ('✅' if theta_day < SELLER_FAST_THETA_THRESHOLD else '')
            # Use graduated delta scoring for more nuanced delta risk indication
            if ENABLE_GRADUATED_DELTA_SCORING:
                delta_score, delta_risk_level, _ = calculate_graduated_delta_risk_score(abs(delta_val))
                if delta_score >= GRADUATED_DELTA_PEAK_SCORE:
                    delta_flag = '🔴'  # Peak risk
                elif delta_score >= GRADUATED_DELTA_HIGH_SCORE:
                    delta_flag = '🟠'  # High risk
                elif delta_score >= GRADUATED_DELTA_MODERATE_SCORE:
                    delta_flag = '🟡'  # Moderate risk
                elif delta_score >= GRADUATED_DELTA_LIGHT_SCORE:
                    delta_flag = '🟢'  # Light risk
                else:
                    delta_flag = '✅'  # Safe
            else:
                # Fallback to legacy binary delta flag
                delta_flag = '⚠️' if (abs(delta_val) >= RISK_DELTA_ATM_LOWER and abs(delta_val) <= RISK_DELTA_ATM_UPPER) else ''
        else:
            theta_flag = '⚠️' if theta_day < RISK_ZONE_THETA_THRESHOLD else ''
            delta_flag = ''
        vega_flag = '⚠️' if vega_val > RISK_ZONE_VEGA_THRESHOLD else ''

        print(f"    Delta: {delta_val:.4f} {delta_flag}")
        # Show graduated delta risk details for SELLER profile
        if RISK_PROFILE == "SELLER" and ENABLE_GRADUATED_DELTA_SCORING:
            delta_score, delta_risk_level, delta_description = calculate_graduated_delta_risk_score(abs(delta_val))
            if delta_score > 0:
                print(f"      Delta Risk: {delta_risk_level} (+{delta_score} points) - {delta_description}")
            else:
                print(f"      Delta Risk: SAFE (0 points) - {delta_description}")
        print(f"    Gamma: {gamma_val:.6f} {gamma_flag} (threshold: {dynamic_gamma_threshold:.6f})")
        if SHOW_DETAILED_RISK_WARNINGS and ENABLE_DYNAMIC_GAMMA_THRESHOLD:
            print(f"      Dynamic threshold: 1/({DYNAMIC_GAMMA_SCALING_FACTOR} × {spot_price:.1f}) = {dynamic_gamma_threshold:.6f}")
        print(f"    Theta/day: {theta_day:.4f} {theta_flag}")
        print(f"    Vega: {vega_val:.4f} {vega_flag}")
        print(f"    Rho: {greeks.get('rho', 0):.4f}")
    except Exception as e:
        print(f"  [ERROR] Could not display detailed risk warnings: {e}")

# Enhanced IV calculation using Newton-Raphson method - ~50% faster than bisection
def enhanced_implied_vol_newton_raphson(opt_type, S, K, r, t, market_price, initial_guess=0.3):
    """Fast Newton-Raphson IV calculation with fallback"""
    try:
        if market_price <= 0 or t <= 0:
            return None
        
        # Edge case protection: Check for deep ITM/OTM scenarios
        # Calculate theoretical price bounds
        min_theo_price = 0.01  # Minimum theoretical price
        max_theo_price = S * 2.0  # Maximum reasonable theoretical price
        
        if market_price < min_theo_price or market_price > max_theo_price:
            return None
        
        # Check for unrealistic price deviations (deep ITM/OTM)
        if ENABLE_IV_EDGE_CASE_PROTECTION:
            theo_price_atm = bs_price(opt_type, S, K, r, 0.3, t)  # Use 30% IV as reference
            tick_size = 0.05  # Standard tick size for most options
            if abs(market_price - theo_price_atm) > MAX_PRICE_DEVIATION_TICKS * tick_size:
                return None
            
        sigma = max(0.01, min(5.0, initial_guess))
        
        for i in range(50):  # max iterations
            try:
                price = bs_price(opt_type, S, K, r, sigma, t)
                vega_val = bs_vega(S, K, r, sigma, t) * 100  # convert from percentage
                
                if abs(vega_val) < 1e-10:
                    break
                    
                price_diff = price - market_price
                if abs(price_diff) < 1e-6:
                    return sigma
                    
                sigma = sigma - price_diff / vega_val
                sigma = max(0.01, min(5.0, sigma))
                
            except:
                break
                
        return sigma if 0.01 <= sigma <= 5.0 else None
        
    except:
        # Fallback to original bisection method
        return implied_vol_bisection_fallback(opt_type, S, K, r, t, market_price)

def implied_vol_bisection_fallback(opt, S, K, r, t, market_price, lo=0.01, hi=5.0, tol=1e-4, max_iter=100):
    """Fallback bisection method for IV calculation"""
    try:
        pl = bs_price(opt, S, K, r, lo, t) - market_price
        ph = bs_price(opt, S, K, r, hi, t) - market_price
        if pl * ph > 0:
            return None
        for _ in range(max_iter):
            mid = 0.5 * (lo + hi)
            pm = bs_price(opt, S, K, r, mid, t) - market_price
            if abs(pm) < tol:
                return mid
            if pl * pm <= 0:
                hi = mid; ph = pm
            else:
                lo = mid; pl = pm
        return 0.5 * (lo + hi)
    except:
        return None

# Keep the original function name for backward compatibility
def implied_vol_bisection(opt, S, K, r, t, market_price, lo=0.01, hi=5.0, tol=1e-4, max_iter=100):
    """Enhanced IV calculation using Newton-Raphson method with fallback"""
    return enhanced_implied_vol_newton_raphson(opt, S, K, r, t, market_price)

# ------------------ BLACK-76 WITH FUTURES ------------------
def _nd(x):  # standard normal PDF
    return math.exp(-0.5*x*x)/math.sqrt(2*math.pi)

def _ncdf(x):  # standard normal CDF
    # Abramowitz-Stegun approximation
    t = 1.0/(1.0+0.2316419*abs(x))
    d = 0.319381530*t - 0.356563782*t**2 + 1.781477937*t**3 - 1.821255978*t**4 + 1.330274429*t**5
    p = 1.0 - _nd(x)*d
    return p if x>=0 else 1.0-p

def black76_price(F, K, r, T, sigma, is_call=True):
    """Black-76 option pricing using futures price as forward"""
    if sigma<=0 or T<=0 or F<=0 or K<=0: 
        return float('nan')
    vol = sigma*math.sqrt(T)
    d1 = (math.log(F/K) + 0.5*vol*vol) / vol
    d2 = d1 - vol
    df = math.exp(-r*T)
    if is_call:
        return df*(F*_ncdf(d1) - K*_ncdf(d2))
    else:
        return df*(K*_ncdf(-d2) - F*_ncdf(-d1))

def implied_vol_black76(target_px, F, K, r, T, is_call=True, 
                        lo=1e-6, hi=5.0, tol=1e-6, max_iter=60):
    """Robust IV calculation using Black-76: bisection + Newton refinement"""
    # 1) bracket sanity
    plo = black76_price(F,K,r,T,lo,is_call)
    phi = black76_price(F,K,r,T,hi,is_call)
    if not (plo <= target_px <= phi):
        # expand hi once if needed
        hi2 = 10.0
        phi2 = black76_price(F,K,r,T,hi2,is_call)
        if not (plo <= target_px <= phi2):
            return None
        hi, phi = hi2, phi2
    
    # 2) bisection
    for _ in range(max_iter):
        mid = 0.5*(lo+hi)
        pm = black76_price(F,K,r,T,mid,is_call)
        if abs(pm - target_px) < tol: 
            sigma = mid
            break
        if pm < target_px: 
            lo = mid
        else: 
            hi = mid
        sigma = 0.5*(lo+hi)
    
    # 3) two Newton steps using vega for polish (optional)
    for _ in range(2):
        vol = sigma*math.sqrt(T)
        if vol<=0: 
            break
        d1 = (math.log(F/K)+0.5*vol*vol)/vol
        df = math.exp(-r*T)
        vega = df*F*_nd(d1)*math.sqrt(T)  # Black-76 vega
        if vega<=1e-10: 
            break
        price = black76_price(F,K,r,T,sigma,is_call)
        sigma = max(1e-8, sigma - (price-target_px)/vega)
    
    return sigma

# ------------------ DATA HELPERS ------------------
def load_instruments_df(kite): return pd.DataFrame(kite.instruments())

def find_options_for_symbol(df_ins, symbol, expiry_str):
    fno = df_ins[(df_ins["segment"] == "NFO-OPT") & (df_ins["name"] == symbol)].copy()
    
    # DEBUG: Show all available expiries for this symbol
    if not fno.empty:
        available_expiries = sorted(set(fno["expiry"].dt.date))
        print(f"[DEBUG] {symbol}: Found {len(fno)} total options across {len(available_expiries)} expiries")
        print(f"[DEBUG] {symbol}: Available expiries: {available_expiries}")
    else:
        print(f"[DEBUG] {symbol}: No options found in instrument data")
        # Check if symbol exists in other segments
        all_symbols = df_ins[df_ins["name"] == symbol]
        if not all_symbols.empty:
            segments = all_symbols["segment"].unique()
            print(f"[DEBUG] {symbol}: Found in segments: {segments}")
        else:
            print(f"[DEBUG] {symbol}: Symbol not found in any segment")
    
    if expiry_str:
        exp_dt = datetime.fromisoformat(expiry_str)
        if hasattr(exp_dt, "to_pydatetime"):
            exp_dt = exp_dt.to_pydatetime()
        fno["expiry"] = pd.to_datetime(fno["expiry"])
        
        # DEBUG: Show what we're looking for vs what we have
        print(f"[DEBUG] {symbol}: Looking for expiry: {exp_dt.date()}")
        print(f"[DEBUG] {symbol}: Expiry type: {type(exp_dt.date())}")
        
        fno = fno[fno["expiry"].dt.date == exp_dt.date()]
        
        # DEBUG: Show filtering results
        print(f"[DEBUG] {symbol}: After expiry filter: {len(fno)} options")
        if not fno.empty:
            print(f"[DEBUG] {symbol}: Filtered expiries: {sorted(set(fno['expiry'].dt.date))}")
    
    return fno

def get_near_month_future_ltp(kite, df_ins, symbol):
    fut = df_ins[(df_ins["segment"] == "NFO-FUT") & (df_ins["name"] == symbol)].copy()
    if fut.empty: return None
    fut = fut.sort_values("expiry")
    token = fut.iloc[0]["instrument_token"]
    return kite.quote([token])[str(token)]["last_price"]

def batch_quote_ltp_oi(kite, tokens):
    q = kite.quote(tokens)
    return {int(k): {"ltp": v.get("last_price"), "oi": v.get("oi")} for k, v in q.items()}

def get_mid_price_from_quote(quote_data):
    """Extract mid-price from Kite quote data if depth available"""
    try:
        # Check if market depth is available
        if 'depth' in quote_data and quote_data['depth']:
            buy_orders = quote_data['depth'].get('buy', [])
            sell_orders = quote_data['depth'].get('sell', [])
            
            if buy_orders and sell_orders:
                best_bid = buy_orders[0].get('price', 0)
                best_ask = sell_orders[0].get('price', 0)
                
                if best_bid > 0 and best_ask > 0:
                    mid_price = (best_bid + best_ask) / 2
                    return mid_price, True  # (mid_price, is_mid)
        
        # Fallback to LTP if no depth available
        ltp = quote_data.get('last_price', 0)
        return ltp, False  # (ltp, is_mid)
        
    except Exception as e:
        # Fallback to LTP on any error
        ltp = quote_data.get('last_price', 0)
        return ltp, False  # (ltp, is_mid)

def batch_quote_with_mid_price(kite, tokens):
    """Get quotes with mid-price calculation and liquidity data"""
    q = kite.quote(tokens)
    result = {}
    
    for k, v in q.items():
        mid_price, is_mid = get_mid_price_from_quote(v)
        result[int(k)] = {
            "ltp": v.get("last_price"),
            "mid_price": mid_price,
            "is_mid_price": is_mid,
            "oi": v.get("oi"),
            "bid": v.get("bid", 0),
            "ask": v.get("ask", 0),
            "volume": v.get("volume", 0)
        }
    
    return result

# ------------- SUPPLY/DEMAND HELPERS -------------
def compute_atr(df: pd.DataFrame, lookback: int = 14) -> float:
    """
    Enhanced ATR calculation with robust error handling and fallback methods
    """
    try:
        if df.empty or len(df) < lookback:
            print(f"[WARN] Insufficient data for ATR calculation: {len(df)} rows, need {lookback}")
            return 0.0
            
        # Ensure we have the required columns
        required_cols = ['high', 'low', 'close']
        for col in required_cols:
            if col not in df.columns:
                print(f"[ERROR] Missing column '{col}' for ATR calculation")
                return 0.0
        
        # Calculate True Range components with NaN handling
        df = df.copy()
        df['prev_close'] = df['close'].shift(1)
        
        # Handle NaN values in calculations
        h_l = df["high"] - df["low"]
        h_pc = (df["high"] - df["prev_close"]).abs()
        l_pc = (df["low"] - df["prev_close"]).abs()
        
        # Create True Range with proper NaN handling
        tr_df = pd.DataFrame({
            'h_l': h_l.fillna(0),
            'h_pc': h_pc.fillna(0),
            'l_pc': l_pc.fillna(0)
        })
        
        # Get maximum across columns for each row
        tr = tr_df.max(axis=1)
        
        # Calculate ATR with error handling and fallback
        atr_series = tr.rolling(window=lookback, min_periods=max(1, lookback//2)).mean()
        atr_value = atr_series.iloc[-1]
        
        if pd.isna(atr_value) or atr_value <= 0:
            # Fallback 1: Use simple range calculation
            try:
                recent_high = df["high"].iloc[-min(lookback, len(df)):].max()
                recent_low = df["low"].iloc[-min(lookback, len(df)):].min()
                atr_value = (recent_high - recent_low) / lookback
                print(f"[WARN] Using fallback ATR calculation (range): {atr_value:.2f}")
            except:
                atr_value = 0.0
        
        # Fallback 2: If still no valid ATR, use percentage of current price
        if atr_value <= 0:
            try:
                current_price = df["close"].iloc[-1]
                atr_value = current_price * 0.02  # 2% of current price as default
                print(f"[WARN] Using fallback ATR calculation (2% of price): {atr_value:.2f}")
            except:
                atr_value = 1.0  # Absolute fallback
        
        return float(atr_value)
        
    except Exception as e:
        print(f"[ERROR] ATR calculation failed: {e}")
        # Emergency fallback - use simple range
        try:
            if not df.empty:
                recent_high = df["high"].iloc[-min(lookback, len(df)):].max()
                recent_low = df["low"].iloc[-min(lookback, len(df)):].min()
                return float(recent_high - recent_low) / min(lookback, len(df))
        except:
            pass
        return 1.0  # Absolute minimum fallback

def pivot_highs_lows_enhanced(df: pd.DataFrame, window: int = 3) -> Tuple[Optional[float], Optional[float]]:
    """
    Enhanced pivot high/low detection with better zone identification and current price context
    """
    try:
        if df.empty or len(df) < window * 2 + 1:
            print(f"[WARN] Insufficient data for pivot detection: {len(df)} rows, need {window*2+1}")
            return None, None
        
        df = df.copy()
        highs = df['high'].values
        lows = df['low'].values
        closes = df['close'].values
        n = len(df)
        
        supply_levels = []
        demand_levels = []
        
        # Find pivot highs and lows with volume confirmation (if available)
        for i in range(window, n - window):
            # Check for pivot high (supply zone)
            is_pivot_high = True
            current_high = highs[i]
            
            # More stringent pivot high detection
            for j in range(i - window, i + window + 1):
                if j != i and highs[j] >= current_high:
                    is_pivot_high = False
                    break
            
            if is_pivot_high:
                # Add volume confirmation if available
                volume_weight = 1.0
                if 'volume' in df.columns:
                    avg_volume = df['volume'].iloc[i-window:i+window+1].mean()
                    current_volume = df['volume'].iloc[i]
                    if current_volume > avg_volume * 1.2:  # 20% above average
                        volume_weight = 1.5
                
                supply_levels.append({
                    'price': current_high,
                    'index': i,
                    'weight': volume_weight,
                    'recent': i > n - 20  # Recent pivots get higher priority
                })
            
            # Check for pivot low (demand zone)  
            is_pivot_low = True
            current_low = lows[i]
            
            for j in range(i - window, i + window + 1):
                if j != i and lows[j] <= current_low:
                    is_pivot_low = False
                    break
                    
            if is_pivot_low:
                # Add volume confirmation if available
                volume_weight = 1.0
                if 'volume' in df.columns:
                    avg_volume = df['volume'].iloc[i-window:i+window+1].mean()
                    current_volume = df['volume'].iloc[i]
                    if current_volume > avg_volume * 1.2:  # 20% above average
                        volume_weight = 1.5
                
                demand_levels.append({
                    'price': current_low,
                    'index': i,
                    'weight': volume_weight,
                    'recent': i > n - 20  # Recent pivots get higher priority
                })
        
        # Get current price and recent price action for context
        current_price = closes[-1]
        recent_trend = 'neutral'
        
        # Determine recent trend (last 10 bars)
        if len(closes) >= 10:
            recent_closes = closes[-10:]
            if recent_closes[-1] > recent_closes[0] * 1.02:  # 2% uptrend
                recent_trend = 'up'
            elif recent_closes[-1] < recent_closes[0] * 0.98:  # 2% downtrend
                recent_trend = 'down'
        
        # Score and rank supply levels
        if supply_levels:
            for level in supply_levels:
                # Base score from weight
                score = level['weight']
                
                # Bonus for recent pivots
                if level['recent']:
                    score += 0.5
                
                # Bonus for levels near current price (but not too close)
                price_distance = abs(level['price'] - current_price) / current_price
                if 0.05 <= price_distance <= 0.15:  # 5-15% from current price
                    score += 1.0
                elif price_distance <= 0.25:  # 5-25% from current price
                    score += 0.5
                
                # Bonus for levels above current price in uptrend
                if recent_trend == 'up' and level['price'] > current_price:
                    score += 0.3
                
                level['score'] = score
            
            # Sort by score and pick best supply level
            supply_levels.sort(key=lambda x: x['score'], reverse=True)
            supply = supply_levels[0]['price']
        else:
            supply = None
        
        # Score and rank demand levels
        if demand_levels:
            for level in demand_levels:
                # Base score from weight
                score = level['weight']
                
                # Bonus for recent pivots
                if level['recent']:
                    score += 0.5
                
                # Bonus for levels near current price (but not too close)
                price_distance = abs(level['price'] - current_price) / current_price
                if 0.05 <= price_distance <= 0.15:  # 5-15% from current price
                    score += 1.0
                elif price_distance <= 0.25:  # 5-25% from current price
                    score += 0.5
                
                # Bonus for levels below current price in downtrend
                if recent_trend == 'down' and level['price'] < current_price:
                    score += 0.3
                
                level['score'] = score
            
            # Sort by score and pick best demand level
            demand_levels.sort(key=lambda x: x['score'], reverse=True)
            demand = demand_levels[0]['price']
        else:
            demand = None
        
        # Fallback to rolling extremes if no pivots found
        if supply is None:
            supply = float(df["high"].rolling(window * 2 + 1).max().iloc[-1])
            print(f"[WARN] No pivot highs found, using rolling max: {supply:.2f}")
            
        if demand is None:
            demand = float(df["low"].rolling(window * 2 + 1).min().iloc[-1])
            print(f"[WARN] No pivot lows found, using rolling min: {demand:.2f}")
        
        # Validate zone relationship
        if supply is not None and demand is not None:
            if supply <= demand:
                print(f"[WARN] Invalid zones: supply ({supply:.2f}) <= demand ({demand:.2f})")
                # Fix by adjusting levels
                mid_price = (supply + demand) / 2
                supply = mid_price * 1.05  # 5% above mid
                demand = mid_price * 0.95  # 5% below mid
                print(f"[FIX] Adjusted zones: supply={supply:.2f}, demand={demand:.2f}")
        
        return float(supply), float(demand)
        
    except Exception as e:
        print(f"[ERROR] Pivot calculation failed: {e}")
        # Emergency fallback
        try:
            supply = float(df["high"].max())
            demand = float(df["low"].min())
            return supply, demand
        except:
            return None, None


def pivot_highs_lows(df: pd.DataFrame, window: int = 3) -> Tuple[Optional[float], Optional[float]]:
    # Simple swing high/low detection on daily data: returns (supply_level, demand_level)
    supply = None
    demand = None
    for i in range(window, len(df)-window):
        hi = df["high"].iloc[i]
        lo = df["low"].iloc[i]
        if hi == df["high"].iloc[i-window:i+window+1].max():
            supply = hi if (supply is None or hi < supply) else supply  # nearest lower supply
        if lo == df["low"].iloc[i-window:i+window+1].min():
            demand = lo if (demand is None or lo > demand) else demand  # nearest higher demand
    if supply is None:
        supply = float(df["high"].rolling(window*2+1).max().iloc[-1])
    if demand is None:
        demand = float(df["low"].rolling(window*2+1).min().iloc[-1])
    return float(supply), float(demand)

def get_equity_token(df_ins: pd.DataFrame, symbol: str) -> Optional[int]:
    row = df_ins[(df_ins["segment"] == "NSE") & (df_ins["tradingsymbol"] == symbol)]
    if row.empty:
        row = df_ins[(df_ins["exchange"] == "NSE") & (df_ins["tradingsymbol"] == symbol)]
        if row.empty:
            return None
    return int(row.iloc[0]["instrument_token"])

def fetch_daily_candles(kite, token: int, days: int = 120) -> pd.DataFrame:
    to_dt = datetime.now(IST)
    from_dt = to_dt - timedelta(days=days)
    candles = kite.historical_data(token, from_dt, to_dt, interval="day", continuous=False, oi=False)
    df = pd.DataFrame(candles)
    if df.empty:
        return df
    df.rename(columns={"date": "date", "open": "open", "high": "high", "low": "low", "close": "close"}, inplace=True)
    return df

def derive_zones_from_history(kite, df_ins, symbol) -> Tuple[Optional[float], Optional[float], Optional[float]]:
    """
    Enhanced zone derivation with improved pivot detection and zone validation
    """
    # Returns (supply_level, demand_level, atr) from daily history.
    # Tries to import user's custom lux algo zones if available; else uses enhanced pivot method.
    try:
        import supply_demand_lux_algo as lux
        if hasattr(lux, "get_supply_demand_zones"):
            supply, demand = lux.get_supply_demand_zones(symbol)
            atr = lux.get_atr(symbol) if hasattr(lux, "get_atr") else None
            if supply and demand and atr:
                print(f"[INFO] Using custom lux algo zones for {symbol}")
                return float(supply), float(demand), float(atr)
    except Exception as e:
        print(f"[INFO] Custom lux algo not available: {e}")

    # Use enhanced pivot method
    token = get_equity_token(df_ins, symbol)
    if not token:
        print(f"[ERROR] No equity token found for {symbol}")
        return None, None, None
    
    df = fetch_daily_candles(kite, token, days=MAX_HISTORY_DAYS)
    if df.empty or len(df) < ATR_LOOKBACK + 5:
        print(f"[ERROR] Insufficient historical data for {symbol}: {len(df)} rows")
        return None, None, None
    
    # Calculate ATR with enhanced function
    atr = compute_atr(df, ATR_LOOKBACK)
    if atr <= 0:
        print(f"[ERROR] Invalid ATR calculated for {symbol}: {atr}")
        return None, None, None
    
    # Use enhanced pivot detection
    supply, demand = pivot_highs_lows_enhanced(df, SWING_WINDOW)
    if supply is None or demand is None:
        print(f"[ERROR] Could not detect pivots for {symbol}")
        return None, None, None
    
    # Get current price for validation
    current_price = df['close'].iloc[-1]
    
    # Validate zones
    validated_supply, validated_demand = validate_zones(supply, demand, current_price, atr)
    if validated_supply is None or validated_demand is None:
        print(f"[ERROR] Zone validation failed for {symbol}")
        return None, None, None
    
    print(f"[INFO] {symbol} zones: supply={validated_supply:.2f}, demand={validated_demand:.2f}, ATR={atr:.2f}")
    return validated_supply, validated_demand, atr

def pick_sd_writing_strikes(df_opts: pd.DataFrame, supply: float, demand: float, atr: float, spot: float,
                            atr_mult: float, min_oi_lakh: float) -> Optional[Dict]:
    """
    Enhanced strike selection with progressive relaxation of barriers and OI requirements
    
    Note: The 'spot' parameter name is kept for API compatibility, but it represents:
    - FUTURES price (F) when ENABLE_BLACK76_FUTURES=True
    - EQUITY SPOT price (S) when ENABLE_BLACK76_FUTURES=False
    This function only uses it for barrier calculations, not for Greeks computation.
    """
    if atr is None or supply is None or demand is None:
        return None

    dd = df_opts.copy()
    dd["oi_lakh"] = (dd["oi"].fillna(0) / 100000.0)

    # Progressive relaxation levels with FLOOR CONSTRAINTS
    # CRITICAL: Maintain minimum standards to preserve strategy integrity
    relaxation_levels = []
    if ENABLE_PROGRESSIVE_RELAXATION:
        for i in range(MAX_RELAXATION_LEVELS):
            # Calculate relaxation factors with floor constraints
            atr_mult_factor = max(MIN_ATR_BUFFER_FACTOR, 1.0 - (i * RELAXATION_STEP))
            oi_mult_factor = max(MIN_OI_FACTOR, 1.0 - (i * RELAXATION_OI_STEP))
            
            level_name = "Standard" if i == 0 else f"Relaxed Level {i}"
            
            # Only add level if it's meaningfully different from previous
            if i == 0 or (atr_mult_factor < 1.0 or oi_mult_factor < 1.0):
                relaxation_levels.append({
                    "atr_mult": atr_mult * atr_mult_factor,
                    "oi_mult": oi_mult_factor,
                    "atr_mult_factor": atr_mult_factor,
                    "oi_mult_factor": oi_mult_factor,
                    "description": level_name
                })
    else:
        # Single level without relaxation
        relaxation_levels = [{
            "atr_mult": atr_mult,
            "oi_mult": 1.0,
            "atr_mult_factor": 1.0,
            "oi_mult_factor": 1.0,
            "description": "Standard"
        }]
    
    # Fail-safe: If no meaningful relaxation levels, use standard only
    if not relaxation_levels:
        relaxation_levels = [{
            "atr_mult": atr_mult,
            "oi_mult": 1.0,
            "atr_mult_factor": 1.0,
            "oi_mult_factor": 1.0,
            "description": "Standard"
        }]

    for level in relaxation_levels:
        current_atr_mult = level["atr_mult"]
        current_oi_mult = level["oi_mult"]
        current_min_oi = min_oi_lakh * current_oi_mult
        
        # Display relaxation details with floor constraints
        atr_pct = level.get("atr_mult_factor", 1.0) * 100
        oi_pct = level.get("oi_mult_factor", 1.0) * 100
        print(f"[STRIKE-SELECT] Trying {level['description']}: "
              f"ATR buffer={current_atr_mult:.2f} ({atr_pct:.0f}% of intended), "
              f"OI min={current_min_oi:.2f}L ({oi_pct:.0f}% of minimum)")
        
        ce_barrier = supply + current_atr_mult * atr
        pe_barrier = demand - current_atr_mult * atr

        # Apply barriers with current settings
        calls = dd[(dd["instrument_type"] == "CE") & 
                   (dd["oi_lakh"] >= current_min_oi) & 
                   (dd["strike"] >= ce_barrier)]
        puts = dd[(dd["instrument_type"] == "PE") & 
                  (dd["oi_lakh"] >= current_min_oi) & 
                  (dd["strike"] <= pe_barrier)]

        if not calls.empty and not puts.empty:
            # Found strikes with current settings
            ce_pick = calls.sort_values("strike").iloc[0].to_dict()
            pe_pick = puts.sort_values("strike", ascending=False).iloc[0].to_dict()
            
            print(f"[STRIKE-SELECT] Success with {level['description']} settings")
            print(f"[STRIKE-SELECT] CE barrier: {ce_barrier:.2f}, selected: {ce_pick['strike']}")
            print(f"[STRIKE-SELECT] PE barrier: {pe_barrier:.2f}, selected: {pe_pick['strike']}")
            
            return {
                "ce": ce_pick,
                "pe": pe_pick,
                "ce_barrier": ce_barrier,
                "pe_barrier": pe_barrier,
                "supply": supply,
                "demand": demand,
                "atr": atr,
                "atr_mult_used": current_atr_mult,
                "oi_mult_used": current_oi_mult,
                "relaxation_level": level['description']
            }
        else:
            # Log what was found at this level
            ce_count = len(calls)
            pe_count = len(puts)
            print(f"[STRIKE-SELECT] Level failed: CE={ce_count}, PE={pe_count}")
            
            if ce_count == 0:
                print(f"[STRIKE-SELECT] No CE strikes above barrier {ce_barrier:.2f}")
            if pe_count == 0:
                print(f"[STRIKE-SELECT] No PE strikes below barrier {pe_barrier:.2f}")
    
    # If we get here, no strikes found even with maximum relaxation
    print("[STRIKE-SELECT] No strikes found even with maximum relaxation")
    return None

def validate_zones(supply: float, demand: float, current_price: float, atr: float) -> Tuple[Optional[float], Optional[float]]:
    """
    Validate supply/demand zones and reject invalid ones instead of creating artificial zones
    """
    try:
        if supply is None or demand is None or current_price is None:
            return None, None
        
        # Basic validation: supply must be above demand
        if supply <= demand:
            print(f"[REJECT] Invalid zones: supply ({supply:.2f}) <= demand ({demand:.2f}) - rejecting artificial zones")
            return None, None
        
        # Ensure zones are not too far from current price
        max_distance = atr * MAX_ZONE_DISTANCE_ATR if atr else current_price * 0.3
        
        # Check supply zone distance
        supply_distance = abs(supply - current_price)
        if supply_distance > max_distance:
            print(f"[REJECT] Supply zone too far: {supply_distance:.2f} > {max_distance:.2f} - rejecting distant zones")
            return None, None
        
        # Check demand zone distance
        demand_distance = abs(demand - current_price)
        if demand_distance > max_distance:
            print(f"[REJECT] Demand zone too far: {demand_distance:.2f} > {max_distance:.2f} - rejecting distant zones")
            return None, None
        
        # Validate minimum separation between zones
        min_separation = atr * MIN_ZONE_SEPARATION_ATR if atr else current_price * 0.05
        zone_separation = abs(supply - demand)
        if zone_separation < min_separation:
            print(f"[REJECT] Zones too close: {zone_separation:.2f} < {min_separation:.2f} - rejecting overlapping zones")
            return None, None
        
        # Additional validation: zones should be on opposite sides of current price
        if (supply < current_price and demand < current_price) or (supply > current_price and demand > current_price):
            print(f"[REJECT] Zones on same side of current price - rejecting invalid positioning")
            return None, None
        
        # Final validation
        if supply <= demand:
            print(f"[ERROR] Final validation failed: supply ({supply:.2f}) <= demand ({demand:.2f})")
            return None, None
        
        print(f"[INFO] Valid zones: supply={supply:.2f}, demand={demand:.2f}")
        return float(supply), float(demand)
        
    except Exception as e:
        print(f"[ERROR] Zone validation failed: {e}")
        return None, None

def display_enhanced_features():
    """
    Display the enhanced supply/demand system features
    """
    print("\n" + "="*80)
    print("ENHANCED SUPPLY/DEMAND OPTIONS WRITING SYSTEM")
    print("="*80)
    print("Key Improvements Implemented:")
    print("1. ✅ Robust ATR Calculation")
    print("   - Multiple fallback methods")
    print("   - NaN value handling")
    print("   - Division by zero protection")
    print("   - Insufficient data handling")
    
    print("\n2. ✅ Enhanced Pivot Detection")
    print("   - Volume-weighted scoring")
    print("   - Recent pivot prioritization")
    print("   - Price context awareness")
    print("   - Trend-based scoring")
    
    print("\n3. ✅ Zone Validation & Rejection")
    print("   - Supply > Demand enforcement")
    print("   - Maximum distance limits")
    print("   - Minimum separation requirements")
    print("   - Reject invalid zones (no artificial creation)")
    
    print("\n4. ✅ Progressive Strike Selection")
    print("   - Multiple relaxation levels")
    print("   - Configurable ATR barriers")
    print("   - Flexible OI requirements")
    print("   - Detailed selection logging")
    
    print("\n5. ✅ Dynamic Delta Targeting")
    print("   - Adaptive delta based on DTE")
    print("   - Short-dated: Lower deltas (0.15)")
    print("   - Long-dated: Higher deltas (0.20-0.25)")
    print("   - Configurable scaling factors")
    
    print("\n6. ✅ Trading-Day Adjusted Theta")
    print("   - Weekend-aware theta calculation")
    print("   - Holiday-adjusted decay rates")
    print("   - More accurate daily time decay")
    print("   - Both calendar and trading day theta")
    
    print("\n7. ✅ Market Liquidity Validation")
    print("   - Bid-ask spread analysis")
    print("   - Volume and OI validation")
    print("   - Liquidity scoring (0-100)")
    print("   - Automatic illiquid option rejection")
    
    print("\n8. ✅ Performance Optimizations")
    print("   - Greeks calculation caching")
    print("   - Centralized OI calculations")
    print("   - Eliminated duplicate computations")
    print("   - Cache efficiency monitoring")
    
    print("\n8. ✅ Calculation Accuracy Improvements")
    print("   - Consistent theta per day calculation")
    print("   - IV edge case protection (deep ITM/OTM)")
    print("   - Delta sign validation for calls vs puts")
    print("   - Configurable price deviation limits")
    
    print("\n9. ✅ Configuration Options")
    print(f"   - ATR Lookback: {ATR_LOOKBACK}")
    print(f"   - Swing Window: {SWING_WINDOW}")
    print(f"   - ATR Buffer: {ATR_BUFFER_MULT}")
    print(f"   - Max Zone Distance: {MAX_ZONE_DISTANCE_ATR} ATR")
    print(f"   - Min Zone Separation: {MIN_ZONE_SEPARATION_ATR} ATR")
    if ENABLE_PROGRESSIVE_RELAXATION:
        print(f"   - Progressive Relaxation: ✅ ENABLED (LIMITED)")
        print(f"     • Max Attempts: {MAX_RELAXATION_LEVELS} (professional fail-fast approach)")
        print(f"     • ATR Buffer Floor: {MIN_ATR_BUFFER_FACTOR*100:.0f}% (maintain zone protection)")
        print(f"     • OI Floor: {MIN_OI_FACTOR*100:.0f}% (maintain liquidity)")
        print(f"     • Philosophy: If good strikes don't exist → SKIP symbol")
    else:
        print(f"   - Progressive Relaxation: ❌ DISABLED (strict criteria only)")
    
    # Display Dynamic Delta Targeting Configuration
    if ENABLE_DYNAMIC_DELTA:
        print(f"\n🎯 DYNAMIC DELTA TARGETING CONFIGURATION:")
        print(f"   Status: ✅ ENABLED (PROFESSIONAL GAMMA-RISK ADJUSTED)")
        print(f"   Base Delta (Monthly): {BASE_DELTA_TARGET:.3f} (82% OTM)")
        print(f"   Min Delta (0-3 DTE): {MIN_DELTA_TARGET:.3f} (95%+ OTM - EXTREME gamma protection)")
        print(f"   Max Delta (>90 DTE): {MAX_DELTA_TARGET:.3f} (75% OTM - low gamma risk)")
        print(f"   Ultra-Short Exit: {'✅ ENABLED' if FORCE_EXIT_ULTRA_SHORT else '❌ DISABLED'} (force exit at 0-3 DTE)")
        print(f"\n   📊 Delta Progression (Professional Gamma-Aware):")
        print(f"      0-3 DTE:  ~0.05 delta (95%+ OTM) {'🚨 FORCED EXIT' if FORCE_EXIT_ULTRA_SHORT else '⚠️  EXTREME gamma zone'}")
        print(f"      4-7 DTE:  ~0.09 delta (91% OTM) - HIGH gamma risk")
        print(f"      8-14 DTE: ~0.12 delta (88% OTM) - Moderate gamma")
        print(f"      15-21 DTE: ~0.15 delta (85% OTM) - Transitioning")
        print(f"      22-30 DTE: ~0.18 delta (82% OTM) - Standard monthly")
        print(f"      31-60 DTE: ~0.20 delta (80% OTM) - LOW gamma")
        print(f"      61-90 DTE: ~0.22 delta (78% OTM) - VERY low gamma")
        print(f"      >90 DTE:  ~0.25 delta (75% OTM) - Minimal gamma")
        print(f"\n   💡 Logic: EXIT or go FAR OTM near expiry (professional behavior)")
    else:
        print(f"\n🎯 DYNAMIC DELTA TARGETING: ❌ DISABLED (Using fixed target: {TARGET_ABS_DELTA:.3f})")
    
    # Display Trading-Day Theta Configuration
    if ENABLE_TRADING_DAY_THETA:
        print(f"\n⏰ TRADING-DAY ADJUSTED THETA CONFIGURATION:")
        print(f"   Status: ✅ ENABLED")
        print(f"   Show Comparison: {'✅ ENABLED' if SHOW_THETA_COMPARISON else '❌ DISABLED'}")
        print(f"   Holiday Calendar: Major Indian market holidays included")
    else:
        print(f"\n⏰ TRADING-DAY ADJUSTED THETA: ❌ DISABLED (Using calendar day theta)")
    
    # Display IV Edge Case Protection Configuration
    if ENABLE_IV_EDGE_CASE_PROTECTION:
        print(f"\n🛡️ IV EDGE CASE PROTECTION CONFIGURATION:")
        print(f"   Status: ✅ ENABLED")
        print(f"   Max Price Deviation: {MAX_PRICE_DEVIATION_TICKS} tick sizes")
        print(f"   Deep ITM/OTM Protection: Active")
    else:
        print(f"\n🛡️ IV EDGE CASE PROTECTION: ❌ DISABLED")
    
    # Display Performance Optimization Configuration
    print(f"\n🚀 PERFORMANCE OPTIMIZATION CONFIGURATION:")
    print(f"   Greeks Caching: ✅ ENABLED")
    print(f"   Cache Monitoring: ✅ ENABLED")
    print(f"   OI Calculation Centralization: ✅ ENABLED")
    
    # Display Market Liquidity Validation Configuration
    if ENABLE_LIQUIDITY_VALIDATION:
        print(f"\n💧 MARKET VALIDATION CONFIGURATION:")
        print(f"   Status: ✅ ENABLED")
        print(f"   Strategy: {VALIDATION_STRATEGY}")
        
        if VALIDATION_STRATEGY == "MONTHLY_WRITING":
            print(f"   Minimum Execution Score: {MIN_EXECUTION_SCORE}/100")
            print(f"   Focus: OI coverage, strike distribution, market structure")
            print(f"   Benefits: Monthly writing optimized, execution confidence, slippage estimation")
            print(f"   Strategic Analysis: {'✅ ENABLED' if ENABLE_STRATEGIC_ANALYSIS else '❌ DISABLED'}")
        else:
            print(f"   Minimum Liquidity Score: {MIN_LIQUIDITY_SCORE}/100")
            print(f"   Reject Extreme Spreads: {'✅ ENABLED' if REJECT_EXTREME_SPREADS else '❌ DISABLED'}")
            print(f"   Reject Low Volume: {'✅ ENABLED' if REJECT_LOW_VOLUME else '❌ DISABLED'}")
            print(f"   Reject Low OI: {'✅ ENABLED' if REJECT_LOW_OI else '❌ DISABLED'}")
            print(f"   Benefits: Intraday liquidity focused, real-time bid/ask validation")
        
        print(f"   Adaptive Scoring: {'✅ ENABLED' if ENABLE_ADAPTIVE_SCORING else '❌ DISABLED'} (relaxes criteria when market closed)")
    else:
        print(f"\n💧 MARKET VALIDATION: ❌ DISABLED (Trading all options regardless of liquidity)")
    
    # Display Current Market Status
    is_open, reason, current_time = detect_market_status()
    market_status_icon = "🟢" if is_open else "🔴"
    print(f"\n📊 CURRENT MARKET STATUS:")
    print(f"   Status: {market_status_icon} {'OPEN' if is_open else 'CLOSED'}")
    print(f"   Reason: {reason}")
    print(f"   Current Time: {current_time.strftime('%Y-%m-%d %H:%M:%S %Z')}")
    if not is_open and ENABLE_ADAPTIVE_SCORING:
        print(f"   Adaptive Liquidity Score: {max(50, MIN_LIQUIDITY_SCORE - 20)}/100 (relaxed)")
    elif not is_open:
        print(f"   Note: Market closed but adaptive scoring disabled - using fixed criteria")
    
    # Display Black-76 with Futures Configuration
    if ENABLE_BLACK76_FUTURES:
        print(f"\n🔬 BLACK-76 WITH FUTURES CONFIGURATION:")
        print(f"   Status: ✅ ENABLED")
        print(f"   Risk-Free Rate: {BLACK76_RISK_FREE_RATE*100:.1f}%")
        print(f"   Mid-Price Usage: {'✅ ENABLED' if BLACK76_USE_MID_PRICE else '❌ DISABLED'}")
        print(f"   Black-Scholes Fallback: {'✅ ENABLED' if BLACK76_FALLBACK_TO_BS else '❌ DISABLED'}")
        print(f"   Benefits: Futures-based pricing, dividend-adjusted, robust IV calculation")
    else:
        print(f"\n🔬 BLACK-76 WITH FUTURES: ❌ DISABLED (Using traditional Black-Scholes)")
    
    # Display Real Market IV Data Integration Configuration
    if ENABLE_MARKET_IV_DATA:
        print(f"\n📊 REAL MARKET IV DATA INTEGRATION:")
        print(f"   Status: ✅ ENABLED (WITH STALENESS & SKEW PROTECTION)")
        print(f"   Data Path: {MARKET_IV_DATA_PATH}")
        print(f"   Auto-detect Latest: {'✅ ENABLED' if MARKET_IV_USE_LATEST else '❌ DISABLED'}")
        print(f"   Max Data Age: {MARKET_IV_MAX_AGE_HOURS} hours (staleness check)")
        print(f"   ATM Range: ±{MARKET_IV_ATM_RANGE_PCT}% (tighter = respects volatility skew)")
        print(f"   Fallback IV: {MARKET_IV_FALLBACK_DEFAULT*100:.0f}%")
        print(f"   Validation: Null checking, range validation (0-200%)")
        print(f"   IV Percentile Analysis: {'✅ ENABLED' if ENABLE_IV_PERCENTILE_ANALYSIS else '❌ DISABLED'}")
        if ENABLE_IV_PERCENTILE_ANALYSIS:
            print(f"     Low IV Threshold: {IV_PERCENTILE_LOW_THRESHOLD}th percentile (risky for sellers)")
            print(f"     High IV Threshold: {IV_PERCENTILE_HIGH_THRESHOLD}th percentile (favorable for sellers)")
        print(f"   PCR Analysis: {'✅ ENABLED' if ENABLE_PCR_ANALYSIS else '❌ DISABLED'}")
        print(f"   Max Pain Awareness: {'✅ ENABLED' if ENABLE_MAX_PAIN_AWARENESS else '❌ DISABLED'}")
        print(f"   Benefits: Fresh ATM IV, skew-aware, IV percentile, market sentiment")
    else:
        print(f"\n📊 REAL MARKET IV DATA: ❌ DISABLED (Using calculated IV only)")
    
    # Display Combined Strangle Metrics Configuration
    print(f"\n📊 COMBINED STRANGLE-LEVEL METRICS:")
    print(f"   Total Theta (Decay): ✅ ENABLED")
    print(f"   Total Vega (IV Sensitivity): ✅ ENABLED")
    print(f"   Breakeven Analysis: ✅ ENABLED")
    print(f"   ROM (Return on Margin): ✅ ENABLED")
    print(f"   Margin Estimation: 20% of underlying value")
    print(f"   Trade-Ready CSV: ✅ FULLY IMPLEMENTED")
    
    print("\n" + "="*80)

# ------------------ MAIN STRATEGIES ------------------
def run_equal_delta_strategy(kite, ins_df, symbol, expiry_dt):
    print(f"\n[EQUAL-DELTA] {symbol} → Expiry: {expiry_dt.date()}")
    
    # Load market IV data for this symbol
    iv_data_df = None
    csv_path = None
    symbol_iv_data = None
    if ENABLE_MARKET_IV_DATA:
        iv_data_df, csv_path = load_market_iv_data()
        if iv_data_df is not None:
            symbol_iv_data = get_symbol_market_iv_data(symbol, iv_data_df, csv_path)
    
    opts = find_options_for_symbol(ins_df, symbol, expiry_dt.strftime("%Y-%m-%d"))
    if opts.empty:
        print(f"[WARN] No options for {symbol} @ {expiry_dt.date()}")
        return None

    # CRITICAL: Choose underlying price based on model
    # Black-76 uses FUTURES (F) - already includes cost-of-carry
    # Black-Scholes uses EQUITY SPOT (S) - needs dividend adjustment
    if ENABLE_BLACK76_FUTURES:
        # Black-76: Get FUTURES price (F)
        underlying_price = get_near_month_future_ltp(kite, ins_df, symbol)
        if underlying_price is None:
            print(f"[ERROR] {symbol}: No futures price available for Black-76, skipping")
            return None
        print(f"[EQUAL-DELTA] Using Black-76 model with FUTURES price (F): {underlying_price:.2f}")
    else:
        # Black-Scholes: Get EQUITY SPOT price (S)
        underlying_price = kite.ltp([f"NSE:{symbol}"])[f"NSE:{symbol}"]["last_price"]
        print(f"[EQUAL-DELTA] Using Black-Scholes model with EQUITY SPOT price (S): {underlying_price:.2f}")
        print(f"[EQUAL-DELTA] Dividend yield: {BLACK_SCHOLES_DIVIDEND_YIELD*100:.2f}% (for cost-of-carry)")

    # Use enhanced quote function with mid-price support
    if ENABLE_BLACK76_FUTURES:
        qmap = batch_quote_with_mid_price(kite, opts["instrument_token"].astype(int).tolist())
        opts["ltp"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("ltp"))
        opts["mid_price"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("mid_price"))
        opts["is_mid_price"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("is_mid_price"))
        opts["oi"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("oi"))
        opts["bid"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("bid"))
        opts["ask"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("ask"))
        opts["volume"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("volume"))
        print(f"[EQUAL-DELTA] Strikes fetched: {len(opts)} (with mid-price support)")
    else:
        qmap = batch_quote_ltp_oi(kite, opts["instrument_token"].astype(int).tolist())
        opts["ltp"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("ltp"))
        opts["oi"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("oi"))
        print(f"[EQUAL-DELTA] Strikes fetched: {len(opts)}")
    
    # Apply strategy-appropriate validation
    if VALIDATION_STRATEGY == "MONTHLY_WRITING":
        print(f"[MONTHLY-WRITING] Assessing execution quality for {len(opts)} options...")
        opts = filter_monthly_writing_options(opts, min_execution_score=MIN_EXECUTION_SCORE)
        
        if opts.empty:
            print(f"[MONTHLY-WRITING] No executable options found for {symbol} after validation")
            return None
        
        print(f"[MONTHLY-WRITING] {get_monthly_execution_summary(opts)}")
    else:
        # Use traditional liquidity validation
        print(f"[LIQUIDITY] Validating market liquidity for {len(opts)} options...")
        
        # Get adaptive liquidity score based on market status
        adaptive_score, score_reason = get_adaptive_liquidity_score()
        print(f"[LIQUIDITY] {score_reason}")
        
        opts = filter_liquid_options(opts, min_liquidity_score=adaptive_score)
        
        if opts.empty:
            print(f"[LIQUIDITY] No liquid options found for {symbol} after validation")
            return None
        
        print(f"[LIQUIDITY] {get_liquidity_summary(opts)}")

    t = year_fraction_to_expiry(expiry_dt.astimezone(IST))
    
    # Dynamic Delta Targeting based on DTE
    dte_days = int(t * 365)  # Convert to days
    dynamic_delta_target = calculate_dynamic_delta_target(dte_days, TARGET_ABS_DELTA)
    print(f"[EQUAL-DELTA] DTE: {dte_days} days, Base Delta: {TARGET_ABS_DELTA:.3f}, Dynamic Target: {dynamic_delta_target:.3f}")
    
    # Calculate trading days for accurate theta
    trading_days = count_trading_days_to_expiry(expiry_dt.astimezone(IST))
    print(f"[EQUAL-DELTA] Trading Days to Expiry: {trading_days} (vs {dte_days} calendar days)")
    
    rows = []
    for _, row in opts.iterrows():
        K = float(row["strike"]); typ = row["instrument_type"]
        
        # Choose price: mid-price if available and enabled, else LTP
        if ENABLE_BLACK76_FUTURES and row.get("is_mid_price", False):
            option_price = row.get("mid_price", 0)
            price_type = "mid"
        else:
            option_price = row.get("ltp", 0)
            price_type = "ltp"
            
        if not option_price or option_price <= 0: continue
        
        # Calculate IV using appropriate method
        # First, try to use real market ATM IV for VERY near-ATM strikes only (respects skew)
        use_market_iv = False
        if ENABLE_MARKET_IV_DATA and symbol_iv_data and symbol_iv_data.get('data_available'):
            # Only use ATM IV if data is fresh (not stale)
            data_is_stale = symbol_iv_data.get('data_stale', False)
            
            if not data_is_stale:
                # Check if strike is near ATM or can use skew interpolation
                strike_distance_pct = abs(K - underlying_price) / underlying_price * 100
                
                # Validate ATM IV before using
                atm_iv = symbol_iv_data.get('atm_iv')
                if atm_iv is not None and pd.notna(atm_iv) and atm_iv > 0 and atm_iv < 200:  # Sanity check
                    if strike_distance_pct <= MARKET_IV_ATM_RANGE_PCT:  # Near ATM (within 5%)
                        # Use ATM IV directly for near-ATM strikes
                        iv = atm_iv / 100.0  # Convert from percentage to decimal
                        use_market_iv = True
                        print(f"[MARKET-IV] Using real ATM IV={iv*100:.1f}% for {row['tradingsymbol']} "
                              f"({strike_distance_pct:.1f}% from ATM)")
                    elif strike_distance_pct <= 15.0:  # 5-15% OTM - use skew interpolation
                        # Apply skew-aware interpolation for moderately OTM strikes
                        atm_iv_decimal = atm_iv / 100.0
                        iv = interpolate_iv_with_skew(atm_iv_decimal, strike_distance_pct)
                        use_market_iv = True
                        print(f"[MARKET-IV] Using skew-interpolated IV={iv*100:.1f}% (ATM={atm_iv:.1f}% + {(iv-atm_iv_decimal)*100:.1f}% skew) "
                              f"for {row['tradingsymbol']} ({strike_distance_pct:.1f}% from ATM)")
                else:
                    print(f"[MARKET-IV] Invalid ATM IV={atm_iv} for {symbol}, calculating IV from price")
            else:
                # Data is stale - log warning and fall back to calculation
                data_age = symbol_iv_data.get('data_age_hours', 0)
                print(f"[MARKET-IV] Data is {data_age:.1f} hours old (stale) - calculating IV from price for {row['tradingsymbol']}")
        
        # If not using market IV, calculate IV from option price
        if not use_market_iv:
            if ENABLE_BLACK76_FUTURES:
                # Use Black-76 IV calculation with FUTURES price (F)
                is_call = (typ == "CE")
                iv = implied_vol_black76(option_price, underlying_price, K, BLACK76_RISK_FREE_RATE, t, is_call)
                
                # Fallback to Black-Scholes if Black-76 fails
                if iv is None and BLACK76_FALLBACK_TO_BS:
                    iv = implied_vol_bisection("C" if typ == "CE" else "P", underlying_price, K, RISK_FREE_RATE, t, option_price)
                    if iv is not None:
                        print(f"[INFO] Black-76 failed for {row['tradingsymbol']}, using Black-Scholes fallback")
            else:
                # Use Black-Scholes IV calculation with EQUITY SPOT price (S)
                iv = implied_vol_bisection("C" if typ == "CE" else "P", underlying_price, K, RISK_FREE_RATE, t, option_price)
        
        # IV Surface Validation: Compare market IV vs calculated IV (if we used market data)
        if use_market_iv and iv is not None:
            # Calculate IV from option price for validation
            if ENABLE_BLACK76_FUTURES:
                is_call = (typ == "CE")
                calculated_iv = implied_vol_black76(option_price, underlying_price, K, BLACK76_RISK_FREE_RATE, t, is_call)
                if calculated_iv is None and BLACK76_FALLBACK_TO_BS:
                    calculated_iv = implied_vol_bisection("C" if typ == "CE" else "P", underlying_price, K, RISK_FREE_RATE, t, option_price)
            else:
                calculated_iv = implied_vol_bisection("C" if typ == "CE" else "P", underlying_price, K, RISK_FREE_RATE, t, option_price)
            
            # Check for significant mismatch (>10% relative difference)
            if calculated_iv is not None:
                iv_diff_pct = abs(calculated_iv - iv) / iv
                if iv_diff_pct > 0.10:  # >10% relative difference
                    print(f"⚠️  IV MISMATCH for {row['tradingsymbol']}: "
                          f"Market/Interpolated={iv*100:.1f}%, Calculated={calculated_iv*100:.1f}% "
                          f"(Δ={iv_diff_pct*100:.1f}%)")
            
        if iv is None: continue
        
        # Calculate all Greeks for enhanced analysis with trading-day adjusted theta
        opt_type = "C" if typ == "CE" else "P"
        
        if ENABLE_BLACK76_FUTURES:
            # Use Black-76 Greeks with FUTURES price (F)
            greeks = calculate_black76_greeks(opt_type, underlying_price, K, BLACK76_RISK_FREE_RATE, iv, t, trading_days)
        else:
            # Use Black-Scholes Greeks with EQUITY SPOT price (S)
            # Note: Caching removed - each strike has unique IV, no benefit
            greeks = calculate_all_greeks(opt_type, underlying_price, K, RISK_FREE_RATE, iv, t, trading_days)
        
        # Theta is already properly scaled in calculate_all_greeks function
        # No additional scaling needed here
        
        # Calculate risk zone warnings with DTE sensitivity and IV data
        iv_percentile = symbol_iv_data.get('iv_percentile') if symbol_iv_data else None
        pcr = symbol_iv_data.get('pcr') if symbol_iv_data else None
        risk_assessment = calculate_risk_zone_warnings(underlying_price, K, greeks, option_price, trading_days, iv_percentile, pcr)
        
        rows.append({
            "tradingsymbol": row["tradingsymbol"], "strike": K, "type": typ,
            "ltp": option_price, "oi_lakh": (row.get("oi") or 0)/100000.0, "iv": iv,
            "delta": greeks["delta"],
            "gamma": greeks["gamma"],
            "theta": greeks["theta"],
            "theta_per_day": greeks["theta_per_day"],
            "theta_per_trading_day": greeks["theta_per_trading_day"],
            "vega": greeks["vega"],
            "rho": greeks["rho"],
            "risk_level": risk_assessment["risk_level"],
            "risk_score": risk_assessment["risk_score"],
            "risk_summary": risk_assessment["risk_summary"],
            "spot_distance_pct": risk_assessment["spot_distance_pct"],
            # Add strategic analysis columns
            "execution_score": row.get("execution_score", 0),
            "confidence_level": row.get("confidence_level", "UNKNOWN"),
            "expected_slippage": row.get("expected_slippage", "Unknown")
        })
    
    dd = pd.DataFrame(rows)
    dd = dd[dd["oi_lakh"] >= MIN_OI_LAKH]
    
    # Add strategic monthly writing analysis
    if not dd.empty and VALIDATION_STRATEGY == "MONTHLY_WRITING" and ENABLE_STRATEGIC_ANALYSIS:
        print(f"\n🎯 STRATEGIC ANALYSIS FOR {symbol}:")
        
        # Find best CE/PE pair (with safety check)
        ce_options = dd[dd["type"] == "CE"].sort_values("risk_score")
        pe_options = dd[dd["type"] == "PE"].sort_values("risk_score")
        
        if not ce_options.empty and not pe_options.empty:
            best_ce = ce_options.iloc[0]
            best_pe = pe_options.iloc[0]
            
            # Perform strategic analysis
            strategic_analysis = analyze_strategic_monthly_writing(best_ce, best_pe, underlying_price)
            display_strategic_analysis(strategic_analysis, symbol)
        else:
            print(f"[WARN] Insufficient options for strategic analysis (CE: {len(ce_options)}, PE: {len(pe_options)})")
    if dd.empty:
        print("[EQUAL-DELTA] After OI filter: 0 strikes")
        return None
    calls = dd[dd["type"] == "CE"].copy()
    puts  = dd[dd["type"] == "PE"].copy()
    if calls.empty or puts.empty:
        print("[EQUAL-DELTA] Missing CE/PE after filter")
        return None
    # Proper delta targeting: calls target positive delta, puts target negative delta
    calls["delta_diff"] = (calls["delta"] - dynamic_delta_target).abs()  # Calls: +0.18 target
    puts["delta_diff"]  = (puts["delta"] + dynamic_delta_target).abs()  # Puts: -0.18 target
    ce = calls.sort_values(["delta_diff", "strike"]).iloc[0].to_dict()
    pe = puts.sort_values(["delta_diff", "strike"]).iloc[0].to_dict()
    
    # Validate delta signs for proper strike selection
    # Calls should have positive delta, puts should have negative delta
    if ce['delta'] <= 0:
        print(f"[WARN] Selected CE has non-positive delta: {ce['delta']:.3f}, may be ITM")
    if pe['delta'] >= 0:
        print(f"[WARN] Selected PE has non-negative delta: {pe['delta']:.3f}, may be ITM")
    
    # Ensure IV is available for risk calculations
    ce['iv'] = ce.get('iv', 0.3)  # Default IV if not available
    pe['iv'] = pe.get('iv', 0.3)  # Default IV if not available

    print(f"[EQUAL-DELTA][RESULT] CE {ce['tradingsymbol']} Δ={ce['delta']:.3f} Γ={ce['gamma']:.6f} Θ={ce['theta_per_day']:.4f} LTP={ce['ltp']} OI={ce['oi_lakh']:.2f}L {ce['risk_summary']}")
    print(f"[EQUAL-DELTA][RESULT] PE {pe['tradingsymbol']} Δ={pe['delta']:.3f} Γ={pe['gamma']:.6f} Θ={pe['theta_per_day']:.4f} LTP={pe['ltp']} OI={pe['oi_lakh']:.2f}L {pe['risk_summary']}")
    print(f"[EQUAL-DELTA][RISK] Overall Risk: {ce['risk_level'] if ce['risk_score'] > pe['risk_score'] else pe['risk_level']} (Max Score: {max(ce['risk_score'], pe['risk_score'])})")
    
    # Display Market IV Data if available
    if symbol_iv_data and symbol_iv_data.get('data_available'):
        print(f"\n[MARKET-IV] {symbol} Market Data:")
        print(f"   ATM IV: {symbol_iv_data.get('atm_iv'):.1f}%")
        if symbol_iv_data.get('iv_percentile') is not None:
            iv_pct = symbol_iv_data.get('iv_percentile')
            iv_env = "HIGH (favorable)" if iv_pct > IV_PERCENTILE_HIGH_THRESHOLD else "LOW (risky)" if iv_pct < IV_PERCENTILE_LOW_THRESHOLD else "MODERATE"
            print(f"   IV Percentile: {iv_pct}th ({iv_env} for sellers)")
        if symbol_iv_data.get('pcr') is not None:
            pcr_val = symbol_iv_data.get('pcr')
            pcr_sentiment = "Bearish" if pcr_val > 1.5 else "Bullish" if pcr_val < 0.5 else "Balanced"
            print(f"   PCR: {pcr_val:.2f} ({pcr_sentiment} sentiment)")
        if ENABLE_MAX_PAIN_AWARENESS and symbol_iv_data.get('max_pain') is not None:
            max_pain = symbol_iv_data.get('max_pain')
            mp_dist_pct = abs(underlying_price - max_pain) / underlying_price * 100
            print(f"   Max Pain: ₹{max_pain:.0f} ({mp_dist_pct:.1f}% from current)")
            if mp_dist_pct <= 2.0:
                print(f"   ⚠️  Current price very close to Max Pain - expect pinning behavior")
            elif mp_dist_pct <= 5.0:
                print(f"   ℹ️  Current price near Max Pain zone")

    
    # Display detailed risk warnings if enabled
    if SHOW_DETAILED_RISK_WARNINGS:
        try:
            # Calculate Greeks for detailed risk warnings
            ce_strike = ce['strike']
            pe_strike = pe['strike']
            
            # Calculate Greeks (caching removed - minimal benefit, adds complexity)
            if ENABLE_BLACK76_FUTURES:
                ce_greeks = calculate_black76_greeks("C", underlying_price, ce_strike, BLACK76_RISK_FREE_RATE, ce['iv'], t, trading_days)
                pe_greeks = calculate_black76_greeks("P", underlying_price, pe_strike, BLACK76_RISK_FREE_RATE, pe['iv'], t, trading_days)
            else:
                ce_greeks = calculate_all_greeks("C", underlying_price, ce_strike, RISK_FREE_RATE, ce['iv'], t, trading_days)
                pe_greeks = calculate_all_greeks("P", underlying_price, pe_strike, RISK_FREE_RATE, pe['iv'], t, trading_days)
            
            ce_risk = calculate_risk_zone_warnings(underlying_price, ce_strike, ce_greeks, ce['ltp'], trading_days)
            pe_risk = calculate_risk_zone_warnings(underlying_price, pe_strike, pe_greeks, pe['ltp'], trading_days)
            
            display_detailed_risk_warnings(underlying_price, ce_strike, ce_greeks, ce_risk, "CE")
            display_detailed_risk_warnings(underlying_price, pe_strike, pe_greeks, pe_risk, "PE")
        except Exception as e:
            print(f"[WARNING] Could not display detailed risk warnings: {e}")
            print("[INFO] Continuing with basic risk assessment...")

    return {
        "symbol": symbol,
        "expiry": expiry_dt.date().isoformat(),
        "spot": round(underlying_price, 2),  # Note: kept as "spot" key for backward compatibility
        "underlying_price": round(underlying_price, 2),  # Added explicit key
        "pricing_model": "Black-76 (Futures)" if ENABLE_BLACK76_FUTURES else "Black-Scholes (Equity Spot)",
        "dte_days": dte_days,
        "trading_days": trading_days,
        "dynamic_delta_target": round(dynamic_delta_target, 3),
        "ce_strike": int(ce["strike"]), "ce_ts": ce["tradingsymbol"], "ce_delta": round(ce["delta"], 3),
        "ce_gamma": round(ce["gamma"], 6), "ce_theta": round(ce["theta_per_day"], 4), "ce_theta_per_day": round(ce["theta_per_day"], 4),
        "ce_theta_per_trading_day": round(ce["theta_per_trading_day"], 4), "ce_vega": round(ce["vega"], 4), "ce_rho": round(ce["rho"], 4), "ce_ltp": ce["ltp"], "ce_oi_lakh": round(ce["oi_lakh"], 2),
        "ce_risk_level": ce["risk_level"], "ce_risk_score": ce["risk_score"], "ce_risk_summary": ce["risk_summary"],
        "ce_spot_distance_pct": round(ce["spot_distance_pct"], 2),
        "pe_strike": int(pe["strike"]), "pe_ts": pe["tradingsymbol"], "pe_delta": round(pe["delta"], 3),
        "pe_gamma": round(pe["gamma"], 6), "pe_theta": round(pe["theta_per_day"], 4), "pe_theta_per_day": round(pe["theta_per_day"], 4),
        "pe_theta_per_trading_day": round(pe["theta_per_trading_day"], 4), "pe_vega": round(pe["vega"], 4), "pe_rho": round(pe["rho"], 4), "pe_ltp": pe["ltp"], "pe_oi_lakh": round(pe["oi_lakh"], 2),
        "pe_risk_level": pe["risk_level"], "pe_risk_score": pe["risk_score"], "pe_risk_summary": pe["risk_summary"],
        "pe_spot_distance_pct": round(pe["spot_distance_pct"], 2),
        # Combined Strangle Metrics
        "total_credit": round(float(ce["ltp"]) + float(pe["ltp"]), 2),
        # For SHORT straddles: flip sign (negative theta from long perspective becomes positive when we sell)
        "net_theta": round(-(ce["theta_per_day"] + pe["theta_per_day"]), 4),  # Per day theta (SHORT perspective)
        "net_theta_per_day": round(-(ce["theta_per_day"] + pe["theta_per_day"]), 4),  # Calendar day theta (SHORT perspective)
        "net_theta_per_trading_day": round(-(ce["theta_per_trading_day"] + pe["theta_per_trading_day"]), 4),  # Trading day theta (SHORT perspective)
        "net_vega": round(-(ce["vega"] + pe["vega"]), 4),  # Negative vega for SHORT straddles (lose when IV rises)
        "be_upper": round(ce["strike"] + float(ce["ltp"]) + float(pe["ltp"]), 2),
        "be_lower": round(pe["strike"] - float(ce["ltp"]) - float(pe["ltp"]), 2),
        "be_upper_dist_pct": round(((ce["strike"] + float(ce["ltp"]) + float(pe["ltp"])) - underlying_price) / underlying_price * 100, 2),
        "be_lower_dist_pct": round((underlying_price - (pe["strike"] - float(ce["ltp"]) - float(pe["ltp"]))) / underlying_price * 100, 2),
        "min_be_distance_pct": round(min(((ce["strike"] + float(ce["ltp"]) + float(pe["ltp"])) - underlying_price) / underlying_price * 100, (underlying_price - (pe["strike"] - float(ce["ltp"]) - float(pe["ltp"]))) / underlying_price * 100), 2),
        "est_margin": round(underlying_price * 0.20, 2),
        "rom_pct": round(((float(ce["ltp"]) + float(pe["ltp"])) / (underlying_price * 0.20)) * 100, 2),
        
        # Overall Risk Assessment
        "overall_risk_level": "HIGH" if max(ce["risk_score"], pe["risk_score"]) >= 5 else "MEDIUM" if max(ce["risk_score"], pe["risk_score"]) >= 3 else "LOW",
        "overall_risk_score": max(ce["risk_score"], pe["risk_score"]),
        
        # Market IV Data (if available)
        "atm_iv": round(symbol_iv_data.get('atm_iv'), 2) if symbol_iv_data and symbol_iv_data.get('atm_iv') else None,
        "iv_percentile": symbol_iv_data.get('iv_percentile') if symbol_iv_data else None,
        "pcr": round(symbol_iv_data.get('pcr'), 2) if symbol_iv_data and symbol_iv_data.get('pcr') else None,
        "max_pain": round(symbol_iv_data.get('max_pain'), 2) if symbol_iv_data and symbol_iv_data.get('max_pain') else None
    }

def run_supply_demand_writing(kite, ins_df, symbol, expiry_dt):
    print(f"\n[SD-WRITE] {symbol} → Expiry: {expiry_dt.date()}")
    zones = derive_zones_from_history(kite, ins_df, symbol)
    if not zones or zones[0] is None or zones[1] is None or zones[2] is None:
        print("[SD-WRITE] Could not derive zones/ATR")
        return None
    supply, demand, atr = zones
    print(f"[SD-WRITE] Supply ~ {supply:.2f}, Demand ~ {demand:.2f}, ATR({ATR_LOOKBACK}) ~ {atr:.2f}")

    # CRITICAL: Choose underlying price based on model
    # Black-76 uses FUTURES (F) - already includes cost-of-carry
    # Black-Scholes uses EQUITY SPOT (S) - needs dividend adjustment
    if ENABLE_BLACK76_FUTURES:
        # Black-76: Get FUTURES price (F)
        underlying_price = get_near_month_future_ltp(kite, ins_df, symbol)
        if underlying_price is None:
            print(f"[ERROR] {symbol}: No futures price available for Black-76, skipping")
            return None
        print(f"[SD-WRITE] Using Black-76 model with FUTURES price (F): {underlying_price:.2f}")
    else:
        # Black-Scholes: Get EQUITY SPOT price (S)
        underlying_price = kite.ltp([f"NSE:{symbol}"])[f"NSE:{symbol}"]["last_price"]
        print(f"[SD-WRITE] Using Black-Scholes model with EQUITY SPOT price (S): {underlying_price:.2f}")
        print(f"[SD-WRITE] Dividend yield: {BLACK_SCHOLES_DIVIDEND_YIELD*100:.2f}% (for cost-of-carry)")

    opts = find_options_for_symbol(ins_df, symbol, expiry_dt.strftime("%Y-%m-%d"))
    if opts.empty:
        print(f"[SD-WRITE] No options for {symbol} @ {expiry_dt.date()}")
        return None

    qmap = batch_quote_ltp_oi(kite, opts["instrument_token"].astype(int).tolist())
    opts["ltp"] = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("ltp"))
    opts["oi"]  = opts["instrument_token"].map(lambda t: qmap.get(int(t), {}).get("oi"))
    print(f"[SD-WRITE] Strikes fetched: {len(opts)}")
    
    # Add basic liquidity data (bid/ask not available in simple quote)
    opts["bid"] = 0  # Will be validated as "no bid/ask data"
    opts["ask"] = 0
    opts["volume"] = 0
    
    # Apply strategy-appropriate validation
    if VALIDATION_STRATEGY == "MONTHLY_WRITING":
        print(f"[MONTHLY-WRITING] Assessing execution quality for {len(opts)} options...")
        opts = filter_monthly_writing_options(opts, min_execution_score=MIN_EXECUTION_SCORE)
        
        if opts.empty:
            print(f"[MONTHLY-WRITING] No executable options found for {symbol} after validation")
            return None
        
        print(f"[MONTHLY-WRITING] {get_monthly_execution_summary(opts)}")
    else:
        # Use traditional liquidity validation
        print(f"[LIQUIDITY] Validating market liquidity for {len(opts)} options...")
        
        # Get adaptive liquidity score based on market status
        adaptive_score, score_reason = get_adaptive_liquidity_score()
        print(f"[LIQUIDITY] {score_reason}")
        
        opts = filter_liquid_options(opts, min_liquidity_score=adaptive_score)
        
        if opts.empty:
            print(f"[LIQUIDITY] No liquid options found for {symbol} after validation")
            return None
        
        print(f"[LIQUIDITY] {get_liquidity_summary(opts)}")

    pick = pick_sd_writing_strikes(opts, supply, demand, atr, underlying_price, ATR_BUFFER_MULT, MIN_OI_LAKH)
    if not pick:
        print("[SD-WRITE] No qualifying strikes found even with progressive relaxation.")
        return None

    ce = pick["ce"]; pe = pick["pe"]
    relaxation_level = pick.get("relaxation_level", "Standard")
    atr_mult_used = pick.get("atr_mult_used", ATR_BUFFER_MULT)
    oi_mult_used = pick.get("oi_mult_used", 1.0)
    
    print(f"[SD-WRITE][BARRIERS] CE >= {pick['ce_barrier']:.2f} | Pick: {ce['tradingsymbol']} @ {ce['strike']}")
    print(f"[SD-WRITE][BARRIERS] PE <= {pick['pe_barrier']:.2f} | Pick: {pe['tradingsymbol']} @ {pe['strike']}")
    print(f"[SD-WRITE][SETTINGS] Used {relaxation_level} settings: ATR mult={atr_mult_used:.2f}, OI mult={oi_mult_used:.2f}")

    # Calculate Greeks for the selected options using appropriate model
    t = year_fraction_to_expiry(expiry_dt.astimezone(IST))
    trading_days = count_trading_days_to_expiry(expiry_dt.astimezone(IST))
    
    if ENABLE_BLACK76_FUTURES:
        # Use Black-76 with FUTURES price (F)
        ce_greeks = calculate_black76_greeks("C", underlying_price, float(ce["strike"]), BLACK76_RISK_FREE_RATE, 0.3, t, trading_days)
        pe_greeks = calculate_black76_greeks("P", underlying_price, float(pe["strike"]), BLACK76_RISK_FREE_RATE, 0.3, t, trading_days)
    else:
        # Use Black-Scholes with EQUITY SPOT price (S)
        ce_greeks = calculate_all_greeks("C", underlying_price, float(ce["strike"]), RISK_FREE_RATE, 0.3, t, trading_days)
        pe_greeks = calculate_all_greeks("P", underlying_price, float(pe["strike"]), RISK_FREE_RATE, 0.3, t, trading_days)
    
    # Theta is already properly scaled in calculate_all_greeks function
    # No additional scaling needed here
    
    # Calculate risk zone warnings with DTE sensitivity
    ce_risk = calculate_risk_zone_warnings(underlying_price, float(ce["strike"]), ce_greeks, ce["ltp"], trading_days)
    pe_risk = calculate_risk_zone_warnings(underlying_price, float(pe["strike"]), pe_greeks, pe["ltp"], trading_days)
    
    print(f"[SD-WRITE][GREKS] CE Δ={ce_greeks['delta']:.3f} Γ={ce_greeks['gamma']:.6f} Θ={ce_greeks['theta_per_day']:.4f} V={ce_greeks['vega']:.4f} ρ={ce_greeks['rho']:.4f} {ce_risk['risk_summary']}")
    print(f"[SD-WRITE][GREKS] PE Δ={pe_greeks['delta']:.3f} Γ={pe_greeks['gamma']:.6f} Θ={pe_greeks['theta_per_day']:.4f} V={pe_greeks['vega']:.4f} ρ={ce_greeks['rho']:.4f} {pe_risk['risk_summary']}")
    print(f"[SD-WRITE][RISK] Overall Risk: {ce_risk['risk_level'] if ce_risk['risk_score'] > pe_risk['risk_score'] else pe_risk['risk_level']} (Max Score: {max(ce_risk['risk_score'], pe_risk['risk_score'])})")
    
    # Display detailed risk warnings if enabled
    if SHOW_DETAILED_RISK_WARNINGS:
        try:
            display_detailed_risk_warnings(underlying_price, float(ce["strike"]), ce_greeks, ce_risk, "CE")
            display_detailed_risk_warnings(underlying_price, float(pe["strike"]), pe_greeks, pe_risk, "PE")
        except Exception as e:
            print(f"[WARNING] Could not display detailed risk warnings: {e}")
            print("[INFO] Continuing with basic risk assessment...")

    return {
        "symbol": symbol,
        "expiry": expiry_dt.date().isoformat(),
        "spot": round(underlying_price, 2),  # Note: kept as "spot" key for backward compatibility
        "underlying_price": round(underlying_price, 2),  # Added explicit key
        "pricing_model": "Black-76 (Futures)" if ENABLE_BLACK76_FUTURES else "Black-Scholes (Equity Spot)",
        "supply": round(pick["supply"], 2),
        "demand": round(pick["demand"], 2),
        "atr": round(pick["atr"], 2),
        "ce_barrier": round(pick["ce_barrier"], 2),
        "pe_barrier": round(pick["pe_barrier"], 2),
        "ce_strike": int(ce["strike"]), "ce_ts": ce["tradingsymbol"], "ce_ltp": ce["ltp"], "ce_oi": int(ce.get("oi", 0)),
        "ce_delta": round(ce_greeks["delta"], 3), "ce_gamma": round(ce_greeks["gamma"], 6),
        "ce_theta": round(ce_greeks["theta_per_day"], 4), "ce_theta_per_day": round(ce_greeks["theta_per_day"], 4),
        "ce_theta_per_trading_day": round(ce_greeks["theta_per_trading_day"], 4),
        "ce_vega": round(ce_greeks["vega"], 4), "ce_rho": round(ce_greeks["rho"], 4),
        "ce_risk_level": ce_risk["risk_level"], "ce_risk_score": ce_risk["risk_score"], "ce_risk_summary": ce_risk["risk_summary"],
        "ce_spot_distance_pct": round(ce_risk["spot_distance_pct"], 2),
        "pe_strike": int(pe["strike"]), "pe_ts": pe["tradingsymbol"], "pe_ltp": pe["ltp"], "pe_oi": int(pe.get("oi", 0)),
        "pe_delta": round(pe_greeks["delta"], 3), "pe_gamma": round(pe_greeks["gamma"], 6),
        "pe_theta": round(pe_greeks["theta_per_day"], 4), "pe_theta_per_day": round(pe_greeks["theta_per_day"], 4),
        "pe_theta_per_trading_day": round(pe_greeks["theta_per_trading_day"], 4),
        "pe_vega": round(pe_greeks["vega"], 4), "pe_rho": round(pe_greeks["rho"], 4),
        "pe_risk_level": pe_risk["risk_level"], "pe_risk_score": pe_risk["risk_score"], "pe_risk_summary": pe_risk["risk_summary"],
        "pe_spot_distance_pct": round(pe_risk["spot_distance_pct"], 2),
        # Combined Strangle Metrics
        "total_credit": round(float((ce.get("ltp") or 0)) + float((pe.get("ltp") or 0)), 2),
        # For SHORT straddles: flip sign (negative theta from long perspective becomes positive when we sell)
        "net_theta": round(-(ce_greeks["theta_per_day"] + pe_greeks["theta_per_day"]), 4),
        "net_theta_per_day": round(-(ce_greeks["theta_per_day"] + pe_greeks["theta_per_day"]), 4),
        "net_theta_per_trading_day": round(-(ce_greeks["theta_per_trading_day"] + pe_greeks["theta_per_trading_day"]), 4),
        "net_vega": round(-(ce_greeks["vega"] + pe_greeks["vega"]), 4),  # Negative vega for SHORT straddles (lose when IV rises)
        "be_upper": round(ce["strike"] + float((ce.get("ltp") or 0)) + float((pe.get("ltp") or 0)), 2),
        "be_lower": round(pe["strike"] - float((ce.get("ltp") or 0)) - float((pe.get("ltp") or 0)), 2),
        "be_upper_dist_pct": round(((ce["strike"] + float((ce.get("ltp") or 0)) + float((pe.get("ltp") or 0))) - underlying_price) / underlying_price * 100, 2),
        "be_lower_dist_pct": round((underlying_price - (pe["strike"] - float((ce.get("ltp") or 0)) - float((pe.get("ltp") or 0)))) / underlying_price * 100, 2),
        "min_be_distance_pct": round(min(((ce["strike"] + float((ce.get("ltp") or 0)) + float((pe.get("ltp") or 0))) - underlying_price) / underlying_price * 100, (underlying_price - (pe["strike"] - float((ce.get("ltp") or 0)) - float((pe.get("ltp") or 0)))) / underlying_price * 100), 2),
        "est_margin": round(underlying_price * 0.20, 2),
        "rom_pct": round(((float((ce.get("ltp") or 0)) + float((pe.get("ltp") or 0))) / (underlying_price * 0.20)) * 100, 2),
        
        # Overall Risk Assessment
        "overall_risk_level": "HIGH" if max(ce_risk["risk_score"], pe_risk["risk_score"]) >= 5 else "MEDIUM" if max(ce_risk["risk_score"], pe_risk["risk_score"]) >= 3 else "LOW",
        "overall_risk_score": max(ce_risk["risk_score"], pe_risk["risk_score"]),
        "relaxation_level": relaxation_level,
        "atr_mult_used": round(atr_mult_used, 2),
        "oi_mult_used": round(oi_mult_used, 2)
    }

# ------------------ MARKET LIQUIDITY VALIDATION ------------------
def validate_market_liquidity(quote_data, symbol=""):
    """
    Validate if an option has sufficient market liquidity for reliable trading
    
    Returns:
        tuple: (is_liquid, reason, liquidity_score)
    """
    try:
        if not quote_data:
            return False, "No quote data", 0
        
        # Extract key data
        ltp = quote_data.get('last_price', 0)
        bid = quote_data.get('bid', 0)
        ask = quote_data.get('ask', 0)
        volume = quote_data.get('volume', 0)
        oi = quote_data.get('oi', 0)
        
        # Check if we have basic price data
        if ltp <= 0:
            return False, "No valid LTP", 0
        
        liquidity_score = 100
        issues = []
        
        # 1. Bid-Ask Spread Check (Critical)
        if bid > 0 and ask > 0:
            spread = ask - bid
            spread_pct = (spread / ltp) * 100 if ltp > 0 else 100
            
            if spread_pct > 50:
                liquidity_score -= 40
                issues.append(f"Extreme spread: {spread_pct:.1f}%")
            elif spread_pct > 30:
                liquidity_score -= 25
                issues.append(f"High spread: {spread_pct:.1f}%")
            elif spread_pct > 20:
                liquidity_score -= 15
                issues.append(f"Moderate spread: {spread_pct:.1f}%")
            elif spread_pct > 10:
                liquidity_score -= 5
                issues.append(f"Acceptable spread: {spread_pct:.1f}%")
        else:
            # No bid/ask data - use LTP as fallback
            liquidity_score -= 20
            issues.append("No bid/ask data")
        
        # 2. Volume Check
        if volume == 0:
            liquidity_score -= 30
            issues.append("No recent volume")
        elif volume < 100:
            liquidity_score -= 20
            issues.append(f"Low volume: {volume}")
        elif volume < 500:
            liquidity_score -= 10
            issues.append(f"Moderate volume: {volume}")
        
        # 3. Open Interest Check
        if oi == 0:
            liquidity_score -= 25
            issues.append("No open interest")
        elif oi < 1000:
            liquidity_score -= 15
            issues.append(f"Low OI: {oi}")
        elif oi < 5000:
            liquidity_score -= 5
            issues.append(f"Moderate OI: {oi}")
        
        # 4. Price Reasonableness Check
        if ltp < 0.05:  # Very cheap options
            liquidity_score -= 10
            issues.append("Very low price (<5p)")
        elif ltp > 1000:  # Very expensive options
            liquidity_score -= 5
            issues.append("Very high price")
        
        # Determine liquidity status
        is_liquid = liquidity_score >= 70
        reason = "; ".join(issues) if issues else "Good liquidity"
        
        return is_liquid, reason, liquidity_score
        
    except Exception as e:
        return False, f"Validation error: {e}", 0

def filter_liquid_options(opts_df, min_liquidity_score=None):
    """
    Filter options DataFrame to only include liquid options
    
    Returns:
        DataFrame: Filtered options with liquidity validation
    """
    if not ENABLE_LIQUIDITY_VALIDATION:
        print("[LIQUIDITY] Validation disabled - returning all options")
        # Add dummy columns to prevent errors when validation is disabled
        opts_df = opts_df.copy()
        opts_df['liquidity_score'] = 100
        opts_df['liquidity_reason'] = 'Validation disabled'
        opts_df['is_liquid'] = True
        return opts_df
    
    if min_liquidity_score is None:
        min_liquidity_score = MIN_LIQUIDITY_SCORE
    if opts_df.empty:
        return opts_df
    
    # Add liquidity validation columns
    opts_df = opts_df.copy()
    opts_df['liquidity_score'] = 0
    opts_df['liquidity_reason'] = ''
    opts_df['is_liquid'] = False
    
    # Validate each option
    for idx, row in opts_df.iterrows():
        # Create quote data structure from row
        quote_data = {
            'last_price': row.get('ltp', 0),
            'bid': row.get('bid', 0),
            'ask': row.get('ask', 0),
            'volume': row.get('volume', 0),
            'oi': row.get('oi', 0)
        }
        
        is_liquid, reason, score = validate_market_liquidity(quote_data, row.get('tradingsymbol', ''))
        
        opts_df.at[idx, 'liquidity_score'] = score
        opts_df.at[idx, 'liquidity_reason'] = reason
        opts_df.at[idx, 'is_liquid'] = is_liquid
    
    # Filter to only liquid options
    liquid_opts = opts_df[opts_df['is_liquid'] == True].copy()
    
    if len(liquid_opts) < len(opts_df):
        rejected_count = len(opts_df) - len(liquid_opts)
        print(f"[LIQUIDITY] Filtered out {rejected_count} illiquid options")
        print(f"[LIQUIDITY] Kept {len(liquid_opts)} liquid options")
        
        # Show some examples of rejected options
        rejected = opts_df[opts_df['is_liquid'] == False].head(3)
        for _, row in rejected.iterrows():
            print(f"[LIQUIDITY] Rejected {row.get('tradingsymbol', 'Unknown')}: {row['liquidity_reason']} (Score: {row['liquidity_score']})")
    
    return liquid_opts

def get_liquidity_summary(opts_df):
    """
    Generate a summary of liquidity across all options
    """
    if opts_df.empty:
        return "No options data"
    
    total_options = len(opts_df)
    liquid_options = len(opts_df[opts_df['is_liquid'] == True])
    illiquid_options = total_options - liquid_options
    
    avg_score = opts_df['liquidity_score'].mean()
    min_score = opts_df['liquidity_score'].min()
    max_score = opts_df['liquidity_score'].max()
    
    summary = f"Liquidity Summary: {liquid_options}/{total_options} liquid options"
    summary += f" | Avg Score: {avg_score:.1f} | Range: {min_score:.0f}-{max_score:.0f}"
    
    return summary

def detect_market_status():
    """
    Detect if Indian market is currently open
    Returns: (is_open, reason, current_time)
    """
    try:
        current_time = datetime.now(IST)
        current_hour = current_time.hour
        current_minute = current_time.minute
        current_weekday = current_time.weekday()
        
        # Market hours: 9:15 AM - 3:30 PM IST, Monday to Friday
        market_open = datetime.now(IST).replace(hour=9, minute=15, second=0, microsecond=0)
        market_close = datetime.now(IST).replace(hour=15, minute=30, second=0, microsecond=0)
        
        # Check if it's a weekday (Monday = 0, Friday = 4)
        if current_weekday >= 5:  # Saturday or Sunday
            return False, "Weekend", current_time
        
        # Check if within market hours
        if current_time < market_open:
            return False, "Before market open", current_time
        elif current_time > market_close:
            return False, "After market close", current_time
        else:
            return True, "Market open", current_time
            
    except Exception as e:
        return False, f"Error detecting market status: {e}", datetime.now(IST)

def get_adaptive_liquidity_score():
    """
    Get liquidity score threshold based on market status
    """
    if not ENABLE_ADAPTIVE_SCORING:
        return MIN_LIQUIDITY_SCORE, "Adaptive scoring disabled - using fixed criteria"
    
    is_open, reason, current_time = detect_market_status()
    
    if is_open:
        return MIN_LIQUIDITY_SCORE, "Market open - using standard criteria"
    else:
        # Relaxed criteria for closed market
        relaxed_score = max(50, MIN_LIQUIDITY_SCORE - 20)
        return relaxed_score, f"Market closed ({reason}) - using relaxed criteria: {relaxed_score}"

# ------------------ MONTHLY OPTION WRITING VALIDATION ------------------
def assess_monthly_execution_quality(symbol, opts_df, symbol_data=None):
    """
    Assess execution quality for monthly option writing strategies
    
    Focuses on structural indicators rather than real-time liquidity:
    - OI percentile ranking
    - Volume activity patterns  
    - Market structure analysis
    - Historical execution patterns
    """
    try:
        if opts_df.empty:
            return False, "No options data", 0
        
        # Calculate OI percentiles across all strikes
        oi_values = opts_df['oi'].fillna(0)
        oi_percentiles = oi_values.rank(pct=True) * 100
        
        # Calculate volume percentiles (if available)
        volume_values = opts_df.get('volume', pd.Series([0] * len(opts_df)))
        volume_percentiles = volume_values.rank(pct=True) * 100
        
        # Count strikes with meaningful OI
        meaningful_oi_threshold = opts_df['oi'].quantile(0.3)  # Top 70% by OI
        strikes_with_oi = len(opts_df[opts_df['oi'] >= meaningful_oi_threshold])
        oi_coverage = strikes_with_oi / len(opts_df) * 100
        
        # Market structure indicators
        total_oi = opts_df['oi'].sum()
        avg_oi_per_strike = total_oi / len(opts_df)
        
        # Calculate execution confidence score
        execution_score = 0
        confidence_factors = []
        
        # 1. OI Coverage (40 points)
        if oi_coverage >= 80:
            execution_score += 40
            confidence_factors.append("Excellent OI coverage")
        elif oi_coverage >= 60:
            execution_score += 30
            confidence_factors.append("Good OI coverage")
        elif oi_coverage >= 40:
            execution_score += 20
            confidence_factors.append("Moderate OI coverage")
        else:
            execution_score += 10
            confidence_factors.append("Poor OI coverage")
        
        # 2. Average OI per Strike (30 points)
        if avg_oi_per_strike >= 10000:  # 1L+ average OI
            execution_score += 30
            confidence_factors.append("High average OI")
        elif avg_oi_per_strike >= 5000:  # 50K+ average OI
            execution_score += 20
            confidence_factors.append("Moderate average OI")
        elif avg_oi_per_strike >= 1000:  # 10K+ average OI
            execution_score += 10
            confidence_factors.append("Low average OI")
        
        # 3. Strike Distribution Quality (20 points)
        # Check if we have strikes around current price
        current_price = symbol_data.get('spot', 0) if symbol_data else 0
        if current_price > 0:
            price_range = current_price * 0.1  # 10% range
            strikes_in_range = len(opts_df[
                (opts_df['strike'] >= current_price - price_range) & 
                (opts_df['strike'] <= current_price + price_range)
            ])
            if strikes_in_range >= 5:
                execution_score += 20
                confidence_factors.append("Good strike distribution")
            elif strikes_in_range >= 3:
                execution_score += 15
                confidence_factors.append("Moderate strike distribution")
            else:
                execution_score += 10
                confidence_factors.append("Limited strike distribution")
        else:
            execution_score += 10
            confidence_factors.append("Strike distribution unknown")
        
        # 4. Price Reasonableness (10 points)
        ltp_values = opts_df['ltp'].fillna(0)
        extreme_prices = len(ltp_values[(ltp_values < 0.05) | (ltp_values > 1000)])
        if extreme_prices == 0:
            execution_score += 10
            confidence_factors.append("All prices reasonable")
        elif extreme_prices <= 2:
            execution_score += 5
            confidence_factors.append("Most prices reasonable")
        else:
            execution_score += 0
            confidence_factors.append("Many extreme prices")
        
        # Determine execution confidence
        if execution_score >= 80:
            confidence_level = "HIGH"
        elif execution_score >= 60:
            confidence_level = "MEDIUM"
        else:
            confidence_level = "LOW"
        
        # Estimate expected slippage
        if execution_score >= 80:
            expected_slippage = "Low (0.5-1%)"
        elif execution_score >= 60:
            expected_slippage = "Moderate (1-2%)"
        else:
            expected_slippage = "High (2-5%)"
        
        reason = f"{confidence_level} confidence: {', '.join(confidence_factors)}"
        
        return execution_score >= 60, reason, execution_score, {
            'confidence_level': confidence_level,
            'expected_slippage': expected_slippage,
            'oi_coverage': f"{oi_coverage:.1f}%",
            'avg_oi_per_strike': f"{avg_oi_per_strike:,.0f}",
            'strikes_with_oi': strikes_with_oi,
            'total_strikes': len(opts_df)
        }
        
    except Exception as e:
        return False, f"Assessment error: {e}", 0, {}

def filter_monthly_writing_options(opts_df, min_execution_score=60):
    """
    Filter options for monthly writing based on execution quality
    """
    if not ENABLE_LIQUIDITY_VALIDATION:
        print("[MONTHLY-WRITING] Validation disabled - returning all options")
        # Add dummy columns to prevent errors
        opts_df = opts_df.copy()
        opts_df['execution_score'] = 100
        opts_df['execution_reason'] = 'Validation disabled'
        opts_df['is_executable'] = True
        opts_df['confidence_level'] = 'HIGH'
        opts_df['expected_slippage'] = 'Low (0.5-1%)'
        return opts_df
    
    if opts_df.empty:
        return opts_df
    
    # Assess execution quality for the entire symbol
    symbol = opts_df.iloc[0].get('tradingsymbol', '').split('25AUG')[0] if '25AUG' in str(opts_df.iloc[0].get('tradingsymbol', '')) else 'Unknown'
    
    is_executable, reason, score, details = assess_monthly_execution_quality(symbol, opts_df)
    
    # Add execution quality columns to all options
    opts_df = opts_df.copy()
    opts_df['execution_score'] = score
    opts_df['execution_reason'] = reason
    opts_df['is_executable'] = is_executable
    opts_df['confidence_level'] = details.get('confidence_level', 'UNKNOWN')
    opts_df['expected_slippage'] = details.get('expected_slippage', 'Unknown')
    
    # Filter to only executable options
    executable_opts = opts_df[opts_df['is_executable'] == True].copy()
    
    if len(executable_opts) < len(opts_df):
        rejected_count = len(opts_df) - len(executable_opts)
        print(f"[MONTHLY-WRITING] Filtered out {rejected_count} poor execution options")
        print(f"[MONTHLY-WRITING] Kept {len(executable_opts)} executable options")
        
        # Show execution quality details
        print(f"[MONTHLY-WRITING] Execution Quality: {details.get('confidence_level', 'UNKNOWN')}")
        print(f"[MONTHLY-WRITING] Expected Slippage: {details.get('expected_slippage', 'Unknown')}")
        print(f"[MONTHLY-WRITING] OI Coverage: {details.get('oi_coverage', 'Unknown')}")
        print(f"[MONTHLY-WRITING] Avg OI per Strike: {details.get('avg_oi_per_strike', 'Unknown')}")
    
    return executable_opts

def get_monthly_execution_summary(opts_df):
    """
    Generate execution quality summary for monthly writing
    """
    if opts_df.empty:
        return "No options data"
    
    total_options = len(opts_df)
    executable_options = len(opts_df[opts_df['is_executable'] == True])
    
    if 'execution_score' in opts_df.columns:
        avg_score = opts_df['execution_score'].mean()
        min_score = opts_df['execution_score'].min()
        max_score = opts_df['execution_score'].max()
        
        summary = f"Monthly Writing Summary: {executable_options}/{total_options} executable options"
        summary += f" | Avg Score: {avg_score:.1f} | Range: {min_score:.0f}-{max_score:.0f}"
    else:
        summary = f"Monthly Writing Summary: {executable_options}/{total_options} executable options"
    
    return summary

def analyze_strategic_monthly_writing(ce_data, pe_data, spot_price):
    """
    Analyze strategic aspects of monthly option writing:
    - Breakeven safety margin
    - Execution cost impact
    - Adjustment flexibility
    - Business scalability
    """
    try:
        # Extract key data
        ce_strike = float(ce_data.get('strike', 0))
        pe_strike = float(pe_data.get('strike', 0))
        ce_premium = float(ce_data.get('ltp', 0))
        pe_premium = float(pe_data.get('ltp', 0))
        
        total_premium = ce_premium + pe_premium
        margin_requirement = spot_price * 0.20  # 20% margin
        
        # 1. Breakeven Safety Analysis
        be_upper = ce_strike + total_premium
        be_lower = pe_strike - total_premium
        
        be_upper_distance = ((be_upper - spot_price) / spot_price) * 100
        be_lower_distance = ((spot_price - be_lower) / spot_price) * 100
        
        # Breakeven safety rating
        if be_upper_distance >= 15 and be_lower_distance >= 15:
            be_safety = "EXCELLENT"
            be_score = 100
        elif be_upper_distance >= 12 and be_lower_distance >= 12:
            be_safety = "GOOD"
            be_score = 80
        elif be_upper_distance >= 10 and be_lower_distance >= 10:
            be_safety = "MODERATE"
            be_score = 60
        elif be_upper_distance >= 8 and be_lower_distance >= 8:
            be_safety = "POOR"
            be_score = 40
        else:
            be_safety = "DANGEROUS"
            be_score = 20
        
        # 2. Execution Cost Impact Analysis
        typical_slippage = 0.15  # ₹0.15 typical bid-ask cost
        slippage_percentage = (typical_slippage / total_premium) * 100
        
        if slippage_percentage <= 5:
            execution_rating = "EXCELLENT"
            execution_score = 100
        elif slippage_percentage <= 10:
            execution_rating = "GOOD"
            execution_score = 80
        elif slippage_percentage <= 15:
            execution_rating = "MODERATE"
            execution_score = 60
        elif slippage_percentage <= 25:
            execution_rating = "POOR"
            execution_score = 40
        else:
            execution_rating = "DANGEROUS"
            execution_score = 20
        
        # 3. Adjustment Flexibility Analysis
        adjustment_cost = 0.20  # ₹0.20 per adjustment
        max_adjustments = int(total_premium / adjustment_cost)
        
        if max_adjustments >= 15:
            adjustment_rating = "EXCELLENT"
            adjustment_score = 100
        elif max_adjustments >= 10:
            adjustment_rating = "GOOD"
            adjustment_score = 80
        elif max_adjustments >= 5:
            adjustment_rating = "MODERATE"
            adjustment_score = 60
        elif max_adjustments >= 3:
            adjustment_rating = "POOR"
            adjustment_score = 40
        else:
            adjustment_rating = "DANGEROUS"
            adjustment_score = 20
        
        # 4. Business Scalability Analysis
        if total_premium >= 5.0:
            scalability_rating = "EXCELLENT"
            scalability_score = 100
        elif total_premium >= 3.0:
            scalability_rating = "GOOD"
            scalability_score = 80
        elif total_premium >= 1.5:
            scalability_rating = "MODERATE"
            scalability_score = 60
        elif total_premium >= 0.8:
            scalability_rating = "POOR"
            scalability_score = 40
        else:
            scalability_rating = "DANGEROUS"
            scalability_score = 20
        
        # 5. Overall Strategic Score
        strategic_score = (be_score + execution_score + adjustment_score + scalability_score) / 4
        
        if strategic_score >= 80:
            overall_strategic_rating = "EXCELLENT"
        elif strategic_score >= 60:
            overall_strategic_rating = "GOOD"
        elif strategic_score >= 40:
            overall_strategic_rating = "MODERATE"
        else:
            overall_strategic_rating = "POOR"
        
        return {
            'overall_rating': overall_strategic_rating,
            'overall_score': strategic_score,
            'breakeven_safety': {
                'rating': be_safety,
                'score': be_score,
                'upper_distance': be_upper_distance,
                'lower_distance': be_lower_distance,
                'upper_breakeven': be_upper,
                'lower_breakeven': be_lower
            },
            'execution_quality': {
                'rating': execution_rating,
                'score': execution_score,
                'slippage_percentage': slippage_percentage,
                'net_premium_after_slippage': total_premium - typical_slippage
            },
            'adjustment_flexibility': {
                'rating': adjustment_rating,
                'score': adjustment_score,
                'max_adjustments': max_adjustments,
                'adjustment_cost': adjustment_cost
            },
            'business_scalability': {
                'rating': scalability_rating,
                'score': scalability_score,
                'total_premium': total_premium,
                'margin_requirement': margin_requirement,
                'rom_percentage': (total_premium / margin_requirement) * 100
            }
        }
        
    except Exception as e:
        return {
            'overall_rating': 'ERROR',
            'overall_score': 0,
            'error': str(e)
        }

def display_strategic_analysis(analysis_result, symbol):
    """
    Display comprehensive strategic analysis for monthly writing
    """
    if 'error' in analysis_result:
        print(f"[STRATEGIC] Error analyzing {symbol}: {analysis_result['error']}")
        return
    
    print(f"\n🎯 STRATEGIC MONTHLY WRITING ANALYSIS: {symbol}")
    print("=" * 60)
    
    # Overall Rating
    overall_icon = "🟢" if analysis_result['overall_score'] >= 80 else "🟡" if analysis_result['overall_score'] >= 60 else "🔴"
    print(f"{overall_icon} OVERALL STRATEGIC RATING: {analysis_result['overall_rating']} ({analysis_result['overall_score']:.1f}/100)")
    
    # Breakeven Safety
    be = analysis_result['breakeven_safety']
    be_icon = "🟢" if be['score'] >= 80 else "🟡" if be['score'] >= 60 else "🔴"
    print(f"\n{be_icon} BREAKEVEN SAFETY: {be['rating']} ({be['score']}/100)")
    print(f"   Upper BE: ₹{be['upper_breakeven']:.2f} (+{be['upper_distance']:.1f}% from spot)")
    print(f"   Lower BE: ₹{be['lower_breakeven']:.2f} (-{be['lower_distance']:.1f}% from spot)")
    
    # Execution Quality
    exec_qual = analysis_result['execution_quality']
    exec_icon = "🟢" if exec_qual['score'] >= 80 else "🟡" if exec_qual['score'] >= 60 else "🔴"
    print(f"\n{exec_icon} EXECUTION QUALITY: {exec_qual['rating']} ({exec_qual['score']}/100)")
    print(f"   Slippage Impact: {exec_qual['slippage_percentage']:.1f}% of premium")
    print(f"   Net Premium: ₹{exec_qual['net_premium_after_slippage']:.2f} (after slippage)")
    
    # Adjustment Flexibility
    adj_flex = analysis_result['adjustment_flexibility']
    adj_icon = "🟢" if adj_flex['score'] >= 80 else "🟡" if adj_flex['score'] >= 60 else "🔴"
    print(f"\n{adj_icon} ADJUSTMENT FLEXIBILITY: {adj_flex['rating']} ({adj_flex['score']}/100)")
    print(f"   Max Adjustments: {adj_flex['max_adjustments']} (before loss)")
    print(f"   Adjustment Cost: ₹{adj_flex['adjustment_cost']:.2f} per move")
    
    # Business Scalability
    scalability = analysis_result['business_scalability']
    scale_icon = "🟢" if scalability['score'] >= 80 else "🟡" if scalability['score'] >= 60 else "🔴"
    print(f"\n{scale_icon} BUSINESS SCALABILITY: {scalability['rating']} ({scalability['score']}/100)")
    print(f"   Total Premium: ₹{scalability['total_premium']:.2f}")
    print(f"   Margin Required: ₹{scalability['margin_requirement']:.2f}")
    print(f"   ROM: {scalability['rom_percentage']:.1f}%")
    
    # Strategic Recommendations
    print(f"\n💡 STRATEGIC RECOMMENDATIONS:")
    
    if analysis_result['overall_score'] >= 80:
        print("   ✅ EXCELLENT candidate for monthly writing")
        print("   ✅ Can scale position size")
        print("   ✅ Full adjustment flexibility")
        print("   ✅ Low execution risk")
    elif analysis_result['overall_score'] >= 60:
        print("   🟡 GOOD candidate with some limitations")
        print("   🟡 Moderate adjustment flexibility")
        print("   🟡 Watch breakeven distances")
    elif analysis_result['overall_score'] >= 40:
        print("   🔴 MODERATE risk - trade with caution")
        print("   🔴 Limited adjustment flexibility")
        print("   🔴 Consider smaller position size")
    else:
        print("   🚨 HIGH risk - avoid or very small size")
        print("   🚨 No adjustment buffer")
        print("   🚨 High execution cost impact")
    
    print("=" * 60)

def calculate_dynamic_gamma_threshold(spot_price):
    """
    Calculate dynamic gamma threshold based on underlying price.
    
    Args:
        spot_price: Current spot price of the underlying
        
    Returns:
        float: Dynamic gamma threshold with bounds applied
        
    Formula: 1 / (scaling_factor * spot_price)
    This ensures higher-priced instruments get proportionally tighter gamma controls.
    
    Examples:
        - NIFTY at 22,000: threshold ≈ 0.00045 (tighter control)
        - Stock at 100: threshold ≈ 0.01 (standard control)
        - Stock at 50: threshold ≈ 0.02 (looser control)
    """
    try:
        # Validate inputs and check if dynamic threshold is enabled
        if not ENABLE_DYNAMIC_GAMMA_THRESHOLD:
            return RISK_ZONE_GAMMA_THRESHOLD  # Fallback to legacy threshold
            
        if not spot_price or not isinstance(spot_price, (int, float)) or spot_price <= 0:
            if SHOW_DETAILED_RISK_WARNINGS:
                print(f"  [WARNING] Invalid spot price for gamma threshold: {spot_price}, using legacy threshold")
            return RISK_ZONE_GAMMA_THRESHOLD  # Fallback to legacy threshold
        
        # Calculate dynamic threshold: 1 / (scaling_factor * spot_price)
        dynamic_threshold = 1.0 / (DYNAMIC_GAMMA_SCALING_FACTOR * spot_price)
        
        # Apply bounds to prevent extreme values
        bounded_threshold = max(MIN_GAMMA_THRESHOLD, 
                               min(MAX_GAMMA_THRESHOLD, dynamic_threshold))
        
        # Log threshold calculation if detailed warnings are enabled
        if SHOW_DETAILED_RISK_WARNINGS and bounded_threshold != dynamic_threshold:
            print(f"  [INFO] Gamma threshold bounded: {dynamic_threshold:.6f} -> {bounded_threshold:.6f}")
        
        return bounded_threshold
        
    except (TypeError, ValueError, ZeroDivisionError) as e:
        # Fallback to legacy threshold if calculation fails
        if SHOW_DETAILED_RISK_WARNINGS:
            print(f"  [ERROR] Gamma threshold calculation failed: {e}, using legacy threshold")
        return RISK_ZONE_GAMMA_THRESHOLD



# ------------------ MAIN ------------------
def main():
    # Display enhanced features
    display_enhanced_features()
    
    # Display dynamic gamma threshold configuration
    if ENABLE_DYNAMIC_GAMMA_THRESHOLD:
        print(f"\n🔧 DYNAMIC GAMMA THRESHOLD CONFIGURATION:")
        print(f"   Status: ENABLED")
        print(f"   Formula: 1 / ({DYNAMIC_GAMMA_SCALING_FACTOR} × spot_price)")
        print(f"   Bounds: [{MIN_GAMMA_THRESHOLD:.6f}, {MAX_GAMMA_THRESHOLD:.6f}]")
        print(f"   Note: MIN threshold reduced to allow proper dynamic scaling")
        print(f"   Legacy Threshold: {RISK_ZONE_GAMMA_THRESHOLD:.6f}")
        print(f"   Examples:")
        print(f"     NIFTY (22,000): {1/(DYNAMIC_GAMMA_SCALING_FACTOR * 22000):.6f}")
        print(f"     Stock (100): {1/(DYNAMIC_GAMMA_SCALING_FACTOR * 100):.6f}")
        print(f"     Stock (50): {1/(DYNAMIC_GAMMA_SCALING_FACTOR * 50):.6f}")
    else:
        print(f"\n🔧 DYNAMIC GAMMA THRESHOLD: DISABLED (using legacy threshold: {RISK_ZONE_GAMMA_THRESHOLD:.6f})")
    
    # Display graduated delta scoring configuration
    if ENABLE_GRADUATED_DELTA_SCORING:
        print(f"\n🎯 GRADUATED DELTA SCORING CONFIGURATION:")
        print(f"   Status: ENABLED")
        print(f"   Risk Profile: {RISK_PROFILE}")
        print(f"   Scoring System:")
        print(f"     🔴 PEAK Risk (0.48 ≤ |delta| ≤ 0.52): +{GRADUATED_DELTA_PEAK_SCORE} points")
        print(f"     🟠 HIGH Risk (0.45 ≤ |delta| ≤ 0.55): +{GRADUATED_DELTA_HIGH_SCORE} points")
        print(f"     🟡 MODERATE Risk (0.40 ≤ |delta| ≤ 0.60): +{GRADUATED_DELTA_MODERATE_SCORE} points")
        print(f"     🟢 LIGHT Risk (0.35 ≤ |delta| ≤ 0.65): +{GRADUATED_DELTA_LIGHT_SCORE} point")
        print(f"     ✅ SAFE (outside ranges): 0 points")
        print(f"   Legacy System: Binary check (0.35 ≤ |delta| ≤ 0.65) = +{RISK_WEIGHT_ATM_DELTA} points")
        print(f"   Note: More nuanced risk assessment replaces binary ATM check")
    else:
        print(f"\n🎯 GRADUATED DELTA SCORING: DISABLED (using legacy binary system: +{RISK_WEIGHT_ATM_DELTA} points for 0.35 ≤ |delta| ≤ 0.65)")
    
    # Display DTE multiplier configuration
    if ENABLE_DTE_MULTIPLIER:
        print(f"\n⏰ DTE MULTIPLIER CONFIGURATION:")
        print(f"   Status: ENABLED")
        print(f"   Time-Sensitive Risk Assessment:")
        print(f"     🔴 ≤3 days to expiry: {DTE_MULTIPLIER_3_DAYS:.1f}x multiplier (gamma explosion zone)")
        print(f"     🟠 ≤7 days to expiry: {DTE_MULTIPLIER_7_DAYS:.1f}x multiplier (weekly options)")
        print(f"     🟡 ≤15 days to expiry: {DTE_MULTIPLIER_15_DAYS:.1f}x multiplier (bi-weekly options)")
        print(f"     🟢 >15 days to expiry: {DTE_MULTIPLIER_NORMAL:.1f}x multiplier (monthly+ options)")
        print(f"   Max Risk Score: {MAX_DTE_ADJUSTED_SCORE} points (capped)")
        print(f"   Note: Closer expiry = tighter gamma control + higher risk scores")
    else:
        print(f"\n⏰ DTE MULTIPLIER: DISABLED (using legacy gamma assessment)")
    
    # Display enhanced theta risk configuration
    if ENABLE_ENHANCED_THETA_RISK:
        print(f"\n⏰ ENHANCED THETA RISK CONFIGURATION:")
        print(f"   Status: ENABLED")
        print(f"   Bi-Directional Risk Detection:")
        print(f"     🔴 ≤7 days to expiry: Rapid decay (< -0.05) = +{THETA_WHIPSAW_RISK_7_DAYS} points (whipsaw risk)")
        print(f"     🟠 ≤7 days to expiry: Slow decay (> -0.01) = +{THETA_SLOW_DECAY_RISK} point (capital inefficiency)")
        print(f"     🟡 ≤15 days to expiry: Fast decay (< -0.08) = +{THETA_WHIPSAW_RISK_15_DAYS} point (moderate whipsaw)")
        print(f"     🟢 >15 days to expiry: Slow decay (> -0.005) = +{THETA_SLOW_DECAY_RISK} point (capital efficiency)")
        print(f"   Note: Both too fast AND too slow theta are now penalized")
    else:
        print(f"\n⏰ ENHANCED THETA RISK: DISABLED (using legacy theta assessment)")
    
    # Test graduated delta scoring system
    if ENABLE_GRADUATED_DELTA_SCORING:
        test_graduated_delta_scoring()
    
    # Test DTE multiplier system
    if ENABLE_DTE_MULTIPLIER:
        test_dte_multiplier_system()
    
    # Test enhanced theta risk system
    if ENABLE_ENHANCED_THETA_RISK:
        test_enhanced_theta_risk_system()
    
    kite = kite_session()
    ins_df = load_instruments_df(kite)
    
    # DEBUG: Show overall instrument data status
    print(f"\n[DEBUG] Total instruments loaded: {len(ins_df)}")
    print(f"[DEBUG] Unique segments: {ins_df['segment'].unique()}")
    
    # Check NFO-OPT data specifically
    nfo_opt = ins_df[ins_df["segment"] == "NFO-OPT"]
    print(f"[DEBUG] NFO-OPT instruments: {len(nfo_opt)}")
    if not nfo_opt.empty:
        nfo_opt["expiry"] = pd.to_datetime(nfo_opt["expiry"])
        unique_expiries = sorted(set(nfo_opt["expiry"].dt.date))
        print(f"[DEBUG] NFO-OPT unique expiries: {len(unique_expiries)}")
        print(f"[DEBUG] NFO-OPT expiry range: {min(unique_expiries)} to {max(unique_expiries)}")
        
        # Check if our target expiry exists
        target_expiry = datetime.fromisoformat(EXPIRY).date() if EXPIRY else None
        if target_expiry:
            print(f"[DEBUG] Target expiry {target_expiry} in data: {target_expiry in unique_expiries}")
    
    # Check symbol availability
    print(f"[DEBUG] Checking first few symbols from SYMBOLS list...")
    for symbol in SYMBOLS[:5]:  # Check first 5 symbols
        symbol_data = ins_df[ins_df["name"] == symbol]
        if not symbol_data.empty:
            segments = symbol_data["segment"].unique()
            print(f"[DEBUG] {symbol}: Found in segments {segments}")
        else:
            print(f"[DEBUG] {symbol}: Not found in instrument data")
    
    print("\n" + "="*80)
    
    # Call comprehensive debug function
    debug_instrument_data_status(ins_df, EXPIRY)

    equal_delta_rows = []
    sd_rows = []

    for symbol in SYMBOLS:
        try:
            expiry_dt = datetime.fromisoformat(EXPIRY) if EXPIRY else nearest_expiry_for_symbol(ins_df, symbol)
            if not expiry_dt:
                print(f"[WARN] No expiry found for {symbol}")
                continue

            # Strategy A: Equal-delta strangle
            eq = run_equal_delta_strategy(kite, ins_df, symbol, expiry_dt)
            if eq:
                equal_delta_rows.append({
                    "timestamp": datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S"), **eq
                })

            # Strategy B: Supply/Demand Option Writing
            sd = run_supply_demand_writing(kite, ins_df, symbol, expiry_dt)
            if sd:
                sd_rows.append({
                    "timestamp": datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S"), **sd
                })

            time.sleep(SCAN_PAUSE_SEC)

        except Exception as e:
            print(f"[ERROR] {symbol}: {e}")

    cwd = os.getcwd()

    if equal_delta_rows:
        out1 = os.path.join(cwd, OUTPUT_CSV_EQUAL_DELTA)
        pd.DataFrame(equal_delta_rows).to_csv(out1, index=False)
        print(f"\n[INFO] Equal-delta results → {out1}")
    else:
        print("\n[INFO] No equal-delta results.")

    if sd_rows:
        out2 = os.path.join(cwd, OUTPUT_CSV_SD_WRITING)
        pd.DataFrame(sd_rows).to_csv(out2, index=False)
        print(f"[INFO] Supply/Demand writing results → {out2}")
    else:
        print("[INFO] No supply/demand writing results.")

# ------------------ DEBUG FUNCTIONS ------------------
def debug_instrument_data_status(ins_df, target_expiry_str=None):
    """
    Debug function to analyze instrument data status and identify issues
    """
    print("\n" + "="*60)
    print("🔍 INSTRUMENT DATA DEBUG ANALYSIS")
    print("="*60)
    
    # Overall data status
    print(f"📊 Total instruments: {len(ins_df):,}")
    print(f"📊 Data columns: {list(ins_df.columns)}")
    
    # Segment breakdown
    segments = ins_df['segment'].value_counts()
    print(f"\n📊 Segment breakdown:")
    for segment, count in segments.items():
        print(f"   {segment}: {count:,}")
    
    # NFO-OPT specific analysis
    nfo_opt = ins_df[ins_df["segment"] == "NFO-OPT"]
    print(f"\n📊 NFO-OPT Analysis:")
    print(f"   Total NFO-OPT instruments: {len(nfo_opt):,}")
    
    if not nfo_opt.empty:
        # Check expiry data
        nfo_opt["expiry"] = pd.to_datetime(nfo_opt["expiry"])
        unique_expiries = sorted(set(nfo_opt["expiry"].dt.date))
        print(f"   Unique expiries: {len(unique_expiries)}")
        print(f"   Expiry range: {min(unique_expiries)} to {max(unique_expiries)}")
        
        # Check target expiry if specified
        if target_expiry_str:
            target_expiry = datetime.fromisoformat(target_expiry_str).date()
            print(f"   Target expiry {target_expiry}: {'✅ FOUND' if target_expiry in unique_expiries else '❌ NOT FOUND'}")
            
            if target_expiry not in unique_expiries:
                # Find closest expiries
                closest_expiries = sorted(unique_expiries, key=lambda x: abs((x - target_expiry).days))[:3]
                print(f"   Closest available expiries: {closest_expiries}")
        
        # Check symbol coverage
        unique_symbols = nfo_opt["name"].nunique()
        print(f"   Unique symbols: {unique_symbols}")
        
        # Sample symbols
        sample_symbols = nfo_opt["name"].unique()[:10]
        print(f"   Sample symbols: {sample_symbols}")
        
        # Check data freshness
        if "last_updated" in nfo_opt.columns:
            print(f"   Last update column available: ✅")
        else:
            print(f"   Last update column: ❌ (data might be stale)")
            
    else:
        print("   ❌ No NFO-OPT instruments found!")
    
    # Check for common issues
    print(f"\n🔍 Common Issues Check:")
    
    # Check if data is too old
    if "expiry" in ins_df.columns:
        try:
            ins_df["expiry"] = pd.to_datetime(ins_df["expiry"])
            latest_expiry = ins_df["expiry"].max()
            if pd.notna(latest_expiry):
                print(f"   Latest expiry in data: {latest_expiry.date()}")
                days_ahead = (latest_expiry.date() - datetime.now().date()).days
                if days_ahead < 30:
                    print(f"   ⚠️  WARNING: Latest expiry is only {days_ahead} days ahead")
                else:
                    print(f"   ✅ Latest expiry is {days_ahead} days ahead")
        except:
            print(f"   ❌ Error parsing expiry dates")
    
    # Check symbol availability
    missing_symbols = []
    for symbol in SYMBOLS[:10]:  # Check first 10
        if ins_df[ins_df["name"] == symbol].empty:
            missing_symbols.append(symbol)
    
    if missing_symbols:
        print(f"   ⚠️  Missing symbols: {missing_symbols[:5]}...")
    else:
        print(f"   ✅ All checked symbols found")
    
    print("="*60)

if __name__ == "__main__":
    main()
