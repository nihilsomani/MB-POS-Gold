"""
OPTIONS COMMAND CENTER
======================
Professional-grade options trading system combining:
1. Multi-day OI trend analysis (Claude-OI-Snapshot logic)
2. Real-time Greeks & IV analysis (greeks_powered_scanner logic)
3. Unified confidence scoring
4. Adaptive strategy selection
5. Portfolio risk management

Author: AI Assistant
Date: 2025-10-24
"""

import pandas as pd
import numpy as np
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')


class OptionsCommandCenter:
    """
    Professional-Grade Options Trading System
    
    ARCHITECTURE:
    Expert Composition + Portfolio Risk Management
    
    EXPERT LAYER:
    1. greeks_powered_scanner: Greeks-based straddle analysis
    2. Claude-OI-Snapshot: OI trend & event risk analysis
    3. OITrendScanner: 7-day trends & rollover intelligence
    
    RISK MANAGEMENT LAYER (Professional Features):
    1. Portfolio Greeks Limits (max gamma, vega, theta)
    2. Position Concentration Limits (max % per stock/sector)
    3. Margin Utilization Tracking
    4. Correlation Risk Assessment
    5. Event Calendar Veto (earnings, policy)
    6. Liquidity Filters (OI depth, bid-ask)
    7. Exit Rules (profit targets, stop losses, Greeks-based)
    8. VIX Regime Adjustment (strategy shifts)
    9. Delta Hedging Triggers
    10. Time-based Exit Warnings (theta acceleration)
    """
    
    # PORTFOLIO RISK LIMITS (Professional Defaults)
    MAX_NET_DELTA = 500000          # Max ₹5L net delta exposure
    MAX_NET_GAMMA = 0.05            # Max portfolio gamma risk
    MAX_NET_VEGA = 50000            # Max ₹50K vega exposure
    MAX_POSITION_PCT = 3.0          # Max 3% per position
    MAX_SECTOR_PCT = 15.0           # Max 15% per sector
    MAX_MARGIN_UTIL = 70.0          # Max 70% margin utilization
    MIN_OI_LAKH = 0.5               # Min 50K OI for liquidity
    PORTFOLIO_SIZE = 10000000       # ₹1 Cr portfolio
    
    def __init__(self, trend_csv=None, greeks_csv=None, snapshot_csvs=None, 
                 greeks_results_csv=None, claude_results_csv=None):
        """
        Initialize with data sources
        
        Args:
            trend_csv: Path to OITrendScanner results (7-day OI trends)
            greeks_csv: Path to delta_strangle_scanner results (Greeks data)
            snapshot_csvs: List of daily FNO snapshot CSVs (for multi-day analysis)
            greeks_results_csv: Path to greeks_powered_scanner results (pre-calculated)
            claude_results_csv: Path to Claude-OI-Snapshot results (pre-calculated)
        """
        self.trend_csv = trend_csv
        self.greeks_csv = greeks_csv
        self.snapshot_csvs = snapshot_csvs
        self.greeks_results_csv = greeks_results_csv
        self.claude_results_csv = claude_results_csv
        
        self.trend_df = None
        self.greeks_df = None
        self.snapshot_df = None
        self.greeks_results_df = None  # Results from greeks_powered_scanner
        self.claude_results_df = None  # Results from Claude-OI-Snapshot
        
        self.unified_results = []
        self.blocked_trades = []  # Trades vetoed by experts
        
        # Portfolio tracking
        self.portfolio_greeks = {
            'net_delta': 0,
            'net_gamma': 0,
            'net_vega': 0,
            'net_theta': 0,
            'margin_used': 0
        }
    
    def calculate_position_size_greeks_based(self, strategy, row_greeks, base_score):
        """
        Professional position sizing based on Greeks risk, not arbitrary %
        
        For straddles: Size based on gamma risk & margin
        For directional: Size based on delta & theta cost
        """
        if 'STRADDLE' in strategy:
            # Straddle sizing: Based on gamma risk
            avg_gamma = (row_greeks.get('ce_gamma', 0) + row_greeks.get('pe_gamma', 0)) / 2
            spot = row_greeks.get('spot', 1000)
            credit = row_greeks.get('total_credit', row_greeks.get('credit', 0))
            
            # Gamma risk: How much loss per 1% move
            gamma_risk_per_pct = avg_gamma * spot * spot * 0.01
            
            # Base position: ₹1L (1% of ₹1Cr portfolio)
            base_capital = self.PORTFOLIO_SIZE * 0.01
            
            # Adjust by gamma risk (lower gamma = larger size)
            if gamma_risk_per_pct > 0:
                # Max loss we accept per 1% move = ₹10,000
                max_lots = min(5, int(10000 / gamma_risk_per_pct))
            else:
                max_lots = 3
            
            # Adjust by score
            if base_score >= 100:
                max_lots = min(max_lots, 3)
            elif base_score >= 80:
                max_lots = min(max_lots, 2)
            else:
                max_lots = min(max_lots, 1)
            
            # Calculate as % of portfolio
            margin_per_lot = spot * 0.20  # 20% SPAN margin
            total_margin = margin_per_lot * max_lots
            position_pct = (total_margin / self.PORTFOLIO_SIZE) * 100
            
            return min(position_pct, self.MAX_POSITION_PCT)
        
        else:
            # Directional sizing: Based on delta exposure
            if base_score >= 80:
                return 2.0
            elif base_score >= 60:
                return 1.5
            else:
                return 1.0
    
    def check_portfolio_limits(self, new_position):
        """
        Check if adding this position would breach portfolio limits
        Returns: (can_add: bool, warnings: list)
        """
        warnings = []
        can_add = True
        
        # Simulate adding position
        if 'STRADDLE' in new_position.get('strategy', ''):
            # Straddle Greeks impact
            theta = new_position.get('theta', 0)
            
            # Check theta limit (don't over-collect)
            if self.portfolio_greeks['net_theta'] + theta > 100:
                warnings.append(f"⚠️ Portfolio theta would exceed ₹100/day")
        
        # Check margin utilization
        # (Simplified - would need actual margin calculation)
        
        return can_add, warnings
    
    def generate_exit_rules(self, opportunity):
        """
        Generate exit rules for each trade (CRITICAL for risk management)
        """
        rules = []
        strategy = opportunity.get('strategy', '')
        
        if 'STRADDLE' in strategy:
            credit = opportunity.get('credit', 0)
            theta = opportunity.get('theta', 0)
            
            if 'SELL' in strategy:
                # Short straddle exits
                rules.append(f"✅ PROFIT TARGET: Close at 70% profit (₹{credit * 0.7:.0f})")
                rules.append(f"🛑 STOP LOSS: Close if loss exceeds 2x credit (₹{credit * 2:.0f})")
                rules.append(f"⏰ TIME EXIT: Close at 7 DTE (gamma acceleration)")
                rules.append(f"📊 GREEK EXIT: Close if gamma >0.01 or vega loss >₹10K")
                rules.append(f"🎯 DELTA EXIT: Close if net delta >0.2 (losing neutrality)")
            else:
                # Long straddle exits
                rules.append(f"✅ PROFIT TARGET: Exit at 2x cost (₹{credit * 2:.0f})")
                rules.append(f"🛑 STOP LOSS: Exit at 50% loss (₹{credit * 0.5:.0f}) or Day 15")
                rules.append(f"⏰ TIME EXIT: Exit by Day 20 (theta killing you)")
                rules.append(f"📊 IV EXIT: Exit if IV drops 5% from entry (vega loss)")
        
        else:
            # Directional exits
            oi_7d = opportunity['context'].get('oi_7d', 0)
            rules.append(f"✅ PROFIT TARGET: 50% of option value or 3% move")
            rules.append(f"🛑 STOP LOSS: 30% of premium or OI reverses")
            rules.append(f"⏰ TIME EXIT: Close if OI trend breaks (reversal)")
        
        return rules
    
    def load_data(self):
        """Load all data sources including expert scanner results"""
        print("="*100)
        print("🔄 LOADING DATA SOURCES".center(100))
        print("="*100)
        
        # Load trend data (7-day OI from OITrendScanner)
        if self.trend_csv:
            self.trend_df = pd.read_csv(self.trend_csv)
            print(f"✅ Trend Data: {len(self.trend_df)} symbols (7-day OI analysis)")
        else:
            import glob
            files = glob.glob("trend_results_adaptive_v10_nuance_*.csv")
            if files:
                self.trend_csv = max(files)
                self.trend_df = pd.read_csv(self.trend_csv)
                print(f"✅ Trend Data: {len(self.trend_df)} symbols from {self.trend_csv}")
        
        # Load Greeks data (raw)
        if self.greeks_csv:
            self.greeks_df = pd.read_csv(self.greeks_csv)
            print(f"✅ Greeks Data: {len(self.greeks_df)} symbols (IV, Greeks, straddle metrics)")
        else:
            import glob
            files = glob.glob("kite_equal_delta_strangles_*.csv")
            if files:
                self.greeks_csv = max(files)
                self.greeks_df = pd.read_csv(self.greeks_csv)
                print(f"✅ Greeks Data: {len(self.greeks_df)} symbols from {self.greeks_csv}")
        
        # Load EXPERT RESULTS from greeks_powered_scanner
        import glob
        
        # Straddle results
        if self.greeks_results_csv:
            self.greeks_results_df = pd.read_csv(self.greeks_results_csv)
        else:
            straddle_files = glob.glob("greeks_straddles_*.csv")
            if straddle_files:
                self.greeks_results_csv = max(straddle_files)
                self.greeks_results_df = pd.read_csv(self.greeks_results_csv)
                print(f"✅ Greeks Expert Results (Straddles): {len(self.greeks_results_df)} from {self.greeks_results_csv}")
        
        # Directional results
        directional_files = glob.glob("greeks_directional_*.csv")
        if directional_files:
            self.greeks_directional_df = pd.read_csv(max(directional_files))
            print(f"✅ Greeks Expert Results (Directional): {len(self.greeks_directional_df)}")
        
        # Claude-OI results (if available) - AUTO-DETECT
        if self.claude_results_csv:
            self.claude_results_df = pd.read_csv(self.claude_results_csv)
            print(f"✅ Claude-OI Expert Results: {len(self.claude_results_df)}")
        else:
            # Auto-detect Claude-OI files (exports as fno_straddle_results.csv)
            claude_files = glob.glob("fno_straddle_results*.csv")
            if claude_files:
                self.claude_results_csv = max(claude_files)
                self.claude_results_df = pd.read_csv(self.claude_results_csv)
                print(f"✅ Claude-OI Expert Results: {len(self.claude_results_df)} from {self.claude_results_csv}")
        
        # Load snapshot data for multi-day persistence analysis
        if self.snapshot_csvs:
            dfs = []
            for file in self.snapshot_csvs:
                df = pd.read_csv(file)
                if 'timestamp' in df.columns:
                    df['timestamp'] = pd.to_datetime(df['timestamp'])
                dfs.append(df)
            self.snapshot_df = pd.concat(dfs, ignore_index=True)
            self.snapshot_df = self.snapshot_df.sort_values(['symbol', 'timestamp'])
            print(f"✅ Snapshot Data: {len(self.snapshot_csvs)} days, {len(self.snapshot_df['symbol'].unique())} symbols")
        
        print("="*100)
        print()
    
    def calculate_trend_score(self, symbol, row_trend):
        """
        Calculate trend strength score from OI analysis (Claude-OI style)
        Max: 40 points + 10 bonus for rollover quality
        """
        score = 0
        signals = []
        
        # Check expiry proximity and rollover status
        days_to_expiry = row_trend.get('days_to_current_expiry', 999)
        days_to_expiry = days_to_expiry if pd.notna(days_to_expiry) else 999
        
        # OI 7-day trend (from OITrendScanner)
        # Note: OITrendScanner already switches to next month if days <= 5
        oi_7d = row_trend.get('current_oi_change_percent', 0)
        oi_7d = oi_7d if pd.notna(oi_7d) else 0
        
        # ROLLOVER INTELLIGENCE: Near expiry (≤7 days), check next month data
        near_expiry = days_to_expiry <= 7
        if near_expiry:
            next_oi = row_trend.get('next_oi_change_percent', None)
            rqi = row_trend.get('rollover_quality_index', None)
            
            # Filter out absurd next month values (likely illiquid contracts just opening)
            # If next_oi > 500%, it's probably a data artifact
            next_oi_valid = pd.notna(next_oi) and abs(next_oi) < 500
            
            # If next month data available and shows strong signal
            if next_oi_valid and abs(next_oi) > abs(oi_7d):
                # Next month showing stronger signal - flag this
                signals.append(f"⚠️ NEAR EXPIRY ({days_to_expiry}D): Next month OI {next_oi:+.1f}%")
                
                # Boost score if rollover quality is good
                if pd.notna(rqi) and rqi > 50:
                    score += 10
                    signals.append(f"✓ Strong Rollover: RQI={rqi:.0f}")
                elif pd.notna(rqi) and rqi < 30:
                    # Only penalize if current month also weak (avoid penalizing strong current signals)
                    if abs(oi_7d) < 15:  # Current signal not strong enough
                        score -= 5
                        signals.append(f"⚠️ Weak Rollover: RQI={rqi:.0f}")
                    else:
                        # Strong current signal with weak rollover - just flag, don't penalize
                        signals.append(f"ℹ️ Note: Rollover quality low (RQI={rqi:.0f}), but current signal strong")
            
            # Use next month data if current month is too close AND next month is valid
            if days_to_expiry <= 3 and next_oi_valid:
                oi_7d = next_oi  # Switch to next month
                signals.append(f"🔄 SWITCHED to next month data (DTE={days_to_expiry})")
            elif days_to_expiry <= 3 and pd.notna(next_oi) and abs(next_oi) >= 500:
                # Very close but next month is illiquid - warn user
                signals.append(f"⚠️ CRITICAL: {days_to_expiry}D to expiry, next month illiquid (OI={next_oi:+.0f}%)")
        
        # Convert to z-score equivalent for consistency
        # Approximate: 20% change ≈ z=3, 12% ≈ z=2, 6% ≈ z=1
        z_equiv = oi_7d / 6.0  # Rough z-score proxy
        
        # Score based on magnitude
        if abs(oi_7d) >= 20:
            score += 30
            signals.append(f"🔥 EXTREME OI Trend: {oi_7d:+.1f}% (7D)")
        elif abs(oi_7d) >= 12:
            score += 22
            signals.append(f"✓✓ Strong OI Trend: {oi_7d:+.1f}% (7D)")
        elif abs(oi_7d) >= 6:
            score += 14
            signals.append(f"✓ Decent OI Trend: {oi_7d:+.1f}% (7D)")
        elif abs(oi_7d) >= 3:
            score += 7
            signals.append(f"~ Mild OI Trend: {oi_7d:+.1f}% (7D)")
        
        # Persistence check from snapshot data
        persistence_bonus = 0
        if self.snapshot_df is not None and abs(oi_7d) >= 3:
            symbol_history = self.snapshot_df[self.snapshot_df['symbol'] == symbol]
            if len(symbol_history) >= 5:
                # Check last 5 days consistency
                recent_oi = symbol_history['current_oi_change_percent'].tail(5)
                if oi_7d > 0:
                    pos_days = (recent_oi > 0).sum()
                    if pos_days >= 4:
                        persistence_bonus = 10
                        signals.append(f"✓✓ PERSISTENT: {pos_days}/5 days confirm trend")
                    elif pos_days >= 3:
                        persistence_bonus = 5
                else:
                    neg_days = (recent_oi < 0).sum()
                    if neg_days >= 4:
                        persistence_bonus = 10
                        signals.append(f"✓✓ PERSISTENT: {neg_days}/5 days confirm trend")
                    elif neg_days >= 3:
                        persistence_bonus = 5
        
        score += persistence_bonus
        
        return {
            'score': score,
            'signals': signals,
            'oi_7d': oi_7d,
            'z_equiv': z_equiv
        }
    
    def calculate_timing_score(self, symbol, row_trend, row_greeks):
        """
        Calculate timing quality score from Greeks & IV (greeks_powered style)
        Max: 40 points
        """
        score = 0
        signals = []
        
        # Price alignment with OI
        oi_7d = row_trend.get('current_oi_change_percent', 0) if pd.notna(row_trend.get('current_oi_change_percent')) else 0
        price_chg = row_trend.get('current_price_change_percent', 0) if pd.notna(row_trend.get('current_price_change_percent')) else 0
        
        aligned = (oi_7d * price_chg) > 0
        
        if aligned and abs(price_chg) >= 2:
            score += 15
            signals.append(f"✓✓ ALIGNED: Price {price_chg:+.1f}% confirms OI {oi_7d:+.1f}%")
        elif not aligned and abs(oi_7d) >= 10 and abs(price_chg) >= 2:
            # Divergence detection
            if oi_7d > 10 and price_chg < -2:
                score += 10
                signals.append(f"🔥 BULLISH DIVERGENCE: Accumulation (OI +{oi_7d:.1f}%, Price {price_chg:.1f}%)")
            elif oi_7d < -10 and price_chg > 2:
                score += 10
                signals.append(f"🔥 BEARISH DIVERGENCE: Distribution (OI {oi_7d:.1f}%, Price +{price_chg:.1f}%)")
        
        # PCR confirmation
        pcr = row_greeks.get('pcr', 1.0) if pd.notna(row_greeks.get('pcr')) else 1.0
        
        if oi_7d > 0 and pcr > 1.2:
            score += 10
            signals.append(f"✓ Bullish PCR: {pcr:.2f} supports uptrend")
        elif oi_7d < 0 and pcr < 0.7:
            score += 10
            signals.append(f"✓ Bearish PCR: {pcr:.2f} supports downtrend")
        
        # IV Rank (strategy selection)
        iv_rank = row_greeks.get('iv_percentile', 50) if pd.notna(row_greeks.get('iv_percentile')) else 50
        
        if iv_rank <= 30:
            score += 15
            signals.append(f"✓✓ LOW IV: {iv_rank:.0f}% (CHEAP - buy options)")
        elif iv_rank >= 70:
            score += 15
            signals.append(f"✓✓ HIGH IV: {iv_rank:.0f}% (EXPENSIVE - sell premium)")
        
        return {
            'score': score,
            'signals': signals,
            'iv_rank': iv_rank,
            'pcr': pcr,
            'price_chg': price_chg,
            'aligned': aligned
        }
    
    def calculate_risk_score(self, row_greeks, strategy_type):
        """
        Calculate risk-adjusted score based on Greeks
        Returns: penalty points (negative) and risk signals
        """
        penalty = 0
        signals = []
        
        if strategy_type == 'directional':
            # For directional: check theta decay & gamma risk
            # Note: Individual option Greeks are from LONG perspective in greeks CSV
            # We need to assess based on what position we'd take
            pass  # Greeks scoring already embedded in strategy logic
            
        elif strategy_type == 'straddle':
            # For straddles: check from Greeks data
            gamma = (row_greeks.get('ce_gamma', 0) + row_greeks.get('pe_gamma', 0)) / 2
            risk_score = row_greeks.get('overall_risk_score', 5)
            
            if risk_score >= 7:
                penalty -= 20
                signals.append(f"⚠️ HIGH RISK: {risk_score:.0f}/10")
            elif gamma > 0.005:
                penalty -= 10
                signals.append(f"⚠️ High Gamma: {gamma:.4f} (risky)")
        
        return {
            'penalty': penalty,
            'signals': signals
        }
    
    def determine_strategy_mode(self, trend_score_data, timing_score_data, row_greeks):
        """
        Determine optimal trading strategy based on combined analysis
        
        NOTE: This is a SIMPLIFIED heuristic for demonstration.
        In production, we should:
        1. Import results from greeks_powered_scanner (has detailed straddle logic)
        2. Import results from Claude-OI-Snapshot (has OI neutrality detection)
        3. Combine their expert opinions, not reimplement their logic
        
        Current implementation serves as fallback when specialist results unavailable.
        
        Returns:
            mode: 'MOMENTUM', 'REVERSAL', 'MEAN_REVERSION', 'VOLATILITY_EXPANSION'
            strategy: specific action (BUY CALL, SELL STRADDLE, etc.)
        """
        oi_7d = trend_score_data['oi_7d']
        z_equiv = trend_score_data['z_equiv']
        iv_rank = timing_score_data['iv_rank']
        aligned = timing_score_data['aligned']
        
        # MODE 1: MOMENTUM (strong trend + alignment + low IV)
        if abs(oi_7d) >= 8 and aligned and iv_rank <= 40:
            if oi_7d > 0:
                return 'MOMENTUM', 'BUY_CALL'
            else:
                return 'MOMENTUM', 'BUY_PUT'
        
        # MODE 2: REVERSAL (strong OI + divergence)
        if abs(oi_7d) >= 10 and not aligned:
            if oi_7d > 10 and timing_score_data['price_chg'] < -2:
                return 'REVERSAL', 'BUY_CALL'  # Accumulation
            elif oi_7d < -10 and timing_score_data['price_chg'] > 2:
                return 'REVERSAL', 'BUY_PUT'  # Distribution
        
        # MODE 3: MEAN REVERSION (neutral OI + elevated IV)
        # Relaxed IV from 60% to 50% and OI from 5% to 8% to capture more opportunities
        # These align better with greeks_powered_scanner and Claude-OI-Snapshot thresholds
        if abs(oi_7d) < 8 and iv_rank >= 50:
            return 'MEAN_REVERSION', 'SELL_STRADDLE'
        
        # MODE 4: VOLATILITY EXPANSION (extreme OI + low IV)
        if abs(z_equiv) >= 2.5 and iv_rank < 50:
            return 'VOLATILITY_EXPANSION', 'BUY_STRADDLE'
        
        # Default: directional based on OI
        if abs(oi_7d) >= 6:
            if oi_7d > 0:
                return 'MOMENTUM', 'BUY_CALL' if iv_rank < 70 else 'BUY_FUTURE'
            else:
                return 'MOMENTUM', 'BUY_PUT' if iv_rank < 70 else 'SELL_FUTURE'
        
        return 'NEUTRAL', 'WATCH'
    
    def calculate_position_size(self, unified_score, mode, row_greeks):
        """
        Calculate position size based on conviction and risk
        """
        base_size = 1.0  # 1% base
        
        # Conviction multiplier
        if unified_score >= 80:
            conviction = 3.0
        elif unified_score >= 65:
            conviction = 2.0
        elif unified_score >= 50:
            conviction = 1.5
        else:
            conviction = 1.0
        
        # Risk adjustment for straddles
        if 'STRADDLE' in mode:
            risk_score = row_greeks.get('overall_risk_score', 5)
            if risk_score >= 5:
                conviction *= 0.7
        
        return base_size * conviction
    
    def combine_expert_opinions(self):
        """
        NEW ARCHITECTURE: Combine results from specialist scanners
        
        This is the CORRECT approach - import and synthesize expert opinions
        rather than reimplementing their logic with different thresholds.
        """
        print("="*100)
        print("🎯 COMBINING EXPERT OPINIONS".center(100))
        print("="*100)
        print()
        
        combined_results = []
        
        # Get all unique symbols across experts
        all_symbols = set()
        if self.greeks_results_df is not None:
            all_symbols.update(self.greeks_results_df['symbol'].unique())
        if hasattr(self, 'greeks_directional_df') and self.greeks_directional_df is not None:
            all_symbols.update(self.greeks_directional_df['symbol'].unique())
        
        # Add Claude-OI symbols to all_symbols
        if self.claude_results_df is not None:
            all_symbols.update(self.claude_results_df['symbol'].unique())
        
        for symbol in all_symbols:
            expert_views = {'symbol': symbol}
            
            # Get greeks_powered opinion on straddles
            if self.greeks_results_df is not None:
                greeks_straddle = self.greeks_results_df[self.greeks_results_df['symbol'] == symbol]
                if not greeks_straddle.empty:
                    greeks_straddle = greeks_straddle.iloc[0]
                    expert_views['greeks_straddle_score'] = greeks_straddle['score']
                    expert_views['greeks_straddle_action'] = greeks_straddle['action']
                    expert_views['greeks_theta'] = greeks_straddle.get('net_theta_day', 0)
                    expert_views['greeks_credit'] = greeks_straddle.get('credit', 0)
                    expert_views['greeks_rom'] = greeks_straddle.get('rom', 0)
                    expert_views['greeks_be_upper'] = greeks_straddle.get('be_upper', 0)
                    expert_views['greeks_be_lower'] = greeks_straddle.get('be_lower', 0)
            
            # Get greeks_powered opinion on directional
            if hasattr(self, 'greeks_directional_df') and self.greeks_directional_df is not None:
                greeks_dir = self.greeks_directional_df[self.greeks_directional_df['symbol'] == symbol]
                if not greeks_dir.empty:
                    greeks_dir = greeks_dir.iloc[0]
                    expert_views['greeks_directional_score'] = abs(greeks_dir['score'])
                    expert_views['greeks_directional_action'] = greeks_dir['action']
            
            # Get Claude-OI opinion on straddles
            if self.claude_results_df is not None:
                claude_straddle = self.claude_results_df[self.claude_results_df['symbol'] == symbol]
                if not claude_straddle.empty:
                    claude_straddle = claude_straddle.iloc[0]
                    expert_views['claude_straddle_score'] = claude_straddle.get('straddle_score', 0)
                    expert_views['claude_action'] = claude_straddle.get('action', '')
                    expert_views['claude_confidence'] = claude_straddle.get('confidence', '')
                    expert_views['claude_blocking_reasons'] = claude_straddle.get('blocking_reasons', [])
            
            # Get OI trend context
            if self.trend_df is not None:
                trend = self.trend_df[self.trend_df['symbol'] == symbol]
                if not trend.empty:
                    trend = trend.iloc[0]
                    expert_views['oi_7d'] = trend.get('current_oi_change_percent', 0)
                    expert_views['price_7d'] = trend.get('current_price_change_percent', 0)
                    expert_views['days_to_expiry'] = trend.get('days_to_current_expiry', 999)
                    expert_views['rollover_quality'] = trend.get('rollover_quality_index', None)
            
            # Decide strategy based on expert consensus
            decision = self._synthesize_decision(expert_views)
            if decision:
                combined_results.append(decision)
        
        self.unified_results = sorted(combined_results, key=lambda x: x['unified_score'], reverse=True)
        print(f"✅ Generated {len(self.unified_results)} unified recommendations\n")
    
    def _analyze_signal_alignment(self, expert_views):
        """
        Cross-validate signals across dimensions
        Returns: alignment_score (0-100), insights list
        """
        insights = []
        alignment_score = 50  # Neutral baseline
        
        # Get signal components
        oi_7d = expert_views.get('oi_7d', 0)
        price_change_7d = expert_views.get('price_change_7d', 0)
        greeks_straddle_action = expert_views.get('greeks_straddle_action', '')
        claude_action = expert_views.get('claude_action', '')
        
        # Check OI-Price alignment (strong signal indicator)
        if abs(oi_7d) > 10 and abs(price_change_7d) > 3:
            if (oi_7d > 0 and price_change_7d > 0) or (oi_7d < 0 and price_change_7d < 0):
                alignment_score += 20
                insights.append(f"💪 STRONG ALIGNMENT: OI {oi_7d:+.1f}% + Price {price_change_7d:+.1f}% (same direction)")
            else:
                alignment_score -= 15
                insights.append(f"⚠️ DIVERGENCE: OI {oi_7d:+.1f}% vs Price {price_change_7d:+.1f}% (opposite)")
        
        # Check expert strategy alignment
        if greeks_straddle_action and claude_action:
            greeks_is_sell = 'SELL' in greeks_straddle_action
            greeks_is_buy = 'BUY' in greeks_straddle_action
            claude_is_sell = 'SELL' in claude_action
            claude_is_buy = 'BUY' in claude_action
            
            if (greeks_is_sell and claude_is_sell) or (greeks_is_buy and claude_is_buy):
                alignment_score += 25
                insights.append("🎯 EXPERT CONSENSUS: Both agree on strategy direction")
            elif (greeks_is_sell and claude_is_buy) or (greeks_is_buy and claude_is_sell):
                alignment_score -= 25
                insights.append("🔴 EXPERT CONFLICT: Opposite strategies recommended")
        
        return max(0, min(100, alignment_score)), insights
    
    def _assess_risk_context(self, expert_views):
        """
        Professional risk assessment beyond scores
        Returns: risk_adjustments dict, warnings list
        """
        warnings = []
        risk_adj = {'score_multiplier': 1.0, 'size_multiplier': 1.0}
        
        # Extract risk factors
        iv_rank = expert_views.get('iv_rank', 50)
        dte = expert_views.get('days_to_expiry', 30)
        risk_score = expert_views.get('risk_score', 5)
        net_gamma = expert_views.get('net_gamma', 0)
        oi_lakh = expert_views.get('oi_lakh', 0)
        
        # 1. IV Regime Risk
        if iv_rank > 85:
            risk_adj['score_multiplier'] *= 1.15  # Favorable for selling
            warnings.append(f"✅ FAVORABLE: IV rank {iv_rank}% (premium rich)")
        elif iv_rank < 20:
            risk_adj['score_multiplier'] *= 0.75  # Unfavorable for selling
            warnings.append(f"⚠️ CAUTION: IV rank {iv_rank}% (premium cheap)")
        
        # 2. Gamma Risk (time to expiry)
        if dte < 7:
            risk_adj['size_multiplier'] *= 0.5  # Cut size in half
            warnings.append(f"⚠️ HIGH GAMMA: DTE={dte} days (reduce size 50%)")
        elif dte < 10:
            risk_adj['size_multiplier'] *= 0.75
            warnings.append(f"⚠️ ELEVATED GAMMA: DTE={dte} days (reduce size 25%)")
        
        # 3. Liquidity Risk
        if oi_lakh > 0 and oi_lakh < 0.5:
            risk_adj['score_multiplier'] *= 0.7
            risk_adj['size_multiplier'] *= 0.5
            warnings.append(f"⚠️ LOW LIQUIDITY: OI {oi_lakh:.1f}L (reduce size, widen stops)")
        
        # 4. Overall Risk Score
        if risk_score >= 7:
            risk_adj['score_multiplier'] *= 0.8
            warnings.append(f"⚠️ HIGH RISK: Score {risk_score}/10 (proceed with caution)")
        
        return risk_adj, warnings
    
    def _timing_intelligence(self, expert_views):
        """
        Decide optimal entry timing
        Returns: timing_advice dict
        """
        advice = {'enter_now': True, 'wait_reason': None, 'better_timing': None}
        
        dte = expert_views.get('days_to_expiry', 30)
        iv_rank = expert_views.get('iv_rank', 50)
        price_change_7d = expert_views.get('price_change_7d', 0)
        oi_7d = expert_views.get('oi_7d', 0)
        
        # Check if timing is suboptimal
        reasons_to_wait = []
        
        # 1. IV spike - wait for stabilization
        if iv_rank > 95 and abs(price_change_7d) > 5:
            reasons_to_wait.append("IV at extreme high during price move - likely to drop")
            advice['better_timing'] = "Wait 1-2 days for IV to stabilize"
        
        # 2. Very close to expiry with high movement
        if dte < 5 and abs(price_change_7d) > 3:
            reasons_to_wait.append(f"DTE={dte} with volatile price - gamma risk extreme")
            advice['better_timing'] = "Avoid near expiry with volatility"
        
        # 3. Strong directional OI near expiry (likely unwinding)
        if dte < 5 and abs(oi_7d) > 20:
            reasons_to_wait.append(f"Large OI change ({oi_7d:+.1f}%) near expiry - rollover noise")
            advice['better_timing'] = "Wait for next month expiry"
        
        if reasons_to_wait:
            advice['enter_now'] = False
            advice['wait_reason'] = ' | '.join(reasons_to_wait)
        
        return advice
    
    def _conflict_resolution(self, expert_views):
        """
        Understand WHY experts disagree and which to trust
        Returns: resolution dict with preferred expert and reasoning
        """
        greeks_action = expert_views.get('greeks_straddle_action', '')
        greeks_score = expert_views.get('greeks_straddle_score', 0)
        claude_action = expert_views.get('claude_action', '')
        claude_score = expert_views.get('claude_straddle_score', 0)
        
        # No conflict if both agree or one is absent
        if not greeks_action or not claude_action:
            return {'conflict': False}
        
        greeks_is_straddle = 'STRADDLE' in greeks_action
        claude_is_straddle = 'STRADDLE' in claude_action
        
        if greeks_is_straddle == claude_is_straddle:
            greeks_dir = 'SELL' if 'SELL' in greeks_action else 'BUY' if 'BUY' in greeks_action else 'NEUTRAL'
            claude_dir = 'SELL' if 'SELL' in claude_action else 'BUY' if 'BUY' in claude_action else 'NEUTRAL'
            
            if greeks_dir == claude_dir:
                return {'conflict': False}
        
        # We have a conflict - analyze WHY
        resolution = {
            'conflict': True,
            'greeks_view': f"{greeks_action} ({greeks_score:.0f})",
            'claude_view': f"{claude_action} ({claude_score:.0f})",
            'trust': None,
            'reasoning': []
        }
        
        # Decision tree for conflict resolution
        iv_rank = expert_views.get('iv_rank', 50)
        dte = expert_views.get('days_to_expiry', 30)
        blocking_reasons = expert_views.get('claude_blocking_reasons', [])
        
        # Handle NaN/float in blocking_reasons
        if isinstance(blocking_reasons, float) or pd.isna(blocking_reasons):
            blocking_reasons = []
        elif isinstance(blocking_reasons, str):
            blocking_reasons = [blocking_reasons] if blocking_reasons.strip() else []
        
        # Rule 1: Claude blocks = always trust Claude (event risk, IV spike)
        if len(blocking_reasons) > 0:
            resolution['trust'] = 'CLAUDE'
            resolution['reasoning'].append("Claude detected critical risk (event/IV spike) - VETO override")
            return resolution
        
        # Rule 2: Very high IV rank + Greeks recommends sell = trust Greeks
        if iv_rank > 85 and 'SELL' in greeks_action:
            resolution['trust'] = 'GREEKS'
            resolution['reasoning'].append(f"IV rank {iv_rank}% extremely high - Greeks right to sell premium")
            resolution['reasoning'].append("Claude may be overly cautious on high IV")
            return resolution
        
        # Rule 3: Near expiry + high gamma = trust Claude (safer)
        if dte < 7:
            resolution['trust'] = 'CLAUDE'
            resolution['reasoning'].append(f"DTE={dte} days - gamma risk high, trust Claude's caution")
            return resolution
        
        # Rule 4: Strong directional OI = trust Claude (trend expert)
        oi_7d = expert_views.get('oi_7d', 0)
        if abs(oi_7d) > 15:
            resolution['trust'] = 'CLAUDE'
            resolution['reasoning'].append(f"Strong OI trend ({oi_7d:+.1f}%) - Claude specializes in OI analysis")
            return resolution
        
        # Default: Average the opinions
        resolution['trust'] = 'BOTH'
        resolution['reasoning'].append("No clear winner - blend both views with reduced confidence")
        
        return resolution
    
    def _synthesize_decision(self, expert_views):
        """
        TRUE EXPERT INTELLIGENCE: Synthesize, cross-validate, add value
        
        NOT just score aggregation - this is where trading intelligence happens:
        1. Understand expert conflicts & resolve intelligently
        2. Cross-validate signals (OI vs Price vs Greeks vs IV)
        3. Assess risk context (regime, liquidity, timing)
        4. Provide actionable guidance (entry, sizing, exits)
        5. Meta-scoring: Risk-adjusted confidence, not raw scores
        """
        symbol = expert_views['symbol']
        
        # CRITICAL: Check for Claude-OI HARD BLOCKS first (veto power)
        claude_blocking = expert_views.get('claude_blocking_reasons', [])
        claude_action = expert_views.get('claude_action', '')
        claude_straddle_raw_score = expert_views.get('claude_straddle_score', None)
        
        # Handle NaN/float in blocking_reasons (can be NaN from CSV)
        if isinstance(claude_blocking, float) or pd.isna(claude_blocking):
            claude_blocking = []
        elif isinstance(claude_blocking, str):
            claude_blocking = [claude_blocking] if claude_blocking.strip() else []
        
        # VETO if: Claude score=0 OR blocking_reasons exists OR action contains "DO NOT TRADE"
        is_blocked = (
            (claude_straddle_raw_score is not None and claude_straddle_raw_score == 0) or
            (len(claude_blocking) > 0) or
            ('DO NOT TRADE' in str(claude_action).upper() or 'BLOCKED' in str(claude_action).upper())
        )
        
        if is_blocked:
            # EXPERT VETO: Record why this trade is blocked
            greeks_wanted = expert_views.get('greeks_straddle_action', 'N/A')
            greeks_score = expert_views.get('greeks_straddle_score', 0)
            
            blocked = {
                'symbol': symbol,
                'greeks_recommendation': f"{greeks_wanted} ({greeks_score})",
                'claude_veto': claude_action if claude_action else "BLOCKED (score=0)",
                'blocking_reasons': claude_blocking if claude_blocking else ["Score=0 (blocked)"],
                'expert_intelligence': "Claude-OI veto overrides all other signals (critical risk detected)"
            }
            
            # Store separately for reporting
            if not hasattr(self, 'blocked_trades'):
                self.blocked_trades = []
            self.blocked_trades.append(blocked)
            
            # HARD VETO - don't trade
            return None
        
        # ========== STEP 1: RUN EXPERT INTELLIGENCE ANALYSIS ==========
        
        # 1. Cross-validate signals (OI, Price, Greeks alignment)
        alignment_score, alignment_insights = self._analyze_signal_alignment(expert_views)
        
        # 2. Assess risk context (IV regime, gamma, liquidity)
        risk_adjustments, risk_warnings = self._assess_risk_context(expert_views)
        
        # 3. Timing intelligence (enter now vs wait)
        timing_advice = self._timing_intelligence(expert_views)
        
        # 4. Conflict resolution (if experts disagree)
        conflict_resolution = self._conflict_resolution(expert_views)
        
        # ========== STEP 2: EXTRACT BASE SCORES ==========
        
        greeks_straddle_score = expert_views.get('greeks_straddle_score', 0) / 150 * 100  # 0-150 → 0-100
        greeks_dir_score = expert_views.get('greeks_directional_score', 0)  # Already abs value
        claude_straddle_score = expert_views.get('claude_straddle_score', 0)  # Already 0-100
        
        # Get context
        oi_7d = expert_views.get('oi_7d', 0)
        days_to_expiry = expert_views.get('days_to_expiry', 999)
        rqi = expert_views.get('rollover_quality', 100)
        
        # CRITICAL: Filter out rollover noise
        is_rollover_noise = (days_to_expiry <= 5 and abs(oi_7d) > 15 and 
                            (rqi is None or rqi < 30))
        
        # ========== STEP 3: SYNTHESIZE WITH INTELLIGENCE ==========
        
        strategy = None
        unified_score = 0
        confidence = "MODERATE"
        reasoning = []
        expert_count = 0
        expert_intelligence = []  # NEW: Track intelligence insights
        
        # Case 1: Straddle recommendations (combine Greeks + Claude-OI if both available)
        has_greeks_straddle = greeks_straddle_score >= 40  # 60/150 normalized
        has_claude_straddle = claude_straddle_score >= 60
        
        if has_greeks_straddle or has_claude_straddle:
            greeks_action = expert_views.get('greeks_straddle_action', '')
            claude_action = expert_views.get('claude_action', '')
            
            greeks_is_straddle = 'STRADDLE' in greeks_action if greeks_action else False
            claude_is_straddle = 'STRADDLE' in claude_action if claude_action else False
            
            # === INTELLIGENT CONFLICT RESOLUTION ===
            if conflict_resolution['conflict']:
                expert_intelligence.append("🧠 CONFLICT DETECTED:")
                expert_intelligence.extend([f"   - {r}" for r in conflict_resolution['reasoning']])
                
                # Apply conflict resolution
                if conflict_resolution['trust'] == 'GREEKS':
                    unified_score = greeks_straddle_score
                    strategy = greeks_action
                    confidence = "HIGH"
                    reasoning.append(f"✅ Greeks Expert (TRUSTED): {greeks_action} ({expert_views.get('greeks_straddle_score', 0):.0f}/150)")
                    reasoning.append(f"⚠️ Claude-OI (DISCOUNTED): {claude_action} ({claude_straddle_score:.0f}/100)")
                    expert_count = 1
                    
                elif conflict_resolution['trust'] == 'CLAUDE':
                    unified_score = claude_straddle_score
                    strategy = claude_action
                    confidence = "HIGH"
                    reasoning.append(f"✅ Claude-OI Expert (TRUSTED): {claude_action} ({claude_straddle_score:.0f}/100)")
                    reasoning.append(f"⚠️ Greeks (DISCOUNTED): {greeks_action} ({expert_views.get('greeks_straddle_score', 0):.0f}/150)")
                    expert_count = 1
                    
                else:  # BOTH - average with penalty
                    unified_score = (greeks_straddle_score + claude_straddle_score) / 2 * 0.7  # 30% conflict penalty
                    strategy = greeks_action  # Use Greeks action
                    confidence = "MODERATE"
                    reasoning.append(f"⚖️ Greeks: {greeks_action} ({expert_views.get('greeks_straddle_score', 0):.0f}/150)")
                    reasoning.append(f"⚖️ Claude: {claude_action} ({claude_straddle_score:.0f}/100)")
                    reasoning.append("⚠️ Experts disagree - blended with 30% penalty")
                    expert_count = 2
            
            # === NO CONFLICT: Standard combination ===
            elif has_greeks_straddle and has_claude_straddle and greeks_is_straddle and claude_is_straddle:
                # BOTH EXPERTS AGREE
                unified_score = (greeks_straddle_score * 0.6) + (claude_straddle_score * 0.4)
                strategy = greeks_action
                confidence = "VERY HIGH" if unified_score >= 80 else "HIGH"
                reasoning.append(f"✅ Greeks Expert: {greeks_action} ({expert_views.get('greeks_straddle_score', 0):.0f}/150)")
                reasoning.append(f"✅ Claude-OI Expert: {claude_action} ({claude_straddle_score:.0f}/100)")
                expert_count = 2
                expert_intelligence.extend(alignment_insights)  # Add alignment analysis
                
            elif has_greeks_straddle and greeks_is_straddle:
                # Only Greeks recommends straddle
                unified_score = greeks_straddle_score
                strategy = greeks_action
                confidence = "HIGH" if greeks_straddle_score >= 75 else "MODERATE"
                reasoning.append(f"✅ Greeks Expert: {strategy} ({expert_views.get('greeks_straddle_score', 0):.0f}/150)")
                expert_count = 1
                
            elif has_claude_straddle and claude_is_straddle:
                # Only Claude recommends straddle
                unified_score = claude_straddle_score
                strategy = claude_action
                confidence = "MODERATE"
                reasoning.append(f"✅ Claude-OI Expert: {strategy} ({claude_straddle_score:.0f}/100)")
                expert_count = 1
            
            # === APPLY RISK ADJUSTMENTS (Intelligence Layer) ===
            if strategy and 'STRADDLE' in strategy:
                # Apply risk-based score adjustments
                unified_score *= risk_adjustments['score_multiplier']
                expert_intelligence.extend(risk_warnings)
                
                # Check rollover noise
                if not is_rollover_noise and abs(oi_7d) > 10:
                    unified_score *= 0.95
                    expert_intelligence.append(f"ℹ️ Directional OI ({oi_7d:+.1f}%) - minor concern for straddle")
                elif is_rollover_noise:
                    expert_intelligence.append(f"✅ OI {oi_7d:+.1f}% flagged as rollover noise (DTE={days_to_expiry})")
        
        # Case 2: Strong directional from Greeks, weak/no straddle
        elif greeks_dir_score >= 50:
            strategy = expert_views.get('greeks_directional_action', 'DIRECTIONAL')
            
            # CRITICAL: Check if OI is rollover noise
            if is_rollover_noise:
                # Don't take directional trades based on rollover noise
                reasoning.append(f"❌ Directional signal rejected: OI {oi_7d:+.1f}% is rollover noise (DTE={days_to_expiry})")
                return None
            
            unified_score = greeks_dir_score
            confidence = "HIGH" if greeks_dir_score >= 70 else "MODERATE"
            reasoning.append(f"✅ Greeks Expert: {strategy} ({greeks_dir_score:.0f})")
        
        else:
            # No strong signal from any expert
            return None
        
        # ========== STEP 4: APPLY TIMING INTELLIGENCE ==========
        
        # Check if timing is optimal
        if not timing_advice['enter_now']:
            expert_intelligence.append(f"⏰ TIMING: {timing_advice['wait_reason']}")
            expert_intelligence.append(f"   → Better: {timing_advice['better_timing']}")
            # Reduce score for suboptimal timing
            unified_score *= 0.8
            confidence = "MODERATE" if confidence == "HIGH" else "LOW" if confidence == "MODERATE" else confidence
        
        # Must meet minimum threshold
        if unified_score < 40:
            return None
        
        # Get additional details
        result = {
            'symbol': symbol,
            'strategy': strategy,
            'unified_score': unified_score,
            'confidence': confidence,
            'reasoning': reasoning,
            'expert_intelligence': expert_intelligence,  # NEW: Intelligence insights
            'alignment_score': alignment_score,  # NEW: Cross-validation score
            'risk_adjustments': risk_adjustments,  # NEW: Risk multipliers applied
            'expert_count': expert_count,
            'expert_scores': {
                'greeks_straddle': expert_views.get('greeks_straddle_score', 0),
                'greeks_directional': expert_views.get('greeks_directional_score', 0),
                'claude_straddle': expert_views.get('claude_straddle_score', 0)
            },
            'context': {
                'oi_7d': oi_7d,
                'days_to_expiry': days_to_expiry,
                'is_rollover_noise': is_rollover_noise,
                'timing_optimal': timing_advice['enter_now'],  # NEW: Timing assessment
                'timing_advice': timing_advice.get('better_timing', 'Enter now')  # NEW
            }
        }
        
        # Add strategy-specific details
        if 'STRADDLE' in strategy:
            result['theta'] = expert_views.get('greeks_theta', 0)
            result['credit'] = expert_views.get('greeks_credit', 0)
            result['rom'] = expert_views.get('greeks_rom', 0)
            result['be_upper'] = expert_views.get('greeks_be_upper', 0)
            result['be_lower'] = expert_views.get('greeks_be_lower', 0)
        
        return result
    
    def analyze_all_symbols(self):
        """
        Main analysis loop - combine all data sources
        """
        if self.trend_df is None or self.greeks_df is None:
            print("❌ Missing required data. Please load data first.")
            return
        
        print("="*100)
        print("🎯 ANALYZING ALL SYMBOLS".center(100))
        print("="*100)
        print()
        
        # Merge trend and Greeks data
        # Include rollover columns from trend data
        merged = self.trend_df.merge(
            self.greeks_df[['symbol', 'atm_iv', 'iv_percentile', 'pcr', 'ce_delta', 'pe_delta', 
                           'ce_gamma', 'pe_gamma', 'ce_theta', 'pe_theta', 'net_theta_per_trading_day',
                           'net_vega', 'total_credit', 'rom_pct', 'overall_risk_score', 'dte_days',
                           'spot', 'be_upper', 'be_lower']],
            on='symbol',
            how='inner'
        )
        
        # Add rollover intelligence columns if available
        rollover_cols = ['days_to_current_expiry', 'next_oi_change_percent', 'next_price_change_percent',
                        'rollover_quality_index', 'roll_skew', 'term_structure_slope_percent']
        for col in rollover_cols:
            if col not in merged.columns and col in self.trend_df.columns:
                # These should already be in merged from trend_df, but check
                pass
        
        print(f"Analyzing {len(merged)} symbols with complete data...\n")
        
        for idx, row in merged.iterrows():
            symbol = row['symbol']
            
            # Step 1: Calculate trend score (OI momentum)
            trend_data = self.calculate_trend_score(symbol, row)
            
            # Step 2: Calculate timing score (Greeks + IV)
            timing_data = self.calculate_timing_score(symbol, row, row)
            
            # Step 3: Determine strategy mode
            mode, strategy = self.determine_strategy_mode(trend_data, timing_data, row)
            
            if mode == 'NEUTRAL':
                continue  # Skip neutral signals
            
            # Step 4: Calculate unified score
            unified_score = trend_data['score'] + timing_data['score']
            
            # Step 5: Risk adjustment
            risk_data = self.calculate_risk_score(row, 'directional' if 'BUY' in strategy or 'SELL_FUTURE' in strategy else 'straddle')
            unified_score += risk_data['penalty']
            
            # Filter by minimum threshold
            if unified_score < 40:
                continue
            
            # Step 6: Calculate position size
            position_size = self.calculate_position_size(unified_score, strategy, row)
            
            # Step 7: Assemble result
            result = {
                'symbol': symbol,
                'unified_score': unified_score,
                'mode': mode,
                'strategy': strategy,
                'position_size': position_size,
                'trend_score': trend_data['score'],
                'timing_score': timing_data['score'],
                'oi_7d': trend_data['oi_7d'],
                'price_chg': timing_data['price_chg'],
                'iv_rank': timing_data['iv_rank'],
                'pcr': timing_data['pcr'],
                'atm_iv': row.get('atm_iv', 0),
                'spot': row.get('spot', 0),
                'days_to_expiry': row.get('days_to_current_expiry', 999),
                'next_oi': row.get('next_oi_change_percent', None),
                'rollover_quality': row.get('rollover_quality_index', None),
                'signals': trend_data['signals'] + timing_data['signals'] + risk_data['signals']
            }
            
            # Add Greeks-specific data
            if 'STRADDLE' in strategy:
                # Greeks CSV contains SHORT straddle perspective
                # If strategy is BUY_STRADDLE, flip signs
                theta_base = row.get('net_theta_per_trading_day', 0)
                vega_base = row.get('net_vega', 0)
                credit_base = row.get('total_credit', 0)
                
                if strategy == 'BUY_STRADDLE':
                    # Flip signs for buying
                    theta_display = -theta_base  # Negative theta (you pay decay)
                    vega_display = -vega_base    # Positive vega (you gain from IV rise)
                    debit_display = credit_base  # You PAY this amount
                    credit_label = 'debit'
                else:  # SELL_STRADDLE
                    theta_display = theta_base
                    vega_display = vega_base
                    debit_display = credit_base
                    credit_label = 'credit'
                
                result.update({
                    'net_theta_day': theta_display,
                    'net_vega': vega_display,
                    'credit_or_debit': debit_display,
                    'premium_type': credit_label,
                    'rom_pct': row.get('rom_pct', 0),
                    'be_upper': row.get('be_upper', 0),
                    'be_lower': row.get('be_lower', 0),
                    'dte': row.get('dte_days', 0)
                })
            else:
                result.update({
                    'delta': row.get('ce_delta', 0) if 'CALL' in strategy else row.get('pe_delta', 0),
                    'delta_exposure': row.get('spot', 0) * abs(row.get('ce_delta', 0) if 'CALL' in strategy else row.get('pe_delta', 0))
                })
            
            self.unified_results.append(result)
        
        # Sort by unified score
        self.unified_results = sorted(self.unified_results, key=lambda x: x['unified_score'], reverse=True)
        
        print(f"✅ Found {len(self.unified_results)} actionable opportunities\n")
    
    def print_unified_report(self):
        """Print comprehensive unified analysis report"""
        if not self.unified_results:
            print("❌ No results to display.")
            return
        
        print("\n")
        print("="*120)
        print("OPTIONS COMMAND CENTER - EXPERT SYNTHESIS".center(120))
        print("="*120)
        
        # Group by strategy type
        straddles = [r for r in self.unified_results if 'STRADDLE' in r['strategy']]
        directional = [r for r in self.unified_results if 'STRADDLE' not in r['strategy']]
        
        # HIGH CONVICTION
        high_conv = [r for r in self.unified_results if r['unified_score'] >= 75]
        
        if high_conv:
            print(f"\n{'='*120}")
            print("🔥 HIGH CONVICTION OPPORTUNITIES (Score ≥ 75)".center(120))
            print("="*120)
            
            for r in high_conv[:15]:
                expert_cnt = r.get('expert_count', 1)
                agreement_badge = "🎯 CONSENSUS" if expert_cnt >= 2 else ""
                
                print(f"\n{'─'*120}")
                print(f"Symbol: {r['symbol']:<12} | Unified Score: {r['unified_score']:.0f} | Strategy: {r['strategy']:<25} | Confidence: {r['confidence']} {agreement_badge}")
                print("─"*120)
                
                print(f"👥 EXPERT OPINIONS ({expert_cnt} expert{'s' if expert_cnt > 1 else ''}):")
                for reason in r.get('reasoning', []):
                    print(f"   {reason}")
                
                # NEW: Show expert intelligence insights
                intelligence = r.get('expert_intelligence', [])
                if intelligence:
                    print(f"\n🧠 EXPERT INTELLIGENCE:")
                    for insight in intelligence:
                        print(f"   {insight}")
                
                # Show alignment score
                alignment = r.get('alignment_score', 50)
                if alignment != 50:  # Only show if not neutral
                    if alignment >= 70:
                        print(f"\n✅ SIGNAL ALIGNMENT: {alignment:.0f}/100 (Strong cross-validation)")
                    elif alignment < 40:
                        print(f"\n⚠️ SIGNAL ALIGNMENT: {alignment:.0f}/100 (Mixed signals)")
                
                # Show context
                ctx = r.get('context', {})
                if ctx:
                    print(f"\n📊 MARKET CONTEXT:")
                    print(f"   • OI 7D: {ctx.get('oi_7d', 0):+.1f}%")
                    print(f"   • Days to Expiry: {ctx.get('days_to_expiry', 'N/A')}")
                    
                    # Show timing advice
                    if not ctx.get('timing_optimal', True):
                        print(f"   ⏰ TIMING: {ctx.get('timing_advice', 'Consider waiting')}")
                    else:
                        print(f"   ✅ TIMING: Optimal entry window")
                    
                    if ctx.get('is_rollover_noise'):
                        print(f"   ⚠️ Rollover week - OI data may contain noise")
                
                # Show details for straddles
                if 'STRADDLE' in r['strategy']:
                    print(f"\n💰 STRADDLE DETAILS:")
                    theta = r.get('theta', 0)
                    credit = r.get('credit', 0)
                    rom = r.get('rom', 0)
                    be_upper = r.get('be_upper', 0)
                    be_lower = r.get('be_lower', 0)
                    
                    if 'SELL' in r['strategy']:
                        print(f"   • Credit Collected: ₹{credit:.0f}")
                        print(f"   • Daily Theta Income: ₹{theta:.2f}/day")
                        print(f"   • RoM: {rom:.1f}% | Breakeven: {be_lower:.0f} - {be_upper:.0f}")
                        if theta > 0 and credit > 0:
                            print(f"   • Break-even Time: ~{int(credit / theta)} days")
                    else:
                        print(f"   • Debit Paid: ₹{credit:.0f}")
                        print(f"   • Daily Theta Cost: ₹{theta:.2f}/day")
                        print(f"   • Breakeven: {be_lower:.0f} - {be_upper:.0f}")
                
                # PROFESSIONAL: Show exit rules
                print(f"\n🎯 EXIT RULES:")
                exit_rules = self.generate_exit_rules(r)
                for rule in exit_rules[:4]:
                    print(f"   {rule}")
        
        # STRADDLE OPPORTUNITIES
        if straddles:
            print(f"\n{'='*120}")
            print(f"⭕ STRADDLE OPPORTUNITIES ({len(straddles)} signals)")
            print("="*120)
            print(f"{'Symbol':<12} {'Score':>6} {'Conf':<12} {'Strategy':<20} {'Experts':<20} {'Theta/Day':>10} {'Credit':>8}")
            print("-"*120)
            
            for r in straddles[:20]:
                expert_cnt = r.get('expert_count', 1)
                scores = r['expert_scores']
                
                if expert_cnt >= 2:
                    expert_str = f"G:{scores['greeks_straddle']:.0f} C:{scores['claude_straddle']:.0f} 🎯"
                else:
                    if scores.get('greeks_straddle', 0) > 0:
                        expert_str = f"Greeks {scores['greeks_straddle']:.0f}/150"
                    elif scores.get('claude_straddle', 0) > 0:
                        expert_str = f"Claude {scores['claude_straddle']:.0f}/100"
                    else:
                        expert_str = "Unknown"
                
                print(f"{r['symbol']:<12} {r['unified_score']:>6.0f} {r['confidence']:<12} {r['strategy']:<20} "
                      f"{expert_str:<20} {r.get('theta', 0):>10.1f} {r.get('credit', 0):>8.0f}")
        
        # DIRECTIONAL OPPORTUNITIES
        if directional:
            print(f"\n{'='*120}")
            print(f"📈 DIRECTIONAL OPPORTUNITIES ({len(directional)} signals)")
            print("="*120)
            print(f"{'Symbol':<12} {'Score':>6} {'Confidence':<12} {'Strategy':<20} {'Expert':<15} {'OI 7D%':>8}")
            print("-"*120)
            
            for r in directional[:20]:
                expert_str = f"{r['expert_scores'].get('greeks_directional', 0):.0f}"
                oi_7d = r['context'].get('oi_7d', 0)
                print(f"{r['symbol']:<12} {r['unified_score']:>6.0f} {r['confidence']:<12} {r['strategy']:<20} "
                      f"{expert_str:<15} {oi_7d:>8.1f}")
        
        # EXPERT VETOES (Claude-OI blocks)
        if hasattr(self, 'blocked_trades') and self.blocked_trades:
            print(f"\n{'='*120}")
            print(f"🚫 EXPERT VETOES - TRADES BLOCKED ({len(self.blocked_trades)})")
            print("="*120)
            print("⚠️  Claude-OI blocked these despite Greeks recommendation (event risk, IV issues, etc.)")
            print(f"{'Symbol':<12} {'Greeks Wanted':<30} {'Claude Veto':<20} {'Reason':<50}")
            print("-"*120)
            
            for b in self.blocked_trades[:10]:
                reasons_str = ', '.join(b['blocking_reasons'][:2]) if isinstance(b['blocking_reasons'], list) else str(b['blocking_reasons'])
                print(f"{b['symbol']:<12} {b['greeks_recommendation']:<30} {b['claude_veto']:<20} {reasons_str[:48]}")
        
        # ROLLOVER ANALYSIS  
        rollover_affected = [r for r in self.unified_results if r['context'].get('is_rollover_noise', False)]
        
        if rollover_affected:
            print(f"\n{'='*120}")
            print(f"🔄 ROLLOVER NOISE FILTERED ({len(rollover_affected)} signals)")
            print("="*120)
            print("✅ These directional signals were filtered due to rollover noise:")
            for r in rollover_affected[:10]:
                dte = r['context'].get('days_to_expiry', 'N/A')
                oi = r['context'].get('oi_7d', 0)
                print(f"   {r['symbol']:<12} OI: {oi:+.1f}% (DTE: {dte}) - Rollover noise, not directional signal")
        
        # PORTFOLIO SUMMARY
        print(f"\n{'='*120}")
        print("📊 PORTFOLIO SUMMARY")
        print("="*120)
        
        total_opportunities = len(self.unified_results)
        high_conviction = len([r for r in self.unified_results if r['unified_score'] >= 75])
        medium_conviction = len([r for r in self.unified_results if 60 <= r['unified_score'] < 75])
        consensus_trades = len([r for r in self.unified_results if r.get('expert_count', 1) >= 2])
        
        print(f"Total Opportunities: {total_opportunities}")
        print(f"  • HIGH Conviction (≥75): {high_conviction}")
        print(f"  • MEDIUM Conviction (60-74): {medium_conviction}")
        print(f"  • REGULAR Conviction (40-59): {total_opportunities - high_conviction - medium_conviction}")
        print(f"\nBy Expert Agreement:")
        print(f"  • 🎯 CONSENSUS (2+ experts agree): {consensus_trades}")
        print(f"  • Single expert recommendation: {total_opportunities - consensus_trades}")
        print(f"\nBy Strategy Type:")
        print(f"  • Straddles: {len(straddles)}")
        print(f"  • Directional: {len(directional)}")
        
        if hasattr(self, 'blocked_trades') and self.blocked_trades:
            print(f"\n⚠️  Expert Vetoes:")
            print(f"  • 🚫 Blocked by Claude-OI: {len(self.blocked_trades)}")
        
        # Calculate portfolio Greeks if straddles present
        sell_straddles = [r for r in straddles if 'SELL' in r['strategy']]
        buy_straddles = [r for r in straddles if 'BUY' in r['strategy']]
        
        # PROFESSIONAL: Calculate Portfolio Greeks
        if self.greeks_df is not None and straddles:
            print(f"\n{'='*100}")
            print("⚖️  PORTFOLIO GREEKS ANALYSIS (Top 10 Straddles)")
            print("="*100)
            
            top_straddles = straddles[:10]
            port_theta = 0
            port_gamma = 0
            port_vega = 0
            port_delta = 0
            total_margin = 0
            total_credit = 0
            
            for opp in top_straddles:
                symbol = opp['symbol']
                greeks_row = self.greeks_df[self.greeks_df['symbol'] == symbol]
                
                if not greeks_row.empty:
                    greeks_row = greeks_row.iloc[0]
                    spot = greeks_row.get('spot', 0)
                    
                    # Aggregate Greeks (assume 1 lot each)
                    port_theta += opp.get('theta', 0)
                    port_gamma += (greeks_row.get('ce_gamma', 0) + greeks_row.get('pe_gamma', 0))
                    port_vega += greeks_row.get('net_vega', 0)
                    port_delta += greeks_row.get('ce_delta', 0) + greeks_row.get('pe_delta', 0)
                    
                    # Calculate margin (20% of spot per lot)
                    total_margin += spot * 0.20
                    total_credit += opp.get('credit', 0)
            
            # Display
            print(f"Net Portfolio Greeks (1 lot each, {len(top_straddles)} positions):")
            print(f"  • Net Delta: {port_delta:.3f} (should be ~0 for straddles)")
            print(f"  • Net Gamma: {port_gamma:.4f} (risk per 1% move)")
            print(f"  • Net Vega:  ₹{port_vega:.0f} (P&L per 1% IV change)")
            print(f"  • Net Theta: ₹{port_theta:.1f}/day (daily income)")
            
            print(f"\nCapital Metrics:")
            print(f"  • Total Margin Required: ₹{total_margin:,.0f}")
            print(f"  • Total Credit Collected: ₹{total_credit:.0f}")
            print(f"  • Margin Utilization: {(total_margin/self.PORTFOLIO_SIZE)*100:.1f}%")
            print(f"  • Break-even Days: ~{int(total_credit/port_theta) if port_theta > 0 else 'N/A'}")
            
            # RISK WARNINGS
            print(f"\nRisk Assessment:")
            if abs(port_delta) > 0.5:
                print(f"  ⚠️  HIGH Delta Bias: {port_delta:.3f} (portfolio losing neutrality!)")
            else:
                print(f"  ✅ Delta Neutral: {port_delta:.3f} (well balanced)")
            
            if port_gamma > self.MAX_NET_GAMMA:
                print(f"  🚨 GAMMA RISK: {port_gamma:.4f} exceeds limit {self.MAX_NET_GAMMA}")
            else:
                print(f"  ✅ Gamma Risk: {port_gamma:.4f} (within limits)")
            
            gamma_risk_1pct = port_gamma * 5000 * 5000 * 0.01  # Assuming avg spot ~₹5000
            print(f"  📊 Est. loss per 1% market move: ₹{gamma_risk_1pct:.0f}")
            
            if (total_margin/self.PORTFOLIO_SIZE)*100 > self.MAX_MARGIN_UTIL:
                print(f"  ⚠️  Margin utilization {(total_margin/self.PORTFOLIO_SIZE)*100:.1f}% exceeds {self.MAX_MARGIN_UTIL}%")
            else:
                print(f"  ✅ Margin utilization: {(total_margin/self.PORTFOLIO_SIZE)*100:.1f}% (healthy)")
        
        print("\n" + "="*120)
        
        # Export results
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = f"options_command_center_results_{timestamp}.csv"
        pd.DataFrame(self.unified_results).to_csv(output_file, index=False)
        print(f"✅ Results exported to {output_file}")
        print("="*120)


def main():
    """Main execution"""
    print("\n")
    print("="*120)
    print("OPTIONS COMMAND CENTER".center(120))
    print("Professional-Grade Multi-Dimensional Options Trading System".center(120))
    print("="*120)
    print()
    
    # Initialize
    occ = OptionsCommandCenter()
    
    # Load data
    occ.load_data()
    
    # NEW ARCHITECTURE: Combine expert opinions
    # This respects specialist scanners instead of reimplementing
    occ.combine_expert_opinions()
    
    # FALLBACK: If no expert results available, use heuristic analysis
    if not occ.unified_results:
        print("⚠️  No expert results found, using fallback heuristic analysis")
        occ.analyze_all_symbols()
    
    # Print report
    occ.print_unified_report()


if __name__ == "__main__":
    main()

