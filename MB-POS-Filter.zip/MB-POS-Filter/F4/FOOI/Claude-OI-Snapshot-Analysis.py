import pandas as pd
import numpy as np
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

class FNOSnapshotAnalyzer:
    """
    Analyzes multi-day FNO snapshot data to identify high-conviction trading opportunities
    """
    
    def __init__(self, csv_files, iv_data_file=None):
        """
        Initialize with list of CSV file paths
        csv_files: list of file paths in chronological order
        iv_data_file: optional path to IV data CSV (from options screener)
        """
        self.csv_files = csv_files
        self.iv_data_file = iv_data_file
        self.data = None
        self.iv_data = None
        self.symbols = None
        self.analysis_results = []
        
    def load_data(self):
        """Load and combine all CSV files"""
        dfs = []
        for file in self.csv_files:
            df = pd.read_csv(file)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            dfs.append(df)
        
        self.data = pd.concat(dfs, ignore_index=True)
        self.data = self.data.sort_values(['symbol', 'timestamp'])
        self.symbols = self.data['symbol'].unique()
        print(f"✓ Loaded {len(self.csv_files)} files with {len(self.symbols)} symbols")
        
        # Load IV data if provided
        if self.iv_data_file:
            try:
                self.iv_data = pd.read_csv(self.iv_data_file)
                # Create lookup dictionary for fast access
                self.iv_lookup = {}
                for _, row in self.iv_data.iterrows():
                    symbol = row['Instrument']
                    self.iv_lookup[symbol] = {
                        'atm_iv': row['ATMIV'],
                        'iv_change': row['ATMIVChange'],
                        'iv_percentile': row['IVPercentile'],
                        'pcr': row['PCR'],
                        'max_pain': row['MaxPain'],
                        'event': row.get('Event', '-')
                    }
                print(f"✓ Loaded IV data for {len(self.iv_lookup)} symbols")
            except Exception as e:
                print(f"⚠️ Could not load IV data: {e}")
                self.iv_data = None
                self.iv_lookup = {}
        else:
            self.iv_lookup = {}
        
        return self
    
    def analyze_oi_momentum(self, symbol_data):
        """Analyze OI momentum trends"""
        oi_changes = symbol_data['current_oi_change_percent'].values
        
        # Check for consistent buildup or decline
        if len(oi_changes) < 2:
            return {'trend': 'insufficient_data', 'strength': 0, 'consistency': 0}
        
        # Use EWMA (recent-weighted) and short-window slope for responsiveness
        oi_series = pd.Series(oi_changes)
        ewma_short = oi_series.ewm(halflife=3, adjust=False).mean().iloc[-1]
        ewma_long = oi_series.ewm(halflife=8, adjust=False).mean().iloc[-1]
        slope_window = min(7, len(oi_series))
        recent_idx = np.arange(slope_window)
        recent_vals = oi_series.iloc[-slope_window:].values
        try:
            slope = np.polyfit(recent_idx, recent_vals, 1)[0]
        except Exception:
            slope = 0.0
        
        # Volatility-normalized signal (z-score over recent history with soft clipping)
        hist_window = min(60, len(oi_series))
        hist_vals = oi_series.iloc[-hist_window:]
        mu = np.mean(hist_vals)
        sigma = np.std(hist_vals) + 1e-9
        z_signal = (ewma_short - mu) / sigma
        
        # Soft clipping: preserve extreme signals with diminishing returns
        # z <= 5: no change
        # z > 5: soft compress using tanh: 5 + 2*tanh((z-5)/3)
        # This allows z=8 → 6.8, z=12 → 7.9 (preserves ordering, reduces magnitude)
        if z_signal > 5.0:
            z_signal = 5.0 + 2.0 * np.tanh((z_signal - 5.0) / 3.0)
        elif z_signal < -5.0:
            z_signal = -5.0 - 2.0 * np.tanh((-z_signal - 5.0) / 3.0)
        z_signal = float(z_signal)
        
        # Hysteresis thresholds and ADAPTIVE N-of-M persistence
        enter_thresh = 1.2
        exit_thresh = 0.8
        m_window = min(5, len(oi_series))
        recent_signs = (oi_series.iloc[-m_window:] > 0).astype(int)
        pos_hits = int(recent_signs.sum())
        neg_hits = int(m_window - pos_hits)
        
        # ADAPTIVE: Lower threshold for extreme z-scores (fast market response)
        # Normal: 3 of 5 (60% consensus)
        # Extreme (|z| > 3): 2 of 5 (40% consensus) - faster trigger
        if abs(z_signal) >= 3.0:
            require_hits = max(2, int(m_window * 0.4))  # 40% for extreme moves
        else:
            require_hits = max(3, int(m_window * 0.6))  # 60% for normal moves
        
        # Determine trend using z-normalized recent-weighted signal with hysteresis and persistence
        signal_value = z_signal
        if signal_value > enter_thresh and slope >= 0 and pos_hits >= require_hits:
            trend_direction = 'buildup'
        elif signal_value < -enter_thresh and slope <= 0 and neg_hits >= require_hits:
            trend_direction = 'decline'
        elif abs(signal_value) < exit_thresh:
            trend_direction = 'neutral'
        else:
            # Keep direction only if persistence supports; otherwise neutral
            if slope >= 0 and pos_hits >= require_hits:
                trend_direction = 'buildup'
            elif slope <= 0 and neg_hits >= require_hits:
                trend_direction = 'decline'
            else:
                trend_direction = 'neutral'
        
        # Consistency over recent bars
        if trend_direction == 'buildup':
            consistency = np.mean(recent_vals > 0) * 100
        elif trend_direction == 'decline':
            consistency = np.mean(recent_vals < 0) * 100
        else:
            consistency = 50
        
        # Momentum fade: short vs long EWMA gap (positive fade when weakening)
        # For buildup, fading if short<long; for decline, fading if short>long
        ewma_gap = ewma_short - ewma_long
        if trend_direction == 'buildup':
            momentum_fade = max(0.0, -ewma_gap)
        elif trend_direction == 'decline':
            momentum_fade = max(0.0, ewma_gap)
        else:
            momentum_fade = 0.0
        
        return {
            'trend': trend_direction,
            'avg_oi_change': float(ewma_short),
            'strength': float(abs(signal_value)),
            'consistency': float(consistency),
            'momentum_fade': float(momentum_fade),
            'latest_oi': float(oi_changes[-1])
        }
    
    def analyze_price_momentum(self, symbol_data):
        """Analyze price momentum and sustainability"""
        price_changes = symbol_data['current_price_change_percent'].values
        
        if len(price_changes) < 2:
            return {'trend': 'insufficient_data', 'strength': 0, 'sustainability': 0}
        
        # Use EWMA (recent-weighted) and short-window slope for responsiveness
        pr_series = pd.Series(price_changes)
        ewma_short = pr_series.ewm(halflife=3, adjust=False).mean().iloc[-1]
        ewma_long = pr_series.ewm(halflife=8, adjust=False).mean().iloc[-1]
        slope_window = min(7, len(pr_series))
        recent_idx = np.arange(slope_window)
        recent_vals = pr_series.iloc[-slope_window:].values
        try:
            slope = np.polyfit(recent_idx, recent_vals, 1)[0]
        except Exception:
            slope = 0.0
        
        # Volatility-normalized signal (z-score over recent history with soft clipping)
        hist_window = min(60, len(pr_series))
        hist_vals = pr_series.iloc[-hist_window:]
        mu = np.mean(hist_vals)
        sigma = np.std(hist_vals) + 1e-9
        z_signal = (ewma_short - mu) / sigma
        
        # Soft clipping: preserve extreme signals with diminishing returns
        if z_signal > 5.0:
            z_signal = 5.0 + 2.0 * np.tanh((z_signal - 5.0) / 3.0)
        elif z_signal < -5.0:
            z_signal = -5.0 - 2.0 * np.tanh((-z_signal - 5.0) / 3.0)
        z_signal = float(z_signal)
        
        # Hysteresis thresholds and ADAPTIVE N-of-M persistence
        enter_thresh = 1.2
        exit_thresh = 0.8
        m_window = min(5, len(pr_series))
        recent_signs = (pr_series.iloc[-m_window:] > 0).astype(int)
        pos_hits = int(recent_signs.sum())
        neg_hits = int(m_window - pos_hits)
        
        # ADAPTIVE: Lower threshold for extreme z-scores (fast market response)
        if abs(z_signal) >= 3.0:
            require_hits = max(2, int(m_window * 0.4))  # 40% for extreme moves
        else:
            require_hits = max(3, int(m_window * 0.6))  # 60% for normal moves
        
        # Determine trend using z-normalized recent-weighted signal with hysteresis and persistence
        signal_value = z_signal
        if signal_value > enter_thresh and slope >= 0 and pos_hits >= require_hits:
            trend_direction = 'bullish'
        elif signal_value < -enter_thresh and slope <= 0 and neg_hits >= require_hits:
            trend_direction = 'bearish'
        elif abs(signal_value) < exit_thresh:
            trend_direction = 'neutral'
        else:
            if slope >= 0 and pos_hits >= require_hits:
                trend_direction = 'bullish'
            elif slope <= 0 and neg_hits >= require_hits:
                trend_direction = 'bearish'
            else:
                trend_direction = 'neutral'
        
        # Sustainability over recent bars
        if trend_direction == 'bullish':
            sustainability = np.mean(recent_vals > 0) * 100
        elif trend_direction == 'bearish':
            sustainability = np.mean(recent_vals < 0) * 100
        else:
            sustainability = 50
        
        return {
            'trend': trend_direction,
            'avg_price_change': float(ewma_short),
            'strength': float(abs(signal_value)),
            'sustainability': float(sustainability),
            'latest_price_change': float(price_changes[-1])
        }
    
    def analyze_price_oi_divergence(self, symbol_data):
        """Detect price-OI divergences with rolling correlation analysis"""
        latest = symbol_data.iloc[-1]
        price_oi_ratio = latest['price_oi_ratio_primary']
        
        # Multi-timeframe rolling correlation analysis
        if len(symbol_data) < 7:
            # Fallback to simple ratio if insufficient data
            if abs(price_oi_ratio) > 5:
                return {
                    'divergence': 'strong_bearish' if price_oi_ratio > 0 else 'strong_buildup',
                    'severity': abs(price_oi_ratio),
                    'signal': 'WARNING' if price_oi_ratio > 0 else 'OPPORTUNITY',
                    'correlation_3d': 0.0,
                    'correlation_5d': 0.0,
                    'correlation_7d': 0.0
                }
            elif abs(price_oi_ratio) > 2:
                return {
                    'divergence': 'moderate_bearish' if price_oi_ratio > 0 else 'moderate_buildup',
                    'severity': abs(price_oi_ratio),
                    'signal': 'CAUTION' if price_oi_ratio > 0 else 'WATCH',
                    'correlation_3d': 0.0,
                    'correlation_5d': 0.0,
                    'correlation_7d': 0.0
                }
            else:
                return {
                    'divergence': 'aligned',
                    'severity': abs(price_oi_ratio),
                    'signal': 'HEALTHY',
                    'correlation_3d': 0.0,
                    'correlation_5d': 0.0,
                    'correlation_7d': 0.0
                }
        
        # Calculate rolling correlations for different timeframes
        price_changes = symbol_data['current_price_change_percent'].values
        oi_changes = symbol_data['current_oi_change_percent'].values
        
        try:
            # 3-day, 5-day, and 7-day correlations
            corr_3d = np.corrcoef(price_changes[-3:], oi_changes[-3:])[0, 1] if len(symbol_data) >= 3 else 0.0
            corr_5d = np.corrcoef(price_changes[-5:], oi_changes[-5:])[0, 1] if len(symbol_data) >= 5 else 0.0
            corr_7d = np.corrcoef(price_changes[-7:], oi_changes[-7:])[0, 1] if len(symbol_data) >= 7 else 0.0
            
            # Handle NaN correlations (when variance is zero)
            corr_3d = 0.0 if np.isnan(corr_3d) else corr_3d
            corr_5d = 0.0 if np.isnan(corr_5d) else corr_5d
            corr_7d = 0.0 if np.isnan(corr_7d) else corr_7d
            
        except Exception:
            corr_3d = corr_5d = corr_7d = 0.0
        
        # Weighted correlation (shorter-term gets more weight)
        avg_corr = (0.5 * corr_3d + 0.3 * corr_5d + 0.2 * corr_7d)
        
        # PRIORITY 1: Check for TRAPS (price moving without OI support) - HIGHEST PRIORITY
        # This is the most dangerous pattern and must be flagged first
        if abs(price_oi_ratio) > 8 and abs(avg_corr) < 0.2:
            # Extreme ratio + no correlation = TRAP
            if price_oi_ratio > 0:
                return {
                    'divergence': 'trap_bullish_exhaustion',
                    'severity': abs(price_oi_ratio) * 2,
                    'signal': 'TRAP',
                    'alignment_type': 'TRAP: Price up without OI (Exhaustion)',
                    'correlation_3d': corr_3d,
                    'correlation_5d': corr_5d,
                    'correlation_7d': corr_7d
                }
            else:
                return {
                    'divergence': 'trap_bearish_capitulation',
                    'severity': abs(price_oi_ratio) * 2,
                    'signal': 'TRAP',
                    'alignment_type': 'TRAP: Price down without OI (Capitulation)',
                    'correlation_3d': corr_3d,
                    'correlation_5d': corr_5d,
                    'correlation_7d': corr_7d
                }
        
        # PRIORITY 2: Check for DIVERGENCES (price-OI disagree) - SECOND PRIORITY
        # Enhanced divergence detection combining ratio and correlation
        # Strong bearish divergence: high ratio + negative correlation
        elif price_oi_ratio > 5 and avg_corr < -0.3:
            return {
                'divergence': 'strong_bearish',
                'severity': abs(price_oi_ratio) * (1 + abs(avg_corr)),
                'signal': 'WARNING',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
        # Strong bullish divergence: negative ratio + positive correlation (OI building without price)
        elif price_oi_ratio < -5 and avg_corr > 0.3:
            return {
                'divergence': 'strong_buildup',
                'severity': abs(price_oi_ratio) * (1 + abs(avg_corr)),
                'signal': 'OPPORTUNITY',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
        # Moderate bearish divergence
        elif price_oi_ratio > 2 and avg_corr < -0.2:
            return {
                'divergence': 'moderate_bearish',
                'severity': abs(price_oi_ratio) * (1 + abs(avg_corr)),
                'signal': 'CAUTION',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
        # Moderate bullish divergence
        elif price_oi_ratio < -2 and avg_corr > 0.2:
            return {
                'divergence': 'moderate_buildup',
                'severity': abs(price_oi_ratio) * (1 + abs(avg_corr)),
                'signal': 'WATCH',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
        # Categorize based on correlation strength (cleaner terminology)
        if avg_corr > 0.7:
            # Strong positive correlation - trending together
            return {
                'divergence': 'strong_alignment',
                'severity': abs(price_oi_ratio),
                'signal': 'TRENDING',
                'alignment_type': 'STRONG ALIGNMENT (Trending)',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
        elif avg_corr < -0.7:
            # Strong negative correlation - diverging
            return {
                'divergence': 'strong_divergence',
                'severity': abs(price_oi_ratio),
                'signal': 'DIVERGENCE',
                'alignment_type': 'STRONG DIVERGENCE (Warning/Opportunity)',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
        elif 0.3 <= avg_corr <= 0.7:
            # Moderate positive correlation
            return {
                'divergence': 'moderate_alignment',
                'severity': abs(price_oi_ratio),
                'signal': 'ALIGNED',
                'alignment_type': 'MODERATE ALIGNMENT',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
        elif -0.7 <= avg_corr <= -0.3:
            # Moderate negative correlation
            return {
                'divergence': 'moderate_divergence',
                'severity': abs(price_oi_ratio),
                'signal': 'DIVERGENCE',
                'alignment_type': 'MODERATE DIVERGENCE',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
        else:
            # Weak/no correlation - choppy, no conviction
            return {
                'divergence': 'weak_relationship',
                'severity': abs(price_oi_ratio),
                'signal': 'CHOPPY',
                'alignment_type': 'WEAK RELATIONSHIP (Choppy/No conviction)',
                'correlation_3d': corr_3d,
                'correlation_5d': corr_5d,
                'correlation_7d': corr_7d
            }
    
    def analyze_writer_sentiment(self, symbol_data):
        """Analyze option writer positioning and changes"""
        latest = symbol_data.iloc[-1]
        
        writer_side = latest['writer_dominant_side']
        call_strength = latest['writer_call_writer_strength_percent']
        put_strength = latest['writer_put_writer_strength_percent']
        pcr = latest['writer_pcr_oi']
        
        # Determine conviction level
        if 'Strong' in writer_side:
            conviction = 'high'
        elif 'Moderate' in writer_side:
            conviction = 'moderate'
        else:
            conviction = 'low'
        
        # Check if writer sentiment is shifting
        if len(symbol_data) >= 2:
            prev_call = symbol_data.iloc[-2]['writer_call_writer_strength_percent']
            prev_put = symbol_data.iloc[-2]['writer_put_writer_strength_percent']
            
            call_shift = call_strength - prev_call
            put_shift = put_strength - prev_put
            
            sentiment_shift = 'bullish' if put_shift > 5 else 'bearish' if call_shift > 5 else 'stable'
        else:
            sentiment_shift = 'unknown'
            call_shift = 0
            put_shift = 0
        
        return {
            'dominant_side': writer_side,
            'conviction': conviction,
            'call_strength': call_strength,
            'put_strength': put_strength,
            'pcr': pcr,
            'sentiment_shift': sentiment_shift,
            'call_shift': call_shift,
            'put_shift': put_shift,
            'max_call_strike': latest['writer_max_call_oi_strike'],
            'max_put_strike': latest['writer_max_put_oi_strike']
        }
    
    def analyze_rollover_quality(self, symbol_data):
        """Analyze rollover behavior"""
        latest = symbol_data.iloc[-1]
        
        rollover_pct = latest['rollover_percent']
        rollover_quality = latest['rollover_quality_index']
        roll_cost = latest['roll_cost_percent_of_spot']
        
        # High quality rollover with good participation
        if rollover_quality >= 7 and rollover_pct > 10:
            quality = 'excellent'
        elif rollover_quality >= 5 and rollover_pct > 5:
            quality = 'good'
        elif rollover_pct < 2:
            quality = 'poor'
        else:
            quality = 'moderate'
        
        # Check for backwardation (negative roll cost = bullish)
        structure = 'backwardation' if roll_cost < -0.5 else 'contango' if roll_cost > 0.5 else 'flat'
        
        return {
            'quality': quality,
            'rollover_percent': rollover_pct,
            'quality_index': rollover_quality,
            'roll_cost': roll_cost,
            'term_structure': structure,
            'immediate_demand': roll_cost < 0
        }
    
    def calculate_conviction_score(self, symbol_data):
        """Calculate overall conviction score (-100 to +100, symmetric for longs and shorts)"""
        latest = symbol_data.iloc[-1]
        
        score = 0  # Start neutral (0 = no bias, +100 = strong long, -100 = strong short)
        signals = []
        
        # 1. OI Momentum Analysis with Adaptive Weighting and Consistency Check
        oi_analysis = self.analyze_oi_momentum(symbol_data)
        
        # Check OI consistency (only penalize erratic patterns when trend is neutral to avoid double-counting)
        if len(symbol_data) >= 3:
            try:
                recent_oi_changes = symbol_data['current_oi_change_percent'].tail(3).values
                
                # Calculate coefficient of variation (use absolute mean for proper CV)
                oi_std = np.std(recent_oi_changes)
                oi_mean_abs = np.abs(np.mean(recent_oi_changes))
                oi_cv = oi_std / (oi_mean_abs + 1e-9)  # Coefficient of variation
                
                # Check for sign consistency (flipping between positive/negative)
                positive_days = sum(1 for x in recent_oi_changes if x > 0)
                negative_days = len(recent_oi_changes) - positive_days
                inconsistency_ratio = min(positive_days, negative_days) / len(recent_oi_changes)
                
                # Only penalize erratic patterns if trend is NEUTRAL (avoid double-counting with consistency bonus)
                if oi_cv > 1.5 or inconsistency_ratio > 0.4:
                    if oi_analysis['trend'] == 'neutral':
                        # Erratic + no direction = bad (no institutional conviction)
                        erratic_penalty = min(12, max(6, (oi_cv + inconsistency_ratio) * 5))
                        score -= erratic_penalty
                        signals.append(f"✗ Erratic OI with no direction: {recent_oi_changes[0]:.1f}% → {recent_oi_changes[1]:.1f}% → {recent_oi_changes[2]:.1f}% (CV: {oi_cv:.2f}, no conviction)")
                    else:
                        # Volatile but has direction = just note it, don't double-penalize
                        signals.append(f"~ Volatile OI pattern but {oi_analysis['trend']} trend intact (CV: {oi_cv:.2f})")
            except (KeyError, TypeError, IndexError) as e:
                # Data structure issue - skip erratic check
                pass
        
        # Dynamic weight based on signal strength (strength is already |z|)
        oi_weight = min(15, max(5, abs(oi_analysis['strength']) * 5))
        oi_consistency_bonus = (oi_analysis['consistency'] - 50) / 50 * 3  # -3 to +3
        
        if oi_analysis['trend'] == 'buildup':
            if oi_analysis['momentum_fade'] > 10:
                score -= oi_weight  # Symmetric penalty
                signals.append(f"✗ OI momentum fading significantly (fade: {oi_analysis['momentum_fade']:.1f}%)")
            else:
                score += oi_weight + oi_consistency_bonus
                signals.append(f"✓ OI buildup (strength: {oi_analysis['strength']:.2f}, consistency: {oi_analysis['consistency']:.0f}%)")
        elif oi_analysis['trend'] == 'decline':
            score -= (oi_weight + oi_consistency_bonus)  # Symmetric penalty for bearish
            signals.append(f"✗ OI declining - position unwinding (strength: {oi_analysis['strength']:.2f})")
        else:
            # Neutral trend - no adjustment (truly neutral)
            signals.append(f"~ Neutral OI trend (strength: {oi_analysis['strength']:.2f})")
        
        # 2. Price Momentum with Adaptive Weighting and Gap Detection
        price_analysis = self.analyze_price_momentum(symbol_data)
        
        # Detect gap-ups/gap-downs without OI support (using futures price)
        gap_detected = False
        if len(symbol_data) >= 2:
            try:
                prev_fut_price = symbol_data.iloc[-2]['current_fut_price']
                curr_fut_price = latest['current_fut_price']
                price_jump = ((curr_fut_price - prev_fut_price) / prev_fut_price) * 100
                
                # Use todays_net_oi_percent_change for same-day OI change
                latest_oi_change = latest.get('todays_net_oi_percent_change', latest.get('current_oi_change_percent', 0))
                
                # Gap-up without OI support (bearish)
                if abs(price_jump) > 2.5:
                    if price_jump > 0 and latest_oi_change < price_jump * 0.5:
                        gap_penalty = min(15, max(8, price_jump * 3))
                        score -= gap_penalty
                        signals.append(f"✗✗ Gap-up exhaustion: Futures +{price_jump:.1f}% but OI only +{latest_oi_change:.1f}% (unsupported move)")
                        gap_detected = True
                    elif price_jump < 0 and latest_oi_change < abs(price_jump) * 0.5:
                        gap_penalty = min(12, max(6, abs(price_jump) * 2.5))
                        score -= gap_penalty
                        signals.append(f"✗ Gap-down without support: Futures {price_jump:.1f}% but OI only +{latest_oi_change:.1f}%")
                        gap_detected = True
            except (KeyError, TypeError) as e:
                pass
        
        # Alternative: Use embedded price change data for single snapshot OR when multi-snapshot gap detection fails
        if not gap_detected:
            try:
                # Use current_price_change_percent (which shows recent price move)
                price_change_pct = latest.get('current_price_change_percent', 0)
                oi_change_pct = latest.get('todays_net_oi_percent_change', latest.get('current_oi_change_percent', 0))
                
                # Large price move without proportional OI support
                if abs(price_change_pct) > 3 and abs(oi_change_pct) < abs(price_change_pct) * 0.6:
                    gap_penalty = min(15, max(8, abs(price_change_pct) * 3))
                    score -= gap_penalty
                    if price_change_pct > 0:
                        signals.append(f"✗✗ Unsupported rally: Price +{price_change_pct:.1f}% but OI only +{oi_change_pct:.1f}% (weak conviction)")
                    else:
                        signals.append(f"✗ Unsupported decline: Price {price_change_pct:.1f}% but OI only {oi_change_pct:.1f}%")
            except (KeyError, TypeError) as e:
                pass
        
        # Dynamic weight based on signal strength
        price_weight = min(15, max(5, abs(price_analysis['strength']) * 5))
        price_sustainability_bonus = (price_analysis['sustainability'] - 50) / 50 * 3  # -3 to +3
        
        if price_analysis['trend'] == 'bullish':
            score += price_weight + price_sustainability_bonus
            signals.append(f"✓ Bullish price momentum (strength: {price_analysis['strength']:.2f}, sustainability: {price_analysis['sustainability']:.0f}%)")
        elif price_analysis['trend'] == 'bearish':
            score -= (price_weight + price_sustainability_bonus)  # Symmetric penalty for shorts
            signals.append(f"✓ Bearish price momentum (strength: {price_analysis['strength']:.2f}, sustainability: {price_analysis['sustainability']:.0f}%) [SHORT SIGNAL]")
        else:
            # Neutral trend - no adjustment (truly neutral)
            signals.append(f"~ Neutral price trend (strength: {price_analysis['strength']:.2f})")
        
        # 3. Price-OI Divergence with Adaptive Weighting (Hierarchical Logic)
        divergence = self.analyze_price_oi_divergence(symbol_data)
        
        # Dynamic weight based on divergence severity and correlation strength
        divergence_weight = min(20, max(5, divergence['severity'] * 2))
        
        # PRIORITY 1: TRAP signals (most critical)
        if divergence['signal'] == 'TRAP':
            trap_penalty = min(25, divergence['severity'])
            score -= trap_penalty
            signals.append(f"🚨🚨 {divergence.get('alignment_type', 'TRAP DETECTED')} - severity: {divergence['severity']:.1f}")
            signals.append("⚠️ CRITICAL: Unsustainable move - high reversal risk")
        
        # PRIORITY 2: Divergence signals (warnings/opportunities)
        elif divergence['signal'] == 'WARNING':
            score -= divergence_weight
            signals.append(f"✗✗ DANGER: Strong bearish divergence (severity: {divergence['severity']:.1f}, corr: {divergence.get('correlation_5d', 0):.2f})")
        elif divergence['signal'] == 'OPPORTUNITY':
            score += divergence_weight * 0.8  # Slightly conservative on bullish divergence
            signals.append(f"✓✓ OPPORTUNITY: Strong bullish divergence (severity: {divergence['severity']:.1f}, corr: {divergence.get('correlation_5d', 0):.2f})")
        elif divergence['signal'] == 'CAUTION':
            score -= divergence_weight * 0.5
            signals.append(f"✗ Caution: Moderate bearish divergence (severity: {divergence['severity']:.1f})")
        elif divergence['signal'] == 'WATCH':
            score += divergence_weight * 0.4  # Conservative on moderate bullish divergence
            signals.append(f"~ Watch: Moderate bullish divergence (severity: {divergence['severity']:.1f})")
        elif divergence['signal'] == 'TRENDING':
            score += 10
            signals.append(f"✓✓ STRONG ALIGNMENT: Price-OI trending together (corr: {divergence.get('correlation_5d', 0):.2f})")
        elif divergence['signal'] == 'ALIGNED':
            score += 5
            signals.append(f"✓ Moderate alignment: Price-OI moving together (corr: {divergence.get('correlation_5d', 0):.2f})")
        elif divergence['signal'] == 'DIVERGENCE':
            # Already handled above in specific divergence cases
            pass
        elif divergence['signal'] == 'CHOPPY':
            # No bonus or penalty for weak/no relationship
            signals.append(f"~ Weak relationship: Price-OI choppy (corr: {divergence.get('correlation_5d', 0):.2f}) - no conviction")
        
        # 4. Context-Aware Writer Sentiment Analysis
        writer = self.analyze_writer_sentiment(symbol_data)
        latest = symbol_data.iloc[-1]
        spot_price = latest['spot_price']
        
        # Distance-based market structure analysis
        call_strike = writer['max_call_strike']
        put_strike = writer['max_put_strike']
        
        distance_to_calls = ((call_strike - spot_price) / spot_price) * 100
        distance_to_puts = ((spot_price - put_strike) / spot_price) * 100
        
        # Context-aware conflict resolution
        context_result = self._analyze_writer_price_context(
            writer, spot_price, distance_to_calls, distance_to_puts, 
            price_analysis['trend'], oi_analysis['trend']
        )
        
        score += context_result['score_adjustment']
        signals.extend(context_result['signals'])
        
        # 5. Rollover Quality with Time-Aware Analysis (Prevents Timing Bias)
        rollover = self.analyze_rollover_quality(symbol_data)
        rollover_result = self._analyze_rollover_timing(rollover, latest['timestamp'])
        score += rollover_result['score_adjustment']
        signals.extend(rollover_result['signals'])
        
        # 6. Protection & Risk with Adaptive Weighting
        low_protection_pct = latest['current_fut_latest_close_vs_series_low_pct']
        
        # Dynamic weight based on protection level
        protection_weight = min(12, max(3, low_protection_pct * 0.5))
        
        if low_protection_pct > 20:
            score += protection_weight + 3  # Bonus for excellent protection
            signals.append(f"✓ Excellent downside protection ({low_protection_pct:.1f}%)")
        elif low_protection_pct > 15:
            score += protection_weight
            signals.append(f"✓ Good downside protection ({low_protection_pct:.1f}%)")
        elif low_protection_pct < 3:
            score -= protection_weight
            signals.append(f"✗ Very near series low - high risk ({low_protection_pct:.1f}%)")
        elif low_protection_pct < 5:
            score -= protection_weight * 0.7
            signals.append(f"✗ Near series low - limited cushion ({low_protection_pct:.1f}%)")
        else:
            # Moderate protection
            score += 2
            signals.append(f"~ Moderate downside protection ({low_protection_pct:.1f}%)")
        
        # 7. Enhanced Intraday Divergence Detection (Ratio-Based)
        if len(symbol_data) >= 2:
            latest_oi = symbol_data.iloc[-1]['todays_net_oi_percent_change']
            latest_price_change = price_analysis['latest_price_change']
            
            # Dynamic divergence detection based on price-to-OI ratio
            price_magnitude = abs(latest_price_change)
            oi_magnitude = abs(latest_oi)
            
            # Calculate ratio for meaningful moves only
            if price_magnitude > 1.5 and oi_magnitude > 0.3:
                ratio = price_magnitude / (oi_magnitude + 0.1)  # Avoid division by tiny values
                
                # Bearish divergence trap: Price rising faster than OI
                if latest_price_change > 2 and latest_oi > 0 and ratio > 3:
                    # Scale penalty by how extreme the divergence is
                    divergence_excess = ratio - 3  # How much over the 3:1 threshold
                    penalty = min(15, max(6, divergence_excess * 2.5))
                    score -= penalty
                    signals.append(f"⚠️ INTRADAY DIVERGENCE: Price +{latest_price_change:.1f}% vs OI +{latest_oi:.1f}% (ratio: {ratio:.1f}:1)")
                
                # Bearish divergence: Price down while OI stays flat/positive
                elif latest_price_change < -2 and latest_oi >= 0 and ratio > 3:
                    penalty = min(12, max(5, (ratio - 3) * 2))
                    score -= penalty * 0.7  # Less harsh
                    signals.append(f"⚠️ DIVERGENCE: Price {latest_price_change:.1f}% vs OI +{latest_oi:.1f}% (ratio: {ratio:.1f}:1)")
            
            # Extreme cases: Price moving but OI completely flat
            elif price_magnitude > 3 and oi_magnitude < 0.5:
                trap_weight = min(15, max(8, price_magnitude * 3))
                if latest_price_change > 0:
                    score -= trap_weight
                    signals.append(f"✗✗ BEARISH TRAP: Price up {latest_price_change:.1f}% but OI flat ({latest_oi:.1f}%)")
                else:
                    score -= trap_weight * 0.7
                    signals.append(f"✗✗ BULLISH TRAP: Price down {latest_price_change:.1f}% but OI flat ({latest_oi:.1f}%)")
            
            # Healthy alignment: Both moving in same direction with good ratio
            elif (latest_price_change > 2 and latest_oi > 1) or (latest_price_change < -2 and latest_oi < -1):
                # Check ratio is reasonable (not extreme divergence)
                if price_magnitude > 0.5 and oi_magnitude > 0.5:
                    ratio = price_magnitude / oi_magnitude
                    if ratio < 3:  # Healthy alignment if ratio is under 3:1
                        score += 3
                        signals.append(f"✓ Healthy price-OI alignment today (price: {latest_price_change:.1f}%, OI: {latest_oi:.1f}%, ratio: {ratio:.1f}:1)")
                    else:
                        signals.append(f"~ Price-OI moving together but diverging ratio ({ratio:.1f}:1)")
        
        # 8. Context-Aware Short Covering Analysis
        if len(symbol_data) >= 1:
            latest_oi_change = latest['current_oi_change_percent']
            latest_price_change = latest['current_price_change_percent']
            
            # Context-aware short covering analysis with flexible thresholds
            if latest_oi_change < -1.5 and latest_price_change > 1:
                # Get context for better interpretation
                price_magnitude = abs(latest_price_change)
                oi_decline_magnitude = abs(latest_oi_change)
                oi_changes = symbol_data['current_oi_change_percent'].values
                recent_oi_trend = np.mean(oi_changes[-3:]) if len(oi_changes) >= 3 else 0
                
                # Calculate divergence strength (how much price rises relative to OI decline)
                divergence_strength = price_magnitude / (oi_decline_magnitude + 0.5)
                
                # Check if this is a bullish short squeeze or bearish weak rally
                if (price_magnitude > 5 and recent_oi_trend > 2 and divergence_strength > 1.5):
                    # Bullish short squeeze completion: Strong price move + OI was previously building
                    bonus = min(15, max(8, price_magnitude * 2))
                    score += bonus
                    signals.append(f"🚀 Short Squeeze Completion: Price up {latest_price_change:.1f}% with OI contraction (bullish continuation)")
                    signals.append(f"📈 Strong breakout - shorts capitulating")
                elif (divergence_strength < 1.2 or recent_oi_trend < -1):
                    # Bearish weak rally: Modest divergence strength OR OI was declining
                    # Scale penalty by divergence strength
                    penalty = min(15, max(8, (price_magnitude + oi_decline_magnitude) * 1.5))
                    score -= penalty
                    signals.append(f"⚠️ Weak Rally: Price up {latest_price_change:.1f}% but OI down {latest_oi_change:.1f}% (divergence: {divergence_strength:.2f})")
                    if score < 65:
                        signals.append("📉 Downgraded to WATCH - wait for follow-through")
                else:
                    # Neutral case: Wait for confirmation
                    signals.append(f"~ Short covering detected: Price up {latest_price_change:.1f}%, OI down {latest_oi_change:.1f}%")
                    signals.append("📊 Wait for follow-through to confirm direction")
            
            # Detect bearish divergence: Falling price with rising OI (position building)
            elif latest_oi_change > 3 and latest_price_change < 0:
                # This is actually bullish - OI building while price falling
                bonus = min(8, max(3, (abs(latest_oi_change) + abs(latest_price_change)) * 0.5))
                score += bonus
                signals.append(f"✓ Bearish Divergence (Bullish): Price down {latest_price_change:.1f}% but OI up {latest_oi_change:.1f}% (position building)")
        
        # 9. OI Reversal Confirmation Filter (Entry Timing)
        if len(symbol_data) >= 4:
            oi_changes = symbol_data['current_oi_change_percent'].values
            
            # Multi-day OI trend analysis for reversal confirmation
            prev_oi_trend = np.mean(oi_changes[-3:-1])  # Last 2-3 days average
            curr_oi_trend = np.mean(oi_changes[-2:])    # Recent 2 days average
            
            # OI reversal: from contraction to expansion with meaningful magnitude
            oi_reversal_magnitude = curr_oi_trend - prev_oi_trend
            oi_reversal = (prev_oi_trend < -1 and curr_oi_trend > 1 and 
                          abs(oi_reversal_magnitude) > 2)
            
            # Add price momentum confirmation
            price_momentum_ok = price_analysis['trend'] in ['bullish', 'neutral']
            
            if oi_reversal and price_momentum_ok:
                # Bonus for confirmed OI reversal with institutional interest
                reversal_bonus = min(10, max(5, abs(oi_reversal_magnitude) * 2))
                score += reversal_bonus
                signals.append(f"✓ OI Reversal Confirmed: {prev_oi_trend:.1f}% → {curr_oi_trend:.1f}% (institutional interest resumption)")
                
                # Mark as entry-eligible
                signals.append("🎯 Entry-eligible: OI expansion confirmed")
            elif prev_oi_trend < 0 and curr_oi_trend < 0:
                # Ongoing OI contraction - caution
                signals.append(f"⚠️ OI Contraction Ongoing: {curr_oi_trend:.1f}% (wait for reversal)")
            elif prev_oi_trend > 0 and curr_oi_trend < 0:
                # OI momentum fading - warning
                fade_penalty = min(8, max(3, abs(oi_reversal_magnitude) * 1.5))
                score -= fade_penalty
                signals.append(f"✗ OI Momentum Fading: {prev_oi_trend:.1f}% → {curr_oi_trend:.1f}% (institutional interest waning)")
        
        # 11. IV Analysis for Directional Trades (Strategy Selection & Adjustments)
        iv_directional = self._analyze_iv_for_directional(latest.get('symbol', ''), symbol_data, score)
        score += iv_directional['score_adjustment']
        signals.extend(iv_directional['signals'])
        
        # Apply minimum thresholds for action levels
        
        # PCR-based adjustments (nuanced thresholds)
        writer = self.analyze_writer_sentiment(symbol_data)
        pcr = writer['pcr']
        
        if pcr < 0.4:
            # Extremely bearish PCR (calls outnumber puts >2.5:1)
            if score >= 65:
                score = min(score, 54)  # Cap at WATCH
                signals.append(f"⚠️ Extremely bearish PCR ({pcr:.2f}) - heavy call writing blocks upside")
            else:
                score -= 5
                signals.append(f"✗ Extremely bearish PCR ({pcr:.2f}) - institutional selling pressure")
        elif pcr < 0.55:
            # Moderately bearish PCR
            if score >= 75:
                score = min(score, 64)  # Cap at BUY level
                signals.append(f"⚠️ Moderately bearish PCR ({pcr:.2f}) - downgraded from STRONG BUY")
            else:
                score -= 2
                signals.append(f"~ Moderately bearish PCR ({pcr:.2f}) - call bias")
        elif pcr > 1.2:
            # Bullish PCR (puts outnumber calls)
            bonus = min(5, (pcr - 1.2) * 3)
            score += bonus
            signals.append(f"✓ Bullish PCR ({pcr:.2f}) - put bias supports upside")
        
        # STRONG BUY (75+): Requires bullish OI AND bullish price
        if score >= 75:
            if oi_analysis['trend'] != 'buildup' or price_analysis['trend'] != 'bullish':
                score = min(score, 49)  # Cap at BUY level
                signals.append("⚠️ Downgraded from STRONG BUY: Requires bullish OI + price trends")
        
        # BUY (50-74): Requires at least one bullish trend (OI OR price)
        if 50 <= score < 75:
            if oi_analysis['trend'] not in ['buildup'] and price_analysis['trend'] not in ['bullish']:
                score = min(score, 14)  # Cap at WATCH level
                signals.append("⚠️ Downgraded from BUY: Requires at least one bullish trend (OI or price)")
        
        # Block BUY if trends are bearish
        if score >= 50:
            if oi_analysis['trend'] == 'decline' or price_analysis['trend'] == 'bearish':
                score = min(score, 14)  # Cap at WATCH level
                signals.append("⚠️ Downgraded: Cannot recommend BUY with declining OI or bearish price")
        
        # STRONG SHORT (-75-): Requires bearish OI AND bearish price
        if score <= -75:
            if oi_analysis['trend'] != 'decline' or price_analysis['trend'] != 'bearish':
                score = max(score, -49)  # Cap at SHORT level
                signals.append("⚠️ Upgraded from STRONG SHORT: Requires bearish OI + price trends")
        
        # SHORT (-50 to -74): Requires at least one bearish trend
        if -75 < score <= -50:
            if oi_analysis['trend'] not in ['decline'] and price_analysis['trend'] not in ['bearish']:
                score = max(score, -14)  # Cap at WATCH level
                signals.append("⚠️ Upgraded from SHORT: Requires at least one bearish trend (OI or price)")
        
        # Block SHORT if trends are bullish
        if score <= -50:
            if oi_analysis['trend'] == 'buildup' or price_analysis['trend'] == 'bullish':
                score = max(score, -14)  # Cap at WATCH level
                signals.append("⚠️ Upgraded: Cannot recommend SHORT with building OI or bullish price")
        
        return max(-100, min(100, score)), signals
    
    def calculate_straddle_score(self, symbol_data):
        """Calculate straddle selling opportunity score (0-100) - inverted logic from directional"""
        latest = symbol_data.iloc[-1]
        symbol = latest['symbol']
        
        score = 50  # Start neutral
        signals = []
        blocking_reasons = []  # Track critical blocking factors
        
        # Get all analysis components
        oi_analysis = self.analyze_oi_momentum(symbol_data)
        price_analysis = self.analyze_price_momentum(symbol_data)
        writer = self.analyze_writer_sentiment(symbol_data)
        rollover = self.analyze_rollover_quality(symbol_data)
        
        spot_price = latest['spot_price']
        call_strike = writer['max_call_strike']
        put_strike = writer['max_put_strike']
        pcr = writer['pcr']
        
        # 0. IV Analysis (CRITICAL - Most Important Factor) ±30 points
        iv_result = self._analyze_iv_for_straddle(symbol, symbol_data)
        score += iv_result['score_adjustment']
        signals.extend(iv_result['signals'])
        
        # ✅ FIX: Add hard block for unsuitable IV
        if not iv_result.get('suitable', True):
            blocking_reasons.append("IV unsuitable for selling")
            signals.append("🚫 HARD BLOCK: IV too low/spiking - DO NOT TRADE")
        
        # ✅ FIX: Add hard block for event risk
        if iv_result.get('event_risk', False):
            blocking_reasons.append("Event risk detected")
            signals.append("🚫 HARD BLOCK: Upcoming event - DO NOT TRADE")
        
        # 1. Neutral Trends (GOOD for straddles) ±20 points
        if oi_analysis['trend'] == 'neutral' and price_analysis['trend'] == 'neutral':
            score += 20
            signals.append(f"✓✓ NEUTRAL OI+PRICE: No directional bias (OI: {oi_analysis['strength']:.2f}, Price: {price_analysis['strength']:.2f})")
        elif oi_analysis['trend'] == 'neutral' or price_analysis['trend'] == 'neutral':
            score += 8
            signals.append(f"✓ Partial neutrality (one trend neutral)")
        else:
            score -= 15
            signals.append(f"✗ Directional bias detected - unsuitable for straddle")
        
        # 2. Balanced PCR (near 1.0) ±15 points
        pcr_distance = abs(pcr - 1.0)
        if pcr_distance < 0.15:
            score += 15
            signals.append(f"✓✓✓ BALANCED PCR: {pcr:.2f} (neutral positioning)")
        elif pcr_distance < 0.3:
            score += 8
            signals.append(f"✓ Decent PCR balance: {pcr:.2f}")
        else:
            penalty = min(12, pcr_distance * 20)
            score -= penalty
            signals.append(f"✗ Imbalanced PCR: {pcr:.2f} (directional bias)")
        
        # 3. Strong Range Definition (call + put writer strength) ±15 points
        call_strength = writer['call_strength']
        put_strength = writer['put_strength']
        avg_writer_strength = (call_strength + put_strength) / 2
        
        if avg_writer_strength > 60 and abs(call_strength - put_strength) < 15:
            score += 15
            signals.append(f"✓✓ STRONG RANGE: Call {call_strength:.0f}% | Put {put_strength:.0f}% (tight boundaries)")
        elif avg_writer_strength > 50:
            score += 8
            signals.append(f"✓ Decent range: Call {call_strength:.0f}% | Put {put_strength:.0f}%")
        else:
            score -= 10
            signals.append(f"✗ Weak range definition (avg strength: {avg_writer_strength:.0f}%)")
        
        # 4. Range Width (optimal 5-12%) ±10 points
        range_width = ((call_strike - put_strike) / spot_price) * 100
        if 5 <= range_width <= 12:
            score += 10
            signals.append(f"✓✓ OPTIMAL RANGE: {range_width:.1f}% wide (Put {put_strike} - Call {call_strike})")
        elif range_width < 5:
            score -= 8
            signals.append(f"✗ Too narrow range: {range_width:.1f}% (high risk)")
        else:
            score -= 5
            signals.append(f"~ Wide range: {range_width:.1f}% (lower premium)")
        
        # 5. Spot Centering (±10 points)
        distance_to_calls = ((call_strike - spot_price) / spot_price) * 100
        distance_to_puts = ((spot_price - put_strike) / spot_price) * 100
        centering_diff = abs(distance_to_calls - distance_to_puts)
        
        if centering_diff < 2:
            score += 10
            signals.append(f"✓✓ CENTERED SPOT: {distance_to_calls:.1f}% to calls | {distance_to_puts:.1f}% to puts")
        elif centering_diff < 4:
            score += 5
            signals.append(f"✓ Reasonably centered: {distance_to_calls:.1f}% to calls | {distance_to_puts:.1f}% to puts")
        else:
            score -= 5
            signals.append(f"✗ Off-center: {distance_to_calls:.1f}% to calls | {distance_to_puts:.1f}% to puts")
        
        # 6. Low Recent Volatility (±10 points)
        if len(symbol_data) >= 5:
            recent_price_changes = symbol_data['current_price_change_percent'].tail(5).values
            volatility = np.std(recent_price_changes)
            
            if volatility < 1.0:
                score += 10
                signals.append(f"✓✓ LOW VOLATILITY: {volatility:.2f}% (stable range)")
            elif volatility < 2.0:
                score += 5
                signals.append(f"✓ Moderate volatility: {volatility:.2f}%")
            else:
                score -= 10
                signals.append(f"✗ High volatility: {volatility:.2f}% (risky for straddle)")
        
        # 7. Low Rollover (no catalyst) ±8 points
        if rollover['rollover_percent'] < 20 and rollover['quality_index'] < 5:
            score += 8
            signals.append(f"✓ LOW ROLLOVER: {rollover['rollover_percent']:.1f}% (no major catalyst)")
        elif rollover['rollover_percent'] > 35:
            score -= 8
            signals.append(f"✗ HIGH ROLLOVER: {rollover['rollover_percent']:.1f}% (institutions positioning)")
        
        # 8. Days to Expiry (optimal 10-20 days) ±8 points
        days_to_expiry = self._estimate_days_to_expiry(latest['timestamp'].date())
        if 10 <= days_to_expiry <= 20:
            score += 8
            signals.append(f"✓✓ OPTIMAL THETA: {days_to_expiry} days to expiry (max decay zone)")
        elif 7 <= days_to_expiry <= 25:
            score += 4
            signals.append(f"✓ Good theta decay: {days_to_expiry} days to expiry")
        elif days_to_expiry < 7:
            score -= 10
            signals.append(f"✗ Too close to expiry: {days_to_expiry} days (gamma risk)")
        else:
            score -= 5
            signals.append(f"~ Far from expiry: {days_to_expiry} days (slow decay)")
        
        # 9. Price Position (mid-range preferred) ±5 points
        protection_pct = latest['current_fut_latest_close_vs_series_low_pct']
        if 30 <= protection_pct <= 70:
            score += 5
            signals.append(f"✓ MID-RANGE POSITION: {protection_pct:.0f}% from low (safe zone)")
        elif protection_pct < 20 or protection_pct > 80:
            score -= 5
            signals.append(f"✗ Extreme position: {protection_pct:.0f}% from low (directional risk)")
        
        # 10. Weak Price-OI Correlation (±5 points)
        divergence = self.analyze_price_oi_divergence(symbol_data)
        avg_corr = (divergence.get('correlation_3d', 0) * 0.5 + 
                   divergence.get('correlation_5d', 0) * 0.3 + 
                   divergence.get('correlation_7d', 0) * 0.2)
        
        if abs(avg_corr) < 0.3:
            score += 5
            signals.append(f"✓ WEAK CORRELATION: {avg_corr:.2f} (no strong trend)")
        elif abs(avg_corr) > 0.7:
            score -= 8
            signals.append(f"✗ STRONG CORRELATION: {avg_corr:.2f} (trend building)")
        
        # 11. Stable Recent Price (±5 points)
        latest_price_change = latest['current_price_change_percent']
        if abs(latest_price_change) < 1.5:
            score += 5
            signals.append(f"✓ STABLE PRICE: {latest_price_change:.1f}% move (low volatility)")
        elif abs(latest_price_change) > 4:
            score -= 8
            signals.append(f"✗ VOLATILE PRICE: {latest_price_change:.1f}% move (unsuitable)")
        
        # ✅ FIX: Enforce hard blocks BEFORE returning
        if blocking_reasons:
            return 0, signals + [f"❌ TRADE BLOCKED: {', '.join(blocking_reasons)}"]
        
        return max(0, min(100, score)), signals
    
    def _analyze_iv_for_straddle(self, symbol, symbol_data):
        """Analyze IV suitability for straddle selling using actual IV data"""
        result = {'score_adjustment': 0, 'signals': [], 'suitable': False, 'atm_iv': 0, 'iv_percentile': 0, 'event_risk': False}
        
        # Check if we have IV data for this symbol
        if symbol not in self.iv_lookup:
            # No IV data - use neutral scoring
            result['signals'].append("~ No IV data available - using neutral assessment")
            result['suitable'] = True  # Don't block if data unavailable
            return result
        
        iv_info = self.iv_lookup[symbol]
        atm_iv = iv_info['atm_iv']
        iv_percentile = iv_info['iv_percentile']
        iv_change = iv_info['iv_change']
        event = iv_info.get('event', '-')
        
        result['atm_iv'] = atm_iv
        result['iv_percentile'] = iv_percentile
        
        # Calculate IV/HV ratio (realized volatility)
        if len(symbol_data) >= 20:
            returns = symbol_data['current_price_change_percent'].tail(20).values
            hv_20d = np.std(returns) * np.sqrt(252)  # Annualized
            iv_hv_ratio = atm_iv / (hv_20d + 1e-9)
        else:
            iv_hv_ratio = 1.0
        
        # 1. Combined IV Analysis (Percentile + Direction + HV Context)
        # Check IV direction first to detect spikes
        iv_is_spiking = iv_change > 2.0
        iv_is_stable = abs(iv_change) <= 2.0
        iv_is_falling = iv_change < -2.0
        
        # High IV percentile scoring depends on IV direction
        if iv_percentile >= 70:
            if iv_is_spiking:
                # High IV + rising = IV spike (DANGEROUS for straddles)
                result['score_adjustment'] -= 20
                result['signals'].append(f"✗✗ IV SPIKE: {atm_iv:.1f}% (rank: {iv_percentile}th) rising +{iv_change:.1f}% - GAMMA RISK")
                result['signals'].append("🚫 Avoid straddle: IV likely to spike higher (event/momentum building)")
                result['suitable'] = False
            elif iv_is_stable or iv_is_falling:
                # High IV + stable/falling = ideal for selling (mean reversion)
                result['score_adjustment'] += 25
                result['signals'].append(f"✓✓✓ EXCELLENT IV: {atm_iv:.1f}% (rank: {iv_percentile}th) stable/falling (IV peak)")
                result['suitable'] = True
            else:
                # High IV + slight rise = caution
                result['score_adjustment'] += 10
                result['signals'].append(f"✓ Good IV: {atm_iv:.1f}% (rank: {iv_percentile}th) but rising {iv_change:.1f}%")
                result['suitable'] = True
        
        elif iv_percentile >= 50:
            if iv_is_spiking:
                # Moderate IV spiking = wait for peak
                result['score_adjustment'] -= 10
                result['signals'].append(f"⚠️ IV rising: {atm_iv:.1f}% (rank: {iv_percentile}th) +{iv_change:.1f}% - wait for peak")
                result['suitable'] = False
            else:
                # Moderate IV stable = acceptable
                result['score_adjustment'] += 12
                result['signals'].append(f"✓ Good IV: {atm_iv:.1f}% (rank: {iv_percentile}th percentile)")
                result['suitable'] = True
        
        elif iv_percentile >= 30:
            result['score_adjustment'] -= 5
            result['signals'].append(f"~ Mediocre IV: {atm_iv:.1f}% (rank: {iv_percentile}th percentile)")
            result['suitable'] = False
        
        else:
            # Low IV - unsuitable regardless of direction
            result['score_adjustment'] -= 25
            result['signals'].append(f"✗✗ LOW IV: {atm_iv:.1f}% (rank: {iv_percentile}th percentile) - UNSUITABLE")
            result['suitable'] = False
        
        # 2. IV/HV Ratio (Validates if IV is overpriced vs realized vol)
        if iv_hv_ratio > 1.3:
            # IV significantly higher than HV = overpriced (good for selling)
            result['score_adjustment'] += 12
            result['signals'].append(f"✓✓ IV/HV ratio: {iv_hv_ratio:.2f} (options overpriced vs realized vol)")
        elif iv_hv_ratio > 1.1:
            result['score_adjustment'] += 6
            result['signals'].append(f"✓ IV/HV ratio: {iv_hv_ratio:.2f} (fair premium)")
        elif iv_hv_ratio < 0.9:
            # IV lower than HV = underpriced or HV spiking (bad for selling)
            result['score_adjustment'] -= 15
            result['signals'].append(f"✗ IV/HV ratio: {iv_hv_ratio:.2f} (options cheap OR realized vol spiking)")
            result['suitable'] = False
        elif iv_hv_ratio < 1.0 and iv_is_spiking:
            # IV rising but still below HV = very dangerous
            result['score_adjustment'] -= 20
            result['signals'].append(f"✗✗ IV catching up to HV: ratio {iv_hv_ratio:.2f}, rising +{iv_change:.1f}% - HIGH RISK")
            result['suitable'] = False
        
        # 4. Event Risk (Block if event upcoming)
        if event != '-' and event != '':
            result['score_adjustment'] -= 20
            result['signals'].append(f"🚫 EVENT RISK: {event} - AVOID STRADDLE")
            result['suitable'] = False
            result['event_risk'] = True  # Flag for hard blocking
        
        return result
    
    def _analyze_iv_for_directional(self, symbol, symbol_data, current_score):
        """Analyze IV for directional trades - strategy selection and adjustments"""
        result = {'score_adjustment': 0, 'signals': [], 'strategy_preference': 'futures'}
        
        # Check if we have IV data for this symbol
        if symbol not in self.iv_lookup:
            return result
        
        iv_info = self.iv_lookup[symbol]
        atm_iv = iv_info['atm_iv']
        iv_percentile = iv_info['iv_percentile']
        iv_change = iv_info['iv_change']
        event = iv_info.get('event', '-')
        
        # Determine if position is bullish or bearish
        is_bullish = current_score > 15
        is_bearish = current_score < -15
        
        # 1. IV Crush Detection (Post-Event)
        if iv_change < -2:
            # IV falling - option premiums collapsing
            penalty = min(10, abs(iv_change) * 2)
            result['score_adjustment'] -= penalty
            result['signals'].append(f"⚠️ IV Crush: IV falling {iv_change:.1f}% - option premiums collapsing")
            result['strategy_preference'] = 'futures'
            
            if is_bullish:
                result['signals'].append("📊 Strategy: Use futures, not calls (IV crush risk)")
            elif is_bearish:
                result['signals'].append("📊 Strategy: Use short futures, not puts (IV crush risk)")
        
        # 2. IV Spike (Pre-Event or Momentum)
        elif iv_change > 2:
            # IV rising - option premiums expanding
            bonus = min(8, iv_change * 2)
            result['score_adjustment'] += bonus
            result['signals'].append(f"✓ IV Spike: IV rising +{iv_change:.1f}% - option premiums expanding")
            result['strategy_preference'] = 'options'
            
            if is_bullish:
                result['signals'].append("📊 Strategy: Buy calls (IV expansion benefits option buyers)")
            elif is_bearish:
                result['signals'].append("📊 Strategy: Buy puts (IV expansion benefits option buyers)")
        
        # 3. IV Percentile-Based Strategy Selection
        if iv_percentile > 70:
            # High IV - options expensive
            result['signals'].append(f"⚠️ High IV: {atm_iv:.1f}% (rank: {iv_percentile}th percentile) - options expensive")
            result['strategy_preference'] = 'futures'
            
            if is_bullish:
                result['signals'].append("💡 Prefer: Long futures over calls (avoid expensive premium)")
            elif is_bearish:
                result['signals'].append("💡 Prefer: Short futures over puts (avoid expensive premium)")
        
        elif iv_percentile < 30:
            # Low IV - options cheap
            result['score_adjustment'] += 5
            result['signals'].append(f"✓ Low IV: {atm_iv:.1f}% (rank: {iv_percentile}th percentile) - options cheap")
            result['strategy_preference'] = 'options'
            
            if is_bullish:
                result['signals'].append("💡 Opportunity: Buy calls (cheap leverage)")
            elif is_bearish:
                result['signals'].append("💡 Opportunity: Buy puts (cheap leverage)")
        
        # 4. Event Risk Warning
        if event != '-' and event != '':
            # Upcoming event - high risk
            penalty = 15
            result['score_adjustment'] -= penalty
            result['signals'].append(f"🚫 EVENT RISK: {event} - High uncertainty")
            result['signals'].append("⚠️ Consider waiting for post-event clarity or reduce position size")
        
        return result
    
    def _analyze_writer_price_context(self, writer, spot_price, distance_to_calls, distance_to_puts, 
                                    price_trend, oi_trend):
        """Context-aware writer sentiment analysis with distance-based scoring"""
        result = {'score_adjustment': 0, 'signals': []}
        
        call_strength = writer['call_strength']
        put_strength = writer['put_strength']
        pcr = writer['pcr']
        
        # 1. CEILING EXHAUSTION: Call resistance near price with bullish trend
        if (distance_to_calls < 3 and price_trend == 'bullish' and 
            'Strong Call Writer' in writer['dominant_side']):
            
            if oi_trend == 'decline':
                # Double bearish: price at resistance + OI declining
                penalty = min(18, max(12, call_strength * 0.3))
                result['score_adjustment'] -= penalty
                result['signals'].append(f"✗✗ CEILING EXHAUSTION: Price at {distance_to_calls:.1f}% from strong call wall ({call_strength:.0f}%) + OI declining")
                result['signals'].append(f"📉 Take profit zone - upside limited to ~{distance_to_calls:.1f}%")
            else:
                # Moderate penalty for resistance without OI decline
                penalty = min(12, max(6, call_strength * 0.2))
                result['score_adjustment'] -= penalty
                result['signals'].append(f"⚠️ NEAR RESISTANCE: Strong call OI at {distance_to_calls:.1f}% from spot - upside limited")
        
        # 2. SUPPORT BOUNCE: Put support near price with bearish trend
        elif (distance_to_puts < 3 and price_trend == 'bearish' and 
              'Put Writer Support' in writer['dominant_side']):
            
            if oi_trend == 'buildup':
                # Bullish reversal setup: price at support + OI building
                bonus = min(15, max(8, put_strength * 0.25))
                result['score_adjustment'] += bonus
                result['signals'].append(f"✓✓ STRONG ALIGNMENT: Bearish price with put support at {distance_to_puts:.1f}% + OI buildup")
                result['signals'].append(f"🎯 Bullish reversal setup - support bounce likely")
            else:
                # Moderate bonus for support without OI buildup
                bonus = min(8, max(4, put_strength * 0.15))
                result['score_adjustment'] += bonus
                result['signals'].append(f"✓ Put support at {distance_to_puts:.1f}% - potential bounce zone")
        
        # 3. HEALTHY STRUCTURE: Call resistance far above with bullish trend
        elif (distance_to_calls > 8 and price_trend == 'bullish' and 
              'Strong Call Writer' in writer['dominant_side']):
            
            if oi_trend == 'buildup':
                # Excellent setup: bullish trend with room to run + OI support
                bonus = min(12, max(6, call_strength * 0.15))
                result['score_adjustment'] += bonus
                result['signals'].append(f"✓✓ HEALTHY STRUCTURE: Bullish trend with {distance_to_calls:.1f}% room to call resistance + OI buildup")
                result['signals'].append(f"🚀 Clear path to {call_strength:.0f}% call wall")
            else:
                # Good structure but monitor OI
                result['score_adjustment'] += 3
                result['signals'].append(f"✓ Healthy structure: {distance_to_calls:.1f}% room to resistance (monitor OI)")
        
        # 4. TESTING ZONE: Moderate distance with mixed signals
        elif (3 <= distance_to_calls <= 8 and price_trend == 'bullish'):
            
            if oi_trend == 'buildup':
                result['score_adjustment'] += 4
                result['signals'].append(f"⚠️ TESTING ZONE: Approaching call resistance at {distance_to_calls:.1f}% - watch closely")
            else:
                result['score_adjustment'] -= 2
                result['signals'].append(f"⚠️ TESTING ZONE: Near resistance at {distance_to_calls:.1f}% without OI support")
        
        # 5. BREAKOUT POTENTIAL: Strong momentum breaking through resistance
        elif (distance_to_calls < 2 and price_trend == 'bullish' and oi_trend == 'buildup'):
            bonus = min(10, max(5, call_strength * 0.2))
            result['score_adjustment'] += bonus
            result['signals'].append(f"🚀 BREAKOUT POTENTIAL: Breaking through call resistance with OI support")
            result['signals'].append(f"📈 Watch for continuation above {writer['max_call_strike']}")
        
        # 6. DEFAULT: Standard writer sentiment scoring with neutral trend handling
        else:
            # Fallback to original logic for moderate cases
            writer_weight = 15 if writer['conviction'] == 'high' else 10 if writer['conviction'] == 'moderate' else 5
            pcr_strength = abs(pcr - 1.0)
            
            if 'Put Writer Support' in writer['dominant_side'] and price_trend != 'bearish':
                result['score_adjustment'] += writer_weight + min(5, pcr_strength * 2)
                result['signals'].append(f"✓ Put writer support (PCR: {pcr:.2f}, strength: {pcr_strength:.2f})")
            elif 'Strong Call Writer' in writer['dominant_side']:
                if price_trend == 'neutral':
                    # Neutral trend + call resistance = bearish setup
                    penalty = min(12, max(6, call_strength * 0.2))
                    result['score_adjustment'] -= penalty
                    result['signals'].append(f"✗ Bearish setup: Strong call resistance ({call_strength:.0f}%) without bullish momentum (PCR: {pcr:.2f})")
                else:
                    # Not bullish (likely bearish) - small bonus for confirmation
                    result['score_adjustment'] += writer_weight * 0.3
                    result['signals'].append(f"~ Call writer resistance aligns with bearish trend (PCR: {pcr:.2f})")
            else:
                if writer['conviction'] == 'high':
                    result['score_adjustment'] += 3
                    result['signals'].append(f"~ Moderate writer sentiment (PCR: {pcr:.2f})")
        
        return result
    
    def _analyze_rollover_timing(self, rollover, timestamp):
        """Time-aware rollover analysis to prevent calendar timing bias"""
        result = {'score_adjustment': 0, 'signals': []}
        
        # Estimate days to expiry (NSE F&O typically expires on last Thursday of month)
        current_date = timestamp.date()
        days_to_expiry = self._estimate_days_to_expiry(current_date)
        
        # Adjust thresholds based on timing (corrected logic)
        if days_to_expiry > 10:
            # Early month: HIGH quality required (selective positioning), LOW participation expected
            quality_thresh_high = 7.0  # If rolling early, quality must be excellent
            quality_thresh_low = 3.0   # Poor quality is very bearish
            participation_thresh = 5   # Low participation is normal (it's early)
            timing_context = "early month"
        elif days_to_expiry > 5:
            # Mid month: Moderate quality, moderate participation
            quality_thresh_high = 5.0
            quality_thresh_low = 2.5
            participation_thresh = 20
            timing_context = "mid month"
        else:
            # Near expiry: Lower quality acceptable, HIGH participation required
            quality_thresh_high = 4.0
            quality_thresh_low = 2.0
            participation_thresh = 40  # Must see strong participation
            timing_context = "near expiry"
        
        # Apply corrected time-adjusted analysis
        quality = rollover['quality_index']
        participation = rollover['rollover_percent']
        
        # Early month: Reward high quality, penalize low quality
        if days_to_expiry > 10:
            if quality >= quality_thresh_high:
                # Excellent early rollover = selective institutional positioning (bullish)
                bonus = min(12, (quality - quality_thresh_high) * 2)
                result['score_adjustment'] += bonus
                result['signals'].append(f"✓✓ SELECTIVE POSITIONING: Quality {quality:.1f} ({timing_context}) - strong institutional conviction")
            elif quality < quality_thresh_low:
                # Poor early rollover = weak hands (bearish)
                penalty = min(15, (quality_thresh_low - quality) * 3)
                result['score_adjustment'] -= penalty
                result['signals'].append(f"✗ Poor early rollover: Quality {quality:.1f} ({timing_context}) - weak institutional interest")
            else:
                # Moderate quality early = neutral
                result['signals'].append(f"~ Moderate rollover quality: {quality:.1f} ({timing_context})")
        
        # Mid/Late month: Focus on participation
        else:
            if quality >= quality_thresh_high and participation >= participation_thresh:
                # Strong quality + participation = healthy carry-forward
                bonus = min(15, quality * 1.5)
                result['score_adjustment'] += bonus
                result['signals'].append(f"✓✓ Strong rollover: Quality {quality:.1f}, Participation {participation:.1f}% ({timing_context})")
            elif participation < participation_thresh:
                # Low participation near expiry = no institutional interest (bearish)
                penalty = min(15, (participation_thresh - participation) * 0.5)
                result['score_adjustment'] -= penalty
                result['signals'].append(f"✗ Weak participation: {participation:.1f}% ({timing_context}) - no institutional carry-forward")
            else:
                # Moderate rollover
                result['signals'].append(f"~ Moderate rollover: Quality {quality:.1f}, Participation {participation:.1f}% ({timing_context})")
        
        return result
    
    def _estimate_days_to_expiry(self, current_date):
        """Estimate days to F&O expiry (last Thursday of month)"""
        import calendar
        
        # Get last Thursday of current month
        year = current_date.year
        month = current_date.month
        
        # Get last day of month
        last_day = calendar.monthrange(year, month)[1]
        
        # Find last Thursday
        for day in range(last_day, 0, -1):
            if calendar.weekday(year, month, day) == 3:  # Thursday = 3
                last_thursday = day
                break
        
        expiry_date = current_date.replace(day=last_thursday)
        
        # If we're past this month's expiry, get next month's
        if current_date > expiry_date:
            if month == 12:
                next_month = 1
                next_year = year + 1
            else:
                next_month = month + 1
                next_year = year
            
            # Get last Thursday of next month
            next_last_day = calendar.monthrange(next_year, next_month)[1]
            for day in range(next_last_day, 0, -1):
                if calendar.weekday(next_year, next_month, day) == 3:
                    expiry_date = current_date.replace(year=next_year, month=next_month, day=day)
                    break
        
        return (expiry_date - current_date).days
    
    def generate_trading_recommendation(self, symbol, score, signals, symbol_data):
        """Generate specific trading recommendation"""
        latest = symbol_data.iloc[-1]
        
        # Get all analysis components
        oi_analysis = self.analyze_oi_momentum(symbol_data)
        price_analysis = self.analyze_price_momentum(symbol_data)
        writer = self.analyze_writer_sentiment(symbol_data)
        divergence = self.analyze_price_oi_divergence(symbol_data)
        rollover = self.analyze_rollover_quality(symbol_data)
        
        recommendation = {
            'symbol': symbol,
            'conviction_score': score,
            'timestamp': latest['timestamp'],
            'spot_price': latest['spot_price'],
            'fut_price': latest['current_fut_price']
        }
        
        # Determine trade direction and type (symmetric for longs and shorts)
        if score >= 75:
            recommendation['action'] = 'STRONG BUY'
            recommendation['confidence'] = 'HIGH'
            recommendation['strategy'] = 'Long Futures or Buy Calls'
            recommendation['direction'] = 'LONG'
        elif score >= 50:
            recommendation['action'] = 'BUY'
            recommendation['confidence'] = 'MODERATE-HIGH'
            recommendation['strategy'] = 'Long Futures or Bull Call Spread'
            recommendation['direction'] = 'LONG'
        elif score >= 15:
            recommendation['action'] = 'WATCH'
            recommendation['confidence'] = 'MODERATE'
            recommendation['strategy'] = 'Wait for confirmation or small position'
            recommendation['direction'] = 'NEUTRAL'
        elif score >= -15:
            recommendation['action'] = 'NEUTRAL'
            recommendation['confidence'] = 'LOW'
            recommendation['strategy'] = 'No clear bias - stay on sidelines'
            recommendation['direction'] = 'NEUTRAL'
        elif score >= -50:
            recommendation['action'] = 'SHORT'
            recommendation['confidence'] = 'MODERATE-HIGH'
            recommendation['strategy'] = 'Short Futures or Buy Puts'
            recommendation['direction'] = 'SHORT'
        else:
            recommendation['action'] = 'STRONG SHORT'
            recommendation['confidence'] = 'HIGH'
            recommendation['strategy'] = 'Short Futures or Bear Put Spread'
            recommendation['direction'] = 'SHORT'
        
        # Key levels
        recommendation['max_call_strike'] = writer['max_call_strike']
        recommendation['max_put_strike'] = writer['max_put_strike']
        recommendation['resistance'] = writer['max_call_strike']
        recommendation['support'] = writer['max_put_strike']
        
        # Risk metrics
        recommendation['downside_protection'] = f"{latest['current_fut_latest_close_vs_series_low_pct']:.1f}%"
        recommendation['pcr'] = writer['pcr']
        recommendation['writer_bias'] = writer['dominant_side']
        
        # Key insights
        recommendation['key_signals'] = signals
        recommendation['oi_trend'] = oi_analysis['trend']
        recommendation['price_trend'] = price_analysis['trend']
        recommendation['divergence_warning'] = divergence['signal']
        recommendation['rollover_quality'] = rollover['quality']
        
        # Risk warnings
        warnings = []
        if divergence['signal'] == 'WARNING':
            warnings.append(f"⚠️ CRITICAL: Bearish divergence detected (price-OI ratio: {divergence['severity']:.1f})")
        if oi_analysis['momentum_fade'] > 10:
            warnings.append(f"⚠️ OI momentum fading by {oi_analysis['momentum_fade']:.1f}%")
        if 'Strong Call Writer' in writer['dominant_side'] and price_analysis['trend'] == 'bullish':
            warnings.append(f"⚠️ Price fighting strong call writers at {writer['max_call_strike']}")
        if latest['todays_net_oi_percent_change'] < 0.5 and price_analysis['latest_price_change'] > 3:
            warnings.append("⚠️⚠️ TRAP ALERT: Price up but OI flat - unsustainable")
        
        recommendation['risk_warnings'] = warnings
        
        # Entry/Exit guidelines for LONGS
        if score >= 50:
            recommendation['entry_zone'] = f"{latest['spot_price'] * 0.98:.2f} - {latest['spot_price'] * 1.005:.2f}"
            recommendation['stop_loss'] = writer['max_put_strike']
            recommendation['target_1'] = f"{latest['spot_price'] * 1.03:.2f}"
            recommendation['target_2'] = writer['max_call_strike'] * 0.98
        
        # Entry/Exit guidelines for SHORTS
        elif score <= -50:
            recommendation['entry_zone'] = f"{latest['spot_price'] * 1.02:.2f} - {latest['spot_price'] * 0.995:.2f}"
            recommendation['stop_loss'] = writer['max_call_strike']
            recommendation['target_1'] = f"{latest['spot_price'] * 0.97:.2f}"
            recommendation['target_2'] = writer['max_put_strike'] * 1.02
        
        return recommendation
    
    def generate_straddle_recommendation(self, symbol, straddle_score, signals, symbol_data):
        """Generate straddle selling recommendation"""
        latest = symbol_data.iloc[-1]
        writer = self.analyze_writer_sentiment(symbol_data)
        
        recommendation = {
            'symbol': symbol,
            'straddle_score': straddle_score,
            'timestamp': latest['timestamp'],
            'spot_price': latest['spot_price'],
            'fut_price': latest['current_fut_price'],
            'atm_strike': round(latest['spot_price'] / 50) * 50,  # Nearest 50 strike
            'call_strike': writer['max_call_strike'],
            'put_strike': writer['max_put_strike']
        }
        
        # ✅ FIX: Check for blocking signals
        blocking_signals = [s for s in signals if 'HARD BLOCK' in s or 'TRADE BLOCKED' in s]
        
        if blocking_signals or straddle_score == 0:
            # BLOCKED TRADE
            recommendation['action'] = 'DO NOT TRADE'
            recommendation['confidence'] = 'BLOCKED'
            recommendation['strategy'] = 'Trade blocked due to critical risk factors'
            recommendation['blocking_reasons'] = blocking_signals
            recommendation['range_width'] = f"{((writer['max_call_strike'] - writer['max_put_strike']) / latest['spot_price']) * 100:.1f}%"
            recommendation['call_resistance'] = writer['max_call_strike']
            recommendation['put_support'] = writer['max_put_strike']
            recommendation['pcr'] = writer['pcr']
            recommendation['call_strength'] = f"{writer['call_strength']:.0f}%"
            recommendation['put_strength'] = f"{writer['put_strength']:.0f}%"
            recommendation['days_to_expiry'] = self._estimate_days_to_expiry(latest['timestamp'].date())
            recommendation['key_signals'] = signals
            return recommendation
        
        # Determine straddle action (only if not blocked)
        if straddle_score >= 75:
            recommendation['action'] = 'STRONG SELL STRADDLE'
            recommendation['confidence'] = 'HIGH'
            recommendation['strategy'] = 'Sell ATM Straddle or narrow Iron Condor'
        elif straddle_score >= 65:
            recommendation['action'] = 'SELL STRADDLE'
            recommendation['confidence'] = 'MODERATE-HIGH'
            recommendation['strategy'] = 'Sell ATM Straddle with wider stops'
        elif straddle_score >= 55:
            recommendation['action'] = 'WATCH FOR STRADDLE'
            recommendation['confidence'] = 'MODERATE'
            recommendation['strategy'] = 'Monitor for better entry or use Iron Condor'
        else:
            recommendation['action'] = 'AVOID STRADDLE'
            recommendation['confidence'] = 'LOW'
            recommendation['strategy'] = 'Directional bias too strong - avoid neutral strategy'
        
        # Calculate range
        range_width = ((writer['max_call_strike'] - writer['max_put_strike']) / latest['spot_price']) * 100
        recommendation['range_width'] = f"{range_width:.1f}%"
        recommendation['call_resistance'] = writer['max_call_strike']
        recommendation['put_support'] = writer['max_put_strike']
        
        # PCR and writer strength
        recommendation['pcr'] = writer['pcr']
        recommendation['call_strength'] = f"{writer['call_strength']:.0f}%"
        recommendation['put_strength'] = f"{writer['put_strength']:.0f}%"
        
        # Days to expiry
        recommendation['days_to_expiry'] = self._estimate_days_to_expiry(latest['timestamp'].date())
        
        # Key signals
        recommendation['key_signals'] = signals
        
        return recommendation
    
    def analyze_all_symbols(self, include_straddles=True):
        """Analyze all symbols and rank by conviction"""
        print("\n" + "="*80)
        print("ANALYZING FNO SNAPSHOTS".center(80))
        print("="*80 + "\n")
        
        self.straddle_results = []
        
        for symbol in self.symbols:
            symbol_data = self.data[self.data['symbol'] == symbol].copy()
            
            if len(symbol_data) < 2:
                print(f"⊗ {symbol}: Insufficient data (only {len(symbol_data)} snapshot)")
                continue
            
            # Calculate directional conviction score
            score, signals = self.calculate_conviction_score(symbol_data)
            
            # Generate directional recommendation
            recommendation = self.generate_trading_recommendation(
                symbol, score, signals, symbol_data
            )
            
            self.analysis_results.append(recommendation)
        
            # Calculate straddle opportunity score if enabled
            if include_straddles:
                straddle_score, straddle_signals = self.calculate_straddle_score(symbol_data)
                straddle_rec = self.generate_straddle_recommendation(
                    symbol, straddle_score, straddle_signals, symbol_data
                )
                self.straddle_results.append(straddle_rec)
        
        # Sort directional results by conviction score
        self.analysis_results = sorted(
            self.analysis_results, 
            key=lambda x: x['conviction_score'], 
            reverse=True
        )
        
        # Sort straddle results by straddle score
        if include_straddles:
            self.straddle_results = sorted(
                self.straddle_results,
                key=lambda x: x['straddle_score'],
            reverse=True
        )
        
        return self
    
    def print_top_opportunities(self, top_n=5):
        """Print top N trading opportunities"""
        print("\n" + "="*80)
        print(f"TOP {top_n} TRADING OPPORTUNITIES".center(80))
        print("="*80 + "\n")
        
        for i, rec in enumerate(self.analysis_results[:top_n], 1):
            print(f"\n{'─'*80}")
            print(f"#{i} {rec['symbol']} - Conviction Score: {rec['conviction_score']}/100")
            print(f"{'─'*80}")
            
            print(f"\n📊 Current Price: ₹{rec['spot_price']:.2f} | Futures: ₹{rec['fut_price']:.2f}")
            print(f"🎯 Action: {rec['action']} | Confidence: {rec['confidence']}")
            print(f"📈 Strategy: {rec['strategy']}")
            
            print(f"\n💡 Key Signals:")
            for signal in rec['key_signals']:
                print(f"   {signal}")
            
            if rec['risk_warnings']:
                print(f"\n⚠️  Risk Warnings:")
                for warning in rec['risk_warnings']:
                    print(f"   {warning}")
            
            print(f"\n📍 Key Levels:")
            print(f"   Resistance (Call OI): {rec['resistance']}")
            print(f"   Support (Put OI): {rec['support']}")
            print(f"   Downside Protection: {rec['downside_protection']}")
            
            print(f"\n📊 Market Structure:")
            print(f"   Writer Bias: {rec['writer_bias']}")
            print(f"   PCR: {rec['pcr']:.2f}")
            print(f"   OI Trend: {rec['oi_trend'].upper()}")
            print(f"   Price Trend: {rec['price_trend'].upper()}")
            print(f"   Rollover: {rec['rollover_quality'].upper()}")
            
            if 'entry_zone' in rec:
                print(f"\n🎯 Trade Setup:")
                print(f"   Entry Zone: {rec['entry_zone']}")
                print(f"   Stop Loss: {rec['stop_loss']}")
                print(f"   Target 1: {rec['target_1']}")
                print(f"   Target 2: {rec['target_2']:.2f}")
        
        print(f"\n{'='*80}\n")
    
    def print_avoid_list(self, bottom_n=3):
        """Print stocks to avoid"""
        print("\n" + "="*80)
        print(f"STOCKS TO AVOID (Bottom {bottom_n})".center(80))
        print("="*80 + "\n")
        
        for i, rec in enumerate(self.analysis_results[-bottom_n:], 1):
            print(f"\n⊗ {rec['symbol']} - Score: {rec['conviction_score']}/100")
            print(f"   Action: {rec['action']}")
            print(f"   Why Avoid:")
            for signal in rec['key_signals'][:3]:
                print(f"     {signal}")
            if rec['risk_warnings']:
                print(f"   Critical Warnings:")
                for warning in rec['risk_warnings'][:2]:
                    print(f"     {warning}")
        
        print(f"\n{'='*80}\n")
    
    def print_top_shorts(self, top_n=3):
        """Print top N short opportunities"""
        # Filter for short recommendations (negative scores)
        short_opportunities = [r for r in self.analysis_results if r['conviction_score'] < -15]
        
        if not short_opportunities:
            print("\n⊗ No short opportunities identified")
            return
        
        print("\n" + "="*80)
        print(f"TOP {top_n} SHORT OPPORTUNITIES".center(80))
        print("="*80 + "\n")
        
        for i, rec in enumerate(short_opportunities[:top_n], 1):
            print(f"\n{'─'*80}")
            print(f"#{i} {rec['symbol']} - Conviction Score: {rec['conviction_score']}/100")
            print(f"{'─'*80}")
            
            print(f"\n📊 Current Price: ₹{rec['spot_price']:.2f} | Futures: ₹{rec['fut_price']:.2f}")
            print(f"🎯 Action: {rec['action']} | Confidence: {rec['confidence']}")
            print(f"📉 Strategy: {rec['strategy']}")
            
            print(f"\n💡 Bearish Signals:")
            for signal in rec['key_signals']:
                print(f"   {signal}")
            
            if rec['risk_warnings']:
                print(f"\n⚠️  Risk Warnings:")
                for warning in rec['risk_warnings']:
                    print(f"   {warning}")
            
            print(f"\n📍 Key Levels:")
            print(f"   Resistance (Call OI): {rec['resistance']}")
            print(f"   Support (Put OI): {rec['support']}")
            print(f"   Downside Protection: {rec['downside_protection']}")
            
            print(f"\n📊 Market Structure:")
            print(f"   Writer Bias: {rec['writer_bias']}")
            print(f"   PCR: {rec['pcr']:.2f}")
            print(f"   OI Trend: {rec['oi_trend'].upper()}")
            print(f"   Price Trend: {rec['price_trend'].upper()}")
            print(f"   Rollover: {rec['rollover_quality'].upper()}")
            
            if 'entry_zone' in rec:
                print(f"\n🎯 Short Setup:")
                print(f"   Entry Zone: {rec['entry_zone']}")
                print(f"   Stop Loss: {rec['stop_loss']}")
                print(f"   Target 1: {rec['target_1']}")
                print(f"   Target 2: {rec['target_2']}")
        
        print(f"\n{'='*80}\n")
    
    def print_top_straddles(self, top_n=5):
        """Print top N straddle selling opportunities"""
        if not hasattr(self, 'straddle_results') or not self.straddle_results:
            print("\n⊗ No straddle analysis available")
            return
        
        print("\n" + "="*80)
        print(f"TOP {top_n} SHORT STRADDLE OPPORTUNITIES".center(80))
        print("="*80 + "\n")
        
        for i, rec in enumerate(self.straddle_results[:top_n], 1):
            print(f"\n{'─'*80}")
            print(f"#{i} {rec['symbol']} - Straddle Score: {rec['straddle_score']}/100")
            print(f"{'─'*80}")
            
            print(f"\n📊 Current Setup:")
            print(f"   Spot Price: ₹{rec['spot_price']:.2f}")
            print(f"   ATM Strike: ₹{rec['atm_strike']}")
            print(f"   Range: {rec['put_support']} - {rec['call_resistance']} ({rec['range_width']} wide)")
            
            print(f"\n🎯 Recommendation: {rec['action']}")
            print(f"   Confidence: {rec['confidence']}")
            print(f"   Strategy: {rec['strategy']}")
            
            # ✅ FIX: Display blocking reasons prominently if trade is blocked
            if rec.get('blocking_reasons'):
                print(f"\n🚫 TRADE BLOCKED - CRITICAL RISKS:")
                for reason in rec['blocking_reasons']:
                    print(f"   {reason}")
                print(f"\n⛔ DO NOT ENTER THIS TRADE")
            
            print(f"\n✓ Favorable Signals:")
            for signal in rec['key_signals']:
                if '✓' in signal:
                    print(f"   {signal}")
            
            unfavorable = [s for s in rec['key_signals'] if '✗' in s or '~' in s]
            if unfavorable:
                print(f"\n⚠️  Risk Factors:")
                for signal in unfavorable[:3]:
                    print(f"   {signal}")
            
            print(f"\n📈 Market Structure:")
            print(f"   OI Trend: Range-bound")
            print(f"   Price Trend: Neutral")
            print(f"   PCR: {rec['pcr']:.2f}")
            print(f"   Call Writer Strength: {rec['call_strength']}")
            print(f"   Put Writer Strength: {rec['put_strength']}")
            print(f"   Days to Expiry: {rec['days_to_expiry']}")
            
            # ✅ FIX: Only show suggested trade if not blocked
            if rec['straddle_score'] >= 65 and rec.get('confidence') != 'BLOCKED':
                print(f"\n💡 Suggested Trade:")
                print(f"   Sell {rec['atm_strike']} Straddle")
                print(f"   Max Profit: Premium collected")
                print(f"   Breakeven: {rec['atm_strike']} ± Premium")
                print(f"   Upper Stop: {rec['call_resistance']} (call resistance)")
                print(f"   Lower Stop: {rec['put_support']} (put support)")
                print(f"   Optimal Hold: {min(10, rec['days_to_expiry'] - 5)} days")
        
        print(f"\n{'='*80}\n")
    
    def export_results(self, filename='fno_analysis_results.csv', straddle_filename='fno_straddle_results.csv'):
        """Export results to CSV"""
        df = pd.DataFrame(self.analysis_results)
        df.to_csv(filename, index=False)
        print(f"✓ Directional results exported to {filename}")
        
        if hasattr(self, 'straddle_results') and self.straddle_results:
            straddle_df = pd.DataFrame(self.straddle_results)
            straddle_df.to_csv(straddle_filename, index=False)
            print(f"✓ Straddle results exported to {straddle_filename}")


# Example usage
if __name__ == "__main__":
    # List your CSV files in chronological order
    csv_files = [        
        'trend_results_adaptive_v10_nuance_20251017_105541.csv',
        'trend_results_adaptive_v10_nuance_20251021_130225.csv',
        'trend_results_adaptive_v10_nuance_20251023_093302.csv',
        'trend_results_adaptive_v10_nuance_20251024_182911.csv',
        'trend_results_adaptive_v10_nuance_20251027_154643.csv'        
            ]
    
    # IV data file (optional but recommended for straddle analysis)
    iv_data_file = r'C:\nihil\finance_ai_ws\options_screener_2025-10-27-03-41-49.csv'
    
    # Initialize and run analysis
    analyzer = FNOSnapshotAnalyzer(csv_files, iv_data_file=iv_data_file)
    analyzer.load_data()
    analyzer.analyze_all_symbols(include_straddles=True)
    
    # Print directional opportunities
    analyzer.print_top_opportunities(top_n=5)
    analyzer.print_top_shorts(top_n=3)
    analyzer.print_avoid_list(bottom_n=3)
    
    # Print straddle opportunities
    analyzer.print_top_straddles(top_n=5)
    
    # Export all analyses
    analyzer.export_results()