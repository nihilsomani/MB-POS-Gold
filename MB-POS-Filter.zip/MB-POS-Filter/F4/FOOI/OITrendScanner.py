import kiteconnect
from kiteconnect import KiteConnect
import pandas as pd
from datetime import datetime, timedelta, date
import time
import logging
import pytz
import traceback
from threading import Lock
import numpy as np

# --- Constants for New Features ---
MIN_FUT_AVG_VOLUME = 50000
MIN_FUT_AVG_OI = 100000
MIN_OPTION_OI = 50
MIN_OPTION_VOLUME = 20
STALE_SPOT_PRICE_THRESHOLD_SECONDS = 300
OUTLIER_STD_DEV_THRESHOLD = 3

# --- Constants for Baseline Z-Score Calculations ---
BASELINE_DAYS_FOR_INDEX_ZSCORE = 90
MIN_INDEX_BASELINE_TRADING_DAYS_FOR_ZSCORE = 40

BASELINE_DAYS_FOR_FUTURES_ZSCORE = 40
MIN_FUT_BASELINE_TRADING_DAYS_FOR_ZSCORE = 20

# --- Constants for Dynamic Regime Detection ---
NIFTY_50_SYMBOL = "NIFTY 50"
INDIA_VIX_SYMBOL = "INDIA VIX"
REGIME_DETECTION_DAYS = 100
EMA_SHORT_PERIOD = 20
EMA_LONG_PERIOD = 50
VIX_LOW_THRESHOLD = 15
VIX_HIGH_THRESHOLD = 22

# --- Constants for Sentiment Determination ---
Z_THRESH_OI = 0.75 # From v9
Z_THRESH_PRICE = 0.75 # From v9
OI_PCT_THRESH_POS = 5.0
OI_PCT_THRESH_NEG = -5.0
PRICE_PCT_THRESH_POS = 0.75
PRICE_PCT_THRESH_NEG = -0.75

# --- Constants for Dynamic Z-Threshold Scaling ---
# Reference daily realized vol in percent to scale z-thresholds around
# Example: if a symbol's daily std of returns is 2.0% (vs ref 1.0%), threshold multiplier ~2.0 (clamped)
DYN_Z_REF_DAILY_RETURN_PCT = 1.0
DYN_Z_MULT_MIN = 0.7
DYN_Z_MULT_MAX = 1.6

# --- Constants for Term Structure Adjustment ---
TERM_STRONG_BACKWARD_THRESH = -1.0
TERM_MODERATE_BACKWARD_THRESH = -0.5
TERM_MILD_BACKWARD_THRESH = 0.0
TERM_MILD_CONTANGO_THRESH = 0.0
TERM_MODERATE_CONTANGO_THRESH = 0.5
TERM_STRONG_CONTANGO_THRESH = 1.0

TERM_ADJ_BULLISH_STRONG_BACKWARD = -8.0
TERM_ADJ_BULLISH_MODERATE_BACKWARD = -4.0
TERM_ADJ_BULLISH_MILD_BACKWARD = -2.0
TERM_ADJ_BULLISH_MILD_CONTANGO = 2.0
TERM_ADJ_BULLISH_MODERATE_CONTANGO = 4.0
TERM_ADJ_BULLISH_STRONG_CONTANGO = 8.0

TERM_ADJ_BEARISH_STRONG_CONTANGO = -8.0
TERM_ADJ_BEARISH_MODERATE_CONTANGO = -4.0
TERM_ADJ_BEARISH_MILD_CONTANGO = -2.0
TERM_ADJ_BEARISH_MILD_BACKWARD = 2.0
TERM_ADJ_BEARISH_MODERATE_BACKWARD = 4.0
TERM_ADJ_BEARISH_STRONG_BACKWARD = 8.0

# --- Constants for Price-to-OI Ratio ---
PRICE_OI_RATIO_LOW_THRESH = 0.02
PRICE_OI_RATIO_HIGH_THRESH = 0.05
PRICE_OI_RATIO_PENALTY = -7.0
PRICE_OI_RATIO_BONUS = 3.0
MIN_OI_CHANGE_FOR_RATIO = 100.0

# --- Constants for Z-Score Divergence ---
ZSCORE_DIVERGENCE_PRICE_THRESH = 0.5
ZSCORE_DIVERGENCE_OI_THRESH = 1.5
ZSCORE_DIVERGENCE_PENALTY = -5.0

# --- Constants for Bullish Confidence Cap ---
BULLISH_CONFIDENCE_CAP = 60.0
BULLISH_CAP_PCR_THRESH = 0.6

# --- Constants for Bearish Institutional Rollover Detection ---
BIR_PRICE_CHANGE_MAX_THRESH = 3.0
BIR_OI_CHANGE_MIN_THRESH = 150.0
BIR_TERM_STRUCTURE_MAX_THRESH = 0.0
BIR_RQI_MIN_THRESH = 6.0
BIR_CONFIDENCE_PENALTY = -20.0

# --- Constants from v9 Enhancements ---
DISQUALIFY_LONG_RQI_THRESH = 4.0
DISQUALIFY_LONG_ROLL_PCT_THRESH = 40.0

# --- ENHANCEMENT V10: New Constants ---
INST_BREAK_PRICE_Z_THRESH = 0.9
INST_BREAK_CALL_WRITER_PCT_THRESH = 60.0
INST_BREAK_SPOT_PRICE_ABOVE_MAX_CALL_STRIKE = True
INST_BREAK_BONUS = 20.0

ROLL_SKEW_THRESH = 50.0
ROLL_SKEW_BULLISH_BONUS = 10.0

TRUST_RQI_THRESH = 6.5
TRUST_ROLL_PCT_THRESH = 70.0
TRUST_TERM_SLOPE_THRESH = 0.25

# --- NUANCE COLUMNS: Price Journey ---
SERIES_LOW_LOOKBACK_DAYS = 120 # Lookback days to find the series low for a contract


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
    handlers=[
        logging.FileHandler("trend_scanner_regime_adaptive_v10_nuance.log"), # Log file name updated
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("OITrendScannerV10Nuance") # Logger name updated

class TokenBucketRateLimiter:
    def __init__(self, capacity, rate_per_second):
        self.capacity = capacity
        self.rate_per_second = rate_per_second
        self.tokens = capacity
        self.last_refill = time.time()
        self.lock = Lock()

    def _refill(self):
        now = time.time()
        elapsed = now - self.last_refill
        new_tokens = elapsed * self.rate_per_second
        self.tokens = min(self.capacity, self.tokens + new_tokens)
        self.last_refill = now

    def acquire(self):
        with self.lock:
            self._refill()
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            return False

    def wait(self, max_retries=5, base_delay=1):
        for attempt in range(max_retries):
            if self.acquire():
                return True
            delay = base_delay * (2 ** attempt)
            logger.debug(f"Rate limit hit, waiting {delay:.2f}s (attempt {attempt + 1}/{max_retries})")
            time.sleep(delay)
        logger.error("Rate limit exceeded after max retries")
        return False


class TrendScanner:
    def __init__(self, api_key, access_token, input_csv="data/FNOStock.csv"):
        self.api_key = api_key
        self.access_token = access_token
        self.kite = KiteConnect(api_key=self.api_key)
        self.kite.set_access_token(self.access_token)
        self.exchange = "NFO"
        self.input_csv = input_csv
        self.results = []
        self.rate_limiter = TokenBucketRateLimiter(capacity=10, rate_per_second=3)
        self.ist_timezone = pytz.timezone("Asia/Kolkata")
        self.detected_market_regime = "NeutralUndetermined"
        self.nifty_token = None
        self.vix_token = None

        logger.info("Initializing TrendScanner V10 (with Price Journey Nuance Columns)...")
        logger.debug("Fetching NSE instruments for cache")
        if not self.rate_limiter.wait():
            logger.critical("Rate limit exceeded (NSE instruments startup). Halting.")
            raise Exception("Rate limit exceeded during critical startup phase (NSE instruments).")
        try:
            self.nse_instrument_cache = pd.DataFrame(self.kite.instruments(exchange="NSE"))
            if self.nse_instrument_cache.empty:
                 logger.critical("NSE instrument cache is empty after fetching. Cannot proceed.")
                 raise ValueError("NSE instrument cache is empty.")
            logger.debug(f"NSE instruments cached: {len(self.nse_instrument_cache)} rows")

            nifty_row = self.nse_instrument_cache[self.nse_instrument_cache['tradingsymbol'] == NIFTY_50_SYMBOL]
            if not nifty_row.empty:
                self.nifty_token = nifty_row['instrument_token'].iloc[0]
                logger.info(f"Found NIFTY 50 token: {self.nifty_token}")
            else:
                logger.error(f"{NIFTY_50_SYMBOL} token not found in NSE instruments. Regime detection will be limited.")

            vix_row = self.nse_instrument_cache[self.nse_instrument_cache['tradingsymbol'] == INDIA_VIX_SYMBOL]
            if not vix_row.empty:
                self.vix_token = vix_row['instrument_token'].iloc[0]
                logger.info(f"Found INDIA VIX token: {self.vix_token}")
            else:
                logger.error(f"{INDIA_VIX_SYMBOL} token not found in NSE instruments. Regime detection will be limited.")

        except (kiteconnect.exceptions.TokenException, kiteconnect.exceptions.NetworkException) as e_api:
            logger.critical(f"API error fetching NSE instruments: {e_api}. Check API key/token and network.")
            raise
        except Exception as e:
            logger.critical(f"Generic error fetching NSE instruments: {traceback.format_exc()}")
            self.nse_instrument_cache = pd.DataFrame()
            raise

        logger.debug("Fetching NFO instruments for cache")
        if not self.rate_limiter.wait():
            logger.critical("Rate limit exceeded (NFO instruments startup). Halting.")
            raise Exception("Rate limit exceeded during critical startup phase (NFO instruments).")
        try:
            nfo_instruments_list = self.kite.instruments(exchange="NFO")
            self.instrument_cache = pd.DataFrame(nfo_instruments_list)
            if self.instrument_cache.empty:
                 logger.warning("NFO instrument cache is empty after fetching. Futures/Options analysis will fail.")
            else:
                logger.debug(f"NFO instruments fetched: {len(self.instrument_cache)} rows")
                self.instrument_cache['expiry'] = pd.to_datetime(self.instrument_cache['expiry'], errors='coerce')
        except (kiteconnect.exceptions.TokenException, kiteconnect.exceptions.NetworkException) as e_api:
            logger.critical(f"API error fetching NFO instruments: {e_api}. Check API key/token and network.")
            raise
        except Exception as e:
            logger.critical(f"Generic error fetching NFO instruments: {traceback.format_exc()}")
            self.instrument_cache = pd.DataFrame()
            raise

        self.detect_market_regime()
        logger.info(f"TrendScanner V10 (Nuance) initialized. Detected Market Regime: {self.detected_market_regime}")

    def _calculate_ema(self, prices_series, period):
        if not isinstance(prices_series, pd.Series):
             prices_series = pd.Series(prices_series)
        if len(prices_series) < period:
            return pd.Series([np.nan] * len(prices_series), index=prices_series.index)
        return prices_series.ewm(span=period, adjust=False, min_periods=period).mean()

    def detect_market_regime(self):
        logger.info("Attempting to detect market regime...")
        if self.nifty_token is None:
            logger.warning("NIFTY 50 token not available. Defaulting regime to NeutralUndetermined.")
            self.detected_market_regime = "NeutralUndetermined"
            return self.detected_market_regime

        current_date_obj = datetime.now(self.ist_timezone).date()
        from_date_obj = current_date_obj - timedelta(days=REGIME_DETECTION_DAYS + EMA_LONG_PERIOD + 20)

        nifty_df = self.get_historical_data(self.nifty_token, from_date_obj, current_date_obj, interval="day", contract_type="index")

        if nifty_df.empty or len(nifty_df) < EMA_LONG_PERIOD:
            logger.warning(f"Insufficient Nifty data ({len(nifty_df)} days) for regime detection. Defaulting to NeutralUndetermined.")
            self.detected_market_regime = "NeutralUndetermined"
            return self.detected_market_regime

        nifty_df['ema_short'] = self._calculate_ema(nifty_df['close'], EMA_SHORT_PERIOD)
        nifty_df['ema_long'] = self._calculate_ema(nifty_df['close'], EMA_LONG_PERIOD)

        nifty_df.dropna(subset=['ema_short', 'ema_long'], inplace=True)
        if nifty_df.empty:
            logger.warning("Nifty data became empty after EMA calculation and NaN drop. Defaulting to NeutralUndetermined.")
            self.detected_market_regime = "NeutralUndetermined"
            return self.detected_market_regime

        latest_nifty = nifty_df.iloc[-1]
        nifty_close = latest_nifty['close']
        nifty_ema_short = latest_nifty['ema_short']
        nifty_ema_long = latest_nifty['ema_long']

        latest_vix_close = VIX_LOW_THRESHOLD
        if self.vix_token:
            vix_from_date = current_date_obj - timedelta(days=10)
            vix_df = self.get_historical_data(self.vix_token, vix_from_date, current_date_obj, interval="day", contract_type="index")
            if not vix_df.empty and 'close' in vix_df.columns and not vix_df['close'].empty:
                latest_vix_close = vix_df['close'].iloc[-1]
            else:
                logger.warning("Insufficient or malformed VIX data. Using default VIX assumption (low).")
        else:
            logger.warning("INDIA VIX token not available. Using default VIX assumption (low).")

        logger.info(f"Regime Detection Data: Nifty Close={nifty_close:.2f}, EMA{EMA_SHORT_PERIOD}={nifty_ema_short:.2f}, EMA{EMA_LONG_PERIOD}={nifty_ema_long:.2f}, VIX Close={latest_vix_close:.2f}")

        regime = "NeutralUndetermined"
        if pd.isna(nifty_ema_short) or pd.isna(nifty_ema_long) or pd.isna(nifty_close):
            logger.warning("NaN values in Nifty EMAs or close. Defaulting regime to NeutralUndetermined.")
            self.detected_market_regime = "NeutralUndetermined"
            return self.detected_market_regime

        is_uptrend = nifty_close > nifty_ema_short and nifty_ema_short > nifty_ema_long
        is_downtrend = nifty_close < nifty_ema_short and nifty_ema_short < nifty_ema_long

        if is_uptrend:
            if latest_vix_close < VIX_LOW_THRESHOLD: regime = "BullishCalm"
            elif latest_vix_close < VIX_HIGH_THRESHOLD: regime = "BullishModerateVol"
            else: regime = "BullishHighVol"
        elif is_downtrend:
            if latest_vix_close < VIX_LOW_THRESHOLD: regime = "BearishCalm"
            elif latest_vix_close < VIX_HIGH_THRESHOLD: regime = "BearishModerateVol"
            else: regime = "BearishHighVol"
        else:
            if latest_vix_close < VIX_LOW_THRESHOLD: regime = "SidewaysLowVol"
            elif latest_vix_close < VIX_HIGH_THRESHOLD: regime = "SidewaysModerateVol"
            else: regime = "SidewaysHighVol"

        self.detected_market_regime = regime
        logger.info(f"Detected Market Regime: {self.detected_market_regime}")
        return self.detected_market_regime

    def read_symbols(self):
        try:
            df = pd.read_csv(self.input_csv)
            if 'Symbol' not in df.columns:
                raise ValueError("CSV must contain 'Symbol' column")
            symbols = df['Symbol'].unique().tolist()
            logger.debug(f"Read {len(symbols)} unique symbols from {self.input_csv}: {symbols}")
            return symbols
        except FileNotFoundError:
            logger.error(f"Input CSV file not found at '{self.input_csv}'. Please create it or check the path.")
            return []
        except Exception as e:
            logger.error(f"Error reading CSV '{self.input_csv}': {traceback.format_exc()}")
            return []

    def _cap_outliers(self, series, column_name="value"):
        if series.empty or series.isnull().all():
            return series
        series_numeric = pd.to_numeric(series, errors='coerce')
        if series_numeric.isnull().all():
            return series

        mean = series_numeric.mean()
        std = series_numeric.std()

        if pd.isna(mean) or pd.isna(std) or std == 0:
            return series

        upper_bound = mean + OUTLIER_STD_DEV_THRESHOLD * std
        lower_bound = mean - OUTLIER_STD_DEV_THRESHOLD * std

        capped_series = series.clip(lower=lower_bound, upper=upper_bound)

        num_capped_upper = (series_numeric > upper_bound).sum()
        num_capped_lower = (series_numeric < lower_bound).sum()
        if num_capped_upper > 0:
            logger.debug(f"Capped {num_capped_upper} upper outliers for {column_name} (limit: {upper_bound:.2f})")
        if num_capped_lower > 0:
            logger.debug(f"Capped {num_capped_lower} lower outliers for {column_name} (limit: {lower_bound:.2f})")
        return capped_series

    def get_historical_data(self, instrument_token, from_date_obj, to_date_obj, interval="day", cap_outliers_flag=False, contract_type="future"):
        if not self.rate_limiter.wait():
            logger.error(f"Rate limit exceeded for historical data token {instrument_token}")
            return pd.DataFrame()
        try:
            from_date_str = from_date_obj.strftime('%Y-%m-%d')
            to_date_str = to_date_obj.strftime('%Y-%m-%d')
            logger.debug(f"Fetching {interval} data for token {instrument_token} ({contract_type}) from {from_date_str} to {to_date_str}")

            fetch_oi = True
            if contract_type == "index":
                fetch_oi = False

            data = self.kite.historical_data(instrument_token, from_date_str, to_date_str, interval, oi=fetch_oi, continuous=False)
            df = pd.DataFrame(data)

            if not df.empty:
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                # Ensure 'close' column is numeric before capping
                if 'close' in df.columns:
                    df['close'] = pd.to_numeric(df['close'], errors='coerce')
                if 'oi' in df.columns and fetch_oi:
                     df['oi'] = pd.to_numeric(df['oi'], errors='coerce')

                if cap_outliers_flag:
                    if 'close' in df.columns:
                        df['close'] = self._cap_outliers(df['close'], f"token {instrument_token} close price")
                    if 'oi' in df.columns and fetch_oi:
                        df['oi'] = self._cap_outliers(df['oi'], f"token {instrument_token} OI")
            else:
                logger.debug(f"No historical data for token {instrument_token} in range {from_date_str} to {to_date_str}.")
            return df
        except kiteconnect.exceptions.InputException as e:
            logger.warning(f"Input error (e.g. no data/invalid date range) for historical data {instrument_token} ({from_date_str} to {to_date_str}): {e}")
        except kiteconnect.exceptions.TokenException as e:
            logger.critical(f"Token error fetching historical data for {instrument_token}: {e}. Halting.")
            raise
        except kiteconnect.exceptions.NetworkException as e:
            logger.error(f"Network/API error fetching historical data for {instrument_token}: {e}")
        except Exception as e:
            logger.error(f"Generic error fetching historical data for {instrument_token}: {traceback.format_exc()}")
        return pd.DataFrame()

    def get_futures_chain(self, symbol):
        if self.instrument_cache.empty:
            logger.warning(f"Instrument cache is empty. Cannot get futures chain for {symbol}")
            return {'current': None, 'next': None}

        futures_df = self.instrument_cache[
            (self.instrument_cache['name'] == symbol.upper()) &
            (self.instrument_cache['instrument_type'] == 'FUT')
        ].copy()

        if futures_df.empty:
            logger.debug(f"No futures data found for underlying {symbol} using 'name' filter.")
            return {'current': None, 'next': None}

        if not pd.api.types.is_datetime64_any_dtype(futures_df['expiry']):
            futures_df['expiry'] = pd.to_datetime(futures_df['expiry'], errors='coerce')
            futures_df.dropna(subset=['expiry'], inplace=True)

        futures_df.sort_values('expiry', inplace=True)
        now_date = datetime.now(self.ist_timezone).date()

        active_futures = futures_df[futures_df['expiry'].dt.date >= now_date]

        if active_futures.empty:
            logger.debug(f"No active futures contracts found for {symbol} on or after {now_date}")
            return {'current': None, 'next': None}

        current_contract_series = active_futures.iloc[0] if not active_futures.empty else None
        current_contract = current_contract_series.to_dict() if current_contract_series is not None else None

        next_contract = None
        if current_contract and len(active_futures) > 1:
            current_expiry_date = pd.Timestamp(current_contract['expiry']).date()
            for i in range(1, len(active_futures)):
                candidate_contract_series = active_futures.iloc[i]
                candidate_expiry_date = pd.Timestamp(candidate_contract_series['expiry']).date()
                if candidate_expiry_date.year > current_expiry_date.year or \
                   (candidate_expiry_date.year == current_expiry_date.year and candidate_expiry_date.month > current_expiry_date.month):
                    next_contract = candidate_contract_series.to_dict()
                    break

        if current_contract: logger.debug(f"Current contract for {symbol}: {current_contract['tradingsymbol']}")
        if next_contract: logger.debug(f"Next contract for {symbol}: {next_contract['tradingsymbol']}")
        else: logger.debug(f"Next month contract not found or not applicable for {symbol}")
        return {'current': current_contract, 'next': next_contract}

    def get_option_chain(self, symbol, expiry_dates_param):
        if self.instrument_cache.empty:
            logger.warning(f"Instrument cache is empty for options of {symbol}")
            return pd.DataFrame()
        try:
            if not expiry_dates_param or not all(isinstance(d, date) for d in expiry_dates_param):
                logger.error(f"Invalid expiry_dates_param for {symbol}: {expiry_dates_param}. Must be list of date objects.")
                return pd.DataFrame()

            target_expiry_dates = list(set(expiry_dates_param))
            logger.debug(f"Fetching options for {symbol} with target expiries: {target_expiry_dates}")

            if 'expiry' not in self.instrument_cache.columns or \
               not pd.api.types.is_datetime64_any_dtype(self.instrument_cache['expiry']):
                logger.error("Instrument cache 'expiry' column is not in datetime format or missing.")
                return pd.DataFrame()

            option_chain_df = self.instrument_cache[
                (self.instrument_cache['name'] == symbol.upper()) &
                (self.instrument_cache['instrument_type'].isin(['CE', 'PE'])) &
                (self.instrument_cache['expiry'].dt.date.isin(target_expiry_dates))
            ].copy()

            if option_chain_df.empty:
                logger.debug(f"No options for {symbol} with expiries {target_expiry_dates} using name filter.")
                return pd.DataFrame()

            tradingsymbols = option_chain_df['tradingsymbol'].tolist()
            batch_size = 400
            live_data = {}
            for i in range(0, len(tradingsymbols), batch_size):
                batch = tradingsymbols[i:i + batch_size]
                if not self.rate_limiter.wait():
                    logger.error(f"Rate limit for option quotes {symbol}. Skipping remaining.")
                    break
                try:
                    nfo_batch = [f"NFO:{ts}" for ts in batch]
                    quotes = self.kite.quote(nfo_batch)
                    if quotes and isinstance(quotes, dict):
                        live_data.update({k.split('NFO:')[1]: v for k, v in quotes.items() if v and 'NFO:' in k and k.split('NFO:')[1] in batch})
                    else: logger.warning(f"Empty/invalid quotes for batch {symbol}: {batch}")
                except Exception as qe: logger.error(f"Error fetching quotes for batch {symbol} {batch}: {qe}")

            option_chain_df['last_price'] = option_chain_df['tradingsymbol'].map(lambda x: live_data.get(x, {}).get('last_price', 0))
            option_chain_df['volume'] = option_chain_df['tradingsymbol'].map(lambda x: live_data.get(x, {}).get('volume', 0))
            option_chain_df['oi'] = option_chain_df['tradingsymbol'].map(lambda x: live_data.get(x, {}).get('oi', 0))
            return option_chain_df

        except Exception as e:
            logger.error(f"Error processing option chain for {symbol}: {traceback.format_exc()}")
        return pd.DataFrame()

    def filter_strikes(self, option_chain_df, spot_price):
        if spot_price is None or spot_price <= 0:
            logger.warning(f"Invalid spot price ({spot_price}), skipping strike filtering.")
            return pd.DataFrame()
        if option_chain_df.empty:
            logger.debug("Empty option chain to filter_strikes.")
            return pd.DataFrame()
        try:
            chain_to_filter = option_chain_df.copy()
            if 'strike' not in chain_to_filter.columns:
                logger.warning("'strike' column missing in option chain for filtering.")
                return pd.DataFrame()

            chain_to_filter['strike'] = pd.to_numeric(chain_to_filter['strike'], errors='coerce')
            chain_to_filter.dropna(subset=['strike'], inplace=True)
            if chain_to_filter.empty:
                logger.debug("Option chain empty after strike conversion/NaN drop.")
                return pd.DataFrame()

            chain_to_filter.sort_values('strike', inplace=True)

            atm_strike_candidates = chain_to_filter.iloc[(chain_to_filter['strike'] - spot_price).abs().argsort()]
            if atm_strike_candidates.empty:
                logger.warning(f"Could not determine ATM strike for spot {spot_price:.2f}.")
                return pd.DataFrame()
            atm_strike = atm_strike_candidates['strike'].iloc[0]

            unique_strikes = sorted(chain_to_filter['strike'].unique())
            strike_step = spot_price * 0.01
            if len(unique_strikes) > 1:
                strike_steps_arr = np.diff(unique_strikes)
                positive_strike_steps = strike_steps_arr[strike_steps_arr > 0]
                if len(positive_strike_steps) > 0:
                    mode_res = pd.Series(positive_strike_steps).mode()
                    if not mode_res.empty:
                        strike_step = mode_res.iloc[0]
                    else:
                        strike_step = np.median(positive_strike_steps)

            strike_step = max(1.0, float(strike_step))

            num_strikes_away = 5  # ±5 strikes around ATM (wider context for OI analysis)
            lower_bound_strikes = atm_strike - (num_strikes_away * strike_step)
            upper_bound_strikes = atm_strike + (num_strikes_away * strike_step)

            lower_bound_percentage = spot_price * 0.88  # ±12% from spot (captures full breakeven range)
            upper_bound_percentage = spot_price * 1.12

            final_lower_bound = min(lower_bound_strikes, lower_bound_percentage)
            final_upper_bound = max(upper_bound_strikes, upper_bound_percentage)

            final_lower_bound = min(final_lower_bound, atm_strike)
            final_upper_bound = max(final_upper_bound, atm_strike)

            filtered_chain = chain_to_filter[(chain_to_filter['strike'] >= final_lower_bound) & (chain_to_filter['strike'] <= final_upper_bound)]
            logger.debug(f"Filtered {len(filtered_chain)} strikes for spot {spot_price:.2f} (ATM: {atm_strike}, Step: {strike_step:.2f}, Range: {final_lower_bound:.2f}-{final_upper_bound:.2f})")
            return filtered_chain
        except Exception as e:
            logger.error(f"Error filtering strikes: {traceback.format_exc()}")
        return pd.DataFrame()

    def get_spot_price(self, symbol):
        if not self.rate_limiter.wait():
            logger.error(f"Rate limit for spot price {symbol}")
            return None
        try:
            instrument = f"NSE:{symbol.upper()}"
            logger.debug(f"Fetching spot price for {instrument}")
            quote_response = self.kite.quote([instrument])

            if quote_response and instrument in quote_response and quote_response[instrument].get('last_price') is not None:
                quote_data = quote_response[instrument]
                spot_price = quote_data['last_price']

                last_trade_time_from_quote = quote_data.get('timestamp')
                last_trade_time = None

                if last_trade_time_from_quote:
                    if isinstance(last_trade_time_from_quote, datetime):
                        if last_trade_time_from_quote.tzinfo is None:
                            last_trade_time = self.ist_timezone.localize(last_trade_time_from_quote)
                        else:
                            last_trade_time = last_trade_time_from_quote.astimezone(self.ist_timezone)
                    elif isinstance(last_trade_time_from_quote, (int, float)):
                        try:
                            last_trade_time = datetime.fromtimestamp(last_trade_time_from_quote, tz=pytz.utc).astimezone(self.ist_timezone)
                        except Exception as e_ts:
                            logger.warning(f"Could not convert epoch {last_trade_time_from_quote} to datetime for {symbol}: {e_ts}")
                    elif isinstance(last_trade_time_from_quote, str):
                        try:
                            dt_obj = pd.to_datetime(last_trade_time_from_quote)
                            if dt_obj.tzinfo is None: last_trade_time = self.ist_timezone.localize(dt_obj)
                            else: last_trade_time = dt_obj.astimezone(self.ist_timezone)
                        except Exception as e_str_ts:
                             logger.warning(f"Spot price timestamp for {symbol} (str) '{last_trade_time_from_quote}' couldn't be parsed: {e_str_ts}")
                    else:
                        logger.warning(f"Spot price timestamp for {symbol} is in an unexpected format: {type(last_trade_time_from_quote)}")

                    if last_trade_time and (datetime.now(self.ist_timezone) - last_trade_time).total_seconds() > STALE_SPOT_PRICE_THRESHOLD_SECONDS:
                        logger.warning(f"Spot price for {symbol} ({spot_price}) might be stale. Last trade: {last_trade_time.strftime('%Y-%m-%d %H:%M:%S %Z')}")
                else:
                    logger.warning(f"No timestamp found in quote for {symbol}. Spot price ({spot_price}) might be stale.")

                logger.debug(f"Spot price for {symbol}: {spot_price}")
                return spot_price
            else:
                err_msg = quote_response.get(instrument) if quote_response and instrument in quote_response else 'Instrument not in response or no response.'
                logger.error(f"Could not get valid spot price for {instrument}. Response: {err_msg}")
                return None
        except (kiteconnect.exceptions.TokenException, kiteconnect.exceptions.NetworkException) as e_api:
            logger.critical(f"API error fetching spot for {symbol}: {e_api}.")
            if isinstance(e_api, kiteconnect.exceptions.TokenException):
                raise
        except Exception as e:
            logger.error(f"Generic error fetching spot for {symbol}: {traceback.format_exc()}")
        return None

    def _determine_sentiment(self, oi_change_percent, price_change_percent, oi_z_score=None, price_z_score=None,
                             oi_z_threshold=None, price_z_threshold=None):
        oi_thresh = oi_z_threshold if oi_z_threshold is not None else Z_THRESH_OI
        px_thresh = price_z_threshold if price_z_threshold is not None else Z_THRESH_PRICE

        significant_oi_increase = (oi_z_score is not None and oi_z_score > oi_thresh) or \
                                  (oi_change_percent is not None and oi_change_percent > OI_PCT_THRESH_POS)
        significant_oi_decrease = (oi_z_score is not None and oi_z_score < -oi_thresh) or \
                                  (oi_change_percent is not None and oi_change_percent < OI_PCT_THRESH_NEG)

        significant_price_increase = (price_z_score is not None and price_z_score > px_thresh) or \
                                     (price_change_percent is not None and price_change_percent > PRICE_PCT_THRESH_POS)
        significant_price_decrease = (price_z_score is not None and price_z_score < -px_thresh) or \
                                     (price_change_percent is not None and price_change_percent < PRICE_PCT_THRESH_NEG)

        sentiment = "Neutral"
        if significant_oi_increase and significant_price_increase: sentiment = "Long Buildup"
        elif significant_oi_decrease and significant_price_increase: sentiment = "Short Covering"
        elif significant_oi_increase and significant_price_decrease: sentiment = "Short Buildup"
        elif significant_oi_decrease and significant_price_decrease: sentiment = "Long Unwinding"

        oi_log = f"{oi_change_percent:.2f}" if oi_change_percent is not None else "N/A"
        px_log = f"{price_change_percent:.2f}" if price_change_percent is not None else "N/A"
        oi_z_log = f"{oi_z_score:.2f}" if oi_z_score is not None else "N/A"
        px_z_log = f"{price_z_score:.2f}" if price_z_score is not None else "N/A"
        logger.info(f"Sentiment: {sentiment} (OI%{oi_log} Z:{oi_z_log}, Px%{px_log} Z:{px_z_log})")
        return sentiment

    def _get_sentiment_strength(self, sentiment):
        if sentiment and "Buildup" in sentiment: strength = 1.5
        elif sentiment and ("Covering" in sentiment or "Unwinding" in sentiment): strength = 0.8
        else: strength = 0.0
        return strength

    def _combine_trends_simplified(self, oi_change_pct, price_change_pct,
                                   oi_zscore, price_zscore, pcr_oi):
        """Use only 3 proven factors: OI+Price alignment, Z-score strength, PCR signal."""
        try:
            # Factor 1: OI + Price alignment (40% weight)
            oi_pos = OI_PCT_THRESH_POS
            oi_neg = OI_PCT_THRESH_NEG
            px_pos = PRICE_PCT_THRESH_POS
            px_neg = PRICE_PCT_THRESH_NEG

            if oi_change_pct is None: oi_change_pct = 0.0
            if price_change_pct is None: price_change_pct = 0.0

            if oi_change_pct > oi_pos and price_change_pct > px_pos:
                oi_price_score = 8.0  # Bullish
            elif oi_change_pct > oi_pos and price_change_pct < px_neg:
                oi_price_score = 2.0  # Short buildup
            elif oi_change_pct < oi_neg and price_change_pct > px_pos:
                oi_price_score = 8.0  # Short covering
            elif oi_change_pct < oi_neg and price_change_pct < px_neg:
                oi_price_score = 2.0  # Long unwinding
            else:
                oi_price_score = 5.0

            # Factor 2: Z-score strength (30% weight)
            abs_oi_z = abs(oi_zscore) if oi_zscore is not None else 0.0
            abs_px_z = abs(price_zscore) if price_zscore is not None else 0.0
            zscore_avg = (abs_oi_z + abs_px_z) / 2.0
            zscore_score = min(10.0, zscore_avg * 2.5)

            # Factor 3: PCR signal (30% weight)
            pcr_score = 5.0
            if pcr_oi is not None:
                if pcr_oi > 1.3:
                    pcr_score = 8.0  # Bullish
                elif pcr_oi < 0.7:
                    pcr_score = 2.0  # Bearish

            confidence = (oi_price_score * 0.4 + zscore_score * 0.3 + pcr_score * 0.3) * 10.0

            if oi_price_score > 6.5 or (price_change_pct > px_pos and (pcr_oi is not None and pcr_oi > 1.2)):
                sentiment = "Bullish"
            elif oi_price_score < 3.5 or (price_change_pct < px_neg and (pcr_oi is not None and pcr_oi < 0.8)):
                sentiment = "Bearish"
            else:
                sentiment = "Neutral"

            return sentiment, round(confidence, 1)
        except Exception:
            # On any calculation issue, return neutral with low confidence
            return "Neutral", 0.0

    def _combine_trends_refined(self, symbol, sent_curr, strength_curr, oi_curr_z, price_curr_z,
                                sent_next, strength_next, oi_next_z, price_next_z,
                                effective_days_to_expiry,
                                rqi_val, writer_analysis, detected_market_regime,
                                is_next_month_focused_trade,
                                term_structure_slope_val,
                                price_oi_ratio_primary,
                                primary_oi_change_percent,
                                primary_price_zscore,
                                primary_oi_zscore,
                                spot_price_val, 
                                roll_skew_val): 
        # Simplified replacement: map available inputs to the 3-factor combiner
        try:
            # Prefer primary leg metrics where available
            oi_change_pct = primary_oi_change_percent

            # Derive a proxy for price_change_pct from price z-score if actual percent isn't passed
            price_change_pct = 0.0
            if primary_price_zscore is not None:
                if primary_price_zscore > Z_THRESH_PRICE:
                    price_change_pct = PRICE_PCT_THRESH_POS + 0.01
                elif primary_price_zscore < -Z_THRESH_PRICE:
                    price_change_pct = PRICE_PCT_THRESH_NEG - 0.01

            # Choose z-scores from primary leg
            oi_zscore = primary_oi_zscore
            price_zscore = primary_price_zscore

            # PCR from writer analysis (fallback neutral 1.0)
            pcr_oi = 1.0
            if isinstance(writer_analysis, dict):
                pcr_oi = writer_analysis.get("pcr_oi", 1.0)

            sentiment, confidence = self._combine_trends_simplified(
                oi_change_pct, price_change_pct, oi_zscore, price_zscore, pcr_oi
            )

            logger.info(f"{symbol} - Combined (simplified): {sentiment}, Confidence: {confidence:.1f}%")
            return sentiment, confidence
        except Exception:
            logger.error(f"{symbol} - Error in simplified combine. Reverting to Neutral.")
            return "Neutral", 0.0

    def _determine_action(self, sentiment, filtered_options_df, spot_price, confidence,
                          detected_market_regime, rqi_val, rollover_pct_val, term_structure_slope_val): 
        """
        Determine trading action and return both action string and selected option details.
        Returns: tuple (action_string, option_details_dict)
        """
        action_confidence_threshold = 55.0
        
        # Default option details (will be populated if an option is selected)
        option_details = {
            'selected_option_symbol': None,
            'selected_option_strike': None,
            'selected_option_type': None,
            'selected_option_oi': None,
            'selected_option_volume': None,
            'selected_option_premium': None
        }

        rqi_check = rqi_val if rqi_val is not None else TRUST_RQI_THRESH -1 
        roll_pct_check = rollover_pct_val if rollover_pct_val is not None else TRUST_ROLL_PCT_THRESH - 1 
        term_slope_check = term_structure_slope_val if term_structure_slope_val is not None else TRUST_TERM_SLOPE_THRESH - 0.1 

        if not (rqi_check >= TRUST_RQI_THRESH and \
                roll_pct_check >= TRUST_ROLL_PCT_THRESH and \
                term_slope_check > TRUST_TERM_SLOPE_THRESH):
            logger.info(f"Action: No Action for {sentiment} due to failing Trend Trust Thresholds. RQI: {rqi_val:.1f} (Req: >= {TRUST_RQI_THRESH}), Roll%: {rollover_pct_val:.1f}% (Req: >= {TRUST_ROLL_PCT_THRESH}%), TermSlope: {term_structure_slope_val:.2f}% (Req: > {TRUST_TERM_SLOPE_THRESH}%). Confidence was {confidence:.1f}%.")
            return f"No Action - Fails Trend Trust Thresh. - Conf: {confidence:.1f}%", option_details

        if "HighVol" in detected_market_regime: action_confidence_threshold = 65.0
        elif "ModerateVol" in detected_market_regime: action_confidence_threshold = 60.0
        if detected_market_regime == "SidewaysLowVol" and sentiment != "Neutral":
            action_confidence_threshold = max(action_confidence_threshold, 65.0)

        if sentiment == "Neutral":
            if "Vol" in detected_market_regime or "Trending" in detected_market_regime:
                action_confidence_threshold = min(99.0, action_confidence_threshold + 15.0)
            elif detected_market_regime == "SidewaysLowVol":
                 action_confidence_threshold = min(99.0, action_confidence_threshold + 10.0)
            else:
                 action_confidence_threshold = min(99.0, action_confidence_threshold + 10.0)

        current_action_confidence = confidence

        if sentiment == "Bullish":
            rqi_v9_check = rqi_val if rqi_val is not None else DISQUALIFY_LONG_RQI_THRESH + 1
            roll_pct_v9_check = rollover_pct_val if rollover_pct_val is not None else DISQUALIFY_LONG_ROLL_PCT_THRESH + 1
            if rqi_v9_check < DISQUALIFY_LONG_RQI_THRESH and roll_pct_v9_check < DISQUALIFY_LONG_ROLL_PCT_THRESH:
                logger.info(f"Action: No Action (Long Disqualified by v9 rule) for {sentiment} due to RQI < {DISQUALIFY_LONG_RQI_THRESH} (Actual: {rqi_val:.1f}) AND Roll % < {DISQUALIFY_LONG_ROLL_PCT_THRESH}% (Actual: {rollover_pct_val:.1f}%). Confidence was {current_action_confidence:.1f}%.")
                return f"No Action - Long Disq. (Low RQI & Roll v9) - Conf: {current_action_confidence:.1f}%", option_details

        if current_action_confidence < action_confidence_threshold:
            logger.info(f"Action: No Action (Confidence) - Confidence {current_action_confidence:.1f}% < Threshold {action_confidence_threshold:.1f}% for Regime '{detected_market_regime}' & Sentiment '{sentiment}'")
            return f"No Action - Confidence: {current_action_confidence:.1f}% (Threshold: {action_confidence_threshold:.1f}%)", option_details

        if filtered_options_df is None or filtered_options_df.empty:
            logger.info(f"Action: No Action - No filtered options for {sentiment} sentiment. Confidence: {current_action_confidence:.1f}%")
            return f"No Action - No Filtered Options - Conf: {current_action_confidence:.1f}%", option_details

        liquidity_col = 'oi'
        if liquidity_col not in filtered_options_df.columns or filtered_options_df[liquidity_col].sum(skipna=True) == 0:
            liquidity_col = 'volume'
            if liquidity_col not in filtered_options_df.columns or filtered_options_df[liquidity_col].sum(skipna=True) == 0:
                logger.warning(f"No OI or Volume data in filtered options for {sentiment} sentiment.")
                return f"No Action - Poor Option Liquidity Data - Conf: {current_action_confidence:.1f}%", option_details

        selected_option_row = None

        if sentiment == "Bullish":
            calls_df = filtered_options_df[filtered_options_df['instrument_type'] == 'CE'].copy()
            if not calls_df.empty:
                otm_calls = calls_df[(calls_df['strike'] >= spot_price) & (calls_df['strike'] <= spot_price * 1.05)].sort_values(by='strike', ascending=True)
                if not otm_calls.empty: selected_option_row = otm_calls.loc[otm_calls[liquidity_col].idxmax()]
                else:
                    any_otm_calls = calls_df[calls_df['strike'] > spot_price].sort_values(by='strike', ascending=True)
                    if not any_otm_calls.empty: selected_option_row = any_otm_calls.loc[any_otm_calls[liquidity_col].idxmax()]
                    else:
                        itm_calls = calls_df[calls_df['strike'] < spot_price].sort_values(by='strike', ascending=False)
                        if not itm_calls.empty: selected_option_row = itm_calls.loc[itm_calls[liquidity_col].idxmax()]
            if selected_option_row is None: logger.debug("No suitable call options found for Bullish sentiment.")

        elif sentiment == "Bearish":
            puts_df = filtered_options_df[filtered_options_df['instrument_type'] == 'PE'].copy()
            if not puts_df.empty:
                otm_puts = puts_df[(puts_df['strike'] <= spot_price) & (puts_df['strike'] >= spot_price * 0.95)].sort_values(by='strike', ascending=False)
                if not otm_puts.empty: selected_option_row = otm_puts.loc[otm_puts[liquidity_col].idxmax()]
                else:
                    any_otm_puts = puts_df[puts_df['strike'] < spot_price].sort_values(by='strike', ascending=False)
                    if not any_otm_puts.empty: selected_option_row = any_otm_puts.loc[any_otm_puts[liquidity_col].idxmax()]
                    else:
                        itm_puts = puts_df[puts_df['strike'] > spot_price].sort_values(by='strike', ascending=True)
                        if not itm_puts.empty: selected_option_row = itm_puts.loc[itm_puts[liquidity_col].idxmax()]
            if selected_option_row is None: logger.debug("No suitable put options found for Bearish sentiment.")

        if selected_option_row is not None:
            option_oi = selected_option_row.get('oi', 0)
            option_vol = selected_option_row.get('volume', 0)
            tradingsymbol = selected_option_row['tradingsymbol']
            strike = selected_option_row['strike']
            option_premium = selected_option_row.get('last_price', None)
            option_type = selected_option_row.get('instrument_type', None)  # CE or PE
            
            # Populate option details
            option_details['selected_option_symbol'] = tradingsymbol
            option_details['selected_option_strike'] = strike
            option_details['selected_option_type'] = option_type
            option_details['selected_option_oi'] = option_oi
            option_details['selected_option_volume'] = option_vol
            option_details['selected_option_premium'] = option_premium

            if option_oi < MIN_OPTION_OI or option_vol < MIN_OPTION_VOLUME:
                logger.warning(f"Chosen option {tradingsymbol} has low liquidity: OI={option_oi}, Vol={option_vol}")
                confidence_after_liq_penalty = max(10.0, current_action_confidence - 20.0)
                if confidence_after_liq_penalty < action_confidence_threshold:
                    return f"No Action - Low Liq. ({tradingsymbol}) & Conf {confidence_after_liq_penalty:.1f}% < Thr {action_confidence_threshold:.1f}%", option_details
                else:
                    action_type = "CALL" if sentiment == "Bullish" else "PUT"
                    logger.debug(f"Selected Option (Low Liq.): {tradingsymbol} (Strike {strike}) with {liquidity_col}={selected_option_row[liquidity_col]}")
                    return f"BUY {action_type} {tradingsymbol} *LOW LIQUIDITY* - Conf: {confidence_after_liq_penalty:.1f}%", option_details
            else:
                action_type = "CALL" if sentiment == "Bullish" else "PUT"
                logger.debug(f"Selected Option: {tradingsymbol} (Strike {strike}) with {liquidity_col}={selected_option_row[liquidity_col]}")
                return f"BUY {action_type} {tradingsymbol} - Confidence: {current_action_confidence:.1f}%", option_details
        else:
            logger.info(f"Action: No Action - No suitable option contract selected for {sentiment} sentiment. Conf: {current_action_confidence:.1f}% (Thr: {action_confidence_threshold:.1f}%)")
            return f"No Action - No Option Selected - Conf: {current_action_confidence:.1f}%", option_details

    def analyze_writer_strength(self, filtered_options_df, spot_price):
        if filtered_options_df is None or filtered_options_df.empty:
            return {"call_writer_strength_percent": 0.0, "put_writer_strength_percent": 0.0,
                    "dominant_side": "Neutral (No Options Data)", "pcr_oi": 1.0,
                    "max_call_oi_strike": None, "max_put_oi_strike": None}

        calls = filtered_options_df[filtered_options_df['instrument_type'] == 'CE']
        puts = filtered_options_df[filtered_options_df['instrument_type'] == 'PE']

        total_call_oi = calls['oi'].sum(skipna=True) if not calls.empty and 'oi' in calls.columns else 0
        total_put_oi = puts['oi'].sum(skipna=True) if not puts.empty and 'oi' in puts.columns else 0

        max_call_strike_info, max_put_strike_info = None, None
        max_call_oi_value, max_put_oi_value = 0, 0
        
        if not calls.empty and total_call_oi > 0 and 'strike' in calls.columns:
             max_call_strike_info = calls.loc[calls['oi'].idxmax()]
             max_call_oi_value = max_call_strike_info['oi']
        if not puts.empty and total_put_oi > 0 and 'strike' in puts.columns:
             max_put_strike_info = puts.loc[puts['oi'].idxmax()]
             max_put_oi_value = max_put_strike_info['oi']

        # Calculate OI concentration percentages
        call_concentration_pct = (max_call_oi_value / total_call_oi * 100) if total_call_oi > 0 else 0
        put_concentration_pct = (max_put_oi_value / total_put_oi * 100) if total_put_oi > 0 else 0

        # Find second highest OI strikes for spread detection
        calls_by_oi = calls.sort_values('oi', ascending=False) if not calls.empty else pd.DataFrame()
        puts_by_oi = puts.sort_values('oi', ascending=False) if not puts.empty else pd.DataFrame()

        second_call_strike = calls_by_oi.iloc[1]['strike'] if len(calls_by_oi) > 1 else None
        second_call_oi_ratio = (calls_by_oi.iloc[1]['oi'] / max_call_oi_value) if len(calls_by_oi) > 1 and max_call_oi_value > 0 else 0

        second_put_strike = puts_by_oi.iloc[1]['strike'] if len(puts_by_oi) > 1 else None
        second_put_oi_ratio = (puts_by_oi.iloc[1]['oi'] / max_put_oi_value) if len(puts_by_oi) > 1 and max_put_oi_value > 0 else 0

        total_oi = total_call_oi + total_put_oi
        call_strength_percent = (total_call_oi / total_oi * 100) if total_oi > 0 else 0.0
        put_strength_percent = (total_put_oi / total_oi * 100) if total_oi > 0 else 0.0

        pcr_oi = total_put_oi / total_call_oi if total_call_oi > 0 else float('inf') if total_put_oi > 0 else 1.0

        if pcr_oi > 1.3: dominant_side = "Strong Put Writer Support (Bullish)"
        elif pcr_oi >= 1.0 and pcr_oi <= 1.3 : dominant_side = "Moderate Put Writer Support (Mildly Bullish)"
        elif pcr_oi < 0.7: dominant_side = "Strong Call Writer Resistance (Bearish)"
        elif pcr_oi < 1.0 and pcr_oi >= 0.7: dominant_side = "Moderate Call Writer Resistance (Mildly Bearish)"
        else: dominant_side = "Neutral / Balanced Writers"

        if total_oi == 0 : dominant_side = "Neutral (No OI)"

        logger.info(f"Writer Analysis: PCR(OI)={pcr_oi:.2f}, Dominant={dominant_side}, TotalCallOI={total_call_oi}, TotalPutOI={total_put_oi}, MaxCallOI={int(max_call_oi_value)}, MaxPutOI={int(max_put_oi_value)}, CallConc={call_concentration_pct:.1f}%, PutConc={put_concentration_pct:.1f}%")
        return {
            "call_writer_strength_percent": round(call_strength_percent,2),
            "put_writer_strength_percent": round(put_strength_percent,2),
            "dominant_side": dominant_side, "pcr_oi": round(pcr_oi,2),
            "max_call_oi_strike": max_call_strike_info['strike'] if max_call_strike_info is not None else None,
            "max_put_oi_strike": max_put_strike_info['strike'] if max_put_strike_info is not None else None,
            # Phase 1: OI Spatial Metrics
            "max_call_oi_value": int(max_call_oi_value),
            "max_put_oi_value": int(max_put_oi_value),
            "call_oi_concentration_pct": round(call_concentration_pct, 1),
            "put_oi_concentration_pct": round(put_concentration_pct, 1),
            "second_call_strike": second_call_strike,
            "second_call_oi_ratio": round(second_call_oi_ratio, 2),
            "second_put_strike": second_put_strike,
            "second_put_oi_ratio": round(second_put_oi_ratio, 2)
        }

    def calculate_rollover(self, current_oi_latest, next_oi_latest):
        try:
            current_oi = float(current_oi_latest) if current_oi_latest is not None else 0.0
            next_oi = float(next_oi_latest) if next_oi_latest is not None else 0.0
            current_oi = max(0, current_oi); next_oi = max(0, next_oi)
            total_series_oi = current_oi + next_oi
            if total_series_oi == 0: return 0.0
            return (next_oi / total_series_oi) * 100
        except (ValueError, TypeError) as e:
            logger.error(f"Error calculating rollover: {e}. Inputs: current={current_oi_latest}, next={next_oi_latest}")
            return 0.0

    def calculate_term_structure_slope(self, prices):
        if not prices or len(prices) < 2 or prices[0] is None or prices[1] is None: return []
        try:
            price0, price1 = float(prices[0]), float(prices[1])
            if price0 == 0: return []
            return [((price1 - price0) / price0) * 100]
        except (ValueError, TypeError) as e:
            logger.error(f"Error calculating term structure: {e}. Prices: {prices}")
            return []

    def calculate_rollover_quality_index(self, current_oi_change_percent, next_oi_change_percent,
                                         next_price_change_percent, current_avg_volume, next_avg_volume):
        try:
            next_oi_chg_perc = float(next_oi_change_percent) if next_oi_change_percent is not None else 0.0
            next_price_chg_perc = float(next_price_change_percent) if next_price_change_percent is not None else 0.0
            curr_vol = float(current_avg_volume) if current_avg_volume is not None and current_avg_volume > 0 else 1.0
            next_vol = float(next_avg_volume) if next_avg_volume is not None and next_avg_volume >= 0 else 0.0

            price_action_score = 0.0
            if next_oi_chg_perc > 2.0:
                if next_price_chg_perc > 0.2: price_action_score = 10
                elif next_price_chg_perc >= -0.2: price_action_score = 7
                else: price_action_score = 4
            elif next_oi_chg_perc < -2.0:
                if next_price_chg_perc < -0.2: price_action_score = 2
                elif next_price_chg_perc <= 0.2: price_action_score = 1
                else: price_action_score = 0
            else:
                if abs(next_price_chg_perc) < 0.2: price_action_score = 5
                elif next_price_chg_perc > 0.2 : price_action_score = 6
                else: price_action_score = 3

            volume_ratio = next_vol / curr_vol if curr_vol > 0 else 0.0
            volume_score = min(10, volume_ratio * 10)
            if next_vol == 0 and curr_vol > 0 : volume_score = 0

            rqi = max(0.0, min(10.0, (0.7 * price_action_score) + (0.3 * volume_score)))
            logger.debug(f"RQI Calc: next_oi_chg%={next_oi_chg_perc:.1f}, next_px_chg%={next_price_chg_perc:.1f}, curr_vol={curr_vol:.0f}, next_vol={next_vol:.0f} -> PxScore={price_action_score:.1f}, VolScore={volume_score:.1f} => RQI={rqi:.1f}")
            return round(rqi, 1)
        except (ValueError, TypeError) as e:
            logger.error(f"Error calculating RQI: {e}")
            return 0.0

    def calculate_roll_cost(self, current_price, next_price, spot_price):
        try:
            if not all(p is not None and isinstance(p, (int, float)) for p in [current_price, next_price, spot_price]):
                return None, None
            if spot_price == 0:
                return (next_price - current_price) if current_price is not None and next_price is not None else None, None

            roll_cost_points = next_price - current_price
            roll_cost_percent = (roll_cost_points / spot_price) * 100
            return roll_cost_points, roll_cost_percent
        except (ValueError, TypeError) as e:
            logger.error(f"Error calculating roll cost: {e}")
            return None, None

    def _get_baseline_stats(self, instrument_token, end_date_obj, contract_type="future"):
        if contract_type == "future":
            baseline_days_config = BASELINE_DAYS_FOR_FUTURES_ZSCORE
            min_trading_days_config = MIN_FUT_BASELINE_TRADING_DAYS_FOR_ZSCORE
            fetch_buffer_days = 45
        else: 
            baseline_days_config = BASELINE_DAYS_FOR_INDEX_ZSCORE
            min_trading_days_config = MIN_INDEX_BASELINE_TRADING_DAYS_FOR_ZSCORE
            fetch_buffer_days = 75

        from_date_baseline = end_date_obj - timedelta(days=baseline_days_config + fetch_buffer_days)
        to_date_baseline = end_date_obj - timedelta(days=1)

        df_baseline_raw = self.get_historical_data(instrument_token, from_date_baseline, to_date_baseline,
                                                 interval="day", cap_outliers_flag=True, contract_type=contract_type)

        if df_baseline_raw is None or df_baseline_raw.empty:
            logger.warning(f"No raw baseline data returned for Z-score for token {instrument_token} ({contract_type}).")
            return None
        if len(df_baseline_raw) < min_trading_days_config :
             logger.warning(f"Insufficient raw baseline data for Z-score for token {instrument_token} ({contract_type}) (fetched {len(df_baseline_raw)}, needed >{min_trading_days_config} raw days).")
             return None

        df_baseline = df_baseline_raw[df_baseline_raw['date'].dt.weekday < 5].copy()
        if len(df_baseline) < min_trading_days_config:
            logger.warning(f"Insufficient baseline trading days for Z-score for token {instrument_token} ({contract_type}) ({len(df_baseline)}, needed {min_trading_days_config} trading days).")
            return None

        if contract_type == "future" and 'oi' in df_baseline.columns:
            df_baseline['oi'] = pd.to_numeric(df_baseline['oi'], errors='coerce')
            df_baseline['oi_change'] = df_baseline['oi'].diff()
        else:
            df_baseline['oi_change'] = np.nan

        df_baseline['close'] = pd.to_numeric(df_baseline['close'], errors='coerce')
        df_baseline['price_change_pct'] = df_baseline['close'].pct_change() * 100

        df_baseline.dropna(subset=['price_change_pct'], inplace=True)
        if contract_type == "future":
             df_baseline.dropna(subset=['oi_change'], inplace=True)

        if df_baseline.empty or len(df_baseline) < (min_trading_days_config - 5):
            logger.warning(f"Not enough data for baseline stats after diff/dropna for {instrument_token} ({contract_type}) ({len(df_baseline)} days).")
            return None

        stats = {
            'mean_oi_change': df_baseline['oi_change'].mean() if 'oi_change' in df_baseline and df_baseline['oi_change'].notna().any() else np.nan,
            'std_oi_change': df_baseline['oi_change'].std() if 'oi_change' in df_baseline and df_baseline['oi_change'].notna().any() else np.nan,
            'mean_price_change_pct': df_baseline['price_change_pct'].mean() if df_baseline['price_change_pct'].notna().any() else np.nan,
            'std_price_change_pct': df_baseline['price_change_pct'].std() if df_baseline['price_change_pct'].notna().any() else np.nan
        }

        if contract_type == "future":
            if pd.isna(stats['mean_oi_change']):
                stats['mean_oi_change'] = None
                stats['std_oi_change'] = None
            elif pd.isna(stats['std_oi_change']) or stats['std_oi_change'] < 1e-6: stats['std_oi_change'] = 1e-6

        if pd.isna(stats['mean_price_change_pct']):
             stats['mean_price_change_pct'] = None
             stats['std_price_change_pct'] = None
        elif pd.isna(stats['std_price_change_pct']) or stats['std_price_change_pct'] < 1e-6: stats['std_price_change_pct'] = 1e-6

        logger.debug(f"Baseline stats for token {instrument_token} ({contract_type}, from {len(df_baseline)} days): {stats}")
        return stats

    def _compute_dynamic_z_thresholds(self, baseline_stats):
        try:
            if not baseline_stats:
                return Z_THRESH_OI, Z_THRESH_PRICE

            std_price_change_pct = baseline_stats.get('std_price_change_pct')
            std_oi_change = baseline_stats.get('std_oi_change')

            # Price z-threshold scaling based on realized daily return std (percent)
            price_std = None
            if std_price_change_pct is not None and not pd.isna(std_price_change_pct) and std_price_change_pct > 0:
                price_std = float(std_price_change_pct)

            # OI scaling based on OI change std; fallback to price vol if OI missing
            oi_std = None
            if std_oi_change is not None and not pd.isna(std_oi_change) and std_oi_change > 0:
                oi_std = float(std_oi_change)

            def clamp(val, lo, hi):
                return max(lo, min(hi, val))

            # Compute multipliers; if price_std unknown, keep baseline
            price_mult = clamp((price_std / DYN_Z_REF_DAILY_RETURN_PCT) if price_std else 1.0, DYN_Z_MULT_MIN, DYN_Z_MULT_MAX)

            # For OI, if oi_std unavailable, proxy with price multiplier
            oi_mult = price_mult if oi_std is None else clamp(1.0, DYN_Z_MULT_MIN, DYN_Z_MULT_MAX)

            # Apply scaling to base thresholds
            dyn_oi_thresh = Z_THRESH_OI * oi_mult
            dyn_price_thresh = Z_THRESH_PRICE * price_mult

            return dyn_oi_thresh, dyn_price_thresh
        except Exception:
            logger.debug("Falling back to static Z thresholds due to dynamic scaling error.")
            return Z_THRESH_OI, Z_THRESH_PRICE

    def _calculate_z_score(self, value, mean, std):
        if value is None or mean is None or std is None: return None
        if abs(std) < 1e-9 : return 0.0 # Avoid division by zero or very small std
        try:
            return (float(value) - float(mean)) / float(std)
        except (ValueError, TypeError):
            logger.warning(f"Could not calculate Z-score for value={value}, mean={mean}, std={std}")
            return None

    def analyze_trend_advanced(self, symbol, trading_days=7):
        try:
            current_time_obj = datetime.now(self.ist_timezone)
            logger.info(f"Starting ADVANCED analysis for {symbol} at {current_time_obj.strftime('%Y-%m-%d %H:%M:%S')} with Market Regime: {self.detected_market_regime}")

            spot_price_val = self.get_spot_price(symbol)
            if spot_price_val is None:
                logger.warning(f"Could not get spot price for {symbol}. Skipping analysis.")
                return None

            futures = self.get_futures_chain(symbol)
            current_fut = futures.get('current')
            next_fut = futures.get('next')
            if not current_fut:
                logger.warning(f"No current future contract found for {symbol}. Skipping.")
                return None

            # Liquidity Check (remains the same)
            min_liquidity_check_days = 20
            liquidity_fetch_calendar_days = int(min_liquidity_check_days * 1.8) + 30
            temp_end_date_obj = current_time_obj.date()
            temp_start_date_obj = temp_end_date_obj - timedelta(days=liquidity_fetch_calendar_days)
            current_fut_temp_data = self.get_historical_data(current_fut['instrument_token'], temp_start_date_obj, temp_end_date_obj,
                                                             interval="day", cap_outliers_flag=False, contract_type="future")
            if not current_fut_temp_data.empty and 'volume' in current_fut_temp_data and 'oi' in current_fut_temp_data and len(current_fut_temp_data) >= min_liquidity_check_days :
                current_fut_temp_data['volume'] = pd.to_numeric(current_fut_temp_data['volume'], errors='coerce')
                current_fut_temp_data['oi'] = pd.to_numeric(current_fut_temp_data['oi'], errors='coerce')
                avg_vol = current_fut_temp_data['volume'].dropna().tail(min_liquidity_check_days).mean()
                avg_oi = current_fut_temp_data['oi'].dropna().tail(min_liquidity_check_days).mean()
                if pd.isna(avg_vol) or pd.isna(avg_oi) or avg_vol < MIN_FUT_AVG_VOLUME or avg_oi < MIN_FUT_AVG_OI:
                    logger.info(f"{symbol} current future ({current_fut['tradingsymbol']}) fails liquidity (AvgVol: {avg_vol:.0f}, AvgOI: {avg_oi:.0f}). Skipping.")
                    return None
            else:
                logger.warning(f"Could not get sufficient temp data for liquidity check of {current_fut['tradingsymbol']}. Skipping.")
                return None

            baseline_end_date = current_time_obj.date()
            current_fut_baseline_stats = self._get_baseline_stats(current_fut['instrument_token'], baseline_end_date, contract_type="future")
            next_fut_baseline_stats = self._get_baseline_stats(next_fut['instrument_token'], baseline_end_date, contract_type="future") if next_fut else None

            analysis_period_calendar_days = int(trading_days * 1.8) + 20
            analysis_fetch_start_date = baseline_end_date - timedelta(days=analysis_period_calendar_days)
            analysis_fetch_end_date = baseline_end_date

            current_data_raw_df = self.get_historical_data(current_fut['instrument_token'], analysis_fetch_start_date, analysis_fetch_end_date,
                                                           interval="day", cap_outliers_flag=True, contract_type="future")
            current_hist_df = current_data_raw_df[current_data_raw_df['date'].dt.weekday < 5].tail(trading_days).copy() if not current_data_raw_df.empty else pd.DataFrame()

            next_hist_df = pd.DataFrame() # Initialize next_hist_df
            if next_fut:
                next_data_raw_df = self.get_historical_data(next_fut['instrument_token'], analysis_fetch_start_date, analysis_fetch_end_date,
                                                            interval="day", cap_outliers_flag=True, contract_type="future")
                next_hist_df = next_data_raw_df[next_data_raw_df['date'].dt.weekday < 5].tail(trading_days).copy() if not next_data_raw_df.empty else pd.DataFrame()


            if current_hist_df.empty or len(current_hist_df) < trading_days:
                logger.warning(f"Insufficient analysis data for {symbol} current fut ({len(current_hist_df)}/{trading_days} days).")
                return None
            
            if 'oi' not in current_hist_df.columns: # Should ideally not happen if data is fetched correctly
                logger.warning(f"'oi' column missing in current_hist_df for {symbol}. Cannot calculate OI metrics.")
                # Depending on strictness, you might return None or try to proceed without OI specific metrics
                current_hist_df['oi'] = np.nan # Add a NaN column to prevent further errors, though results will be impacted
            else:
                current_hist_df['oi'] = pd.to_numeric(current_hist_df['oi'], errors='coerce')


            analysis_start_date_actual = current_hist_df['date'].iloc[0].date()
            analysis_end_date_actual = current_hist_df['date'].iloc[-1].date()

            # Current month calculations (over analysis window `trading_days`)
            current_hist_df['open'] = pd.to_numeric(current_hist_df['open'], errors='coerce')
            current_hist_df['close'] = pd.to_numeric(current_hist_df['close'], errors='coerce')
            current_hist_df['volume'] = pd.to_numeric(current_hist_df['volume'], errors='coerce')
            current_hist_df['high'] = pd.to_numeric(current_hist_df['high'], errors='coerce')
            current_hist_df['low'] = pd.to_numeric(current_hist_df['low'], errors='coerce')
            
            current_oi_initial = current_hist_df['oi'].iloc[0] if pd.notna(current_hist_df['oi'].iloc[0]) else None
            current_oi_final = current_hist_df['oi'].iloc[-1] if pd.notna(current_hist_df['oi'].iloc[-1]) else None
            
            current_oi_period_change = (current_oi_final - current_oi_initial) if current_oi_final is not None and current_oi_initial is not None else 0.0
            current_oi_change_pct = (current_oi_period_change / current_oi_initial * 100) if current_oi_initial is not None and current_oi_initial != 0 else 0.0
            
            current_price_initial = current_hist_df['open'].iloc[0] if pd.notna(current_hist_df['open'].iloc[0]) else None
            current_price_final = current_hist_df['close'].iloc[-1] if pd.notna(current_hist_df['close'].iloc[-1]) else None
            current_price_period_change_pct = ((current_price_final - current_price_initial) / current_price_initial * 100) if current_price_initial is not None and current_price_initial != 0 and current_price_final is not None else 0.0
            
            # REALIZED VOLATILITY CALCULATION (for straddle strategy)
            # Calculate daily returns and volatility metrics
            current_hist_df['daily_return_pct'] = current_hist_df['close'].pct_change() * 100
            current_hist_df['daily_range_pct'] = ((current_hist_df['high'] - current_hist_df['low']) / current_hist_df['close']) * 100
            
            # Realized volatility (std dev of daily returns) - annualized
            daily_returns = current_hist_df['daily_return_pct'].dropna()
            if len(daily_returns) >= 3:
                current_realized_vol_daily_pct = daily_returns.std()  # Daily std dev
                current_realized_vol_annualized = current_realized_vol_daily_pct * np.sqrt(252)  # Annualized
                current_avg_abs_daily_move_pct = daily_returns.abs().mean()  # Average absolute daily move
                current_avg_daily_range_pct = current_hist_df['daily_range_pct'].dropna().mean()  # Avg high-low range
                current_max_single_day_move_pct = daily_returns.abs().max()  # Largest single-day move
                
                # HISTORICAL MAX MOVE DETECTION (breakeven breach risk)
                # Calculate max upswing and max drawdown over the window
                close_prices = current_hist_df['close'].dropna()
                if len(close_prices) >= 2:
                    current_max_upswing_pct = ((close_prices.max() / close_prices.min()) - 1) * 100
                    current_max_drawdown_pct = ((close_prices.min() / close_prices.max()) - 1) * 100
                    current_max_excursion_pct = max(current_max_upswing_pct, abs(current_max_drawdown_pct))
                else:
                    current_max_upswing_pct = None
                    current_max_drawdown_pct = None
                    current_max_excursion_pct = None
            else:
                current_realized_vol_daily_pct = None
                current_realized_vol_annualized = None
                current_avg_abs_daily_move_pct = None
                current_avg_daily_range_pct = None
                current_max_single_day_move_pct = None
                current_max_upswing_pct = None
                current_max_drawdown_pct = None
                current_max_excursion_pct = None
            
            current_oi_z, current_price_z = None, None
            avg_daily_oi_change_in_analysis_window = current_oi_period_change / len(current_hist_df) if len(current_hist_df) > 0 and current_oi_period_change is not None else 0.0

            if current_fut_baseline_stats:
                current_oi_z = self._calculate_z_score(avg_daily_oi_change_in_analysis_window, current_fut_baseline_stats.get('mean_oi_change'), current_fut_baseline_stats.get('std_oi_change'))
                avg_daily_price_change_pct = current_price_period_change_pct / len(current_hist_df) if len(current_hist_df) > 0 and current_price_period_change_pct is not None else 0.0
                current_price_z = self._calculate_z_score(avg_daily_price_change_pct, current_fut_baseline_stats.get('mean_price_change_pct'), current_fut_baseline_stats.get('std_price_change_pct'))
            
            current_latest_price = current_price_final
            current_latest_oi = current_oi_final
            current_avg_volume = current_hist_df['volume'].dropna().mean() if not current_hist_df['volume'].dropna().empty else 0.0

            # --- Existing OI Metrics (Calculated for current future) ---
            daily_avg_oi_change_val = avg_daily_oi_change_in_analysis_window
            daily_avg_oi_percent_change_val = (current_oi_change_pct / len(current_hist_df)) \
                if len(current_hist_df) > 0 and current_oi_change_pct is not None else None

            current_month_monthly_oi_change_val = None
            current_monthly_oi_percent_change_val = None
            num_trading_days_in_month_so_far = 0
            avg_daily_change_from_monthly_trend_val = None

            month_start_date_obj = analysis_fetch_end_date.replace(day=1)
            current_fut_monthly_data_df_raw = self.get_historical_data(
                current_fut['instrument_token'],
                month_start_date_obj,
                analysis_fetch_end_date, 
                interval="day",
                cap_outliers_flag=True, 
                contract_type="future"
            )

            if not current_fut_monthly_data_df_raw.empty and 'oi' in current_fut_monthly_data_df_raw.columns:
                current_fut_monthly_data_df = current_fut_monthly_data_df_raw[
                    current_fut_monthly_data_df_raw['date'].dt.weekday < 5
                ].copy()
                current_fut_monthly_data_df['oi'] = pd.to_numeric(current_fut_monthly_data_df['oi'], errors='coerce')

                if not current_fut_monthly_data_df.empty and len(current_fut_monthly_data_df) >= 1:
                    num_trading_days_in_month_so_far = len(current_fut_monthly_data_df)
                    oi_at_month_start = current_fut_monthly_data_df['oi'].iloc[0]
                    oi_at_month_end = current_fut_monthly_data_df['oi'].iloc[-1]

                    if pd.notna(oi_at_month_start) and pd.notna(oi_at_month_end):
                        current_month_monthly_oi_change_val = oi_at_month_end - oi_at_month_start
                        if pd.notna(oi_at_month_start) and oi_at_month_start != 0:
                            current_monthly_oi_percent_change_val = (current_month_monthly_oi_change_val / oi_at_month_start) * 100
                        
                        if num_trading_days_in_month_so_far > 0 :
                             avg_daily_change_from_monthly_trend_val = current_month_monthly_oi_change_val / num_trading_days_in_month_so_far


            todays_net_oi_change_val = None
            todays_net_oi_percent_change_val = None
            if len(current_hist_df) >= 2: 
                oi_today_in_window = current_hist_df['oi'].iloc[-1]
                oi_yesterday_in_window = current_hist_df['oi'].iloc[-2]
                if pd.notna(oi_today_in_window) and pd.notna(oi_yesterday_in_window):
                    todays_net_oi_change_val = oi_today_in_window - oi_yesterday_in_window
                    if pd.notna(oi_yesterday_in_window) and oi_yesterday_in_window != 0:
                        todays_net_oi_percent_change_val = (todays_net_oi_change_val / oi_yesterday_in_window) * 100
            elif len(current_hist_df) == 1 and pd.notna(current_hist_df['oi'].iloc[0]) and current_data_raw_df is not None and len(current_data_raw_df[current_data_raw_df['date'].dt.weekday < 5]) > 1:
                all_trading_days_df = current_data_raw_df[current_data_raw_df['date'].dt.weekday < 5].copy()
                all_trading_days_df['oi'] = pd.to_numeric(all_trading_days_df['oi'], errors='coerce') # Ensure numeric for calculation
                if len(all_trading_days_df) >=2:
                    oi_today_in_window = all_trading_days_df['oi'].iloc[-1] 
                    oi_yesterday_overall = all_trading_days_df['oi'].iloc[-2]
                    if pd.notna(oi_today_in_window) and pd.notna(oi_yesterday_overall):
                        todays_net_oi_change_val = oi_today_in_window - oi_yesterday_overall
                        if pd.notna(oi_yesterday_overall) and oi_yesterday_overall !=0:
                             todays_net_oi_percent_change_val = (todays_net_oi_change_val / oi_yesterday_overall) * 100


            todays_oi_vs_daily_avg_percent_val = None
            if pd.notna(todays_net_oi_change_val) and pd.notna(daily_avg_oi_change_val) and daily_avg_oi_change_val != 0:
                todays_oi_vs_daily_avg_percent_val = (todays_net_oi_change_val / daily_avg_oi_change_val) * 100

            todays_oi_vs_monthly_avg_percent_val = None
            if pd.notna(todays_net_oi_change_val) and pd.notna(avg_daily_change_from_monthly_trend_val) and avg_daily_change_from_monthly_trend_val != 0:
                todays_oi_vs_monthly_avg_percent_val = (todays_net_oi_change_val / avg_daily_change_from_monthly_trend_val) * 100
            
            # --- NUANCE COLUMNS: PRICE JOURNEY (Current Future) ---
            current_fut_series_lowest_close_val = None
            current_fut_is_low_protected_val = None
            current_fut_latest_close_vs_series_low_pct_val = None
            
            series_low_from_date = analysis_fetch_end_date - timedelta(days=SERIES_LOW_LOOKBACK_DAYS)

            if current_fut:
                logger.debug(f"Fetching series low data for current future {current_fut['tradingsymbol']} from {series_low_from_date} to {analysis_fetch_end_date}")
                current_fut_series_data_df = self.get_historical_data(
                    current_fut['instrument_token'],
                    series_low_from_date,
                    analysis_fetch_end_date,
                    interval="day",
                    cap_outliers_flag=False, 
                    contract_type="future"
                )
                if not current_fut_series_data_df.empty and 'close' in current_fut_series_data_df.columns and current_fut_series_data_df['close'].notna().any():
                    current_fut_series_data_df['close'] = pd.to_numeric(current_fut_series_data_df['close'], errors='coerce') # Ensure numeric
                    current_fut_series_lowest_close_val = current_fut_series_data_df['close'].min()
                    
                    if pd.notna(current_latest_price) and pd.notna(current_fut_series_lowest_close_val):
                        if current_latest_price > current_fut_series_lowest_close_val:
                            current_fut_is_low_protected_val = "Yes"
                        elif current_latest_price < current_fut_series_lowest_close_val:
                            current_fut_is_low_protected_val = "No"
                        else:
                            current_fut_is_low_protected_val = "At Low"
                        
                        if current_fut_series_lowest_close_val != 0: # Avoid division by zero
                            current_fut_latest_close_vs_series_low_pct_val = \
                                ((current_latest_price - current_fut_series_lowest_close_val) / abs(current_fut_series_lowest_close_val)) * 100
                else:
                    logger.debug(f"No series data or close prices for current future {current_fut['tradingsymbol']} to determine series low.")

            # --- MOVED NEXT MONTH CALCULATIONS (MAIN BLOCK) HERE ---
            next_oi_change_pct_for_sentiment, next_price_change_pct_for_sentiment = 0.0, 0.0
            next_oi_z_for_sentiment, next_price_z_for_sentiment = None, None
            # Initialize next_latest_price, next_latest_oi, next_avg_volume
            next_latest_price, next_latest_oi, next_avg_volume = None, None, 0.0
            # Initialize next month volatility metrics
            next_realized_vol_daily_pct = None
            next_realized_vol_annualized = None
            next_avg_abs_daily_move_pct = None
            next_avg_daily_range_pct = None
            next_max_single_day_move_pct = None

            if next_fut and not next_hist_df.empty and len(next_hist_df) == trading_days:
                if 'oi' not in next_hist_df.columns: # Safety check for next_hist_df
                    logger.warning(f"'oi' column missing in next_hist_df for {symbol}.")
                    next_hist_df['oi'] = np.nan
                else:
                    next_hist_df['oi'] = pd.to_numeric(next_hist_df['oi'], errors='coerce')

                next_hist_df['open'] = pd.to_numeric(next_hist_df['open'], errors='coerce')
                next_hist_df['close'] = pd.to_numeric(next_hist_df['close'], errors='coerce')
                next_hist_df['volume'] = pd.to_numeric(next_hist_df['volume'], errors='coerce')
                next_hist_df['high'] = pd.to_numeric(next_hist_df['high'], errors='coerce')
                next_hist_df['low'] = pd.to_numeric(next_hist_df['low'], errors='coerce')

                next_oi_initial = next_hist_df['oi'].iloc[0] if pd.notna(next_hist_df['oi'].iloc[0]) else None
                next_oi_final = next_hist_df['oi'].iloc[-1] if pd.notna(next_hist_df['oi'].iloc[-1]) else None
                next_oi_period_change = (next_oi_final - next_oi_initial) if next_oi_final is not None and next_oi_initial is not None else 0.0
                next_oi_change_pct_for_sentiment = (next_oi_period_change / next_oi_initial * 100) if next_oi_initial is not None and next_oi_initial != 0 else 0.0
                
                next_price_initial = next_hist_df['open'].iloc[0] if pd.notna(next_hist_df['open'].iloc[0]) else None
                _next_price_final_temp = next_hist_df['close'].iloc[-1] if pd.notna(next_hist_df['close'].iloc[-1]) else None
                next_latest_price = _next_price_final_temp # << THIS IS WHERE next_latest_price GETS ITS VALUE
                
                next_price_change_pct_for_sentiment = ((_next_price_final_temp - next_price_initial) / next_price_initial * 100) if next_price_initial is not None and next_price_initial != 0 and _next_price_final_temp is not None else 0.0
                
                # REALIZED VOLATILITY CALCULATION FOR NEXT MONTH (for straddle strategy)
                next_hist_df['daily_return_pct'] = next_hist_df['close'].pct_change() * 100
                next_hist_df['daily_range_pct'] = ((next_hist_df['high'] - next_hist_df['low']) / next_hist_df['close']) * 100
                
                # Realized volatility metrics for next month
                next_daily_returns = next_hist_df['daily_return_pct'].dropna()
                if len(next_daily_returns) >= 3:
                    next_realized_vol_daily_pct = next_daily_returns.std()
                    next_realized_vol_annualized = next_realized_vol_daily_pct * np.sqrt(252)
                    next_avg_abs_daily_move_pct = next_daily_returns.abs().mean()
                    next_avg_daily_range_pct = next_hist_df['daily_range_pct'].dropna().mean()
                    next_max_single_day_move_pct = next_daily_returns.abs().max()
                    
                    # HISTORICAL MAX MOVE DETECTION FOR NEXT MONTH
                    next_close_prices = next_hist_df['close'].dropna()
                    if len(next_close_prices) >= 2:
                        next_max_upswing_pct = ((next_close_prices.max() / next_close_prices.min()) - 1) * 100
                        next_max_drawdown_pct = ((next_close_prices.min() / next_close_prices.max()) - 1) * 100
                        next_max_excursion_pct = max(next_max_upswing_pct, abs(next_max_drawdown_pct))
                    else:
                        next_max_upswing_pct = None
                        next_max_drawdown_pct = None
                        next_max_excursion_pct = None
                else:
                    next_realized_vol_daily_pct = None
                    next_realized_vol_annualized = None
                    next_avg_abs_daily_move_pct = None
                    next_avg_daily_range_pct = None
                    next_max_single_day_move_pct = None
                    next_max_upswing_pct = None
                    next_max_drawdown_pct = None
                    next_max_excursion_pct = None
                
                if next_fut_baseline_stats:
                    avg_daily_next_oi_change = next_oi_period_change / len(next_hist_df) if len(next_hist_df) > 0 and next_oi_period_change is not None else 0.0
                    next_oi_z_for_sentiment = self._calculate_z_score(avg_daily_next_oi_change, next_fut_baseline_stats.get('mean_oi_change'), next_fut_baseline_stats.get('std_oi_change'))
                    avg_daily_next_price_change_pct = next_price_change_pct_for_sentiment / len(next_hist_df) if len(next_hist_df) > 0 and next_price_change_pct_for_sentiment is not None else 0.0
                    next_price_z_for_sentiment = self._calculate_z_score(avg_daily_next_price_change_pct, next_fut_baseline_stats.get('mean_price_change_pct'), next_fut_baseline_stats.get('std_price_change_pct'))
                
                next_latest_oi = next_oi_final
                next_avg_volume = next_hist_df['volume'].dropna().mean() if not next_hist_df['volume'].dropna().empty else 0.0
            # --- END OF MOVED NEXT MONTH CALCULATIONS (MAIN BLOCK) ---

            # --- NUANCE COLUMNS: PRICE JOURNEY (Next Future) ---
            # Initialize these before use
            next_fut_series_lowest_close_val = None
            next_fut_is_low_protected_val = None
            next_fut_latest_close_vs_series_low_pct_val = None

            if next_fut: # Check if next_fut itself exists
                # next_latest_price is now populated (or None if next_hist_df was invalid)
                logger.debug(f"Fetching series low data for next future {next_fut['tradingsymbol']} from {series_low_from_date} to {analysis_fetch_end_date}")
                next_fut_series_data_df = self.get_historical_data(
                    next_fut['instrument_token'],
                    series_low_from_date,
                    analysis_fetch_end_date,
                    interval="day",
                    cap_outliers_flag=False, 
                    contract_type="future"
                )
                if not next_fut_series_data_df.empty and 'close' in next_fut_series_data_df.columns and next_fut_series_data_df['close'].notna().any():
                    next_fut_series_data_df['close'] = pd.to_numeric(next_fut_series_data_df['close'], errors='coerce') # Ensure numeric
                    next_fut_series_lowest_close_val = next_fut_series_data_df['close'].min()
                    
                    if pd.notna(next_latest_price) and pd.notna(next_fut_series_lowest_close_val):
                        if next_latest_price > next_fut_series_lowest_close_val:
                            next_fut_is_low_protected_val = "Yes"
                        elif next_latest_price < next_fut_series_lowest_close_val:
                            next_fut_is_low_protected_val = "No"
                        else:
                            next_fut_is_low_protected_val = "At Low"

                        if next_fut_series_lowest_close_val != 0: # Avoid division by zero
                            next_fut_latest_close_vs_series_low_pct_val = \
                                ((next_latest_price - next_fut_series_lowest_close_val) / abs(next_fut_series_lowest_close_val)) * 100
                else:
                    logger.debug(f"No series data or close prices for next future {next_fut['tradingsymbol']} to determine series low.")
            # --- END OF NUANCE COLUMNS: PRICE JOURNEY (Next Future) ---

            # Rollover calculations and sentiment determination
            roll_cost_pts, roll_cost_pct = self.calculate_roll_cost(current_latest_price, next_latest_price, spot_price_val)
            term_structure = self.calculate_term_structure_slope([current_latest_price, next_latest_price])
            term_structure_slope_val = term_structure[0] if term_structure else None
            rqi_val = self.calculate_rollover_quality_index(current_oi_change_pct, next_oi_change_pct_for_sentiment, next_price_change_pct_for_sentiment, current_avg_volume, next_avg_volume)
            rollover_pct_val = self.calculate_rollover(current_latest_oi, next_latest_oi)

            roll_skew_val = None
            if all(v is not None for v in [next_oi_change_pct_for_sentiment, current_oi_change_pct, next_price_change_pct_for_sentiment, current_price_period_change_pct]):
                roll_skew_val = (next_oi_change_pct_for_sentiment - current_oi_change_pct) + \
                                (next_price_change_pct_for_sentiment - current_price_period_change_pct)
                logger.debug(f"{symbol} - Roll Skew calculated: {roll_skew_val:.2f}")

            # Compute dynamic thresholds from current contract realized vol
            curr_dyn_oi_thresh, curr_dyn_px_thresh = self._compute_dynamic_z_thresholds(current_fut_baseline_stats)
            sent_curr = self._determine_sentiment(
                current_oi_change_pct, current_price_period_change_pct,
                current_oi_z, current_price_z,
                oi_z_threshold=curr_dyn_oi_thresh, price_z_threshold=curr_dyn_px_thresh
            )
            strength_curr = self._get_sentiment_strength(sent_curr)
            # Next contract dynamic thresholds, if next baseline exists
            next_dyn_oi_thresh, next_dyn_px_thresh = (self._compute_dynamic_z_thresholds(next_fut_baseline_stats)
                                                     if next_fut_baseline_stats else (None, None))
            sent_next = self._determine_sentiment(
                next_oi_change_pct_for_sentiment, next_price_change_pct_for_sentiment,
                next_oi_z_for_sentiment, next_price_z_for_sentiment,
                oi_z_threshold=next_dyn_oi_thresh, price_z_threshold=next_dyn_px_thresh
            ) if (next_fut and not next_hist_df.empty and len(next_hist_df) == trading_days) else "Neutral"
            strength_next = self._get_sentiment_strength(sent_next)

            # Expiry related logic
            current_fut_expiry_date = pd.Timestamp(current_fut['expiry']).date()
            days_to_current_expiry = (current_fut_expiry_date - current_time_obj.date()).days
            action_option_expiry_date_obj, is_next_month_focused_trade = current_fut_expiry_date, False
            if days_to_current_expiry <= 5 and next_fut:
                next_fut_expiry_date_obj = pd.Timestamp(next_fut['expiry']).date()
                if next_fut_expiry_date_obj > current_fut_expiry_date:
                    action_option_expiry_date_obj = next_fut_expiry_date_obj
                    is_next_month_focused_trade = True
                    logger.info(f"Trade focus shifted to next month expiry {action_option_expiry_date_obj} for {symbol}.")
            effective_days_to_expiry_for_penalty = (pd.Timestamp(action_option_expiry_date_obj).date() - current_time_obj.date()).days

            # Option chain analysis
            option_chain_df = self.get_option_chain(symbol, [action_option_expiry_date_obj])
            filtered_options = self.filter_strikes(option_chain_df, spot_price_val)
            writer_analysis = self.analyze_writer_strength(filtered_options, spot_price_val)

            # Primary metrics for combined sentiment
            primary_oi_change_percent_val = next_oi_change_pct_for_sentiment if is_next_month_focused_trade else current_oi_change_pct
            primary_price_change_percent_val = next_price_change_pct_for_sentiment if is_next_month_focused_trade else current_price_period_change_pct # This var itself is not directly used in _combine_trends_refined anymore for inst break
            price_oi_ratio_primary_val = (primary_price_change_percent_val / (primary_oi_change_percent_val + 1e-6)) if primary_oi_change_percent_val is not None and primary_price_change_percent_val is not None and abs(primary_oi_change_percent_val) > 1e-6 else None
            primary_price_zscore_val = next_price_z_for_sentiment if is_next_month_focused_trade else current_price_z
            primary_oi_zscore_val = next_oi_z_for_sentiment if is_next_month_focused_trade else current_oi_z

            combined_sentiment, confidence = self._combine_trends_refined(
                symbol, sent_curr, strength_curr, current_oi_z, current_price_z,
                sent_next, strength_next, next_oi_z_for_sentiment, next_price_z_for_sentiment,
                effective_days_to_expiry_for_penalty,
                rqi_val, writer_analysis, self.detected_market_regime,
                is_next_month_focused_trade,
                term_structure_slope_val,
                price_oi_ratio_primary_val,
                primary_oi_change_percent_val,
                primary_price_zscore_val, 
                primary_oi_zscore_val,
                spot_price_val, 
                roll_skew_val 
            )
            action, option_details = self._determine_action(combined_sentiment, filtered_options, spot_price_val,
                                            confidence, self.detected_market_regime,
                                            rqi_val, rollover_pct_val, term_structure_slope_val) 
            
            # Calculate ATM strike from filtered options
            atm_strike_val = None
            if filtered_options is not None and not filtered_options.empty and 'strike' in filtered_options.columns:
                filtered_options_copy = filtered_options.copy()
                filtered_options_copy['strike'] = pd.to_numeric(filtered_options_copy['strike'], errors='coerce')
                filtered_options_copy.dropna(subset=['strike'], inplace=True)
                if not filtered_options_copy.empty:
                    atm_strike_candidates = filtered_options_copy.iloc[(filtered_options_copy['strike'] - spot_price_val).abs().argsort()]
                    if not atm_strike_candidates.empty:
                        atm_strike_val = atm_strike_candidates['strike'].iloc[0]

            result = {
                'timestamp': current_time_obj.strftime('%Y-%m-%d %H:%M:%S'), 'symbol': symbol,
                'detected_market_regime': self.detected_market_regime,
                'spot_price': spot_price_val,
                'combined_sentiment': combined_sentiment, 'confidence_percent': confidence,
                'action': action,
                'current_month_fut': current_fut['tradingsymbol'],
                'current_fut_price': current_latest_price,
                'current_fut_oi': round(current_latest_oi, 0) if current_latest_oi is not None else None,
                'current_fut_avg_volume': round(current_avg_volume, 0) if current_avg_volume is not None else None,
                'current_oi_change_percent': round(current_oi_change_pct,2) if current_oi_change_pct is not None else None,
                'current_price_change_percent': round(current_price_period_change_pct,2) if current_price_period_change_pct is not None else None,
                'current_oi_zscore': f"{current_oi_z:.2f}" if current_oi_z is not None else None,
                'current_price_zscore': f"{current_price_z:.2f}" if current_price_z is not None else None,
                
                # Realized Volatility Metrics (for straddle strategy)
                'current_realized_vol_daily_pct': round(current_realized_vol_daily_pct, 2) if current_realized_vol_daily_pct is not None else None,
                'current_realized_vol_annualized': round(current_realized_vol_annualized, 2) if current_realized_vol_annualized is not None else None,
                'current_avg_abs_daily_move_pct': round(current_avg_abs_daily_move_pct, 2) if current_avg_abs_daily_move_pct is not None else None,
                'current_avg_daily_range_pct': round(current_avg_daily_range_pct, 2) if current_avg_daily_range_pct is not None else None,
                'current_max_single_day_move_pct': round(current_max_single_day_move_pct, 2) if current_max_single_day_move_pct is not None else None,
                'current_max_upswing_pct': round(current_max_upswing_pct, 2) if current_max_upswing_pct is not None else None,
                'current_max_drawdown_pct': round(current_max_drawdown_pct, 2) if current_max_drawdown_pct is not None else None,
                'current_max_excursion_pct': round(current_max_excursion_pct, 2) if current_max_excursion_pct is not None else None,
                
                'daily_avg_oi_change': round(daily_avg_oi_change_val, 0) if daily_avg_oi_change_val is not None else None,
                'daily_avg_oi_percent_change': round(daily_avg_oi_percent_change_val, 2) if daily_avg_oi_percent_change_val is not None else None,
                'current_month_monthly_oi_change': round(current_month_monthly_oi_change_val, 0) if current_month_monthly_oi_change_val is not None else None,
                'current_monthly_oi_percent_change': round(current_monthly_oi_percent_change_val, 2) if current_monthly_oi_percent_change_val is not None else None,
                'todays_net_oi_change': round(todays_net_oi_change_val, 0) if todays_net_oi_change_val is not None else None,
                'todays_net_oi_percent_change': round(todays_net_oi_percent_change_val, 2) if todays_net_oi_percent_change_val is not None else None,
                'todays_oi_vs_daily_avg_percent': round(todays_oi_vs_daily_avg_percent_val, 2) if todays_oi_vs_daily_avg_percent_val is not None else None,
                'todays_oi_vs_monthly_percent': round(todays_oi_vs_monthly_avg_percent_val, 2) if todays_oi_vs_monthly_avg_percent_val is not None else None,
                
                'current_fut_series_lowest_close': round(current_fut_series_lowest_close_val, 2) if pd.notna(current_fut_series_lowest_close_val) else None,
                'current_fut_is_low_protected': current_fut_is_low_protected_val,
                'current_fut_latest_close_vs_series_low_pct': round(current_fut_latest_close_vs_series_low_pct_val, 2) if pd.notna(current_fut_latest_close_vs_series_low_pct_val) else None,
                'next_fut_series_lowest_close': round(next_fut_series_lowest_close_val, 2) if pd.notna(next_fut_series_lowest_close_val) else None,
                'next_fut_is_low_protected': next_fut_is_low_protected_val,
                'next_fut_latest_close_vs_series_low_pct': round(next_fut_latest_close_vs_series_low_pct_val, 2) if pd.notna(next_fut_latest_close_vs_series_low_pct_val) else None,

                'days_to_current_expiry': days_to_current_expiry,
                'current_fut_expiry': current_fut_expiry_date.strftime('%Y-%m-%d'),
                'next_month_fut': next_fut['tradingsymbol'] if next_fut else None,
                'next_fut_price': next_latest_price,
                'next_fut_oi': round(next_latest_oi, 0) if next_latest_oi is not None else None,
                'next_fut_avg_volume': round(next_avg_volume, 0) if next_avg_volume is not None else None,
                'next_oi_change_percent': round(next_oi_change_pct_for_sentiment,2) if next_oi_change_pct_for_sentiment is not None else None,
                'next_price_change_percent': round(next_price_change_pct_for_sentiment,2) if next_price_change_pct_for_sentiment is not None else None,
                'next_oi_zscore': f"{next_oi_z_for_sentiment:.2f}" if next_oi_z_for_sentiment is not None else None,
                'next_price_zscore': f"{next_price_z_for_sentiment:.2f}" if next_price_z_for_sentiment is not None else None,
                
                # Realized Volatility Metrics for Next Month
                'next_realized_vol_daily_pct': round(next_realized_vol_daily_pct, 2) if next_realized_vol_daily_pct is not None else None,
                'next_realized_vol_annualized': round(next_realized_vol_annualized, 2) if next_realized_vol_annualized is not None else None,
                'next_avg_abs_daily_move_pct': round(next_avg_abs_daily_move_pct, 2) if next_avg_abs_daily_move_pct is not None else None,
                'next_avg_daily_range_pct': round(next_avg_daily_range_pct, 2) if next_avg_daily_range_pct is not None else None,
                'next_max_single_day_move_pct': round(next_max_single_day_move_pct, 2) if next_max_single_day_move_pct is not None else None,
                'next_max_upswing_pct': round(next_max_upswing_pct, 2) if next_max_upswing_pct is not None else None,
                'next_max_drawdown_pct': round(next_max_drawdown_pct, 2) if next_max_drawdown_pct is not None else None,
                'next_max_excursion_pct': round(next_max_excursion_pct, 2) if next_max_excursion_pct is not None else None,
                
                'rollover_percent': round(rollover_pct_val,2) if rollover_pct_val is not None else None,
                'rollover_quality_index': rqi_val if rqi_val is not None else None,
                'roll_cost_points': roll_cost_pts if roll_cost_pts is not None else None,
                'roll_cost_percent_of_spot': round(roll_cost_pct,2) if roll_cost_pct is not None else None,
                'term_structure_slope_percent': round(term_structure_slope_val,2) if term_structure_slope_val is not None else None,
                'price_oi_ratio_primary': round(price_oi_ratio_primary_val, 4) if price_oi_ratio_primary_val is not None else None,
                'roll_skew': round(roll_skew_val, 2) if roll_skew_val is not None else None, 
                'sentiment_current': sent_curr, 'sentiment_next': sent_next,
                'analysis_start_date': analysis_start_date_actual.strftime('%Y-%m-%d'),
                'analysis_end_date': analysis_end_date_actual.strftime('%Y-%m-%d'),
                'analysis_trading_days': len(current_hist_df),
                'trade_option_expiry': action_option_expiry_date_obj.strftime('%Y-%m-%d'),
                
                # ATM strike reference
                'atm_strike': round(atm_strike_val, 2) if atm_strike_val is not None else None,
                
                # Selected option details (specific strike for trade)
                'selected_option_symbol': option_details.get('selected_option_symbol'),
                'selected_option_strike': round(option_details.get('selected_option_strike'), 2) if option_details.get('selected_option_strike') is not None else None,
                'selected_option_type': option_details.get('selected_option_type'),
                'selected_option_oi': round(option_details.get('selected_option_oi'), 0) if option_details.get('selected_option_oi') is not None else None,
                'selected_option_volume': round(option_details.get('selected_option_volume'), 0) if option_details.get('selected_option_volume') is not None else None,
                'selected_option_premium': round(option_details.get('selected_option_premium'), 2) if option_details.get('selected_option_premium') is not None else None
            }
            result.update({f"writer_{k.replace(' ', '_')}": v for k,v in writer_analysis.items()})
            logger.info(f"ADVANCED Analysis COMPLETE for {symbol} - Action: {action}")
            return result
        except Exception as e:
            logger.error(f"Major error in ADVANCED analysis for {symbol}: {traceback.format_exc()}")
            return None
    def run_trend_scan(self, trading_days=7):
        logger.info(f"Starting trend scan at {datetime.now(self.ist_timezone).strftime('%Y-%m-%d %H:%M:%S')} under detected regime: {self.detected_market_regime}")

        symbols = self.read_symbols()
        if not symbols:
            logger.error("No symbols to process. Exiting scan.")
            return

        self.results = []
        processed_symbols_in_run = set()
        for symbol_name in symbols:
            symbol_name = str(symbol_name).strip().upper()
            if not symbol_name: continue
            if symbol_name in processed_symbols_in_run:
                logger.info(f"Skipping duplicate symbol in input list: {symbol_name}")
                continue
            try:
                analysis_result = self.analyze_trend_advanced(symbol_name, trading_days=trading_days)
                if analysis_result is not None:
                    self.results.append(analysis_result)
                else:
                    logger.warning(f"No analysis result for {symbol_name} from advanced analysis.")
                processed_symbols_in_run.add(symbol_name)
            except kiteconnect.exceptions.TokenException as te:
                logger.critical(f"TokenException encountered for {symbol_name}. Halting further processing. {te}")
                if self.results: self.save_results()
                raise
            except Exception as e:
                logger.error(f"CRITICAL Error processing {symbol_name}: {traceback.format_exc()}")

        if self.results: self.save_results()
        else: logger.info("No results generated in this run to save.")

    def save_results(self):
        if not self.results:
            logger.info("No results to save.")
            return
        valid_results = [r for r in self.results if isinstance(r, dict)]
        if not valid_results:
            logger.info("No valid dictionary results to save.")
            return

        df = pd.DataFrame(valid_results)
        if 'timestamp' in df.columns:
             try:
                df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce').dt.strftime('%Y-%m-%d %H:%M:%S')
             except AttributeError:
                logger.debug("Timestamp column already string or unconvertible, skipping strftime.")
             except Exception as e:
                logger.error(f"Error formatting 'timestamp' column: {e}")

        run_ts_str = datetime.now(self.ist_timezone).strftime('%Y%m%d_%H%M%S')
        output_file = f"trend_results_adaptive_v10_nuance_{run_ts_str}.csv" 
        try:
            core_cols = ['timestamp', 'symbol', 'detected_market_regime', 'spot_price', 'combined_sentiment', 'confidence_percent', 'action', 'trade_option_expiry']
            fut_cols = ['current_month_fut', 'current_fut_price', 'current_fut_oi', 'current_fut_avg_volume', 'current_oi_change_percent', 'current_price_change_percent', 'current_oi_zscore', 'current_price_zscore', 'days_to_current_expiry', 'current_fut_expiry']
            
            oi_detail_cols = [
                'daily_avg_oi_change', 'daily_avg_oi_percent_change', 
                'current_month_monthly_oi_change', 'current_monthly_oi_percent_change',
                'todays_net_oi_change', 'todays_net_oi_percent_change',
                'todays_oi_vs_daily_avg_percent', 'todays_oi_vs_monthly_percent'
            ]
            
            # --- NEW NUANCE PRICE JOURNEY COLUMN LIST ---
            price_journey_nuance_cols = [
                'current_fut_series_lowest_close', 'current_fut_is_low_protected', 'current_fut_latest_close_vs_series_low_pct',
                'next_fut_series_lowest_close', 'next_fut_is_low_protected', 'next_fut_latest_close_vs_series_low_pct'
            ]
            # --- END OF NEW NUANCE PRICE JOURNEY COLUMN LIST ---

            next_fut_cols = ['next_month_fut', 'next_fut_price', 'next_fut_oi', 'next_fut_avg_volume', 'next_oi_change_percent', 'next_price_change_percent', 'next_oi_zscore', 'next_price_zscore']
            roll_cols = ['rollover_percent', 'rollover_quality_index', 'roll_cost_points', 'roll_cost_percent_of_spot', 'term_structure_slope_percent', 'price_oi_ratio_primary', 'roll_skew']
            
            # --- NEW OPTION DETAILS COLUMNS ---
            option_cols = [
                'atm_strike',
                'selected_option_symbol', 'selected_option_strike', 'selected_option_type',
                'selected_option_oi', 'selected_option_volume', 'selected_option_premium'
            ]
            # --- END OF NEW OPTION DETAILS COLUMNS ---
            
            writer_cols = sorted([col for col in df.columns if col.startswith('writer_')])
            analysis_info_cols = ['analysis_start_date', 'analysis_end_date', 'analysis_trading_days']

            ordered_cols = []
            for col_list in [core_cols, fut_cols, oi_detail_cols, price_journey_nuance_cols, next_fut_cols, roll_cols, option_cols, writer_cols, analysis_info_cols]:
                for col in col_list:
                    if col in df.columns and col not in ordered_cols:
                        ordered_cols.append(col)
            remaining_cols = sorted([col for col in df.columns if col not in ordered_cols])
            final_column_order = ordered_cols + remaining_cols

            df = df[final_column_order]

            df.to_csv(output_file, index=False, float_format='%.2f')
            logger.info(f"Trend results saved to {output_file} with {len(df)} rows.")
        except Exception as e:
            logger.error(f"Error saving results to {output_file}: {traceback.format_exc()}")

def main():
    API_KEY = "3bi2yh8g830vq3y6" # Replace with your actual API key
    ACCESS_TOKEN = "YitEzaTwOIBQGUcxii2baV03hfLwsloR" # Replace with your actual access token

    TRADING_DAYS_FOR_SCAN_ANALYSIS =  5
    logger.info(f"Script will use an analysis window of {TRADING_DAYS_FOR_SCAN_ANALYSIS} trading days.")

    if API_KEY == "YOUR_API_KEY" or ACCESS_TOKEN == "YOUR_ACCESS_TOKEN":
        logger.error("API_KEY or ACCESS_TOKEN not set. Update in main().")
        print("ERROR: API_KEY or ACCESS_TOKEN not set. Please update them in the script.")
        return

    input_csv_file = "data/FNOStock.csv"
    import os
    data_dir = "data"
    if not os.path.exists(data_dir):
        try:
            os.makedirs(data_dir)
            logger.info(f"Created directory: {data_dir}")
        except Exception as e_dir:
            logger.error(f"Could not create directory {data_dir}: {e_dir}")
            return

    if not os.path.exists(input_csv_file):
        logger.warning(f"Input CSV not found: {input_csv_file}. Creating a dummy file with a few symbols.")
        try:
            with open(input_csv_file, 'w') as f:
                f.write("Symbol\nRELIANCE\nINFY\nSBIN\nTCS\nICICIBANK\nAXISBANK\nAARTIIND\nABB\nABCAPITAL\nCDSL\nICICIPRULI\nADANIENT\nCUMMINSIND\nPRESTIGE\n")
            logger.info(f"Created dummy input CSV: {input_csv_file}.")
        except Exception as e_csv:
            logger.error(f"Could not create dummy CSV {input_csv_file}: {e_csv}")
            return

    try:
        actual_api_key = API_KEY 
        actual_access_token = ACCESS_TOKEN
        
        if actual_api_key == "YOUR_API_KEY" or actual_access_token == "YOUR_ACCESS_TOKEN":
            logger.error("Critical: API_KEY or ACCESS_TOKEN placeholders detected in main execution block. Exiting.")
            print("ERROR: Please replace YOUR_API_KEY and YOUR_ACCESS_TOKEN with actual credentials.")
            return
            
        scanner = TrendScanner(api_key=actual_api_key, access_token=actual_access_token, input_csv=input_csv_file)
        scanner.run_trend_scan(trading_days=TRADING_DAYS_FOR_SCAN_ANALYSIS)
    except kiteconnect.exceptions.TokenException as te:
        logger.critical(f"Kite Connect Token Exception: {te}. Please check your API key and access token. It might be expired or invalid.")
        print(f"A critical Kite Connect Token error occurred: {te}. Ensure your access token is valid and not expired.")
    except kiteconnect.exceptions.NetworkException as ne:
        logger.critical(f"Kite Connect Network Exception: {ne}. Check your internet connection and Kite API status.")
        print(f"A Kite Connect Network error occurred: {ne}. Please check your internet connection.")
    except ValueError as ve:
        logger.critical(f"ValueError during initialization or processing: {ve}")
        print(f"A critical ValueError occurred: {ve}")
    except Exception as e:
        logger.critical(f"Unhandled exception in main: {traceback.format_exc()}")
        print(f"A critical error occurred: {e}")

if __name__ == "__main__":
    main()