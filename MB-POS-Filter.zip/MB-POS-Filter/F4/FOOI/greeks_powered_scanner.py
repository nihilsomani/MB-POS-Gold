"""
GREEKS-POWERED SCANNER
Uses actual Greeks from delta_strangle_scanner output

Core Metrics (ALL implemented):
1. OI Change - From trend_results
2. Price Change - From trend_results  
3. PCR - From strangles CSV
4. IV Rank - From strangles CSV
5. Greeks - Delta, Gamma, Theta, Vega from strangles CSV
"""

import pandas as pd
import glob
from datetime import datetime

class GreeksPoweredScanner:
    """
    Combines trend data with Greeks data for complete analysis
    """
    
    def __init__(self, trend_csv=None, greeks_csv=None):
        # Load trend data (OI, Price changes)
        if trend_csv is None:
            files = glob.glob("trend_results_adaptive_v10_nuance_*.csv")
            trend_csv = max(files) if files else None
        
        if trend_csv:
            self.trend_df = pd.read_csv(trend_csv)
            print(f"✅ Loaded {len(self.trend_df)} stocks from trend data")
            print(f"   File: {trend_csv}")
            
            # Validation: Show sample data
            if len(self.trend_df) > 0 and 'AUBANK' in self.trend_df['symbol'].values:
                sample = self.trend_df[self.trend_df['symbol']=='AUBANK'].iloc[0]
                print(f"   Sample (AUBANK): Today OI={sample['current_oi_change_percent']:.2f}%, Price={sample['current_price_change_percent']:.2f}%, PCR={sample['writer_pcr_oi']:.2f}")
        else:
            print("❌ No trend data found")
            self.trend_df = pd.DataFrame()
        
        # Load Greeks data
        if greeks_csv is None:
            files = glob.glob("kite_equal_delta_strangles_*.csv")
            greeks_csv = max(files) if files else None
        
        if greeks_csv:
            self.greeks_df = pd.read_csv(greeks_csv)
            print(f"✅ Loaded {len(self.greeks_df)} stocks with Greeks data")
            print(f"   File: {greeks_csv}")
            
            # Validation: Show sample data
            if len(self.greeks_df) > 0 and 'AUBANK' in self.greeks_df['symbol'].values:
                sample = self.greeks_df[self.greeks_df['symbol']=='AUBANK'].iloc[0]
                print(f"   Sample (AUBANK): PCR={sample['pcr']:.2f}, IV Rank={sample['iv_percentile']:.0f}%, ATM IV={sample['atm_iv']:.1f}%")
            print()
        else:
            print("❌ No Greeks data found")
            self.greeks_df = pd.DataFrame()
    
    def analyze_directional(self):
        """
        Directional trades using OI + Price + Greeks context
        
        SCORING SYSTEM (max 100 points):
        - OI 7-Day Trend: 30 points (reduced from 40; already smoothed by 7-day lookback)
        - Price Alignment: 30 points (confirmation/divergence detection)
        - PCR Sentiment: 20 points (option writer positioning)
        - IV Rank: 10 points (strategy selection: options vs futures)
        
        NOTE: OI data from OITrendScanner is a 7-day lookback, not single-day
        This inherently reduces noise compared to daily OI spikes.
        
        THRESHOLDS:
        - >= 50 points: STRONG signal (2% position)
        - >= 30 points: Regular signal (1% position)
        - < 30 points: Filtered out
        """
        if self.trend_df.empty:
            return []
        
        results = []
        
        # Merge trend with Greeks for IV/PCR data
        merged = self.trend_df.merge(
            self.greeks_df[['symbol', 'atm_iv', 'iv_percentile', 'pcr']],
            on='symbol',
            how='left'
        )
        
        for _, row in merged.iterrows():
            score = 0
            signals = []
            
            # METRIC 1: 7-Day OI Trend (30 points max, reduced from 40)
            # NOTE: current_oi_change_percent from OITrendScanner is ALREADY a 7-day lookback
            # So this is NOT single-day noise, but a weekly trend
            oi_7d = row.get('current_oi_change_percent', 0)
            oi_7d = oi_7d if pd.notna(oi_7d) else 0
            
            # Smoother scoring to avoid cliff effects
            if abs(oi_7d) >= 20:
                oi_score = 30 if oi_7d > 0 else -30
                signals.append(f"🔥 MASSIVE OI (7D): {oi_7d:+.1f}%")
            elif abs(oi_7d) >= 12:
                oi_score = 22 if oi_7d > 0 else -22
                signals.append(f"✓✓ Strong OI (7D): {oi_7d:+.1f}%")
            elif abs(oi_7d) >= 6:
                oi_score = 14 if oi_7d > 0 else -14
                signals.append(f"✓ Decent OI (7D): {oi_7d:+.1f}%")
            elif abs(oi_7d) >= 3:
                oi_score = 7 if oi_7d > 0 else -7
                signals.append(f"~ Mild OI (7D): {oi_7d:+.1f}%")
            else:
                oi_score = 0
            
            score += oi_score
            
            # METRIC 2: Price + Divergence Detection (30 points)
            price_chg = row.get('current_price_change_percent', 0)
            price_chg = price_chg if pd.notna(price_chg) else 0
            
            aligned = (oi_7d * price_chg) > 0  # Same sign
            
            # CASE 1: Aligned (momentum/confirmation)
            if aligned and abs(price_chg) >= 2:
                score += 30 if price_chg > 0 else -30
                signals.append(f"✓✓ ALIGNED: Price {price_chg:+.1f}% confirms OI {oi_7d:+.1f}%")
            
            # CASE 2: Strong Divergence (reversal opportunity) 
            elif not aligned and abs(oi_7d) >= 10 and abs(price_chg) >= 2:
                # Bullish Divergence: +OI but -Price = Accumulation
                if oi_7d > 10 and price_chg < -2:
                    score += 20  # OPPORTUNITY
                    signals.append(f"🔥 BULLISH DIVERGENCE: OI +{oi_7d:.1f}% but Price {price_chg:.1f}% (accumulation!)")
                # Bearish Divergence: -OI but +Price = Distribution  
                elif oi_7d < -10 and price_chg > 2:
                    score -= 20  # SHORT OPPORTUNITY
                    signals.append(f"🔥 BEARISH DIVERGENCE: OI {oi_7d:.1f}% but Price +{price_chg:.1f}% (distribution!)")
                # Mixed strong divergence (unclear)
                else:
                    score -= 10
                    signals.append(f"⚠️ Mixed divergence: OI {oi_7d:+.1f}%, Price {price_chg:+.1f}%")
            
            # CASE 3: Weak Divergence (no conviction)
            elif not aligned and abs(price_chg) >= 1:
                score -= 15
                signals.append(f"✗ WEAK DIVERGENCE: OI {oi_7d:+.1f}%, Price {price_chg:+.1f}% (no conviction)")
            
            # METRIC 3: PCR (20 points) - Sentiment confirmation
            # PCR > 1.2 = Bullish (more puts = put writers support)
            # PCR < 0.7 = Bearish (more calls = call writers resist)
            pcr = row.get('pcr', 1.0)
            pcr = pcr if pd.notna(pcr) else 1.0
            
            if score > 0:  # Building LONG position
                if pcr > 1.2:  # Bullish PCR supports long
                    score += 20
                    signals.append(f"✓✓ Bullish PCR: {pcr:.2f} (supports long)")
                elif pcr < 0.7:  # Bearish PCR contradicts long
                    score -= 15
                    signals.append(f"✗ Bearish PCR: {pcr:.2f} (contradicts long)")
            
            elif score < 0:  # Building SHORT position
                if pcr < 0.7:  # Bearish PCR supports short
                    score -= 20  # Make MORE negative (strengthen short)
                    signals.append(f"✓✓ Bearish PCR: {pcr:.2f} (supports short)")
                elif pcr > 1.2:  # Bullish PCR contradicts short
                    score += 15  # Make LESS negative (weaken short)
                    signals.append(f"✗ Bullish PCR: {pcr:.2f} (contradicts short)")
            
            # METRIC 4: IV Rank (10 points) - Strategy selection
            # LOW IV = Good for BUYING options (cheap premium + vega tailwind)
            # HIGH IV = Bad for BUYING options (expensive premium + vega headwind)
            iv_rank = row.get('iv_percentile', 50)
            iv_rank = iv_rank if pd.notna(iv_rank) else 50
            
            instrument = "OPTIONS"
            if iv_rank >= 70:
                # Options too expensive - use futures to avoid premium
                instrument = "FUTURES"
                signals.append(f"⚠️ High IV {iv_rank:.0f}% - options EXPENSIVE, use FUTURES")
            elif iv_rank <= 30:
                # Options cheap - prefer options for leverage + vega profit
                score += 10
                instrument = "OPTIONS"
                signals.append(f"✓✓ Low IV {iv_rank:.0f}% - options CHEAP, use OPTIONS (vega tailwind!)")
            else:
                signals.append(f"~ Moderate IV {iv_rank:.0f}% - either options or futures OK")
            
            # Determine action
            if abs(score) >= 50:
                action = "STRONG BUY" if score > 0 else "STRONG SHORT"
                position_size = 2.0
            elif abs(score) >= 30:
                action = "BUY" if score > 0 else "SHORT"
                position_size = 1.0
            else:
                continue  # Skip weak signals
            
            # Calculate delta exposure from Greeks data if available
            delta_exposure = None
            delta_value = None
            
            if not self.greeks_df.empty:
                greeks_row = self.greeks_df[self.greeks_df['symbol'] == row['symbol']]
                if not greeks_row.empty:
                    greeks_row = greeks_row.iloc[0]
                    spot = greeks_row['spot']
                    
                    if instrument == "FUTURES":
                        # Futures delta = 1.0
                        delta_value = 1.0
                        delta_exposure = spot * delta_value
                    elif instrument == "OPTIONS":
                        # Use actual delta from Greeks
                        if score > 0:  # CALL options
                            delta_value = greeks_row['ce_delta']  # ~0.5 for ATM
                            delta_exposure = spot * delta_value
                        else:  # PUT options
                            delta_value = abs(greeks_row['pe_delta'])  # ~0.5 for ATM
                            delta_exposure = spot * delta_value
            
            results.append({
                'symbol': row['symbol'],
                'score': score,
                'action': action,
                'position_size': f"{position_size}%",
                'instrument': instrument,
                'delta': f"{delta_value:.3f}" if delta_value else "N/A",
                'delta_exposure': f"₹{delta_exposure:.0f}" if delta_exposure else "N/A",
                'oi_7d': oi_7d,
                'price_chg': price_chg,
                'pcr': pcr,
                'iv_rank': iv_rank,
                'signals': signals
            })
        
        return sorted(results, key=lambda x: abs(x['score']), reverse=True)
    
    def analyze_straddles(self, debug=False):
        """Straddle analysis using Greeks + IV"""
        if self.greeks_df.empty:
            return []
        
        results = []
        
        # Merge with trend for OI stability check
        merged = self.greeks_df.merge(
            self.trend_df[['symbol', 'current_oi_change_percent', 'current_price_change_percent']],
            on='symbol',
            how='left'
        )
        
        # Tracking stats for debugging
        filter_stats = {
            'total': len(merged),
            'failed_iv_rank': 0,
            'failed_risk_score': 0,
            'failed_dte': 0,
            'failed_score_threshold': 0,
            'passed': 0
        }
        failed_details = []
        
        for _, row in merged.iterrows():
            score = 50
            signals = []
            symbol = row['symbol']
            
            # CRITICAL FILTERS FIRST
            iv_rank = row['iv_percentile']
            risk_score = row['overall_risk_score']
            dte = row['dte_days']
            
            # Track failures for debugging
            failure_reasons = []
            
            # Hard blocks
            if iv_rank < 40:
                filter_stats['failed_iv_rank'] += 1
                failure_reasons.append(f"IV Rank {iv_rank:.0f}% < 40%")
                if debug:
                    failed_details.append({'symbol': symbol, 'reason': f"Low IV: {iv_rank:.0f}%", 'iv_rank': iv_rank, 'risk': risk_score, 'dte': dte})
                continue  # Skip low IV
            if risk_score >= 7:
                filter_stats['failed_risk_score'] += 1
                failure_reasons.append(f"Risk Score {risk_score:.1f} >= 7")
                if debug:
                    failed_details.append({'symbol': symbol, 'reason': f"High Risk: {risk_score:.1f}/10", 'iv_rank': iv_rank, 'risk': risk_score, 'dte': dte})
                continue  # Skip high risk
            if dte < 7 or dte > 35:
                filter_stats['failed_dte'] += 1
                failure_reasons.append(f"DTE {dte:.0f} days (need 7-35)")
                if debug:
                    failed_details.append({'symbol': symbol, 'reason': f"Bad DTE: {dte:.0f} days", 'iv_rank': iv_rank, 'risk': risk_score, 'dte': dte})
                continue  # Skip gamma risk / slow decay
            
            # METRIC 1: IV Rank (40 points)
            if iv_rank >= 70:
                score += 40
                signals.append(f"✓✓✓ EXCELLENT IV: {row['atm_iv']:.1f}% (rank {iv_rank:.0f})")
            elif iv_rank >= 60:
                score += 30
                signals.append(f"✓✓ Great IV: {row['atm_iv']:.1f}% (rank {iv_rank:.0f})")
            elif iv_rank >= 50:
                score += 20
                signals.append(f"✓ Good IV: {row['atm_iv']:.1f}% (rank {iv_rank:.0f})")
            
            # METRIC 2: Theta Collection (25 points)
            net_theta_day = row['net_theta_per_trading_day']  # Use original sign from CSV
            credit = row['total_credit']
            theta_as_pct_of_credit = (abs(net_theta_day) / credit * 100) if credit > 0 else 0
            
            # For SHORT straddles: Positive theta = collect decay (good), Negative theta = pay decay (bad)
            if net_theta_day > 0 and theta_as_pct_of_credit > 8:  # >8% daily decay collection
                score += 25
                signals.append(f"✓✓✓ EXCELLENT Theta: ₹{net_theta_day:.0f}/day ({theta_as_pct_of_credit:.1f}% of credit)")
            elif net_theta_day > 0 and theta_as_pct_of_credit > 5:
                score += 15
                signals.append(f"✓✓ Good Theta: ₹{net_theta_day:.0f}/day")
            elif net_theta_day < 0:  # Negative theta = you pay decay (bad for short straddles)
                score -= 25
                signals.append(f"✗✗✗ BAD Theta: ₹{abs(net_theta_day):.0f}/day (you PAY decay!)")
            
            # METRIC 3: Gamma Risk (20 points)
            ce_gamma = row['ce_gamma']
            pe_gamma = row['pe_gamma']
            avg_gamma = (ce_gamma + pe_gamma) / 2
            
            # Lower gamma = safer
            if avg_gamma < 0.002:
                score += 20
                signals.append(f"✓✓ Low Gamma: {avg_gamma:.4f} (safe)")
            elif avg_gamma < 0.005:
                score += 10
                signals.append(f"✓ Manageable Gamma: {avg_gamma:.4f}")
            else:
                score -= 10
                signals.append(f"⚠️ High Gamma: {avg_gamma:.4f} (risky)")
            
            # METRIC 4: Vega Risk (20 points) - IV exposure check
            net_vega = row['net_vega']  # Use the net_vega directly from CSV
            
            # Check IV trend direction (from options screener if available)
            # When selling straddles, you want HIGH IV that's STABLE or FALLING
            iv_percentile = row['iv_percentile']
            
            # For SHORT straddles: Negative vega = profit from IV drop (good), Positive vega = loss from IV drop (bad)
            if net_vega < 0 and iv_percentile >= 60:
                # Good: High IV + negative vega = profit from IV crush
                vega_bonus = min(20, int((iv_percentile - 50) / 2))
                score += vega_bonus
                signals.append(f"✓✓ Vega profit: IV rank {iv_percentile:.0f}% (vega {net_vega:.2f})")
            elif net_vega < 0 and iv_percentile >= 50:
                score += 5
                signals.append(f"✓ Moderate IV: {iv_percentile:.0f}% (vega {net_vega:.2f})")
            elif net_vega > 0:
                # Bad: Positive vega = you lose when IV drops (and IV is likely to drop from high percentile)
                score -= 20
                signals.append(f"✗✗✗ BAD Vega: {net_vega:.2f} (you LOSE when IV drops!)")
            elif iv_percentile < 40:
                score -= 20
                signals.append(f"✗✗ LOW IV risk: Rank {iv_percentile:.0f}% + vega {net_vega:.2f}")
            
            # METRIC 5: PCR Balance (15 points)
            pcr = row['pcr']
            pcr_distance = abs(pcr - 1.0)
            
            if pcr_distance < 0.15:
                score += 15
                signals.append(f"✓✓ Balanced PCR: {pcr:.2f}")
            elif pcr_distance < 0.3:
                score += 8
                signals.append(f"✓ Decent PCR: {pcr:.2f}")
            
            # METRIC 6: OI/Price Stability (10 points each)
            today_oi = row.get('current_oi_change_percent', 0)
            today_oi = abs(today_oi) if pd.notna(today_oi) else 0
            
            if today_oi < 3:
                score += 10
                signals.append(f"✓ Stable OI: {today_oi:.1f}%")
            elif today_oi > 8:
                score -= 15
            
            price_chg = row.get('current_price_change_percent', 0)
            price_chg = abs(price_chg) if pd.notna(price_chg) else 0
            
            if price_chg < 2:
                score += 10
                signals.append(f"✓ Stable price: {price_chg:.1f}%")
            elif price_chg > 4:
                score -= 15
            
            # Calculate RoM (Return on Margin)
            rom = row['rom_pct']
            
            # Determine action
            if score >= 90:
                action = "STRONG SELL STRADDLE"
                position_size = "2%"
            elif score >= 75:
                action = "SELL STRADDLE"
                position_size = "1.5%"
            elif score >= 60:
                action = "WATCH"
                position_size = "1%"
            else:
                filter_stats['failed_score_threshold'] += 1
                if debug:
                    failed_details.append({'symbol': symbol, 'reason': f"Score {score:.0f} < 60", 'score': score, 'iv_rank': iv_rank, 'risk': risk_score, 'dte': dte})
                continue
            
            # Calculate net delta (should be near-zero for straddles)
            ce_delta = row['ce_delta']
            pe_delta = row['pe_delta']
            net_delta = ce_delta + pe_delta  # Should be ~0 for ATM straddles
            
            filter_stats['passed'] += 1
            
            results.append({
                'symbol': row['symbol'],
                'score': score,
                'action': action,
                'position_size': position_size,
                'atm_iv': row['atm_iv'],
                'iv_rank': iv_rank,
                'pcr': pcr,
                'net_delta': net_delta,
                'net_theta_day': net_theta_day,
                'avg_gamma': avg_gamma,
                'credit': credit,
                'rom': rom,
                'dte': dte,
                'be_upper': row['be_upper'],
                'be_lower': row['be_lower'],
                'risk_score': risk_score,
                'signals': signals
            })
        
        # Print debug info if enabled
        if debug:
            print(f"\n{'='*80}")
            print("🔍 STRADDLE FILTER DIAGNOSTICS")
            print("="*80)
            print(f"Total stocks analyzed: {filter_stats['total']}")
            print(f"✅ Passed all filters: {filter_stats['passed']}")
            print(f"❌ Failed IV Rank (<40%): {filter_stats['failed_iv_rank']}")
            print(f"❌ Failed Risk Score (≥7): {filter_stats['failed_risk_score']}")
            print(f"❌ Failed DTE (not 7-25): {filter_stats['failed_dte']}")
            print(f"❌ Failed Score (<60): {filter_stats['failed_score_threshold']}")
            
            if failed_details and filter_stats['passed'] == 0:
                print(f"\n📋 Sample failures (showing first 15):")
                print(f"{'Symbol':<12} {'Reason':<30} {'IV Rank':>8} {'Risk':>6} {'DTE':>5}")
                print("-"*80)
                for detail in failed_details[:15]:
                    print(f"{detail['symbol']:<12} {detail['reason']:<30} "
                          f"{detail.get('iv_rank', 0):>8.0f} {detail.get('risk', 0):>6.1f} {detail.get('dte', 0):>5.0f}")
            print("="*80)
        
        return sorted(results, key=lambda x: x['score'], reverse=True)
    
    def print_report(self, debug=False):
        """Print comprehensive report"""
        print("="*120)
        print("GREEKS-POWERED SCANNER - Complete Analysis".center(120))
        print("="*120)
        
        directional = self.analyze_directional()
        straddles = self.analyze_straddles(debug=debug)
        
        # DIRECTIONAL
        longs = [r for r in directional if r['score'] > 0]
        shorts = [r for r in directional if r['score'] < 0]
        
        if longs:
            print(f"\n{'='*120}")
            print("📈 LONG OPPORTUNITIES (OI + Price + PCR + IV + Delta)")
            print("="*120)
            print(f"{'Symbol':<12} {'Score':>5} {'Action':<18} {'Size':>6} {'Instrument':<12} {'Delta':>7} {'Exposure':>12} {'OI7D%':>8} {'Price%':>8}")
            print("-"*120)
            
            for r in longs[:10]:
                print(f"{r['symbol']:<12} {r['score']:>5.0f} {r['action']:<18} {r['position_size']:>6} "
                      f"{r['instrument']:<12} {r['delta']:>7} {r['delta_exposure']:>12} "
                      f"{r['oi_7d']:>8.1f} {r['price_chg']:>8.2f}")
                for sig in r['signals'][:2]:
                    print(f"    {sig}")
        
        if shorts:
            print(f"\n{'='*120}")
            print("📉 SHORT OPPORTUNITIES")
            print("="*120)
            print(f"{'Symbol':<12} {'Score':>5} {'Action':<18} {'Size':>6} {'Instrument':<12} {'Delta':>7} {'Exposure':>12} {'OI7D%':>8} {'Price%':>8}")
            print("-"*120)
            
            for r in shorts[:8]:
                print(f"{r['symbol']:<12} {r['score']:>5.0f} {r['action']:<18} {r['position_size']:>6} "
                      f"{r['instrument']:<12} {r['delta']:>7} {r['delta_exposure']:>12} "
                      f"{r['oi_7d']:>8.1f} {r['price_chg']:>8.2f}")
                for sig in r['signals'][:2]:
                    print(f"    {sig}")
        
        # STRADDLES
        if straddles:
            print(f"\n{'='*120}")
            print("⭕ STRADDLE OPPORTUNITIES (Greeks-Powered)")
            print("="*120)
            print(f"{'Symbol':<10} {'Score':>5} {'Action':<20} {'Size':>6} {'Delta':>7} {'Theta/Day':>10} {'Gamma':>8} {'IV Rank':>8} {'RoM%':>6}")
            print("-"*120)
            
            for r in straddles[:15]:
                print(f"{r['symbol']:<10} {r['score']:>5.0f} {r['action']:<20} {r['position_size']:>6} "
                      f"{r['net_delta']:>7.3f} {r['net_theta_day']:>10.0f} {r['avg_gamma']:>8.4f} "
                      f"{r['iv_rank']:>8.0f} {r['rom']:>6.1f}")
                
                # Show key signals for top picks
                if r['score'] >= 80:
                    print(f"    Credit: ₹{r['credit']:.0f} | BE: {r['be_lower']:.0f}-{r['be_upper']:.0f} | DTE: {r['dte']:.0f} | Risk: {r['risk_score']:.0f}/10")
                    for sig in r['signals'][:3]:
                        print(f"    {sig}")
        
        # SUMMARY
        print(f"\n{'='*120}")
        print("📊 SUMMARY")
        print("="*120)
        print(f"Directional opportunities: {len(directional)}")
        print(f"  - Longs: {len(longs)} ({len([r for r in longs if r['score'] >= 50])} strong)")
        print(f"  - Shorts: {len(shorts)} ({len([r for r in shorts if r['score'] <= -50])} strong)")
        print(f"\nStraddle opportunities: {len(straddles)}")
        print(f"  - Excellent (90+): {len([r for r in straddles if r['score'] >= 90])}")
        print(f"  - Good (75-89): {len([r for r in straddles if 75 <= r['score'] < 90])}")
        print(f"  - Watch (60-74): {len([r for r in straddles if 60 <= r['score'] < 75])}")
        
        # Portfolio Delta Analysis
        print(f"\n{'='*120}")
        print("⚖️  PORTFOLIO DELTA EXPOSURE")
        print("="*120)
        
        # Calculate total delta exposure for directional trades
        total_long_delta = 0
        total_short_delta = 0
        
        for r in longs:
            if r['delta_exposure'] != "N/A":
                exposure = float(r['delta_exposure'].replace('₹', '').replace(',', ''))
                pos_size = float(r['position_size'].replace('%', ''))
                # Assume 1% = ₹100,000 portfolio allocation
                total_long_delta += (exposure * pos_size / 100)
        
        for r in shorts:
            if r['delta_exposure'] != "N/A":
                exposure = float(r['delta_exposure'].replace('₹', '').replace(',', ''))
                pos_size = float(r['position_size'].replace('%', ''))
                total_short_delta += (exposure * pos_size / 100)
        
        net_directional_delta = total_long_delta - total_short_delta
        
        print(f"Directional Exposure (assuming ₹1L per 1% allocation):")
        print(f"  - Long delta exposure: ₹{total_long_delta:,.0f}")
        print(f"  - Short delta exposure: ₹{total_short_delta:,.0f}")
        print(f"  - Net delta: ₹{net_directional_delta:,.0f}")
        
        if abs(net_directional_delta) > 500000:
            print(f"  ⚠️  High net delta (>₹5L) - consider balancing")
        elif abs(net_directional_delta) < 100000:
            print(f"  ✓ Well-balanced portfolio (<₹1L net)")
        
        # Straddle Greeks Summary
        if straddles:
            avg_theta = sum(r['net_theta_day'] for r in straddles[:10]) / min(10, len(straddles))
            avg_rom = sum(r['rom'] for r in straddles[:10]) / min(10, len(straddles))
            avg_gamma = sum(r['avg_gamma'] for r in straddles[:10]) / min(10, len(straddles))
            
            print(f"\nTop 10 Straddles Average:")
            print(f"  - Daily Theta: ₹{avg_theta:.0f} (income per day)")
            print(f"  - Average Gamma: {avg_gamma:.4f} (risk per % move)")
            print(f"  - RoM: {avg_rom:.1f}% (return on margin)")
            
            # If you deploy all top 10 straddles
            total_theta = sum(r['net_theta_day'] for r in straddles[:10])
            total_credit = sum(r['credit'] for r in straddles[:10])
            print(f"\nIf deploying top 10 straddles:")
            print(f"  - Total daily theta: ₹{total_theta:.0f}")
            print(f"  - Total credit: ₹{total_credit:.0f}")
            print(f"  - Break-even in ~{int(total_credit / total_theta)} days")
        
        print("\n" + "="*120)
        
        # Export
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        if directional:
            pd.DataFrame(directional).to_csv(f"greeks_directional_{timestamp}.csv", index=False)
            print(f"✅ Exported {len(directional)} directional signals")
        
        if straddles:
            pd.DataFrame(straddles).to_csv(f"greeks_straddles_{timestamp}.csv", index=False)
            print(f"✅ Exported {len(straddles)} straddle signals")


def main():
    scanner = GreeksPoweredScanner()
    # Enable debug=True to see why straddles are failing filters
    scanner.print_report(debug=True)


if __name__ == "__main__":
    main()

