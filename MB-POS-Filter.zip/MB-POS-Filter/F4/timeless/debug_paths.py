"""Debug script to show where files are being created"""
import os
from datetime import datetime, timedelta

print("="*80)
print("PATH DEBUGGING")
print("="*80)

# Show current working directory
print(f"\n1. Current working directory:")
print(f"   {os.getcwd()}")

# Show script directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
print(f"\n2. Script directory:")
print(f"   {SCRIPT_DIR}")

# Show where cache would be created
CACHE_DIR = os.path.join(SCRIPT_DIR, "MB_Breakout_Cache")
print(f"\n3. Cache directory (with fix):")
print(f"   {CACHE_DIR}")
print(f"   Exists: {os.path.exists(CACHE_DIR)}")

# Show where cache would be created without fix
OLD_CACHE_DIR = "MB_Breakout_Cache"
print(f"\n4. Cache directory (old way - relative to CWD):")
print(f"   {os.path.abspath(OLD_CACHE_DIR)}")
print(f"   Exists: {os.path.exists(OLD_CACHE_DIR)}")

# Show universe file path
UNIVERSE_CSV = os.path.join(SCRIPT_DIR, "..", "..", "..", "data", "29oct2025_sector_marketcap_freefloat_20251101_150338.csv")
print(f"\n5. Universe CSV:")
print(f"   {os.path.abspath(UNIVERSE_CSV)}")
print(f"   Exists: {os.path.exists(UNIVERSE_CSV)}")

# Date calculation
print(f"\n6. Date calculations:")
end_date = datetime.now().date()
start_date = end_date - timedelta(days=180)
print(f"   End date: {end_date}")
print(f"   Start date (180 days ago): {start_date}")
print(f"   Calendar days: 180")
print(f"   Expected trading days: ~90-110")

print("\n" + "="*80)

