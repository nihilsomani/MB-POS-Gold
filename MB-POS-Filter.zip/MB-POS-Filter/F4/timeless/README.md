# Timeless Market Strategy

**Location:** `MB-POS-Filter/F4/timeless/`

A systematic trading system implementing the **4 enduring principles of market behavior**.

## Quick Start

### From the timeless directory:

```bash
cd MB-POS-Filter/F4/timeless
python run_timeless_scanner.py
```

### With a symbols CSV:

```bash
python run_timeless_scanner.py "../../../data/FNOStock.csv"
```

## Files

- `timeless_market_strategy.py` - Core strategy implementation
- `timeless_market_scanner.py` - Scanner for finding signals
- `timeless_market_backtester.py` - Backtesting engine
- `run_timeless_scanner.py` - Quick runner script
- `TIMELESS_MARKET_STRATEGY.md` - Full documentation

## Configuration

The scanner will automatically look for `config.json` in:
1. Current directory (`timeless/`)
2. Parent directories
3. Workspace root

Your `config.json` should contain:
```json
{
    "api_key": "your_kite_api_key",
    "access_token": "your_access_token",
    "symbols_file": "data/FNOStock.csv"
}
```

## Usage Examples

### Basic Scanning
```python
from timeless_market_scanner import TimelessMarketScanner

scanner = TimelessMarketScanner(
    api_key='your_key',
    access_token='your_token'
)

signals = scanner.scan_from_csv('symbols.csv', min_quality_score=50)
scanner.print_signals_summary(signals)
```

### Direct Strategy Usage
```python
from timeless_market_strategy import TimelessMarketStrategy
import pandas as pd

strategy = TimelessMarketStrategy()
signals = strategy.detect_signals(your_df, symbol='RELIANCE')
```

### Backtesting
```python
from timeless_market_backtester import TimelessMarketBacktester

backtester = TimelessMarketBacktester(initial_capital=100000)
results = backtester.backtest_multiple_symbols(data_dict)
backtester.print_results(results)
```

## Output Files

- Signal CSVs: Saved in the `timeless/` directory as `timeless_signals_YYYYMMDD_HHMMSS.csv`
- Backtest CSVs: Saved as `timeless_backtest_YYYYMMDD_HHMMSS.csv`

## See Also

For full documentation, see `TIMELESS_MARKET_STRATEGY.md`

