# Timeless Market Strategy - Contraction → Expansion in Uptrend

A systematic trading system implementing the **4 enduring principles of market behavior**, operationalized into an executable trading process.

## 📋 The Four Principles

| Principle | Core Idea | Quantification | Trading Implication |
|-----------|-----------|----------------|---------------------|
| **1. Trend Continuation > Reversal** | Trends persist due to institutional positioning, liquidity, and behavioral herding | 20/50 EMA alignment, HH-HL structure, ADX rising | Trade with dominant structure, avoid bottom picking |
| **2. Momentum Precedes Price** | Volume, volatility, and breadth expansions occur before sustained price runs | ROC, Volume Z-score, RSI slope, candle range after compression | Detect impulse waves early for trend confirmation |
| **3. Trends End in Climax** | Exhaustion occurs when everyone is "all in" — volume and volatility spike sharply | Parabolic extensions, volume spikes, wide candles, divergence | Exit or trail stops aggressively; avoid new entries |
| **4. Range Expansion ↔ Contraction** | Markets alternate between quiet (energy buildup) and active (release) | Bollinger Band width, ATR percentile, Keltner Channel squeeze | Wait for contraction → enter when range expands in trend direction |

## 🎯 Strategy Logic

### Entry Setup (3 out of 4 Principles)

1. **Uptrend (Principle 1)**
   - 20 EMA > 50 EMA
   - Price above both EMAs
   - Structure = higher highs and higher lows

2. **Momentum Confirmation (Principle 2)**
   - Strong move in recent bars (5–10% surge with volume > 1.5x average)
   - ROC > 0, RSI slope positive

3. **Volatility Contraction (Principle 4)**
   - Narrow Bollinger Band width (lowest in last 50–100 sessions)
   - ATR percentile < 25%
   - Tight consolidation near highs

### Trigger / Entry

- Price breaks out of contraction zone with volume expansion
- Candle closes above resistance or prior swing high
- Volume > 1.5x 10-day average

### Exit (Principle 3)

- Trail stops via 20 EMA or prior swing lows
- Watch for parabolic extension, volume spikes, or exhaustion gaps
- Exit on climax signals: volume spike + volatility expansion + divergence

## 📊 System Parameters

```
Step | Filter | Description
-----|--------|------------
1 | Trend | 20EMA > 50EMA and price > 20EMA
2 | Momentum | Last 10-day ROC > 0 and volume surge detected
3 | Contraction | Bollinger Band width < 20th percentile of last 100 days
4 | Breakout Trigger | Today's close > 10-day high with volume > 1.5× 10-day average
5 | Stop/Exit | Below 20 EMA or ATR(14) × 1.5 from entry
```

## 🚀 Quick Start

### Installation

```bash
# Ensure required packages are installed
pip install pandas numpy scipy kiteconnect
```

### Basic Usage

```python
from timeless_market_strategy import TimelessMarketStrategy
import pandas as pd

# Initialize strategy
strategy = TimelessMarketStrategy()

# Load your price data (OHLCV DataFrame)
df = pd.read_csv('your_data.csv', index_col='date', parse_dates=True)

# Detect signals
signals = strategy.detect_signals(df, symbol='RELIANCE')

# Print results
for signal in signals:
    print(f"Signal for {signal.symbol}:")
    print(f"  Entry: {signal.entry_price}")
    print(f"  Stop: {signal.stop_loss}")
    print(f"  Target: {signal.target}")
    print(f"  Quality Score: {signal.quality_score}")
```

### Scanner Usage

```python
from timeless_market_scanner import TimelessMarketScanner

# Initialize scanner (with KiteConnect credentials)
scanner = TimelessMarketScanner(
    api_key='your_api_key',
    access_token='your_access_token'
)

# Load instruments
scanner.load_instruments()

# Scan from CSV
signals = scanner.scan_from_csv('symbols.csv', min_quality_score=50)

# Or scan specific symbols
symbols = ['RELIANCE', 'TCS', 'INFY']
signals = scanner.scan_symbols(symbols, min_quality_score=50)

# Display and save results
scanner.print_signals_summary(signals, top_n=20)
scanner.save_signals_to_csv(signals)
```

### Backtesting

```python
from timeless_market_backtester import TimelessMarketBacktester
from datetime import datetime

# Initialize backtester
backtester = TimelessMarketBacktester(
    initial_capital=100000,
    risk_per_trade=0.02,  # 2% risk per trade
    commission=0.001,     # 0.1% commission
    slippage=0.001        # 0.1% slippage
)

# Prepare data dictionary {symbol: DataFrame}
data_dict = {
    'RELIANCE': df_reliance,
    'TCS': df_tcs,
    'INFY': df_infy
}

# Run backtest
results = backtester.backtest_multiple_symbols(
    data_dict,
    start_date=datetime(2023, 1, 1),
    end_date=datetime(2024, 12, 31)
)

# Display results
backtester.print_results(results)

# Save trades
backtester.save_results(results)
```

## ⚙️ Configuration

You can customize strategy parameters:

```python
config = {
    # EMA settings
    'ema_short': 20,
    'ema_long': 50,
    
    # Momentum settings
    'roc_period': 10,
    'rsi_period': 14,
    
    # Bollinger Bands
    'bb_period': 20,
    'bb_std': 2.0,
    'bb_width_lookback': 100,
    'bb_width_percentile': 20,  # Max percentile for contraction
    
    # ATR settings
    'atr_period': 14,
    'atr_percentile_lookback': 100,
    'atr_percentile_max': 25,   # Max percentile for contraction
    
    # Volume
    'volume_multiplier': 1.5,
    'volume_lookback': 10,
    
    # Stop loss
    'stop_atr_multiplier': 1.5,
    'use_ema_trailing': True,
    
    # Breakout
    'breakout_lookback': 10
}

strategy = TimelessMarketStrategy(config)
```

## 📈 Quality Score

Each signal receives a quality score (0-100) based on:

- **Trend Strength** (0-30 points): EMA alignment, trend separation, structure
- **Momentum Strength** (0-30 points): ROC, RSI, RSI slope
- **Volume Strength** (0-20 points): Volume ratio
- **Contraction Quality** (0-20 points): BB width percentile, ATR percentile

Higher scores indicate stronger setups.

## 📝 Output Format

### Signal Output

Each signal contains:
- `symbol`: Trading symbol
- `date`: Signal date
- `entry_price`: Entry price
- `stop_loss`: Stop loss price
- `target`: Target price
- `risk_reward`: Risk:Reward ratio
- `quality_score`: Quality score (0-100)
- `signals`: Detailed signal metrics (ROC, RSI, Volume, etc.)
- `notes`: Human-readable summary

### Backtest Output

Backtest results include:
- Total Trades, Win Rate
- Total P&L, CAGR, Total Return
- Profit Factor, Average Win/Loss
- Max Drawdown, Sharpe Ratio
- Average Holding Period
- Detailed trade log

## 🎓 Why This Works

The system syncs with the **rhythm of the market**:

1. ✅ **Wait until energy builds** (contraction)
2. ✅ **Align with dominant flow** (trend)
3. ✅ **Confirm participation** (momentum)
4. ✅ **Exit when enthusiasm peaks** (climax)

This structure eliminates emotional decision-making and allows you to be systematic yet adaptive.

## 🔧 Integration with KiteConnect (Zerodha)

The scanner integrates with Zerodha's KiteConnect API for live scanning:

```python
from timeless_market_scanner import TimelessMarketScanner

scanner = TimelessMarketScanner(
    api_key='your_kite_api_key',
    access_token='your_access_token'
)

# Scan NSE stocks
signals = scanner.scan_from_csv('symbols.csv')
```

## 📚 Files

- `timeless_market_strategy.py` - Core strategy implementation
- `timeless_market_scanner.py` - Scanner for finding signals
- `timeless_market_backtester.py` - Backtesting engine
- `TIMELESS_MARKET_STRATEGY.md` - This documentation

## ⚠️ Disclaimer

This strategy is for educational and research purposes. Past performance does not guarantee future results. Always use proper risk management and do your own research before trading.

## 📄 License

This implementation is provided as-is for educational purposes.

