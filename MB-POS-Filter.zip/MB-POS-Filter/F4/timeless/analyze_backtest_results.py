"""
Analyze Timeless Market Strategy Backtest Results
Deep dive into trade performance to identify issues and improvements
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import os

def analyze_trades(csv_path):
    """Comprehensive trade analysis"""
    
    df = pd.read_csv(csv_path)
    
    print("="*80)
    print("TIMELESS MARKET STRATEGY - TRADE ANALYSIS")
    print("="*80)
    
    # Basic stats
    print(f"\n📊 OVERVIEW")
    print(f"{'-'*80}")
    print(f"Total Trades: {len(df)}")
    print(f"Winning: {len(df[df['pnl'] > 0])} ({len(df[df['pnl'] > 0])/len(df)*100:.1f}%)")
    print(f"Losing: {len(df[df['pnl'] < 0])} ({len(df[df['pnl'] < 0])/len(df)*100:.1f}%)")
    print(f"Breakeven: {len(df[df['pnl'] == 0])}")
    
    # Exit reasons analysis
    print(f"\n🚪 EXIT REASONS BREAKDOWN")
    print(f"{'-'*80}")
    exit_reasons = df['exit_reason'].value_counts()
    for reason, count in exit_reasons.items():
        pct = count / len(df) * 100
        avg_pnl = df[df['exit_reason'] == reason]['pnl'].mean()
        print(f"{reason:30s} {count:4d} ({pct:5.1f}%) | Avg P&L: ₹{avg_pnl:8.2f}")
    
    # Exit reason by win/loss
    print(f"\n📉 EXIT REASONS - WIN/LOSS BREAKDOWN")
    print(f"{'-'*80}")
    for reason in exit_reasons.index:
        reason_df = df[df['exit_reason'] == reason]
        wins = len(reason_df[reason_df['pnl'] > 0])
        losses = len(reason_df[reason_df['pnl'] < 0])
        win_rate = wins / len(reason_df) * 100 if len(reason_df) > 0 else 0
        print(f"{reason:30s} Wins: {wins:3d} Losses: {losses:3d} Win Rate: {win_rate:5.1f}%")
    
    # Quality score analysis
    print(f"\n⭐ QUALITY SCORE ANALYSIS")
    print(f"{'-'*80}")
    df['quality_bucket'] = pd.cut(df['quality_score'], 
                                   bins=[0, 50, 60, 70, 80, 100], 
                                   labels=['50-60', '60-70', '70-80', '80-90', '90-100'])
    
    for bucket in ['50-60', '60-70', '70-80', '80-90', '90-100']:
        bucket_df = df[df['quality_bucket'] == bucket]
        if len(bucket_df) > 0:
            win_rate = len(bucket_df[bucket_df['pnl'] > 0]) / len(bucket_df) * 100
            avg_pnl = bucket_df['pnl'].mean()
            print(f"Quality {bucket:10s} Trades: {len(bucket_df):3d} | Win Rate: {win_rate:5.1f}% | Avg P&L: ₹{avg_pnl:8.2f}")
    
    # Holding period analysis
    print(f"\n⏱️  HOLDING PERIOD ANALYSIS")
    print(f"{'-'*80}")
    df['holding_bucket'] = pd.cut(df['holding_days'], 
                                   bins=[0, 5, 10, 20, 30, 1000], 
                                   labels=['1-5', '6-10', '11-20', '21-30', '30+'])
    
    for bucket in ['1-5', '6-10', '11-20', '21-30', '30+']:
        bucket_df = df[df['holding_bucket'] == bucket]
        if len(bucket_df) > 0:
            win_rate = len(bucket_df[bucket_df['pnl'] > 0]) / len(bucket_df) * 100
            avg_pnl = bucket_df['pnl'].mean()
            print(f"Holding {bucket:10s} Trades: {len(bucket_df):3d} | Win Rate: {win_rate:5.1f}% | Avg P&L: ₹{avg_pnl:8.2f}")
    
    # Stop loss analysis
    print(f"\n🛡️  STOP LOSS ANALYSIS")
    print(f"{'-'*80}")
    df['stop_loss_pct'] = ((df['entry_price'] - df['stop_loss']) / df['entry_price'] * 100).abs()
    df['risk'] = df['entry_price'] - df['stop_loss']
    df['reward'] = df['target'] - df['entry_price']
    df['rr_ratio'] = df['reward'] / df['risk']
    
    print(f"Average Stop Loss: {df['stop_loss_pct'].mean():.2f}%")
    print(f"Average Risk: ₹{df['risk'].mean():.2f}")
    print(f"Average Reward: ₹{df['reward'].mean():.2f}")
    print(f"Average R:R Ratio: {df['rr_ratio'].mean():.2f}:1")
    
    # Stop loss by exit reason
    print(f"\n🛑 STOP LOSS HITS ANALYSIS")
    print(f"{'-'*80}")
    stop_loss_trades = df[df['exit_reason'] == 'Stop Loss']
    if len(stop_loss_trades) > 0:
        print(f"Stop Loss Hits: {len(stop_loss_trades)} ({len(stop_loss_trades)/len(df)*100:.1f}%)")
        print(f"Avg Stop Loss %: {stop_loss_trades['stop_loss_pct'].mean():.2f}%")
        print(f"Avg Loss: ₹{stop_loss_trades['pnl'].mean():.2f}")
        
        # How tight are stops that get hit?
        print(f"\nStop Loss Tightness (when hit):")
        tight_stops = stop_loss_trades[stop_loss_trades['stop_loss_pct'] < 4]
        medium_stops = stop_loss_trades[(stop_loss_trades['stop_loss_pct'] >= 4) & (stop_loss_trades['stop_loss_pct'] < 7)]
        wide_stops = stop_loss_trades[stop_loss_trades['stop_loss_pct'] >= 7]
        
        print(f"  Tight (<4%): {len(tight_stops)} trades")
        print(f"  Medium (4-7%): {len(medium_stops)} trades")
        print(f"  Wide (>7%): {len(wide_stops)} trades")
    
    # Target hits analysis
    target_trades = df[df['exit_reason'] == 'Target Hit']
    if len(target_trades) > 0:
        print(f"\n🎯 TARGET HITS ANALYSIS")
        print(f"{'-'*80}")
        print(f"Target Hits: {len(target_trades)} ({len(target_trades)/len(df)*100:.1f}%)")
        print(f"Avg Win: ₹{target_trades['pnl'].mean():.2f}")
        avg_rr = target_trades['rr_ratio'].mean()
        print(f"Avg R:R Achieved: {avg_rr:.2f}:1")
    
    # P&L distribution
    print(f"\n💰 P&L DISTRIBUTION")
    print(f"{'-'*80}")
    print(f"Best Trade: ₹{df['pnl'].max():.2f} ({df.loc[df['pnl'].idxmax(), 'symbol']})")
    print(f"Worst Trade: ₹{df['pnl'].min():.2f} ({df.loc[df['pnl'].idxmin(), 'symbol']})")
    print(f"Median Win: ₹{df[df['pnl'] > 0]['pnl'].median():.2f}")
    print(f"Median Loss: ₹{df[df['pnl'] < 0]['pnl'].median():.2f}")
    
    # Top/Bottom performers
    print(f"\n🏆 TOP 10 WINNERS")
    print(f"{'-'*80}")
    top_winners = df.nlargest(10, 'pnl')[['symbol', 'pnl', 'pnl_pct', 'holding_days', 'exit_reason', 'quality_score']]
    for idx, row in top_winners.iterrows():
        print(f"{row['symbol']:15s} ₹{row['pnl']:8.2f} ({row['pnl_pct']:6.2f}%) | {row['holding_days']:3.0f}d | {row['exit_reason']:20s} | Q:{row['quality_score']:.1f}")
    
    print(f"\n💥 BOTTOM 10 LOSERS")
    print(f"{'-'*80}")
    top_losers = df.nsmallest(10, 'pnl')[['symbol', 'pnl', 'pnl_pct', 'holding_days', 'exit_reason', 'quality_score']]
    for idx, row in top_losers.iterrows():
        print(f"{row['symbol']:15s} ₹{row['pnl']:8.2f} ({row['pnl_pct']:6.2f}%) | {row['holding_days']:3.0f}d | {row['exit_reason']:20s} | Q:{row['quality_score']:.1f}")
    
    # Recommendations
    print(f"\n💡 KEY INSIGHTS & RECOMMENDATIONS")
    print(f"{'-'*80}")
    
    stop_loss_pct = len(df[df['exit_reason'] == 'Stop Loss']) / len(df) * 100
    if stop_loss_pct > 50:
        print(f"⚠️  {stop_loss_pct:.1f}% of trades hit stop loss - STOPS TOO TIGHT or ENTRIES TOO POOR")
    
    avg_loss = df[df['pnl'] < 0]['pnl'].mean()
    avg_win = df[df['pnl'] > 0]['pnl'].mean()
    if abs(avg_loss) > avg_win:
        print(f"⚠️  Average loss (₹{abs(avg_loss):.2f}) > Average win (₹{avg_win:.2f}) - Need wider stops or better exits")
    
    win_rate = len(df[df['pnl'] > 0]) / len(df) * 100
    if win_rate < 40:
        print(f"⚠️  Win rate {win_rate:.1f}% too low - Strategy needs better entry filters or trend confirmation")
    
    if len(df) < 200:
        print(f"⚠️  Only {len(df)} trades in 3+ years - Follow-through may be too strict, missing opportunities")
    
    avg_holding = df['holding_days'].mean()
    if avg_holding < 10:
        print(f"⚠️  Avg holding {avg_holding:.1f} days is very short - Trades exiting too early, missing run")
    
    print("\n" + "="*80)
    
    return df

if __name__ == "__main__":
    import sys
    import io
    
    # Set UTF-8 encoding for Windows console
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    
    # Find latest trades file
    results_dir = Path(__file__).parent / "backtest_results"
    trade_files = list(results_dir.glob("timeless_trades_*.csv"))
    
    if trade_files:
        latest_file = max(trade_files, key=lambda x: x.stat().st_mtime)
        print(f"Analyzing: {latest_file.name}\n")
        df = analyze_trades(latest_file)
    else:
        print("❌ No trade files found in backtest_results directory")
        if len(sys.argv) > 1:
            df = analyze_trades(sys.argv[1])
        else:
            print("Usage: python analyze_backtest_results.py <trades.csv>")

