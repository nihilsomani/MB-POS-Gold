# Concall & Annual Report Analysis Framework

## Complete Scoring System (Now Enhanced!)

### **Total Score Range: 0-100+**

The qualitative score is calculated from **6 key dimensions**:

```
Qual Score = 50 (baseline)
           + Management Quality      (-50 to +50)
           + Strategic Updates       (0 to +20)    ← NEW!
           + Guidance/Outlook        (-15 to +15)  ← NEW!
           + Earning Triggers        (0 to +25)    ← NEW!
           + Management Consistency  (-20 to +20)  ← NEW!
           + Moat Validation        (-30 to +30)
           + Capital Allocation     (-20 to +20)
```

---

## 1️⃣ **Management Quality** (-50 to +50 points)

### ✅ **POSITIVE SIGNALS**

#### **Capital Allocation Focus (+20)**
- **Keywords:** "capital allocation", "ROCE", "ROIC", "free cash flow", "FCF", "buyback", "shareholder value", "return on capital"
- **>10 mentions** → +20 pts: "✅ Capital-focused management"
- **>5 mentions** → +10 pts
- **Why:** Shows owners' mindset, not empire builders

#### **Transparency (+15)**
- **Keywords:** "challenge", "headwind", "admitted", "acknowledged", "difficult", "setback", "temporary"
- **>5 mentions** → +15 pts: "✅ Transparent - acknowledges challenges"
- **>2 mentions** → +8 pts
- **Why:** Honest management > sugar-coated lies

#### **Execution Track Record (+15)**
- **Keywords:** "achieved", "delivered", "completed", "exceeded", "commissioned", "launched", "executed"
- **>8 mentions** → +15 pts: "✅ Strong execution track record"
- **>4 mentions** → +8 pts
- **Why:** Talk is cheap, delivery matters

### 🚩 **NEGATIVE SIGNALS**

#### **Excuse-Making (-20)**
- **Keywords:** "external factors", "macroeconomic", "geopolitical", "beyond our control", "market conditions"
- **>5 mentions** → -20 pts: "🚩 Excessive excuse-making"
- **>2 mentions** → -10 pts
- **Why:** Weak management blames externals

#### **Accounting Red Flags (-25)**
- **Keywords:** "one-time charge", "exceptional item", "goodwill impairment", "restructuring charge", "write-off", "provision"
- **>3 mentions** → -25 pts: "🚩 Multiple one-time charges"
- **>1 mention** → -10 pts
- **Why:** Frequent "one-time" = earnings manipulation

#### **Corporate Jargon Overload (-15)**
- **Keywords:** "synergy", "transformational", "strategic", "leverage", "going forward"
- **>30 mentions** → -15 pts: "⚠️ Heavy corporate jargon"
- **Why:** Jargon hides poor results

---

## 2️⃣ **Strategic Updates** (0 to +20 points) ⭐ NEW!

### **Clear Strategic Initiatives (+10)**
- **Keywords:** "new product launch", "market expansion", "capacity expansion", "digital transformation", "automation", "technology upgrade", "new facility", "greenfield", "brownfield"
- **>3 mentions** → +10 pts: "✅ Clear strategic initiatives outlined"
- **>1 mention** → +5 pts
- **Why:** Vision without execution is hallucination

### **Geographic/Market Expansion (+5)**
- **Keywords:** "international expansion", "export growth", "new markets", "market share gain", "penetration"
- **>2 mentions** → +5 pts: "✅ Geographic/market expansion plans"
- **Why:** TAM expansion = long runway

### **Innovation/R&D Focus (+5)**
- **Keywords:** "r&d", "research and development", "innovation", "patent", "new technology", "product pipeline"
- **>3 mentions** → +5 pts: "✅ Strong R&D/innovation focus"
- **Why:** Innovation = moat defense

---

## 3️⃣ **Guidance & Outlook** (-15 to +15 points) ⭐ NEW!

### **Positive Guidance (+15)**
- **Keywords:** "guidance raised", "upgraded guidance", "expect growth", "improving outlook", "positive momentum", "expect improvement", "margin expansion expected", "targeting growth"
- **>3 mentions** → +15 pts: "✅ Positive forward guidance"
- **>1 mention** → +8 pts
- **Why:** Management confidence = future visibility

### **Negative Guidance (-15)**
- **Keywords:** "guidance cut", "lowered guidance", "downgraded outlook", "expect weakness", "expect decline", "challenging outlook"
- **>2 mentions** → -15 pts: "🚩 Guidance cut or negative outlook"
- **>0 mentions** → -8 pts
- **Why:** Downgrades = deteriorating business

### **Specific Targets Provided (+5)**
- **Keywords:** "target", "aim for", pattern matching for "expect X%", "guidance Y%"
- **Found** → +5 pts: "✅ Specific targets/guidance provided"
- **Why:** Specific > vague promises

---

## 4️⃣ **Earning Triggers/Catalysts** (0 to +25 points) ⭐ NEW!

### **New Contract Wins (+10)**
- **Keywords:** "order book", "order intake", "contract win", "order backlog", "new contract", "awarded", "won order"
- **>3 mentions** → +10 pts: "✅ Strong order book/new contract wins"
- **>1 mention** → +5 pts
- **Why:** Order book = revenue visibility

### **Capacity Utilization/Expansion (+8)**
- **Keywords:** "capacity utilization", "operating at X%", "full capacity", "capacity addition", "ramp up", "scaling up"
- **>2 mentions** → +8 pts: "✅ Capacity expansion/high utilization"
- **>0 mentions** → +4 pts
- **Why:** High utilization → pricing power

### **Product Launches/Pipeline (+7)**
- **Keywords:** "new product", "product launch", "product pipeline", "product portfolio", "new offering"
- **>2 mentions** → +7 pts: "✅ New product launches/strong pipeline"
- **>0 mentions** → +3 pts
- **Why:** New products = growth drivers

---

## 5️⃣ **Management Consistency** (-20 to +20 points) ⭐ NEW!

### **Meeting Commitments (+20)**
- **Keywords:** "as committed", "as promised", "as guided", "delivered on", "met our guidance", "achieved our target", "on track"
- **>3 mentions** → +20 pts: "✅ Consistently delivers on commitments"
- **>1 mention** → +10 pts
- **Why:** Track record = credibility

### **Missing Commitments (-20)**
- **Keywords:** "missed guidance", "fell short", "did not achieve", "below guidance", "delayed from original"
- **>2 mentions** → -20 pts: "🚩 Frequently misses commitments"
- **>0 mentions** → -10 pts
- **Why:** Unreliable management = avoid

### **Changing Narrative (-10)**
- **Keywords:** "revised approach", "change in strategy", "different from", "pivoting", "reconsidering"
- **>3 mentions** → -10 pts: "⚠️ Frequently changing narrative"
- **Why:** Consistency > flip-flopping

---

## 6️⃣ **Moat Validation** (-30 to +30 points)

### **Network Effects (+10)**
- **Keywords:** "platform", "network effect", "marketplace", "ecosystem", "two-sided"
- **>3 mentions** → +10 pts: "✅ Network effects mentioned"

### **Switching Costs (+10)**
- **Keywords:** "customer retention", "sticky", "embedded", "integration", "lifetime value", "switching cost"
- **>3 mentions** → +10 pts: "✅ High switching costs"

### **Brand/Pricing Power (+10)**
- **Keywords:** "brand equity", "premium pricing", "pricing power", "market leader"
- **>3 mentions** → +10 pts: "✅ Brand/pricing power"

### **Competitive Pressure (-20)**
- **Keywords:** "intense competition", "competitive pressure", "price war", "margin pressure", "commoditized"
- **>3 mentions** → -20 pts: "🚩 Intense competitive pressure"

---

## 7️⃣ **Capital Allocation History** (-20 to +20 points)

### **Shareholder Returns (+20)**
- **Keywords:** "buyback", "share repurchase", "dividend increase", "special dividend"
- **>3 mentions** → +20 pts: "✅ Active shareholder returns"

### **Value-Destroying M&A (-15)**
- **Keywords:** "acquisition", "merger", "consolidation", "diversification"
- **>5 mentions** → -15 pts: "⚠️ Frequent M&A activity"

### **Discipline (+10)**
- **Keywords:** "disciplined approach", "selective", "focused", "return threshold"
- **>3 mentions** → +10 pts: "✅ Disciplined capital allocation"

---

## 📊 **Final Qual Score Interpretation**

| Score Range | Grade | Interpretation |
|-------------|-------|----------------|
| **80-100** | A+ | Exceptional management + clear strategy + positive outlook |
| **70-79** | A | Excellent quality + good execution |
| **60-69** | B+ | Good management + some concerns |
| **50-59** | B | Average/Mixed signals |
| **40-49** | C | Below average quality |
| **<40** | D | Poor quality/Major red flags |

---

## 🎯 **Example: ACUTAAS Concall Analysis**

When you re-run the analysis, ACUTAAS concall will be scanned for:

### **Strategic Updates:**
- ✅ Market expansion plans?
- ✅ Capacity additions mentioned?
- ✅ New product launches?

### **Guidance & Outlook:**
- ✅ FY25 guidance positive/negative?
- ✅ Margin expansion expected?
- 🚩 Any guidance cuts?

### **Earning Triggers:**
- ✅ Order book strength?
- ✅ Capacity utilization levels?
- ✅ Client wins mentioned?

### **Management Consistency:**
- ✅ "Delivered as promised" mentions?
- 🚩 "Missed our guidance" flags?
- ⚠️ Strategy changes?

### **Moat Evidence:**
- ✅ Customer stickiness discussed?
- 🚩 Competitive intensity acknowledged?
- ✅ Pricing power mentioned?

---

## 🔄 **Impact on Final Decision**

### **Current (Without Documents):**
```
ACUTAAS:
  Quant: Grade D + Weak Moat
  Qual:  No Documents (Score = 50)
  Final: PASS
```

### **After Enhancement (With Concall):**

**Scenario A: Positive Concall (Score 75+)**
```
ACUTAAS:
  Quant: Grade D + Weak Moat
  Qual:  Score = 75 (Good management, positive outlook)
  Final: WATCH (Qual overcomes weak quant)
  
  Insights:
  - ✅ Strong execution track record
  - ✅ Positive FY25 guidance
  - ✅ New contract wins mentioned
  - ✅ Management delivered on commitments
```

**Scenario B: Negative Concall (Score 30)**
```
ACUTAAS:
  Quant: Grade D + Weak Moat
  Qual:  Score = 30 (Red flags)
  Final: PASS (Confirmed)
  
  Red Flags:
  - 🚩 Guidance cut
  - 🚩 Excessive excuse-making
  - 🚩 Margin pressure acknowledged
  - 🚩 Missed previous commitments
```

---

## ✅ **Next Steps**

1. **Re-run analysis** with the path fix
2. **Documents will be processed** automatically
3. **Get comprehensive qual scores** with insights
4. **Make informed decisions** based on complete picture

**The analyzer now looks for everything you mentioned!** 🎉

