"""
Anthropic Haiku 4.5 Concall Analyzer
Ultra-fast, ultra-cheap: ~$0.02 per company!
"""

import os
import json
import re
from pathlib import Path
from datetime import datetime
from anthropic import Anthropic

class HaikuConcallAnalyzer:
    def __init__(self, api_key: str = None, downloads_dir: str = "downloads"):
        """
        Initialize with Anthropic Haiku 4.5
        
        Cost: ~$0.02 per company analysis
        Speed: ~30 seconds total
        """
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError("Please set ANTHROPIC_API_KEY environment variable or pass api_key")
        
        self.client = Anthropic(api_key=self.api_key)
        self.model = "claude-3-5-haiku-20241022"  # Haiku 4.5
        self.concalls_dir = Path(downloads_dir) / "concalls"
        
        print(f"✓ Haiku Analyzer initialized")
        print(f"   Model: {self.model}")
        print(f"   Cost: ~$0.02 per company\n")
    
    def _extract_pdf_text(self, pdf_path: str, max_pages: int = 15) -> str:
        """Extract text from PDF"""
        try:
            import PyPDF2
            text = ""
            with open(pdf_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                pages = min(max_pages, len(reader.pages))
                print(f"   📄 Reading {pages} pages...")
                
                for i in range(pages):
                    text += reader.pages[i].extract_text() + "\n"
            
            return text
        except Exception as e:
            print(f"   ✗ Error: {e}")
            return ""
    
    def read_concall(self, symbol: str) -> str:
        """Read concall"""
        concalls = list(self.concalls_dir.glob(f"{symbol}*"))
        if not concalls:
            return ""
        
        print(f"   ✓ Found: {concalls[0].name}")
        
        if concalls[0].suffix.lower() == '.pdf':
            return self._extract_pdf_text(str(concalls[0]))
        else:
            return concalls[0].read_text(encoding='utf-8', errors='ignore')
    
    def _query_haiku(self, prompt: str, max_tokens: int = 1000) -> str:
        """Query Haiku with prompt"""
        try:
            message = self.client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                temperature=0,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            return message.content[0].text
        except Exception as e:
            print(f"   ❌ API Error: {e}")
            return ""
    
    def analyze_tone(self, text: str) -> dict:
        """Analyze management tone"""
        snippet = text[:4000]  # First 4k chars
        
        prompt = f"""Analyze management tone from this concall excerpt.

Concall:
{snippet}

Rate these (0-100):
- Confidence (positive/cautious)
- Transparency (candid/evasive)
- Outlook (bullish/bearish)

Return ONLY valid JSON:
{{"confidence": 85, "transparency": 75, "outlook": 80, "summary": "one sentence"}}"""

        response = self._query_haiku(prompt, max_tokens=300)
        
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            return {"error": "Could not parse", "raw": response[:200]}
        except:
            return {"error": "Parse failed"}
    
    def extract_guidance(self, text: str) -> dict:
        """Extract forward guidance"""
        # Smart search for guidance section
        text_lower = text.lower()
        guidance_pos = max(text_lower.find('guidance'), 
                          text_lower.find('outlook'),
                          text_lower.find('fy'), 0)
        
        snippet = text[guidance_pos:guidance_pos+5000]
        
        prompt = f"""Extract forward guidance from this concall.

Concall:
{snippet}

Find:
- Revenue guidance (% or absolute)
- Margin targets
- Key initiatives
- Timeline

Return ONLY valid JSON:
{{"revenue_guidance": "20-25% growth", "margin_target": "28-30%", "key_initiatives": ["item1", "item2"], "timeline": "FY25"}}"""

        response = self._query_haiku(prompt, max_tokens=500)
        
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            return {"error": "Could not parse"}
        except:
            return {"error": "Parse failed"}
    
    def identify_catalysts(self, text: str) -> dict:
        """Identify growth catalysts"""
        # Search for catalyst keywords
        text_lower = text.lower()
        catalyst_pos = 0
        for keyword in ['order book', 'expansion', 'new product', 'launch', 'win']:
            pos = text_lower.find(keyword)
            if pos > 0:
                catalyst_pos = pos
                break
        
        snippet = text[max(0, catalyst_pos-1000):catalyst_pos+4000]
        
        prompt = f"""Identify growth catalysts from this concall.

Concall:
{snippet}

Find:
- Order book status/wins
- New products/launches
- Market expansion
- Partnerships

Return ONLY valid JSON:
{{"catalysts": ["catalyst1", "catalyst2"], "order_book": "strong/weak/not mentioned", "partnerships": ["partner1"]}}"""

        response = self._query_haiku(prompt, max_tokens=400)
        
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            return {"error": "Could not parse"}
        except:
            return {"error": "Parse failed"}
    
    def assess_risks(self, text: str) -> dict:
        """Assess risks and challenges"""
        # Search for risk keywords
        text_lower = text.lower()
        risk_pos = 0
        for keyword in ['risk', 'challenge', 'headwind', 'pressure', 'concern']:
            pos = text_lower.find(keyword)
            if pos > 0:
                risk_pos = pos
                break
        
        snippet = text[max(0, risk_pos-1000):risk_pos+4000]
        
        prompt = f"""Identify risks from this concall.

Concall:
{snippet}

Find:
- Competitive threats
- Margin pressures
- Supply chain issues
- Market risks

Return ONLY valid JSON:
{{"risks": ["risk1", "risk2"], "severity": "low/moderate/high"}}"""

        response = self._query_haiku(prompt, max_tokens=400)
        
        try:
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            return {"error": "Could not parse"}
        except:
            return {"error": "Parse failed"}
    
    def analyze(self, company: str, symbol: str, industry: str) -> dict:
        """Complete analysis"""
        print(f"\n{'='*70}")
        print(f"HAIKU ANALYSIS: {company} ({symbol})")
        print(f"{'='*70}\n")
        
        print("📞 Reading concall...")
        text = self.read_concall(symbol)
        
        if not text:
            print("❌ No concall found")
            return {"error": "No concall"}
        
        print(f"   ✓ Loaded {len(text)} characters\n")
        
        print("🎯 Analyzing tone (Haiku)...")
        tone = self.analyze_tone(text)
        
        print("📊 Extracting guidance (Haiku)...")
        guidance = self.extract_guidance(text)
        
        print("🚀 Identifying catalysts (Haiku)...")
        catalysts = self.identify_catalysts(text)
        
        print("⚠️  Assessing risks (Haiku)...")
        risks = self.assess_risks(text)
        
        print("✅ Analysis complete!\n")
        
        return {
            'company': company,
            'symbol': symbol,
            'industry': industry,
            'model': 'claude-3-5-haiku-20241022',
            'estimated_cost': '$0.02',
            'tone': tone,
            'guidance': guidance,
            'catalysts': catalysts,
            'risks': risks,
            'analyzed_at': datetime.now().isoformat()
        }
    
    def print_report(self, result: dict):
        """Print detailed report"""
        if 'error' in result:
            print(f"❌ {result['error']}")
            return
        
        print(f"{'='*70}")
        print(f"HAIKU ANALYSIS REPORT".center(70))
        print(f"{'='*70}")
        
        print(f"\n📊 {result['company']} ({result['symbol']})")
        print(f"   Industry: {result['industry']}")
        print(f"   Cost: ~{result.get('estimated_cost', '$0.02')}")
        
        print(f"\n{'─'*70}")
        print("🎙️  MANAGEMENT TONE & CONFIDENCE")
        print(f"{'─'*70}")
        tone = result.get('tone', {})
        if 'error' not in tone:
            print(f"\n   Confidence: {tone.get('confidence', 'N/A')}/100")
            print(f"   Transparency: {tone.get('transparency', 'N/A')}/100")
            print(f"   Outlook: {tone.get('outlook', 'N/A')}/100")
            if tone.get('summary'):
                print(f"\n   Summary: {tone['summary']}")
        
        print(f"\n{'─'*70}")
        print("📈 FORWARD GUIDANCE & OUTLOOK")
        print(f"{'─'*70}")
        guidance = result.get('guidance', {})
        if 'error' not in guidance:
            print(f"\n   Revenue: {guidance.get('revenue_guidance', 'N/A')}")
            print(f"   Margin: {guidance.get('margin_target', 'N/A')}")
            if guidance.get('timeline'):
                print(f"   Timeline: {guidance['timeline']}")
            if guidance.get('key_initiatives'):
                print(f"\n   Key Initiatives:")
                for init in guidance['key_initiatives'][:5]:
                    print(f"      • {init}")
        
        print(f"\n{'─'*70}")
        print("🚀 GROWTH CATALYSTS")
        print(f"{'─'*70}")
        catalysts = result.get('catalysts', {})
        if 'error' not in catalysts:
            if catalysts.get('order_book'):
                print(f"\n   Order Book: {catalysts['order_book'].title()}")
            if catalysts.get('catalysts'):
                print(f"\n   Identified Catalysts:")
                for cat in catalysts['catalysts']:
                    print(f"      ✅ {cat}")
            if catalysts.get('partnerships'):
                print(f"\n   Partnerships:")
                for p in catalysts['partnerships']:
                    print(f"      • {p}")
        
        print(f"\n{'─'*70}")
        print("⚠️  RISKS & CHALLENGES")
        print(f"{'─'*70}")
        risks = result.get('risks', {})
        if 'error' not in risks:
            if risks.get('severity'):
                print(f"\n   Risk Level: {risks['severity'].upper()}")
            if risks.get('risks'):
                print(f"\n   Identified Risks:")
                for risk in risks['risks']:
                    print(f"      🚩 {risk}")
        
        print(f"\n{'='*70}")
        print("💡 INVESTMENT VERDICT")
        print(f"{'='*70}\n")
        
        if tone.get('confidence', 0) > 70 and tone.get('outlook', 0) > 70:
            print("   ✅ STRONG POSITIVE: High confidence, bullish outlook")
        elif tone.get('confidence', 0) > 60:
            print("   ✅ POSITIVE: Management confident")
        elif tone.get('confidence', 0) > 45:
            print("   ⚠️  NEUTRAL: Balanced view")
        else:
            print("   🚩 CAUTIOUS: Concerns evident")
        
        print(f"\n{'='*70}\n")


def main():
    import sys
    if sys.platform == 'win32':
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except:
            pass
    
    print("="*70)
    print("ANTHROPIC HAIKU 4.5 ANALYZER".center(70))
    print("="*70)
    print("\n✨ Ultra-fast & ultra-cheap: ~$0.02 per company")
    print("   $5 credit = 250 companies analyzed!\n")
    
    # Check for API key
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        print("⚠️  No API key found!")
        print("\nSetup:")
        print("   1. Get key from: https://console.anthropic.com/")
        print("   2. Set environment variable:")
        print("      $env:ANTHROPIC_API_KEY = 'your-key-here'\n")
        api_key = input("Or enter API key now: ").strip()
        if not api_key:
            print("❌ Cannot proceed without API key")
            return
    
    analyzer = HaikuConcallAnalyzer(api_key=api_key)
    
    company = input("Company name: ").strip()
    symbol = input("Symbol: ").strip().upper()
    industry = input("Industry: ").strip()
    
    result = analyzer.analyze(company, symbol, industry)
    analyzer.print_report(result)
    
    # Save
    save = input("\n💾 Save report? (y/n): ").strip().lower()
    if save == 'y':
        filename = f"{symbol}_haiku_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(result, f, indent=2)
        print(f"✅ Saved: {filename}")
    
    print(f"\n💰 Estimated cost for this analysis: ~$0.02")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

