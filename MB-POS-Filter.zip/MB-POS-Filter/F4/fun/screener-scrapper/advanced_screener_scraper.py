import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import re
import logging
from typing import Dict, List, Optional, Tuple, Any
import json
from urllib.parse import urljoin, urlparse
import random
from datetime import datetime
import os
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('advanced_screener_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class AdvancedScreenerScraper:
    """
    Advanced web scraper for screener.in with enhanced features
    """
    
    def __init__(self, 
                 base_url: str = "https://www.screener.in", 
                 delay_range: Tuple[int, int] = (1, 3),
                 max_workers: int = 3,
                 timeout: int = 30,
                 retry_attempts: int = 3):
        """
        Initialize the advanced scraper
        
        Args:
            base_url: Base URL for screener.in
            delay_range: Range of seconds to delay between requests (min, max)
            max_workers: Maximum number of concurrent workers
            timeout: Request timeout in seconds
            retry_attempts: Number of retry attempts for failed requests
        """
        self.base_url = base_url
        self.delay_range = delay_range
        self.max_workers = max_workers
        self.timeout = timeout
        self.retry_attempts = retry_attempts
        
        # Thread-local session for each worker
        self.session_local = threading.local()
        
        # Rate limiting
        self.request_lock = threading.Lock()
        self.last_request_time = 0
        
        # Financial metrics mapping
        self.metrics_mapping = {
            'Market Cap': 'market_cap',
            'Current Price': 'current_price',
            'High / Low': 'high_low',
            'Stock P/E': 'pe_ratio',
            'Book Value': 'book_value',
            'Dividend Yield': 'dividend_yield',
            'ROCE': 'roce',
            'ROE': 'roe',
            'Face Value': 'face_value',
            'EPS': 'eps',
            'Industry PE': 'industry_pe',
            '3Yrs PE': 'pe_3yrs',
            'Free Cash Flow 3Yrs': 'fcf_3yrs',
            'Price to Cash Flow': 'price_to_cash_flow',
            'Price to Earning': 'price_to_earning',
            'Price to book value': 'price_to_book',
            'Intrinsic Value': 'intrinsic_value',
            'OPM': 'opm',
            'Enterprise Value': 'enterprise_value',
            'PEG Ratio': 'peg_ratio',
            'Earning Power': 'earning_power',
            'Net block': 'net_block',
            'Price to Sales': 'price_to_sales',
            'Int Coverage': 'interest_coverage',
            'Asset Turnover': 'asset_turnover'
        }
        
    def _get_session(self):
        """Get thread-local session"""
        if not hasattr(self.session_local, 'session'):
            session = requests.Session()
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'Cache-Control': 'max-age=0',
            })
            self.session_local.session = session
        return self.session_local.session
        
    def _rate_limit(self):
        """Implement rate limiting"""
        with self.request_lock:
            current_time = time.time()
            time_since_last = current_time - self.last_request_time
            min_delay = self.delay_range[0]
            
            if time_since_last < min_delay:
                sleep_time = min_delay - time_since_last
                time.sleep(sleep_time)
                
            self.last_request_time = time.time()
            
    def _delay(self):
        """Add random delay between requests"""
        delay = random.uniform(*self.delay_range)
        time.sleep(delay)
        
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text data with proper Unicode handling"""
        if not text:
            return ""
        
        # Fix common Unicode encoding issues
        # Replace incorrectly encoded Rupee symbol
        text = text.replace('â‚¹', '₹')
        text = text.replace('â€"', '—')  # em dash
        text = text.replace('â€"', '–')  # en dash
        text = text.replace('â€™', "'")   # apostrophe
        text = text.replace('â€œ', '"')   # left double quote
        text = text.replace('â€', '"')    # right double quote
        
        # Remove extra whitespace and normalize
        text = re.sub(r'\s+', ' ', text.strip())
        return text
        
    def _extract_number(self, text: str) -> Optional[float]:
        """Extract numeric value from text, handling currency symbols and units"""
        if not text:
            return None
            
        # Clean the text first to fix Unicode issues
        text = self._clean_text(text)
            
        # Remove currency symbols and common text (including both correct and incorrect Rupee symbols)
        text = re.sub(r'[₹$€£]', '', text)
        text = re.sub(r'â‚¹', '', text)  # Remove incorrectly encoded Rupee symbol
        text = re.sub(r'\s*(Cr\.|Cr|Lakh|Lac|Million|Billion)\s*', '', text, flags=re.IGNORECASE)
        text = re.sub(r'\s*%\s*', '', text)
        
        # Extract numbers (including decimals and negative numbers)
        numbers = re.findall(r'-?\d+\.?\d*', text)
        if numbers:
            try:
                return float(numbers[0])
            except ValueError:
                return None
        return None
        
    def _extract_high_low(self, text: str) -> Tuple[Optional[float], Optional[float]]:
        """Extract high and low values from 'High / Low' format"""
        if not text:
            return None, None
            
        # Clean the text first to fix Unicode issues
        text = self._clean_text(text)
            
        # Remove currency symbol (including both correct and incorrect Rupee symbols)
        text = re.sub(r'[₹$€£]', '', text)
        text = re.sub(r'â‚¹', '', text)  # Remove incorrectly encoded Rupee symbol
        
        # Extract numbers
        numbers = re.findall(r'\d+\.?\d*', text)
        if len(numbers) >= 2:
            try:
                return float(numbers[0]), float(numbers[1])
            except ValueError:
                return None, None
        return None, None
        
    def _get_page_with_retry(self, url: str) -> Optional[BeautifulSoup]:
        """Get and parse a web page with retry logic"""
        session = self._get_session()
        
        for attempt in range(self.retry_attempts):
            try:
                # Basic rate limit and randomized jitter between requests
                self._rate_limit()
                self._delay()

                response = session.get(url, timeout=self.timeout)

                # Handle explicit rate limiting from server
                if response.status_code in (429, 403):
                    # Honor Retry-After header if present, otherwise backoff with jitter
                    retry_after_header = response.headers.get('Retry-After')
                    if retry_after_header:
                        try:
                            wait_seconds = int(float(retry_after_header))
                        except ValueError:
                            wait_seconds = 0
                    else:
                        wait_seconds = 0

                    if wait_seconds <= 0:
                        wait_seconds = min(
                            90,
                            int((2 ** attempt) * random.uniform(1.5, 3.0) + random.uniform(1, 4))
                        )

                    logger.warning(
                        f"Rate limited (HTTP {response.status_code}) for {url}. "
                        f"Sleeping ~{wait_seconds}s before retry"
                    )
                    time.sleep(wait_seconds)
                    continue

                response.raise_for_status()
                
                # Check if we got a valid HTML response
                if 'text/html' not in response.headers.get('content-type', ''):
                    logger.warning(f"Non-HTML response from {url}")
                    # Small delay then retry, as this is likely a transient block/CDN response
                    time.sleep(min(30, int((2 ** attempt) * random.uniform(0.5, 1.5))))
                    continue
                    
                return BeautifulSoup(response.content, 'html.parser')
                
            except requests.RequestException as e:
                logger.warning(f"Attempt {attempt + 1} failed for {url}: {e}")
                if attempt < self.retry_attempts - 1:
                    # Exponential backoff with jitter
                    sleep_time = min(90, (2 ** attempt) + random.uniform(1, 3))
                    time.sleep(sleep_time)
                else:
                    logger.error(f"All attempts failed for {url}: {e}")
                    return None
            except Exception as e:
                logger.error(f"Unexpected error fetching {url}: {e}")
                return None
                
        return None
        
    def extract_company_metrics(self, company_url: str) -> Dict[str, Any]:
        """
        Extract financial metrics from a company page with enhanced parsing
        
        Args:
            company_url: URL of the company page
            
        Returns:
            Dictionary containing extracted metrics
        """
        soup = self._get_page_with_retry(company_url)
        if not soup:
            return {}
            
        metrics = {
            'company_url': company_url,
            'scraped_at': datetime.now().isoformat(),
            'status': 'success'
        }
        
        # Store detailed data separately to avoid CSV issues
        detailed_data = {}
        
        try:
            # Extract company name (try multiple selectors for robustness)
            company_name = None
            
            # Try method 1: h1 with class 'company-name'
            company_name_elem = soup.find('h1', class_='company-name')
            if company_name_elem:
                company_name = self._clean_text(company_name_elem.get_text())
            
            # Try method 2: Any h1 tag in the header area
            if not company_name:
                header = soup.find('div', id='top')
                if header:
                    h1_elem = header.find('h1')
                    if h1_elem:
                        company_name = self._clean_text(h1_elem.get_text())
            
            # Try method 3: Look for h1 anywhere on page
            if not company_name:
                h1_elem = soup.find('h1')
                if h1_elem:
                    company_name = self._clean_text(h1_elem.get_text())
            
            # Fallback: Extract from URL
            if not company_name:
                symbol = self._extract_symbol_from_url(company_url)
                if symbol:
                    company_name = symbol
            
            metrics['company_name'] = company_name if company_name else 'Unknown'
            
            # Extract sector
            sector_elem = soup.find('a', class_='sector')
            if sector_elem:
                metrics['sector'] = self._clean_text(sector_elem.get_text())
            else:
                # Try alternate sector extraction
                sector_elem = soup.find('a', href=re.compile(r'/screens/'))
                if sector_elem:
                    metrics['sector'] = self._clean_text(sector_elem.get_text())
                
            # Find the company ratios section
            ratios_section = soup.find('div', class_='company-ratios')
            if not ratios_section:
                logger.warning(f"No company ratios section found on {company_url}")
                metrics['status'] = 'no_ratios_found'
                return metrics
                
            # Find all ratio items
            ratio_items = ratios_section.find_all('li', class_='flex flex-space-between')
            
            extracted_metrics = 0
            for item in ratio_items:
                name_span = item.find('span', class_='name')
                value_span = item.find('span', class_='nowrap value')
                
                if not name_span or not value_span:
                    continue
                    
                metric_name = self._clean_text(name_span.get_text())
                metric_value = self._clean_text(value_span.get_text())
                
                if not metric_name:
                    continue
                    
                # Extract numeric value
                numeric_value = self._extract_number(metric_value)
                
                # Handle special cases
                if metric_name == 'High / Low':
                    high, low = self._extract_high_low(metric_value)
                    metrics['high_price'] = high
                    metrics['low_price'] = low
                    metrics['high_low_raw'] = metric_value
                else:
                    # Use standardized column names
                    clean_name = self.metrics_mapping.get(metric_name, metric_name.lower().replace(' ', '_'))
                    metrics[clean_name] = numeric_value
                    metrics[f'{clean_name}_raw'] = metric_value
                    
                extracted_metrics += 1
                
            metrics['metrics_extracted'] = extracted_metrics
            
            # Extract quarterly data
            quarterly_data = self._extract_quarterly_data(soup)
            if quarterly_data:
                metrics['has_quarterly_data'] = True
                # Store only summary info in main metrics, not the full JSON
                metrics['quarterly_quarters_count'] = quarterly_data.get('total_quarters', 0)
                metrics['quarterly_metrics_count'] = quarterly_data.get('total_metrics', 0)
                if 'upcoming_result_date' in quarterly_data:
                    metrics['quarterly_upcoming_date'] = quarterly_data['upcoming_result_date']
                # Store detailed data separately
                detailed_data['quarterly_data'] = quarterly_data
            else:
                metrics['has_quarterly_data'] = False
                metrics['quarterly_quarters_count'] = 0
                metrics['quarterly_metrics_count'] = 0
            
            # Extract profit & loss data
            pnl_data = self._extract_profit_loss_data(soup)
            if pnl_data:
                metrics['has_pnl_data'] = True
                # Store only summary info in main metrics, not the full JSON
                metrics['pnl_years_count'] = pnl_data.get('total_years', 0)
                metrics['pnl_metrics_count'] = pnl_data.get('total_metrics', 0)
                # Store detailed data separately
                detailed_data['pnl_data'] = pnl_data
            else:
                metrics['has_pnl_data'] = False
                metrics['pnl_years_count'] = 0
                metrics['pnl_metrics_count'] = 0
            
            # Extract balance sheet data
            balance_sheet_data = self._extract_balance_sheet_data(soup)
            if balance_sheet_data:
                metrics['has_balance_sheet_data'] = True
                # Store only summary info in main metrics, not the full JSON
                metrics['balance_sheet_years_count'] = balance_sheet_data.get('total_years', 0)
                metrics['balance_sheet_metrics_count'] = balance_sheet_data.get('total_metrics', 0)
                # Store detailed data separately
                detailed_data['balance_sheet_data'] = balance_sheet_data
            else:
                metrics['has_balance_sheet_data'] = False
                metrics['balance_sheet_years_count'] = 0
                metrics['balance_sheet_metrics_count'] = 0
            
            # Extract cash flow data
            cash_flow_data = self._extract_cash_flow_data(soup)
            if cash_flow_data:
                metrics['has_cash_flow_data'] = True
                metrics['cash_flow_years_count'] = cash_flow_data.get('total_years', 0)
                metrics['cash_flow_metrics_count'] = cash_flow_data.get('total_metrics', 0)
                detailed_data['cash_flow_data'] = cash_flow_data
            else:
                metrics['has_cash_flow_data'] = False
                metrics['cash_flow_years_count'] = 0
                metrics['cash_flow_metrics_count'] = 0
            
            # Extract documents (annual reports, concalls)
            documents_data = self._extract_documents(soup)
            if documents_data:
                metrics['has_documents'] = True
                metrics['total_annual_reports'] = documents_data.get('total_annual_reports', 0)
                metrics['total_concalls'] = documents_data.get('total_concalls', 0)
                metrics['total_documents'] = documents_data.get('total_documents', 0)
                
                # Store latest document URLs for easy access
                if 'latest_annual_report' in documents_data:
                    metrics['latest_annual_report_url'] = documents_data['latest_annual_report'].get('url', '')
                    metrics['latest_annual_report_year'] = documents_data['latest_annual_report'].get('year', '')
                if 'latest_concall' in documents_data:
                    metrics['latest_concall_url'] = documents_data['latest_concall'].get('url', '')
                    metrics['latest_concall_period'] = documents_data['latest_concall'].get('period', '')
                
                detailed_data['documents'] = documents_data
            else:
                metrics['has_documents'] = False
                metrics['total_annual_reports'] = 0
                metrics['total_concalls'] = 0
                metrics['total_documents'] = 0
            
            # Extract additional information if available
            self._extract_additional_info(soup, metrics)
            
            # Store detailed data in metrics for later processing
            if detailed_data:
                metrics['_detailed_data'] = detailed_data
            
        except Exception as e:
            logger.error(f"Error processing {company_url}: {e}")
            metrics['status'] = 'processing_error'
            metrics['error'] = str(e)
            
        return metrics
        
    def _extract_quarterly_data(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """
        Extract quarterly financial data from the quarters section
        
        Args:
            soup: BeautifulSoup object of the company page
            
        Returns:
            Dictionary containing quarterly data
        """
        quarterly_data = {}
        
        try:
            # Find the quarters section
            quarters_section = soup.find('section', id='quarters')
            if not quarters_section:
                logger.debug("No quarters section found")
                return {}
                
            # Find the quarterly results table
            table = quarters_section.find('table', class_='data-table')
            if not table:
                logger.debug("No quarterly data table found")
                return {}
                
            # Extract column headers (quarters)
            headers = []
            header_row = table.find('thead').find('tr')
            if header_row:
                header_cells = header_row.find_all('th')
                for cell in header_cells:
                    header_text = self._clean_text(cell.get_text())
                    if header_text and header_text != '':
                        headers.append(header_text)
            
            # Extract data rows
            data_rows = []
            tbody = table.find('tbody')
            if tbody:
                rows = tbody.find_all('tr')
                for row in rows:
                    # Skip the PDF links row
                    if 'font-size-14' in row.get('class', []):
                        continue
                        
                    cells = row.find_all(['td', 'th'])
                    if len(cells) > 1:  # Must have at least metric name and one value
                        metric_name = self._clean_text(cells[0].get_text())
                        if metric_name and metric_name != 'Raw PDF':
                            row_data = {'metric': metric_name}
                            
                            # Extract values for each quarter
                            for i, cell in enumerate(cells[1:], 1):
                                if i <= len(headers):
                                    quarter = headers[i-1]
                                    value_text = self._clean_text(cell.get_text())
                                    numeric_value = self._extract_number(value_text)
                                    row_data[quarter] = numeric_value
                                    row_data[f'{quarter}_raw'] = value_text
                            
                            data_rows.append(row_data)
            
            quarterly_data = {
                'quarters': headers,
                'data': data_rows,
                'total_quarters': len(headers),
                'total_metrics': len(data_rows)
            }
            
            # Extract upcoming result date if available
            upcoming_elem = quarters_section.find('span', class_='badge')
            if upcoming_elem:
                upcoming_text = self._clean_text(upcoming_elem.get_text())
                if 'Upcoming result date:' in upcoming_text:
                    date_match = re.search(r'(\d{1,2}\s+\w+\s+\d{4})', upcoming_text)
                    if date_match:
                        quarterly_data['upcoming_result_date'] = date_match.group(1)
            
            logger.info(f"Extracted quarterly data: {len(headers)} quarters, {len(data_rows)} metrics")
            return quarterly_data
            
        except Exception as e:
            logger.error(f"Error extracting quarterly data: {e}")
            return {}

    def _extract_profit_loss_data(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """
        Extract year-wise Profit & Loss data from the profit-loss section
        
        Args:
            soup: BeautifulSoup object of the company page
            
        Returns:
            Dictionary containing P&L data
        """
        pnl_data = {}
        
        try:
            # Find the profit-loss section
            pnl_section = soup.find('section', id='profit-loss')
            if not pnl_section:
                logger.debug("No profit-loss section found")
                return {}
                
            # Find the P&L data table
            table = pnl_section.find('table', class_='data-table')
            if not table:
                logger.debug("No P&L data table found")
                return {}
                
            # Extract column headers (years)
            headers = []
            header_row = table.find('thead').find('tr')
            if header_row:
                header_cells = header_row.find_all('th')
                for cell in header_cells:
                    header_text = self._clean_text(cell.get_text())
                    if header_text and header_text != '':
                        headers.append(header_text)
            
            # Extract data rows
            data_rows = []
            tbody = table.find('tbody')
            if tbody:
                rows = tbody.find_all('tr')
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) > 1:  # Must have at least metric name and one value
                        metric_name = self._clean_text(cells[0].get_text())
                        if metric_name and metric_name != '':
                            row_data = {'metric': metric_name}
                            
                            # Extract values for each year
                            for i, cell in enumerate(cells[1:], 1):
                                if i <= len(headers):
                                    year = headers[i-1]
                                    value_text = self._clean_text(cell.get_text())
                                    numeric_value = self._extract_number(value_text)
                                    row_data[year] = numeric_value
                                    row_data[f'{year}_raw'] = value_text
                            
                            data_rows.append(row_data)
            
            pnl_data = {
                'years': headers,
                'data': data_rows,
                'total_years': len(headers),
                'total_metrics': len(data_rows)
            }
            
            # Extract growth metrics if available
            growth_tables = pnl_section.find_all('table', class_='ranges-table')
            growth_metrics = {}
            
            for table in growth_tables:
                rows = table.find_all('tr')
                if rows:
                    # Get table title
                    title_cell = rows[0].find('th')
                    if title_cell:
                        title = self._clean_text(title_cell.get_text())
                        
                        # Extract growth data
                        growth_data = {}
                        for row in rows[1:]:  # Skip header row
                            cells = row.find_all(['td', 'th'])
                            if len(cells) >= 2:
                                period = self._clean_text(cells[0].get_text())
                                value = self._clean_text(cells[1].get_text())
                                growth_data[period] = value
                        
                        growth_metrics[title] = growth_data
            
            pnl_data['growth_metrics'] = growth_metrics
            
            logger.info(f"Extracted P&L data: {len(headers)} years, {len(data_rows)} metrics")
            return pnl_data
            
        except Exception as e:
            logger.error(f"Error extracting P&L data: {e}")
            return {}
    
    def _extract_balance_sheet_data(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """
        Extract year-wise Balance Sheet data from the balance-sheet section
        
        Args:
            soup: BeautifulSoup object of the company page
            
        Returns:
            Dictionary containing Balance Sheet data
        """
        balance_sheet_data = {}
        
        try:
            # Find the balance-sheet section
            balance_sheet_section = soup.find('section', id='balance-sheet')
            if not balance_sheet_section:
                logger.debug("No balance-sheet section found")
                return {}
                
            # Find the Balance Sheet data table
            table = balance_sheet_section.find('table', class_='data-table')
            if not table:
                logger.debug("No Balance Sheet data table found")
                return {}
                
            # Extract column headers (years)
            headers = []
            header_row = table.find('thead').find('tr')
            if header_row:
                header_cells = header_row.find_all('th')
                for cell in header_cells:
                    header_text = self._clean_text(cell.get_text())
                    if header_text and header_text != '':
                        headers.append(header_text)
            
            # Extract data rows
            data_rows = []
            tbody = table.find('tbody')
            if tbody:
                rows = tbody.find_all('tr')
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) > 1:  # Must have at least metric name and one value
                        metric_name = self._clean_text(cells[0].get_text())
                        if metric_name and metric_name != '':
                            row_data = {'metric': metric_name}
                            
                            # Extract values for each year
                            for i, cell in enumerate(cells[1:], 1):
                                if i <= len(headers):
                                    year = headers[i-1]
                                    value_text = self._clean_text(cell.get_text())
                                    numeric_value = self._extract_number(value_text)
                                    row_data[year] = numeric_value
                                    row_data[f'{year}_raw'] = value_text
                            
                            data_rows.append(row_data)
            
            balance_sheet_data = {
                'years': headers,
                'data': data_rows,
                'total_years': len(headers),
                'total_metrics': len(data_rows)
            }
            
            # Extract growth metrics if available
            growth_tables = balance_sheet_section.find_all('table', class_='ranges-table')
            growth_metrics = {}
            
            for table in growth_tables:
                rows = table.find_all('tr')
                if rows:
                    # Get table title
                    title_cell = rows[0].find('th')
                    if title_cell:
                        title = self._clean_text(title_cell.get_text())
                        
                        # Extract growth data
                        growth_data = {}
                        for row in rows[1:]:  # Skip header row
                            cells = row.find_all(['td', 'th'])
                            if len(cells) >= 2:
                                period = self._clean_text(cells[0].get_text())
                                value = self._clean_text(cells[1].get_text())
                                growth_data[period] = value
                        
                        growth_metrics[title] = growth_data
            
            balance_sheet_data['growth_metrics'] = growth_metrics
            
            logger.info(f"Extracted Balance Sheet data: {len(headers)} years, {len(data_rows)} metrics")
            return balance_sheet_data
            
        except Exception as e:
            logger.error(f"Error extracting Balance Sheet data: {e}")
            return {}
    
    def _extract_cash_flow_data(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """
        Extract year-wise Cash Flow data from the cash-flow section
        
        Args:
            soup: BeautifulSoup object of the company page
            
        Returns:
            Dictionary containing Cash Flow data
        """
        cash_flow_data: Dict[str, Any] = {}
        
        try:
            # Find the cash-flow section
            cash_flow_section = soup.find('section', id='cash-flow')
            if not cash_flow_section:
                logger.debug("No cash-flow section found")
                return {}
            
            # Find the Cash Flow data table
            table = cash_flow_section.find('table', class_='data-table')
            if not table:
                logger.debug("No Cash Flow data table found")
                return {}
            
            # Extract column headers (years)
            headers: List[str] = []
            header_row = table.find('thead').find('tr')
            if header_row:
                header_cells = header_row.find_all('th')
                for cell in header_cells:
                    header_text = self._clean_text(cell.get_text())
                    if header_text and header_text != '':
                        headers.append(header_text)
            
            # Extract data rows
            data_rows: List[Dict[str, Any]] = []
            tbody = table.find('tbody')
            if tbody:
                rows = tbody.find_all('tr')
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) > 1:  # Must have at least metric name and one value
                        metric_name = self._clean_text(cells[0].get_text())
                        if metric_name and metric_name != '':
                            row_data: Dict[str, Any] = {'metric': metric_name}
                            
                            # Extract values for each year
                            for i, cell in enumerate(cells[1:], 1):
                                if i <= len(headers):
                                    year = headers[i-1]
                                    value_text = self._clean_text(cell.get_text())
                                    numeric_value = self._extract_number(value_text)
                                    row_data[year] = numeric_value
                                    row_data[f'{year}_raw'] = value_text
                            
                            data_rows.append(row_data)
            
            cash_flow_data = {
                'years': headers,
                'data': data_rows,
                'total_years': len(headers),
                'total_metrics': len(data_rows)
            }
            
            logger.info(f"Extracted Cash Flow data: {len(headers)} years, {len(data_rows)} metrics")
            return cash_flow_data
            
        except Exception as e:
            logger.error(f"Error extracting Cash Flow data: {e}")
            return {}
    
    def _extract_documents(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """
        Extract documents (Annual Reports, Concalls, etc.) from the Documents section
        
        Args:
            soup: BeautifulSoup object of the company page
            
        Returns:
            Dictionary containing document links and metadata
        """
        documents_data = {
            'annual_reports': [],
            'concalls': [],
            'other_documents': []
        }
        
        try:
            # Find the documents section
            documents_section = soup.find('section', id='documents')
            if not documents_section:
                logger.debug("No documents section found")
                return {}
            
            # Find all document links
            doc_links = documents_section.find_all('a', href=True)
            
            for link in doc_links:
                href = link.get('href', '')
                text = self._clean_text(link.get_text())
                
                if not href or not text:
                    continue
                
                # Build full URL
                full_url = urljoin(self.base_url, href) if not href.startswith('http') else href
                
                # Categorize documents
                text_lower = text.lower()
                doc_info = {
                    'title': text,
                    'url': full_url,
                    'type': ''
                }
                
                # Identify annual reports
                if 'annual report' in text_lower or 'annual-report' in href.lower():
                    # Extract year if possible
                    year_match = re.search(r'20\d{2}', text)
                    if year_match:
                        doc_info['year'] = year_match.group(0)
                    doc_info['type'] = 'annual_report'
                    documents_data['annual_reports'].append(doc_info)
                
                # Identify concalls/earnings calls
                elif any(keyword in text_lower for keyword in ['concall', 'earnings call', 'investor call', 'conference call']):
                    # Extract quarter/year if possible
                    quarter_match = re.search(r'Q[1-4]\s*(?:FY)?20\d{2}', text, re.IGNORECASE)
                    if quarter_match:
                        doc_info['period'] = quarter_match.group(0)
                    year_match = re.search(r'20\d{2}', text)
                    if year_match:
                        doc_info['year'] = year_match.group(0)
                    doc_info['type'] = 'concall'
                    documents_data['concalls'].append(doc_info)
                
                # Other documents (presentations, notices, etc.)
                else:
                    doc_info['type'] = 'other'
                    documents_data['other_documents'].append(doc_info)
            
            # Get counts
            total_docs = len(documents_data['annual_reports']) + len(documents_data['concalls']) + len(documents_data['other_documents'])
            
            if total_docs > 0:
                logger.info(f"Extracted documents: {len(documents_data['annual_reports'])} annual reports, {len(documents_data['concalls'])} concalls, {len(documents_data['other_documents'])} other")
                
                # Add summary counts
                documents_data['total_annual_reports'] = len(documents_data['annual_reports'])
                documents_data['total_concalls'] = len(documents_data['concalls'])
                documents_data['total_documents'] = total_docs
                
                # Get latest documents
                if documents_data['annual_reports']:
                    documents_data['latest_annual_report'] = documents_data['annual_reports'][0]
                if documents_data['concalls']:
                    documents_data['latest_concall'] = documents_data['concalls'][0]
            
            return documents_data
            
        except Exception as e:
            logger.error(f"Error extracting documents: {e}")
            return {}
    
    def _extract_additional_info(self, soup: BeautifulSoup, metrics: Dict[str, Any]):
        """Extract additional information from the page"""
        try:
            # Extract company description
            desc_elem = soup.find('div', class_='company-description')
            if desc_elem:
                metrics['description'] = self._clean_text(desc_elem.get_text())
                
            # Extract stock exchange info
            exchange_elem = soup.find('span', class_='exchange')
            if exchange_elem:
                metrics['exchange'] = self._clean_text(exchange_elem.get_text())
                
            # Extract market cap category
            cap_elem = soup.find('span', class_='market-cap')
            if cap_elem:
                metrics['market_cap_category'] = self._clean_text(cap_elem.get_text())
                
        except Exception as e:
            logger.warning(f"Error extracting additional info: {e}")
            
    def get_company_list(self, list_url: str = None) -> List[str]:
        """
        Get list of company URLs to scrape
        
        Args:
            list_url: URL of the page containing company links
            
        Returns:
            List of company URLs
        """
        if not list_url:
            # Default to NSE 500 companies page
            list_url = f"{self.base_url}/screener/equity/"
            
        soup = self._get_page_with_retry(list_url)
        if not soup:
            return []
            
        company_urls = []
        
        # Find company links (adjust selector based on actual page structure)
        company_links = soup.find_all('a', href=re.compile(r'/company/[^/]+/$'))
        
        for link in company_links:
            href = link.get('href')
            if href:
                full_url = urljoin(self.base_url, href)
                company_urls.append(full_url)
                
        logger.info(f"Found {len(company_urls)} companies to scrape")
        return company_urls
        
    def scrape_companies_parallel(self, company_urls: List[str] = None, max_companies: int = None) -> pd.DataFrame:
        """
        Scrape financial metrics for multiple companies using parallel processing
        
        Args:
            company_urls: List of company URLs to scrape
            max_companies: Maximum number of companies to scrape (for testing)
            
        Returns:
            DataFrame containing all extracted metrics
        """
        if company_urls is None:
            company_urls = self.get_company_list()
            
        if max_companies:
            company_urls = company_urls[:max_companies]
            
        all_metrics = []
        successful_scrapes = 0
        failed_scrapes = 0
        
        logger.info(f"Starting to scrape {len(company_urls)} companies with {self.max_workers} workers")
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all scraping tasks
            future_to_url = {executor.submit(self.extract_company_metrics, url): url 
                           for url in company_urls}
            
            # Process completed tasks
            for future in as_completed(future_to_url):
                url = future_to_url[future]
                try:
                    metrics = future.result()
                    if metrics and metrics.get('status') == 'success':
                        all_metrics.append(metrics)
                        successful_scrapes += 1
                        company_name = metrics.get('company_name', 'Unknown')
                        logger.info(f"Successfully scraped: {company_name}")
                    else:
                        failed_scrapes += 1
                        logger.warning(f"Failed to extract metrics from {url}")
                except Exception as e:
                    failed_scrapes += 1
                    logger.error(f"Error scraping {url}: {e}")
                    
        logger.info(f"Scraping completed. Successful: {successful_scrapes}, Failed: {failed_scrapes}")
        
        if all_metrics:
            df = pd.DataFrame(all_metrics)
            return df
        else:
            logger.warning("No data was scraped successfully")
            return pd.DataFrame()
            
    def save_to_csv(self, df: pd.DataFrame, filename: str = None) -> str:
        """
        Save scraped data to CSV file with enhanced formatting
        
        Args:
            df: DataFrame to save
            filename: Output filename (auto-generated if None)
            
        Returns:
            Path to saved file
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"advanced_screener_metrics_{timestamp}.csv"
            
        # Create output directory if it doesn't exist
        os.makedirs('output', exist_ok=True)
        filepath = os.path.join('output', filename)
        
        # Create a clean DataFrame for CSV export (without JSON data)
        df_clean = df.copy()
        
        # Remove JSON columns that cause CSV issues
        json_columns = ['quarterly_data', 'pnl_data', 'balance_sheet_data', '_detailed_data']
        for col in json_columns:
            if col in df_clean.columns:
                df_clean = df_clean.drop(columns=[col])
        
        # Reorder columns for better readability
        column_order = [
            'company_name', 'sector', 'company_url', 'scraped_at', 'status',
            'current_price', 'market_cap', 'pe_ratio', 'book_value', 'eps',
            'roe', 'roce', 'dividend_yield', 'high_price', 'low_price',
            'industry_pe', 'pe_3yrs', 'price_to_book', 'price_to_sales',
            'enterprise_value', 'peg_ratio', 'opm', 'earning_power',
            'fcf_3yrs', 'price_to_cash_flow', 'intrinsic_value',
            'net_block', 'interest_coverage', 'asset_turnover',
            'face_value', 'price_to_earning', 'metrics_extracted',
            'has_quarterly_data', 'quarterly_quarters_count', 'quarterly_metrics_count', 'quarterly_upcoming_date',
            'has_pnl_data', 'pnl_years_count', 'pnl_metrics_count',
            'has_balance_sheet_data', 'balance_sheet_years_count', 'balance_sheet_metrics_count',
            'has_cash_flow_data', 'cash_flow_years_count', 'cash_flow_metrics_count',
            'has_documents', 'total_annual_reports', 'total_concalls', 'total_documents',
            'latest_annual_report_url', 'latest_annual_report_year',
            'latest_concall_url', 'latest_concall_period'
        ]
        
        # Add any missing columns to the end
        existing_columns = [col for col in column_order if col in df_clean.columns]
        remaining_columns = [col for col in df_clean.columns if col not in column_order]
        final_column_order = existing_columns + remaining_columns
        
        # Reorder DataFrame
        df_ordered = df_clean[final_column_order] if final_column_order else df_clean
        
        # Save with proper UTF-8 encoding and BOM for better Excel compatibility
        df_ordered.to_csv(filepath, index=False, encoding='utf-8-sig')
        logger.info(f"Data saved to {filepath}")
        
        # Save quarterly data separately if available
        self._save_quarterly_data(df, filepath)
        
        # Save P&L data separately if available
        self._save_pnl_data(df, filepath)
        
        # Save Balance Sheet data separately if available
        self._save_balance_sheet_data(df, filepath)
        
        # Save Cash Flow data separately if available
        self._save_cash_flow_data(df, filepath)
        
        # Save documents data separately if available
        self._save_documents_data(df, filepath)
        
        # Also save a summary
        self._save_summary(df_ordered, filepath)
        
        return filepath
        
    def _extract_symbol_from_url(self, company_url: str) -> Optional[str]:
        """Extract the company symbol from a Screener company URL."""
        if not company_url:
            return None
        try:
            parsed = urlparse(company_url)
            parts = [p for p in parsed.path.split('/') if p]
            # Expected: ["company", "SYMBOL"]
            if len(parts) >= 2 and parts[0] == 'company':
                return parts[1]
        except Exception:
            return None
        return None

    def _safe_company_basename(self, company: pd.Series) -> str:
        """Create a unique, filesystem-safe base name for per-company files.

        Preference order: symbol from URL → sanitized company name → "company".
        """
        raw_name = company.get('company_name', '') or ''
        raw_url = company.get('company_url', '') or ''
        symbol = self._extract_symbol_from_url(raw_url) or ''

        # Sanitize
        safe_name = re.sub(r'[^\w\s-]', '', str(raw_name)).strip()
        safe_name = re.sub(r'[-\s]+', '_', safe_name) if safe_name else ''
        safe_symbol = re.sub(r'[^A-Za-z0-9_]', '', str(symbol)) if symbol else ''

        if safe_symbol:
            return safe_symbol
        if safe_name:
            return safe_name
        return 'company'

    def _save_quarterly_data(self, df: pd.DataFrame, csv_filepath: str):
        """Save quarterly data to separate files"""
        try:
            # Filter companies with quarterly data
            companies_with_quarterly = df[df['has_quarterly_data'] == True]
            
            if companies_with_quarterly.empty:
                logger.info("No companies with quarterly data found")
                return
                
            # Create quarterly data directory
            quarterly_dir = os.path.join('output', 'quarterly_data')
            os.makedirs(quarterly_dir, exist_ok=True)
            
            # Save quarterly data for each company
            for _, company in companies_with_quarterly.iterrows():
                company_name = company.get('company_name', 'Unknown')
                detailed_data = company.get('_detailed_data', {})
                quarterly_data = detailed_data.get('quarterly_data', {})
                
                if quarterly_data and 'data' in quarterly_data:
                    # Create filename for this company (unique and safe)
                    base = self._safe_company_basename(company)
                    quarterly_file = os.path.join(quarterly_dir, f"{base}_quarterly.csv")
                    
                    # Convert quarterly data to DataFrame
                    quarterly_df = pd.DataFrame(quarterly_data['data'])
                    
                    if not quarterly_df.empty:
                        # Add company info
                        quarterly_df['company_name'] = company_name
                        quarterly_df['company_url'] = company.get('company_url', '')
                        quarterly_df['scraped_at'] = company.get('scraped_at', '')
                        
                        # Reorder columns
                        cols = ['company_name', 'company_url', 'scraped_at', 'metric'] + [col for col in quarterly_df.columns if col not in ['company_name', 'company_url', 'scraped_at', 'metric']]
                        quarterly_df = quarterly_df[cols]
                        
                        quarterly_df.to_csv(quarterly_file, index=False, encoding='utf-8-sig')
                        logger.info(f"Quarterly data saved for {base}: {quarterly_file}")
            
            # Create a consolidated quarterly summary
            self._save_quarterly_summary(companies_with_quarterly, quarterly_dir)
            
        except Exception as e:
            logger.error(f"Error saving quarterly data: {e}")
    
    def _save_quarterly_summary(self, companies_df: pd.DataFrame, quarterly_dir: str):
        """Save a summary of quarterly data"""
        try:
            summary_file = os.path.join(quarterly_dir, 'quarterly_summary.txt')
            
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write("Quarterly Data Summary\n")
                f.write("=" * 30 + "\n\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Companies with quarterly data: {len(companies_df)}\n\n")
                
                for _, company in companies_df.iterrows():
                    company_name = company.get('company_name', 'Unknown')
                    detailed_data = company.get('_detailed_data', {})
                    quarterly_data = detailed_data.get('quarterly_data', {})
                    
                    f.write(f"Company: {company_name}\n")
                    f.write(f"  Quarters: {quarterly_data.get('total_quarters', 0)}\n")
                    f.write(f"  Metrics: {quarterly_data.get('total_metrics', 0)}\n")
                    
                    if 'upcoming_result_date' in quarterly_data:
                        f.write(f"  Upcoming Result: {quarterly_data['upcoming_result_date']}\n")
                    
                    f.write("\n")
                    
            logger.info(f"Quarterly summary saved to {summary_file}")
            
        except Exception as e:
            logger.error(f"Error saving quarterly summary: {e}")
        
    def _save_pnl_data(self, df: pd.DataFrame, csv_filepath: str):
        """Save P&L data to separate files"""
        try:
            # Filter companies with P&L data
            companies_with_pnl = df[df['has_pnl_data'] == True]
            
            if companies_with_pnl.empty:
                logger.info("No companies with P&L data found")
                return
                
            # Create P&L data directory
            pnl_dir = os.path.join('output', 'pnl_data')
            os.makedirs(pnl_dir, exist_ok=True)
            
            # Save P&L data for each company
            for _, company in companies_with_pnl.iterrows():
                company_name = company.get('company_name', 'Unknown')
                detailed_data = company.get('_detailed_data', {})
                pnl_data = detailed_data.get('pnl_data', {})
                
                if pnl_data and 'data' in pnl_data:
                    # Create filename for this company (unique and safe)
                    base = self._safe_company_basename(company)
                    pnl_file = os.path.join(pnl_dir, f"{base}_pnl.csv")
                    
                    # Convert P&L data to DataFrame
                    pnl_df = pd.DataFrame(pnl_data['data'])
                    
                    if not pnl_df.empty:
                        # Add company info
                        pnl_df['company_name'] = company_name
                        pnl_df['company_url'] = company.get('company_url', '')
                        pnl_df['scraped_at'] = company.get('scraped_at', '')
                        
                        # Reorder columns
                        cols = ['company_name', 'company_url', 'scraped_at', 'metric'] + [col for col in pnl_df.columns if col not in ['company_name', 'company_url', 'scraped_at', 'metric']]
                        pnl_df = pnl_df[cols]
                        
                        pnl_df.to_csv(pnl_file, index=False, encoding='utf-8-sig')
                        # Use symbol from filename instead of possibly missing company_name
                        logger.info(f"P&L data saved for {base}: {pnl_file}")
            
            # Create a consolidated P&L summary
            self._save_pnl_summary(companies_with_pnl, pnl_dir)
            
        except Exception as e:
            logger.error(f"Error saving P&L data: {e}")
    
    def _save_pnl_summary(self, companies_df: pd.DataFrame, pnl_dir: str):
        """Save a summary of P&L data"""
        try:
            summary_file = os.path.join(pnl_dir, 'pnl_summary.txt')
            
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write("Profit & Loss Summary\n")
                f.write("=" * 20 + "\n\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Companies with P&L data: {len(companies_df)}\n\n")
                
                for _, company in companies_df.iterrows():
                    company_name = company.get('company_name', 'Unknown')
                    detailed_data = company.get('_detailed_data', {})
                    pnl_data = detailed_data.get('pnl_data', {})
                    
                    f.write(f"Company: {company_name}\n")
                    f.write(f"  Years: {pnl_data.get('total_years', 0)}\n")
                    f.write(f"  Metrics: {pnl_data.get('total_metrics', 0)}\n")
                    
                    if 'upcoming_result_date' in pnl_data:
                        f.write(f"  Upcoming Result: {pnl_data['upcoming_result_date']}\n")
                    
                    f.write("\n")
                    
            logger.info(f"P&L summary saved to {summary_file}")
            
        except Exception as e:
            logger.error(f"Error saving P&L summary: {e}")
    
    def _save_balance_sheet_data(self, df: pd.DataFrame, csv_filepath: str):
        """Save Balance Sheet data to separate files"""
        try:
            # Filter companies with Balance Sheet data
            companies_with_balance_sheet = df[df['has_balance_sheet_data'] == True]
            
            if companies_with_balance_sheet.empty:
                logger.info("No companies with Balance Sheet data found")
                return
                
            # Create Balance Sheet data directory
            balance_sheet_dir = os.path.join('output', 'balance_sheet_data')
            os.makedirs(balance_sheet_dir, exist_ok=True)
            
            # Save Balance Sheet data for each company
            for _, company in companies_with_balance_sheet.iterrows():
                company_name = company.get('company_name', 'Unknown')
                detailed_data = company.get('_detailed_data', {})
                balance_sheet_data = detailed_data.get('balance_sheet_data', {})
                
                if balance_sheet_data and 'data' in balance_sheet_data:
                    # Create filename for this company (unique and safe)
                    base = self._safe_company_basename(company)
                    balance_sheet_file = os.path.join(balance_sheet_dir, f"{base}_balance_sheet.csv")
                    
                    # Convert Balance Sheet data to DataFrame
                    balance_sheet_df = pd.DataFrame(balance_sheet_data['data'])
                    
                    if not balance_sheet_df.empty:
                        # Add company info
                        balance_sheet_df['company_name'] = company_name
                        balance_sheet_df['company_url'] = company.get('company_url', '')
                        balance_sheet_df['scraped_at'] = company.get('scraped_at', '')
                        
                        # Reorder columns
                        cols = ['company_name', 'company_url', 'scraped_at', 'metric'] + [col for col in balance_sheet_df.columns if col not in ['company_name', 'company_url', 'scraped_at', 'metric']]
                        balance_sheet_df = balance_sheet_df[cols]
                        
                        balance_sheet_df.to_csv(balance_sheet_file, index=False, encoding='utf-8-sig')
                        logger.info(f"Balance Sheet data saved for {base}: {balance_sheet_file}")
            
            # Create a consolidated Balance Sheet summary
            self._save_balance_sheet_summary(companies_with_balance_sheet, balance_sheet_dir)
            
        except Exception as e:
            logger.error(f"Error saving Balance Sheet data: {e}")
    
    def _save_cash_flow_data(self, df: pd.DataFrame, csv_filepath: str):
        """Save Cash Flow data to separate files"""
        try:
            # Filter companies with Cash Flow data
            companies_with_cf = df[df['has_cash_flow_data'] == True]
            
            if companies_with_cf.empty:
                logger.info("No companies with Cash Flow data found")
                return
                
            # Create Cash Flow data directory
            cf_dir = os.path.join('output', 'cash_flow_data')
            os.makedirs(cf_dir, exist_ok=True)
            
            # Save Cash Flow data for each company
            for _, company in companies_with_cf.iterrows():
                company_name = company.get('company_name', 'Unknown')
                detailed_data = company.get('_detailed_data', {})
                cf_data = detailed_data.get('cash_flow_data', {})
                
                if cf_data and 'data' in cf_data:
                    # Create filename for this company (unique and safe)
                    base = self._safe_company_basename(company)
                    cf_file = os.path.join(cf_dir, f"{base}_cash_flow.csv")
                    
                    # Convert cash flow data to DataFrame
                    cf_df = pd.DataFrame(cf_data['data'])
                    
                    if not cf_df.empty:
                        # Add company info
                        cf_df['company_name'] = company_name
                        cf_df['company_url'] = company.get('company_url', '')
                        cf_df['scraped_at'] = company.get('scraped_at', '')
                        
                        # Reorder columns
                        cols = ['company_name', 'company_url', 'scraped_at', 'metric'] + [col for col in cf_df.columns if col not in ['company_name', 'company_url', 'scraped_at', 'metric']]
                        cf_df = cf_df[cols]
                        
                        cf_df.to_csv(cf_file, index=False, encoding='utf-8-sig')
                        logger.info(f"Cash Flow data saved for {base}: {cf_file}")
            
            # Create a consolidated Cash Flow summary
            self._save_cash_flow_summary(companies_with_cf, cf_dir)
            
        except Exception as e:
            logger.error(f"Error saving Cash Flow data: {e}")

    def _save_cash_flow_summary(self, companies_df: pd.DataFrame, cf_dir: str):
        """Save a summary of Cash Flow data"""
        try:
            summary_file = os.path.join(cf_dir, 'cash_flow_summary.txt')
            
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write("Cash Flow Summary\n")
                f.write("=" * 20 + "\n\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Companies with Cash Flow data: {len(companies_df)}\n\n")
                
                for _, company in companies_df.iterrows():
                    company_name = company.get('company_name', 'Unknown')
                    detailed_data = company.get('_detailed_data', {})
                    cf_data = detailed_data.get('cash_flow_data', {})
                    
                    f.write(f"Company: {company_name}\n")
                    f.write(f"  Years: {cf_data.get('total_years', 0)}\n")
                    f.write(f"  Metrics: {cf_data.get('total_metrics', 0)}\n")
                    f.write("\n")
            
            logger.info(f"Cash Flow summary saved to {summary_file}")
            
        except Exception as e:
            logger.error(f"Error saving Cash Flow summary: {e}")
    
    def _save_documents_data(self, df: pd.DataFrame, csv_filepath: str):
        """Save documents data (Annual Reports, Concalls) to separate files"""
        try:
            # Filter companies with documents data
            companies_with_docs = df[df['has_documents'] == True]
            
            if companies_with_docs.empty:
                logger.info("No companies with documents data found")
                return
            
            # Create documents directory
            docs_dir = os.path.join('output', 'documents')
            os.makedirs(docs_dir, exist_ok=True)
            
            # Create separate directory for document links CSV
            all_documents = []
            
            # Extract and save documents for each company
            for _, company in companies_with_docs.iterrows():
                company_name = company.get('company_name', 'Unknown')
                detailed_data = company.get('_detailed_data', {})
                documents_data = detailed_data.get('documents', {})
                
                if documents_data:
                    base = self._safe_company_basename(company)
                    company_url = company.get('company_url', '')
                    
                    # Add annual reports to list
                    for doc in documents_data.get('annual_reports', []):
                        all_documents.append({
                            'company': base,
                            'company_name': company_name,
                            'company_url': company_url,
                            'doc_type': 'Annual Report',
                            'title': doc.get('title', ''),
                            'url': doc.get('url', ''),
                            'year': doc.get('year', ''),
                            'period': ''
                        })
                    
                    # Add concalls to list
                    for doc in documents_data.get('concalls', []):
                        all_documents.append({
                            'company': base,
                            'company_name': company_name,
                            'company_url': company_url,
                            'doc_type': 'Concall',
                            'title': doc.get('title', ''),
                            'url': doc.get('url', ''),
                            'year': doc.get('year', ''),
                            'period': doc.get('period', '')
                        })
            
            # Save all documents to a single CSV
            if all_documents:
                docs_df = pd.DataFrame(all_documents)
                docs_file = os.path.join(docs_dir, 'all_documents.csv')
                docs_df.to_csv(docs_file, index=False, encoding='utf-8-sig')
                logger.info(f"Documents index saved: {docs_file} ({len(all_documents)} documents)")
                
                # Save separate files for annual reports and concalls
                annual_reports = docs_df[docs_df['doc_type'] == 'Annual Report']
                if not annual_reports.empty:
                    annual_file = os.path.join(docs_dir, 'annual_reports_index.csv')
                    annual_reports.to_csv(annual_file, index=False, encoding='utf-8-sig')
                    logger.info(f"Annual reports index: {annual_file} ({len(annual_reports)} reports)")
                
                concalls = docs_df[docs_df['doc_type'] == 'Concall']
                if not concalls.empty:
                    concalls_file = os.path.join(docs_dir, 'concalls_index.csv')
                    concalls.to_csv(concalls_file, index=False, encoding='utf-8-sig')
                    logger.info(f"Concalls index: {concalls_file} ({len(concalls)} concalls)")
                
                # Create summary
                self._save_documents_summary(companies_with_docs, docs_dir, len(all_documents))
        
        except Exception as e:
            logger.error(f"Error saving documents data: {e}")
    
    def _save_documents_summary(self, companies_df: pd.DataFrame, docs_dir: str, total_docs: int):
        """Save a summary of documents data"""
        try:
            summary_file = os.path.join(docs_dir, 'documents_summary.txt')
            
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write("Documents Summary\n")
                f.write("=" * 40 + "\n\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Companies with documents: {len(companies_df)}\n")
                f.write(f"Total documents found: {total_docs}\n\n")
                
                # Count by type
                total_annual = 0
                total_concalls = 0
                
                for _, company in companies_df.iterrows():
                    company_name = company.get('company_name', 'Unknown')
                    total_annual += company.get('total_annual_reports', 0)
                    total_concalls += company.get('total_concalls', 0)
                    
                    f.write(f"Company: {company_name}\n")
                    f.write(f"  Annual Reports: {company.get('total_annual_reports', 0)}\n")
                    f.write(f"  Concalls: {company.get('total_concalls', 0)}\n")
                    
                    if company.get('latest_annual_report_url'):
                        f.write(f"  Latest Report: {company.get('latest_annual_report_year', 'N/A')}\n")
                    if company.get('latest_concall_url'):
                        f.write(f"  Latest Concall: {company.get('latest_concall_period', 'N/A')}\n")
                    
                    f.write("\n")
                
                f.write(f"\nTotals:\n")
                f.write(f"  Annual Reports: {total_annual}\n")
                f.write(f"  Concalls: {total_concalls}\n")
            
            logger.info(f"Documents summary saved to {summary_file}")
            
        except Exception as e:
            logger.error(f"Error saving documents summary: {e}")
    
    def _save_balance_sheet_summary(self, companies_df: pd.DataFrame, balance_sheet_dir: str):
        """Save a summary of Balance Sheet data"""
        try:
            summary_file = os.path.join(balance_sheet_dir, 'balance_sheet_summary.txt')
            
            with open(summary_file, 'w', encoding='utf-8') as f:
                f.write("Balance Sheet Summary\n")
                f.write("=" * 25 + "\n\n")
                f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Companies with Balance Sheet data: {len(companies_df)}\n\n")
                
                for _, company in companies_df.iterrows():
                    company_name = company.get('company_name', 'Unknown')
                    detailed_data = company.get('_detailed_data', {})
                    balance_sheet_data = detailed_data.get('balance_sheet_data', {})
                    
                    f.write(f"Company: {company_name}\n")
                    f.write(f"  Years: {balance_sheet_data.get('total_years', 0)}\n")
                    f.write(f"  Metrics: {balance_sheet_data.get('total_metrics', 0)}\n")
                    
                    if 'upcoming_result_date' in balance_sheet_data:
                        f.write(f"  Upcoming Result: {balance_sheet_data['upcoming_result_date']}\n")
                    
                    f.write("\n")
                    
            logger.info(f"Balance Sheet summary saved to {summary_file}")
            
        except Exception as e:
            logger.error(f"Error saving Balance Sheet summary: {e}")
        
    def _save_summary(self, df: pd.DataFrame, csv_filepath: str):
        """Save a summary of the scraped data"""
        summary_filepath = csv_filepath.replace('.csv', '_summary.txt')
        
        with open(summary_filepath, 'w', encoding='utf-8') as f:
            f.write("Screener.in Scraping Summary\n")
            f.write("=" * 50 + "\n\n")
            f.write(f"Scraping Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Companies: {len(df)}\n")
            f.write(f"Successful Scrapes: {len(df[df['status'] == 'success'])}\n")
            f.write(f"Failed Scrapes: {len(df[df['status'] != 'success'])}\n\n")
            
            if not df.empty:
                f.write("Metrics Summary:\n")
                f.write("-" * 20 + "\n")
                numeric_columns = df.select_dtypes(include=['number']).columns
                for col in numeric_columns:
                    if col in df.columns and df[col].notna().any():
                        f.write(f"{col}: {df[col].describe()}\n")
                        
        logger.info(f"Summary saved to {summary_filepath}")
        
    def scrape_single_company(self, company_symbol: str) -> Dict[str, Any]:
        """
        Scrape metrics for a single company by symbol
        
        Args:
            company_symbol: Company symbol (e.g., 'RELIANCE', 'TCS')
            
        Returns:
            Dictionary containing company metrics
        """
        company_url = f"{self.base_url}/company/{company_symbol}/"
        return self.extract_company_metrics(company_url)

def main():
    """Main function to run the advanced scraper"""
    scraper = AdvancedScreenerScraper(max_workers=2)  # Conservative for testing
    
    # Example usage:
    
    # 1. Scrape a single company
    print("Scraping single company example...")
    metrics = scraper.scrape_single_company('RELIANCE')
    if metrics:
        print(f"Reliance metrics: {json.dumps(metrics, indent=2)}")
    
    # 2. Scrape multiple companies (limited for testing)
    print("\nScraping multiple companies...")
    df = scraper.scrape_companies_parallel(max_companies=3)  # Limit to 3 for testing
    
    if not df.empty:
        # Save to CSV
        output_file = scraper.save_to_csv(df)
        print(f"Data saved to: {output_file}")
        
        # Display summary
        print(f"\nScraped data summary:")
        print(f"Total companies: {len(df)}")
        print(f"Successful scrapes: {len(df[df['status'] == 'success'])}")
        print(f"Columns: {list(df.columns)}")
        print(f"\nFirst few rows:")
        print(df.head())
    else:
        print("No data was scraped successfully")

if __name__ == "__main__":
    main() 