#!/usr/bin/env python3
"""
Test script to verify Unicode encoding fixes
"""

from advanced_screener_scraper import AdvancedScreenerScraper

def test_unicode_fix():
    """Test the Unicode encoding fix"""
    
    print("Testing Unicode Encoding Fix")
    print("=" * 40)
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Test data with the problematic encoding
    test_cases = [
        "â‚¹ 18,79,999 Cr.",
        "â‚¹ 1,389",
        "â‚¹ 1,551 / 1,115",
        "â‚¹ 401",
        "â€" Test dash",
        "â€™ Test apostrophe",
        "â€œ Test quote â€",
    ]
    
    print("Original text (with encoding issues):")
    for i, text in enumerate(test_cases, 1):
        print(f"  {i}. {text}")
    
    print("\nAfter Unicode fix:")
    for i, text in enumerate(test_cases, 1):
        fixed_text = scraper._clean_text(text)
        print(f"  {i}. {fixed_text}")
    
    print("\nTesting number extraction:")
    for i, text in enumerate(test_cases, 1):
        number = scraper._extract_number(text)
        print(f"  {i}. {text} -> {number}")
    
    print("\n" + "="*40)
    print("Test completed!")

def test_single_company():
    """Test scraping a single company to verify the fix works in practice"""
    
    print("\nTesting with actual company data...")
    
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Test with a well-known company
    company_symbol = 'RELIANCE'
    print(f"Scraping {company_symbol}...")
    
    try:
        metrics = scraper.scrape_single_company(company_symbol)
        
        if metrics and metrics.get('status') == 'success':
            print("✓ Successfully scraped company data")
            
            # Check for raw columns that might have encoding issues
            raw_columns = [col for col in metrics.keys() if '_raw' in col]
            print(f"Raw columns found: {raw_columns}")
            
            for col in raw_columns:
                value = metrics.get(col, '')
                if isinstance(value, str) and 'â‚¹' in value:
                    print(f"  ⚠️  {col}: Still has encoding issue")
                elif isinstance(value, str) and '₹' in value:
                    print(f"  ✓ {col}: Fixed encoding")
                else:
                    print(f"  - {col}: {value}")
        else:
            print("✗ Failed to scrape company data")
            
    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    test_unicode_fix()
    test_single_company() 