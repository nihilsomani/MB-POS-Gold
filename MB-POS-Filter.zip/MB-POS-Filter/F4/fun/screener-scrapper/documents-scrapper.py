import pandas as pd
import requests
from bs4 import BeautifulSoup
import os
import time
from urllib.parse import urljoin
import logging
import re

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ScreenerScraper:
    def __init__(self, input_csv='input.csv', output_dir='downloads'):
        self.input_csv = input_csv
        self.output_dir = output_dir
        self.base_url = 'https://www.screener.in'
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Create output directories
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'annual_reports'), exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'concalls'), exist_ok=True)
    
    def get_company_page(self, symbol):
        """Fetch company page from screener.in"""
        url = f'{self.base_url}/company/{symbol}/'
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            return response.text
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching page for {symbol}: {e}")
            return None
    
    def find_section_by_heading(self, soup, heading_text):
        """Find a section in the page by its heading text"""
        # Search through the page content
        page_text = soup.get_text()
        
        # Find the position of the heading
        if heading_text.lower() not in page_text.lower():
            return None
        
        # Find all text nodes and their parent elements
        for element in soup.find_all(text=re.compile(heading_text, re.IGNORECASE)):
            parent = element.parent
            # Navigate up to find a container (usually h2, h3, or section)
            for _ in range(5):  # Look up to 5 levels
                if parent and parent.name in ['h2', 'h3', 'h4', 'section', 'div']:
                    # Found a potential section header
                    # Now find the next list or div with content
                    next_element = parent.find_next_sibling()
                    if not next_element:
                        parent = parent.parent
                        if parent:
                            next_element = parent.find_next_sibling()
                    
                    return next_element if next_element else parent
                parent = parent.parent if parent else None
        
        return None
    
    def parse_documents(self, html, symbol):
        """Parse the documents section and extract latest Annual Report and Concall"""
        soup = BeautifulSoup(html, 'html.parser')
        
        documents = {
            'annual_report': None,
            'concall': None
        }
        
        # Method 1: Try to find by text pattern "Annual reports" and "Concalls"
        page_content = str(soup)
        
        # Find Annual Reports
        annual_match = re.search(r'Annual reports(.*?)(?:Concalls|Business Profile|$)', 
                                page_content, re.IGNORECASE | re.DOTALL)
        if annual_match:
            annual_html = annual_match.group(1)
            annual_soup = BeautifulSoup(annual_html, 'html.parser')
            pdf_links = annual_soup.find_all('a', href=re.compile(r'\.pdf$', re.IGNORECASE))
            
            if pdf_links:
                href = pdf_links[0].get('href')
                year_match = re.search(r'(20\d{2})', annual_html)
                year = year_match.group(1) if year_match else 'Latest'
                
                documents['annual_report'] = {
                    'text': f"Annual Report {year}",
                    'url': href if href.startswith('http') else urljoin(self.base_url, href)
                }
                logger.info(f"{symbol}: Found Annual Report - {year}")
            else:
                logger.warning(f"{symbol}: Annual Reports section exists but no PDFs found")
        else:
            logger.warning(f"{symbol}: No Annual Reports section found")
        
        # Find Concalls
        concall_match = re.search(r'Concalls(.*?)(?:Business Profile|Shareholding Pattern|$)', 
                                 page_content, re.IGNORECASE | re.DOTALL)
        if concall_match:
            concall_html = concall_match.group(1)
            concall_soup = BeautifulSoup(concall_html, 'html.parser')
            
            # Find all list items (each concall entry)
            # Look for the first item with a Transcript link
            all_links = concall_soup.find_all('a', href=re.compile(r'\.pdf$', re.IGNORECASE))
            
            for link in all_links:
                link_text = link.get_text(strip=True).lower()
                # Prefer transcript links
                if 'transcript' in link_text or link_text == 'transcript':
                    href = link.get('href')
                    
                    # Try to find the month/year for this concall
                    parent_text = link.find_parent('li')
                    if parent_text:
                        parent_text = parent_text.get_text(strip=True)
                        month_year = parent_text.split('\n')[0].strip()
                    else:
                        month_year = "Latest"
                    
                    documents['concall'] = {
                        'text': f"Concall Transcript {month_year}",
                        'url': href if href.startswith('http') else urljoin(self.base_url, href)
                    }
                    logger.info(f"{symbol}: Found Concall - {month_year}")
                    break
            
            if not documents['concall']:
                logger.warning(f"{symbol}: Concalls section exists but no transcripts found")
        else:
            logger.warning(f"{symbol}: No Concalls section found")
        
        return documents
    
    def download_pdf(self, url, output_path):
        """Download PDF file"""
        try:
            response = self.session.get(url, timeout=60, stream=True)
            response.raise_for_status()
            
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            
            logger.info(f"Downloaded: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Error downloading {url}: {e}")
            return False
    
    def process_symbol(self, symbol):
        """Process a single company symbol"""
        logger.info(f"Processing {symbol}...")
        
        # Get company page
        html = self.get_company_page(symbol)
        if not html:
            return False
        
        # Parse documents
        documents = self.parse_documents(html, symbol)
        
        # Download Annual Report
        if documents['annual_report']:
            filename = f"{symbol}_Annual_Report.pdf"
            output_path = os.path.join(self.output_dir, 'annual_reports', filename)
            self.download_pdf(documents['annual_report']['url'], output_path)
        
        # Download Concall
        if documents['concall']:
            filename = f"{symbol}_Concall.pdf"
            output_path = os.path.join(self.output_dir, 'concalls', filename)
            self.download_pdf(documents['concall']['url'], output_path)
        
        # Be respectful to the server
        time.sleep(2)
        return True
    
    def run(self):
        """Main execution method"""
        try:
            # Read input CSV
            df = pd.read_csv(self.input_csv)
            
            if 'Symbol' not in df.columns:
                logger.error("CSV must contain a 'Symbol' column")
                return
            
            symbols = df['Symbol'].dropna().unique()
            logger.info(f"Found {len(symbols)} symbols to process")
            
            # Process each symbol
            for idx, symbol in enumerate(symbols, 1):
                logger.info(f"[{idx}/{len(symbols)}] Processing {symbol}")
                self.process_symbol(symbol)
            
            logger.info("Scraping completed!")
            
        except FileNotFoundError:
            logger.error(f"Input file '{self.input_csv}' not found")
        except Exception as e:
            logger.error(f"Error during execution: {e}")

if __name__ == '__main__':
    # Create input.csv example if it doesn't exist
    if not os.path.exists('input.csv'):
        example_df = pd.DataFrame({
            'Symbol': ['LLOYDSME','NPST','AVANTEL','WAAREEENER','VADILALIND','SOLARINDS','INDRAMEDCO','ANANDRATHI','PIIND','JSLL','PRUDENT','TATAELXSI','PAGEIND','DOMS','JBCHEPHARM','HBLENGINE','HYUNDAI','MRPL','BIKAJI','JYOTHYLAB','RPGLIFE','ABBOTINDIA','ESABINDIA','SHRIPISTON','TRENT','MM','ASIANPAINT','SUPREMEIND','3MINDIA','CUMMINSIND','FORCEMOT','DRREDDY','GUJTHEM','MEDANTA','PREMEXPLN','STYLAMIND','TORNTPHARM','EICHERMOT','SAFARI','BECTORFOOD','FCL','BRITANNIA','CMSINFO','KKCL','ECLERX','ELECON','INGERRAND','CGPOWER','NEWGEN','TCS','AUTOAXLES','LTTS','EMAMILTD','JINDALSAW','RKFORGE','ROLEXRINGS','UNOMINDA','VENUSPIPES','AJANTPHARM','CAMS','SHARDAMOTR','SONACOMS','SWARAJENG','HAPPYFORGE','MANYAVAR','SBCL','KFINTECH','MSUMI','SKFINDIA','AKZOINDIA','NEULANDLAB','ACI','AEGISLOG','LTIM','CHAMBLFERT','GALLANTT','JAIBALAJI','CIPLA','CARBORUNIV','USHAMART','BERGEPAINT','JSL','LALPATHLAB','POLYMED','RPEL','BAYERCROP','INDIGOPNTS','JKTYRE','TI','HCLTECH','KPITTECH','MRF','LUPIN','NUCLEUS','CHENNPETRO','CAMPUS','GHCL','QPOWER','SUMICHEM','BANCOINDIA','DBCORP','KEI','PNCINFRA','TIPSMUSIC','ZENSARTECH','IRCTC','OLECTRA','PIDILITIND','TVSMOTOR','KSCL','AGI','DHANUKA','LGBBROSLTD','MAHSEAMLES','NDRAUTO']
        })
        example_df.to_csv('input.csv', index=False)
        logger.info("Created example input.csv with sample symbols")
    
    # Run scraper
    scraper = ScreenerScraper(input_csv='input.csv', output_dir='downloads')
    scraper.run()