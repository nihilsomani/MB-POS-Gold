# Balance Sheet Extraction Feature

## Overview

The Balance Sheet extraction feature has been added to the Advanced Screener Scraper to extract year-wise Balance Sheet data from screener.in company pages. This feature complements the existing Profit & Loss (P&L) and quarterly data extraction capabilities.

## What Data is Extracted

### Balance Sheet Metrics
The scraper extracts the following Balance Sheet metrics for each year:
- **Assets**: Total Assets, Current Assets, Non-Current Assets
- **Liabilities**: Total Liabilities, Current Liabilities, Non-Current Liabilities
- **Equity**: Shareholders' Equity, Retained Earnings
- **Working Capital**: Current Assets, Current Liabilities, Net Working Capital
- **Debt**: Total Debt, Short-term Debt, Long-term Debt
- **Cash & Cash Equivalents**: Cash, Bank Balances, Investments
- **Fixed Assets**: Property, Plant & Equipment, Intangible Assets
- **Other Assets/Liabilities**: Various other Balance Sheet items

### Growth Metrics
The scraper also extracts growth metrics from the "ranges-table" sections:
- **Asset Growth**: Year-over-year asset growth rates
- **Liability Growth**: Year-over-year liability growth rates
- **Equity Growth**: Year-over-year equity growth rates
- **Working Capital Trends**: Changes in working capital over time

## How to Use

### Basic Usage

```python
from advanced_screener_scraper import AdvancedScreenerScraper

# Initialize scraper
scraper = AdvancedScreenerScraper(max_workers=2)

# Scrape a single company
metrics = scraper.scrape_single_company('RELIANCE')

# Check if Balance Sheet data is available
if metrics.get('has_balance_sheet_data'):
    balance_sheet_data = metrics['balance_sheet_data']
    print(f"Years: {balance_sheet_data['total_years']}")
    print(f"Metrics: {balance_sheet_data['total_metrics']}")
```

### Multiple Companies

```python
# Scrape multiple companies
company_urls = [
    'https://www.screener.in/company/RELIANCE/',
    'https://www.screener.in/company/TCS/',
    'https://www.screener.in/company/HDFCBANK/'
]

df = scraper.scrape_companies_parallel(company_urls=company_urls)
output_file = scraper.save_to_csv(df, "balance_sheet_results.csv")
```

## Output Files

### Main CSV File
The main CSV file includes a `has_balance_sheet_data` column indicating whether Balance Sheet data was successfully extracted for each company.

### Balance Sheet Data Files
For companies with Balance Sheet data, separate CSV files are created in the `output/balance_sheet_data/` directory:

```
output/
├── balance_sheet_data/
│   ├── RELIANCE_balance_sheet.csv
│   ├── TCS_balance_sheet.csv
│   ├── HDFCBANK_balance_sheet.csv
│   └── balance_sheet_summary.txt
```

### Balance Sheet CSV Structure
Each Balance Sheet CSV file contains:
- `company_name`: Company name
- `company_url`: Source URL
- `scraped_at`: Timestamp of scraping
- `metric`: Balance Sheet metric name
- `2024`, `2023`, `2022`, etc.: Year-wise values
- `2024_raw`, `2023_raw`, etc.: Raw text values

### Summary File
A `balance_sheet_summary.txt` file provides an overview:
```
Balance Sheet Summary
=========================

Generated: 2025-01-27 15:30:45
Companies with Balance Sheet data: 3

Company: Reliance Industries
  Years: 5
  Metrics: 15

Company: Tata Consultancy Services
  Years: 5
  Metrics: 12
```

## Testing

### Run the Test Script
```bash
python test_balance_sheet_extraction.py
```

This will test:
- Single company Balance Sheet extraction
- Multiple company extraction
- CSV output generation

### Run the Demo Script
```bash
python demo_balance_sheet_extraction.py
```

This provides a demonstration of the feature with sample output.

## Configuration

### Scraper Settings
```python
scraper = AdvancedScreenerScraper(
    max_workers=2,        # Number of parallel workers
    delay_range=(1, 3),   # Delay between requests
    timeout=30,           # Request timeout
    retry_attempts=3      # Retry attempts for failed requests
)
```

### Custom Company Lists
Use the existing custom company configuration:

```python
from custom_companies_config import CUSTOM_COMPANIES

# Use predefined company list
company_urls = [f"https://www.screener.in/company/{symbol}/" for symbol in CUSTOM_COMPANIES]
df = scraper.scrape_companies_parallel(company_urls=company_urls)
```

## Error Handling

### Common Issues
1. **No Balance Sheet Section**: Some companies may not have Balance Sheet data available
2. **Network Errors**: Retry mechanism handles temporary network issues
3. **Rate Limiting**: Built-in delays prevent being blocked
4. **Encoding Issues**: Unicode characters are properly handled

### Error Recovery
- Failed requests are retried up to 3 times
- Companies with errors are marked with `status: 'processing_error'`
- Balance Sheet extraction errors don't affect other data extraction

## Performance

### Optimization Tips
- Use `max_workers=2-3` for optimal performance
- Increase `delay_range` if experiencing rate limiting
- Process companies in batches for large datasets

### Expected Performance
- Single company: ~2-3 seconds
- Multiple companies (parallel): ~1-2 seconds per company
- Balance Sheet data extraction adds minimal overhead

## Data Quality

### Validation
- Numeric values are extracted and cleaned
- Raw text values are preserved for reference
- Missing data is handled gracefully
- Unicode characters are properly encoded

### Data Completeness
- Not all companies have Balance Sheet data
- Some companies may have partial data
- Growth metrics may not be available for all companies

## Integration with Existing Features

### Combined Data Extraction
The Balance Sheet feature works alongside:
- **Profit & Loss (P&L)**: Year-wise P&L statements
- **Quarterly Data**: Quarterly financial results
- **Basic Metrics**: Current price, P/E ratio, etc.

### Output Integration
All data types are saved to separate directories:
- `output/balance_sheet_data/` - Balance Sheet files
- `output/pnl_data/` - P&L files
- `output/quarterly_data/` - Quarterly files

## Future Enhancements

### Planned Features
1. **Cash Flow Extraction**: Add Cash Flow statement extraction
2. **Ratio Calculations**: Automatically calculate financial ratios
3. **Trend Analysis**: Identify trends in Balance Sheet metrics
4. **Export Formats**: Support for Excel, JSON, and other formats
5. **Real-time Updates**: Periodic data refresh capabilities

### Customization Options
1. **Metric Selection**: Allow users to select specific Balance Sheet metrics
2. **Year Range**: Specify custom year ranges for extraction
3. **Filtering**: Filter companies based on Balance Sheet criteria
4. **Aggregation**: Combine Balance Sheet data across companies

## Troubleshooting

### Common Problems

**Q: No Balance Sheet data is being extracted**
A: Check if the company has Balance Sheet data available on screener.in. Not all companies provide this data.

**Q: CSV files have encoding issues**
A: Files are saved with `utf-8-sig` encoding. Open in Excel or use a text editor that supports UTF-8.

**Q: Slow scraping performance**
A: Reduce `max_workers` or increase `delay_range` to avoid rate limiting.

**Q: Missing companies in output**
A: Check the `status` column in the main CSV file for error details.

### Debug Mode
Enable debug logging for detailed information:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Support

For issues or questions:
1. Check the test scripts for examples
2. Review the error logs in `advanced_screener_scraper.log`
3. Verify the HTML structure on screener.in hasn't changed
4. Test with a single company first before batch processing

## Changelog

### Version 1.0 (Current)
- ✅ Balance Sheet data extraction
- ✅ Year-wise metric extraction
- ✅ Growth metrics extraction
- ✅ Separate CSV file generation
- ✅ Summary file creation
- ✅ Integration with existing scraper
- ✅ Test and demo scripts
- ✅ Unicode encoding support
- ✅ Error handling and retry logic 