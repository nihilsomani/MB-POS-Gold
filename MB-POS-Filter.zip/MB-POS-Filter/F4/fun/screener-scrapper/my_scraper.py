#!/usr/bin/env python3
"""
Stage 2 Shortlist Scraper
==========================

Scrapes financial data for all companies in data/Stage2Shortlist.csv
with batch processing, progress tracking, and error handling.

Author: Custom scraper for Stage 2 analysis
Date: 2025-10-16
"""

import pandas as pd
import os
import sys
from datetime import datetime
from advanced_screener_scraper import AdvancedScreenerScraper

def load_companies(csv_path):
    """Load company symbols from CSV file"""
    try:
        df = pd.read_csv(csv_path)
        companies = df['Symbol'].tolist()
        print(f"✅ Loaded {len(companies)} companies from {csv_path}")
        return companies
    except Exception as e:
        print(f"❌ Error loading CSV: {e}")
        sys.exit(1)

def scrape_stage2_companies(batch_size=10, max_workers=3, delay_range=(1, 2)):
    """
    Scrape all Stage 2 shortlist companies with batch processing
    
    Args:
        batch_size: Number of companies to scrape per batch (default: 10)
        max_workers: Number of parallel threads (default: 3)
        delay_range: Delay between requests in seconds (default: (1, 2))
    """
    
    print("\n" + "=" * 70)
    print("STAGE 2 SHORTLIST - FINANCIAL DATA SCRAPER")
    print("=" * 70)
    
    # Load companies
    csv_path = os.path.join('data\MCAP-great2500.csv')
    companies = load_companies(csv_path)
    
    print(f"\n📊 Configuration:")
    print(f"   Total Companies: {len(companies)}")
    print(f"   Batch Size: {batch_size}")
    print(f"   Parallel Workers: {max_workers}")
    print(f"   Delay Range: {delay_range[0]}-{delay_range[1]} seconds")
    print(f"   Estimated Time: ~{len(companies) * 2 / 60:.1f} minutes")
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(
        max_workers=max_workers,
        delay_range=delay_range,
        timeout=30,
        retry_attempts=3
    )
    
    # Prepare for batch processing
    total_batches = (len(companies) + batch_size - 1) // batch_size
    all_results = []
    successful_count = 0
    failed_count = 0
    
    print(f"\n🚀 Starting scraping in {total_batches} batches...")
    print("=" * 70)
    
    start_time = datetime.now()
    
    # Process in batches
    for batch_num, i in enumerate(range(0, len(companies), batch_size), 1):
        batch = companies[i:i+batch_size]
        
        print(f"\n📦 Batch {batch_num}/{total_batches}")
        print(f"   Companies: {', '.join(batch[:3])}{'...' if len(batch) > 3 else ''}")
        print(f"   Progress: {i}/{len(companies)} ({i/len(companies)*100:.1f}%)")
        
        # Convert to URLs
        urls = [f"https://www.screener.in/company/{symbol}/" for symbol in batch]
        
        # Scrape batch
        batch_start = datetime.now()
        df_batch = scraper.scrape_companies_parallel(company_urls=urls)
        batch_duration = (datetime.now() - batch_start).total_seconds()
        
        if not df_batch.empty:
            all_results.append(df_batch)
            
            # Count successes and failures
            batch_successful = len(df_batch[df_batch['status'] == 'success'])
            batch_failed = len(df_batch[df_batch['status'] != 'success'])
            successful_count += batch_successful
            failed_count += batch_failed
            
            print(f"   ✅ Batch complete: {batch_successful}/{len(batch)} successful ({batch_duration:.1f}s)")
            
            # Save intermediate results every 5 batches
            if batch_num % 5 == 0:
                temp_df = pd.concat(all_results, ignore_index=True)
                temp_file = f"output/stage2_partial_{batch_num}.csv"
                temp_df.to_csv(temp_file, index=False, encoding='utf-8-sig')
                print(f"   💾 Checkpoint saved: {temp_file}")
        else:
            print(f"   ⚠️  Batch returned no data")
            failed_count += len(batch)
    
    # Combine all results
    print("\n" + "=" * 70)
    print("📊 PROCESSING RESULTS...")
    
    if all_results:
        final_df = pd.concat(all_results, ignore_index=True)
        
        # Save final results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = scraper.save_to_csv(final_df, f"stage2_shortlist_{timestamp}.csv")
        
        # Calculate statistics
        elapsed_time = (datetime.now() - start_time).total_seconds()
        success_rate = (successful_count / len(companies)) * 100
        
        print("\n" + "=" * 70)
        print("✅ SCRAPING COMPLETE!")
        print("=" * 70)
        print(f"\n📈 Summary:")
        print(f"   Total Companies: {len(companies)}")
        print(f"   ✅ Successful: {successful_count} ({success_rate:.1f}%)")
        print(f"   ❌ Failed: {failed_count}")
        print(f"   ⏱️  Time Taken: {elapsed_time/60:.1f} minutes")
        print(f"   ⚡ Avg Speed: {elapsed_time/len(companies):.1f}s per company")
        
        print(f"\n📁 Output Files:")
        print(f"   Main Data: {output_file}")
        print(f"   P&L Data: output/pnl_data/")
        print(f"   Balance Sheet: output/balance_sheet_data/")
        print(f"   Quarterly Data: output/quarterly_data/")
        print(f"   Cash Flow Data: output/cash_flow_data/")
        
        # Show data availability statistics
        if not final_df.empty:
            pnl_count = len(final_df[final_df['has_pnl_data'] == True])
            bs_count = len(final_df[final_df['has_balance_sheet_data'] == True])
            qtr_count = len(final_df[final_df['has_quarterly_data'] == True])
            cf_count = len(final_df[final_df['has_cash_flow_data'] == True])
            
            print(f"\n📊 Data Availability:")
            print(f"   P&L Data: {pnl_count}/{successful_count} companies")
            print(f"   Balance Sheet: {bs_count}/{successful_count} companies")
            print(f"   Quarterly Data: {qtr_count}/{successful_count} companies")
            print(f"   Cash Flow Data: {cf_count}/{successful_count} companies")
        
        # Show top 5 by market cap
        successful_df = final_df[final_df['status'] == 'success']
        if not successful_df.empty and 'market_cap' in successful_df.columns:
            print(f"\n🏆 Top 5 by Market Cap:")
            top5 = successful_df.nlargest(5, 'market_cap')
            for idx, (_, company) in enumerate(top5.iterrows(), 1):
                name = company.get('company_name', 'Unknown')
                mcap = company.get('market_cap', 0)
                price = company.get('current_price', 0)
                pe = company.get('pe_ratio', 0)
                print(f"   {idx}. {name}: ₹{mcap:.0f} Cr (Price: ₹{price}, P/E: {pe})")
        
        print("\n" + "=" * 70)
        print("🎉 All data has been scraped and saved!")
        print("=" * 70)
        
        return final_df
    else:
        print("\n❌ No data was scraped successfully!")
        return None

def main():
    """Main function"""
    
    # Configuration
    BATCH_SIZE = 10          # Companies per batch
    MAX_WORKERS = 3          # Parallel threads
    DELAY_RANGE = (1, 2)     # Delay between requests (seconds)
    
    # You can adjust these values:
    # BATCH_SIZE = 5           # Smaller batches = more polite, slower
    # MAX_WORKERS = 2          # Fewer workers = more polite, slower
    # DELAY_RANGE = (2, 4)     # Longer delays = more polite, slower
    
    try:
        df = scrape_stage2_companies(
            batch_size=BATCH_SIZE,
            max_workers=MAX_WORKERS,
            delay_range=DELAY_RANGE
        )
        
        if df is not None:
            print("\n💡 Next Steps:")
            print("   1. Check the CSV files in output/ directory")
            print("   2. Review detailed data in output/pnl_data/, etc.")
            print("   3. Use financial_scanner.py to analyze the data")
            print("   4. Run: python ../../financial_scanner.py")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Scraping interrupted by user")
        print("💡 Partial results saved in output/stage2_partial_*.csv")
        print("   You can resume by running the script again")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()

