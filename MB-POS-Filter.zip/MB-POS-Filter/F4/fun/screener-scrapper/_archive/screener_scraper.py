import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import re
import logging
from typing import Dict, List, Optional, Tuple
import json
from urllib.parse import urljoin, urlparse
import random
from datetime import datetime
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('screener_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class ScreenerScraper:
    """
    Web scraper for screener.in to extract financial metrics from company pages
    """
    
    def __init__(self, base_url: str = "https://www.screener.in", delay_range: Tuple[int, int] = (1, 3)):
        """
        Initialize the scraper
        
        Args:
            base_url: Base URL for screener.in
            delay_range: Range of seconds to delay between requests (min, max)
        """
        self.base_url = base_url
        self.delay_range = delay_range
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
        
        # Financial metrics to extract
        self.metrics_to_extract = [
            'Market Cap', 'Current Price', 'High / Low', 'Stock P/E', 'Book Value',
            'Dividend Yield', 'ROCE', 'ROE', 'Face Value', 'EPS', 'Industry PE',
            '3Yrs PE', 'Free Cash Flow 3Yrs', 'Price to Cash Flow', 'Price to Earning',
            'Price to book value', 'Intrinsic Value', 'OPM', 'Enterprise Value',
            'PEG Ratio', 'Earning Power', 'Net block', 'Price to Sales', 'Int Coverage',
            'Asset Turnover'
        ]
        
    def _delay(self):
        """Add random delay between requests to be respectful to the server"""
        delay = random.uniform(*self.delay_range)
        time.sleep(delay)
        
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text data with proper Unicode handling"""
        if not text:
            return ""
        
        # Fix common Unicode encoding issues
        # Replace incorrectly encoded Rupee symbol
        text = text.replace('â‚¹', '₹')
        text = text.replace('â€"', '—')  # em dash
        text = text.replace('â€"', '–')  # en dash
        text = text.replace('â€™', "'")   # apostrophe
        text = text.replace('â€œ', '"')   # left double quote
        text = text.replace('â€', '"')    # right double quote
        
        # Remove extra whitespace and normalize
        text = re.sub(r'\s+', ' ', text.strip())
        return text
        
    def _extract_number(self, text: str) -> Optional[float]:
        """Extract numeric value from text, handling currency symbols and units"""
        if not text:
            return None
            
        # Clean the text first to fix Unicode issues
        text = self._clean_text(text)
            
        # Remove currency symbols and common text (including both correct and incorrect Rupee symbols)
        text = re.sub(r'[₹$€£]', '', text)
        text = re.sub(r'â‚¹', '', text)  # Remove incorrectly encoded Rupee symbol
        text = re.sub(r'\s*(Cr\.|Cr|Lakh|Lac|Million|Billion)\s*', '', text, flags=re.IGNORECASE)
        text = re.sub(r'\s*%\s*', '', text)
        
        # Extract numbers (including decimals and negative numbers)
        numbers = re.findall(r'-?\d+\.?\d*', text)
        if numbers:
            try:
                return float(numbers[0])
            except ValueError:
                return None
        return None
        
    def _extract_high_low(self, text: str) -> Tuple[Optional[float], Optional[float]]:
        """Extract high and low values from 'High / Low' format"""
        if not text:
            return None, None
            
        # Clean the text first to fix Unicode issues
        text = self._clean_text(text)
            
        # Remove currency symbol (including both correct and incorrect Rupee symbols)
        text = re.sub(r'[₹$€£]', '', text)
        text = re.sub(r'â‚¹', '', text)  # Remove incorrectly encoded Rupee symbol
        
        # Extract numbers
        numbers = re.findall(r'\d+\.?\d*', text)
        if len(numbers) >= 2:
            try:
                return float(numbers[0]), float(numbers[1])
            except ValueError:
                return None, None
        return None, None
        
    def _get_page(self, url: str) -> Optional[BeautifulSoup]:
        """Get and parse a web page"""
        try:
            self._delay()
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            return BeautifulSoup(response.content, 'html.parser')
        except requests.RequestException as e:
            logger.error(f"Error fetching {url}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error fetching {url}: {e}")
            return None
            
    def extract_company_metrics(self, company_url: str) -> Dict:
        """
        Extract financial metrics from a company page
        
        Args:
            company_url: URL of the company page
            
        Returns:
            Dictionary containing extracted metrics
        """
        soup = self._get_page(company_url)
        if not soup:
            return {}
            
        metrics = {
            'company_url': company_url,
            'scraped_at': datetime.now().isoformat()
        }
        
        # Find the company ratios section
        ratios_section = soup.find('div', class_='company-ratios')
        if not ratios_section:
            logger.warning(f"No company ratios section found on {company_url}")
            return metrics
            
        # Find all ratio items
        ratio_items = ratios_section.find_all('li', class_='flex flex-space-between')
        
        for item in ratio_items:
            name_span = item.find('span', class_='name')
            value_span = item.find('span', class_='nowrap value')
            
            if not name_span or not value_span:
                continue
                
            metric_name = self._clean_text(name_span.get_text())
            metric_value = self._clean_text(value_span.get_text())
            
            if not metric_name:
                continue
                
            # Extract numeric value
            numeric_value = self._extract_number(metric_value)
            
            # Handle special cases
            if metric_name == 'High / Low':
                high, low = self._extract_high_low(metric_value)
                metrics[f'{metric_name}_High'] = high
                metrics[f'{metric_name}_Low'] = low
                metrics[f'{metric_name}_Raw'] = metric_value
            else:
                metrics[metric_name] = numeric_value
                metrics[f'{metric_name}_Raw'] = metric_value
                
        # Extract company name if available
        company_name_elem = soup.find('h1', class_='company-name')
        if company_name_elem:
            metrics['Company_Name'] = self._clean_text(company_name_elem.get_text())
            
        # Extract sector if available
        sector_elem = soup.find('a', class_='sector')
        if sector_elem:
            metrics['Sector'] = self._clean_text(sector_elem.get_text())
            
        return metrics
        
    def get_company_list(self, list_url: str = None) -> List[str]:
        """
        Get list of company URLs to scrape
        
        Args:
            list_url: URL of the page containing company links
            
        Returns:
            List of company URLs
        """
        if not list_url:
            # Default to NSE 500 companies page
            list_url = f"{self.base_url}/screener/equity/"
            
        soup = self._get_page(list_url)
        if not soup:
            return []
            
        company_urls = []
        
        # Find company links (adjust selector based on actual page structure)
        company_links = soup.find_all('a', href=re.compile(r'/company/[^/]+/$'))
        
        for link in company_links:
            href = link.get('href')
            if href:
                full_url = urljoin(self.base_url, href)
                company_urls.append(full_url)
                
        logger.info(f"Found {len(company_urls)} companies to scrape")
        return company_urls
        
    def scrape_companies(self, company_urls: List[str] = None, max_companies: int = None) -> pd.DataFrame:
        """
        Scrape financial metrics for multiple companies
        
        Args:
            company_urls: List of company URLs to scrape
            max_companies: Maximum number of companies to scrape (for testing)
            
        Returns:
            DataFrame containing all extracted metrics
        """
        if company_urls is None:
            company_urls = self.get_company_list()
            
        if max_companies:
            company_urls = company_urls[:max_companies]
            
        all_metrics = []
        successful_scrapes = 0
        failed_scrapes = 0
        
        logger.info(f"Starting to scrape {len(company_urls)} companies")
        
        for i, url in enumerate(company_urls, 1):
            logger.info(f"Scraping {i}/{len(company_urls)}: {url}")
            
            try:
                metrics = self.extract_company_metrics(url)
                if metrics:
                    all_metrics.append(metrics)
                    successful_scrapes += 1
                    logger.info(f"Successfully scraped metrics for {metrics.get('Company_Name', 'Unknown')}")
                else:
                    failed_scrapes += 1
                    logger.warning(f"No metrics extracted from {url}")
            except Exception as e:
                failed_scrapes += 1
                logger.error(f"Error scraping {url}: {e}")
                
        logger.info(f"Scraping completed. Successful: {successful_scrapes}, Failed: {failed_scrapes}")
        
        if all_metrics:
            df = pd.DataFrame(all_metrics)
            return df
        else:
            logger.warning("No data was scraped successfully")
            return pd.DataFrame()
            
    def save_to_csv(self, df: pd.DataFrame, filename: str = None) -> str:
        """
        Save scraped data to CSV file
        
        Args:
            df: DataFrame to save
            filename: Output filename (auto-generated if None)
            
        Returns:
            Path to saved file
        """
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"screener_financial_metrics_{timestamp}.csv"
            
        # Create output directory if it doesn't exist
        os.makedirs('output', exist_ok=True)
        filepath = os.path.join('output', filename)
        
        # Save with proper UTF-8 encoding and BOM for better Excel compatibility
        df.to_csv(filepath, index=False, encoding='utf-8-sig')
        logger.info(f"Data saved to {filepath}")
        return filepath
        
    def scrape_single_company(self, company_symbol: str) -> Dict:
        """
        Scrape metrics for a single company by symbol
        
        Args:
            company_symbol: Company symbol (e.g., 'RELIANCE', 'TCS')
            
        Returns:
            Dictionary containing company metrics
        """
        company_url = f"{self.base_url}/company/{company_symbol}/"
        return self.extract_company_metrics(company_url)

def main():
    """Main function to run the scraper"""
    scraper = ScreenerScraper()
    
    # Example usage:
    
    # 1. Scrape a single company
    print("Scraping single company example...")
    metrics = scraper.scrape_single_company('RELIANCE')
    if metrics:
        print(f"Reliance metrics: {json.dumps(metrics, indent=2)}")
    
    # 2. Scrape multiple companies (limited for testing)
    print("\nScraping multiple companies...")
    df = scraper.scrape_companies(max_companies=5)  # Limit to 5 for testing
    
    if not df.empty:
        # Save to CSV
        output_file = scraper.save_to_csv(df)
        print(f"Data saved to: {output_file}")
        
        # Display summary
        print(f"\nScraped data summary:")
        print(f"Total companies: {len(df)}")
        print(f"Columns: {list(df.columns)}")
        print(f"\nFirst few rows:")
        print(df.head())
    else:
        print("No data was scraped successfully")

if __name__ == "__main__":
    main() 