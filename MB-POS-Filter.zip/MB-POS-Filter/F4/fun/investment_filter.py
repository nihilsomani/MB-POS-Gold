#!/usr/bin/env python3
"""
Professional Investment Filter - Pyramid Approach
==================================================

Philosophy: Investment decisions should follow a HIERARCHY, not a composite score.
Think like a professional analyst, not a data scientist.

The Investment Pyramid:
    ┌──────────────────┐
    │    VALUATION     │  ← Only evaluate if Tiers 1-3 pass
    ├──────────────────┤
    │   MOAT & GROWTH  │  ← Sustainable competitive advantage
    ├──────────────────┤
    │  QUALITY BUSINESS│  ← Cash generation & capital efficiency
    ├──────────────────┤
    │ FINANCIAL SAFETY │  ← Avoid disasters (Tier 1 - KNOCKOUT)
    └──────────────────┘

Output: Simple BUY/WATCH/PASS decision with clear reasoning

Author: Professional Investment Framework
"""

import pandas as pd
import numpy as np
import os
import json
from datetime import datetime
from typing import Dict, List, Tuple, Optional
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


class InvestmentFilter:
    """
    Professional-grade investment filter using pyramid approach
    """
    
    def __init__(self, data_dir: str = "output"):
        self.data_dir = data_dir
        self.results = []
        
        # Investment criteria (inspired by Buffett, Munger, Greenblatt, Khemka)
        self.criteria = {
            # TIER 1: FINANCIAL SAFETY (Knockout Round)
            'safety': {
                'debt_equity_max': 1.0,           # Manageable debt
                'current_ratio_min': 1.0,         # Liquidity
                'ocf_positive': True,             # Must generate cash
                'consecutive_losses_max': 0       # No serial loss-makers
            },
            
            # TIER 2: QUALITY BUSINESS (The Core)
            'quality': {
                'roic_min': 15.0,                 # Capital efficiency (Greenblatt's magic)
                'fcf_conversion_min': 0.7,        # Cash > Accounting profit (Khemka)
                'gross_margin_min': 25.0,         # Pricing power
                'fcf_positive_years_min': 3       # Consistency
            },
            
            # TIER 3: MOAT & GROWTH (Sustainability)
            'moat': {
                'revenue_cagr_min': 10.0,         # Growing business
                'margin_trend': 'stable_or_improving',  # Operating leverage
                'asset_turnover_min': 0.8,        # Asset-light preferred
                'ccc_max': 90                     # Working capital efficiency
            },
            
            # TIER 4: VALUATION (Only after quality confirmed)
            'valuation': {
                'pe_max': 35,                     # Not egregiously expensive
                'ev_fcf_max': 30,                 # Khemka's preferred metric
                'peg_max': 2.0                    # Growth-adjusted value
            }
        }
    
    def load_company_data(self, company_symbol: str) -> Optional[Dict]:
        """Load financial data for analysis"""
        try:
            data = {}
            
            # P&L
            pnl_file = os.path.join(self.data_dir, "pnl_data", f"{company_symbol}_pnl.csv")
            if os.path.exists(pnl_file):
                data['pnl'] = pd.read_csv(pnl_file)
            
            # Balance Sheet
            bs_file = os.path.join(self.data_dir, "balance_sheet_data", f"{company_symbol}_balance_sheet.csv")
            if os.path.exists(bs_file):
                data['balance_sheet'] = pd.read_csv(bs_file)
            
            # Cash Flow
            cf_file = os.path.join(self.data_dir, "cash_flow_data", f"{company_symbol}_cash_flow.csv")
            if os.path.exists(cf_file):
                data['cash_flow'] = pd.read_csv(cf_file)
            
            return data if data else None
        except Exception as e:
            logger.error(f"Error loading {company_symbol}: {e}")
            return None
    
    def extract_value(self, df: pd.DataFrame, metric: str, year: str = 'Mar 2024') -> float:
        """Extract single metric value"""
        try:
            row = df[df['metric'] == metric]
            if row.empty:
                return 0.0
            
            raw_col = f"{year}_raw"
            value = row[raw_col].iloc[0] if raw_col in row.columns else row[year].iloc[0]
            
            # Clean value
            if pd.isna(value) or value == '' or value == '-':
                return 0.0
            
            if isinstance(value, (int, float)):
                return float(value)
            
            value_str = str(value).replace('"', '').replace(',', '').replace('₹', '').replace('%', '')
            if value_str.startswith('(') and value_str.endswith(')'):
                value_str = '-' + value_str[1:-1]
            
            return float(value_str)
        except:
            return 0.0
    
    # ==================== TIER 1: FINANCIAL SAFETY ====================
    
    def check_financial_safety(self, data: Dict) -> Tuple[bool, List[str], Dict]:
        """
        KNOCKOUT ROUND: Company must pass ALL safety checks
        
        Returns: (passes, reasons_if_failed, metrics)
        """
        failures = []
        metrics = {}
        
        if 'balance_sheet' not in data or 'pnl' not in data:
            return False, ["Missing financial data"], {}
        
        bs = data['balance_sheet']
        pnl = data['pnl']
        
        # 1. Debt Safety
        borrowings = self.extract_value(bs, 'Borrowings +')
        equity = self.extract_value(bs, 'Total Equity')
        if equity == 0:
            equity = self.extract_value(bs, 'Equity Capital') + self.extract_value(bs, 'Reserves')
        
        debt_equity = borrowings / equity if equity > 0 else 999
        metrics['debt_equity'] = debt_equity
        
        if debt_equity > self.criteria['safety']['debt_equity_max']:
            failures.append(f"High Debt (D/E={debt_equity:.2f})")
        
        # 2. Liquidity
        current_assets = self.extract_value(bs, 'Other Assets +')
        current_liabilities = self.extract_value(bs, 'Other Liabilities +')
        current_ratio = current_assets / current_liabilities if current_liabilities > 0 else 0
        metrics['current_ratio'] = current_ratio
        
        if current_ratio < self.criteria['safety']['current_ratio_min']:
            failures.append(f"Liquidity Risk (CR={current_ratio:.2f})")
        
        # 3. Operating Cash Flow (must be positive)
        if 'cash_flow' in data:
            cf = data['cash_flow']
            ocf = self.extract_value(cf, 'Cash from Operating Activity +')
            metrics['ocf'] = ocf
            
            if ocf <= 0:
                failures.append("Negative/Zero Operating Cash Flow")
        else:
            failures.append("No cash flow data")
        
        # 4. No consecutive losses
        years = ['Mar 2023', 'Mar 2024']
        losses = 0
        for year in years:
            np = self.extract_value(pnl, 'Net Profit +', year)
            if np < 0:
                losses += 1
        
        metrics['consecutive_losses'] = losses
        if losses > self.criteria['safety']['consecutive_losses_max']:
            failures.append(f"Loss-making ({losses} years)")
        
        passed = len(failures) == 0
        return passed, failures, metrics
    
    # ==================== TIER 2: QUALITY BUSINESS ====================
    
    def assess_quality(self, data: Dict, safety_metrics: Dict) -> Tuple[str, Dict, List[str]]:
        """
        Rate business quality: A (Excellent), B (Good), C (Average), D (Poor)
        
        Focus: Cash generation & capital efficiency (with turnaround detection)
        Returns: (grade, metrics, strengths)
        """
        pnl = data['pnl']
        bs = data['balance_sheet']
        cf = data.get('cash_flow')
        
        metrics = {}
        strengths = []
        points = 0  # Out of 100
        
        # 1. ROIC - Return on Invested Capital (40 points)
        # Enhanced: Blend current ROIC with trend (70% recent, 30% historical)
        
        # Current ROIC (latest year)
        op_profit = self.extract_value(pnl, 'Operating Profit')
        tax_rate = 0.25  # Assume 25% tax
        nopat = op_profit * (1 - tax_rate)
        
        equity = self.extract_value(bs, 'Total Equity')
        if equity == 0:
            equity = self.extract_value(bs, 'Equity Capital') + self.extract_value(bs, 'Reserves')
        borrowings = self.extract_value(bs, 'Borrowings +')
        invested_capital = equity + borrowings
        
        roic_current = (nopat / invested_capital * 100) if invested_capital > 0 else 0
        
        # 3-Year Average ROIC for stability check
        roic_3y = []
        for year in ['Mar 2022', 'Mar 2023', 'Mar 2024']:
            op = self.extract_value(pnl, 'Operating Profit', year)
            eq = self.extract_value(bs, 'Total Equity', year)
            if eq == 0:
                eq = self.extract_value(bs, 'Equity Capital', year) + self.extract_value(bs, 'Reserves', year)
            bor = self.extract_value(bs, 'Borrowings +', year)
            inv_cap = eq + bor
            
            if inv_cap > 0 and op > 0:
                roic_year = (op * 0.75 / inv_cap * 100)
                roic_3y.append(roic_year)
        
        # Blended ROIC: 70% recent (current + 3Y avg), 30% absolute current
        roic_avg_3y = sum(roic_3y) / len(roic_3y) if roic_3y else 0
        roic_blended = (roic_current * 0.5 + roic_avg_3y * 0.5) if roic_3y else roic_current
        
        # Detect turnaround (was negative, now positive)
        is_turnaround = False
        if roic_3y and roic_3y[0] < 5 and roic_current > 10:
            is_turnaround = True
            strengths.append(f"🔄 Turnaround: ROIC improved to {roic_current:.1f}%")
        
        metrics['roic'] = roic_current
        metrics['roic_3y_avg'] = roic_avg_3y
        metrics['roic_blended'] = roic_blended
        metrics['is_turnaround'] = is_turnaround
        
        # Score based on blended ROIC (gives credit to improving trends)
        scoring_roic = roic_blended
        
        if scoring_roic > 25:
            points += 40
            strengths.append(f"Exceptional ROIC ({roic_current:.1f}%)")
        elif scoring_roic > 20:
            points += 35
            strengths.append(f"Excellent ROIC ({roic_current:.1f}%)")
        elif scoring_roic > 15:
            points += 25
        elif scoring_roic > 10:
            points += 15  # Increased from 10 to give credit to improving companies
        elif scoring_roic > 5:
            points += 8   # New tier for emerging quality
        elif is_turnaround and roic_current > 8:
            points += 12  # Bonus for turnarounds showing momentum
        
        # 2. FCF Conversion - Cash vs Accounting Profit (30 points)
        if cf is not None:
            ocf = safety_metrics.get('ocf', 0)
            net_profit = self.extract_value(pnl, 'Net Profit +')
            fcf_conversion = ocf / net_profit if net_profit > 0 else 0
            metrics['fcf_conversion'] = fcf_conversion
            
            if fcf_conversion > 1.3:
                points += 30
                strengths.append(f"Superior Cash Conversion ({fcf_conversion:.2f}x)")
            elif fcf_conversion > 1.0:
                points += 25
                strengths.append(f"Strong Cash Conversion ({fcf_conversion:.2f}x)")
            elif fcf_conversion > 0.7:
                points += 15
        
        # 3. Gross Margin - Pricing Power (20 points)
        # Enhanced: Detect margin expansion (turnaround signal)
        sales = self.extract_value(pnl, 'Sales +')
        op_profit = self.extract_value(pnl, 'Operating Profit')
        gross_margin = (op_profit / sales * 100) if sales > 0 else 0
        
        # Check margin trend (3-year improvement)
        margin_3y = []
        for year in ['Mar 2022', 'Mar 2023', 'Mar 2024']:
            s = self.extract_value(pnl, 'Sales +', year)
            op = self.extract_value(pnl, 'Operating Profit', year)
            if s > 0:
                margin_3y.append((op / s * 100))
        
        margin_improving = False
        margin_expansion_bps = 0
        if len(margin_3y) >= 2:
            margin_expansion_bps = margin_3y[-1] - margin_3y[0]
            if margin_expansion_bps > 500:  # 5%+ expansion
                margin_improving = True
                strengths.append(f"📈 Margin Expansion: +{margin_expansion_bps:.0f}bps")
        
        metrics['gross_margin'] = gross_margin
        metrics['margin_expansion_bps'] = margin_expansion_bps
        metrics['margin_improving'] = margin_improving
        
        # Score (with bonus for improving margins)
        if gross_margin > 30:
            points += 20
            strengths.append(f"High Margins ({gross_margin:.1f}%)")
        elif gross_margin > 25:
            points += 15
        elif gross_margin > 20:
            points += 10
        elif gross_margin > 15 and margin_improving:
            points += 12  # Bonus for improving margins (was 0)
            strengths.append(f"Improving Margins ({gross_margin:.1f}%)")
        elif gross_margin > 10 and margin_improving:
            points += 8   # Give credit to turnarounds
        elif gross_margin > 15:
            points += 5   # Basic credit for reasonable margins
        
        # 4. FCF Consistency (10 points)
        if cf is not None:
            fcf_years = 0
            for year in ['Mar 2022', 'Mar 2023', 'Mar 2024']:
                ocf_year = self.extract_value(cf, 'Cash from Operating Activity +', year)
                icf_year = self.extract_value(cf, 'Cash from Investing Activity +', year)
                capex = abs(icf_year) if icf_year < 0 else 0
                fcf = ocf_year - capex
                if fcf > 0:
                    fcf_years += 1
            
            metrics['fcf_positive_years'] = fcf_years
            if fcf_years >= 3:
                points += 10
                strengths.append(f"Consistent FCF ({fcf_years}Y)")
            elif fcf_years >= 2:
                points += 5
        
        # Grade based on points
        if points >= 80:
            grade = 'A'
        elif points >= 60:
            grade = 'B'
        elif points >= 40:
            grade = 'C'
        else:
            grade = 'D'
        
        metrics['quality_score'] = points
        return grade, metrics, strengths
    
    # ==================== TIER 3: MOAT & GROWTH ====================
    
    def assess_moat(self, data: Dict, quality_metrics: Dict) -> Tuple[str, Dict, List[str]]:
        """
        Evaluate competitive moat and sustainable growth
        
        Returns: (rating, metrics, moat_indicators)
        """
        pnl = data['pnl']
        bs = data['balance_sheet']
        
        metrics = {}
        moat_indicators = []
        points = 0
        
        # 1. Revenue Growth (40 points)
        sales_2024 = self.extract_value(pnl, 'Sales +', 'Mar 2024')
        sales_2019 = self.extract_value(pnl, 'Sales +', 'Mar 2019')
        
        if sales_2019 > 0 and sales_2024 > 0:
            cagr = ((sales_2024 / sales_2019) ** (1/5) - 1) * 100
            metrics['revenue_cagr_5y'] = cagr
            
            if cagr > 25:
                points += 40
                moat_indicators.append(f"Fast Growth ({cagr:.1f}% CAGR)")
            elif cagr > 15:
                points += 30
                moat_indicators.append(f"Strong Growth ({cagr:.1f}% CAGR)")
            elif cagr > 10:
                points += 20
            elif cagr > 5:
                points += 10
        
        # 2. Operating Leverage - Margins expanding faster than revenue (30 points)
        opm_2024 = quality_metrics.get('gross_margin', 0)
        sales_2022 = self.extract_value(pnl, 'Sales +', 'Mar 2022')
        op_2022 = self.extract_value(pnl, 'Operating Profit', 'Mar 2022')
        opm_2022 = (op_2022 / sales_2022 * 100) if sales_2022 > 0 else 0
        
        margin_expansion = opm_2024 - opm_2022
        metrics['margin_trend'] = margin_expansion
        
        if margin_expansion > 5:
            points += 30
            moat_indicators.append("Expanding Margins (Operating Leverage)")
        elif margin_expansion > 2:
            points += 20
        elif margin_expansion > -2:
            points += 10
        
        # 3. Asset-Light Model (20 points)
        total_assets = self.extract_value(bs, 'Total Assets')
        asset_turnover = sales_2024 / total_assets if total_assets > 0 else 0
        metrics['asset_turnover'] = asset_turnover
        
        if asset_turnover > 1.5:
            points += 20
            moat_indicators.append("Capital-Light Business")
        elif asset_turnover > 1.0:
            points += 15
        elif asset_turnover > 0.8:
            points += 10
        
        # 4. Working Capital Efficiency (10 points)
        # NOTE: CCC calculation disabled - data not available from scraper
        # TODO: Update scraper to extract Trade receivables, Inventories, Trade payables
        
        # Placeholder CCC calculation (currently unreliable due to missing data)
        receivables = self.extract_value(bs, 'Trade receivables')
        if receivables == 0:
            receivables = self.extract_value(bs, 'Debtors')
        
        inventory = self.extract_value(bs, 'Inventories')
        payables = self.extract_value(bs, 'Trade payables')
        if payables == 0:
            payables = self.extract_value(bs, 'Creditors')
        
        # Only calculate if we actually have the data
        if receivables > 0 or inventory > 0 or payables > 0:
            if sales_2024 > 0:
                rec_days = (receivables / sales_2024 * 365)
                inv_days = (inventory / sales_2024 * 365)
                pay_days = (payables / sales_2024 * 365)
                ccc = rec_days + inv_days - pay_days
                metrics['ccc'] = ccc
                
                if ccc < 0:
                    points += 10
                    moat_indicators.append("Negative CCC (Supplier Financing)")
                elif ccc < 30:
                    points += 8
                elif ccc < 60:
                    points += 5
                elif ccc < 90:
                    points += 3
        else:
            # Data not available - don't award points
            metrics['ccc'] = None
        
        # Rating
        if points >= 75:
            rating = 'Strong Moat'
        elif points >= 50:
            rating = 'Moderate Moat'
        elif points >= 30:
            rating = 'Weak Moat'
        else:
            rating = 'No Moat'
        
        metrics['moat_score'] = points
        return rating, metrics, moat_indicators
    
    # ==================== TIER 4: VALUATION ====================
    
    def check_valuation(self, company_symbol: str, quality_metrics: Dict, 
                       moat_metrics: Dict) -> Tuple[str, Dict]:
        """
        Only check valuation if company passed quality tests
        
        Returns: (verdict, metrics)
        """
        # Try to load market data from scraper output
        scraper_file = None
        for f in os.listdir(self.data_dir):
            if f.startswith('stage2_shortlist_') and f.endswith('.csv'):
                scraper_file = os.path.join(self.data_dir, f)
                break
        
        if not scraper_file:
            return "Unknown", {}
        
        try:
            df = pd.read_csv(scraper_file)
            company_data = df[df['company_name'].str.contains(company_symbol, case=False, na=False)]
            
            if company_data.empty:
                return "Unknown", {}
            
            row = company_data.iloc[0]
            
            pe = row.get('pe_ratio', 0)
            mcap = row.get('market_cap', 0)
            
            metrics = {
                'pe_ratio': pe,
                'market_cap': mcap
            }
            
            # Simple valuation check
            roic = quality_metrics.get('roic', 0)
            growth = moat_metrics.get('revenue_cagr_5y', 0)
            
            # PEG ratio
            peg = pe / growth if growth > 0 else 999
            metrics['peg'] = peg
            
            # Valuation verdict
            if pe < 15:
                verdict = "Cheap"
            elif pe < 25 and peg < 1.5:
                verdict = "Fair (Growth-adjusted)"
            elif pe < 35 and roic > 20:
                verdict = "Reasonable (High Quality)"
            else:
                verdict = "Expensive"
            
            return verdict, metrics
            
        except Exception as e:
            logger.debug(f"Valuation check failed: {e}")
            return "Unknown", {}
    
    # ==================== FINAL DECISION ====================
    
    def make_decision(self, company_symbol: str, safety_passed: bool, 
                     quality_grade: str, moat_rating: str, valuation: str,
                     all_metrics: Dict, strengths: List[str],
                     moat_indicators: List[str]) -> Dict:
        """
        Final investment decision using pyramid logic
        """
        
        # Decision logic
        if not safety_passed:
            decision = "PASS"
            reason = "Failed financial safety checks"
            action = "🚫 Avoid - Safety concerns"
        
        elif quality_grade == 'D':
            decision = "PASS"
            reason = "Poor business quality"
            action = "🚫 Avoid - Low quality business"
        
        elif quality_grade == 'A' and moat_rating in ['Strong Moat', 'Moderate Moat']:
            if valuation in ["Cheap", "Fair (Growth-adjusted)"]:
                decision = "BUY"
                reason = "High quality + Moat + Reasonable price"
                action = "✅ BUY - Excellent opportunity"
            elif valuation == "Reasonable (High Quality)":
                decision = "WATCH"
                reason = "Excellent business, slightly expensive"
                action = "⚠️ WATCH - Quality worth paying for, but wait for dip"
            else:
                decision = "WATCH"
                reason = "Great business, too expensive"
                action = "⚠️ WATCH - Wait for better valuation"
        
        elif quality_grade in ['A', 'B'] and moat_rating != 'No Moat':
            if valuation in ["Cheap", "Fair (Growth-adjusted)"]:
                decision = "BUY"
                reason = "Good quality + Growth + Fair price"
                action = "✅ BUY - Solid opportunity"
            else:
                decision = "WATCH"
                reason = "Good business, valuation stretched"
                action = "⚠️ WATCH - Wait for correction"
        
        elif quality_grade == 'C':
            decision = "WATCH"
            reason = "Average quality, needs monitoring"
            action = "⚠️ WATCH - Average business, risky"
        
        else:
            decision = "PASS"
            reason = "Doesn't meet investment criteria"
            action = "🚫 PASS - Better opportunities elsewhere"
        
        return {
            'company': company_symbol,
            'decision': decision,
            'action': action,
            'reason': reason,
            'quality_grade': quality_grade,
            'moat_rating': moat_rating,
            'valuation': valuation,
            'strengths': strengths,
            'moat_indicators': moat_indicators,
            'metrics': all_metrics
        }
    
    def analyze_company(self, company_symbol: str) -> Optional[Dict]:
        """Run complete pyramid analysis"""
        
        logger.info(f"\n{'='*70}")
        logger.info(f"ANALYZING: {company_symbol}")
        logger.info(f"{'='*70}")
        
        # Load data
        data = self.load_company_data(company_symbol)
        if not data:
            logger.warning(f"No data for {company_symbol}")
            return None
        
        # TIER 1: Safety
        logger.info("\n🛡️  TIER 1: Financial Safety Check...")
        safety_passed, failures, safety_metrics = self.check_financial_safety(data)
        
        if not safety_passed:
            logger.warning(f"❌ FAILED: {', '.join(failures)}")
            result = self.make_decision(
                company_symbol, False, 'D', 'No Moat', 'Unknown',
                safety_metrics, [], []
            )
            return result
        else:
            logger.info("✅ PASSED: Financially safe")
        
        # TIER 2: Quality
        logger.info("\n💎 TIER 2: Business Quality Assessment...")
        quality_grade, quality_metrics, strengths = self.assess_quality(data, safety_metrics)
        logger.info(f"Grade: {quality_grade} ({quality_metrics.get('quality_score', 0)}/100)")
        if strengths:
            for s in strengths:
                logger.info(f"  • {s}")
        
        # TIER 3: Moat
        logger.info("\n🏰 TIER 3: Competitive Moat Analysis...")
        moat_rating, moat_metrics, moat_indicators = self.assess_moat(data, quality_metrics)
        logger.info(f"Rating: {moat_rating} ({moat_metrics.get('moat_score', 0)}/100)")
        if moat_indicators:
            for m in moat_indicators:
                logger.info(f"  • {m}")
        
        # TIER 4: Valuation
        logger.info("\n💰 TIER 4: Valuation Check...")
        valuation, val_metrics = self.check_valuation(company_symbol, quality_metrics, moat_metrics)
        logger.info(f"Verdict: {valuation}")
        if val_metrics:
            logger.info(f"  P/E: {val_metrics.get('pe_ratio', 0):.1f}, PEG: {val_metrics.get('peg', 0):.2f}")
        
        # Combine all metrics
        all_metrics = {**safety_metrics, **quality_metrics, **moat_metrics, **val_metrics}
        
        # Final Decision
        result = self.make_decision(
            company_symbol, safety_passed, quality_grade, moat_rating,
            valuation, all_metrics, strengths, moat_indicators
        )
        
        logger.info(f"\n{'='*70}")
        logger.info(f"FINAL DECISION: {result['action']}")
        logger.info(f"Reason: {result['reason']}")
        logger.info(f"{'='*70}")
        
        return result
    
    def scan_all_companies(self) -> pd.DataFrame:
        """Analyze all companies and return results"""
        
        pnl_dir = os.path.join(self.data_dir, "pnl_data")
        if not os.path.exists(pnl_dir):
            logger.error(f"Data directory not found: {pnl_dir}")
            return pd.DataFrame()
        
        companies = [
            f.replace('_pnl.csv', '')
            for f in os.listdir(pnl_dir)
            if f.endswith('_pnl.csv')
        ]
        
        logger.info(f"\n🔍 Analyzing {len(companies)} companies using Investment Pyramid...")
        
        results = []
        for company in companies:
            result = self.analyze_company(company)
            if result:
                results.append(result)
        
        # Convert to DataFrame
        df = pd.DataFrame(results)
        
        # Sort: BUY first, then WATCH, then PASS
        decision_order = {'BUY': 0, 'WATCH': 1, 'PASS': 2}
        df['_sort'] = df['decision'].map(decision_order)
        df = df.sort_values(['_sort', 'quality_grade', 'moat_rating'])
        df = df.drop('_sort', axis=1)
        
        return df
    
    def generate_report(self, df: pd.DataFrame):
        """Generate actionable investment report"""
        
        if df.empty:
            print("No companies analyzed")
            return
        
        print("\n" + "="*90)
        print("INVESTMENT FILTER RESULTS - ACTIONABLE REPORT".center(90))
        print("="*90)
        
        # Summary
        buy_count = len(df[df['decision'] == 'BUY'])
        watch_count = len(df[df['decision'] == 'WATCH'])
        pass_count = len(df[df['decision'] == 'PASS'])
        
        print(f"\n📊 Portfolio Actions:")
        print(f"   ✅ BUY NOW: {buy_count} companies")
        print(f"   ⚠️  WATCH LIST: {watch_count} companies")
        print(f"   🚫 PASS: {pass_count} companies")
        
        # BUY recommendations
        if buy_count > 0:
            print(f"\n{'='*90}")
            print("✅ BUY RECOMMENDATIONS (High conviction)")
            print("="*90)
            
            buy_df = df[df['decision'] == 'BUY']
            for idx, row in buy_df.iterrows():
                print(f"\n{row['company']}")
                print(f"   Quality: {row['quality_grade']} | Moat: {row['moat_rating']} | Valuation: {row['valuation']}")
                print(f"   Reason: {row['reason']}")
                
                if row['strengths']:
                    print(f"   Strengths: {', '.join(row['strengths'][:3])}")
                
                # Key metrics
                m = row['metrics']
                print(f"   📈 ROIC: {m.get('roic', 0):.1f}% | FCF Conv: {m.get('fcf_conversion', 0):.2f}x | Growth: {m.get('revenue_cagr_5y', 0):.1f}%")
        
        # WATCH list
        if watch_count > 0 and watch_count <= 10:
            print(f"\n{'='*90}")
            print("⚠️  WATCH LIST (Good businesses, wait for better entry)")
            print("="*90)
            
            watch_df = df[df['decision'] == 'WATCH'].head(10)
            for idx, row in watch_df.iterrows():
                print(f"\n{row['company']}")
                print(f"   Quality: {row['quality_grade']} | Moat: {row['moat_rating']} | Valuation: {row['valuation']}")
                print(f"   {row['reason']}")
        
        print(f"\n{'='*90}")


def main():
    """Run the professional investment filter"""
    
    filter_system = InvestmentFilter(data_dir="output")
    
    # Scan all companies
    df = filter_system.scan_all_companies()
    
    # Generate report
    filter_system.generate_report(df)
    
    # Save results
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"investment_decisions_{timestamp}.csv"
    
    # Prepare clean CSV
    csv_data = []
    for _, row in df.iterrows():
        m = row['metrics']
        csv_data.append({
            'Company': row['company'],
            'Decision': row['decision'],
            'Action': row['action'],
            'Quality_Grade': row['quality_grade'],
            'Moat_Rating': row['moat_rating'],
            'Valuation': row['valuation'],
            'Reason': row['reason'],
            
            # Key Metrics
            'ROIC_%': m.get('roic', 0),
            'FCF_Conversion': m.get('fcf_conversion', 0),
            'Gross_Margin_%': m.get('gross_margin', 0),
            'Revenue_CAGR_5Y_%': m.get('revenue_cagr_5y', 0),
            'Asset_Turnover': m.get('asset_turnover', 0),
            'CCC_Days': m.get('ccc', 0),
            'Debt_Equity': m.get('debt_equity', 0),
            'Current_Ratio': m.get('current_ratio', 0),
            'P/E': m.get('pe_ratio', 0),
            'PEG': m.get('peg', 0),
            
            'Strengths': ' | '.join(row['strengths']),
            'Moat_Indicators': ' | '.join(row['moat_indicators'])
        })
    
    pd.DataFrame(csv_data).to_csv(output_file, index=False, encoding='utf-8-sig')
    
    print(f"\n📁 Results saved to: {output_file}")
    print("="*90)


if __name__ == "__main__":
    main()

