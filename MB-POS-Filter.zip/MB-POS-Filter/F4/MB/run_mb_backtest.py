"""
Quick-Start Script for MultiBeggar Backtesting
==============================================
Simplified interface to run backtests with predefined scenarios

Usage:
    python run_mb_backtest.py --scenario default
    python run_mb_backtest.py --scenario aggressive
    python run_mb_backtest.py --scenario conservative
    python run_mb_backtest.py --scenario custom
"""

import argparse
from MBBacktester import *

# =============================================================================
# PREDEFINED SCENARIOS
# =============================================================================

SCENARIOS = {
    'default': {
        'name': 'Default Scanner Settings',
        'description': 'Use exact settings from MBSystemGemini.py scanner',
        'config': {
            'trix_threshold': 1.5,
            'kc_distance_threshold': 0.5,
            'kc_slope_required': True,
            'trix_momentum_required': True,
            'bearish_fractal_bonus': True,
            'rsi_threshold': 70,
            'volume_ratio_threshold': 0.8,
            'atr_percent_threshold': 8.0,
            'entry_conditions_required': 4,
            'fractal_strength_required': True,
            'exit_strategy': 'hybrid',
            'trailing_stop_pct': 0.15,
            'hold_period_min': 4,
            'hold_period_max': 52,
            'conviction_multiplier': 1.5,
            'volatility_target': 0.03,
        }
    },
    
    'aggressive': {
        'name': 'Aggressive (More Signals, Higher Risk)',
        'description': 'Looser filters, shorter holds, more trades',
        'config': {
            'trix_threshold': 2.0,           # Allow higher TRIX (more signals)
            'kc_distance_threshold': 0.5,
            'kc_slope_required': False,      # Don't require KC slope
            'trix_momentum_required': False,  # Don't require momentum
            'bearish_fractal_bonus': True,
            'rsi_threshold': 75,             # Allow higher RSI
            'volume_ratio_threshold': 0.8,
            'atr_percent_threshold': 10.0,   # Allow higher volatility
            'entry_conditions_required': 3,   # Only need 3/6 conditions
            'fractal_strength_required': False,
            'exit_strategy': 'trailing_stop',  # Faster exits
            'trailing_stop_pct': 0.12,       # Tighter stop (12%)
            'hold_period_min': 2,            # Shorter minimum hold
            'hold_period_max': 26,           # Shorter maximum hold (6 months)
            'conviction_multiplier': 2.0,     # Bigger positions on winners
            'volatility_target': 0.04,
        }
    },
    
    'conservative': {
        'name': 'Conservative (Fewer Signals, Lower Risk)',
        'description': 'Stricter filters, longer holds, fewer trades',
        'config': {
            'trix_threshold': 1.0,           # Lower TRIX threshold (fewer signals)
            'kc_distance_threshold': 1.0,    # Must be further from KC
            'kc_slope_required': True,
            'trix_momentum_required': True,
            'bearish_fractal_bonus': True,
            'rsi_threshold': 65,             # Lower RSI threshold
            'volume_ratio_threshold': 1.0,   # Higher volume required
            'atr_percent_threshold': 6.0,    # Lower volatility only
            'entry_conditions_required': 5,   # Need 5/6 conditions
            'fractal_strength_required': True,
            'exit_strategy': 'hybrid',
            'trailing_stop_pct': 0.20,       # Wider stop (20%)
            'hold_period_min': 8,            # Longer minimum hold
            'hold_period_max': 52,           # Full year hold
            'conviction_multiplier': 1.0,     # Equal weight only
            'volatility_target': 0.02,
        }
    },
    
    'fractal_focus': {
        'name': 'Fractal Breakout Focus',
        'description': 'Heavy emphasis on bearish fractal breakouts',
        'config': {
            'trix_threshold': 2.0,           # Relax TRIX (fractal is main signal)
            'kc_distance_threshold': 0.5,
            'kc_slope_required': True,
            'trix_momentum_required': False,
            'bearish_fractal_bonus': True,   # MUST have BF breakout
            'rsi_threshold': 70,
            'volume_ratio_threshold': 1.0,   # Need volume on breakout
            'atr_percent_threshold': 8.0,
            'entry_conditions_required': 4,
            'fractal_strength_required': True,  # Weekly fractal strength
            'exit_strategy': 'fractal_break',   # Exit on bearish fractal
            'trailing_stop_pct': 0.15,
            'hold_period_min': 4,
            'hold_period_max': 39,           # 9 months
            'conviction_multiplier': 1.5,
            'volatility_target': 0.03,
        }
    },
    
    'trend_rider': {
        'name': 'Trend Rider (Long Holds)',
        'description': 'Enter early, hold long, let winners run',
        'config': {
            'trix_threshold': 1.5,
            'kc_distance_threshold': 0.5,
            'kc_slope_required': True,
            'trix_momentum_required': True,
            'bearish_fractal_bonus': True,
            'rsi_threshold': 70,
            'volume_ratio_threshold': 0.8,
            'atr_percent_threshold': 8.0,
            'entry_conditions_required': 4,
            'fractal_strength_required': False,
            'exit_strategy': 'trix_deterioration',  # Only exit on TRIX flip
            'trailing_stop_pct': 0.25,       # Wide stop (25%)
            'hold_period_min': 12,           # Long minimum hold (3 months)
            'hold_period_max': 104,          # 2 years maximum
            'conviction_multiplier': 1.5,
            'volatility_target': 0.03,
        }
    },
}

# =============================================================================
# ANALYSIS FUNCTIONS
# =============================================================================

def compare_scenarios(scenarios: List[str], data_fetcher: KiteDataFetcher):
    """Compare multiple scenarios side-by-side"""
    logger.info("\n" + "="*80)
    logger.info("SCENARIO COMPARISON")
    logger.info("="*80)
    
    results = {}
    
    for scenario_name in scenarios:
        if scenario_name not in SCENARIOS:
            logger.error(f"Unknown scenario: {scenario_name}")
            continue
        
        scenario = SCENARIOS[scenario_name]
        logger.info(f"\n--- Running Scenario: {scenario['name']} ---")
        logger.info(f"Description: {scenario['description']}")
        
        # Run backtest
        backtester = MBBacktester(scenario['config'], data_fetcher)
        metrics = backtester.run_backtest(
            datetime.strptime(BACKTEST_START_DATE, '%Y-%m-%d'),
            datetime.strptime(BACKTEST_END_DATE, '%Y-%m-%d')
        )
        
        results[scenario_name] = {
            'scenario': scenario,
            'metrics': metrics,
            'trades': backtester.trade_history,
            'equity_curve': backtester.equity_curve
        }
    
    # Generate comparison table
    logger.info("\n" + "="*80)
    logger.info("SCENARIO COMPARISON SUMMARY")
    logger.info("="*80)
    
    comparison_data = []
    for scenario_name, result in results.items():
        metrics = result['metrics']
        comparison_data.append({
            'Scenario': scenario_name,
            'CAGR (%)': f"{metrics.get('cagr', 0):.2f}",
            'Max DD (%)': f"{metrics.get('max_drawdown', 0):.2f}",
            'Sharpe': f"{metrics.get('sharpe_ratio', 0):.2f}",
            'Win Rate (%)': f"{metrics.get('win_rate', 0):.2f}",
            'Num Trades': f"{metrics.get('num_trades', 0)}",
            'Avg Hold (days)': f"{metrics.get('avg_hold_days', 0):.0f}",
            'Final Equity': f"₹{metrics.get('final_equity', 0):,.0f}"
        })
    
    comparison_df = pd.DataFrame(comparison_data)
    logger.info("\n" + comparison_df.to_string(index=False))
    
    # Save comparison
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    comparison_file = os.path.join(OUTPUT_DIR, f'scenario_comparison_{timestamp}.csv')
    comparison_df.to_csv(comparison_file, index=False)
    logger.info(f"\nComparison saved to {comparison_file}")
    
    return results

def analyze_parameter_sensitivity(param_name: str, param_values: List, 
                                  base_config: Dict, data_fetcher: KiteDataFetcher):
    """Analyze sensitivity of a single parameter"""
    logger.info(f"\n--- Sensitivity Analysis: {param_name} ---")
    logger.info(f"Testing values: {param_values}")
    
    results = []
    
    for value in param_values:
        config = base_config.copy()
        config[param_name] = value
        
        logger.info(f"\nTesting {param_name} = {value}")
        backtester = MBBacktester(config, data_fetcher)
        metrics = backtester.run_backtest(
            datetime.strptime(BACKTEST_START_DATE, '%Y-%m-%d'),
            datetime.strptime(BACKTEST_END_DATE, '%Y-%m-%d')
        )
        
        results.append({
            'param_value': value,
            'cagr': metrics.get('cagr', 0),
            'sharpe': metrics.get('sharpe_ratio', 0),
            'max_dd': metrics.get('max_drawdown', 0),
            'win_rate': metrics.get('win_rate', 0),
            'num_trades': metrics.get('num_trades', 0)
        })
    
    # Plot sensitivity
    results_df = pd.DataFrame(results)
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle(f'Sensitivity Analysis: {param_name}', fontsize=16)
    
    axes[0, 0].plot(results_df['param_value'], results_df['cagr'], marker='o')
    axes[0, 0].set_title('CAGR vs Parameter Value')
    axes[0, 0].set_xlabel(param_name)
    axes[0, 0].set_ylabel('CAGR (%)')
    axes[0, 0].grid(True)
    
    axes[0, 1].plot(results_df['param_value'], results_df['sharpe'], marker='o', color='green')
    axes[0, 1].set_title('Sharpe Ratio vs Parameter Value')
    axes[0, 1].set_xlabel(param_name)
    axes[0, 1].set_ylabel('Sharpe Ratio')
    axes[0, 1].grid(True)
    
    axes[1, 0].plot(results_df['param_value'], results_df['max_dd'], marker='o', color='red')
    axes[1, 0].set_title('Max Drawdown vs Parameter Value')
    axes[1, 0].set_xlabel(param_name)
    axes[1, 0].set_ylabel('Max DD (%)')
    axes[1, 0].grid(True)
    
    axes[1, 1].plot(results_df['param_value'], results_df['num_trades'], marker='o', color='orange')
    axes[1, 1].set_title('Number of Trades vs Parameter Value')
    axes[1, 1].set_xlabel(param_name)
    axes[1, 1].set_ylabel('Num Trades')
    axes[1, 1].grid(True)
    
    plt.tight_layout()
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    plot_file = os.path.join(OUTPUT_DIR, f'sensitivity_{param_name}_{timestamp}.png')
    plt.savefig(plot_file, dpi=150)
    logger.info(f"Sensitivity plot saved to {plot_file}")
    
    return results_df

# =============================================================================
# MAIN CLI
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description='MultiBeggar Strategy Backtester')
    parser.add_argument('--scenario', type=str, default='default',
                       help='Scenario to run: default, aggressive, conservative, fractal_focus, trend_rider')
    parser.add_argument('--compare', nargs='+',
                       help='Compare multiple scenarios (space-separated)')
    parser.add_argument('--sensitivity', type=str,
                       help='Run sensitivity analysis on a parameter')
    parser.add_argument('--param-values', nargs='+', type=float,
                       help='Values to test for sensitivity analysis')
    
    args = parser.parse_args()
    
    # Initialize API
    logger.info("Initializing Kite API...")
    data_fetcher = KiteDataFetcher(API_KEY, ACCESS_TOKEN)
    
    if args.compare:
        # Compare multiple scenarios
        compare_scenarios(args.compare, data_fetcher)
    
    elif args.sensitivity:
        # Sensitivity analysis
        if not args.param_values:
            logger.error("Must provide --param-values for sensitivity analysis")
            return
        
        base_config = SCENARIOS['default']['config']
        analyze_parameter_sensitivity(args.sensitivity, args.param_values, base_config, data_fetcher)
    
    else:
        # Run single scenario
        if args.scenario not in SCENARIOS:
            logger.error(f"Unknown scenario: {args.scenario}")
            logger.info(f"Available scenarios: {list(SCENARIOS.keys())}")
            return
        
        scenario = SCENARIOS[args.scenario]
        logger.info(f"\n--- Running Scenario: {scenario['name']} ---")
        logger.info(f"Description: {scenario['description']}")
        
        backtester = MBBacktester(scenario['config'], data_fetcher)
        metrics = backtester.run_backtest(
            datetime.strptime(BACKTEST_START_DATE, '%Y-%m-%d'),
            datetime.strptime(BACKTEST_END_DATE, '%Y-%m-%d')
        )
        
        # Print results
        logger.info("\n" + "="*80)
        logger.info("BACKTEST RESULTS")
        logger.info("="*80)
        logger.info(f"Final Equity: ₹{metrics.get('final_equity', 0):,.0f}")
        logger.info(f"Total Return: {metrics.get('total_return', 0):.2f}%")
        logger.info(f"CAGR: {metrics.get('cagr', 0):.2f}%")
        logger.info(f"Max Drawdown: {metrics.get('max_drawdown', 0):.2f}%")
        logger.info(f"Sharpe Ratio: {metrics.get('sharpe_ratio', 0):.2f}")
        logger.info(f"Number of Trades: {metrics.get('num_trades', 0)}")
        logger.info(f"Win Rate: {metrics.get('win_rate', 0):.2f}%")
        logger.info(f"Avg Win: {metrics.get('avg_win', 0):.2f}%")
        logger.info(f"Avg Loss: {metrics.get('avg_loss', 0):.2f}%")
        logger.info(f"Profit Factor: {metrics.get('profit_factor', 0):.2f}")
        logger.info(f"Avg Hold Period: {metrics.get('avg_hold_days', 0):.0f} days")
        
        # Save trades
        if backtester.trade_history:
            trades_df = pd.DataFrame(backtester.trade_history)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            trades_file = os.path.join(OUTPUT_DIR, f'trades_{args.scenario}_{timestamp}.csv')
            trades_df.to_csv(trades_file, index=False)
            logger.info(f"\nTrades saved to {trades_file}")
            
            # Show sample trades
            logger.info("\n--- Sample Trades ---")
            logger.info(trades_df.head(10).to_string(index=False))

if __name__ == "__main__":
    main()

