"""
MultiBeggar Backtest Results Analyzer
=====================================
Visualize and analyze backtest results from parameter testing

Usage:
    python analyze_mb_results.py --results parameter_test_results_20251023_120000.pkl
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import argparse
import os
from datetime import datetime
import pickle

# Set style
sns.set_style('darkgrid')
plt.rcParams['figure.figsize'] = (16, 10)

def load_results(results_file: str):
    """Load backtest results from pickle file"""
    try:
        results_df = pd.read_pickle(results_file)
        print(f"Loaded {len(results_df)} test results from {results_file}")
        return results_df
    except Exception as e:
        print(f"Error loading results: {e}")
        return None

def extract_metrics(results_df: pd.DataFrame):
    """Extract metrics from nested results structure"""
    data = []
    
    for idx, row in results_df.iterrows():
        config = row['config']
        in_sample = row['in_sample']
        oos = row['out_of_sample']
        
        record = config.copy()
        
        # In-sample metrics
        record['is_cagr'] = in_sample.get('cagr', 0)
        record['is_max_dd'] = in_sample.get('max_drawdown', 0)
        record['is_sharpe'] = in_sample.get('sharpe_ratio', 0)
        record['is_win_rate'] = in_sample.get('win_rate', 0)
        record['is_num_trades'] = in_sample.get('num_trades', 0)
        record['is_profit_factor'] = in_sample.get('profit_factor', 0)
        
        # Out-of-sample metrics (if available)
        if oos:
            record['oos_cagr'] = oos.get('cagr', 0)
            record['oos_max_dd'] = oos.get('max_drawdown', 0)
            record['oos_sharpe'] = oos.get('sharpe_ratio', 0)
            record['oos_win_rate'] = oos.get('win_rate', 0)
            record['oos_num_trades'] = oos.get('num_trades', 0)
        
        data.append(record)
    
    return pd.DataFrame(data)

def plot_parameter_impact(df: pd.DataFrame, param_name: str, output_dir: str):
    """Plot how a single parameter affects key metrics"""
    if param_name not in df.columns:
        print(f"Parameter {param_name} not found in results")
        return
    
    # Group by parameter value
    grouped = df.groupby(param_name).agg({
        'is_cagr': ['mean', 'std', 'min', 'max'],
        'is_sharpe': ['mean', 'std'],
        'is_max_dd': ['mean', 'std'],
        'is_win_rate': ['mean', 'std'],
        'is_num_trades': ['mean', 'std']
    }).reset_index()
    
    # Create subplots
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))
    fig.suptitle(f'Parameter Impact Analysis: {param_name}', fontsize=16, fontweight='bold')
    
    # CAGR
    ax = axes[0, 0]
    param_values = grouped[param_name]
    ax.errorbar(param_values, grouped[('is_cagr', 'mean')], 
                yerr=grouped[('is_cagr', 'std')], 
                marker='o', capsize=5, capthick=2, linewidth=2)
    ax.fill_between(param_values, 
                     grouped[('is_cagr', 'min')], 
                     grouped[('is_cagr', 'max')], 
                     alpha=0.2)
    ax.set_xlabel(param_name, fontsize=12)
    ax.set_ylabel('CAGR (%)', fontsize=12)
    ax.set_title('CAGR vs Parameter Value', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    # Sharpe Ratio
    ax = axes[0, 1]
    ax.errorbar(param_values, grouped[('is_sharpe', 'mean')], 
                yerr=grouped[('is_sharpe', 'std')], 
                marker='o', capsize=5, capthick=2, linewidth=2, color='green')
    ax.set_xlabel(param_name, fontsize=12)
    ax.set_ylabel('Sharpe Ratio', fontsize=12)
    ax.set_title('Sharpe Ratio vs Parameter Value', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    # Max Drawdown
    ax = axes[0, 2]
    ax.errorbar(param_values, grouped[('is_max_dd', 'mean')], 
                yerr=grouped[('is_max_dd', 'std')], 
                marker='o', capsize=5, capthick=2, linewidth=2, color='red')
    ax.set_xlabel(param_name, fontsize=12)
    ax.set_ylabel('Max Drawdown (%)', fontsize=12)
    ax.set_title('Max Drawdown vs Parameter Value', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    # Win Rate
    ax = axes[1, 0]
    ax.errorbar(param_values, grouped[('is_win_rate', 'mean')], 
                yerr=grouped[('is_win_rate', 'std')], 
                marker='o', capsize=5, capthick=2, linewidth=2, color='orange')
    ax.set_xlabel(param_name, fontsize=12)
    ax.set_ylabel('Win Rate (%)', fontsize=12)
    ax.set_title('Win Rate vs Parameter Value', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    # Number of Trades
    ax = axes[1, 1]
    ax.errorbar(param_values, grouped[('is_num_trades', 'mean')], 
                yerr=grouped[('is_num_trades', 'std')], 
                marker='o', capsize=5, capthick=2, linewidth=2, color='purple')
    ax.set_xlabel(param_name, fontsize=12)
    ax.set_ylabel('Number of Trades', fontsize=12)
    ax.set_title('Number of Trades vs Parameter Value', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    # Risk-Adjusted Return (CAGR / Max DD)
    ax = axes[1, 2]
    risk_adj_return = grouped[('is_cagr', 'mean')] / abs(grouped[('is_max_dd', 'mean')])
    ax.plot(param_values, risk_adj_return, marker='o', linewidth=2, color='brown')
    ax.set_xlabel(param_name, fontsize=12)
    ax.set_ylabel('CAGR / Max DD', fontsize=12)
    ax.set_title('Risk-Adjusted Return', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    # Save plot
    plot_file = os.path.join(output_dir, f'parameter_impact_{param_name}.png')
    plt.savefig(plot_file, dpi=150, bbox_inches='tight')
    print(f"Saved plot: {plot_file}")
    plt.close()

def plot_correlation_matrix(df: pd.DataFrame, output_dir: str):
    """Plot correlation between parameters and performance metrics"""
    # Select numeric columns only
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    
    # Filter to key metrics
    key_metrics = ['is_cagr', 'is_sharpe', 'is_max_dd', 'is_win_rate', 'is_num_trades']
    available_metrics = [col for col in key_metrics if col in numeric_cols]
    
    if not available_metrics:
        print("No numeric metrics found for correlation analysis")
        return
    
    # Compute correlation
    corr_df = df[numeric_cols].corr()
    
    # Plot heatmap
    fig, ax = plt.subplots(figsize=(14, 12))
    sns.heatmap(corr_df, annot=True, fmt='.2f', cmap='coolwarm', center=0,
                square=True, linewidths=0.5, cbar_kws={"shrink": 0.8}, ax=ax)
    ax.set_title('Parameter-Metric Correlation Matrix', fontsize=16, fontweight='bold', pad=20)
    
    plt.tight_layout()
    
    plot_file = os.path.join(output_dir, 'correlation_matrix.png')
    plt.savefig(plot_file, dpi=150, bbox_inches='tight')
    print(f"Saved plot: {plot_file}")
    plt.close()

def plot_pareto_frontier(df: pd.DataFrame, output_dir: str):
    """Plot Pareto frontier: CAGR vs Max Drawdown"""
    fig, ax = plt.subplots(figsize=(12, 8))
    
    # Scatter plot
    scatter = ax.scatter(abs(df['is_max_dd']), df['is_cagr'], 
                        c=df['is_sharpe'], cmap='viridis', 
                        s=100, alpha=0.6, edgecolors='black')
    
    # Find Pareto-optimal points (higher CAGR, lower DD)
    pareto_points = []
    for idx, row in df.iterrows():
        is_dominated = False
        for idx2, row2 in df.iterrows():
            if idx == idx2:
                continue
            # row2 dominates row if it has higher CAGR AND lower DD
            if row2['is_cagr'] >= row['is_cagr'] and abs(row2['is_max_dd']) <= abs(row['is_max_dd']):
                if row2['is_cagr'] > row['is_cagr'] or abs(row2['is_max_dd']) < abs(row['is_max_dd']):
                    is_dominated = True
                    break
        if not is_dominated:
            pareto_points.append(idx)
    
    # Highlight Pareto frontier
    pareto_df = df.iloc[pareto_points].sort_values('is_max_dd')
    ax.plot(abs(pareto_df['is_max_dd']), pareto_df['is_cagr'], 
            'r--', linewidth=2, label='Pareto Frontier', alpha=0.7)
    ax.scatter(abs(pareto_df['is_max_dd']), pareto_df['is_cagr'], 
              s=200, facecolors='none', edgecolors='red', linewidths=2)
    
    # Color bar
    cbar = plt.colorbar(scatter, ax=ax)
    cbar.set_label('Sharpe Ratio', fontsize=12)
    
    ax.set_xlabel('Max Drawdown (%)', fontsize=12)
    ax.set_ylabel('CAGR (%)', fontsize=12)
    ax.set_title('Risk-Return Pareto Frontier', fontsize=16, fontweight='bold')
    ax.legend(fontsize=12)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    plot_file = os.path.join(output_dir, 'pareto_frontier.png')
    plt.savefig(plot_file, dpi=150, bbox_inches='tight')
    print(f"Saved plot: {plot_file}")
    plt.close()
    
    return pareto_df

def plot_top_configs(df: pd.DataFrame, output_dir: str, top_n=10):
    """Bar chart of top N configurations by CAGR"""
    # Sort by CAGR
    top_configs = df.nlargest(top_n, 'is_cagr')
    
    fig, axes = plt.subplots(2, 1, figsize=(14, 10))
    
    # CAGR bar chart
    ax = axes[0]
    x_pos = np.arange(len(top_configs))
    bars = ax.bar(x_pos, top_configs['is_cagr'], color='steelblue', alpha=0.7, edgecolor='black')
    
    # Color bars by Sharpe Ratio
    norm = plt.Normalize(vmin=top_configs['is_sharpe'].min(), vmax=top_configs['is_sharpe'].max())
    colors = plt.cm.RdYlGn(norm(top_configs['is_sharpe']))
    for bar, color in zip(bars, colors):
        bar.set_color(color)
    
    ax.set_xlabel('Configuration Rank', fontsize=12)
    ax.set_ylabel('CAGR (%)', fontsize=12)
    ax.set_title(f'Top {top_n} Configurations by CAGR (colored by Sharpe)', fontsize=14, fontweight='bold')
    ax.set_xticks(x_pos)
    ax.set_xticklabels([f'#{i+1}' for i in range(len(top_configs))], fontsize=10)
    ax.grid(True, alpha=0.3, axis='y')
    
    # Max Drawdown comparison
    ax = axes[1]
    bars_dd = ax.bar(x_pos, abs(top_configs['is_max_dd']), color='salmon', alpha=0.7, edgecolor='black')
    ax.set_xlabel('Configuration Rank', fontsize=12)
    ax.set_ylabel('Max Drawdown (%)', fontsize=12)
    ax.set_title(f'Max Drawdown for Top {top_n} CAGR Configurations', fontsize=14, fontweight='bold')
    ax.set_xticks(x_pos)
    ax.set_xticklabels([f'#{i+1}' for i in range(len(top_configs))], fontsize=10)
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    
    plot_file = os.path.join(output_dir, 'top_configurations.png')
    plt.savefig(plot_file, dpi=150, bbox_inches='tight')
    print(f"Saved plot: {plot_file}")
    plt.close()

def generate_insights_report(df: pd.DataFrame, output_dir: str):
    """Generate text report with key insights"""
    report = []
    report.append("="*80)
    report.append("MULTIBEGGAR BACKTEST ANALYSIS - KEY INSIGHTS")
    report.append("="*80)
    report.append(f"\nAnalysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append(f"Total Configurations Tested: {len(df)}")
    
    # Overall statistics
    report.append("\n" + "-"*80)
    report.append("OVERALL PERFORMANCE STATISTICS")
    report.append("-"*80)
    report.append(f"\nCAGR:")
    report.append(f"  Mean: {df['is_cagr'].mean():.2f}%")
    report.append(f"  Median: {df['is_cagr'].median():.2f}%")
    report.append(f"  Std Dev: {df['is_cagr'].std():.2f}%")
    report.append(f"  Range: {df['is_cagr'].min():.2f}% to {df['is_cagr'].max():.2f}%")
    
    report.append(f"\nMax Drawdown:")
    report.append(f"  Mean: {df['is_max_dd'].mean():.2f}%")
    report.append(f"  Median: {df['is_max_dd'].median():.2f}%")
    report.append(f"  Std Dev: {df['is_max_dd'].std():.2f}%")
    report.append(f"  Range: {df['is_max_dd'].min():.2f}% to {df['is_max_dd'].max():.2f}%")
    
    report.append(f"\nSharpe Ratio:")
    report.append(f"  Mean: {df['is_sharpe'].mean():.2f}")
    report.append(f"  Median: {df['is_sharpe'].median():.2f}")
    report.append(f"  Range: {df['is_sharpe'].min():.2f} to {df['is_sharpe'].max():.2f}")
    
    # Top performers
    report.append("\n" + "-"*80)
    report.append("TOP 5 CONFIGURATIONS BY CAGR")
    report.append("-"*80)
    top_5_cagr = df.nlargest(5, 'is_cagr')
    for i, (idx, row) in enumerate(top_5_cagr.iterrows()):
        report.append(f"\n#{i+1}:")
        report.append(f"  CAGR: {row['is_cagr']:.2f}%")
        report.append(f"  Max DD: {row['is_max_dd']:.2f}%")
        report.append(f"  Sharpe: {row['is_sharpe']:.2f}")
        report.append(f"  Win Rate: {row['is_win_rate']:.2f}%")
        report.append(f"  Trades: {row['is_num_trades']}")
        
        # Show key config differences
        config_keys = ['trix_threshold', 'rsi_threshold', 'exit_strategy', 
                      'trailing_stop_pct', 'entry_conditions_required']
        config_str = ", ".join([f"{k}={row.get(k, 'N/A')}" for k in config_keys if k in row])
        report.append(f"  Config: {config_str}")
    
    # Best Sharpe
    report.append("\n" + "-"*80)
    report.append("TOP 5 CONFIGURATIONS BY SHARPE RATIO")
    report.append("-"*80)
    top_5_sharpe = df.nlargest(5, 'is_sharpe')
    for i, (idx, row) in enumerate(top_5_sharpe.iterrows()):
        report.append(f"\n#{i+1}:")
        report.append(f"  Sharpe: {row['is_sharpe']:.2f}")
        report.append(f"  CAGR: {row['is_cagr']:.2f}%")
        report.append(f"  Max DD: {row['is_max_dd']:.2f}%")
        report.append(f"  Win Rate: {row['is_win_rate']:.2f}%")
    
    # Parameter insights
    report.append("\n" + "-"*80)
    report.append("PARAMETER INSIGHTS")
    report.append("-"*80)
    
    # Identify most impactful parameters
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    param_cols = [col for col in numeric_cols if col not in ['is_cagr', 'is_sharpe', 'is_max_dd', 'is_win_rate', 'is_num_trades', 'is_profit_factor']]
    
    if param_cols:
        correlations = {}
        for param in param_cols:
            if df[param].nunique() > 1:  # Only if parameter varies
                corr = df[param].corr(df['is_cagr'])
                if not np.isnan(corr):
                    correlations[param] = corr
        
        if correlations:
            sorted_corr = sorted(correlations.items(), key=lambda x: abs(x[1]), reverse=True)
            report.append("\nParameters Most Correlated with CAGR:")
            for param, corr in sorted_corr[:10]:
                direction = "positive" if corr > 0 else "negative"
                report.append(f"  {param}: {corr:.3f} ({direction})")
    
    # Save report
    report_text = "\n".join(report)
    report_file = os.path.join(output_dir, 'analysis_insights.txt')
    with open(report_file, 'w') as f:
        f.write(report_text)
    
    print(f"\nInsights report saved to {report_file}")
    print("\n" + report_text)

def main():
    parser = argparse.ArgumentParser(description='Analyze MultiBeggar backtest results')
    parser.add_argument('--results', type=str, required=True,
                       help='Path to results pickle file')
    parser.add_argument('--output-dir', type=str, default='mb_backtest_results',
                       help='Output directory for plots')
    
    args = parser.parse_args()
    
    # Create output directory
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Load results
    results_df = load_results(args.results)
    if results_df is None:
        return
    
    # Extract metrics
    print("\nExtracting metrics...")
    df = extract_metrics(results_df)
    print(f"Extracted {len(df)} configurations")
    
    # Generate plots
    print("\nGenerating visualizations...")
    
    # Parameter impact plots
    key_params = ['trix_threshold', 'rsi_threshold', 'trailing_stop_pct', 
                  'entry_conditions_required', 'kc_distance_threshold']
    
    for param in key_params:
        if param in df.columns:
            print(f"  Plotting {param}...")
            plot_parameter_impact(df, param, args.output_dir)
    
    # Correlation matrix
    print("  Plotting correlation matrix...")
    plot_correlation_matrix(df, args.output_dir)
    
    # Pareto frontier
    print("  Plotting Pareto frontier...")
    pareto_df = plot_pareto_frontier(df, args.output_dir)
    
    # Top configurations
    print("  Plotting top configurations...")
    plot_top_configs(df, args.output_dir, top_n=10)
    
    # Generate insights report
    print("\nGenerating insights report...")
    generate_insights_report(df, args.output_dir)
    
    print(f"\nAnalysis complete! Results saved to {args.output_dir}/")

if __name__ == "__main__":
    main()

