# 🚀 Quick Start Guide

## 5-Minute Setup

### Step 1: Install Dependencies
```bash
cd C:\nihil\finance_ai_ws\MB-POS-Filter\F4\SAR-RENCO
pip install -r requirements.txt
```

### Step 2: Configure API Credentials

Edit `SARRenkoStrategy.py` (lines 48-49):
```python
API_KEY = "your_api_key_here"
ACCESS_TOKEN = "your_access_token_here"
```

**Get your credentials:**
1. Go to [Kite Connect](https://kite.trade/)
2. Login → API tab → Create app
3. Copy API Key
4. Generate access token (valid for 1 day)

### Step 3: Prepare Stock Universe

Create `data/MCAP-great2500.csv`:
```csv
Symbol
RELIANCE
TCS
INFY
HDFCBANK
ICICIBANK
BHARTIARTL
```

Or use your existing CSV from the project.

### Step 4: Run Test Scan

```bash
python SARRenkoStrategy.py --test
```

**Expected output:**
```
2024-10-22 10:30:00 - INFO - Connected as: ABC123
2024-10-22 10:30:05 - INFO - Market Breadth: 58.50%
2024-10-22 10:30:10 - INFO - Scanning 5 stocks...
2024-10-22 10:30:25 - INFO - ✅ RELIANCE: LONG @ 2850.00 (Stop: 2770.00, Conf: 85)
2024-10-22 10:30:30 - INFO - SCAN COMPLETE: 1 signals found
```

### Step 5: View Results

Check `output/sar_renko_scan_[timestamp].csv`:
```csv
symbol,date,signal,entry_price,stop_loss,confidence,quantity
RELIANCE,2024-10-22,LONG,2850.0,2770.0,85,250
```

---

## Common Commands

### Live Scanning
```bash
# Full universe scan
python SARRenkoStrategy.py

# Specific stocks
python SARRenkoStrategy.py --symbols RELIANCE TCS INFY

# Test mode (faster)
python SARRenkoStrategy.py --test
```

### Backtesting
```bash
# Need historical data first
# (Prepare CSV with: date,symbol,open,high,low,close,volume)

python SARRenkoBacktester.py --data historical_data.csv

# Optimize parameters
python SARRenkoBacktester.py --data historical_data.csv --optimize
```

---

## Understanding the Output

### Signal Interpretation

```csv
symbol,signal,entry_price,stop_loss,confidence,quantity,position_value
RELIANCE,LONG,2850.0,2770.0,85,250,712500
```

**What this means:**
- **Signal**: LONG (buy signal generated today)
- **Entry**: ₹2,850 per share (current market price)
- **Stop Loss**: ₹2,770 (3% below entry, based on PSAR)
- **Confidence**: 85/100 (high confidence - all filters aligned strongly)
- **Quantity**: 250 shares (calculated from 2% risk rule)
- **Position Value**: ₹7,12,500 (total capital required)

### Confidence Score Breakdown

| Score | Meaning | Action |
|-------|---------|--------|
| 90-100 | **Excellent** - All filters + strong momentum | ⭐ Trade immediately |
| 75-89 | **Good** - All filters aligned | ✓ Trade |
| 60-74 | **Fair** - Some filters marginal | ⚠️ Consider |
| < 60 | **Weak** - Missing confirmations | ✗ Skip |

---

## Configuration Tips

### For Conservative Trading
```python
# In SARRenkoStrategy.py

PSAR_CONFIG = {
    'start_af': 0.01,    # ← Slower (was 0.02)
    'step_af': 0.01,     # ← Slower
    'max_af': 0.15,      # ← Tighter stops
}

BREADTH_CONFIG = {
    'min_breadth_long': 55,  # ← Stricter (was 50)
}

RISK_CONFIG = {
    'risk_per_trade_pct': 1.5,  # ← Lower risk (was 2.0)
}
```

**Result**: Fewer signals, but higher quality

### For Aggressive Trading
```python
PSAR_CONFIG = {
    'start_af': 0.03,    # ← Faster
    'max_af': 0.25,      # ← Wider stops
}

BREADTH_CONFIG = {
    'min_breadth_long': 45,  # ← Looser
}

RENKO_CONFIG = {
    'min_bricks_for_signal': 1,  # ← Less confirmation
}
```

**Result**: More signals, lower quality

---

## Troubleshooting

### Issue: "No signals found"

**Possible causes:**
1. Breadth filter too strict
   - **Fix**: Lower `min_breadth_long` to 40
   
2. No stocks meeting criteria today
   - **Normal**: Strategy is low-frequency (expect this often)
   
3. Renko brick size too large
   - **Fix**: Use `brick_size_method: 'fixed'` with `fixed_brick_size: 50`

### Issue: "Connection failed"

**Check:**
1. Access token expired (regenerate daily)
2. Internet connection
3. Kite API status ([status.zerodha.com](https://status.zerodha.com))

### Issue: "Rate limit exceeded"

**Fix:**
```python
# Increase delay in SARRenkoStrategy.py
API_CALL_DELAY = 0.5  # Was 0.35
```

---

## Next Steps

### 1. Paper Trade for 1 Month
- Run scanner daily
- Record all signals
- Track hypothetical performance
- Compare to backtest expectations

### 2. Backtest Your Universe
- Export 2+ years of historical data
- Run backtester
- Verify strategy works on your stocks
- Check drawdown tolerance

### 3. Integrate with Broker
- Implement automated order placement
- Add error handling for rejections
- Set up position monitoring
- Create alert system (Telegram/Email)

### 4. Optimize for Your Style
- Adjust risk per trade
- Modify breadth thresholds
- Experiment with brick sizing
- Add custom filters

---

## Daily Workflow

### Morning (Market Open)
1. **9:00 AM**: Run breadth calculation
   ```bash
   # Check market health first
   python -c "from SARRenkoStrategy import *; bc = MarketBreadth(kite, BREADTH_CONFIG); print(f'Breadth: {bc.calculate_breadth():.2f}%')"
   ```

2. **9:15 AM**: Run full scan
   ```bash
   python SARRenkoStrategy.py
   ```

3. **9:30 AM**: Review signals
   - Check confidence scores
   - Verify stop loss distances
   - Calculate position sizes

### Intraday
- Monitor PSAR stops for open positions
- Set alerts for stop loss levels
- No new signals intraday (strategy is EOD-based)

### Evening (Market Close)
1. Update open position P&L
2. Check if any stops triggered
3. Log performance in spreadsheet
4. Review missed opportunities

---

## Performance Tracking Template

Create a spreadsheet to track:

| Date | Symbol | Signal | Entry | Stop | Exit | P&L | Reason | Notes |
|------|--------|--------|-------|------|------|-----|--------|-------|
| 2024-10-22 | RELIANCE | LONG | 2850 | 2770 | - | - | - | Confidence: 85 |
| 2024-10-25 | RELIANCE | EXIT | 2850 | 2770 | 2920 | +17,500 | Target | +2.5% in 3 days |

**Monthly review:**
- Win rate vs expected (55-65%)
- Average P&L vs expected
- Drawdown vs backtest
- Signals missed (why?)

---

## Warning Signs to Stop Trading

🚨 **Pause strategy if:**
- Win rate < 40% over 10 trades
- Drawdown > 15%
- Sharpe ratio < 0.5 over 6 months
- Market VIX > 30 (high volatility regime)
- You're overriding system decisions

---

## Support Resources

- **Full Documentation**: `README.md`
- **Strategy Deep-Dive**: (see React dashboard code for visual explanation)
- **Code Issues**: Check logs in `sar_renko_scanner.log`
- **API Issues**: [Kite Connect Forum](https://kite.trade/forum)

---

## Sanity Checks

Before trusting any signal:

✅ **Checklist:**
- [ ] Breadth is reasonable (30-70%)
- [ ] Stop loss is 1-5% away
- [ ] Position size is < 30% of capital
- [ ] Confidence > 70
- [ ] You understand why signal triggered
- [ ] Market is open (not holiday)
- [ ] Stock is liquid (volume > 1M shares/day)

---

**You're ready to trade! Remember: Discipline > Optimization**

Start small, track everything, and adjust based on real performance (not backtest fantasies).

