# PSAR + Renko + Breadth Multi-Filter Strategy

## 🎯 Strategy Overview

A **low-frequency, high-conviction** trading system that combines multiple independent confirmation layers to identify high-probability trend reversals in Indian equity markets.

### Core Philosophy

> "When multiple chart types agree on direction, the probability of a genuine trend increases exponentially."

This strategy operates on **convergence principle** - waiting for 4 distinct technical perspectives to align before entering trades.

---

## 📊 The Four-Layer Filter Cascade

### 1️⃣ **PSAR (Primary Signal)**
- **Role**: First-mover trend reversal detector
- **Mechanics**: Parabolic SAR accelerates as trend matures
- **Output**: Binary flip (bullish ↔ bearish)
- **Weakness**: ~50% false signals in ranging markets
- **Parameters**:
  - `start_af`: 0.02 (initial acceleration)
  - `step_af`: 0.02 (increment per period)
  - `max_af`: 0.20 (maximum acceleration)

### 2️⃣ **Renko Confirmation (Noise Filter)**
- **Role**: Filter intraday volatility noise
- **Mechanics**: Time-independent bricks (form only on threshold price moves)
- **Output**: Brick direction (up/down) + consecutive count
- **Critical**: Brick size must scale with ATR
- **Parameters**:
  - `brick_size_method`: 'atr' (recommended) or 'fixed'
  - `atr_multiplier`: 1.5 (brick = ATR × 1.5)
  - `min_bricks_for_signal`: 2 (consecutive bricks required)

### 3️⃣ **Point & Figure (Structural Validation)**
- **Role**: Supply/demand zone confirmation
- **Mechanics**: Column height breakout validation
- **Output**: Binary breakout confirmation
- **Latency**: Can lag 5-10% of move
- **Note**: Currently manual toggle (TradingView limitation)

### 4️⃣ **Breadth Filter (Regime Confirmation)**
- **Role**: Market-wide health check
- **Mechanics**: % of stocks above 50-day MA
- **Output**: Percentage (0-100%)
- **Thresholds**:
  - Long entries: Breadth > 50%
  - Short entries: Breadth < 40%
  - Neutral zone: 40-50%

---

## 🚦 Entry Conditions

**ALL conditions must be TRUE:**

```python
LONG ENTRY:
✓ PSAR flips bullish (price > SAR and SAR[prev] > price[prev])
✓ Renko shows 2+ consecutive green bricks
✓ Point & Figure confirms breakout (manual check)
✓ Market breadth > 50%
✓ Volume > 20-day average (optional)

SHORT ENTRY:
✓ PSAR flips bearish (price < SAR and SAR[prev] < price[prev])
✓ Renko shows 2+ consecutive red bricks
✓ Point & Figure confirms breakdown
✓ Market breadth < 40%
✓ Volume > 20-day average (optional)
```

---

## 🛑 Exit Conditions

**Exit on ANY condition:**

1. **PSAR Trailing Stop Hit**
   - Primary exit mechanism
   - Stop automatically tightens as trend develops
   
2. **Opposite Signal**
   - PSAR flips to opposite direction
   - Immediate exit at market

3. **Time-Based Stop** (Optional)
   - Maximum holding period: 30 days
   - Prevents capital lockup

---

## 💰 Risk Management

### Position Sizing
```
Risk per Trade: 2% of capital (adjustable)
Position Size = (Capital × Risk%) / Stop Distance

Example:
Capital: ₹10,00,000
Risk: 2% = ₹20,000
Entry: ₹1,000
Stop: ₹950 (5% distance)
Quantity = ₹20,000 / ₹50 = 400 shares
Position Value = ₹4,00,000 (40% of capital)
```

### Risk Limits
- **Per Trade**: 2% maximum capital risk
- **Per Position**: 30% maximum capital allocation
- **Portfolio**: 10% maximum total risk (sum of all open positions)
- **Stop Distance**: 1-5% range (reject if outside)

### Transaction Costs
- **Commission**: 0.05% per trade (₹500 on ₹10L)
- **Slippage**: 0.05% (₹500 on ₹10L)
- **Total Round-Trip Cost**: ~0.2% (₹2,000 on ₹10L)

---

## 📈 Expected Performance

### Realistic Expectations

| Metric | Realistic Range | Notes |
|--------|----------------|-------|
| **Annual Return** | 12-20% | Regime-dependent |
| **Win Rate** | 55-65% | Lower than backtest |
| **Sharpe Ratio** | 0.8-1.3 | Account for slippage |
| **Max Drawdown** | 10-20% | Expect 15%+ in reality |
| **Trades/Year** | 8-15 | Low frequency |
| **Avg Hold Period** | 14-30 days | Position trades |
| **Profit Factor** | 1.5-2.0 | Gross profit / gross loss |

### Market Regime Dependency

| Market Type | Expected Performance | Example Period |
|-------------|---------------------|----------------|
| **Strong Trend** | ⭐⭐⭐⭐⭐ Excellent | 2020-2021 bull run |
| **Choppy Bull** | ⭐⭐⭐ Breakeven | 2023-2024 |
| **Bear Market** | ⭐⭐ Poor | 2022 drawdown |
| **Sideways** | ⭐ Terrible | 2015-2016 range |

> **Key Insight**: This strategy makes 80% of profits in 20% of time (trending regimes). Expect 6-12 month flat/drawdown periods.

---

## 🛠️ Installation & Setup

### Prerequisites
```bash
# Python 3.8+
pip install pandas numpy kiteconnect matplotlib seaborn ratelimit python-dotenv

# Optional (for technical indicators)
pip install talib pandas-ta
```

### Kite Connect Setup

1. **Create Kite Connect App**
   - Go to [Kite Connect](https://kite.trade/)
   - Create app and get API key
   - Generate access token

2. **Configure Credentials**
```python
# In SARRenkoStrategy.py
API_KEY = "your_api_key"
ACCESS_TOKEN = "your_access_token"
```

### Project Structure
```
SAR-RENCO/
├── SARRenkoStrategy.py      # Main scanner
├── SARRenkoBacktester.py    # Backtesting engine
├── README.md                 # This file
├── requirements.txt          # Dependencies
├── config.json               # Configuration
├── output/                   # Scan results
├── cache/                    # Cached data
└── data/                     # Input stock universe
    └── MCAP-great2500.csv    # Stock list
```

---

## 🚀 Usage

### 1. Live Scanner (Find Current Signals)

```bash
# Scan all stocks from CSV
python SARRenkoStrategy.py

# Test mode (limited stocks)
python SARRenkoStrategy.py --test

# Scan specific symbols
python SARRenkoStrategy.py --symbols RELIANCE TCS INFY
```

**Output**: CSV file with signals
```csv
symbol,date,signal,entry_price,stop_loss,confidence,quantity,position_value
RELIANCE,2024-10-22,LONG,2850.0,2770.0,85,140,399000
TCS,2024-10-22,LONG,3650.0,3550.0,78,200,730000
```

### 2. Backtesting

```bash
# Basic backtest
python SARRenkoBacktester.py --data historical_data.csv

# Date range
python SARRenkoBacktester.py --data historical_data.csv --start 2020-01-01 --end 2024-10-01

# Parameter optimization
python SARRenkoBacktester.py --data historical_data.csv --optimize

# Monte Carlo simulation (1000 runs)
python SARRenkoBacktester.py --data historical_data.csv --monte-carlo --runs 1000
```

### 3. Parameter Optimization

```python
param_ranges = {
    'psar_start': [0.01, 0.02, 0.03, 0.04],
    'psar_step': [0.01, 0.02, 0.03],
    'psar_max': [0.15, 0.20, 0.25],
    'atr_multiplier': [1.0, 1.5, 2.0],
}

optimizer = ParameterOptimizer(df)
results = optimizer.optimize(param_ranges)
```

---

## 📊 Configuration

### Strategy Parameters (Tunable)

```python
PSAR_CONFIG = {
    'start_af': 0.02,        # Lower = less sensitive (0.01-0.05)
    'step_af': 0.02,         # Lower = slower acceleration
    'max_af': 0.2,           # Lower = tighter trailing stop
}

RENKO_CONFIG = {
    'brick_size_method': 'atr',  # 'atr' or 'fixed'
    'atr_multiplier': 1.5,       # Higher = fewer bricks
    'min_bricks_for_signal': 2,  # Higher = stricter filter
}

BREADTH_CONFIG = {
    'use_breadth_filter': True,
    'min_breadth_long': 50,      # Higher = fewer long trades
    'min_breadth_short': 40,     # Lower = fewer short trades
}

RISK_CONFIG = {
    'risk_per_trade_pct': 2.0,   # Lower = smaller positions
    'max_stop_distance_pct': 5.0, # Reject wide stops
}
```

### Optimization Guidelines

| Parameter | Test Range | Increment | Notes |
|-----------|-----------|-----------|-------|
| `psar_start` | 0.01-0.05 | 0.005 | Lower = smoother |
| `psar_step` | 0.01-0.05 | 0.005 | Lower = slower acceleration |
| `psar_max` | 0.10-0.30 | 0.05 | Lower = tighter stops |
| `atr_multiplier` | 1.0-3.0 | 0.5 | Adapt to volatility |
| `min_breadth` | 40-60 | 5 | Market-dependent |

---

## ⚠️ Critical Warnings & Limitations

### Statistical Red Flags

#### 1. **Overfitting Risk**
- Small sample sizes (< 30 trades) = statistical noise
- 4 trades with 75% win rate has confidence interval of 40-95%
- **Mitigation**: Require 100+ trades for validation

#### 2. **Signal Latency**
- By the time all 4 filters confirm, you've missed 20-30% of move
- Renko/P&F are lagging by design
- **Reality**: Late entries = lower R:R ratios

#### 3. **Breadth Data Challenge**
- Requires real-time data for 50-500 stocks
- Expensive data subscriptions
- Most retail traders use proxies (which lag)

#### 4. **Look-Ahead Bias in Backtests**
- Renko bricks calculated on historical data ≠ real-time behavior
- In live trading, brick completion is unknown until bar close
- **Impact**: Backtest returns can be 20-30% inflated

### Implementation Realities

#### 1. **The Renko Problem**
```python
# Historical backtest (biased)
if price crosses brick_threshold:
    form_brick()  # Instant

# Live trading (realistic)
if price crosses brick_threshold:
    wait_for_bar_close()  # 1-day delay
    form_brick()
```

#### 2. **Regime Brittleness**
- Strategy uses **same parameters in all markets**
- No adaptive mechanism
- Will underperform in 40-60% of years

#### 3. **Black Swan Events**
- No circuit breakers for gap downs
- PSAR stops are next-day execution (gap risk)
- **Mitigation**: Add -8% hard stop, max daily loss limits

### Honest Deployment Expectations

**Year 1 Reality Check:**
- You'll have 2-3 month periods with ZERO signals
- Win rate will drop to 55-60% (not 75%)
- You'll experience 15-20% drawdown (not 2%)
- You'll miss 2-3 big moves due to breadth filter lag
- Slippage will be 2-3× your estimate

**The Psychological Edge**:
The real challenge isn't the math - it's:
- ✗ Sitting idle for 3 months during hot market
- ✗ Watching strategy miss 20% rally (breadth didn't confirm)
- ✗ Not overriding system during drawdown
- ✓ Following rules mechanically (the actual edge)

---

## 📋 Deployment Checklist

### Before Going Live

- [ ] **Walk-forward optimization complete** (60/40 train/test split)
- [ ] **Out-of-sample validation passed** (separate test period)
- [ ] **Slippage & fees included** (0.2% round-trip minimum)
- [ ] **Risk controls implemented**:
  - [ ] Max position size limit
  - [ ] Max portfolio risk limit
  - [ ] Hard stop loss (-8%)
  - [ ] Daily loss limit
- [ ] **Paper trading for 1 month minimum**
- [ ] **Broker API integration tested** (order placement works)
- [ ] **Live monitoring dashboard** (track open positions)
- [ ] **Tested on multiple market regimes**:
  - [ ] Bull market (2020-2021)
  - [ ] Bear market (2022)
  - [ ] Sideways (2015-2016)
- [ ] **Parameter stability verified** (bootstrap samples)
- [ ] **Monte Carlo simulation run** (1000+ runs)

### Post-Deployment Monitoring

- [ ] Track **actual vs expected** slippage
- [ ] Monitor **real fill prices** vs theoretical
- [ ] Compare **live performance** to backtest monthly
- [ ] Log all **rejected signals** (breadth filter, etc.)
- [ ] Review **missed opportunities** weekly

### Kill Switch Conditions

**Stop trading if:**
- 3 consecutive losses
- Drawdown > 15%
- Win rate < 40% over 10 trades
- Sharpe ratio < 0.5 over 6 months
- Market regime changes (high VIX > 30)

---

## 🧪 Testing Framework

### 1. Walk-Forward Optimization

```python
# 5-year test (2019-2024)
# Year 1-3: In-sample (train)
# Year 4: Out-of-sample (test)
# Year 5: Walk forward
```

### 2. Monte Carlo Simulation

```python
# Resample trades 1000 times
# Check:
# - 5th percentile return (worst case)
# - Max drawdown distribution
# - Probability of ruin
```

### 3. Regime Analysis

Test separately on:
- Bull markets (Nifty +20%/year)
- Bear markets (Nifty -15%/year)
- Sideways (Nifty ±5%/year)

### 4. Sensitivity Analysis

Vary each parameter ±20% and check:
- Performance degradation
- Sharpe ratio stability
- Drawdown increase

**Pass Criteria**: < 15% performance change with ±10% parameter change

---

## 📚 Advanced Topics

### Adaptive Brick Sizing

```python
# Dynamic brick size based on volatility regime
current_atr = calculate_atr(df, period=14)
brick_size = current_atr * multiplier

# High volatility (ATR > 80th percentile)
if current_atr > atr_80th_percentile:
    multiplier = 2.0  # Larger bricks (fewer signals)

# Low volatility
else:
    multiplier = 1.0  # Smaller bricks (more signals)
```

### Market Regime Classification

```python
# Classify market before applying strategy
nifty_sma_50 = nifty['close'].rolling(50).mean()
nifty_sma_200 = nifty['close'].rolling(200).mean()

if nifty_close > nifty_sma_200 and nifty_sma_50 > nifty_sma_200:
    regime = 'BULL'  # Use strategy
elif nifty_close < nifty_sma_200:
    regime = 'BEAR'  # Skip longs or go flat
else:
    regime = 'SIDEWAYS'  # Skip entirely
```

### Portfolio Integration

```python
# Don't run this strategy in isolation
# Combine with:
# 1. Mean-reversion (opposite regime)
# 2. Sector rotation (complement)
# 3. Options hedges (black swan protection)
```

---

## 🐛 Troubleshooting

### Common Issues

#### "No signals found"
- Check breadth filter (might be excluding all trades)
- Verify Renko brick size (too large = no bricks)
- Check date range (need sufficient lookback)

#### "All positions stopped out"
- PSAR too tight (increase `start_af` to 0.03)
- Brick size too small (increase `atr_multiplier`)
- Market is ranging (strategy not suitable)

#### "Poor backtest performance"
- Slippage too low (use 0.1% minimum)
- Commission not included
- Look-ahead bias (check Renko calculation)

---

## 📖 References & Further Reading

### Academic Papers
1. Wilder, J. W. (1978). *New Concepts in Technical Trading Systems*. (Original PSAR)
2. Nison, S. (1991). *Japanese Candlestick Charting Techniques*. (Renko origins)
3. Dorsey, T. (1995). *Point & Figure Charting*. (P&F methodology)

### Books
- *Technical Analysis of the Financial Markets* - John Murphy
- *Evidence-Based Technical Analysis* - David Aronson (on overfitting)
- *The New Trading for a Living* - Alexander Elder

### Online Resources
- [TradingView Pine Script Docs](https://www.tradingview.com/pine-script-docs/)
- [Kite Connect API Docs](https://kite.trade/docs/connect/v3/)
- [QuantConnect Forums](https://www.quantconnect.com/forum)

---

## 📞 Support & Contact

### Issues & Bugs
- File issues on GitHub
- Include full error trace
- Provide sample data if possible

### Feature Requests
- Adaptive parameter sizing
- Machine learning integration
- Multi-timeframe analysis
- Real-time alert system

---

## 📜 License

MIT License - Use at your own risk.

**Disclaimer**: This software is for educational purposes only. Past performance is not indicative of future results. Trading involves substantial risk of loss. Always conduct your own research and consult with a licensed financial advisor before making investment decisions.

---

## ✅ Version History

### v1.0.0 (October 2024)
- Initial release
- PSAR + Renko + Breadth multi-filter system
- Live scanner with Kite Connect integration
- Comprehensive backtester with walk-forward validation
- Monte Carlo simulation
- Parameter optimization
- Production-grade risk management

### Roadmap
- [ ] v1.1: Machine learning signal confidence scoring
- [ ] v1.2: Multi-timeframe confirmation
- [ ] v1.3: Options overlay for hedging
- [ ] v1.4: Telegram/Discord alert integration
- [ ] v2.0: Adaptive regime detection

---

**Built with ❤️ for systematic traders who understand that discipline > optimization**

