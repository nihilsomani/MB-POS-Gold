"""
Breadth Scenario Tester
========================

Tests SAR-RENCO strategy under different breadth regimes:
1. Strong Bull (breadth 70%)
2. Weak Bull (breadth 55%)  ← Your current 200-day
3. Neutral (breadth 50%)
4. Weak Bear (breadth 45%)
5. Strong Bear (breadth 30%)
6. No filter (breadth 100%)  ← Baseline

This helps determine optimal breadth threshold and filter value.

Usage:
    python test_breadth_scenarios.py --data historical_data.csv
"""

import pandas as pd
import json
import os
from datetime import datetime

# Scenarios to test
SCENARIOS = {
    'strong_bull': {
        'weighted_breadth_50d': 70,
        'weighted_breadth_200d': 72,
        'health_score': 75,
        'regime': 'STRONG_BULL'
    },
    'weak_bull': {
        'weighted_breadth_50d': 55,
        'weighted_breadth_200d': 58,
        'health_score': 60,
        'regime': 'WEAK_BULL'
    },
    'neutral': {
        'weighted_breadth_50d': 50,
        'weighted_breadth_200d': 50,
        'health_score': 50,
        'regime': 'NEUTRAL'
    },
    'weak_bear': {
        'weighted_breadth_50d': 45,
        'weighted_breadth_200d': 42,
        'health_score': 40,
        'regime': 'WEAK_BEAR'
    },
    'strong_bear': {
        'weighted_breadth_50d': 30,
        'weighted_breadth_200d': 28,
        'health_score': 25,
        'regime': 'STRONG_BEAR'
    },
    'no_filter': {
        'weighted_breadth_50d': 100,
        'weighted_breadth_200d': 100,
        'health_score': 100,
        'regime': 'NO_FILTER'
    }
}

def create_scenario_breadth_file(scenario_name, scenario_data):
    """Create breadth JSON file for scenario"""
    breadth_data = {
        'timestamp': datetime.now().isoformat(),
        'date': datetime.now().strftime('%Y-%m-%d'),
        'scenario': scenario_name,
        **scenario_data
    }
    
    # Create output directory if needed
    os.makedirs('../output', exist_ok=True)
    
    # Save to market_breadth.json (strategy reads this)
    with open('../output/market_breadth.json', 'w') as f:
        json.dump(breadth_data, f, indent=2)
    
    print(f"\n{'='*60}")
    print(f"SCENARIO: {scenario_name.upper()}")
    print(f"{'='*60}")
    print(f"Breadth 50d:  {scenario_data['weighted_breadth_50d']}%")
    print(f"Breadth 200d: {scenario_data['weighted_breadth_200d']}%")
    print(f"Health Score: {scenario_data['health_score']}")
    print(f"Regime:       {scenario_data['regime']}")
    print(f"{'='*60}\n")

def main():
    print("\n" + "="*60)
    print("SAR-RENCO BREADTH SCENARIO TESTER")
    print("="*60)
    print("\nThis will test the strategy under different market regimes.")
    print("For each scenario, manually run:")
    print("  python SARRenkoStrategy.py --test")
    print("\nThen compare:")
    print("  - Number of signals")
    print("  - Signal confidence")
    print("  - Blocked vs allowed trades")
    print()
    
    results = []
    
    for scenario_name, scenario_data in SCENARIOS.items():
        create_scenario_breadth_file(scenario_name, scenario_data)
        
        print(f"Ready to test: {scenario_name}")
        print("Run: python SARRenkoStrategy.py --test")
        print()
        
        input("Press Enter when done to continue to next scenario...")
        
        # Record results (manual for now)
        signals = input("How many signals found? ")
        notes = input("Any observations? ")
        
        results.append({
            'scenario': scenario_name,
            'breadth_50d': scenario_data['weighted_breadth_50d'],
            'breadth_200d': scenario_data['weighted_breadth_200d'],
            'signals': signals,
            'notes': notes
        })
        
        print()
    
    # Save results
    df_results = pd.DataFrame(results)
    df_results.to_csv('breadth_scenario_results.csv', index=False)
    
    print("\n" + "="*60)
    print("SCENARIO TESTING COMPLETE")
    print("="*60)
    print("\nResults saved to: breadth_scenario_results.csv")
    print("\nSummary:")
    print(df_results.to_string(index=False))
    print()
    print("Analysis:")
    print("- Which scenario had most signals?")
    print("- Did breadth filter reduce false signals?")
    print("- What's the optimal breadth threshold?")
    print()

if __name__ == "__main__":
    main()

