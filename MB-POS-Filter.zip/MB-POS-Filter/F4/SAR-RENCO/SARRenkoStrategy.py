"""
PSAR + Renko + Breadth Multi-Filter Confirmation Strategy
==========================================================

Strategy Logic:
    1. PSAR Signal: Primary trend reversal detector (Parabolic SAR flip)
    2. Renko Confirmation: Price structure validation (brick direction alignment)
    3. Point & Figure: Structural breakout confirmation (optional)
    4. Breadth Filter: Market-wide context (% stocks above 50-day MA)

Entry Conditions (ALL must be true):
    - PSAR flips bullish (price crosses above SAR)
    - Renko bricks turn green (upward momentum)
    - Breadth > 50% (healthy market environment)
    - Volume confirmation (optional)

Exit Conditions:
    - PSAR trailing stop hit
    - Renko bricks turn red (2 consecutive)
    - Time-based stop (optional)

Risk Management:
    - 2% risk per trade (adjustable)
    - PSAR-based stop loss
    - Maximum position size limits
    
Author: Trading System Framework
Version: 1.0.0
Last Updated: October 2024
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import warnings
import time
import json
import os
import logging
import argparse
from typing import Dict, List, Optional, Tuple
from ratelimit import limits, sleep_and_retry

warnings.filterwarnings('ignore')

# =============================================================================
# CONFIGURATION SECTION
# =============================================================================

# API Configuration
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "IPu3YFNqPkAlRsmQ6R7whtIhJSJsLsKf"

# Strategy Parameters (Optimizable)
PSAR_CONFIG = {
    'start_af': 0.02,        # Initial acceleration factor (0.01-0.05)
    'step_af': 0.02,         # AF increment per period (0.01-0.05)
    'max_af': 0.2,           # Maximum acceleration (0.1-0.3)
}

RENKO_CONFIG = {
    'brick_size_method': 'atr',  # 'fixed', 'atr', 'percent'
    'fixed_brick_size': 75,      # Points (for Nifty/BankNifty)
    'atr_multiplier': 1.5,       # Brick size = ATR * multiplier
    'atr_period': 14,            # ATR calculation period
    'min_bricks_for_signal': 2,  # Consecutive bricks for confirmation
}

BREADTH_CONFIG = {
    'use_breadth_filter': True,      # Now enabled - uses MarketBreadthScanner.py output
    'breadth_ma_period': 50,         # MA period for breadth calculation
    'min_breadth_long': 50,          # Minimum % for long entries
    'min_breadth_short': 40,         # Maximum % for short entries
    'breadth_universe': 'NIFTY500',  # Index for breadth calculation
}

ADX_CONFIG = {
    'use_adx_filter': True,          # Enable trend strength filter
    'adx_period': 14,                # ADX calculation period
    'min_adx': 25,                   # Minimum ADX for trade (25 = trending)
    'strong_trend_adx': 30,          # ADX > 30 = very strong trend (confidence bonus)
}

RISK_CONFIG = {
    'risk_per_trade_pct': 2.0,       # % of capital risked per trade
    'max_portfolio_risk_pct': 10.0,  # Maximum total portfolio risk
    'min_stop_distance_pct': 1.0,    # Minimum stop loss distance
    'max_stop_distance_pct': 5.0,    # Maximum stop loss distance
    'position_size_method': 'risk',  # 'fixed', 'risk', 'volatility'
}

# Data Configuration
DATA_CONFIG = {
    'lookback_days': 100,            # Days of historical data
    'timeframe': 'day',              # 'minute', '3minute', '5minute', 'day'
    'cache_expiry_hours': 24,        # Cache validity
    'min_data_points': 50,           # Minimum bars for analysis
}

# Scanner Configuration
SCANNER_CONFIG = {
    'input_csv': 'data/Quarterly_Momentum_Picks_20251022_122809.csv',  # Stock universe
    'output_dir': 'output',
    'scan_mode': 'all',              # 'all', 'long_only', 'short_only'
    'min_price': 50,                 # Minimum stock price
    'min_liquidity': 1000000,        # Minimum daily volume
}

# Rate Limiting
API_CALL_DELAY = 0.35               # Delay between API calls
MAX_RETRIES = 3
RETRY_DELAY = 5

# Logging Configuration
LOG_LEVEL = logging.INFO
LOG_FILE = 'sar_renko_scanner.log'

# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level=LOG_LEVEL,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# =============================================================================
# RENKO BRICK CALCULATOR
# =============================================================================

class RenkoBricks:
    """
    Renko brick generator with multiple sizing methods.
    
    Key Insight: Renko bricks ignore time - they only form when price
    moves by a threshold amount. This filters intraday noise.
    """
    
    def __init__(self, df: pd.DataFrame, config: dict):
        self.df = df.copy()
        self.config = config
        self.brick_size = self._calculate_brick_size()
        
    def _calculate_brick_size(self) -> float:
        """Calculate brick size based on method"""
        method = self.config['brick_size_method']
        
        if method == 'fixed':
            return self.config['fixed_brick_size']
            
        elif method == 'atr':
            atr_period = self.config['atr_period']
            atr = self._calculate_atr(atr_period)
            brick_size = atr * self.config['atr_multiplier']
            logger.debug(f"ATR-based brick size: {brick_size:.2f} (ATR: {atr:.2f})")
            return brick_size
            
        elif method == 'percent':
            # Use % of current price
            recent_price = self.df['close'].iloc[-1]
            return recent_price * (self.config.get('percent_brick', 0.5) / 100)
            
        else:
            logger.warning(f"Unknown brick method {method}, using fixed")
            return self.config['fixed_brick_size']
    
    def _calculate_atr(self, period: int) -> float:
        """Calculate Average True Range"""
        high = self.df['high']
        low = self.df['low']
        close = self.df['close']
        
        tr1 = high - low
        tr2 = abs(high - close.shift(1))
        tr3 = abs(low - close.shift(1))
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=period).mean().iloc[-1]
        
        return atr if not np.isnan(atr) else self.config['fixed_brick_size']
    
    def build_bricks(self) -> pd.DataFrame:
        """
        Build Renko bricks from price data.
        
        Returns DataFrame with:
            - brick_direction: 1 (up), -1 (down), 0 (no brick)
            - brick_count: cumulative brick count
            - brick_price: current brick close price
        """
        prices = self.df['close'].values
        brick_size = self.brick_size
        
        brick_directions = np.zeros(len(prices), dtype=int)
        brick_prices = np.zeros(len(prices))
        brick_counts = np.zeros(len(prices), dtype=int)
        
        # Initialize
        current_brick = prices[0]
        last_direction = 0
        brick_count = 0
        
        for i in range(len(prices)):
            price = prices[i]
            move = price - current_brick
            
            # Check for new brick formation
            if move >= brick_size:
                # Upward brick(s)
                num_bricks = int(move / brick_size)
                current_brick += num_bricks * brick_size
                brick_directions[i] = 1
                last_direction = 1
                brick_count += num_bricks
                
            elif move <= -brick_size:
                # Downward brick(s)
                num_bricks = int(abs(move) / brick_size)
                current_brick -= num_bricks * brick_size
                brick_directions[i] = -1
                last_direction = -1
                brick_count += num_bricks
                
            else:
                # No new brick
                brick_directions[i] = 0
            
            brick_prices[i] = current_brick
            brick_counts[i] = brick_count
        
        # Add to dataframe
        self.df['renko_direction'] = brick_directions
        self.df['renko_price'] = brick_prices
        self.df['renko_count'] = brick_counts
        
        # Calculate consecutive bricks in same direction
        self.df['renko_consecutive'] = self._count_consecutive(brick_directions)
        
        return self.df
    
    def _count_consecutive(self, directions: np.ndarray) -> np.ndarray:
        """Count consecutive bricks in same direction"""
        consecutive = np.zeros(len(directions), dtype=int)
        count = 0
        last_dir = 0
        
        for i, direction in enumerate(directions):
            if direction == 0:
                consecutive[i] = count
            elif direction == last_dir:
                count += 1
                consecutive[i] = count
            else:
                count = 1
                consecutive[i] = count
                last_dir = direction
                
        return consecutive


# =============================================================================
# PARABOLIC SAR CALCULATOR
# =============================================================================

class ParabolicSAR:
    """
    Parabolic SAR implementation with acceleration factor.
    
    Key Insight: PSAR accelerates as trend matures, making it progressively
    more sensitive to reversals. This is both strength and weakness.
    """
    
    def __init__(self, df: pd.DataFrame, config: dict):
        self.df = df.copy()
        self.config = config
        
    def calculate(self) -> pd.DataFrame:
        """Calculate Parabolic SAR"""
        high = self.df['high'].values
        low = self.df['low'].values
        close = self.df['close'].values
        
        start_af = self.config['start_af']
        step_af = self.config['step_af']
        max_af = self.config['max_af']
        
        n = len(close)
        psar = np.zeros(n)
        trend = np.zeros(n, dtype=int)  # 1: bullish, -1: bearish
        af = np.zeros(n)
        ep = np.zeros(n)  # Extreme point
        
        # Initialize
        psar[0] = close[0]
        trend[0] = 1
        af[0] = start_af
        ep[0] = high[0]
        
        for i in range(1, n):
            # Calculate PSAR
            psar[i] = psar[i-1] + af[i-1] * (ep[i-1] - psar[i-1])
            
            # Check for trend reversal
            if trend[i-1] == 1:  # Was bullish
                # Ensure PSAR doesn't go above last 2 lows
                psar[i] = min(psar[i], low[i-1], low[i-2] if i > 1 else low[i-1])
                
                # Check for reversal
                if low[i] < psar[i]:
                    trend[i] = -1  # Switch to bearish
                    psar[i] = ep[i-1]  # PSAR becomes the last extreme point
                    ep[i] = low[i]
                    af[i] = start_af
                else:
                    trend[i] = 1  # Continue bullish
                    if high[i] > ep[i-1]:
                        ep[i] = high[i]
                        af[i] = min(af[i-1] + step_af, max_af)
                    else:
                        ep[i] = ep[i-1]
                        af[i] = af[i-1]
                        
            else:  # Was bearish
                # Ensure PSAR doesn't go below last 2 highs
                psar[i] = max(psar[i], high[i-1], high[i-2] if i > 1 else high[i-1])
                
                # Check for reversal
                if high[i] > psar[i]:
                    trend[i] = 1  # Switch to bullish
                    psar[i] = ep[i-1]
                    ep[i] = high[i]
                    af[i] = start_af
                else:
                    trend[i] = -1  # Continue bearish
                    if low[i] < ep[i-1]:
                        ep[i] = low[i]
                        af[i] = min(af[i-1] + step_af, max_af)
                    else:
                        ep[i] = ep[i-1]
                        af[i] = af[i-1]
        
        self.df['psar'] = psar
        self.df['psar_trend'] = trend
        self.df['psar_af'] = af
        self.df['psar_ep'] = ep
        
        # Identify trend reversals
        self.df['psar_reversal'] = (self.df['psar_trend'] != self.df['psar_trend'].shift(1)).astype(int)
        
        return self.df


# =============================================================================
# ADX CALCULATOR (Trend Strength Filter)
# =============================================================================

class ADXCalculator:
    """
    Average Directional Index (ADX) calculator.
    
    Key Insight: ADX measures trend STRENGTH, not direction.
    - ADX < 20 = Weak trend / Ranging (PSAR fails here)
    - ADX 20-25 = Moderate trend
    - ADX 25-40 = Strong trend (PSAR works well)
    - ADX > 40 = Very strong trend
    
    Use ADX to filter out choppy stocks where PSAR whipsaws.
    """
    
    def __init__(self, df: pd.DataFrame, period: int = 14):
        self.df = df.copy()
        self.period = period
    
    def calculate(self) -> pd.DataFrame:
        """Calculate ADX"""
        high = self.df['high']
        low = self.df['low']
        close = self.df['close']
        
        # Calculate True Range
        tr1 = high - low
        tr2 = abs(high - close.shift(1))
        tr3 = abs(low - close.shift(1))
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        
        # Calculate Directional Movement
        up_move = high - high.shift(1)
        down_move = low.shift(1) - low
        
        plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0)
        minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0)
        
        plus_dm = pd.Series(plus_dm, index=self.df.index)
        minus_dm = pd.Series(minus_dm, index=self.df.index)
        
        # Smooth with Wilder's smoothing (EMA-like)
        atr = tr.ewm(alpha=1/self.period, adjust=False).mean()
        plus_di = 100 * (plus_dm.ewm(alpha=1/self.period, adjust=False).mean() / atr)
        minus_di = 100 * (minus_dm.ewm(alpha=1/self.period, adjust=False).mean() / atr)
        
        # Calculate DX
        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        
        # ADX is smoothed DX
        adx = dx.ewm(alpha=1/self.period, adjust=False).mean()
        
        self.df['adx'] = adx
        self.df['plus_di'] = plus_di
        self.df['minus_di'] = minus_di
        
        return self.df


# =============================================================================
# MARKET BREADTH CALCULATOR
# =============================================================================

class MarketBreadth:
    """
    Calculate market breadth metrics (% stocks above MA).
    
    Key Insight: This is the regime filter. Don't fight the overall market.
    """
    
    def __init__(self, kite: KiteConnect, config: dict):
        self.kite = kite
        self.config = config
        self.cache_file = 'cache/breadth_cache.json'
        
    def calculate_breadth(self, date: datetime = None) -> float:
        """
        Read breadth from MarketBreadthScanner output.
        
        Returns: Percentage (0-100)
        """
        if not self.config['use_breadth_filter']:
            return 100  # Neutral if filter disabled
        
        # Try to read from MarketBreadthScanner output
        try:
            # Try multiple possible paths (relative and absolute)
            script_dir = os.path.dirname(os.path.abspath(__file__))
            
            possible_paths = [
                os.path.join(script_dir, '../../../output/market_breadth.json'),  # From SAR-RENCO folder
                'C:/nihil/finance_ai_ws/output/market_breadth.json',  # Absolute path
                'output/market_breadth.json',  # If run from root
            ]
            
            breadth_file = None
            for path in possible_paths:
                if os.path.exists(path):
                    breadth_file = path
                    break
            
            if breadth_file:
                with open(breadth_file, 'r') as f:
                    breadth_data = json.load(f)
                
                # Check if data is fresh (same day)
                breadth_date = datetime.fromisoformat(breadth_data['timestamp']).date()
                today = datetime.now().date()
                
                if breadth_date == today:
                    # Use health score (composite) for position trading
                    # Health score considers multiple timeframes, not just 50-day
                    health_score = breadth_data.get('health_score', 50)
                    breadth_200d = breadth_data.get('weighted_breadth_200d', 50)
                    breadth_50d = breadth_data.get('weighted_breadth_50d', 50)
                    
                    # Use 200-day breadth for position trading (aligns with 8-month trend)
                    breadth_pct = breadth_200d  # 200-day captures long-term trend
                    
                    logger.info(f"Market breadth (200-day): {breadth_pct:.2f}%")
                    logger.info(f"  Health Score: {health_score:.1f} (composite)")
                    logger.info(f"  50-day: {breadth_50d:.1f}% (short-term)")
                    logger.info(f"  200-day: {breadth_200d:.1f}% (long-term) <-- USING THIS")
                    logger.info(f"  Regime: {breadth_data.get('regime', 'N/A')}")
                    logger.info(f"  Recommendation: {breadth_data.get('trade_recommendation', 'N/A')}")
                    
                    return breadth_pct
                else:
                    logger.warning(f"Breadth data is stale (from {breadth_date}). Run MarketBreadthScanner.py first!")
                    return 50  # Neutral
            else:
                logger.warning("Breadth file not found in any of these locations:")
                for path in possible_paths:
                    logger.warning(f"  - {path}")
                logger.warning("Run: python MarketBreadthScanner.py")
                return 50  # Neutral
                
        except Exception as e:
            logger.error(f"Failed to read breadth data: {e}")
            return 50  # Neutral on error
    
    def _calculate_fresh_breadth(self, date: datetime = None) -> float:
        """Calculate breadth from live data"""
        universe = self._get_universe_symbols()
        ma_period = self.config['breadth_ma_period']
        
        above_ma_count = 0
        total_count = 0
        
        logger.info(f"Calculating breadth for {len(universe)} stocks...")
        
        for symbol in universe[:100]:  # Limit to 100 for speed (adjust as needed)
            try:
                time.sleep(API_CALL_DELAY)
                
                # Fetch historical data
                instrument_token = self._get_instrument_token(symbol)
                if not instrument_token:
                    continue
                
                to_date = date if date else datetime.now()
                from_date = to_date - timedelta(days=ma_period + 30)
                
                df = pd.DataFrame(
                    self.kite.historical_data(
                        instrument_token,
                        from_date.strftime('%Y-%m-%d'),
                        to_date.strftime('%Y-%m-%d'),
                        'day'
                    )
                )
                
                if len(df) < ma_period:
                    continue
                
                # Calculate MA
                df['ma'] = df['close'].rolling(window=ma_period).mean()
                
                # Check if above MA
                latest_close = df['close'].iloc[-1]
                latest_ma = df['ma'].iloc[-1]
                
                if latest_close > latest_ma:
                    above_ma_count += 1
                
                total_count += 1
                
            except Exception as e:
                logger.debug(f"Error processing {symbol} for breadth: {e}")
                continue
        
        if total_count == 0:
            return 50
        
        breadth_pct = (above_ma_count / total_count) * 100
        logger.info(f"Market breadth: {breadth_pct:.2f}% ({above_ma_count}/{total_count} above MA)")
        
        return breadth_pct
    
    def _get_universe_symbols(self) -> List[str]:
        """Get symbols for breadth calculation"""
        # For now, use a simplified approach
        # In production, fetch actual index constituents
        universe_name = self.config['breadth_universe']
        
        # You could fetch from a CSV or API
        # For now, return empty list (implement based on your data source)
        logger.warning("Breadth universe not implemented, returning empty")
        return []
    
    def _get_instrument_token(self, symbol: str) -> Optional[int]:
        """Get instrument token for symbol"""
        try:
            instruments = self.kite.instruments("NSE")
            for inst in instruments:
                if inst['tradingsymbol'] == symbol and inst['instrument_type'] == 'EQ':
                    return inst['instrument_token']
        except Exception as e:
            logger.debug(f"Token lookup failed for {symbol}: {e}")
        return None
    
    def _load_cache(self) -> Optional[float]:
        """Load cached breadth value"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'r') as f:
                    cache = json.load(f)
                    
                cache_time = datetime.fromisoformat(cache['timestamp'])
                expiry_hours = DATA_CONFIG['cache_expiry_hours']
                
                if datetime.now() - cache_time < timedelta(hours=expiry_hours):
                    return cache['breadth']
        except Exception as e:
            logger.debug(f"Cache load failed: {e}")
        
        return None
    
    def _save_cache(self, breadth: float):
        """Save breadth to cache"""
        try:
            os.makedirs(os.path.dirname(self.cache_file), exist_ok=True)
            with open(self.cache_file, 'w') as f:
                json.dump({
                    'breadth': breadth,
                    'timestamp': datetime.now().isoformat()
                }, f)
        except Exception as e:
            logger.debug(f"Cache save failed: {e}")


# =============================================================================
# SIGNAL GENERATOR
# =============================================================================

class SARRenkoSignalGenerator:
    """
    Multi-filter signal generator combining PSAR, Renko, and Breadth.
    """
    
    def __init__(self, df: pd.DataFrame, breadth: float, configs: dict):
        self.df = df
        self.breadth = breadth
        self.configs = configs
        
    def generate_signals(self) -> pd.DataFrame:
        """
        Generate trading signals based on all filters.
        
        Returns DataFrame with:
            - signal: 1 (long), -1 (short), 0 (no signal)
            - stop_loss: Stop loss price
            - confidence: Signal confidence (0-100)
        """
        # Calculate PSAR
        psar_calc = ParabolicSAR(self.df, self.configs['psar'])
        self.df = psar_calc.calculate()
        
        # Calculate Renko
        renko_calc = RenkoBricks(self.df, self.configs['renko'])
        self.df = renko_calc.build_bricks()
        
        # Calculate ADX (trend strength)
        if self.configs.get('adx', {}).get('use_adx_filter', False):
            adx_calc = ADXCalculator(self.df, self.configs['adx']['adx_period'])
            self.df = adx_calc.calculate()
        else:
            self.df['adx'] = 100  # No filter (allow all)
        
        # Initialize signal columns
        self.df['signal'] = 0
        self.df['stop_loss'] = np.nan
        self.df['confidence'] = 0
        
        # Generate signals row by row
        for i in range(len(self.df)):
            if i < 2:  # Need history
                continue
                
            signal, stop, confidence = self._evaluate_signal(i)
            self.df.loc[self.df.index[i], 'signal'] = signal
            self.df.loc[self.df.index[i], 'stop_loss'] = stop
            self.df.loc[self.df.index[i], 'confidence'] = confidence
        
        return self.df
    
    def _evaluate_signal(self, idx: int) -> Tuple[int, float, int]:
        """Evaluate signal for a given index"""
        row = self.df.iloc[idx]
        prev_row = self.df.iloc[idx-1]
        
        # === LONG SIGNAL CONDITIONS ===
        long_conditions = []
        
        # 1. PSAR reversal to bullish
        psar_long = (row['psar_trend'] == 1 and row['psar_reversal'] == 1)
        long_conditions.append(psar_long)
        
        # 2. Renko bricks are green
        renko_long = (row['renko_direction'] == 1 and 
                      row['renko_consecutive'] >= self.configs['renko']['min_bricks_for_signal'])
        long_conditions.append(renko_long)
        
        # 3. Breadth filter
        breadth_long = self.breadth >= self.configs['breadth']['min_breadth_long']
        long_conditions.append(breadth_long)
        
        # 4. ADX filter (trend strength)
        if self.configs.get('adx', {}).get('use_adx_filter', False):
            min_adx = self.configs['adx']['min_adx']
            adx_long = row.get('adx', 100) >= min_adx
            long_conditions.append(adx_long)
        
        # === SHORT SIGNAL CONDITIONS ===
        short_conditions = []
        
        # 1. PSAR reversal to bearish
        psar_short = (row['psar_trend'] == -1 and row['psar_reversal'] == 1)
        short_conditions.append(psar_short)
        
        # 2. Renko bricks are red
        renko_short = (row['renko_direction'] == -1 and 
                       row['renko_consecutive'] >= self.configs['renko']['min_bricks_for_signal'])
        short_conditions.append(renko_short)
        
        # 3. Breadth filter
        breadth_short = self.breadth <= self.configs['breadth']['min_breadth_short']
        short_conditions.append(breadth_short)
        
        # 4. ADX filter (trend strength)
        if self.configs.get('adx', {}).get('use_adx_filter', False):
            min_adx = self.configs['adx']['min_adx']
            adx_short = row.get('adx', 100) >= min_adx
            short_conditions.append(adx_short)
        
        # === DETERMINE SIGNAL ===
        signal = 0
        stop_loss = np.nan
        confidence = 0
        
        if all(long_conditions):
            signal = 1
            stop_loss = row['psar']  # Use PSAR as trailing stop
            confidence = self._calculate_confidence(long_conditions, row)
            
        elif all(short_conditions):
            signal = -1
            stop_loss = row['psar']
            confidence = self._calculate_confidence(short_conditions, row)
        
        return signal, stop_loss, confidence
    
    def _calculate_confidence(self, conditions: List[bool], row: pd.Series) -> int:
        """Calculate signal confidence (0-100)"""
        base_confidence = len([c for c in conditions if c]) / len(conditions) * 70
        
        # Bonus factors
        bonus = 0
        
        # Strong acceleration factor
        if row['psar_af'] > 0.1:
            bonus += 10
        
        # Multiple consecutive Renko bricks
        if row['renko_consecutive'] >= 3:
            bonus += 10
        
        # Strong breadth
        if self.breadth > 65 or self.breadth < 35:
            bonus += 10
        
        # Strong trend (ADX)
        adx = row.get('adx', 0)
        if adx > 40:
            bonus += 15  # Very strong trend
        elif adx > 30:
            bonus += 10  # Strong trend
        elif adx > 25:
            bonus += 5   # Moderate trend
        
        return min(int(base_confidence + bonus), 100)


# =============================================================================
# POSITION SIZER
# =============================================================================

class PositionSizer:
    """Calculate position sizes based on risk parameters"""
    
    def __init__(self, config: dict):
        self.config = config
        
    def calculate_size(self, capital: float, entry_price: float, 
                      stop_price: float) -> Dict:
        """
        Calculate position size based on risk.
        
        Args:
            capital: Total available capital
            entry_price: Entry price per share
            stop_price: Stop loss price
            
        Returns:
            Dict with quantity, risk_amount, position_value
        """
        risk_per_trade = capital * (self.config['risk_per_trade_pct'] / 100)
        
        # Calculate stop distance
        stop_distance = abs(entry_price - stop_price)
        stop_distance_pct = (stop_distance / entry_price) * 100
        
        # Validate stop distance
        if stop_distance_pct < self.config['min_stop_distance_pct']:
            logger.warning(f"Stop too tight: {stop_distance_pct:.2f}%")
            stop_distance_pct = self.config['min_stop_distance_pct']
            stop_price = entry_price * (1 - stop_distance_pct/100)
            stop_distance = abs(entry_price - stop_price)
            
        if stop_distance_pct > self.config['max_stop_distance_pct']:
            logger.warning(f"Stop too wide: {stop_distance_pct:.2f}%")
            return {'quantity': 0, 'reason': 'stop_too_wide'}
        
        # Calculate quantity
        quantity = int(risk_per_trade / stop_distance)
        position_value = quantity * entry_price
        
        # Validate position size
        if position_value > capital * 0.2:  # Max 20% per position
            quantity = int((capital * 0.2) / entry_price)
            position_value = quantity * entry_price
        
        return {
            'quantity': quantity,
            'position_value': position_value,
            'risk_amount': risk_per_trade,
            'stop_distance_pct': stop_distance_pct,
            'stop_price': stop_price
        }


# =============================================================================
# MAIN SCANNER
# =============================================================================

class SARRenkoScanner:
    """Main scanner class"""
    
    def __init__(self, api_key: str, access_token: str):
        logger.info("Initializing SAR-Renko Scanner...")
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Verify connection
        try:
            profile = self.kite.profile()
            logger.info(f"Connected as: {profile.get('user_id')}")
        except Exception as e:
            logger.error(f"Failed to connect to Kite: {e}")
            raise
        
        # Initialize components
        self.breadth_calc = MarketBreadth(self.kite, BREADTH_CONFIG)
        self.position_sizer = PositionSizer(RISK_CONFIG)
        
        # Load instrument map
        self.instrument_map = self._load_instruments()
        
    def _load_instruments(self) -> Dict[str, int]:
        """Load instrument tokens"""
        logger.info("Loading NSE instruments...")
        try:
            instruments = self.kite.instruments("NSE")
            instrument_map = {}
            
            for inst in instruments:
                if inst['exchange'] == 'NSE' and inst['instrument_type'] == 'EQ':
                    instrument_map[inst['tradingsymbol']] = inst['instrument_token']
            
            logger.info(f"Loaded {len(instrument_map)} instruments")
            return instrument_map
            
        except Exception as e:
            logger.error(f"Failed to load instruments: {e}")
            return {}
    
    @sleep_and_retry
    @limits(calls=3, period=1)
    def _fetch_historical_data(self, symbol: str) -> Optional[pd.DataFrame]:
        """Fetch historical data with rate limiting"""
        try:
            if symbol not in self.instrument_map:
                logger.debug(f"Symbol {symbol} not found")
                return None
            
            instrument_token = self.instrument_map[symbol]
            
            to_date = datetime.now()
            from_date = to_date - timedelta(days=DATA_CONFIG['lookback_days'])
            
            data = self.kite.historical_data(
                instrument_token,
                from_date.strftime('%Y-%m-%d'),
                to_date.strftime('%Y-%m-%d'),
                DATA_CONFIG['timeframe']
            )
            
            df = pd.DataFrame(data)
            
            if len(df) < DATA_CONFIG['min_data_points']:
                logger.debug(f"{symbol}: Insufficient data ({len(df)} bars)")
                return None
            
            # Add symbol column
            df['symbol'] = symbol
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def scan_stock(self, symbol: str, breadth: float) -> Optional[Dict]:
        """Scan a single stock"""
        try:
            # Fetch data
            df = self._fetch_historical_data(symbol)
            if df is None:
                return None
            
            # Generate signals
            signal_gen = SARRenkoSignalGenerator(
                df,
                breadth,
                {
                    'psar': PSAR_CONFIG,
                    'renko': RENKO_CONFIG,
                    'breadth': BREADTH_CONFIG,
                    'adx': ADX_CONFIG
                }
            )
            
            df_with_signals = signal_gen.generate_signals()
            
            # Get latest signal
            latest = df_with_signals.iloc[-1]
            
            if latest['signal'] == 0:
                return None  # No signal
            
            # Calculate position size
            capital = 1000000  # Adjust based on your capital
            position_info = self.position_sizer.calculate_size(
                capital,
                latest['close'],
                latest['stop_loss']
            )
            
            if position_info.get('quantity', 0) == 0:
                return None
            
            # Build result
            result = {
                'symbol': symbol,
                'date': latest['date'],
                'signal': 'LONG' if latest['signal'] == 1 else 'SHORT',
                'entry_price': latest['close'],
                'stop_loss': latest['stop_loss'],
                'confidence': latest['confidence'],
                'adx': latest.get('adx', np.nan),
                'psar': latest['psar'],
                'psar_af': latest['psar_af'],
                'renko_direction': latest['renko_direction'],
                'renko_consecutive': latest['renko_consecutive'],
                'breadth': breadth,
                'quantity': position_info['quantity'],
                'position_value': position_info['position_value'],
                'risk_amount': position_info['risk_amount'],
                'risk_pct': (position_info['risk_amount'] / capital) * 100,
            }
            
            adx_str = f", ADX: {result['adx']:.1f}" if not np.isnan(result['adx']) else ""
            logger.info(f"✅ {symbol}: {result['signal']} @ {result['entry_price']:.2f} "
                       f"(Stop: {result['stop_loss']:.2f}, Conf: {result['confidence']}{adx_str})")
            
            return result
            
        except Exception as e:
            logger.error(f"Error scanning {symbol}: {e}")
            return None
    
    def run_scan(self, symbols: List[str] = None) -> pd.DataFrame:
        """Run full scan"""
        logger.info("=" * 60)
        logger.info("STARTING SAR-RENKO STRATEGY SCAN")
        logger.info("=" * 60)
        
        # Calculate market breadth
        logger.info("Calculating market breadth...")
        breadth = self.breadth_calc.calculate_breadth()
        logger.info(f"Market Breadth: {breadth:.2f}%")
        
        # Load symbols if not provided
        if symbols is None:
            symbols = self._load_symbols_from_csv()
        
        logger.info(f"Scanning {len(symbols)} stocks...")
        
        # Scan all stocks
        results = []
        for i, symbol in enumerate(symbols, 1):
            if i % 10 == 0:
                logger.info(f"Progress: {i}/{len(symbols)}")
            
            result = self.scan_stock(symbol, breadth)
            if result:
                results.append(result)
            
            time.sleep(API_CALL_DELAY)
        
        # Convert to DataFrame
        if results:
            df_results = pd.DataFrame(results)
            df_results = df_results.sort_values('confidence', ascending=False)
            
            logger.info("=" * 60)
            logger.info(f"SCAN COMPLETE: {len(results)} signals found")
            logger.info("=" * 60)
            
            return df_results
        else:
            logger.info("No signals found")
            return pd.DataFrame()
    
    def _load_symbols_from_csv(self) -> List[str]:
        """Load symbols from input CSV"""
        try:
            csv_path = SCANNER_CONFIG['input_csv']
            df = pd.read_csv(csv_path)
            symbols = df['Symbol'].str.strip().tolist()
            logger.info(f"Loaded {len(symbols)} symbols from {csv_path}")
            return symbols
        except Exception as e:
            logger.error(f"Failed to load symbols: {e}")
            return []
    
    def save_results(self, df_results: pd.DataFrame):
        """Save scan results"""
        if df_results.empty:
            logger.info("No results to save")
            return
        
        # Create output directory
        output_dir = SCANNER_CONFIG['output_dir']
        os.makedirs(output_dir, exist_ok=True)
        
        # Generate filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = f"{output_dir}/sar_renko_scan_{timestamp}.csv"
        
        # Save
        df_results.to_csv(output_file, index=False)
        logger.info(f"Results saved to: {output_file}")
        
        # Print summary
        print("\n" + "=" * 60)
        print("TOP 10 SIGNALS")
        print("=" * 60)
        print(df_results.head(10).to_string(index=False))


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description='SAR-Renko Strategy Scanner')
    parser.add_argument('--symbols', nargs='+', help='Specific symbols to scan')
    parser.add_argument('--test', action='store_true', help='Test mode (limited symbols)')
    args = parser.parse_args()
    
    try:
        # Initialize scanner
        scanner = SARRenkoScanner(API_KEY, ACCESS_TOKEN)
        
        # Determine symbols
        if args.test:
            test_symbols = ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK']
            logger.info(f"TEST MODE: Scanning {len(test_symbols)} symbols")
            symbols = test_symbols
        elif args.symbols:
            symbols = args.symbols
        else:
            symbols = None  # Will load from CSV
        
        # Run scan
        results = scanner.run_scan(symbols)
        
        # Save results
        scanner.save_results(results)
        
    except KeyboardInterrupt:
        logger.info("\nScan interrupted by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)


if __name__ == "__main__":
    main()

