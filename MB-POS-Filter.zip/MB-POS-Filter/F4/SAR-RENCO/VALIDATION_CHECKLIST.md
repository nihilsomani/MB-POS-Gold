# Strategy Validation Checklist

## Purpose

Before deploying **any** trading strategy with real capital, you must validate that:
1. The strategy works on **out-of-sample data** (not just backtest period)
2. The edge is **statistically significant** (not random luck)
3. The implementation is **bug-free** (no look-ahead bias, correct calculations)
4. You understand **when it fails** (regime awareness)

This checklist is based on professional quant validation frameworks.

---

## Phase 1: Code Validation ✅

### 1.1 Mathematical Correctness

- [ ] **PSAR Calculation Verified**
  - Test against known values from TradingView/MetaTrader
  - Edge case: What happens on first day (no prior extreme point)?
  - Edge case: What happens on gaps (opening price ≠ prior close)?
  
- [ ] **Renko Brick Formation Verified**
  - Manual calculation for 10 days matches code output
  - Test: Price moves exactly 1 brick → should form 1 brick (not 0, not 2)
  - Test: Price moves 2.7 bricks → should form 2 bricks (not 3)
  - **Critical**: Brick formation uses CLOSE price only (not intraday highs/lows)
  
- [ ] **Breadth Calculation Verified**
  - Matches published breadth data (e.g., NSE breadth indicators)
  - Test: If 300/500 stocks above MA, breadth = 60% (not 59.9% or 60.1%)
  
- [ ] **Position Sizing Verified**
  - Test: ₹10L capital, 2% risk, ₹50 stop → quantity = 400 shares
  - Test: Position value never exceeds 30% of capital
  - Test: Quantity is always INTEGER (no fractional shares)

### 1.2 Look-Ahead Bias Check

**Critical**: Backtest must NOT use future information.

- [ ] **Renko Bricks**
  - [ ] Code waits for bar close before forming brick
  - [ ] No peeking at next day's high/low
  - [ ] Test: Run backtest on hourly data vs daily data → results should differ
  
- [ ] **PSAR**
  - [ ] SAR value calculated using only prior data
  - [ ] Extreme point (EP) updates only when new high/low occurs
  
- [ ] **Breadth**
  - [ ] Breadth calculated using data available BEFORE entry
  - [ ] No using "end of day" breadth for "start of day" entry

### 1.3 Transaction Cost Reality

- [ ] **Commission Included**
  - Default: 0.05% per trade (₹500 on ₹10L)
  - Zerodha: 0.03% or ₹20 per trade (whichever is lower)
  
- [ ] **Slippage Included**
  - Default: 0.05% on entry AND exit
  - For illiquid stocks (< 1M volume): 0.1%
  - Test: Remove slippage → returns should increase ~0.2% per trade
  
- [ ] **Taxes Included (if applicable)**
  - STT: 0.1% on sell side
  - GST on brokerage: 18%

---

## Phase 2: Statistical Validation 📊

### 2.1 Sample Size Sufficiency

- [ ] **Minimum 30 Trades**
  - With < 30 trades, confidence intervals are ± 20%
  - Example: 75% win rate with 10 trades → true win rate could be 55-95%
  
- [ ] **Minimum 2 Years of Data**
  - Must include at least 1 bull market and 1 correction
  - Single regime testing = useless (overfits to that regime)

### 2.2 Out-of-Sample Testing

**THE GOLDEN RULE: Never optimize on data you will test on.**

- [ ] **Walk-Forward Validation**
  ```
  2019-2021: Train (optimize parameters)
  2022:      Test (locked parameters, no changes)
  2023:      Walk forward (use 2022 learnings)
  2024:      Final validation
  ```
  
- [ ] **Performance on Test Period**
  - [ ] Test period Sharpe > 0.5 (minimum)
  - [ ] Test period drawdown < 1.5× train period drawdown
  - [ ] Test period win rate within ±10% of train period
  
- [ ] **If test period fails:**
  - **DO NOT** re-optimize to fix test period (that's data snooping)
  - **DO** investigate why (regime change? structural break?)
  - **DO** discard strategy if edge disappeared

### 2.3 Parameter Sensitivity Analysis

**Goal**: Strategy should work with parameters ±10% from optimal.

- [ ] **Test PSAR Start AF**
  - Optimal: 0.02
  - Test: 0.018, 0.019, 0.021, 0.022
  - **Pass criteria**: Performance degradation < 15%
  
- [ ] **Test Renko Brick Size**
  - Optimal: ATR × 1.5
  - Test: ATR × 1.3, 1.4, 1.6, 1.7
  - **Pass criteria**: Performance degradation < 20%
  
- [ ] **Test Breadth Threshold**
  - Optimal: 50%
  - Test: 45%, 48%, 52%, 55%
  - **Pass criteria**: Performance degradation < 10%

**Red flag**: If changing parameter by 5% causes 30%+ performance drop → **overfitted**.

### 2.4 Random Control Test

**Question**: Is strategy performance better than random entries with same risk management?

- [ ] **Generate Random Entries**
  ```python
  # Random strategy:
  # 1. Enter random days (same frequency as real strategy)
  # 2. Use same stop loss rules (PSAR trailing stop)
  # 3. Run 1000 times, measure average performance
  ```
  
- [ ] **Compare Results**
  - Real strategy Sharpe: 1.2
  - Random strategy avg Sharpe: 0.3
  - **Z-score**: (1.2 - 0.3) / std(random) = ???
  
- [ ] **Pass criteria**
  - Z-score > 2.0 (95% confidence)
  - Real strategy outperforms 95%+ of random runs

### 2.5 Monte Carlo Simulation

**Goal**: Understand range of possible outcomes.

- [ ] **Resample Trades 1000 Times**
  ```python
  # Randomly shuffle trade order 1000 times
  # This simulates "what if trades happened in different order"
  ```
  
- [ ] **Check Distribution**
  - [ ] 5th percentile return > -10% (worst case acceptable)
  - [ ] 50th percentile (median) close to backtest return
  - [ ] 95th percentile return not crazy high (no lottery tickets)
  
- [ ] **Pass criteria**
  - 5th percentile return > 0% (worst case still profitable)
  - Median return within ±20% of backtest return

---

## Phase 3: Regime Testing 🌦️

### 3.1 Test on Different Market Regimes

- [ ] **Bull Market Performance**
  - Period: 2020-2021 (Nifty +100%)
  - Expected: Strategy thrives (70%+ win rate)
  - **Fail condition**: Win rate < 60%
  
- [ ] **Bear Market Performance**
  - Period: 2022 (Nifty -15%)
  - Expected: Strategy struggles (50-55% win rate)
  - **Fail condition**: Drawdown > 30%
  
- [ ] **Sideways Market Performance**
  - Period: 2015-2016 (Nifty ±5%)
  - Expected: Strategy bleeds slowly (45-50% win rate)
  - **Acceptable**: Small losses if breadth filter kept capital safe
  
- [ ] **Pass criteria**
  - No single regime accounts for > 60% of total profit
  - Strategy doesn't blow up in any regime (max DD < 30%)

### 3.2 Stress Tests

- [ ] **COVID Crash (Feb-Mar 2020)**
  - Nifty drops 40% in 1 month
  - **Test**: How many gap-down stops? Total loss?
  - **Pass criteria**: Strategy loss < 15% (better than market)
  
- [ ] **2018 NBFC Crisis**
  - Liquidity crunch, high volatility
  - **Test**: Does breadth filter save you?
  - **Pass criteria**: Low trade frequency during crisis
  
- [ ] **2016 Demonetization**
  - Sudden regime shift
  - **Test**: Exit speed, capital preservation
  - **Pass criteria**: Closed positions within 3 days

---

## Phase 4: Implementation Validation 🖥️

### 4.1 Broker Integration Testing

- [ ] **Order Placement Works**
  - Test: Place order via API → order appears in broker portal
  - Test: Market order fills at reasonable price (< 0.1% slippage)
  - Test: Stop loss order triggers correctly
  
- [ ] **Data Feed Reliability**
  - Test: Historical data matches broker's data
  - Test: Real-time quotes update within 1 second
  - Test: What happens if data feed drops? (graceful failure)
  
- [ ] **Error Handling**
  - Test: Insufficient funds → order rejected (not placed)
  - Test: Stock halted → no entry (don't catch falling knife)
  - Test: Internet drops → positions monitored (don't lose track)

### 4.2 Paper Trading Results

**Critical**: Paper trade for minimum 1 month before live trading.

- [ ] **Paper Trading Checklist**
  - [ ] Run scanner daily at same time (e.g., 9:30 AM)
  - [ ] Record ALL signals (even if you wouldn't take them)
  - [ ] Track hypothetical P&L with realistic slippage
  - [ ] Compare to backtest expectations
  
- [ ] **Paper Trading Metrics**
  - [ ] Win rate within ±15% of backtest
  - [ ] Average win/loss within ±20% of backtest
  - [ ] Signal frequency matches backtest (8-15/year)
  - [ ] No unexpected errors or bugs
  
- [ ] **Pass criteria**
  - Paper trading Sharpe > 0.5
  - No major discrepancies from backtest
  - You understand why EVERY signal was generated

### 4.3 Live Trading (Small Size)

- [ ] **Start with 10% of Target Capital**
  - If target is ₹10L, start with ₹1L
  - This limits damage from unknown unknowns
  
- [ ] **First 10 Trades Review**
  - [ ] Track: Entry slippage (actual vs expected)
  - [ ] Track: Exit slippage (actual vs expected)
  - [ ] Track: Commission (actual vs expected)
  - [ ] Track: Emotional compliance (did you follow rules?)
  
- [ ] **Scale-Up Criteria**
  - After 10 trades: Review performance
  - If performance within 20% of expectations → scale to 30%
  - After 20 trades: Scale to 50%
  - After 30 trades: Scale to 100%

---

## Phase 5: Ongoing Monitoring 📈

### 5.1 Monthly Performance Review

- [ ] **Compare to Benchmarks**
  - vs Nifty 500 (market return)
  - vs Strategy backtest (expected return)
  - vs Risk-free rate (opportunity cost)
  
- [ ] **Check for Degradation**
  - Rolling 3-month Sharpe ratio
  - Rolling 6-month win rate
  - Rolling 12-month drawdown
  
- [ ] **Warning Signs**
  - Win rate drops below 45% (3-month rolling)
  - Sharpe ratio < 0.3 (6-month rolling)
  - Drawdown > 20%

### 5.2 Regime Monitoring

- [ ] **Track Current Market Regime**
  - Nifty 500 vs 200-day SMA (trend direction)
  - VIX level (volatility regime)
  - Market breadth (participation)
  
- [ ] **Adjust Strategy Usage**
  - If VIX > 30: Reduce position sizes by 50%
  - If breadth < 40 for 2 weeks: Stop new long entries
  - If drawdown > 15%: Pause trading, review

### 5.3 Parameter Drift Check

**Over time, optimal parameters can shift due to market evolution.**

- [ ] **Annual Re-Optimization**
  - Re-run optimization on last 3 years
  - Compare new optimal vs current parameters
  - If difference > 30%, consider updating
  
- [ ] **But Avoid Over-Updating**
  - Don't change parameters more than once/year
  - Don't change after a single bad month
  - Don't curve-fit to recent data

---

## Phase 6: Kill Switch Conditions 🚨

**When to STOP trading the strategy entirely:**

### 6.1 Statistical Breakdown

- [ ] **Win rate < 40% over 15+ trades**
  - Threshold: Edge disappeared (< 50% is coin flip)
  - Action: Pause 3 months, re-validate
  
- [ ] **Sharpe ratio < 0.3 over 12 months**
  - Threshold: Risk-adjusted returns worse than bonds
  - Action: Stop trading, deep review
  
- [ ] **Max drawdown > 25%**
  - Threshold: Unacceptable capital impairment
  - Action: Immediate stop, regime may have changed

### 6.2 Operational Breakdown

- [ ] **Consistent data feed issues**
  - Multiple missed signals due to bad data
  - Action: Fix data infrastructure before resuming
  
- [ ] **Broker execution problems**
  - Orders not filling, excessive slippage (> 0.2%)
  - Action: Switch brokers or reduce position size
  
- [ ] **Emotional override pattern**
  - You overrode system 3+ times in a month
  - Action: You're not ready for systematic trading

### 6.3 Market Structure Change

- [ ] **Breadth calculation no longer reliable**
  - Index composition changed significantly
  - Action: Recalibrate breadth universe
  
- [ ] **Regulatory changes**
  - New SEBI rules affect strategy mechanics
  - Action: Legal review before resuming
  
- [ ] **Market microstructure shift**
  - Algo trading penetration increases volatility
  - Action: Re-test strategy on recent data

---

## Validation Checklist Summary

### Before Going Live

**Minimum Requirements (ALL must pass):**

- ✅ Out-of-sample test period Sharpe > 0.5
- ✅ Parameter sensitivity test passed (< 20% degradation)
- ✅ Random control test passed (Z-score > 2.0)
- ✅ Monte Carlo 5th percentile > 0%
- ✅ Tested on 3+ market regimes
- ✅ Paper traded for 1 month minimum
- ✅ Broker integration tested
- ✅ Kill switch conditions defined

### During Live Trading

**Monthly Checks:**
- Track performance vs backtest expectations
- Monitor regime alignment
- Review compliance (did you follow all rules?)

**Quarterly Checks:**
- Deep dive into losing trades (was strategy wrong, or bad luck?)
- Parameter drift analysis
- Portfolio correlation check

**Annual Checks:**
- Full strategy re-validation on new data
- Consider parameter re-optimization
- Review kill switch conditions (still appropriate?)

---

## Common Validation Failures & Fixes

### Failure: "Backtest great, paper trading terrible"

**Possible causes:**
1. Look-ahead bias in backtest
2. Slippage underestimated
3. Data feed differences
4. Regime changed

**Fix**:
- Audit code for look-ahead bias
- Increase slippage assumption to 0.1%
- Verify data sources match
- Check current market regime vs backtest period

### Failure: "Parameter sensitivity test failed"

**Symptom**: Changing parameter by 10% causes 50% performance drop

**Cause**: Overfitting

**Fix**:
- Use wider parameter ranges in optimization
- Require parameter stability
- Consider fewer parameters (remove one filter)

### Failure: "Random control test failed"

**Symptom**: Random entries perform just as well

**Cause**: No genuine edge (just got lucky)

**Fix**:
- Strategy has no edge, discard it
- Or: Add stronger filters (increase selectivity)
- Or: Change holding period (maybe wrong timeframe)

### Failure: "Regime test shows 80% profit from 1 year"

**Symptom**: 2021 bull market accounts for 80% of total profit

**Cause**: Strategy only works in strong trends

**Fix**:
- Accept that strategy is regime-dependent
- Add regime classifier (only trade in trending markets)
- Or: Combine with mean-reversion strategy for sideways markets

---

## Final Checklist Before Live Trading

Print this out and check EVERY box:

- [ ] I have tested this strategy on out-of-sample data
- [ ] I understand when and why this strategy fails
- [ ] I have paper traded for at least 1 month
- [ ] I will follow the system rules 100% (no overrides)
- [ ] I accept that 40-45% of trades will lose money
- [ ] I accept 3-6 month periods with no signals
- [ ] I accept 15-20% drawdowns as normal
- [ ] I have defined my kill switch conditions in writing
- [ ] I will review performance monthly (not daily)
- [ ] I understand this is not a get-rich-quick scheme

**If you can't check EVERY box, you're not ready for live trading.**

---

## Resources for Further Validation

### Books
- *Evidence-Based Technical Analysis* - David Aronson (on proper testing)
- *Quantitative Trading* - Ernest Chan (validation frameworks)
- *The Evaluation and Optimization of Trading Strategies* - Robert Pardo

### Tools
- **QuantConnect** - Cloud backtesting with institutional-grade data
- **Backtrader** - Python backtesting library
- **TradeStation** - Professional backtesting software

### Professional Services
- **Quant validation firms** - Pay to have your strategy audited
- **University partnerships** - Academic validation studies
- **CFA Institute** - Resources on strategy validation

---

**Remember: The goal of validation is to DISPROVE your strategy. If it survives all attempts to break it, you might have something real.**

