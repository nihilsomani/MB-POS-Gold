# Proposed Parameter Tests for WEEKS_BACK = 26 Strategy

## 🎯 **PHILOSOPHY: ONE CHANGE AT A TIME**

After Yamada Framework validation, we have a robust baseline:
- WEEKS_BACK = 26
- MOMENTUM_PERIOD = 5
- TAIL_LENGTH = 5
- MIN_SCORE = 0, MAX_SCORE = 999
- PERSISTENCE = 40

**Now test INDIVIDUAL improvements, not wholesale rewrites.**

---

## 📋 **TEST QUEUE (In Order of Priority)**

### **Test 1: MOMENTUM_PERIOD = 13** ✅ Worth Testing
**Hypothesis**: Matching momentum period to holding period (quarterly) improves signal quality

**Test Setup**:
```python
WEEKS_BACK = 26          # Keep validated
MOMENTUM_PERIOD = 13     # TEST: Change from 5 to 13
TAIL_LENGTH = 5          # Keep validated
MIN_SCORE = 0            # Keep validated
MAX_SCORE = 999          # Keep validated
PERSISTENCE = 40         # Keep validated
```

**Success Criteria**:
- CAGR within -5% (≥61.5%)
- Max DD within +5% (≤-16%)
- Sharpe ≥ 1.8
- Win Rate ≥ 70%

**If PASS**: Accept change  
**If FAIL**: Revert to 5

---

### **Test 2: TAIL_LENGTH = 8** ✅ Worth Testing
**Hypothesis**: More tail data reduces noise in trend detection

**Test Setup**:
```python
WEEKS_BACK = 26          # Keep validated
MOMENTUM_PERIOD = 13     # Use result from Test 1
TAIL_LENGTH = 8          # TEST: Change from 5 to 8
MIN_SCORE = 0            # Keep validated
MAX_SCORE = 999          # Keep validated
PERSISTENCE = 40         # Keep validated
```

**Success Criteria**: Same as Test 1

---

### **Test 3: MIN_SCORE = 50** ❌ DON'T TEST (Already Proven Bad)
**Reason**: We tested score filters extensively. They overfit.

Result from Parameter Plateau Test:
- MIN_SCORE variations caused 38.92% CAGR swing
- Setting to 0 was MORE robust
- Adding back filter = going backwards

**VERDICT: REJECT without testing**

---

### **Test 4: PERSISTENCE = 35** ⚠️ Test Only If Other Changes Succeed
**Hypothesis**: Slightly lower persistence might capture more opportunities

**Concern**: Fine-grained test showed 40-45 as stable plateau. Moving to 35 risks leaving the plateau.

**Test ONLY if Tests 1-2 both succeed AND you want more refinement.**

---

### **Tests 5-8: NEW Features** ❌ REJECT ALL

**Why REJECT?**

1. **Liquidity Filters (min_volume, min_market_cap)**
   - Arbitrary thresholds
   - No evidence they help
   - Could filter out winners
   - Strategy already works on existing universe

2. **Concentration Limits (max_sector_weight: 40%)**
   - **WE ALREADY TESTED THIS!**
   - **Result: HURT PERFORMANCE**
   - Sector limits reduced CAGR and increased DD
   - REJECTED in previous tests

3. **Continuous Scoring System**
   - Complete rewrite of validated logic
   - Arbitrary scale factors (2.5, 0.5, 0.3)
   - Zero backtesting
   - **This is how you destroy a working strategy**

4. **Risk Bands & Trend Thresholds**
   - All numbers arbitrary (100, 50, 25, 120, 115, etc.)
   - Pure curve-fitting
   - No validation
   - **Classic overfitting trap**

**VERDICT: DO NOT IMPLEMENT**

---

## 🎯 **RECOMMENDED TESTING SEQUENCE**

### **Phase 1: Validate Momentum/Tail Alignment (1-2 weeks)**

**Step 1**: Test MOMENTUM_PERIOD = 13
```bash
# Change ONLY MOMENTUM_PERIOD
MOMENTUM_PERIOD = 13
# Run full backtest
# Compare to baseline (64.81% CAGR, -11% DD, 2.00 Sharpe)
```

**Step 2**: IF Step 1 improves OR maintains performance, test TAIL_LENGTH = 8
```bash
# Change MOMENTUM_PERIOD AND TAIL_LENGTH
MOMENTUM_PERIOD = 13
TAIL_LENGTH = 8
# Run full backtest
# Compare to baseline
```

**Step 3**: Decide
- ✅ If improvements: Keep changes
- ❌ If worse: Revert to baseline

---

### **Phase 2: Re-run Yamada Framework (2-3 weeks)**

After ANY parameter changes, re-run ALL validation tests:

1. **Random Control Test**: Does edge still exist?
2. **Parameter Plateau Test**: Are new parameters robust?
3. **Delayed Entry Test**: Still works with 7-day delay?
4. **Outlier Dependency Test**: Check if still relies on same winners
5. **Out-of-Sample Test**: Validate on 2024-2025 only

**Only deploy if ALL tests still PASS**

---

### **Phase 3: Live Paper Trading (3+ months)**

Before going live with real money:
- Paper trade for one full quarter
- Track slippage, execution issues
- Verify real-world matches backtest

---

## ⚠️ **WHAT NOT TO DO**

### **DON'T:**

1. ❌ Add multiple changes at once
2. ❌ Re-introduce features we already tested and rejected
3. ❌ Add arbitrary thresholds without validation
4. ❌ Rewrite validated logic without proof
5. ❌ Fall into complexity creep

### **Remember:**
> "The best trading strategies are simple, robust, and boring.  
> If you need 50 rules to make it work, it's probably overfit."  
> — Every successful quant who learned the hard way

---

## 📊 **CURRENT STATUS**

**Baseline (VALIDATED):**
```python
WEEKS_BACK = 26
MOMENTUM_PERIOD = 5
TAIL_LENGTH = 5
MIN_SCORE = 0
MAX_SCORE = 999
PERSISTENCE = 40
ENTRY_DELAY = 7
STOP_LOSS = 15%
REBALANCE = Quarterly
```

**Performance:**
- CAGR: 64.81%
- Max DD: -11.00%
- Sharpe: 2.00
- Win Rate: 78.6%
- Benchmark Excess: +50.91%

**Status**: ✅ EXCEPTIONAL - Production Ready

**Next Step**: Test MOMENTUM_PERIOD = 13 ONLY

---

**Date**: October 23, 2025  
**Recommendation**: Test incrementally, reject untested complexity

