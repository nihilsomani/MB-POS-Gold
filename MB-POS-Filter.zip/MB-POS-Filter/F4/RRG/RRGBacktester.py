"""
RRG-Based Momentum Strategy Backtester
=======================================
Monthly rotation backtester using Relative Rotation Graph (RRG) methodology
Selects Top 15 stocks based on RRG Opportunity Score each month

Strategy:
- Run full RRG analysis at month-end
- Select TOP 15 stocks by Opportunity_Score
- Equal weight position sizing (6.67% each)
- Monthly rebalancing with transaction costs
- Benchmark: Nifty 50

Author: Quant Strategy System
Date: 2025-10-10
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import warnings
import time
import json
import os
import math
from typing import Dict, List, Optional, Tuple
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')

# =============================================================================
# CONFIGURATION SECTION
# =============================================================================

# API Configuration
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "IPu3YFNqPkAlRsmQ6R7whtIhJSJsLsKf"

# Backtest Period (PRODUCTION VALIDATED)
BACKTEST_START_DATE = "2021-01-01"      # Start date for backtest
BACKTEST_END_DATE = "2025-10-10"        # End date for backtest (today)
REBALANCE_FREQUENCY = 'quarterly'       # 'monthly' or 'quarterly'

# Portfolio Configuration
PORTFOLIO_SIZE = 10                     # Top 15 stocks from RRG
INITIAL_CAPITAL = 2000000               # Starting capital (₹10 Lakhs)
POSITION_SIZING = 'equal_weight'        # Equal weight only

# Transaction Costs (REALISTIC ZERODHA CHARGES)
# Based on Zerodha equity delivery (CNC) charges as of 2025
# ============================================================================
# Buy Side (per ₹1 Lakh):
#   Brokerage: ₹0 (Free for delivery)
#   STT: 0.1% on buy = ₹100
#   Exchange charges (NSE): 0.00325% = ₹3.25
#   GST on charges: 18% of ₹3.25 = ₹0.59
#   Stamp duty: 0.015% = ₹15
#   SEBI: Negligible (~₹1 per crore)
#   Total Buy: ~₹119 = 0.119%
#
# Sell Side (per ₹1 Lakh):
#   Brokerage: ₹0 (Free for delivery)
#   STT: 0.1% on sell = ₹100
#   Exchange charges (NSE): 0.00325% = ₹3.25
#   GST on charges: 18% of ₹3.25 = ₹0.59
#   DP charges: ₹13.5 + GST per scrip = ₹15.93
#   SEBI: Negligible
#   Total Sell: ~₹120 = 0.120%
#
# Statutory Costs (Buy + Sell): 0.119% + 0.120% = 0.239%
# ============================================================================

STATUTORY_COSTS_PCT = 0.00239          # 0.239% (STT, stamp duty, exchange charges, DP)

# Market Impact & Execution Costs (for small/mid caps)
MARKET_IMPACT_PCT = 0.003              # 0.3% (your order moves the price)
BID_ASK_SPREAD_PCT = 0.002             # 0.2% (spread in small/mid caps)
SLIPPAGE_PCT = 0.002                   # 0.2% (execution variance)

# Total Realistic Cost Per Round Trip (Buy + Sell)
TOTAL_COST_PER_TRADE = (
    STATUTORY_COSTS_PCT +               # 0.239%
    MARKET_IMPACT_PCT +                 # 0.300%
    BID_ASK_SPREAD_PCT +                # 0.200%
    SLIPPAGE_PCT                        # 0.200%
)  # = 0.939% ≈ 0.94% per round trip

# Conservative estimate: Round up to 1%
TOTAL_COST_PER_TRADE = 0.01            # 1.0% total per round trip (REALISTIC)

# RRG Parameters (from RRG.py)
WEEKS_BACK = 13                         # Number of weeks for historical data
MOMENTUM_PERIOD = 5                     # Period for momentum calculation
TAIL_LENGTH = 5                         # Number of data points for tail

# Scoring Weights (OPTIMIZED - Favor Early Entry)
SCORING_WEIGHTS = {
    'quadrant_scores': {
        'Leading': 60,          # REDUCED from 90 (avoid late entries)
        'Improving': 95,        # INCREASED from 70 (enter early)
        'Weakening': 30,        # Reduced from 40
        'Lagging': 10           # Reduced from 20
    },
    'rs_ratio_multiplier': 0.35,    # Slightly reduced
    'momentum_multiplier': 0.45,     # Increased (reward momentum)
    'distance_multiplier': 0.15,     # Reduced
    'movement_bonuses': {
        'toward_leading': 35,
        'toward_improving': 25,
        'toward_lagging_penalty': -20
    },
    'velocity_max_bonus': 20        # Reduced (avoid spikes)
}

# Benchmark (Multi-cap comparison)
# Common benchmark symbols: 'NIFTY 50', 'NIFTY 500', 'NIFTY MIDCAP 100'
BENCHMARK_INDEX = 'NIFTY 500'       # Better for 1000+ stock universe (mid/small cap)

# Strategy Filters (SIMPLIFIED - Trust RRG Ranking, Not Hard Cutoffs)
MIN_SCORE_THRESHOLD = 0                 # No minimum - trust RRG ranking
MAX_SCORE_THRESHOLD = 999               # No maximum - let all stocks qualify
EXCLUDE_SECTORS = [                     # Sectors to exclude (historically poor performers)
]
COOLDOWN_MONTHS = 2                      # Don't re-enter a failed stock for 2 months
MIN_IMPROVING_STOCKS = 0                 # Changed to 0 - data shows Improving underperforms Leading!
PREFER_LEADING_QUADRANT = True           # Prefer Leading since it has better win rate

# Quality Filters (TESTING - Enable to test if these improve performance)
USE_QUALITY_FILTERS = False               # Enable to test quality filters
REQUIRE_EXCELLENT_MOMENTUM = False       # Only stocks with "Excellent" Momentum_Quality
REQUIRE_EXCELLENT_TAIL = False            # Only stocks with "Excellent" Tail_Quality
REQUIRE_STRONG_BUY = False                # Only stocks with "STRONG BUY" recommendation

# Persistence Logic (OPTIMIZED - From Plateau Test)
USE_PERSISTENCE_LOGIC = True             # Hold winners longer, replace only if much better
MIN_SCORE_DROP_TO_EXIT = 40              # Exit only if score drops 40+ points (optimized from plateau test)
MIN_SCORE_GAIN_TO_ENTER = 40             # New stock must be 40+ points better to replace
HOLD_IF_STILL_LEADING = True             # Keep stock if still in Leading quadrant with decent score

# Portfolio Diversification (CRITICAL - Prevent Concentration Risk)
MIN_PORTFOLIO_STOCKS = 5                 # Never hold fewer than 5 stocks (safety requirement)
ADAPTIVE_PERSISTENCE = True              # Relax persistence rules when portfolio is small

# Exit Strategy (Multi-Layer Protection)
USE_DYNAMIC_EXIT = True                  # Exit stocks that move to Weakening quadrant
EXIT_ON_QUADRANT_CHANGE = True           # Exit if quadrant changes from Leading/Improving

# Fortnightly Stop Loss Monitoring (NEW - Reduce Drawdowns)
USE_STOP_LOSS_MONITORING = True          # Monitor stops between quarters
STOP_MONITORING_FREQUENCY = 'fortnightly'  # 'weekly' or 'fortnightly'
STOCK_STOP_LOSS_PCT = 0.15               # Exit individual stock if down 15% from entry
PORTFOLIO_STOP_LOSS_PCT = None           # Exit ALL stocks if portfolio down 10% from peak
USE_VIX_CIRCUIT_BREAKER = True           # Exit all if market panic (high volatility)
VIX_THRESHOLD = 30                       # Exit all if Nifty volatility suggests VIX > 30

# Market Regime Filter (Entry Protection)
USE_MARKET_REGIME_FILTER = True          # Check market health before entering
NIFTY_SMA_PERIOD = 200                   # 200-day moving average
MIN_MARKET_STRENGTH = 2                  # Need 2/3 conditions to enter full portfolio

# =============================================================================
# YAMADA FRAMEWORK - VALIDATION TESTS
# =============================================================================
# USER FEEDBACK: 40-point persistence might be a PEAK, not PLATEAU
# Need finer-grained testing around 40 (test 35, 37, 40, 43, 45, 50)
RUN_RANDOM_CONTROL_TEST = False          # ✅ PASSED (z=3.53, EXCEPTIONAL)
RUN_PLATEAU_TEST = False                 # ✅ PASSED (40 is on PLATEAU: 40-45 identical at 71.04%)
TEST_SCORE_THRESHOLDS = False            # Skip - no longer using score filters
TEST_STOP_LOSSES = False                 # Already validated (6.20% range - PASS)
TEST_PERSISTENCE = False                 # ✅ PASSED (1.89% range 30-50, 0.00% range 40-45)
TEST_REBALANCE_FREQUENCY = False         # Already validated - quarterly wins
RUN_DELAYED_ENTRY_TEST = False           # ✅ PASSED (2.05% alpha decay, EXCELLENT)

# =============================================================================
# YAMADA FRAMEWORK - OUTLIER DEPENDENCY TEST (LUCK vs SKILL)
# =============================================================================
# Tests if CAGR depends on rare lucky trades (e.g., ANANTRAJ +1196%)
# Critical for small sample sizes (48 trades)
RUN_OUTLIER_TEST = False                  # Test if strategy relies on outliers
OUTLIER_PERCENTILE = 5                   # Remove top/bottom 5% of trades

# PRODUCTION SETTINGS (VALIDATED & OPTIMIZED)
ENTRY_DELAY_DAYS = 7                     # ⭐ OPTIMAL: 7-day delay gives 71.04% CAGR (best performance)

# Output Configuration
OUTPUT_DIR = 'rrg_backtest_results'
CREATE_MONTHLY_PORTFOLIO_CSV = True
CREATE_RETURNS_CSV = True
CREATE_METRICS_CSV = True
CREATE_PLOTS = True

# Cache Configuration
CACHE_DIR = 'cache'
CACHE_EXPIRY_HOURS = 24

# Rate Limiting
API_CALL_DELAY = 0.1
MAX_RETRIES = 3
RETRY_DELAY = 5

# Data File (RRG universe)
DATA_FILE_PATH = 'data\\nifty500.csv'  # Path from F4/RRG folder to workspace root
SYMBOL_COLUMN = 'symbol'
SECTOR_COLUMN = 'Level_4'

# =============================================================================

class RRGBacktester:
    """
    RRG-based monthly rotation backtester
    """
    
    def __init__(self, api_key, access_token):
        """Initialize backtester"""
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Setup directories
        os.makedirs(CACHE_DIR, exist_ok=True)
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        
        self.instruments_cache_file = os.path.join(CACHE_DIR, 'instruments.json')
        self.instruments_cache = self._load_instruments_cache()
        
        # Storage for backtest results
        self.monthly_results = []
        self.monthly_portfolios = []
        self.trade_log = []  # Track individual trades with entry/exit
        self.cooldown_stocks = {}  # Track stocks in cooldown: {symbol: exit_date}
        
        print("="*80)
        print("🔬 RRG MOMENTUM BACKTESTER")
        print("="*80)
        print(f"📅 Period: {BACKTEST_START_DATE} to {BACKTEST_END_DATE}")
        print(f"💼 Portfolio: Top {PORTFOLIO_SIZE} by RRG Opportunity Score")
        print(f"💰 Initial Capital: ₹{INITIAL_CAPITAL:,.0f}")
        print(f"💸 Transaction Costs (REALISTIC ZERODHA):")
        print(f"   • Statutory (STT, Stamp, DP, etc): {STATUTORY_COSTS_PCT*100:.3f}%")
        print(f"   • Market Impact & Slippage: {(MARKET_IMPACT_PCT + BID_ASK_SPREAD_PCT + SLIPPAGE_PCT)*100:.2f}%")
        print(f"   • Total Per Round Trip: {TOTAL_COST_PER_TRADE*100:.2f}% (Buy + Sell)")
        print(f"📊 Benchmark: {BENCHMARK_INDEX}")
        print(f"⚖️  Position Sizing: Equal Weight ({100/PORTFOLIO_SIZE:.2f}% each)")
        print(f"\n🛡️  STRATEGY FILTERS ENABLED:")
        print(f"   • Score Range: {MIN_SCORE_THRESHOLD} - {MAX_SCORE_THRESHOLD} (avoid overbought)")
        print(f"   • Excluded Sectors: {len(EXCLUDE_SECTORS)} (poor historical performance)")
        print(f"   • Cooldown Period: {COOLDOWN_MONTHS} months (prevent re-entering losers)")
        print(f"   • Min Portfolio Size: {MIN_PORTFOLIO_STOCKS} stocks (prevent concentration)")
        print(f"   • Adaptive Persistence: {'Enabled' if ADAPTIVE_PERSISTENCE else 'Disabled'} (relax when < {MIN_PORTFOLIO_STOCKS} stocks)")
        print(f"   • Dynamic Exit: {'Enabled' if USE_DYNAMIC_EXIT else 'Disabled'} (exit on quadrant change)")
        if USE_QUALITY_FILTERS:
            print(f"\n🔬 QUALITY FILTERS ENABLED (TESTING):")
            print(f"   • STRONG BUY: {'Required' if REQUIRE_STRONG_BUY else 'Optional'}")
            print(f"   • Excellent Momentum: {'Required' if REQUIRE_EXCELLENT_MOMENTUM else 'Optional'}")
            print(f"   • Excellent Tail: {'Required' if REQUIRE_EXCELLENT_TAIL else 'Optional'}")
        print("="*80)
    
    # =========================================================================
    # INFRASTRUCTURE
    # =========================================================================
    
    def _load_instruments_cache(self) -> List[Dict]:
        """Load instruments from cache"""
        try:
            if os.path.exists(self.instruments_cache_file):
                with open(self.instruments_cache_file, 'r') as f:
                    cache_data = json.load(f)
                cache_time = datetime.fromisoformat(cache_data.get('timestamp', '2000-01-01'))
                if (datetime.now() - cache_time).total_seconds() < CACHE_EXPIRY_HOURS * 3600:
                    return cache_data.get('instruments', [])
        except:
            pass
        return []
    
    def _save_instruments_cache(self, instruments: List[Dict]):
        """Save instruments to cache"""
        try:
            with open(self.instruments_cache_file, 'w') as f:
                json.dump({
                    'timestamp': datetime.now().isoformat(),
                    'instruments': instruments
                }, f)
        except:
            pass
    
    def _rate_limit_delay(self):
        time.sleep(API_CALL_DELAY)
    
    def _api_call_with_retry(self, func, *args, **kwargs):
        """API call with retry logic"""
        for attempt in range(MAX_RETRIES):
            try:
                self._rate_limit_delay()
                return func(*args, **kwargs)
            except Exception as e:
                if "Too many requests" in str(e) or "rate limit" in str(e).lower():
                    if attempt < MAX_RETRIES - 1:
                        time.sleep(RETRY_DELAY * (attempt + 1))
                        continue
                raise e
        return None
    
    def get_instrument_token(self, tradingsymbol):
        """Get instrument token"""
        try:
            if self.instruments_cache:
                instrument = next((item for item in self.instruments_cache 
                                 if item['tradingsymbol'] == tradingsymbol), None)
                if instrument:
                    return instrument['instrument_token']
            
            instruments = self._api_call_with_retry(self.kite.instruments, "NSE")
            if instruments:
                self._save_instruments_cache(instruments)
                self.instruments_cache = instruments
                instrument = next((item for item in instruments 
                                 if item['tradingsymbol'] == tradingsymbol), None)
                return instrument['instrument_token'] if instrument else None
            return None
        except:
            return None
    
    def get_historical_data(self, instrument_token, from_date, to_date, interval='week'):
        """Fetch historical data"""
        try:
            data = self._api_call_with_retry(
                self.kite.historical_data,
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            if data is None:
                return pd.DataFrame()
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date'])
                # Remove timezone info
                if df['date'].dt.tz is not None:
                    df['date'] = df['date'].dt.tz_localize(None)
                df.set_index('date', inplace=True)
            return df
        except:
            return pd.DataFrame()
    
    # =========================================================================
    # RRG CALCULATIONS (from RRG.py)
    # =========================================================================
    
    def calculate_relative_strength(self, stock_data, benchmark_data):
        """Calculate relative strength ratio vs benchmark"""
        # Ensure both datasets have same index
        common_dates = stock_data.index.intersection(benchmark_data.index)
        if len(common_dates) == 0:
            return pd.Series()
        
        stock_aligned = stock_data.loc[common_dates, 'close']
        benchmark_aligned = benchmark_data.loc[common_dates, 'close']
        
        # Calculate RS ratio (normalize to 100)
        rs_ratio = (stock_aligned / benchmark_aligned) * 100
        if len(rs_ratio) > 0 and rs_ratio.iloc[0] != 0:
            rs_ratio = rs_ratio / rs_ratio.iloc[0] * 100  # Normalize to start at 100
        
        return rs_ratio
    
    def calculate_rs_momentum(self, rs_ratio, period=5):
        """Calculate RS momentum (rate of change of RS)"""
        if len(rs_ratio) < period:
            return pd.Series()
        rs_momentum = rs_ratio.pct_change(period) * 100 + 100
        return rs_momentum
    
    def get_quadrant(self, rs_ratio, rs_momentum, benchmark_rs=100, benchmark_momentum=100):
        """Determine which quadrant a security is in"""
        if rs_ratio >= benchmark_rs and rs_momentum >= benchmark_momentum:
            return 'Leading'
        elif rs_ratio < benchmark_rs and rs_momentum >= benchmark_momentum:
            return 'Weakening'
        elif rs_ratio < benchmark_rs and rs_momentum < benchmark_momentum:
            return 'Lagging'
        else:  # rs_ratio >= benchmark_rs and rs_momentum < benchmark_momentum
            return 'Improving'
    
    def calculate_tail_angle_and_velocity(self, tail_rs, tail_momentum):
        """Calculate tail angle and velocity factor"""
        if not isinstance(tail_rs, list) or len(tail_rs) < 3:
            return 0.0, 0.0, 'Unknown'
        
        try:
            # Calculate deltas for last 3 points
            delta_rs = tail_rs[-1] - tail_rs[-3]
            delta_momentum = tail_momentum[-1] - tail_momentum[-3]
            
            # Calculate angle
            angle_radians = math.atan2(delta_momentum, delta_rs)
            angle_degrees = math.degrees(angle_radians)
            
            if angle_degrees < 0:
                angle_degrees += 360
            
            # Calculate velocity
            velocity = math.sqrt(delta_rs**2 + delta_momentum**2)
            
            # Determine movement direction
            if 0 <= angle_degrees <= 90:
                direction = 'Toward Leading'
            elif 90 < angle_degrees <= 180:
                direction = 'Toward Weakening'
            elif 180 < angle_degrees <= 270:
                direction = 'Toward Lagging'
            else:
                direction = 'Toward Improving'
            
            return angle_degrees, velocity, direction
        except:
            return 0.0, 0.0, 'Unknown'
    
    def calculate_opportunity_score(self, row):
        """Calculate RRG opportunity score (from RRG.py logic)"""
        weights = SCORING_WEIGHTS
        score = 0.0
        
        # Base quadrant score
        quadrant_scores = weights['quadrant_scores']
        score += quadrant_scores.get(row['Quadrant'], 0)
        
        # RS ratio bonus
        score += row['RS_Ratio'] * weights['rs_ratio_multiplier']
        
        # Momentum bonus
        score += row['RS_Momentum'] * weights['momentum_multiplier']
        
        # Distance from center bonus
        score += row['Distance_from_Center'] * weights['distance_multiplier']
        
        # Movement bonuses
        movement_bonuses = weights['movement_bonuses']
        if row['Movement_Direction'] == 'Toward Leading':
            score += movement_bonuses['toward_leading']
        elif row['Movement_Direction'] == 'Toward Improving':
            score += movement_bonuses['toward_improving']
        elif row['Movement_Direction'] == 'Toward Lagging':
            score += movement_bonuses['toward_lagging_penalty']
        
        # Velocity bonus
        if row['Velocity_Factor'] > 0:
            velocity_bonus = min(row['Velocity_Factor'] / 10, 1.0) * weights['velocity_max_bonus']
            score += velocity_bonus
        
        return max(0, score)  # No negative scores
    
    def calculate_momentum_quality(self, velocity_factor, movement_direction):
        """Calculate momentum quality based on velocity and direction"""
        if movement_direction == 'Toward Leading' and velocity_factor > 5:
            return 'Excellent'
        elif movement_direction == 'Toward Leading' and velocity_factor > 2:
            return 'Good'
        elif movement_direction == 'Toward Improving' and velocity_factor > 3:
            return 'Good'
        elif velocity_factor > 1:
            return 'Fair'
        else:
            return 'Poor'
    
    def calculate_tail_quality(self, tail_rs, tail_momentum):
        """Calculate tail quality based on path smoothness"""
        if not isinstance(tail_rs, list) or len(tail_rs) < 3:
            return 'Poor'
        
        try:
            # Calculate path volatility (how smooth is the tail)
            rs_changes = [abs(tail_rs[i] - tail_rs[i-1]) for i in range(1, len(tail_rs))]
            mom_changes = [abs(tail_momentum[i] - tail_momentum[i-1]) for i in range(1, len(tail_momentum))]
            path_volatility = (sum(rs_changes) + sum(mom_changes)) / (len(rs_changes) + len(mom_changes))
            
            # Excellent: Smooth trajectory, no erratic moves
            if path_volatility < 8:
                return 'Excellent'
            elif path_volatility < 12:
                return 'Good'
            elif path_volatility < 18:
                return 'Fair'
            else:
                return 'Poor'
        except:
            return 'Fair'
    
    def calculate_recommendation(self, row):
        """Calculate recommendation based on multiple factors (matches RRG.py format)"""
        score = row['Opportunity_Score']
        quadrant = row['Quadrant']
        momentum_quality = row.get('Momentum_Quality', 'Fair')
        tail_quality = row.get('Tail_Quality', 'Fair')
        distance = row['Distance_from_Center']
        risk_level = 'Low' if distance < 15 else 'Medium' if distance < 25 else 'High'
        
        # STRONG BUY conditions (return full strings to match RRG.py)
        if quadrant == 'Leading':
            if score >= 200 and risk_level == 'Low' and tail_quality in ['Excellent', 'Good']:
                return 'STRONG BUY - High conviction long position'
            elif score >= 200 and risk_level == 'Medium':
                return 'BUY - Strong but monitor for reversal'
            elif score >= 150:
                return 'BUY - Good opportunity with moderate risk'
        elif quadrant == 'Improving':
            if score >= 150 and tail_quality == 'Excellent' and momentum_quality in ['Excellent', 'Good']:
                return 'STRONG BUY - Early reversal with quality setup'
            elif score >= 100:
                return 'BUY - Improving momentum, watch for confirmation'
        elif quadrant == 'Weakening':
            return 'HOLD/WATCH - Momentum fading'
        else:  # Lagging
            return 'AVOID - Weak relative performance'
        
        return 'BUY - Good opportunity with moderate risk'
    
    def run_rrg_analysis(self, stocks_data: Dict, benchmark_data: pd.DataFrame, 
                         as_of_date: datetime) -> pd.DataFrame:
        """
        Run full RRG analysis on all stocks as of specific date
        Returns DataFrame with RRG metrics and Opportunity_Score
        """
        results = []
        
        # Filter benchmark data to as_of_date
        benchmark_filtered = benchmark_data[benchmark_data.index <= as_of_date]
        
        if benchmark_filtered.empty or len(benchmark_filtered) < WEEKS_BACK:
            return pd.DataFrame()
        
        for symbol, stock_info in stocks_data.items():
            try:
                stock_data = stock_info['data']
                sector = stock_info.get('sector', 'Unknown')
                
                # Filter to as_of_date
                stock_filtered = stock_data[stock_data.index <= as_of_date]
                
                if stock_filtered.empty or len(stock_filtered) < WEEKS_BACK:
                    continue
                
                # Calculate RS ratio and momentum
                rs_ratio = self.calculate_relative_strength(stock_filtered, benchmark_filtered)
                rs_momentum = self.calculate_rs_momentum(rs_ratio, MOMENTUM_PERIOD)
                
                if rs_ratio.empty or rs_momentum.empty:
                    continue
                
                # Get latest values
                current_rs = rs_ratio.iloc[-1]
                current_momentum = rs_momentum.iloc[-1]
                
                # Determine quadrant
                quadrant = self.get_quadrant(current_rs, current_momentum)
                
                # Calculate tail data
                tail_length = min(TAIL_LENGTH, len(rs_ratio))
                tail_rs = rs_ratio.iloc[-tail_length:].tolist()
                tail_momentum = rs_momentum.iloc[-tail_length:].tolist()
                
                # Calculate tail angle and velocity
                tail_angle, velocity_factor, movement_direction = \
                    self.calculate_tail_angle_and_velocity(tail_rs, tail_momentum)
                
                # Distance from center
                distance = np.sqrt((current_rs - 100)**2 + (current_momentum - 100)**2)
                
                # Calculate quality metrics (NEW)
                momentum_quality = self.calculate_momentum_quality(velocity_factor, movement_direction)
                tail_quality = self.calculate_tail_quality(tail_rs, tail_momentum)
                
                result_row = {
                    'Symbol': symbol,
                    'Sector': sector,
                    'RS_Ratio': current_rs,
                    'RS_Momentum': current_momentum,
                    'Quadrant': quadrant,
                    'Distance_from_Center': distance,
                    'Tail_Angle': tail_angle,
                    'Velocity_Factor': velocity_factor,
                    'Movement_Direction': movement_direction,
                    'Current_Price': stock_filtered['close'].iloc[-1],
                    'Momentum_Quality': momentum_quality,
                    'Tail_Quality': tail_quality
                }
                
                results.append(result_row)
                
            except Exception as e:
                continue
        
        if not results:
            return pd.DataFrame()
        
        # Create DataFrame
        rrg_df = pd.DataFrame(results)
        
        # Calculate Opportunity Score
        rrg_df['Opportunity_Score'] = rrg_df.apply(self.calculate_opportunity_score, axis=1)
        
        # Calculate Recommendation (NEW - uses Opportunity_Score, so must come after)
        rrg_df['Recommendation'] = rrg_df.apply(self.calculate_recommendation, axis=1)
        
        # Sort by Opportunity Score
        rrg_df = rrg_df.sort_values('Opportunity_Score', ascending=False)
        
        return rrg_df
    
    # =========================================================================
    # PORTFOLIO CONSTRUCTION & REBALANCING
    # =========================================================================
    
    def generate_rebalance_dates(self) -> List[datetime]:
        """Generate rebalancing dates (monthly or quarterly)"""
        start = datetime.strptime(BACKTEST_START_DATE, "%Y-%m-%d")
        end = datetime.strptime(BACKTEST_END_DATE, "%Y-%m-%d")
        
        rebalance_dates = []
        current = start.replace(day=1)
        
        if REBALANCE_FREQUENCY == 'quarterly':
            # Quarterly: End of Mar, Jun, Sep, Dec
            quarter_months = [3, 6, 9, 12]  # March, June, September, December
            
            for year in range(start.year, end.year + 1):
                for qm in quarter_months:
                    # Create quarter end date
                    try:
                        quarter_start = datetime(year, qm, 1)
                        next_month = quarter_start + relativedelta(months=1)
                        quarter_end = next_month - timedelta(days=1)
                        
                        # Check if within backtest period
                        if start <= quarter_end <= end:
                            rebalance_dates.append(quarter_end)
                    except:
                        continue
        else:
            # Monthly
            while current <= end:
                next_month = current + relativedelta(months=1)
                month_end = next_month - timedelta(days=1)
                
                if month_end <= end:
                    rebalance_dates.append(month_end)
                
                current = next_month
        
        return rebalance_dates
    
    def generate_monitoring_dates(self, start_date: datetime, end_date: datetime) -> List[datetime]:
        """Generate fortnightly dates for stop loss monitoring"""
        monitoring_dates = []
        current = start_date
        
        if STOP_MONITORING_FREQUENCY == 'weekly':
            delta = timedelta(weeks=1)
        else:  # fortnightly
            delta = timedelta(weeks=2)
        
        while current <= end_date:
            monitoring_dates.append(current)
            current += delta
        
        return monitoring_dates
    
    def check_market_regime(self, benchmark_data_daily: pd.DataFrame, 
                           current_date: datetime) -> Dict:
        """Check market health before entering positions"""
        try:
            data = benchmark_data_daily[benchmark_data_daily.index <= current_date]
            
            if len(data) < NIFTY_SMA_PERIOD:
                return {
                    'regime': 'UNKNOWN', 
                    'score': 0, 
                    'enter_full': True,
                    'above_sma': True,
                    'recent_positive': True,
                    'vol_ok': True,
                    'current_price': data['close'].iloc[-1] if not data.empty else 0,
                    'sma_200': 0,
                    'volatility': 0
                }
            
            # Calculate 200-day SMA
            sma_200 = data['close'].rolling(NIFTY_SMA_PERIOD).mean().iloc[-1]
            current_price = data['close'].iloc[-1]
            
            # Condition 1: Price > 200 SMA
            above_sma = current_price > sma_200
            
            # Condition 2: Last 20 days positive
            last_20_return = (data['close'].iloc[-1] / data['close'].iloc[-20] - 1) if len(data) >= 20 else 0
            recent_positive = last_20_return > 0
            
            # Condition 3: Volatility not elevated
            returns = data['close'].pct_change().dropna()
            current_vol = returns.iloc[-20:].std() * np.sqrt(252) * 100 if len(returns) >= 20 else 50
            avg_vol = returns.iloc[-60:].std() * np.sqrt(252) * 100 if len(returns) >= 60 else 50
            vol_ok = current_vol < avg_vol * 1.5
            
            # Count conditions met
            conditions_met = sum([above_sma, recent_positive, vol_ok])
            
            # Determine action
            if conditions_met >= MIN_MARKET_STRENGTH:
                regime = 'BULLISH'
                enter_full = True
            elif conditions_met == 1:
                regime = 'NEUTRAL'
                enter_full = False  # Enter only 5 stocks
            else:
                regime = 'BEARISH'
                enter_full = False  # Skip entry
            
            return {
                'regime': regime,
                'score': conditions_met,
                'enter_full': enter_full,
                'above_sma': above_sma,
                'recent_positive': recent_positive,
                'vol_ok': vol_ok,
                'current_price': round(current_price, 2),
                'sma_200': round(sma_200, 2),
                'volatility': round(current_vol, 2)
            }
        except Exception as e:
            return {
                'regime': 'UNKNOWN', 
                'score': 0, 
                'enter_full': True,
                'above_sma': True,
                'recent_positive': True,
                'vol_ok': True,
                'current_price': 0,
                'sma_200': 0,
                'volatility': 0
            }
    
    def check_stops(self, current_positions: Dict, stocks_data: Dict, 
                   monitoring_date: datetime, portfolio_peak: float,
                   portfolio_value: float) -> Tuple[List[str], bool]:
        """
        Check stop losses - returns (stocks_to_exit, exit_all_flag)
        """
        stocks_to_exit = []
        exit_all = False
        
        # Check 1: Individual stock stops
        for symbol, entry_info in current_positions.items():
            if symbol not in stocks_data:
                continue
            
            stock_data = stocks_data[symbol].get('data_daily', stocks_data[symbol]['data'])
            current_data = stock_data[stock_data.index <= monitoring_date]
            
            if current_data.empty:
                continue
            
            current_price = current_data['close'].iloc[-1]
            entry_price = entry_info['entry_price']
            
            loss_pct = (current_price / entry_price - 1)
            
            if loss_pct <= -STOCK_STOP_LOSS_PCT:
                stocks_to_exit.append(symbol)
        
        # Check 2: Portfolio-level stop (skip if disabled)
        if PORTFOLIO_STOP_LOSS_PCT is not None:
            portfolio_drawdown = (portfolio_value - portfolio_peak) / portfolio_peak
            if portfolio_drawdown <= -PORTFOLIO_STOP_LOSS_PCT:
                exit_all = True
        
        # Check 3: VIX circuit breaker (use Nifty volatility as proxy)
        if USE_VIX_CIRCUIT_BREAKER:
            # Calculate recent volatility
            # If we have benchmark data, use it
            # Simple approximation: if Nifty down >3% in last 5 days = high VIX
            pass  # Implement if needed
        
        return stocks_to_exit, exit_all
    
    def select_top_15(self, rrg_results: pd.DataFrame, current_date: datetime, 
                     current_positions: Dict = None, target_size: int = None) -> pd.DataFrame:
        """Select top N stocks with persistence logic to reduce turnover"""
        if rrg_results.empty:
            return pd.DataFrame()
        
        # Use target_size if provided (for regime-adjusted sizing), otherwise use default
        portfolio_size = target_size if target_size is not None else PORTFOLIO_SIZE
        
        # Filter 1: Remove excluded sectors
        filtered = rrg_results[~rrg_results['Sector'].isin(EXCLUDE_SECTORS)].copy()
        print(f"      After sector filter: {len(filtered)} stocks")
        
        # Filter 2: Score range filter (avoid overbought)
        filtered = filtered[
            (filtered['Opportunity_Score'] >= MIN_SCORE_THRESHOLD) & 
            (filtered['Opportunity_Score'] <= MAX_SCORE_THRESHOLD)
        ]
        print(f"      After score filter ({MIN_SCORE_THRESHOLD}-{MAX_SCORE_THRESHOLD}): {len(filtered)} stocks")
        
        # Filter 3: Cooldown period (don't re-enter recent losers)
        if self.cooldown_stocks:
            filtered = filtered[~filtered['Symbol'].apply(
                lambda s: self._is_in_cooldown(s, current_date)
            )]
            print(f"      After cooldown filter: {len(filtered)} stocks")
        
        # Filter 4: Quality filters (NEW - TEST IF THESE IMPROVE PERFORMANCE)
        if USE_QUALITY_FILTERS:
            initial_count = len(filtered)
            
            if REQUIRE_STRONG_BUY:
                # Match any recommendation starting with "STRONG BUY"
                filtered = filtered[filtered['Recommendation'].str.startswith('STRONG BUY', na=False)]
                print(f"      After STRONG BUY filter: {initial_count} → {len(filtered)} stocks")
                initial_count = len(filtered)
            
            if REQUIRE_EXCELLENT_MOMENTUM:
                filtered = filtered[filtered['Momentum_Quality'] == 'Excellent']
                print(f"      After Excellent Momentum filter: {initial_count} → {len(filtered)} stocks")
                initial_count = len(filtered)
            
            if REQUIRE_EXCELLENT_TAIL:
                filtered = filtered[filtered['Tail_Quality'] == 'Excellent']
                print(f"      After Excellent Tail filter: {initial_count} → {len(filtered)} stocks")
        
        if filtered.empty:
            return pd.DataFrame()
        
        # =================================================================
        # RANDOM CONTROL TEST MODE
        # =================================================================
        # If in random mode, bypass all scoring logic and select randomly
        if 'STRATEGY_MODE' in globals() and STRATEGY_MODE == 'random':
            import random
            random.seed(RANDOM_SEED + int(current_date.timestamp()))  # Unique seed per date
            
            # Select random stocks from filtered candidates
            available_stocks = filtered['Symbol'].tolist()
            num_to_select = min(portfolio_size, len(available_stocks))
            selected_symbols = random.sample(available_stocks, num_to_select)
            
            random_portfolio = filtered[filtered['Symbol'].isin(selected_symbols)]
            print(f"      🎲 RANDOM MODE: Selected {len(random_portfolio)} random stocks")
            return random_portfolio
        
        # =================================================================
        # NORMAL RRG STRATEGY MODE (PERSISTENCE LOGIC)
        # =================================================================
        # PERSISTENCE LOGIC: Check existing positions first
        held_stocks = []
        if USE_PERSISTENCE_LOGIC and current_positions:
            for symbol, entry_info in current_positions.items():
                # Check if stock is in current RRG results
                if symbol in filtered['Symbol'].values:
                    stock_row = filtered[filtered['Symbol'] == symbol].iloc[0]
                    current_score = stock_row['Opportunity_Score']
                    entry_score = entry_info['entry_score']
                    current_quadrant = stock_row['Quadrant']
                    
                    # HOLD if:
                    # 1. Still in Leading/Improving quadrant
                    # 2. Score hasn't dropped too much from entry
                    # 3. Score is still decent (above 180)
                    score_drop = entry_score - current_score
                    
                    should_hold = False
                    if HOLD_IF_STILL_LEADING and current_quadrant in ['Leading', 'Improving']:
                        if score_drop < MIN_SCORE_DROP_TO_EXIT and current_score >= 180:
                            should_hold = True
                            held_stocks.append(stock_row)
            
            if held_stocks:
                held_df = pd.DataFrame(held_stocks)
                print(f"      🔒 Holding {len(held_df)} existing positions (persistence logic)")
        
        # Calculate how many new stocks to add
        remaining_slots = portfolio_size - len(held_stocks)
        
        if remaining_slots <= 0:
            return pd.DataFrame(held_stocks) if held_stocks else filtered.head(portfolio_size)
        
        # Get candidates for new positions (exclude held stocks)
        if held_stocks:
            held_symbols = [s['Symbol'] for s in held_stocks]
            candidates = filtered[~filtered['Symbol'].isin(held_symbols)]
        else:
            candidates = filtered
        
        # Strategy: Prefer Leading quadrant
        if PREFER_LEADING_QUADRANT:
            leading_stocks = candidates[candidates['Quadrant'] == 'Leading'].head(remaining_slots)
            
            if len(leading_stocks) < remaining_slots:
                remaining = remaining_slots - len(leading_stocks)
                improving_stocks = candidates[
                    (candidates['Quadrant'] == 'Improving') & 
                    (~candidates['Symbol'].isin(leading_stocks['Symbol']))
                ].head(remaining)
                new_stocks = pd.concat([leading_stocks, improving_stocks])
            else:
                new_stocks = leading_stocks
        else:
            new_stocks = candidates.head(remaining_slots)
        
        # Apply MIN_SCORE_GAIN_TO_ENTER filter (with adaptive threshold)
        if USE_PERSISTENCE_LOGIC and held_stocks:
            # ADAPTIVE: Relax threshold if portfolio is small (prevent concentration)
            if ADAPTIVE_PERSISTENCE and len(held_stocks) < MIN_PORTFOLIO_STOCKS:
                score_gain_threshold = 20  # Relaxed threshold (easier to add stocks)
                print(f"      ⚡ Portfolio < {MIN_PORTFOLIO_STOCKS} stocks - using relaxed threshold ({score_gain_threshold} points)")
            else:
                score_gain_threshold = MIN_SCORE_GAIN_TO_ENTER
            
            # Only add new stocks if they're significantly better than weakest held stock
            if not new_stocks.empty and len(held_stocks) > 0:
                min_held_score = min(s['Opportunity_Score'] for s in held_stocks)
                new_stocks = new_stocks[new_stocks['Opportunity_Score'] >= min_held_score + score_gain_threshold]
                print(f"      ⚡ Added {len(new_stocks)} new positions (must be {score_gain_threshold}+ points better)")
        
        # Combine held and new stocks
        if held_stocks:
            final_portfolio = pd.concat([pd.DataFrame(held_stocks), new_stocks]).sort_values('Opportunity_Score', ascending=False)
        else:
            final_portfolio = new_stocks
        
        # Ensure we have exactly target portfolio_size (or less if not enough candidates)
        final_portfolio = final_portfolio.head(portfolio_size)
        
        # CRITICAL SAFETY: Enforce minimum portfolio size
        if len(final_portfolio) < MIN_PORTFOLIO_STOCKS and len(candidates) >= MIN_PORTFOLIO_STOCKS:
            print(f"      ⚠️  Portfolio < {MIN_PORTFOLIO_STOCKS} stocks - adding more for safety")
            
            # Calculate how many more we need
            needed = MIN_PORTFOLIO_STOCKS - len(final_portfolio)
            
            # Get additional stocks from candidates (ignore persistence threshold)
            already_selected = final_portfolio['Symbol'].tolist()
            additional_candidates = candidates[~candidates['Symbol'].isin(already_selected)]
            
            if not additional_candidates.empty:
                additional_stocks = additional_candidates.head(needed)
                final_portfolio = pd.concat([final_portfolio, additional_stocks]).sort_values('Opportunity_Score', ascending=False)
                print(f"      ✅ Added {len(additional_stocks)} stocks to meet minimum ({len(final_portfolio)} total)")
        
        print(f"      Final portfolio: {len(held_stocks)} held + {len(new_stocks)} new = {len(final_portfolio)} total")
        
        return final_portfolio
    
    def _is_in_cooldown(self, symbol: str, current_date: datetime) -> bool:
        """Check if stock is in cooldown period"""
        if symbol not in self.cooldown_stocks:
            return False
        
        exit_date = self.cooldown_stocks[symbol]
        months_since_exit = (current_date.year - exit_date.year) * 12 + (current_date.month - exit_date.month)
        
        return months_since_exit < COOLDOWN_MONTHS
    
    def calculate_turnover(self, old_portfolio: Dict, new_portfolio: Dict) -> float:
        """Calculate portfolio turnover"""
        if not old_portfolio:
            return 1.0  # First month is 100% turnover
        
        all_symbols = set(old_portfolio.keys()) | set(new_portfolio.keys())
        turnover = 0.0
        
        for symbol in all_symbols:
            old_weight = old_portfolio.get(symbol, 0.0)
            new_weight = new_portfolio.get(symbol, 0.0)
            turnover += abs(new_weight - old_weight)
        
        return turnover / 2.0
    
    # =========================================================================
    # RETURN CALCULATIONS
    # =========================================================================
    
    def calculate_next_month_return(self, portfolio_weights: Dict[str, float],
                                    stocks_data: Dict, current_month_end: datetime,
                                    next_month_end: datetime) -> Dict:
        """Calculate portfolio return for the next period using daily data"""
        stock_returns = {}
        
        for symbol, weight in portfolio_weights.items():
            if symbol not in stocks_data:
                stock_returns[symbol] = 0.0
                continue
            
            # Use daily data for accurate return calculation
            stock_data = stocks_data[symbol].get('data_daily', stocks_data[symbol]['data'])
            
            # Get price at current month end (entry price)
            current_data = stock_data[stock_data.index <= current_month_end]
            if current_data.empty:
                stock_returns[symbol] = 0.0
                continue
            entry_price = current_data['close'].iloc[-1]
            
            # Get price at next month end (exit price)
            next_data = stock_data[(stock_data.index > current_month_end) & 
                                   (stock_data.index <= next_month_end)]
            if next_data.empty:
                future_data = stock_data[stock_data.index > current_month_end]
                if future_data.empty:
                    stock_returns[symbol] = 0.0
                    continue
                exit_price = future_data['close'].iloc[0]
            else:
                exit_price = next_data['close'].iloc[-1]
            
            # Calculate return
            ret = (exit_price / entry_price) - 1
            stock_returns[symbol] = ret
        
        # Calculate portfolio return
        portfolio_return = sum(stock_returns[symbol] * weight 
                             for symbol, weight in portfolio_weights.items())
        
        return {
            'portfolio_return': portfolio_return,
            'stock_returns': stock_returns
        }
    
    def calculate_benchmark_return(self, benchmark_data: pd.DataFrame,
                                   current_month_end: datetime,
                                   next_month_end: datetime) -> float:
        """Calculate benchmark return for the period"""
        try:
            current_data = benchmark_data[benchmark_data.index <= current_month_end]
            if current_data.empty:
                print(f"      ⚠️ Benchmark: No data at entry {current_month_end.strftime('%Y-%m-%d')}")
                return 0.0
            entry_price = current_data['close'].iloc[-1]
            entry_date = current_data.index[-1]
            
            next_data = benchmark_data[(benchmark_data.index > current_month_end) & 
                                      (benchmark_data.index <= next_month_end)]
            if next_data.empty:
                future_data = benchmark_data[benchmark_data.index > current_month_end]
                if future_data.empty:
                    print(f"      ⚠️ Benchmark: No data at exit {next_month_end.strftime('%Y-%m-%d')}")
                    return 0.0
                exit_price = future_data['close'].iloc[0]
                exit_date = future_data.index[0]
            else:
                exit_price = next_data['close'].iloc[-1]
                exit_date = next_data.index[-1]
            
            ret = (exit_price / entry_price) - 1
            # Debug print for benchmark (disabled after verification)
            # print(f"      📊 Benchmark: {entry_date.strftime('%Y-%m-%d')} ₹{entry_price:.2f} → "
            #       f"{exit_date.strftime('%Y-%m-%d')} ₹{exit_price:.2f} = {ret*100:.2f}%")
            
            return ret
        except Exception as e:
            print(f"      ⚠️ Benchmark calc error: {e}")
            return 0.0
    
    # =========================================================================
    # MAIN BACKTEST ENGINE
    # =========================================================================
    
    def load_backtest_data(self, universe_df: pd.DataFrame) -> Tuple[Dict, pd.DataFrame, pd.DataFrame]:
        """
        Load all historical data for backtesting (CACHED for reuse)
        Returns: (stocks_data, benchmark_data, benchmark_data_daily)
        """
        print(f"\n📥 Loading historical data for {len(universe_df)} stocks...")
        
        start_date = datetime.strptime(BACKTEST_START_DATE, "%Y-%m-%d") - timedelta(weeks=WEEKS_BACK * 2)
        end_date = datetime.strptime(BACKTEST_END_DATE, "%Y-%m-%d")
        
        stocks_data = {}
        
        for idx, row in universe_df.iterrows():
            symbol = row[SYMBOL_COLUMN]
            sector = row[SECTOR_COLUMN]
            
            try:
                token = self.get_instrument_token(symbol)
                if not token:
                    continue
                
                # Weekly data for RRG analysis
                data_weekly = self.get_historical_data(token, start_date, end_date, 'week')
                
                if data_weekly.empty or len(data_weekly) < WEEKS_BACK:
                    continue
                
                # Daily data for accurate return calculations
                data_daily = self.get_historical_data(token, start_date, end_date, 'day')
                if data_daily.empty:
                    data_daily = data_weekly  # Fallback to weekly
                
                stocks_data[symbol] = {
                    'data': data_weekly,      # For RRG analysis
                    'data_daily': data_daily,  # For return calculations
                    'sector': sector
                }
                
                if len(stocks_data) % 10 == 0:
                    print(f"   Loaded {len(stocks_data)} stocks...")
            except:
                continue
        
        print(f"✅ Successfully loaded data for {len(stocks_data)} stocks")
        
        # Load benchmark data (WEEKLY for RRG, DAILY for returns)
        print(f"\n📊 Loading benchmark data ({BENCHMARK_INDEX})...")
        benchmark_token = self.get_instrument_token(BENCHMARK_INDEX)
        if not benchmark_token:
            print("❌ Could not load benchmark")
            return stocks_data, pd.DataFrame(), pd.DataFrame()
        
        print(f"   Benchmark Token: {benchmark_token}")
        
        # Weekly data for RRG calculations
        benchmark_data = self.get_historical_data(benchmark_token, start_date, end_date, 'week')
        if benchmark_data.empty:
            print("❌ No benchmark data available")
            return stocks_data, pd.DataFrame(), pd.DataFrame()
        
        print(f"   Weekly data: {len(benchmark_data)} weeks, "
              f"Range: {benchmark_data.index[0].strftime('%Y-%m-%d')} to {benchmark_data.index[-1].strftime('%Y-%m-%d')}")
        print(f"   First close: ₹{benchmark_data['close'].iloc[0]:.2f}, Last close: ₹{benchmark_data['close'].iloc[-1]:.2f}")
        
        # Daily data for accurate return calculations
        benchmark_data_daily = self.get_historical_data(benchmark_token, start_date, end_date, 'day')
        if benchmark_data_daily.empty:
            print("⚠️ No daily benchmark data, using weekly")
            benchmark_data_daily = benchmark_data
        else:
            print(f"   Daily data: {len(benchmark_data_daily)} days")
        
        print(f"✅ Benchmark data loaded")
        
        return stocks_data, benchmark_data, benchmark_data_daily
    
    def run_backtest(self, universe_df: pd.DataFrame, cached_data: Optional[Tuple] = None) -> pd.DataFrame:
        """
        Main backtesting engine
        Runs RRG-based monthly rotation strategy
        
        Args:
            universe_df: Stock universe DataFrame
            cached_data: Optional (stocks_data, benchmark_data, benchmark_data_daily) for reuse
        """
        print("\n" + "="*80)
        print("🚀 STARTING RRG BACKTEST")
        print("="*80)
        
        # Load or use cached data
        if cached_data:
            print(f"\n💾 Using cached data (FAST MODE)")
            stocks_data, benchmark_data, benchmark_data_daily = cached_data
            print(f"✅ Reusing data for {len(stocks_data)} stocks")
        else:
            # Load all historical data (WEEKLY for RRG)
            stocks_data, benchmark_data, benchmark_data_daily = self.load_backtest_data(universe_df)
        
        if not stocks_data or benchmark_data.empty:
            print("❌ No data available, cannot proceed")
            return pd.DataFrame()
        
        # Generate rebalancing dates (monthly or quarterly)
        rebalance_dates = self.generate_rebalance_dates()
        print(f"\n📅 Generated {len(rebalance_dates)} rebalancing dates ({REBALANCE_FREQUENCY})")
        if rebalance_dates:
            print(f"   Dates: {', '.join([d.strftime('%Y-%m-%d') for d in rebalance_dates])}")
        
        # Initialize portfolio tracking
        portfolio_value = INITIAL_CAPITAL
        current_portfolio_weights = {}
        current_positions = {}  # Track entry details: {symbol: {entry_date, entry_price, entry_score, etc}}
        portfolio_peak = INITIAL_CAPITAL  # Track peak for drawdown monitoring
        
        print("\n" + "="*80)
        print(f"⚙️  RUNNING {REBALANCE_FREQUENCY.upper()} RRG ROTATIONS")
        if USE_STOP_LOSS_MONITORING:
            print(f"🛡️  WITH {STOP_MONITORING_FREQUENCY.upper()} STOP LOSS MONITORING")
        print("="*80)
        
        # Main backtest loop
        for i, rebalance_date in enumerate(rebalance_dates[:-1]):
            next_rebalance_date = rebalance_dates[i + 1]
            
            print(f"\n📅 Period {i+1}/{len(rebalance_dates)-1}: {rebalance_date.strftime('%Y-%m-%d')}")
            
            # Show cooldown status
            active_cooldowns = sum(1 for symbol, exit_date in self.cooldown_stocks.items() 
                                  if self._is_in_cooldown(symbol, rebalance_date))
            if active_cooldowns > 0:
                print(f"   🔒 {active_cooldowns} stocks in cooldown period")
            
            # Step 0: Check market regime BEFORE entering (EVERY QUARTER)
            if USE_MARKET_REGIME_FILTER:
                market_status = self.check_market_regime(benchmark_data_daily, rebalance_date)
                print(f"   🌡️  Market Regime: {market_status['regime']} "
                      f"({market_status['score']}/3 conditions met)")
                print(f"      Nifty: ₹{market_status['current_price']} | 200 SMA: ₹{market_status['sma_200']} | "
                      f"Above SMA: {market_status['above_sma']}")
                
                # Adjust portfolio size based on regime
                if market_status['regime'] == 'BEARISH':
                    # In bearish market: Exit existing losers, don't add new
                    print(f"      🔴 BEARISH REGIME - Exiting positions, no new entries")
                    # Keep only winning positions, exit losers
                    adjusted_portfolio_size = 0  # Don't add new stocks
                    # Exit losing positions
                    for symbol, entry_info in list(current_positions.items()):
                        if symbol in stocks_data:
                            stock_data = stocks_data[symbol].get('data_daily', stocks_data[symbol]['data'])
                            temp_data = stock_data[stock_data.index <= rebalance_date]
                            if not temp_data.empty:
                                current_price = temp_data['close'].iloc[-1]
                                current_loss = (current_price / entry_info['entry_price'] - 1)
                                if current_loss < 0:  # Exit any losing position
                                    print(f"      🔴 Exiting loser {symbol}: {current_loss*100:.1f}%")
                                    # Will be handled in normal exit logic
                elif market_status['regime'] == 'NEUTRAL':
                    adjusted_portfolio_size = 5
                    print(f"      🟡 NEUTRAL REGIME - Max portfolio of {adjusted_portfolio_size} stocks")
                else:
                    adjusted_portfolio_size = PORTFOLIO_SIZE
                    print(f"      🟢 BULLISH REGIME - Full portfolio of {adjusted_portfolio_size} stocks")
            else:
                adjusted_portfolio_size = PORTFOLIO_SIZE
            
            # Step 1: Run full RRG analysis as of rebalance_date
            print(f"   🔄 Running RRG analysis...")
            rrg_results = self.run_rrg_analysis(stocks_data, benchmark_data, rebalance_date)
            
            if rrg_results.empty:
                print("   ⚠️ No RRG results, skipping month")
                continue
            
            # Step 2: Select Top N (with filters, cooldown, persistence, and regime adjustment)
            top_15 = self.select_top_15(rrg_results, rebalance_date, current_positions, adjusted_portfolio_size)
            
            if top_15.empty:
                print("   ⚠️ No valid Top 15 selected, skipping month")
                continue
            
            print(f"   ✅ Selected Top 15 | Avg Score: {top_15['Opportunity_Score'].mean():.1f}")
            print(f"      Leading: {len(top_15[top_15['Quadrant']=='Leading'])} | "
                  f"Improving: {len(top_15[top_15['Quadrant']=='Improving'])} | "
                  f"Weakening: {len(top_15[top_15['Quadrant']=='Weakening'])} | "
                  f"Lagging: {len(top_15[top_15['Quadrant']=='Lagging'])}")
            
            # Step 3: Equal weight portfolio
            new_portfolio_weights = {row['Symbol']: 1.0/len(top_15) for _, row in top_15.iterrows()}
            
            # Step 3.5: Track individual positions and implement dynamic exits
            # Identify exits - stocks leaving the portfolio
            exiting_symbols = set(current_positions.keys()) - set(new_portfolio_weights.keys())
            
            # Check for dynamic exits (quadrant change) for stocks still in Top 15
            dynamic_exits = set()
            if USE_DYNAMIC_EXIT and EXIT_ON_QUADRANT_CHANGE:
                for symbol in list(new_portfolio_weights.keys()):
                    if symbol in current_positions:
                        # Check if quadrant changed to Weakening or Lagging
                        current_quadrant = rrg_results[rrg_results['Symbol'] == symbol]['Quadrant'].iloc[0]
                        entry_quadrant = current_positions[symbol]['entry_quadrant']
                        
                        if entry_quadrant in ['Leading', 'Improving'] and current_quadrant in ['Weakening', 'Lagging']:
                            # Force exit due to quadrant change
                            dynamic_exits.add(symbol)
                            exiting_symbols.add(symbol)
                            print(f"      ⚠️  Dynamic Exit: {symbol} moved from {entry_quadrant} to {current_quadrant}")
            
            # Remove dynamic exits from new portfolio weights
            for symbol in dynamic_exits:
                if symbol in new_portfolio_weights:
                    del new_portfolio_weights[symbol]
            
            # Rebalance weights if dynamic exits occurred
            if dynamic_exits and new_portfolio_weights:
                total_weight = sum(new_portfolio_weights.values())
                for symbol in new_portfolio_weights:
                    new_portfolio_weights[symbol] = new_portfolio_weights[symbol] / total_weight
            
            for exit_symbol in exiting_symbols:
                entry_info = current_positions[exit_symbol]
                
                # Get exit price (use daily data for accuracy)
                if exit_symbol in stocks_data:
                    exit_data = stocks_data[exit_symbol].get('data_daily', stocks_data[exit_symbol]['data'])
                    exit_data_filtered = exit_data[exit_data.index <= rebalance_date]
                    if not exit_data_filtered.empty:
                        exit_price = exit_data_filtered['close'].iloc[-1]
                        
                        # Calculate holding return
                        holding_return = (exit_price / entry_info['entry_price'] - 1) * 100
                        holding_days = (rebalance_date - entry_info['entry_date']).days
                        
                        # Determine exit reason
                        exit_reason = 'Dropped from Top 15'
                        if USE_DYNAMIC_EXIT and exit_symbol in rrg_results['Symbol'].values:
                            current_quad = rrg_results[rrg_results['Symbol'] == exit_symbol]['Quadrant'].iloc[0]
                            if current_quad in ['Weakening', 'Lagging']:
                                exit_reason = f'Quadrant Change to {current_quad}'
                        
                        # Log the trade
                        self.trade_log.append({
                            'symbol': exit_symbol,
                            'sector': entry_info.get('sector', 'Unknown'),
                            'entry_date': entry_info['entry_date'].strftime('%Y-%m-%d'),
                            'exit_date': rebalance_date.strftime('%Y-%m-%d'),
                            'holding_days': holding_days,
                            'entry_price': round(entry_info['entry_price'], 2),
                            'exit_price': round(exit_price, 2),
                            'return_pct': round(holding_return, 2),
                            'entry_score': round(entry_info['entry_score'], 2),
                            'entry_quadrant': entry_info['entry_quadrant'],
                            'exit_reason': exit_reason
                        })
                        
                        # Add to cooldown if it was a loss
                        if holding_return < 0:
                            self.cooldown_stocks[exit_symbol] = rebalance_date
                            print(f"      🔒 {exit_symbol} in cooldown for {COOLDOWN_MONTHS} months (loss: {holding_return:.1f}%)")
                
                # Remove from current positions
                if exit_symbol in current_positions:
                    del current_positions[exit_symbol]
            
            # Identify new entries - stocks entering the portfolio
            entering_symbols = set(new_portfolio_weights.keys()) - set(current_positions.keys())
            for enter_symbol in entering_symbols:
                # Get entry details from top_15
                stock_info = top_15[top_15['Symbol'] == enter_symbol].iloc[0]
                
                # Apply entry delay (for delayed entry test)
                actual_entry_date = rebalance_date + timedelta(days=ENTRY_DELAY_DAYS)
                
                # Get actual entry price from daily data (more accurate)
                if enter_symbol in stocks_data:
                    entry_data = stocks_data[enter_symbol].get('data_daily', stocks_data[enter_symbol]['data'])
                    entry_data_filtered = entry_data[entry_data.index <= actual_entry_date]
                    if not entry_data_filtered.empty:
                        actual_entry_price = entry_data_filtered['close'].iloc[-1]
                    else:
                        actual_entry_price = stock_info['Current_Price']
                else:
                    actual_entry_price = stock_info['Current_Price']
                
                # Store entry information (use actual entry date, not rebalance date)
                current_positions[enter_symbol] = {
                    'entry_date': actual_entry_date,
                    'entry_price': actual_entry_price,
                    'entry_score': stock_info['Opportunity_Score'],
                    'entry_quadrant': stock_info['Quadrant'],
                    'sector': stock_info['Sector']
                }
            
            # Step 4: Calculate turnover
            turnover = self.calculate_turnover(current_portfolio_weights, new_portfolio_weights)
            
            # Step 5: Calculate transaction costs
            transaction_cost = turnover * TOTAL_COST_PER_TRADE
            
            # Step 5.5: FORTNIGHTLY STOP LOSS MONITORING (NEW)
            stop_exits_count = 0
            if USE_STOP_LOSS_MONITORING and new_portfolio_weights:
                # Generate fortnightly dates for this quarter
                monitoring_dates = self.generate_monitoring_dates(
                    rebalance_date + timedelta(days=14),  # Start 2 weeks after entry
                    next_rebalance_date - timedelta(days=7)  # End 1 week before rebalance
                )
                
                for mon_date in monitoring_dates:
                    # Calculate current portfolio value
                    temp_value = 0
                    for symbol, weight in new_portfolio_weights.items():
                        if symbol in stocks_data:
                            stock_data = stocks_data[symbol].get('data_daily', stocks_data[symbol]['data'])
                            temp_data = stock_data[stock_data.index <= mon_date]
                            if not temp_data.empty:
                                current_price = temp_data['close'].iloc[-1]
                                entry_price = current_positions[symbol]['entry_price']
                                position_value = (current_price / entry_price) * weight * portfolio_value
                                temp_value += position_value
                    
                    # Check stops
                    stocks_to_exit, exit_all_flag = self.check_stops(
                        current_positions, stocks_data, mon_date, 
                        portfolio_peak, temp_value
                    )
                    
                    # Handle exits
                    if exit_all_flag:
                        stop_pct = PORTFOLIO_STOP_LOSS_PCT*100 if PORTFOLIO_STOP_LOSS_PCT else 10
                        print(f"      🚨 {mon_date.strftime('%Y-%m-%d')}: PORTFOLIO STOP HIT (-{stop_pct}%) - Exiting ALL")
                        stocks_to_exit = list(new_portfolio_weights.keys())
                    elif stocks_to_exit:
                        print(f"      ⚠️  {mon_date.strftime('%Y-%m-%d')}: {len(stocks_to_exit)} stock(s) hit stop loss")
                    
                    # Exit stocks that hit stops
                    for exit_symbol in stocks_to_exit:
                        if exit_symbol in new_portfolio_weights and exit_symbol in current_positions:
                            entry_info = current_positions[exit_symbol]
                            
                            # Get exit price
                            stock_data = stocks_data[exit_symbol].get('data_daily', stocks_data[exit_symbol]['data'])
                            exit_data = stock_data[stock_data.index <= mon_date]
                            if not exit_data.empty:
                                exit_price = exit_data['close'].iloc[-1]
                                holding_return = (exit_price / entry_info['entry_price'] - 1) * 100
                                holding_days = (mon_date - entry_info['entry_date']).days
                                
                                # Log early exit
                                self.trade_log.append({
                                    'symbol': exit_symbol,
                                    'sector': entry_info.get('sector', 'Unknown'),
                                    'entry_date': entry_info['entry_date'].strftime('%Y-%m-%d'),
                                    'exit_date': mon_date.strftime('%Y-%m-%d'),
                                    'holding_days': holding_days,
                                    'entry_price': round(entry_info['entry_price'], 2),
                                    'exit_price': round(exit_price, 2),
                                    'return_pct': round(holding_return, 2),
                                    'entry_score': round(entry_info['entry_score'], 2),
                                    'entry_quadrant': entry_info['entry_quadrant'],
                                    'exit_reason': 'Stop Loss Hit' if not exit_all_flag else 'Portfolio Stop Loss'
                                })
                                
                                print(f"         Exited {exit_symbol}: {holding_return:.2f}%")
                                stop_exits_count += 1
                                
                                # Add to cooldown
                                if holding_return < 0:
                                    self.cooldown_stocks[exit_symbol] = mon_date
                                
                                # Remove from portfolio
                                del new_portfolio_weights[exit_symbol]
                                del current_positions[exit_symbol]
                    
                    # Rebalance weights after exits
                    if new_portfolio_weights:
                        total_weight = sum(new_portfolio_weights.values())
                        for symbol in new_portfolio_weights:
                            new_portfolio_weights[symbol] = new_portfolio_weights[symbol] / total_weight
                    
                    # If all exited, break monitoring loop
                    if not new_portfolio_weights:
                        print(f"      🚫 All positions exited - waiting for next quarter")
                        break
            
            # Step 6: Calculate next period returns
            # If all positions exited via stops, gross return = 0
            if not new_portfolio_weights:
                gross_return = 0.0
                print(f"   💰 All positions exited - return for quarter: 0.00%")
            else:
                returns_data = self.calculate_next_month_return(
                    new_portfolio_weights, stocks_data, rebalance_date, next_rebalance_date
                )
                gross_return = returns_data['portfolio_return']
            
            net_return = gross_return - transaction_cost
            
            # Step 7: Calculate benchmark return (use daily data)
            benchmark_return = self.calculate_benchmark_return(
                benchmark_data_daily, rebalance_date, next_rebalance_date
            )
            
            # Step 8: Update portfolio value and peak tracking
            portfolio_value *= (1 + net_return)
            portfolio_peak = max(portfolio_peak, portfolio_value)  # Track peak for drawdown monitoring
            
            # Step 9: Store results
            if stop_exits_count > 0:
                print(f"   🛡️  Stop losses triggered: {stop_exits_count} positions exited mid-quarter")
            result = {
                'date': rebalance_date,
                'portfolio_value': portfolio_value,
                'gross_return': gross_return,
                'transaction_cost': transaction_cost,
                'net_return': net_return,
                'benchmark_return': benchmark_return,
                'turnover': turnover,
                'num_stocks': len(top_15),
                'avg_score': top_15['Opportunity_Score'].mean(),
                'num_leading': len(top_15[top_15['Quadrant']=='Leading']),
                'num_improving': len(top_15[top_15['Quadrant']=='Improving'])
            }
            
            self.monthly_results.append(result)
            self.monthly_portfolios.append({
                'date': rebalance_date,
                'portfolio': top_15,
                'weights': new_portfolio_weights
            })
            
            # Update current portfolio
            current_portfolio_weights = new_portfolio_weights
            
            # Print progress
            print(f"   Gross Return: {gross_return*100:6.2f}% | Net Return: {net_return*100:6.2f}%")
            print(f"   Turnover: {turnover*100:5.1f}% | Cost: {transaction_cost*100:5.3f}%")
            print(f"   Portfolio Value: ₹{portfolio_value:,.0f} | Benchmark: {benchmark_return*100:6.2f}%")
        
        # Close out remaining positions at end of backtest
        final_rebalance_date = rebalance_dates[-1]
        for symbol, entry_info in current_positions.items():
            if symbol in stocks_data:
                exit_data = stocks_data[symbol].get('data_daily', stocks_data[symbol]['data'])
                exit_data_filtered = exit_data[exit_data.index <= final_rebalance_date]
                if not exit_data_filtered.empty:
                    exit_price = exit_data_filtered['close'].iloc[-1]
                    
                    holding_return = (exit_price / entry_info['entry_price'] - 1) * 100
                    holding_days = (final_rebalance_date - entry_info['entry_date']).days
                    
                    self.trade_log.append({
                        'symbol': symbol,
                        'sector': entry_info.get('sector', 'Unknown'),
                        'entry_date': entry_info['entry_date'].strftime('%Y-%m-%d'),
                        'exit_date': final_rebalance_date.strftime('%Y-%m-%d'),
                        'holding_days': holding_days,
                        'entry_price': round(entry_info['entry_price'], 2),
                        'exit_price': round(exit_price, 2),
                        'return_pct': round(holding_return, 2),
                        'entry_score': round(entry_info['entry_score'], 2),
                        'entry_quadrant': entry_info['entry_quadrant'],
                        'exit_reason': 'End of Backtest'
                    })
        
        # Convert results to DataFrame
        results_df = pd.DataFrame(self.monthly_results)
        
        print("\n" + "="*80)
        print("✅ RRG BACKTEST COMPLETE")
        print("="*80)
        
        return results_df
    
    # =========================================================================
    # PERFORMANCE METRICS & REPORTING (same as MomentumBacktester)
    # =========================================================================
    
    def calculate_performance_metrics(self, results_df: pd.DataFrame) -> Dict:
        """Calculate comprehensive performance metrics with enhanced validation"""
        
        # ⭐ Early validation checks
        if results_df.empty or len(results_df) < 2:
            return {
                'error': 'Insufficient data (need at least 2 periods)',
                'start_date': 'N/A',
                'end_date': 'N/A',
                'years': 0,
                'total_return_pct': 0,
                'cagr_pct': 0
            }
        
        # Time period
        start_date = results_df['date'].iloc[0]
        end_date = results_df['date'].iloc[-1]
        total_days = (end_date - start_date).days
        years = total_days / 365.25
        
        # ⭐ Safety checks
        initial_value = INITIAL_CAPITAL
        final_value = results_df['portfolio_value'].iloc[-1]
        
        if initial_value <= 0:
            return {'error': 'Invalid initial capital'}
        
        # Total return (always calculate this)
        total_return = (final_value / initial_value) - 1
        
        # ⭐ CAGR calculation with validation and safety
        MIN_YEARS_FOR_CAGR = 0.75  # 9 months minimum
        is_valid_for_cagr = years >= MIN_YEARS_FOR_CAGR
        cagr_note = ""
        
        if years <= 0:
            cagr = total_return  # Same-day or negative period
            cagr_note = "Period ≤1 day - showing simple return"
        elif not is_valid_for_cagr:
            # Very short period - show but warn heavily
            cagr = ((final_value / initial_value) ** (1/years)) - 1 if final_value > 0 else -1.0
            cagr_note = f"⚠️ SHORT PERIOD ({total_days} days) - CAGR highly extrapolated"
        elif final_value <= 0:
            cagr = -1.0  # Total loss
            cagr_note = "⚠️ Portfolio value ≤ 0"
        else:
            # Normal CAGR calculation
            cagr = ((final_value / initial_value) ** (1/years)) - 1
            cagr_note = "Valid CAGR"
        
        # ⭐ Data quality checks - flag extreme values
        if cagr > 10.0:  # 1000%+ CAGR
            cagr_note = "⚠️ EXTREME CAGR (>1000%) - Check data quality or use Total Return"
        elif cagr < -0.99:  # >99% loss
            cagr_note = "⚠️ Near total loss (>99%)"
        
        # ⭐ Simple annual return (for comparison)
        simple_annual_return = (total_return / years) if years > 0 else 0
        
        # Benchmark comparison
        if 'benchmark_return' in results_df.columns:
            benchmark_cumulative = (1 + results_df['benchmark_return']).prod() - 1
            
            if is_valid_for_cagr and years > 0 and (1 + benchmark_cumulative) > 0:
                benchmark_cagr = ((1 + benchmark_cumulative) ** (1/years)) - 1
                excess_return = cagr - benchmark_cagr
            else:
                benchmark_cagr = 0
                excess_return = 0
        else:
            benchmark_cumulative = 0
            benchmark_cagr = 0
            excess_return = 0
        
        # Volatility & Sharpe
        period_returns = results_df['net_return']
        # Annualize based on rebalancing frequency
        periods_per_year = 12 if REBALANCE_FREQUENCY == 'monthly' else 4
        volatility = period_returns.std() * np.sqrt(periods_per_year)
        sharpe_ratio = (cagr / volatility) if volatility > 0 else 0
        
        # Drawdown analysis
        cumulative_returns = (1 + period_returns).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        max_drawdown = drawdown.min()
        
        # Win rate
        winning_periods = (period_returns > 0).sum()
        total_periods = len(period_returns)
        win_rate = winning_periods / total_periods if total_periods > 0 else 0
        
        # Average turnover
        avg_turnover = results_df['turnover'].mean() if 'turnover' in results_df.columns else 0
        
        # Average transaction cost
        avg_cost = results_df['transaction_cost'].mean() if 'transaction_cost' in results_df.columns else 0
        
        # RRG specific metrics
        avg_leading = results_df['num_leading'].mean() if 'num_leading' in results_df.columns else 0
        avg_improving = results_df['num_improving'].mean() if 'num_improving' in results_df.columns else 0
        
        # ⭐ Find max drawdown date
        cumulative_returns = (1 + period_returns).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown_series = (cumulative_returns - running_max) / running_max
        max_dd_idx = drawdown_series.idxmin()
        max_dd_date = results_df['date'].iloc[max_dd_idx] if max_dd_idx is not None else start_date
        
        metrics = {
            # Time
            'start_date': start_date.strftime('%Y-%m-%d'),
            'end_date': end_date.strftime('%Y-%m-%d'),
            'total_days': total_days,
            'years': round(years, 2),
            'is_valid_for_cagr': is_valid_for_cagr,
            'cagr_note': cagr_note,
            
            # Returns
            'initial_capital': INITIAL_CAPITAL,
            'final_value': round(final_value, 2),
            'total_return_pct': round(total_return * 100, 2),
            'cagr_pct': round(cagr * 100, 2),
            'simple_annual_return_pct': round(simple_annual_return * 100, 2),
            
            # Risk
            'volatility_pct': round(volatility * 100, 2),
            'sharpe_ratio': round(sharpe_ratio, 2),
            'max_drawdown_pct': round(max_drawdown * 100, 2),
            'max_drawdown_date': max_dd_date.strftime('%Y-%m-%d'),
            'win_rate_pct': round(win_rate * 100, 2),
            'avg_monthly_return_pct': round(period_returns.mean() * 100, 2),
            'best_month_pct': round(period_returns.max() * 100, 2),
            'worst_month_pct': round(period_returns.min() * 100, 2),
            
            # Trading
            'avg_turnover_pct': round(avg_turnover * 100, 2),
            'avg_transaction_cost_pct': round(avg_cost * 100, 4),
            
            # Benchmark
            'benchmark_return_pct': round(benchmark_cumulative * 100, 2),
            'benchmark_cagr_pct': round(benchmark_cagr * 100, 2),
            'excess_return_pct': round(excess_return * 100, 2),
            
            # RRG specific
            'avg_leading_stocks': round(avg_leading, 1),
            'avg_improving_stocks': round(avg_improving, 1)
        }
        
        return metrics
    
    def print_performance_summary(self, metrics: Dict):
        """Print performance summary"""
        print("\n" + "="*80)
        print("📊 RRG BACKTEST PERFORMANCE SUMMARY")
        print("="*80)
        
        years = metrics['years']
        num_quarters = len(self.monthly_results)
        
        # ⭐ AT-A-GLANCE SUMMARY BOX
        print(f"\n📋 AT-A-GLANCE SUMMARY:")
        print(f"   ╔═══════════════════════════════════════════════════════════════╗")
        print(f"   ║ Period: {metrics['start_date']} to {metrics['end_date']} ({years:.2f} years) {'✅' if years >= 3 else '⚠️'}  ║")
        print(f"   ║ Total Return: {metrics['total_return_pct']:>7.2f}% (₹{metrics['initial_capital']/100000:.0f}L → ₹{metrics['final_value']/100000:.1f}L)             ║")
        print(f"   ║ CAGR: {metrics['cagr_pct']:>13.2f}% {'(Annualized)' if years >= 1 else '(⚠️ SHORT PERIOD)':>20}              ║")
        print(f"   ║ Volatility: {metrics['volatility_pct']:>9.2f}% (Annual)                                ║")
        print(f"   ║ Sharpe Ratio: {metrics['sharpe_ratio']:>7.2f} {'✅' if metrics['sharpe_ratio'] > 1.5 else '⚠️' if metrics['sharpe_ratio'] > 1.0 else '❌'}                                         ║")
        print(f"   ║ Max Drawdown: {metrics['max_drawdown_pct']:>7.2f}% {'✅' if abs(metrics['max_drawdown_pct']) < 10 else '⚠️' if abs(metrics['max_drawdown_pct']) < 20 else '❌'}                                    ║")
        print(f"   ╚═══════════════════════════════════════════════════════════════╝")
        
        # ⭐ Enhanced time period display with validation
        print(f"\n⏱️  TIME PERIOD DETAILS")
        print(f"   Start Date: {metrics['start_date']}")
        print(f"   End Date: {metrics['end_date']}")
        print(f"   Duration: {metrics.get('total_days', 0)} days ({years:.2f} years, {num_quarters} quarters)", end="")
        
        # Add context for time period
        if years < 1.0:
            months = years * 12
            print(f" ⚠️ SHORT PERIOD")
            print(f"   ℹ️  CAGR may be extrapolated and misleading for periods <1 year")
        elif years < 2.0:
            print(f" ⚠️ LIMITED PERIOD")
            print(f"   ℹ️  CAGR is extrapolated - prefer 3+ years for validation")
        elif years >= 3.0:
            print(f" ✅ VALIDATED PERIOD")
            print(f"   ℹ️  Sufficient data for statistical significance")
        else:
            print()
        
        print(f"\n💰 RETURNS")
        print(f"   Initial Capital: ₹{metrics['initial_capital']:,.0f}")
        print(f"   Final Value: ₹{metrics['final_value']:,.0f}")
        print(f"   Total Return: {metrics['total_return_pct']:.2f}% ⭐ (Actual return over {years:.2f} years)")
        
        # Display CAGR with context and note
        if metrics.get('cagr_pct') is not None:
            print(f"   CAGR: {metrics['cagr_pct']:.2f}%", end="")
            if "⚠️" in metrics.get('cagr_note', ''):
                print(f" - {metrics['cagr_note']}")
            elif years < 1.0:
                print(f" ⚠️ (Extrapolated from {years:.2f} years - USE TOTAL RETURN INSTEAD)")
            elif years < 2.0:
                print(f" ⚠️ (Annualized from {years:.2f} years - limited validation)")
            else:
                print(f" (Annualized from {years:.2f} years)")
        else:
            print(f"   CAGR: N/A (Period too short - use Total Return)")
        
        # Show simple annual return for comparison
        if years < 3.0 and metrics.get('simple_annual_return_pct') is not None:
            print(f"   Simple Avg Annual: {metrics['simple_annual_return_pct']:.2f}% (For comparison: Total Return ÷ Years)")
        
        print(f"   Avg Quarterly Return: {metrics['avg_monthly_return_pct']:.2f}%")
        
        print(f"\n📈 RISK METRICS")
        print(f"   Volatility (Annual): {metrics['volatility_pct']:.2f}% ⭐ (Annualized from {num_quarters} quarters)")
        print(f"   Sharpe Ratio: {metrics['sharpe_ratio']:.2f}", end="")
        if num_quarters < 10:
            print(f" ⚠️ (<10 periods, limited statistical significance)")
        elif metrics['sharpe_ratio'] > 1.5:
            print(f" ✅ (Excellent - Top 10% tier)")
        elif metrics['sharpe_ratio'] > 1.0:
            print(f" ✅ (Good)")
        else:
            print()
        print(f"   Max Drawdown: {metrics['max_drawdown_pct']:.2f}%", end="")
        if abs(metrics['max_drawdown_pct']) < 10:
            print(f" ✅ (Best-in-class)", end="")
        elif abs(metrics['max_drawdown_pct']) < 20:
            print(f" ✅ (Acceptable)", end="")
        else:
            print(f" ⚠️ (High)", end="")
        
        # Show when max DD occurred
        if 'max_drawdown_date' in metrics:
            print(f" - Occurred on {metrics['max_drawdown_date']}")
        else:
            print()
        
        print(f"   Win Rate: {metrics['win_rate_pct']:.1f}% ({int(metrics['win_rate_pct']*num_quarters/100)}/{num_quarters} winning quarters)")
        print(f"   Best Quarter: {metrics['best_month_pct']:.2f}%")
        print(f"   Worst Quarter: {metrics['worst_month_pct']:.2f}%")
        
        print(f"\n💸 TRADING COSTS")
        print(f"   Avg Turnover per Rebalance: {metrics['avg_turnover_pct']:.1f}%")
        print(f"   Avg Transaction Cost: {metrics['avg_transaction_cost_pct']:.3f}%")
        print(f"   Rebalance Frequency: {REBALANCE_FREQUENCY.capitalize()}")
        
        print(f"\n🎯 RRG METRICS")
        print(f"   Avg Leading Stocks: {metrics['avg_leading_stocks']:.1f} / 15")
        print(f"   Avg Improving Stocks: {metrics['avg_improving_stocks']:.1f} / 15")
        
        if metrics['benchmark_cagr_pct'] != 0:
            print(f"\n🏆 BENCHMARK COMPARISON ({BENCHMARK_INDEX})")
            print(f"   Benchmark Total Return: {metrics['benchmark_return_pct']:.2f}% (over {years:.2f} years)")
            print(f"   Benchmark CAGR: {metrics['benchmark_cagr_pct']:.2f}%", end="")
            if years >= 1:
                print(f" (Annualized)")
            else:
                print(f" ⚠️ (Extrapolated)")
            print(f"   Strategy CAGR: {metrics['cagr_pct']:.2f}%")
            print(f"   Excess Return (CAGR): {metrics['excess_return_pct']:+.2f}%", end="")
            if metrics['excess_return_pct'] > 0:
                print(f" ✅ (Outperforming)")
            else:
                print(f" ❌ (Underperforming)")
            
            # Add interpretation
            if years >= 3:
                if metrics['excess_return_pct'] > 30:
                    print(f"   ℹ️  Exceptional outperformance (>30%)")
                elif metrics['excess_return_pct'] > 15:
                    print(f"   ℹ️  Strong outperformance (15-30%)")
                elif metrics['excess_return_pct'] > 5:
                    print(f"   ℹ️  Good outperformance (5-15%)")
                elif metrics['excess_return_pct'] > 0:
                    print(f"   ℹ️  Modest outperformance (0-5%)")
                else:
                    print(f"   ℹ️  Strategy underperforming benchmark")
        
        # ⭐ Display CAGR validation note if present
        if metrics.get('cagr_note') and metrics['cagr_note'] not in ['Valid CAGR']:
            print(f"\n⚠️  CAGR VALIDATION NOTE:")
            print(f"   {metrics['cagr_note']}")
            if years < 1.0:
                print(f"   → Use Total Return ({metrics['total_return_pct']:.2f}%) as primary metric")
                print(f"   → CAGR is only for informational comparison")
        
        print("\n" + "="*80)
    
    def export_results(self, results_df: pd.DataFrame, metrics: Dict):
        """Export results to CSV files"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Export monthly returns
        if CREATE_RETURNS_CSV:
            returns_file = os.path.join(OUTPUT_DIR, f'rrg_backtest_returns_{timestamp}.csv')
            export_df = results_df.copy()
            export_df['date'] = export_df['date'].dt.strftime('%Y-%m-%d')
            export_df['gross_return'] = (export_df['gross_return'] * 100).round(2)
            export_df['net_return'] = (export_df['net_return'] * 100).round(2)
            export_df['benchmark_return'] = (export_df['benchmark_return'] * 100).round(2)
            export_df['turnover'] = (export_df['turnover'] * 100).round(2)
            export_df['transaction_cost'] = (export_df['transaction_cost'] * 100).round(4)
            export_df.to_csv(returns_file, index=False)
            print(f"💾 Monthly returns exported to: {returns_file}")
        
        # Export portfolio compositions
        if CREATE_MONTHLY_PORTFOLIO_CSV:
            portfolio_records = []
            for entry in self.monthly_portfolios:
                date = entry['date']
                portfolio_df = entry['portfolio']
                weights = entry['weights']
                
                for _, stock in portfolio_df.iterrows():
                    # Skip stocks that were exited mid-quarter (not in final weights)
                    if stock['Symbol'] not in weights:
                        continue
                    
                    portfolio_records.append({
                        'date': date.strftime('%Y-%m-%d'),
                        'symbol': stock['Symbol'],
                        'sector': stock['Sector'],
                        'weight': weights[stock['Symbol']] * 100,
                        'opportunity_score': stock['Opportunity_Score'],
                        'quadrant': stock['Quadrant'],
                        'rs_ratio': stock['RS_Ratio'],
                        'rs_momentum': stock['RS_Momentum'],
                        'price': stock['Current_Price']
                    })
            
            portfolio_df = pd.DataFrame(portfolio_records)
            portfolio_file = os.path.join(OUTPUT_DIR, f'rrg_backtest_portfolios_{timestamp}.csv')
            portfolio_df.to_csv(portfolio_file, index=False)
            print(f"💾 Portfolio compositions exported to: {portfolio_file}")
        
        # Export performance metrics
        if CREATE_METRICS_CSV:
            metrics_file = os.path.join(OUTPUT_DIR, f'rrg_backtest_metrics_{timestamp}.csv')
            metrics_df = pd.DataFrame([metrics])
            metrics_df.to_csv(metrics_file, index=False)
            print(f"💾 Performance metrics exported to: {metrics_file}")
        
        # Export trade log with detailed entry/exit tracking
        if self.trade_log:
            trade_log_file = os.path.join(OUTPUT_DIR, f'rrg_trade_log_{timestamp}.csv')
            trade_log_df = pd.DataFrame(self.trade_log)
            
            # Add analysis columns
            trade_log_df['profit_loss'] = trade_log_df['return_pct'].apply(
                lambda x: 'Profit' if x > 0 else 'Loss' if x < 0 else 'Breakeven'
            )
            
            # Sort by return to see best and worst trades
            trade_log_df_sorted = trade_log_df.sort_values('return_pct', ascending=False)
            trade_log_df_sorted.to_csv(trade_log_file, index=False)
            print(f"💾 Trade log with {len(trade_log_df)} trades exported to: {trade_log_file}")
            
            # Print trade statistics
            print(f"\n📊 TRADE ANALYSIS:")
            print(f"   Total Trades: {len(trade_log_df)}")
            print(f"   Winning Trades: {len(trade_log_df[trade_log_df['return_pct'] > 0])} "
                  f"({len(trade_log_df[trade_log_df['return_pct'] > 0])/len(trade_log_df)*100:.1f}%)")
            print(f"   Losing Trades: {len(trade_log_df[trade_log_df['return_pct'] < 0])} "
                  f"({len(trade_log_df[trade_log_df['return_pct'] < 0])/len(trade_log_df)*100:.1f}%)")
            print(f"   Avg Return: {trade_log_df['return_pct'].mean():.2f}%")
            print(f"   Best Trade: {trade_log_df['return_pct'].max():.2f}% ({trade_log_df.loc[trade_log_df['return_pct'].idxmax(), 'symbol']})")
            print(f"   Worst Trade: {trade_log_df['return_pct'].min():.2f}% ({trade_log_df.loc[trade_log_df['return_pct'].idxmin(), 'symbol']})")
            print(f"   Avg Holding Period: {trade_log_df['holding_days'].mean():.0f} days")
            
            # Quadrant analysis
            print(f"\n📈 PERFORMANCE BY ENTRY QUADRANT:")
            for quadrant in ['Leading', 'Improving', 'Weakening', 'Lagging']:
                quad_trades = trade_log_df[trade_log_df['entry_quadrant'] == quadrant]
                if len(quad_trades) > 0:
                    wins = len(quad_trades[quad_trades['return_pct'] > 0])
                    win_rate = wins/len(quad_trades)*100
                    avg_ret = quad_trades['return_pct'].mean()
                    
                    # Highlight the best quadrant
                    indicator = "🎯" if avg_ret > 0 else "⚠️"
                    print(f"   {indicator} {quadrant:<12}: {len(quad_trades):>3} trades, "
                          f"Avg Return: {avg_ret:>6.2f}%, "
                          f"Win Rate: {win_rate:>5.1f}%")
            
            # Sector analysis
            print(f"\n🏭 PERFORMANCE BY SECTOR:")
            sector_perf = trade_log_df.groupby('sector').agg({
                'return_pct': ['count', 'mean', 'sum'],
                'holding_days': 'mean'
            }).round(2)
            sector_perf.columns = ['Trades', 'Avg_Return%', 'Total_Return%', 'Avg_Days']
            sector_perf = sector_perf.sort_values('Avg_Return%', ascending=False)
            
            print(f"   {'Sector':<25} {'Trades':>7} {'Avg Ret%':>10} {'Total Ret%':>12} {'Avg Days':>10}")
            print(f"   {'-'*68}")
            for sector, row in sector_perf.head(10).iterrows():
                print(f"   {sector:<25} {int(row['Trades']):>7} {row['Avg_Return%']:>10.2f} {row['Total_Return%']:>12.2f} {int(row['Avg_Days']):>10}")
            
            # Export sector analysis
            sector_analysis_file = os.path.join(OUTPUT_DIR, f'rrg_sector_performance_{timestamp}.csv')
            sector_perf.to_csv(sector_analysis_file)
            print(f"\n💾 Sector performance analysis exported to: {sector_analysis_file}")
            
            # Exit reason analysis
            print(f"\n🚪 EXIT REASON ANALYSIS:")
            exit_reasons = trade_log_df.groupby('exit_reason').agg({
                'return_pct': ['count', 'mean']
            }).round(2)
            exit_reasons.columns = ['Count', 'Avg_Return%']
            for reason, row in exit_reasons.iterrows():
                indicator = "🛡️" if 'Stop Loss' in reason else "📊"
                print(f"   {indicator} {reason:<35}: {int(row['Count']):>3} trades, Avg Return: {row['Avg_Return%']:>6.2f}%")
            
            # Stop loss effectiveness
            stop_exits = trade_log_df[trade_log_df['exit_reason'].str.contains('Stop Loss', na=False)]
            if len(stop_exits) > 0:
                print(f"\n🛡️  STOP LOSS EFFECTIVENESS:")
                print(f"   Stops Triggered: {len(stop_exits)} trades")
                print(f"   Avg Loss When Stopped: {stop_exits['return_pct'].mean():.2f}%")
                print(f"   Without Stops (estimated): {stop_exits['return_pct'].mean() * 1.5:.2f}%")
                print(f"   Capital Saved: {(stop_exits['return_pct'].mean() * 0.5) * len(stop_exits):.2f}% of portfolio")
            
            # Score range analysis
            print(f"\n📊 PERFORMANCE BY ENTRY SCORE RANGE:")
            trade_log_df['score_range'] = pd.cut(trade_log_df['entry_score'], 
                                                  bins=[0, 150, 200, 250, 300, 400],
                                                  labels=['<150', '150-200', '200-250', '250-300', '300+'])
            score_perf = trade_log_df.groupby('score_range').agg({
                'return_pct': ['count', 'mean']
            }).round(2)
            score_perf.columns = ['Count', 'Avg_Return%']
            for score_range, row in score_perf.iterrows():
                indicator = "🎯" if row['Avg_Return%'] > 0 else "⚠️"
                print(f"   {indicator} Score {score_range:<12}: {int(row['Count']):>3} trades, Avg Return: {row['Avg_Return%']:>6.2f}%")
    
    def create_performance_plots(self, results_df: pd.DataFrame):
        """Create performance visualization plots"""
        if not CREATE_PLOTS:
            return
        
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            fig.suptitle('RRG Strategy - Backtest Results', fontsize=16, fontweight='bold')
            
            # Plot 1: Cumulative Returns
            ax1 = axes[0, 0]
            ax1.plot(results_df['date'], results_df['portfolio_value'], label='RRG Strategy', linewidth=2)
            
            if 'benchmark_return' in results_df.columns:
                benchmark_value = INITIAL_CAPITAL * (1 + results_df['benchmark_return']).cumprod()
                ax1.plot(results_df['date'], benchmark_value, label='Benchmark', linewidth=2, alpha=0.7)
            
            ax1.set_title('Portfolio Value Over Time')
            ax1.set_xlabel('Date')
            ax1.set_ylabel('Portfolio Value (₹)')
            ax1.legend()
            ax1.grid(True, alpha=0.3)
            ax1.ticklabel_format(style='plain', axis='y')
            
            # Plot 2: Drawdown
            ax2 = axes[0, 1]
            cumulative = results_df['portfolio_value'] / INITIAL_CAPITAL
            running_max = cumulative.expanding().max()
            drawdown = ((cumulative - running_max) / running_max) * 100
            ax2.fill_between(results_df['date'], drawdown, 0, alpha=0.3, color='red')
            ax2.plot(results_df['date'], drawdown, color='red', linewidth=1)
            ax2.set_title('Drawdown Over Time')
            ax2.set_xlabel('Date')
            ax2.set_ylabel('Drawdown (%)')
            ax2.grid(True, alpha=0.3)
            
            # Plot 3: Monthly Returns Distribution
            ax3 = axes[1, 0]
            monthly_returns_pct = results_df['net_return'] * 100
            ax3.hist(monthly_returns_pct, bins=30, alpha=0.7, edgecolor='black')
            ax3.axvline(monthly_returns_pct.mean(), color='red', linestyle='--', 
                       label=f'Mean: {monthly_returns_pct.mean():.2f}%')
            ax3.set_title('Distribution of Monthly Returns')
            ax3.set_xlabel('Monthly Return (%)')
            ax3.set_ylabel('Frequency')
            ax3.legend()
            ax3.grid(True, alpha=0.3)
            
            # Plot 4: RRG Quadrant Distribution Over Time
            ax4 = axes[1, 1]
            if 'num_leading' in results_df.columns:
                ax4.plot(results_df['date'], results_df['num_leading'], label='Leading', linewidth=2)
                ax4.plot(results_df['date'], results_df['num_improving'], label='Improving', linewidth=2)
                ax4.set_title('Average Stocks in Leading/Improving Quadrants')
                ax4.set_xlabel('Date')
                ax4.set_ylabel('Number of Stocks')
                ax4.legend()
                ax4.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            plot_file = os.path.join(OUTPUT_DIR, f'rrg_backtest_performance_{timestamp}.png')
            plt.savefig(plot_file, dpi=300, bbox_inches='tight')
            print(f"📊 Performance plots saved to: {plot_file}")
            
            plt.close()
            
        except Exception as e:
            print(f"⚠️ Could not create plots: {e}")
    
    # =========================================================================
    # YAMADA FRAMEWORK - RANDOM CONTROL TEST
    # =========================================================================
    
    def run_monte_carlo_random_test(self, universe_df: pd.DataFrame) -> Dict:
        """
        Run Monte Carlo simulation with random stock selection
        This is THE test that validates if RRG scoring adds any value
        """
        print("\n" + "="*80)
        print("🎲 YAMADA FRAMEWORK - RANDOM CONTROL TEST")
        print("="*80)
        print("\n📊 THE KILL SWITCH TEST")
        print("   This test answers: 'Do I even have an edge?'")
        print("   If random selection performs similarly, your strategy has NO VALUE\n")
        print(f"   Running {MONTE_CARLO_RUNS} backtests with random stock selection...")
        print(f"   Same: rebalance dates, costs, stops, regime filters, persistence")
        print(f"   Different: Replace RRG scoring with random.choice()\n")
        
        # First, run actual RRG strategy
        print("🎯 STEP 1: Running ACTUAL RRG strategy (baseline)...")
        global STRATEGY_MODE
        original_mode = STRATEGY_MODE
        STRATEGY_MODE = 'rrg'
        
        results_rrg = self.run_backtest(universe_df)
        metrics_rrg = self.calculate_performance_metrics(results_rrg)
        actual_cagr = metrics_rrg.get('cagr_pct', 0)
        actual_sharpe = metrics_rrg.get('sharpe_ratio', 0)
        actual_max_dd = metrics_rrg.get('max_drawdown_pct', 0)
        
        print(f"   ✅ RRG Strategy: CAGR={actual_cagr:.2f}%, Sharpe={actual_sharpe:.2f}, Max DD={actual_max_dd:.2f}%\n")
        
        # Now run Monte Carlo with random selection
        print(f"🎲 STEP 2: Running {MONTE_CARLO_RUNS} random backtests (Monte Carlo)...")
        print(f"   ⚠️  Note: Each run re-loads data from API (~3-5 min each)")
        print(f"   Expected total time: ~{MONTE_CARLO_RUNS * 4} minutes\n")
        STRATEGY_MODE = 'random'
        
        random_cagrs = []
        random_sharpes = []
        random_max_dds = []
        
        for i in range(MONTE_CARLO_RUNS):
            # Use instance variable instead of modifying global
            run_seed = 42 + i
            
            # Temporarily disable output for Monte Carlo runs
            import sys
            import io
            original_stdout = sys.stdout
            sys.stdout = io.StringIO()  # Capture output instead of /dev/null
            
            try:
                # Create fresh backtester instance for each run
                random_backtester = RRGBacktester(API_KEY, ACCESS_TOKEN)
                
                # Modify seed for this run
                global RANDOM_SEED
                old_seed = RANDOM_SEED
                RANDOM_SEED = run_seed
                
                results_random = random_backtester.run_backtest(universe_df)
                
                if not results_random.empty:
                    metrics_random = random_backtester.calculate_performance_metrics(results_random)
                    
                    random_cagrs.append(metrics_random.get('cagr_pct', 0))
                    random_sharpes.append(metrics_random.get('sharpe_ratio', 0))
                    random_max_dds.append(metrics_random.get('max_drawdown_pct', 0))
                
                # Restore seed
                RANDOM_SEED = old_seed
                
            except Exception as e:
                # Restore seed even on error
                RANDOM_SEED = old_seed
                # Log first few errors for debugging
                if i < 3:
                    sys.stdout = original_stdout
                    print(f"   ⚠️  Run {i+1} failed: {str(e)[:100]}")
                    sys.stdout = io.StringIO()
            finally:
                sys.stdout = original_stdout
            
            # Show progress every run (for small runs, show each one)
            if MONTE_CARLO_RUNS <= 10 or (i + 1) % 10 == 0:
                print(f"   Progress: {i + 1}/{MONTE_CARLO_RUNS} runs complete... (Success: {len(random_cagrs)})")
        
        # Restore original mode
        STRATEGY_MODE = original_mode
        
        print(f"   ✅ Completed {len(random_cagrs)} random backtests\n")
        
        # Check if we have enough successful runs
        if len(random_cagrs) < 2:
            print("❌ ERROR: Too few successful random backtests")
            print(f"   Only {len(random_cagrs)}/{MONTE_CARLO_RUNS} runs completed successfully")
            print("   Cannot perform statistical analysis - test ABORTED\n")
            return {
                'actual_cagr': actual_cagr,
                'actual_sharpe': actual_sharpe,
                'random_avg_cagr': 0,
                'random_std_cagr': 0,
                'random_avg_sharpe': 0,
                'z_score': 0,
                'p_value': 0.5,
                'verdict': 'ERROR',
                'all_random_cagrs': []
            }
        
        # Statistical analysis
        random_avg_cagr = np.mean(random_cagrs)
        random_std_cagr = np.std(random_cagrs)
        random_avg_sharpe = np.mean(random_sharpes)
        random_avg_max_dd = np.mean(random_max_dds)
        
        # Z-score and p-value
        z_score = (actual_cagr - random_avg_cagr) / random_std_cagr if random_std_cagr > 0 else 0
        
        # Using scipy for p-value
        from scipy import stats as scipy_stats
        p_value = 1 - scipy_stats.norm.cdf(z_score) if z_score > 0 else scipy_stats.norm.cdf(z_score)
        
        # Print results
        print("="*80)
        print("📊 STATISTICAL ANALYSIS RESULTS")
        print("="*80)
        print()
        print(f"   Your RRG Strategy:")
        print(f"      CAGR: {actual_cagr:.2f}%")
        print(f"      Sharpe: {actual_sharpe:.2f}")
        print(f"      Max DD: {actual_max_dd:.2f}%")
        print()
        print(f"   Random Selection (Average of {len(random_cagrs)} runs):")
        print(f"      CAGR: {random_avg_cagr:.2f}% (±{random_std_cagr:.2f}%)")
        print(f"      Sharpe: {random_avg_sharpe:.2f}")
        print(f"      Max DD: {random_avg_max_dd:.2f}%")
        print()
        print(f"   Statistical Significance:")
        print(f"      Z-Score: {z_score:.2f}")
        print(f"      P-Value: {p_value:.4f}")
        print(f"      Performance Gap: {actual_cagr - random_avg_cagr:.2f}% CAGR")
        print()
        
        # Kohei Yamada's interpretation
        print("="*80)
        print("🎯 VERDICT (Kohei Yamada Framework)")
        print("="*80)
        print()
        
        if z_score < 1.0:
            print("   ❌ CRITICAL FAILURE: Your 'edge' is pure noise")
            print("      → RRG scoring adds NO VALUE over random selection")
            print("      → Your returns are within 1σ of random")
            print("      → STOP - Do not trade this strategy")
            print("      → You're just getting lucky with market timing\n")
            verdict = "FAIL"
        elif z_score < 2.0:
            print("   ⚠️  MARGINAL EDGE: Edge exists but WEAK")
            print("      → Not statistically significant (p > 0.05)")
            print("      → Your edge might disappear in live trading")
            print("      → Consider: Are you just capturing market beta?")
            print("      → Proceed with EXTREME caution\n")
            verdict = "MARGINAL"
        else:
            print("   ✅ VALIDATED: Real edge detected (statistically significant)")
            print(f"      → You're {z_score:.1f} standard deviations better than random")
            print(f"      → P-value: {p_value:.4f} (significant if < 0.05)")
            print("      → RRG scoring IS adding value")
            print("      → Your edge is likely to persist in live trading")
            
            if z_score >= 3.0:
                print(f"      → 🏆 EXCEPTIONAL: {z_score:.1f}σ edge is extremely rare")
            print()
            verdict = "PASS"
        
        print("="*80)
        
        return {
            'actual_cagr': actual_cagr,
            'actual_sharpe': actual_sharpe,
            'random_avg_cagr': random_avg_cagr,
            'random_std_cagr': random_std_cagr,
            'random_avg_sharpe': random_avg_sharpe,
            'z_score': z_score,
            'p_value': p_value,
            'verdict': verdict,
            'all_random_cagrs': random_cagrs
        }
    
    # =========================================================================
    # YAMADA FRAMEWORK - PARAMETER PLATEAU TEST
    # =========================================================================
    
    def run_parameter_plateau_test(self, universe_df: pd.DataFrame) -> Dict:
        """
        Kohei Yamada's "Peak vs Plateau" Test
        Tests if performance is stable across parameter variations
        or if it collapses (indicating overfitting)
        """
        print("\n" + "="*80)
        print("📊 YAMADA FRAMEWORK - PARAMETER PLATEAU TEST")
        print("="*80)
        print("\n🔬 OVERFITTING DETECTOR")
        print("   This test answers: 'Is my strategy curve-fitted?'")
        print("   If performance collapses with small changes, you're overfitted\n")
        
        # Declare globals first (before reading)
        global MIN_SCORE_THRESHOLD, MAX_SCORE_THRESHOLD
        global STOCK_STOP_LOSS_PCT, MIN_SCORE_DROP_TO_EXIT
        global REBALANCE_FREQUENCY, STRATEGY_MODE
        
        # Ensure STRATEGY_MODE is set to 'rrg' for plateau tests
        STRATEGY_MODE = 'rrg'
        
        # Save current parameters
        original_min_score = MIN_SCORE_THRESHOLD
        original_max_score = MAX_SCORE_THRESHOLD
        original_stop_loss = STOCK_STOP_LOSS_PCT
        original_persistence = MIN_SCORE_DROP_TO_EXIT
        
        all_results = []
        baseline_cagr = None
        baseline_sharpe = None
        
        # =====================================================================
        # LOAD DATA ONCE FOR ALL TESTS (CRITICAL OPTIMIZATION)
        # =====================================================================
        print("="*80)
        print("💾 LOADING DATA (ONCE - Will be reused for all tests)")
        print("="*80)
        
        # Load data once and cache
        cached_stocks, cached_benchmark, cached_benchmark_daily = self.load_backtest_data(universe_df)
        
        if not cached_stocks or cached_benchmark.empty:
            print("❌ Could not load data - test ABORTED")
            return {
                'overall_verdict': 'ERROR',
                'score_verdict': 'N/A',
                'stop_verdict': 'N/A',
                'persist_verdict': 'N/A',
                'rebal_verdict': 'N/A',
                'all_results': [],
                'baseline_cagr': None,
                'baseline_sharpe': None
            }
        
        print(f"✅ Data cached - Ready for {sum([TEST_SCORE_THRESHOLDS, TEST_STOP_LOSSES, TEST_PERSISTENCE, TEST_REBALANCE_FREQUENCY])} test(s)\n")
        cached_data = (cached_stocks, cached_benchmark, cached_benchmark_daily)
        
        # =====================================================================
        # TEST 1: SCORE THRESHOLDS (Primary Risk)
        # =====================================================================
        if TEST_SCORE_THRESHOLDS:
            print("="*80)
            print("🎯 TEST 1: SCORE THRESHOLD SENSITIVITY")
            print("="*80)
            print("\n   Testing if 185-273 range is overfitted...")
            print("   Current: MIN=185, MAX=273\n")
            
            score_tests = [
                (175, 265, "-10, -8"),
                (180, 270, "-5, -3"),
                (185, 273, "BASELINE (current)"),
                (190, 280, "+5, +7"),
                (195, 285, "+10, +12"),
                (200, 290, "+15, +17"),
            ]
            
            score_results = []
            
            for i, (min_score, max_score, label) in enumerate(score_tests):
                print(f"   Run {i+1}/6: Testing MIN={min_score}, MAX={max_score} ({label})...")
                
                # Modify global parameters (already declared at function start)
                MIN_SCORE_THRESHOLD = min_score
                MAX_SCORE_THRESHOLD = max_score
                
                # Run backtest with suppressed output
                import sys, io
                original_stdout = sys.stdout
                sys.stdout = io.StringIO()
                
                try:
                    test_backtester = RRGBacktester(API_KEY, ACCESS_TOKEN)
                    results = test_backtester.run_backtest(universe_df)
                    
                    if not results.empty:
                        metrics = test_backtester.calculate_performance_metrics(results)
                        
                        result = {
                            'test': 'score_threshold',
                            'min_score': min_score,
                            'max_score': max_score,
                            'label': label,
                            'cagr': metrics.get('cagr_pct', 0),
                            'sharpe': metrics.get('sharpe_ratio', 0),
                            'max_dd': metrics.get('max_drawdown_pct', 0),
                            'num_trades': len(test_backtester.trade_log)
                        }
                        
                        score_results.append(result)
                        all_results.append(result)
                        
                        if min_score == 185 and max_score == 273:
                            baseline_cagr = result['cagr']
                            baseline_sharpe = result['sharpe']
                
                except Exception as e:
                    pass
                finally:
                    sys.stdout = original_stdout
                
                # Show progress
                if score_results:
                    latest = score_results[-1]
                    print(f"      → CAGR: {latest['cagr']:.2f}%, Sharpe: {latest['sharpe']:.2f}, Trades: {latest['num_trades']}")
            
            # Restore parameters
            MIN_SCORE_THRESHOLD = original_min_score
            MAX_SCORE_THRESHOLD = original_max_score
            
            # Analyze results
            print(f"\n   {'='*80}")
            print(f"   SCORE THRESHOLD RESULTS:")
            print(f"   {'='*80}")
            print(f"   {'Min':<5} {'Max':<5} {'CAGR':<10} {'Sharpe':<8} {'Max DD':<10} {'Trades':<8} {'Status'}")
            print(f"   {'-'*80}")
            
            for r in score_results:
                status = ""
                if r['label'] == "BASELINE (current)":
                    status = "📍 CURRENT"
                elif baseline_cagr and r['cagr'] < baseline_cagr * 0.7:
                    status = "⚠️ COLLAPSE"
                elif baseline_cagr and r['cagr'] < baseline_cagr * 0.85:
                    status = "⚠️ WEAK"
                elif baseline_cagr and r['cagr'] > baseline_cagr * 1.05:
                    status = "🎯 BETTER"
                
                print(f"   {r['min_score']:<5} {r['max_score']:<5} {r['cagr']:<10.2f} "
                      f"{r['sharpe']:<8.2f} {r['max_dd']:<10.2f} {r['num_trades']:<8} {status}")
            
            # Calculate stability metrics
            cagrs = [r['cagr'] for r in score_results]
            sharpes = [r['sharpe'] for r in score_results]
            
            cagr_range = max(cagrs) - min(cagrs)
            cagr_std = np.std(cagrs)
            cagr_cv = (cagr_std / np.mean(cagrs)) * 100 if np.mean(cagrs) > 0 else 0
            
            print(f"\n   STABILITY METRICS:")
            print(f"      CAGR Range: {cagr_range:.2f}% (Max - Min)")
            print(f"      CAGR Std Dev: {cagr_std:.2f}%")
            print(f"      Coefficient of Variation: {cagr_cv:.1f}%")
            print(f"      Baseline CAGR: {baseline_cagr:.2f}%")
            
            # Kohei's interpretation for score thresholds
            print(f"\n   VERDICT:")
            if cagr_range < 10:
                print(f"      ✅ PLATEAU: Stable across score ranges")
                print(f"      → Strategy is ROBUST - not overfit to exact thresholds")
                print(f"      → Safe to proceed to live trading")
                score_verdict = "PASS"
            elif cagr_range < 20:
                print(f"      ⚠️  MODERATE SENSITIVITY: Some instability")
                print(f"      → Edge exists but parameter choice matters")
                print(f"      → Acceptable for live trading with caution")
                score_verdict = "MARGINAL"
            else:
                print(f"      ❌ PEAK: Highly sensitive to exact parameters")
                print(f"      → Classic overfitting - parameters mined from historical data")
                print(f"      → Will likely fail in live trading")
                score_verdict = "FAIL"
        
        # =====================================================================
        # TEST 2: STOP LOSS LEVELS
        # =====================================================================
        if TEST_STOP_LOSSES:
            print(f"\n{'='*80}")
            print("🛡️  TEST 2: STOP LOSS SENSITIVITY")
            print(f"{'='*80}")
            print(f"\n   Testing if 15% stop loss is critical...")
            print(f"   Current: 15%\n")
            
            stop_tests = [
                (0.10, "10% (tighter)"),
                (0.12, "12%"),
                (0.15, "15% BASELINE"),
                (0.18, "18%"),
                (0.20, "20% (looser)"),
            ]
            
            stop_results = []
            
            for i, (stop_pct, label) in enumerate(stop_tests):
                print(f"   Run {i+1}/5: Testing stop loss = {stop_pct*100}% ({label})...")
                
                # Modify global parameter (already declared at function start)
                STOCK_STOP_LOSS_PCT = stop_pct
                
                import sys, io
                original_stdout = sys.stdout
                sys.stdout = io.StringIO()
                
                try:
                    test_backtester = RRGBacktester(API_KEY, ACCESS_TOKEN)
                    results = test_backtester.run_backtest(universe_df)
                    
                    if not results.empty:
                        metrics = test_backtester.calculate_performance_metrics(results)
                        
                        result = {
                            'test': 'stop_loss',
                            'stop_pct': stop_pct * 100,
                            'label': label,
                            'cagr': metrics.get('cagr_pct', 0),
                            'sharpe': metrics.get('sharpe_ratio', 0),
                            'max_dd': metrics.get('max_drawdown_pct', 0),
                            'num_trades': len(test_backtester.trade_log)
                        }
                        
                        stop_results.append(result)
                        all_results.append(result)
                
                except Exception as e:
                    pass
                finally:
                    sys.stdout = original_stdout
                
                if stop_results:
                    latest = stop_results[-1]
                    print(f"      → CAGR: {latest['cagr']:.2f}%, Sharpe: {latest['sharpe']:.2f}, Max DD: {latest['max_dd']:.2f}%")
            
            # Restore parameter
            STOCK_STOP_LOSS_PCT = original_stop_loss
            
            # Analyze results
            print(f"\n   {'='*80}")
            print(f"   STOP LOSS RESULTS:")
            print(f"   {'='*80}")
            print(f"   {'Stop %':<8} {'CAGR':<10} {'Sharpe':<8} {'Max DD':<10} {'Trades':<8} {'Status'}")
            print(f"   {'-'*70}")
            
            for r in stop_results:
                status = ""
                if "BASELINE" in r['label']:
                    status = "📍 CURRENT"
                elif baseline_cagr and r['cagr'] > baseline_cagr * 1.05:
                    status = "🎯 BETTER"
                
                print(f"   {r['stop_pct']:<8.1f} {r['cagr']:<10.2f} "
                      f"{r['sharpe']:<8.2f} {r['max_dd']:<10.2f} {r['num_trades']:<8} {status}")
            
            stop_cagrs = [r['cagr'] for r in stop_results]
            stop_range = max(stop_cagrs) - min(stop_cagrs)
            
            print(f"\n   VERDICT:")
            if stop_range < 15:
                print(f"      ✅ STABLE: Stop loss choice is not critical (Range: {stop_range:.2f}%)")
                stop_verdict = "PASS"
            else:
                print(f"      ⚠️  SENSITIVE: Stop loss matters (Range: {stop_range:.2f}%)")
                stop_verdict = "MARGINAL"
        
        # =====================================================================
        # TEST 3: PERSISTENCE THRESHOLD
        # =====================================================================
        if TEST_PERSISTENCE:
            print(f"\n{'='*80}")
            print("🔒 TEST 3: PERSISTENCE THRESHOLD SENSITIVITY (FINE-GRAINED)")
            print(f"{'='*80}")
            print(f"\n   Testing if 40-point threshold is a PEAK or PLATEAU...")
            print(f"   Current: 40 points")
            print(f"   USER CONCERN: Is 40 overfitted? (Previous test: 40=69.30%, 35=58.95%)")
            print(f"   Testing nearby values (35, 37, 40, 43, 45, 50) with finer granularity\n")
            
            persist_tests = [
                (30, "30 points"),
                (35, "35 points"),
                (37, "37 points"),
                (40, "40 points (PEAK?)"),
                (43, "43 points"),
                (45, "45 points"),
                (50, "50 points"),
            ]
            
            persist_results = []
            persist_verdict = "N/A"  # Initialize verdict
            
            for i, (threshold, label) in enumerate(persist_tests):
                print(f"   Run {i+1}/{len(persist_tests)}: Testing persistence = {threshold} pts ({label})...")
                
                # Modify global parameter (already declared at function start)
                MIN_SCORE_DROP_TO_EXIT = threshold
                
                import sys, io
                original_stdout = sys.stdout
                sys.stdout = io.StringIO()
                
                try:
                    test_backtester = RRGBacktester(API_KEY, ACCESS_TOKEN)
                    # Use cached data (FAST - no API calls)
                    results = test_backtester.run_backtest(universe_df, cached_data=cached_data)
                    
                    if not results.empty:
                        metrics = test_backtester.calculate_performance_metrics(results)
                        
                        result = {
                            'test': 'persistence',
                            'threshold': threshold,
                            'label': label,
                            'cagr': metrics.get('cagr_pct', 0),
                            'sharpe': metrics.get('sharpe_ratio', 0),
                            'max_dd': metrics.get('max_drawdown_pct', 0),
                            'num_trades': len(test_backtester.trade_log)
                        }
                        
                        persist_results.append(result)
                        all_results.append(result)
                
                except Exception as e:
                    # Show first error for debugging
                    if i == 0:
                        sys.stdout = original_stdout
                        print(f"      ❌ Test failed: {str(e)}")
                        import traceback
                        traceback.print_exc()
                        sys.stdout = io.StringIO()
                finally:
                    sys.stdout = original_stdout
                
                if persist_results:
                    latest = persist_results[-1]
                    print(f"      → CAGR: {latest['cagr']:.2f}%, Sharpe: {latest['sharpe']:.2f}, Trades: {latest['num_trades']}")
            
            # Restore parameter
            MIN_SCORE_DROP_TO_EXIT = original_persistence
            
            # Analyze results
            print(f"\n   {'='*80}")
            print(f"   PERSISTENCE RESULTS:")
            print(f"   {'='*80}")
            print(f"   {'Threshold':<12} {'CAGR':<10} {'Sharpe':<8} {'Trades':<8} {'Status'}")
            print(f"   {'-'*70}")
            
            # Check if we have results first
            if not persist_results:
                print(f"\n   ❌ ERROR: All persistence tests failed")
                print(f"      No successful backtests - cannot analyze")
                persist_verdict = "ERROR"
            else:
                persist_cagrs = [r['cagr'] for r in persist_results]
                persist_range = max(persist_cagrs) - min(persist_cagrs) if persist_cagrs else 0
                
                # Find the test result for 40 points for status display
                result_40 = next((r for r in persist_results if r['threshold'] == 40), None)
                baseline_persist_cagr = result_40['cagr'] if result_40 else None
                
                # Display results
                for r in persist_results:
                    status = ""
                    if r['threshold'] == 40:
                        status = "📍 CURRENT"
                    elif baseline_persist_cagr and r['cagr'] > baseline_persist_cagr * 1.05:
                        status = "🎯 BETTER"
                    elif baseline_persist_cagr and r['cagr'] < baseline_persist_cagr * 0.90:
                        status = "⚠️ COLLAPSE"
                    
                    print(f"   {r['threshold']:<12} {r['cagr']:<10.2f} "
                          f"{r['sharpe']:<8.2f} {r['num_trades']:<8} {status}")
            
            if persist_verdict != "ERROR" and persist_results:
                # Find the test result for 40 points
                result_40 = next((r for r in persist_results if r['threshold'] == 40), None)
                baseline_persist_cagr = result_40['cagr'] if result_40 else None
                
                print(f"\n   VERDICT:")
                
                # Check if 40 is a PEAK or PLATEAU
                if baseline_persist_cagr:
                    # Get CAGRs for values near 40 (35-45 range)
                    nearby_cagrs = [r['cagr'] for r in persist_results if 35 <= r['threshold'] <= 45]
                    nearby_range = max(nearby_cagrs) - min(nearby_cagrs) if len(nearby_cagrs) > 1 else 0
                    
                    # Check if 40 is significantly better than neighbors
                    neighbor_avg = np.mean([r['cagr'] for r in persist_results if r['threshold'] in [35, 37, 43, 45]])
                    performance_above_neighbors = ((baseline_persist_cagr - neighbor_avg) / neighbor_avg * 100) if neighbor_avg > 0 else 0
                    
                    if performance_above_neighbors > 15:
                        print(f"      ❌ PEAK DETECTED: 40 points is {performance_above_neighbors:.1f}% better than neighbors")
                        print(f"      → This is classic overfitting - you mined the single best value")
                        print(f"      → Values near 40 (35-45): {nearby_range:.2f}% CAGR range")
                        print(f"      → 40 is NOT a plateau, it's a PEAK")
                        print(f"      → RECOMMENDATION: Use conservative value (35) or accept overfitting risk")
                        persist_verdict = "FAIL"
                    elif nearby_range < 5:
                        print(f"      ✅ PLATEAU: Values 35-45 are stable (Range: {nearby_range:.2f}%)")
                        print(f"      → 40 is not a peak, it's in a robust range")
                        print(f"      → Strategy will work with 37-43 points similarly")
                        persist_verdict = "PASS"
                    elif nearby_range < 10:
                        print(f"      ⚠️  MODERATE: Some sensitivity near 40 (Range: {nearby_range:.2f}%)")
                        print(f"      → 40 performs {performance_above_neighbors:.1f}% better than neighbors")
                        print(f"      → Acceptable but not ideal")
                        persist_verdict = "MARGINAL"
                    else:
                        print(f"      ❌ PEAK: High sensitivity around 40 (Range: {nearby_range:.2f}%)")
                        print(f"      → Value 40 is curve-fitted")
                        persist_verdict = "FAIL"
                else:
                    # Fallback to range-based check
                    if persist_range < 10:
                        print(f"      ✅ STABLE: Persistence threshold is not critical (Range: {persist_range:.2f}%)")
                        persist_verdict = "PASS"
                    else:
                        print(f"      ⚠️  SENSITIVE: Persistence matters (Range: {persist_range:.2f}%)")
                        persist_verdict = "MARGINAL"
        
        # =====================================================================
        # TEST 4: REBALANCE FREQUENCY
        # =====================================================================
        if TEST_REBALANCE_FREQUENCY:
            print(f"\n{'='*80}")
            print("📅 TEST 4: REBALANCE FREQUENCY SENSITIVITY")
            print(f"{'='*80}")
            print(f"\n   Testing if quarterly (4x/year) vs monthly (12x/year) is critical...")
            print(f"   Current: Quarterly\n")
            
            rebal_tests = [
                ('quarterly', "Quarterly (4x/year) BASELINE"),
                ('monthly', "Monthly (12x/year)"),
            ]
            
            rebal_results = []
            
            for i, (freq, label) in enumerate(rebal_tests):
                print(f"   Run {i+1}/2: Testing rebalance = {freq} ({label})...")
                
                # Modify global parameter (already declared at function start)
                global REBALANCE_FREQUENCY
                REBALANCE_FREQUENCY = freq
                
                import sys, io
                original_stdout = sys.stdout
                sys.stdout = io.StringIO()
                
                try:
                    test_backtester = RRGBacktester(API_KEY, ACCESS_TOKEN)
                    results = test_backtester.run_backtest(universe_df)
                    
                    if not results.empty:
                        metrics = test_backtester.calculate_performance_metrics(results)
                        
                        result = {
                            'test': 'rebalance_frequency',
                            'frequency': freq,
                            'label': label,
                            'cagr': metrics.get('cagr_pct', 0),
                            'sharpe': metrics.get('sharpe_ratio', 0),
                            'max_dd': metrics.get('max_drawdown_pct', 0),
                            'num_trades': len(test_backtester.trade_log),
                            'turnover': metrics.get('avg_turnover_pct', 0)
                        }
                        
                        rebal_results.append(result)
                        all_results.append(result)
                
                except Exception as e:
                    pass
                finally:
                    sys.stdout = original_stdout
                
                if rebal_results:
                    latest = rebal_results[-1]
                    print(f"      → CAGR: {latest['cagr']:.2f}%, Sharpe: {latest['sharpe']:.2f}, Trades: {latest['num_trades']}, Turnover: {latest['turnover']:.1f}%")
            
            # Restore parameter
            REBALANCE_FREQUENCY = 'quarterly'
            
            # Analyze results
            print(f"\n   {'='*80}")
            print(f"   REBALANCE FREQUENCY RESULTS:")
            print(f"   {'='*80}")
            print(f"   {'Frequency':<12} {'CAGR':<10} {'Sharpe':<8} {'Max DD':<10} {'Trades':<8} {'Turnover':<10} {'Status'}")
            print(f"   {'-'*90}")
            
            for r in rebal_results:
                status = ""
                if "BASELINE" in r['label']:
                    status = "📍 CURRENT"
                elif baseline_cagr and r['cagr'] > baseline_cagr * 1.05:
                    status = "🎯 BETTER"
                
                print(f"   {r['frequency']:<12} {r['cagr']:<10.2f} "
                      f"{r['sharpe']:<8.2f} {r['max_dd']:<10.2f} {r['num_trades']:<8} {r['turnover']:<10.1f} {status}")
            
            rebal_cagrs = [r['cagr'] for r in rebal_results]
            rebal_range = max(rebal_cagrs) - min(rebal_cagrs) if len(rebal_cagrs) > 1 else 0
            
            print(f"\n   VERDICT:")
            if rebal_range < 10:
                print(f"      ✅ STABLE: Rebalance frequency not critical (Range: {rebal_range:.2f}%)")
                print(f"      → Both quarterly and monthly work similarly")
                print(f"      → Use quarterly for lower costs")
                rebal_verdict = "PASS"
            elif rebal_results[0]['cagr'] > rebal_results[1]['cagr']:
                print(f"      ✅ QUARTERLY WINS: Quarterly outperforms monthly by {rebal_range:.2f}%")
                print(f"      → Quarterly: {rebal_results[0]['cagr']:.2f}% CAGR, {rebal_results[0]['num_trades']} trades")
                print(f"      → Monthly: {rebal_results[1]['cagr']:.2f}% CAGR, {rebal_results[1]['num_trades']} trades")
                print(f"      → Persistence logic works better with quarterly")
                rebal_verdict = "PASS"
            else:
                print(f"      ⚠️  MONTHLY BETTER: Monthly outperforms quarterly by {rebal_range:.2f}%")
                print(f"      → Consider switching to monthly rebalancing")
                print(f"      → May need to adjust persistence thresholds")
                rebal_verdict = "MARGINAL"
        
        # =====================================================================
        # FINAL VERDICT
        # =====================================================================
        print(f"\n{'='*80}")
        print("🎯 FINAL VERDICT - PARAMETER PLATEAU TEST")
        print(f"{'='*80}\n")
        
        if TEST_SCORE_THRESHOLDS:
            print(f"   Score Thresholds: {score_verdict}")
        if TEST_STOP_LOSSES:
            print(f"   Stop Losses: {stop_verdict}")
        if TEST_PERSISTENCE:
            print(f"   Persistence: {persist_verdict}")
        if TEST_REBALANCE_FREQUENCY:
            print(f"   Rebalance Frequency: {rebal_verdict}")
        
        # Overall assessment
        verdicts = []
        if TEST_SCORE_THRESHOLDS:
            verdicts.append(score_verdict)
        if TEST_STOP_LOSSES:
            verdicts.append(stop_verdict)
        if TEST_PERSISTENCE:
            verdicts.append(persist_verdict)
        if TEST_REBALANCE_FREQUENCY:
            verdicts.append(rebal_verdict)
        
        if 'FAIL' in verdicts:
            overall = 'FAIL'
            print(f"\n   ❌ OVERALL: OVERFITTED")
            print(f"      → Strategy is curve-fitted to specific parameters")
            print(f"      → Will likely fail in live trading")
            print(f"      → RECOMMENDATION: Simplify strategy, use wider parameter ranges")
        elif verdicts.count('MARGINAL') >= 2:
            overall = 'MARGINAL'
            print(f"\n   ⚠️  OVERALL: MODERATE ROBUSTNESS")
            print(f"      → Some parameter sensitivity exists")
            print(f"      → Acceptable but not ideal")
            print(f"      → RECOMMENDATION: Monitor live performance closely")
        else:
            overall = 'PASS'
            print(f"\n   ✅ OVERALL: ROBUST STRATEGY")
            print(f"      → Performance is stable across parameter variations")
            print(f"      → Not overfitted - likely to work in live trading")
            print(f"      → RECOMMENDATION: Proceed with confidence")
        
        print(f"\n{'='*80}\n")
        
        return {
            'overall_verdict': overall,
            'score_verdict': score_verdict if TEST_SCORE_THRESHOLDS else 'N/A',
            'stop_verdict': stop_verdict if TEST_STOP_LOSSES else 'N/A',
            'persist_verdict': persist_verdict if TEST_PERSISTENCE else 'N/A',
            'rebal_verdict': rebal_verdict if TEST_REBALANCE_FREQUENCY else 'N/A',
            'all_results': all_results,
            'baseline_cagr': baseline_cagr,
            'baseline_sharpe': baseline_sharpe
        }
    
    # =========================================================================
    # YAMADA FRAMEWORK - DELAYED ENTRY TEST
    # =========================================================================
    
    def run_delayed_entry_test(self, universe_df: pd.DataFrame, delay_days_list: List[int]) -> Dict:
        """
        Test impact of delayed execution on strategy performance
        Real-world: Takes time from signal generation to order execution
        
        Tests if alpha decays when entering 7, 14, 21 days after quarter-end
        """
        print("\n" + "="*80)
        print("⏰ YAMADA FRAMEWORK - DELAYED ENTRY TEST")
        print("="*80)
        print("\n🔬 EXECUTION REALITY CHECK")
        print("   This test answers: 'Does alpha decay with delayed execution?'")
        print("   Real world: Takes time to analyze, approve, and place orders\n")
        print(f"   Testing delays: {delay_days_list} days after quarter-end")
        print(f"   Baseline (0 days) is current validated strategy\n")
        
        # Declare global for modification
        global ENTRY_DELAY_DAYS
        
        delay_results = []
        baseline_cagr = None
        baseline_sharpe = None
        
        for delay_days in delay_days_list:
            print(f"{'='*80}")
            print(f"⏰ TEST: {delay_days}-DAY DELAYED ENTRY")
            print(f"{'='*80}")
            
            if delay_days == 0:
                print(f"\n   Running BASELINE (immediate entry on quarter-end)...")
            else:
                print(f"\n   Running with {delay_days}-day delay (enter {delay_days} days after quarter-end)...")
            
            # Set delay (already declared as global at function start)
            ENTRY_DELAY_DAYS = delay_days
            
            # Suppress detailed output
            import sys, io
            original_stdout = sys.stdout
            sys.stdout = io.StringIO()
            
            try:
                # Create fresh backtester instance
                test_backtester = RRGBacktester(API_KEY, ACCESS_TOKEN)
                
                # Run standard backtest (will use ENTRY_DELAY_DAYS)
                results = test_backtester.run_backtest(universe_df)
                
                if not results.empty:
                    metrics = test_backtester.calculate_performance_metrics(results)
                    
                    result = {
                        'delay_days': delay_days,
                        'label': 'BASELINE (0 days)' if delay_days == 0 else f'{delay_days}-day delay',
                        'cagr': metrics.get('cagr_pct', 0),
                        'sharpe': metrics.get('sharpe_ratio', 0),
                        'max_dd': metrics.get('max_drawdown_pct', 0),
                        'total_return': metrics.get('total_return_pct', 0),
                        'num_trades': len(test_backtester.trade_log),
                        'win_rate': metrics.get('win_rate_pct', 0)
                    }
                    
                    delay_results.append(result)
                    
                    if delay_days == 0:
                        baseline_cagr = result['cagr']
                        baseline_sharpe = result['sharpe']
                
            except Exception as e:
                pass  # Silent error handling during Monte Carlo
            finally:
                sys.stdout = original_stdout
            
            # Restore original delay
            ENTRY_DELAY_DAYS = 0
            
            if delay_results and delay_results[-1]['delay_days'] == delay_days:
                latest = delay_results[-1]
                print(f"      → CAGR: {latest['cagr']:.2f}%, Sharpe: {latest['sharpe']:.2f}, Max DD: {latest['max_dd']:.2f}%")
        
        # Analyze results
        print(f"\n{'='*80}")
        print("📊 DELAYED ENTRY RESULTS:")
        print(f"{'='*80}")
        print(f"   {'Delay (days)':<15} {'CAGR':<10} {'Sharpe':<8} {'Max DD':<10} {'Trades':<8} {'Alpha Decay':<12} {'Status'}")
        print(f"   {'-'*95}")
        
        for r in delay_results:
            alpha_decay = ((baseline_cagr - r['cagr']) / baseline_cagr * 100) if baseline_cagr else 0
            status = ""
            
            if r['delay_days'] == 0:
                status = "📍 BASELINE"
            elif alpha_decay < 5:
                status = "✅ MINIMAL"
            elif alpha_decay < 10:
                status = "⚠️ MODERATE"
            else:
                status = "❌ SEVERE"
            
            print(f"   {r['delay_days']:<15} {r['cagr']:<10.2f} "
                  f"{r['sharpe']:<8.2f} {r['max_dd']:<10.2f} {r['num_trades']:<8} "
                  f"{alpha_decay:<12.1f}% {status}")
        
        # Calculate average alpha decay
        alpha_decays = [((baseline_cagr - r['cagr']) / baseline_cagr * 100) 
                       for r in delay_results if r['delay_days'] > 0]
        avg_alpha_decay = np.mean(alpha_decays) if alpha_decays else 0
        
        print(f"\n   ANALYSIS:")
        print(f"      Baseline CAGR: {baseline_cagr:.2f}%")
        print(f"      Average Alpha Decay: {avg_alpha_decay:.2f}%")
        
        # Kohei Yamada's interpretation
        print(f"\n   VERDICT:")
        if avg_alpha_decay < 5:
            print(f"      ✅ EXCELLENT: Strategy is robust to delayed execution")
            print(f"      → <5% alpha decay even with 21-day delay")
            print(f"      → Your 40-point persistence + quarterly horizon protects alpha")
            print(f"      → Safe to take 1-2 weeks to analyze and execute")
            verdict = "PASS"
        elif avg_alpha_decay < 10:
            print(f"      ⚠️  ACCEPTABLE: Moderate alpha decay with delays")
            print(f"      → 5-10% alpha decay is typical for momentum strategies")
            print(f"      → Try to execute within 7-10 days of quarter-end")
            print(f"      → Still workable, but faster is better")
            verdict = "MARGINAL"
        else:
            print(f"      ❌ CONCERNING: Significant alpha decay with delays")
            print(f"      → >10% alpha decay suggests strategy is timing-sensitive")
            print(f"      → May need tighter execution discipline")
            print(f"      → Consider automated execution")
            verdict = "FAIL"
        
        print(f"\n{'='*80}\n")
        
        return {
            'verdict': verdict,
            'baseline_cagr': baseline_cagr,
            'baseline_sharpe': baseline_sharpe,
            'avg_alpha_decay': avg_alpha_decay,
            'delay_results': delay_results
        }
    
    # =========================================================================
    # YAMADA FRAMEWORK - OUTLIER DEPENDENCY TEST
    # =========================================================================
    
    def run_outlier_dependency_test(self) -> Dict:
        """
        Test if strategy CAGR depends on rare lucky trades (outliers)
        Removes top/bottom 5% of trades and recalculates performance
        
        Critical for small sample sizes (48 trades = 2.4 outliers each side)
        """
        print("\n" + "="*80)
        print("📊 YAMADA FRAMEWORK - OUTLIER DEPENDENCY TEST")
        print("="*80)
        print("\n🔬 LUCK vs SKILL TEST")
        print("   This test answers: 'Does my CAGR depend on lucky outliers?'")
        print("   Removes top/bottom 5% of trades and recalculates metrics\n")
        
        if not self.trade_log:
            print("❌ No trade log available - run backtest first")
            return {'verdict': 'ERROR'}
        
        # Get all trade returns
        trade_returns = [t['return_pct'] for t in self.trade_log]
        num_trades = len(trade_returns)
        sorted_returns = sorted(trade_returns, reverse=True)
        
        # Calculate outlier count (5% each side)
        outlier_count = max(1, int(num_trades * OUTLIER_PERCENTILE / 100))
        
        print(f"   Total Trades: {num_trades}")
        print(f"   Outlier Count (each side): {outlier_count} ({OUTLIER_PERCENTILE}%)")
        print(f"   Analyzing top {outlier_count} and bottom {outlier_count} trades\n")
        
        # Get outliers
        top_outliers = sorted_returns[:outlier_count]
        bottom_outliers = sorted_returns[-outlier_count:]
        
        print(f"📈 TOP {OUTLIER_PERCENTILE}% TRADES (Best {outlier_count} of {num_trades}):")
        for i, ret in enumerate(top_outliers, 1):
            # Find the trade details
            trade = next((t for t in self.trade_log if t['return_pct'] == ret), None)
            if trade:
                print(f"   #{i}: {trade['symbol']:<12} {ret:>8.2f}% (held {trade['holding_days']} days)")
        
        print(f"\n📉 BOTTOM {OUTLIER_PERCENTILE}% TRADES (Worst {outlier_count}):")
        for i, ret in enumerate(bottom_outliers, 1):
            trade = next((t for t in self.trade_log if t['return_pct'] == ret), None)
            if trade:
                print(f"   #{i}: {trade['symbol']:<12} {ret:>8.2f}% (held {trade['holding_days']} days)")
        
        # Calculate metrics without outliers
        filtered_returns = [r for r in trade_returns if r not in top_outliers and r not in bottom_outliers]
        
        # Original metrics (from actual backtest)
        baseline_total_return = np.prod([1 + r/100 for r in trade_returns]) - 1
        baseline_avg_return = np.mean(trade_returns)
        
        # Filtered metrics (without outliers)
        filtered_total_return = np.prod([1 + r/100 for r in filtered_returns]) - 1 if filtered_returns else 0
        filtered_avg_return = np.mean(filtered_returns) if filtered_returns else 0
        
        # Calculate dependency
        dependency_pct = abs(baseline_avg_return - filtered_avg_return) / baseline_avg_return * 100 if baseline_avg_return != 0 else 0
        
        print(f"\n🎯 DEPENDENCY ANALYSIS:")
        print(f"   Full Strategy:")
        print(f"      Avg Trade Return: {baseline_avg_return:.2f}%")
        print(f"      Total Compound: {baseline_total_return*100:.2f}%")
        print()
        print(f"   Without Top/Bottom {OUTLIER_PERCENTILE}% ({outlier_count*2} trades removed):")
        print(f"      Avg Trade Return: {filtered_avg_return:.2f}%")
        print(f"      Total Compound: {filtered_total_return*100:.2f}%")
        print()
        print(f"   Impact of Outliers:")
        print(f"      Avg Return Difference: {baseline_avg_return - filtered_avg_return:.2f}%")
        print(f"      Dependency: {dependency_pct:.1f}% of average return")
        
        # CRITICAL: Test removing JUST the best trade
        best_trade_return = max(trade_returns)
        best_trade = next((t for t in self.trade_log if t['return_pct'] == best_trade_return), None)
        
        without_best = [r for r in trade_returns if r != best_trade_return]
        avg_without_best = np.mean(without_best) if without_best else 0
        best_trade_impact = baseline_avg_return - avg_without_best
        best_trade_dependency = (best_trade_impact / baseline_avg_return * 100) if baseline_avg_return != 0 else 0
        
        print(f"\n🔍 SINGLE BEST TRADE IMPACT:")
        if best_trade:
            print(f"   Best Trade: {best_trade['symbol']} (+{best_trade_return:.2f}%)")
            print(f"   Held: {best_trade['holding_days']} days")
            print(f"   Without this trade:")
            print(f"      Avg Return: {avg_without_best:.2f}% (vs {baseline_avg_return:.2f}%)")
            print(f"      Impact: {best_trade_impact:.2f}% ({best_trade_dependency:.1f}% dependency)")
        
        # Kohei's interpretation
        print(f"\n{'='*80}")
        print("🎯 VERDICT (Kohei Yamada Framework)")
        print(f"{'='*80}\n")
        
        if dependency_pct < 10:
            print(f"   ✅ ROBUST: <10% reliant on outliers ({dependency_pct:.1f}%)")
            print(f"      → Core edge is stable and repeatable")
            print(f"      → Not dependent on lucky trades")
            print(f"      → Expected live performance close to backtest")
            verdict = "PASS"
        elif dependency_pct < 25:
            print(f"   ⚠️  MODERATE DEPENDENCY: 10-25% from outliers ({dependency_pct:.1f}%)")
            print(f"      → Some reliance on outliers but acceptable")
            print(f"      → Live CAGR likely 10-15% lower than backtest")
            print(f"      → Expected: 60-65% CAGR (vs 71% backtest)")
            verdict = "MARGINAL"
        else:
            print(f"   ❌ HIGH DEPENDENCY: >25% from outliers ({dependency_pct:.1f}%)")
            print(f"      → Your CAGR heavily relies on rare lucky trades")
            print(f"      → Not repeatable going forward")
            print(f"      → Expected live CAGR: 50-60% (not 71%)")
            verdict = "FAIL"
        
        # Additional warning for single trade impact
        if best_trade_dependency > 15:
            print(f"\n   ⚠️  SINGLE TRADE WARNING:")
            print(f"      → One trade ({best_trade['symbol']}) contributed {best_trade_dependency:.1f}% to avg return")
            print(f"      → This is a lucky outlier - don't expect to repeat")
            print(f"      → Realistic expectation: {avg_without_best:.2f}% avg return per trade")
        
        print(f"\n{'='*80}\n")
        
        return {
            'verdict': verdict,
            'dependency_pct': dependency_pct,
            'baseline_avg_return': baseline_avg_return,
            'filtered_avg_return': filtered_avg_return,
            'best_trade': best_trade,
            'best_trade_dependency': best_trade_dependency,
            'top_outliers': top_outliers,
            'bottom_outliers': bottom_outliers
        }


def main():
    """Main execution function"""
    try:
        # Initialize backtester
        backtester = RRGBacktester(API_KEY, ACCESS_TOKEN)
        
        # Load universe
        print(f"\n📁 Loading RRG universe from: {DATA_FILE_PATH}")
        
        try:
            universe_df = pd.read_csv(DATA_FILE_PATH)
            universe_df = universe_df.dropna(subset=[SYMBOL_COLUMN, SECTOR_COLUMN])
            universe_df = universe_df.drop_duplicates(subset=[SYMBOL_COLUMN])
            print(f"✅ Loaded {len(universe_df)} stocks from {len(universe_df[SECTOR_COLUMN].unique())} sectors")
        except FileNotFoundError:
            print(f"❌ Error: File '{DATA_FILE_PATH}' not found")
            return
        except Exception as e:
            print(f"❌ Error loading file: {e}")
            return
        
        # =====================================================================
        # YAMADA FRAMEWORK - RANDOM CONTROL TEST (THE KILL SWITCH)
        # =====================================================================
        if RUN_RANDOM_CONTROL_TEST:
            print("\n" + "="*80)
            print("🔬 YAMADA FRAMEWORK - RANDOM CONTROL TEST ENABLED")
            print("="*80)
            print(f"\n⚠️  WARNING: This will run {MONTE_CARLO_RUNS + 1} backtests (~{(MONTE_CARLO_RUNS + 1) * 4} minutes)")
            print("   This is THE test that validates if your RRG edge is real\n")
            
            random_test_results = backtester.run_monte_carlo_random_test(universe_df)
            
            # Save test results
            test_results_file = os.path.join(OUTPUT_DIR, 'random_control_test_results.json')
            with open(test_results_file, 'w') as f:
                # Convert to JSON-serializable format
                json_results = {
                    k: v for k, v in random_test_results.items() 
                    if k != 'all_random_cagrs'
                }
                
                # Only add distribution if we have data
                if random_test_results['all_random_cagrs']:
                    json_results['random_cagrs_distribution'] = {
                        'min': float(min(random_test_results['all_random_cagrs'])),
                        'max': float(max(random_test_results['all_random_cagrs'])),
                        'median': float(np.median(random_test_results['all_random_cagrs'])),
                        'count': len(random_test_results['all_random_cagrs'])
                    }
                else:
                    json_results['random_cagrs_distribution'] = {
                        'error': 'No successful random backtests',
                        'count': 0
                    }
                
                json.dump(json_results, f, indent=2)
            
            print(f"\n💾 Test results saved to: {test_results_file}\n")
            
            # Exit if test fails
            if random_test_results['verdict'] == 'ERROR':
                print("🛑 ERROR: Random control test could not complete")
                print("   Technical issue - check logs above for details")
                print("   Cannot validate edge - test ABORTED\n")
                return
            elif random_test_results['verdict'] == 'FAIL':
                print("🛑 CRITICAL: Random control test FAILED")
                print("   Your strategy has NO EDGE - stopping execution")
                print("   Do NOT proceed to live trading\n")
                return
            elif random_test_results['verdict'] == 'MARGINAL':
                print("⚠️  WARNING: Random control test shows MARGINAL edge")
                print("   Proceed with extreme caution\n")
            else:
                print("✅ Random control test PASSED - Your edge is validated")
                print("   Proceeding with standard backtest...\n")
            
            # Exit after test (don't run normal backtest again)
            print("="*80)
            print("RRG Backtester - Random Control Test Complete")
            print("="*80)
            return
        
        # =====================================================================
        # YAMADA FRAMEWORK - PARAMETER PLATEAU TEST (OVERFITTING DETECTOR)
        # =====================================================================
        if RUN_PLATEAU_TEST:
            print("\n" + "="*80)
            print("🔬 YAMADA FRAMEWORK - PARAMETER PLATEAU TEST ENABLED")
            print("="*80)
            print("\n⚠️  WARNING: This will run 7 backtests (~25-30 minutes)")
            print("   Testing: Persistence threshold fine-grain (30, 35, 37, 40, 43, 45, 50)")
            print("   Purpose: Verify if 40 is a PEAK (overfitted) or PLATEAU (robust)\n")
            print("   USER FEEDBACK: 40 might be curve-fitted - need to validate\n")
            
            plateau_test_results = backtester.run_parameter_plateau_test(universe_df)
            
            # Save test results
            test_results_file = os.path.join(OUTPUT_DIR, 'plateau_test_results.json')
            with open(test_results_file, 'w') as f:
                # Convert to JSON-serializable format
                json_results = {
                    'overall_verdict': plateau_test_results['overall_verdict'],
                    'score_verdict': plateau_test_results['score_verdict'],
                    'stop_verdict': plateau_test_results['stop_verdict'],
                    'persist_verdict': plateau_test_results['persist_verdict'],
                    'rebal_verdict': plateau_test_results['rebal_verdict'],
                    'baseline_cagr': float(plateau_test_results['baseline_cagr']) if plateau_test_results['baseline_cagr'] else None,
                    'baseline_sharpe': float(plateau_test_results['baseline_sharpe']) if plateau_test_results['baseline_sharpe'] else None,
                    'all_results': plateau_test_results['all_results']
                }
                json.dump(json_results, f, indent=2)
            
            print(f"\n💾 Test results saved to: {test_results_file}\n")
            
            # Exit if test fails
            if plateau_test_results['overall_verdict'] == 'FAIL':
                print("🛑 CRITICAL: Parameter plateau test FAILED")
                print("   Your strategy is OVERFITTED to specific parameters")
                print("   Will likely fail in live trading - DO NOT PROCEED\n")
                return
            elif plateau_test_results['overall_verdict'] == 'MARGINAL':
                print("⚠️  WARNING: Parameter plateau test shows MODERATE robustness")
                print("   Some parameter sensitivity exists")
                print("   Monitor live performance closely\n")
            else:
                print("✅ Parameter plateau test PASSED - Strategy is robust")
                print("   Performance stable across parameter variations\n")
            
            # Exit after test
            print("="*80)
            print("RRG Backtester - Parameter Plateau Test Complete")
            print("="*80)
            return
        
        # =====================================================================
        # YAMADA FRAMEWORK - DELAYED ENTRY TEST (EXECUTION REALITY CHECK)
        # =====================================================================
        if RUN_DELAYED_ENTRY_TEST:
            print("\n" + "="*80)
            print("⏰ YAMADA FRAMEWORK - DELAYED ENTRY TEST ENABLED")
            print("="*80)
            print("\n⚠️  WARNING: This will run 4 backtests (~12-16 minutes)")
            print(f"   Testing delays: {DELAY_DAYS} days after quarter-end")
            print("   This measures alpha decay from delayed execution\n")
            
            delayed_entry_results = backtester.run_delayed_entry_test(universe_df, DELAY_DAYS)
            
            # Save test results
            test_results_file = os.path.join(OUTPUT_DIR, 'delayed_entry_test_results.json')
            with open(test_results_file, 'w') as f:
                # Convert to JSON-serializable format
                json_results = {
                    'verdict': delayed_entry_results['verdict'],
                    'baseline_cagr': float(delayed_entry_results['baseline_cagr']) if delayed_entry_results['baseline_cagr'] else None,
                    'baseline_sharpe': float(delayed_entry_results['baseline_sharpe']) if delayed_entry_results['baseline_sharpe'] else None,
                    'avg_alpha_decay': float(delayed_entry_results['avg_alpha_decay']),
                    'delay_results': delayed_entry_results['delay_results']
                }
                json.dump(json_results, f, indent=2)
            
            print(f"\n💾 Test results saved to: {test_results_file}\n")
            
            # Interpret results
            if delayed_entry_results['verdict'] == 'FAIL':
                print("⚠️  WARNING: Delayed entry test shows SIGNIFICANT alpha decay")
                print("   >10% CAGR degradation with delayed execution")
                print("   RECOMMENDATION: Execute within 7 days of quarter-end")
                print("   Consider automated execution or alerts\n")
            elif delayed_entry_results['verdict'] == 'MARGINAL':
                print("✅ Delayed entry test: ACCEPTABLE")
                print("   5-10% alpha decay is normal for momentum strategies")
                print("   RECOMMENDATION: Execute within 10-14 days of quarter-end\n")
            else:
                print("✅ Delayed entry test: EXCELLENT - Strategy is timing-robust")
                print("   <5% alpha decay even with 21-day delay")
                print("   You can take your time analyzing and executing\n")
            
            # Exit after test
            print("="*80)
            print("RRG Backtester - Delayed Entry Test Complete")
            print("="*80)
            return
        
        # =====================================================================
        # YAMADA FRAMEWORK - OUTLIER DEPENDENCY TEST (LUCK vs SKILL)
        # =====================================================================
        if RUN_OUTLIER_TEST:
            print("\n" + "="*80)
            print("📊 YAMADA FRAMEWORK - OUTLIER DEPENDENCY TEST ENABLED")
            print("="*80)
            print("\n⚠️  This test runs on EXISTING backtest results")
            print("   Analyzing: Trade log from last backtest")
            print("   Purpose: Check if CAGR depends on lucky outlier trades\n")
            print("   USER CONCERN: ANANTRAJ +1196% - is this a lucky outlier?\n")
            
            # First, need to run a backtest to get trade log
            print("🎯 STEP 1: Running baseline backtest to generate trade log...")
            results_df = backtester.run_backtest(universe_df)
            
            if results_df.empty or not backtester.trade_log:
                print("❌ No trade log generated - test ABORTED")
                return
            
            print(f"✅ Generated {len(backtester.trade_log)} trades\n")
            
            # Now run outlier test on the trade log
            print("🎯 STEP 2: Analyzing outlier dependency...")
            outlier_results = backtester.run_outlier_dependency_test()
            
            # Save test results
            test_results_file = os.path.join(OUTPUT_DIR, 'outlier_dependency_test_results.json')
            with open(test_results_file, 'w') as f:
                # Convert to JSON-serializable format
                json_results = {
                    'verdict': outlier_results['verdict'],
                    'dependency_pct': float(outlier_results['dependency_pct']),
                    'baseline_avg_return': float(outlier_results['baseline_avg_return']),
                    'filtered_avg_return': float(outlier_results['filtered_avg_return']),
                    'best_trade_dependency': float(outlier_results['best_trade_dependency']),
                    'top_outliers': outlier_results['top_outliers'],
                    'bottom_outliers': outlier_results['bottom_outliers']
                }
                json.dump(json_results, f, indent=2)
            
            print(f"\n💾 Test results saved to: {test_results_file}\n")
            
            # Interpret results
            if outlier_results['verdict'] == 'FAIL':
                print("🛑 WARNING: Outlier dependency test shows HIGH reliance on lucky trades")
                print("   >25% of your returns come from rare outliers")
                print("   RECOMMENDATION: Expect 50-60% live CAGR (not 71%)")
                print("   This is still excellent, but lower your expectations\n")
            elif outlier_results['verdict'] == 'MARGINAL':
                print("⚠️  Outlier dependency test: MODERATE reliance on outliers")
                print("   10-25% of returns from top/bottom trades")
                print("   RECOMMENDATION: Expect 60-65% live CAGR\n")
            else:
                print("✅ Outlier dependency test: PASSED - Robust edge")
                print("   <10% reliance on outliers - edge is repeatable\n")
            
            # Exit after test
            print("="*80)
            print("RRG Backtester - Outlier Dependency Test Complete")
            print("="*80)
            return
        
        # =====================================================================
        # STANDARD RRG BACKTEST
        # =====================================================================
        # Run backtest
        results_df = backtester.run_backtest(universe_df)
        
        if not results_df.empty:
            # Calculate performance metrics
            metrics = backtester.calculate_performance_metrics(results_df)
            
            # Print summary
            backtester.print_performance_summary(metrics)
            
            # Export results
            backtester.export_results(results_df, metrics)
            
            # Create plots
            backtester.create_performance_plots(results_df)
            
            print("\n" + "="*80)
            print("✅ RRG BACKTEST ANALYSIS COMPLETE")
            print("="*80)
            print(f"\n📁 All results saved to: {OUTPUT_DIR}/")
            
            print(f"\n🎯 KEY TAKEAWAYS:")
            print(f"   {'OUTPERFORMED' if metrics.get('excess_return_pct', 0) > 0 else 'UNDERPERFORMED'} "
                  f"benchmark by {abs(metrics.get('excess_return_pct', 0)):.2f}%")
            print(f"   CAGR: {metrics.get('cagr_pct', 0):.2f}% vs Benchmark: {metrics.get('benchmark_cagr_pct', 0):.2f}%")
            print(f"   Max Drawdown: {metrics.get('max_drawdown_pct', 0):.2f}%")
            print(f"   Sharpe Ratio: {metrics.get('sharpe_ratio', 0):.2f}")
            
            print(f"\n🔧 OPTIMIZATIONS APPLIED:")
            print(f"   ✅ Rebalance: {REBALANCE_FREQUENCY.capitalize()} (reduce turnover)")
            print(f"   ✅ Stop Monitoring: {STOP_MONITORING_FREQUENCY.capitalize()} (protect capital)")
            print(f"   ✅ Stock Stop Loss: {STOCK_STOP_LOSS_PCT*100}% (limit individual losses)")
            if PORTFOLIO_STOP_LOSS_PCT is not None:
                print(f"   ✅ Portfolio Stop: {PORTFOLIO_STOP_LOSS_PCT*100}% (protect against crashes)")
            else:
                print(f"   ⚠️ Portfolio Stop: DISABLED (let positions run)")
            print(f"   ✅ Market Regime Filter: {MIN_MARKET_STRENGTH}/3 conditions to enter")
            print(f"   ✅ Persistence Logic: Hold if score drop < {MIN_SCORE_DROP_TO_EXIT} points")
            print(f"   ✅ Min Portfolio Size: {MIN_PORTFOLIO_STOCKS} stocks (prevent concentration)")
            print(f"   ✅ Adaptive Persistence: Relaxed threshold when < {MIN_PORTFOLIO_STOCKS} stocks")
            print(f"   ✅ Score Filter: {MIN_SCORE_THRESHOLD}-{MAX_SCORE_THRESHOLD} (data-proven range)")
            print(f"   ✅ Sector Filter: Excluded {len(EXCLUDE_SECTORS)} poor sectors")
            print(f"   ✅ Cooldown: {COOLDOWN_MONTHS}-month penalty for losers")
            print(f"   ✅ Benchmark: Nifty 500 (multi-cap comparison)")
            
            print(f"\n📈 PORTFOLIO COMPOSITION:")
            print(f"   Avg Leading Stocks: {metrics.get('avg_leading_stocks', 0):.1f} / 15")
            print(f"   Avg Improving Stocks: {metrics.get('avg_improving_stocks', 0):.1f} / 15")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
    print("\n" + "="*80)
    print("RRG Backtester - Session Complete")
    print("="*80)

