"""
Stage Classification Engine
Classifies stocks into Uptrend, Base Consolidation, Breakout Candidate, etc.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
import logging

from config import config, STAGE_LABELS

logger = logging.getLogger(__name__)

class StageClassifier:
    """Classifies stocks into different market stages based on technical analysis"""
    
    def __init__(self, config_obj=None):
        self.config = config_obj or config
    
    def classify_uptrend_continuation(self, df: pd.DataFrame) -> pd.Series:
        """
        Uptrend_Continuation:
        - MA_short > MA_long AND
        - MA_slope > 0 AND  
        - price > MA_short
        """
        if df.empty:
            return pd.Series([], dtype=bool)
        
        short_ma = f'ma_short_{self.config.MA_SHORT_WEEKS}w'
        long_ma = f'ma_long_{self.config.MA_LONG_WEEKS}w'
        
        conditions = [
            df[short_ma] > df[long_ma],
            df['ma_slope'] > 0,
            df['close'] > df[short_ma]
        ]
        
        return pd.Series([all(cond) for cond in zip(*conditions)], index=df.index)
    
    def classify_base_consolidation(self, df: pd.DataFrame) -> pd.Series:
        """
        Base_Consolidation:
        - range_pct < RANGE_PCT_THRESHOLD (default 20%) AND
        - ATR_shrink true AND
        - vol_spike < 1.0 (volume contraction) AND
        - price inside [range_low, range_high] (not below range_low)
        """
        if df.empty:
            return pd.Series([], dtype=bool)
        
        range_pct_col = f'range_pct_{self.config.RANGE_WEEKS}w'
        range_high_col = f'range_high_{self.config.RANGE_WEEKS}w'
        range_low_col = f'range_low_{self.config.RANGE_WEEKS}w'
        
        conditions = [
            df[range_pct_col] < self.config.RANGE_PCT_THRESHOLD,
            df.get('atr_shrink', pd.Series([False] * len(df), index=df.index)),
            df['vol_spike'] < 1.0,
            (df['close'] >= df[range_low_col]) & (df['close'] <= df[range_high_col])
        ]
        
        return pd.Series([all(cond) for cond in zip(*conditions)], index=df.index)
    
    def classify_base_breakout_candidate(self, df: pd.DataFrame) -> pd.Series:
        """
        Base_Breakout_Candidate:
        - Was in BASE_CONSOLIDATION recently and now:
        - weekly_close > range_high * (1 + breakout_buffer) AND
        - vol_spike >= WEEKLY_VOL_SPIKE (default 1.8) AND
        - RS positive AND
        - MA_short >= MA_long or MA_short trending up
        """
        if df.empty:
            return pd.Series([], dtype=bool)
        
        # First check if it was in consolidation recently (last 4 weeks)
        base_consolidation = self.classify_base_consolidation(df)
        was_in_base = base_consolidation.rolling(window=4).sum() > 0
        
        range_high_col = f'range_high_{self.config.RANGE_WEEKS}w'
        short_ma = f'ma_short_{self.config.MA_SHORT_WEEKS}w'
        long_ma = f'ma_long_{self.config.MA_LONG_WEEKS}w'
        
        # Current breakout conditions
        breakout_conditions = [
            df['close'] > df[range_high_col] * (1 + self.config.BREAKOUT_BUFFER),
            df['vol_spike'] >= self.config.WEEKLY_VOL_SPIKE,
            df.get(f'rs_{self.config.RS_WEEKS}w', pd.Series([1.0] * len(df), index=df.index)) > 1.0,
            (df[short_ma] >= df[long_ma]) | (df['ma_slope'] > 0)
        ]
        
        current_breakout = pd.Series([all(cond) for cond in zip(*breakout_conditions)], index=df.index)
        
        # Combine: was in base AND current breakout
        return was_in_base & current_breakout
    
    def classify_failed_breakout(self, df: pd.DataFrame) -> pd.Series:
        """
        Failed_Breakout:
        - Was a breakout candidate but failed within 2-3 weeks
        - weekly close back under breakout_level
        """
        if df.empty:
            return pd.Series([], dtype=bool)
        
        # Check if breakout failed (close back below breakout level)
        failed_breakout = df['close'] < df['breakout_level']
        
        # Look for recent breakout candidates that failed
        breakout_candidates = self.classify_base_breakout_candidate(df)
        recent_breakout = breakout_candidates.rolling(window=3).sum() > 0
        
        return recent_breakout & failed_breakout
    
    def classify_downtrend(self, df: pd.DataFrame) -> pd.Series:
        """
        Downtrend/Other:
        - MA_short < MA_long AND
        - MA_slope < 0 AND
        - price < MA_short
        """
        if df.empty:
            return pd.Series([], dtype=bool)
        
        short_ma = f'ma_short_{self.config.MA_SHORT_WEEKS}w'
        long_ma = f'ma_long_{self.config.MA_LONG_WEEKS}w'
        
        conditions = [
            df[short_ma] < df[long_ma],
            df['ma_slope'] < 0,
            df['close'] < df[short_ma]
        ]
        
        return pd.Series([all(cond) for cond in zip(*conditions)], index=df.index)
    
    def classify_stage(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Main classification function that assigns stages to each row
        Priority order: Failed Breakout > Breakout > Uptrend > Base > Downtrend
        """
        if df.empty:
            return df
        
        df = df.copy()
        
        # Calculate all stage classifications
        uptrend = self.classify_uptrend_continuation(df)
        base_consolidation = self.classify_base_consolidation(df)
        base_breakout = self.classify_base_breakout_candidate(df)
        failed_breakout = self.classify_failed_breakout(df)
        downtrend = self.classify_downtrend(df)
        
        # Initialize stage column
        df['stage'] = 'OTHER'
        
        # Apply classifications in priority order
        df.loc[failed_breakout, 'stage'] = 'FAILED_BREAKOUT'
        df.loc[base_breakout & ~failed_breakout, 'stage'] = 'BASE_BREAKOUT'
        df.loc[uptrend & ~base_breakout & ~failed_breakout, 'stage'] = 'UPTREND_CONT'
        df.loc[base_consolidation & ~uptrend & ~base_breakout & ~failed_breakout, 'stage'] = 'BASE_CONSOLIDATION'
        df.loc[downtrend & ~base_consolidation & ~uptrend & ~base_breakout & ~failed_breakout, 'stage'] = 'DOWNTREND'
        
        # Add stage labels for readability
        df['stage_label'] = df['stage'].map(STAGE_LABELS)
        
        return df
    
    def get_stage_summary(self, df: pd.DataFrame) -> Dict[str, int]:
        """Get summary count of each stage"""
        if df.empty or 'stage' not in df.columns:
            return {}
        
        return df['stage'].value_counts().to_dict()
    
    def get_latest_stage(self, df: pd.DataFrame) -> str:
        """Get the latest stage for a symbol"""
        if df.empty or 'stage' not in df.columns:
            return 'UNKNOWN'
        
        return df['stage'].iloc[-1]
    
    def get_stage_transitions(self, df: pd.DataFrame) -> List[Dict]:
        """Get stage transitions over time"""
        if df.empty or 'stage' not in df.columns:
            return []
        
        transitions = []
        prev_stage = None
        
        for date, row in df.iterrows():
            current_stage = row['stage']
            if prev_stage is not None and prev_stage != current_stage:
                transitions.append({
                    'date': date,
                    'from_stage': prev_stage,
                    'to_stage': current_stage,
                    'price': row['close']
                })
            prev_stage = current_stage
        
        return transitions
    
    def validate_classification(self, df: pd.DataFrame) -> Dict[str, any]:
        """Validate the classification logic and return diagnostics"""
        if df.empty:
            return {'error': 'Empty dataframe'}
        
        diagnostics = {
            'total_periods': len(df),
            'stages_found': df['stage'].value_counts().to_dict() if 'stage' in df.columns else {},
            'missing_indicators': [],
            'data_quality_issues': []
        }
        
        # Check for required indicators
        required_indicators = [
            f'ma_short_{self.config.MA_SHORT_WEEKS}w',
            f'ma_long_{self.config.MA_LONG_WEEKS}w',
            f'range_high_{self.config.RANGE_WEEKS}w',
            f'range_low_{self.config.RANGE_WEEKS}w',
            'vol_spike',
            'ma_slope'
        ]
        
        for indicator in required_indicators:
            if indicator not in df.columns:
                diagnostics['missing_indicators'].append(indicator)
        
        # Check for data quality issues
        if 'close' in df.columns:
            if df['close'].isna().any():
                diagnostics['data_quality_issues'].append('Missing close prices')
            
            if (df['close'] <= 0).any():
                diagnostics['data_quality_issues'].append('Non-positive close prices')
        
        return diagnostics
