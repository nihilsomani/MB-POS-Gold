"""
Weekly→Daily Scanner - Main Orchestrator
Production-ready scanner that combines all components
"""

import pandas as pd
import numpy as np
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path
import json

from config import config
from data_fetcher import KiteDataFetcher
from technical_indicators import TechnicalIndicators
from stage_classifier import StageClassifier
from scoring_engine import ScoringEngine
from daily_confirmation import DailyConfirmation
from position_sizing import PositionSizing
from csv_output import CSVOutputGenerator

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('scanner.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class WeeklyDailyScanner:
    """Main scanner orchestrator that combines all components"""
    
    def __init__(self, config_obj=None):
        self.config = config_obj or config
        
        # Initialize components
        self.data_fetcher = KiteDataFetcher()
        self.technical_indicators = TechnicalIndicators(self.config)
        self.stage_classifier = StageClassifier(self.config)
        self.scoring_engine = ScoringEngine(self.config)
        self.daily_confirmation = DailyConfirmation(self.config)
        self.position_sizing = PositionSizing(self.config)
        self.csv_output = CSVOutputGenerator(self.config)
        
        # Scanner state
        self.scanner_results = {}
        self.benchmark_data = None
        self.scan_metadata = {}
    
    def run_full_scan(self, symbols: List[str], 
                     account_capital: float = 100000,
                     save_results: bool = True) -> Dict[str, Any]:
        """
        Run the complete weekly→daily scanner
        
        Args:
            symbols: List of symbols to scan
            account_capital: Account capital for position sizing
            save_results: Whether to save results to CSV
        
        Returns:
            Dictionary containing scan results and metadata
        """
        logger.info(f"Starting full scan for {len(symbols)} symbols")
        start_time = datetime.now()
        
        try:
            # Step 1: Fetch benchmark data
            logger.info("Fetching benchmark data...")
            self.benchmark_data = self.data_fetcher.get_benchmark_data()
            
            # Step 2: Fetch historical data for all symbols with simple rate limiting
            logger.info(f"Fetching historical data for {len(symbols)} symbols...")
            logger.info(f"Estimated time: {len(symbols) * 0.35:.0f} seconds ({len(symbols) * 0.35 / 60:.1f} minutes)")
            daily_data = self.data_fetcher.batch_fetch_data(symbols)
            
            # Step 3: Process each symbol
            logger.info("Processing symbols...")
            processed_count = 0
            for symbol in symbols:
                try:
                    if symbol in daily_data and not daily_data[symbol].empty:
                        result = self._process_symbol(symbol, daily_data[symbol], account_capital)
                        if result:
                            self.scanner_results[symbol] = result
                            processed_count += 1
                    else:
                        logger.warning(f"No data available for {symbol}")
                except Exception as e:
                    logger.error(f"Error processing {symbol}: {e}")
                    continue
            
            # Step 4: Generate output
            logger.info("Generating output...")
            output_df = self.csv_output.create_scanner_output(self.scanner_results)
            
            # Step 5: Save results
            if save_results and not output_df.empty:
                output_file = self.csv_output.save_scanner_output(output_df)
                logger.info(f"Results saved to {output_file}")
            
            # Step 6: Generate summary
            scan_summary = self._generate_scan_summary(output_df, start_time)
            
            logger.info(f"Scan completed successfully. Processed {processed_count} symbols")
            return {
                'success': True,
                'processed_symbols': processed_count,
                'total_symbols': len(symbols),
                'output_dataframe': output_df,
                'scanner_results': self.scanner_results,
                'scan_summary': scan_summary,
                'scan_metadata': self.scan_metadata
            }
            
        except Exception as e:
            logger.error(f"Scan failed: {e}")
            return {
                'success': False,
                'error': str(e),
                'processed_symbols': processed_count if 'processed_count' in locals() else 0
            }
        finally:
            # Clean up
            self.data_fetcher.close()
    
    def _process_symbol(self, symbol: str, daily_df: pd.DataFrame, 
                       account_capital: float) -> Optional[Dict[str, Any]]:
        """Process a single symbol through the complete pipeline"""
        try:
            # Step 1: Calculate technical indicators
            weekly_df = self.technical_indicators.calculate_all_indicators(
                daily_df, self.benchmark_data
            )
            
            if weekly_df.empty:
                logger.warning(f"No weekly data for {symbol}")
                return None
            
            # Step 2: Classify stage
            weekly_df = self.stage_classifier.classify_stage(weekly_df)
            latest_stage = self.stage_classifier.get_latest_stage(weekly_df)
            
            # Step 3: Calculate confidence score
            weekly_df = self.scoring_engine.calculate_confidence_score(weekly_df)
            latest_scores = self.scoring_engine.get_score_breakdown(weekly_df)
            
            # Step 4: Daily confirmation (only for breakout candidates)
            confirmation_analysis = None
            if latest_stage in ['BASE_BREAKOUT', 'UPTREND_CONT']:
                latest_weekly = weekly_df.iloc[-1]
                breakout_level = latest_weekly.get('breakout_level', latest_weekly['close'])
                breakout_date = latest_weekly.name
                
                confirmation_analysis = self.daily_confirmation.get_confirmation_summary(
                    daily_df, breakout_level, breakout_date
                )
            
            # Step 5: Position sizing and trade setup
            trade_setup = None
            trade_validation = None
            if latest_stage in ['BASE_BREAKOUT', 'UPTREND_CONT']:
                # Use confirmation price if available
                confirmation_price = None
                if confirmation_analysis and confirmation_analysis['confirmation']['confirmed']:
                    confirmation_price = confirmation_analysis['confirmation']['confirmation_price']
                
                trade_setup = self.position_sizing.calculate_complete_trade_setup(
                    weekly_df, confirmation_price, account_capital
                )
                trade_validation = self.position_sizing.validate_trade_setup(trade_setup)
            
            # Step 6: Compile results
            result = {
                'symbol': symbol,
                'daily_data': daily_df,
                'weekly_data': weekly_df,
                'stage_analysis': {
                    'latest_stage': latest_stage,
                    'stage_summary': self.stage_classifier.get_stage_summary(weekly_df),
                    'stage_transitions': self.stage_classifier.get_stage_transitions(weekly_df)
                },
                'scoring_analysis': latest_scores,
                'confirmation_analysis': confirmation_analysis,
                'trade_setup': trade_setup,
                'trade_validation': trade_validation
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error processing {symbol}: {e}")
            return None
    
    def _generate_scan_summary(self, output_df: pd.DataFrame, 
                              start_time: datetime) -> Dict[str, Any]:
        """Generate comprehensive scan summary"""
        end_time = datetime.now()
        duration = end_time - start_time
        
        summary = {
            'scan_timing': {
                'start_time': start_time.isoformat(),
                'end_time': end_time.isoformat(),
                'duration_seconds': duration.total_seconds(),
                'duration_minutes': duration.total_seconds() / 60
            },
            'data_quality': {
                'total_symbols_processed': len(output_df),
                'symbols_with_data': len(output_df[output_df['confidence_score'] > 0]),
                'data_completeness': len(output_df[output_df['confidence_score'] > 0]) / len(output_df) if len(output_df) > 0 else 0
            }
        }
        
        if not output_df.empty:
            summary.update(self.csv_output.create_summary_report(output_df))
        
        return summary
    
    def run_quick_scan(self, symbols: List[str], 
                      min_confidence: float = 0.5) -> pd.DataFrame:
        """
        Run a quick scan with minimal processing
        
        Args:
            symbols: List of symbols to scan
            min_confidence: Minimum confidence score to include
        
        Returns:
            DataFrame with quick scan results
        """
        logger.info(f"Starting quick scan for {len(symbols)} symbols")
        
        try:
            # Fetch data with simple rate limiting
            daily_data = self.data_fetcher.batch_fetch_data(symbols)
            
            quick_results = []
            for symbol in symbols:
                if symbol in daily_data and not daily_data[symbol].empty:
                    try:
                        # Calculate indicators
                        weekly_df = self.technical_indicators.calculate_all_indicators(
                            daily_data[symbol], self.benchmark_data
                        )
                        
                        if weekly_df.empty:
                            continue
                        
                        # Classify and score
                        weekly_df = self.stage_classifier.classify_stage(weekly_df)
                        weekly_df = self.scoring_engine.calculate_confidence_score(weekly_df)
                        
                        latest = weekly_df.iloc[-1]
                        
                        if latest['confidence_score'] >= min_confidence:
                            quick_results.append({
                                'symbol': symbol,
                                'stage': latest['stage'],
                                'confidence_score': latest['confidence_score'],
                                'confidence_level': latest['confidence_level'],
                                'close': latest['close'],
                                'vol_spike': latest.get('vol_spike', 0),
                                'rs': latest.get(f'rs_{self.config.RS_WEEKS}w', 1.0)
                            })
                    except Exception as e:
                        logger.error(f"Error in quick scan for {symbol}: {e}")
                        continue
            
            return pd.DataFrame(quick_results)
            
        except Exception as e:
            logger.error(f"Quick scan failed: {e}")
            return pd.DataFrame()
        finally:
            self.data_fetcher.close()
    
    def get_top_candidates(self, min_confidence: float = 0.6, 
                          top_n: int = 10) -> pd.DataFrame:
        """Get top N candidates from the last scan"""
        if not self.scanner_results:
            logger.warning("No scan results available. Run a scan first.")
            return pd.DataFrame()
        
        # Create output dataframe
        output_df = self.csv_output.create_scanner_output(self.scanner_results)
        
        if output_df.empty:
            return pd.DataFrame()
        
        # Filter and sort
        filtered_df = self.csv_output.filter_by_criteria(
            output_df, min_confidence=min_confidence
        )
        
        return filtered_df.head(top_n)
    
    def export_results(self, filepath: str = None) -> str:
        """Export scan results to CSV"""
        if not self.scanner_results:
            logger.warning("No scan results available. Run a scan first.")
            return ""
        
        output_df = self.csv_output.create_scanner_output(self.scanner_results)
        
        if output_df.empty:
            logger.warning("No data to export")
            return ""
        
        return self.csv_output.save_scanner_output(output_df, filepath)
    
    def get_symbol_analysis(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get detailed analysis for a specific symbol"""
        if symbol not in self.scanner_results:
            logger.warning(f"No analysis available for {symbol}")
            return None
        
        return self.scanner_results[symbol]
    
    def validate_configuration(self) -> Dict[str, Any]:
        """Validate scanner configuration"""
        validation = {
            'valid': True,
            'issues': [],
            'warnings': []
        }
        
        # Check API credentials
        if not self.config.API_KEY or not self.config.ACCESS_TOKEN:
            validation['issues'].append("Missing Kite Connect API credentials")
            validation['valid'] = False
        
        # Check scoring weights
        if abs(sum(self.config.SCORING_WEIGHTS.values()) - 1.0) > 0.01:
            validation['issues'].append("Scoring weights must sum to 1.0")
            validation['valid'] = False
        
        # Check risk parameters
        if self.config.RISK_PERCENT <= 0 or self.config.RISK_PERCENT > 0.1:
            validation['warnings'].append("Risk percent should be between 0 and 10%")
        
        if self.config.MAX_POSITION_PERCENT <= 0 or self.config.MAX_POSITION_PERCENT > 0.5:
            validation['warnings'].append("Max position percent should be between 0 and 50%")
        
        # Check directory permissions
        for dir_path in [self.config.DATA_DIR, self.config.CACHE_DIR, self.config.OUTPUT_DIR]:
            try:
                Path(dir_path).mkdir(exist_ok=True)
            except Exception as e:
                validation['issues'].append(f"Cannot create directory {dir_path}: {e}")
                validation['valid'] = False
        
        return validation

def main():
    """Example usage of the scanner"""
    # Initialize scanner
    scanner = WeeklyDailyScanner()
    
    # Validate configuration
    validation = scanner.validate_configuration()
    if not validation['valid']:
        logger.error(f"Configuration validation failed: {validation['issues']}")
        return
    
    # Example symbols (replace with your universe)
    symbols = [
        'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR',
        'ICICIBANK', 'KOTAKBANK', 'SBIN', 'BHARTIARTL', 'ITC'
    ]
    
    # Run full scan
    results = scanner.run_full_scan(symbols, account_capital=100000)
    
    if results['success']:
        logger.info("Scan completed successfully!")
        
        # Get top candidates
        top_candidates = scanner.get_top_candidates(min_confidence=0.6, top_n=5)
        print("\nTop 5 Candidates:")
        print(top_candidates[['symbol', 'label', 'confidence_score', 'recommendation']])
        
        # Export results
        output_file = scanner.export_results()
        logger.info(f"Results exported to {output_file}")
    else:
        logger.error(f"Scan failed: {results['error']}")

if __name__ == "__main__":
    main()
