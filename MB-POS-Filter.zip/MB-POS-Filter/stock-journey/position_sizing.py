"""
Position Sizing and Risk Management
Calculates entry, stop, target levels and position sizes
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
import logging
from datetime import datetime

from config import config

logger = logging.getLogger(__name__)

class PositionSizing:
    """Handles position sizing, entry/stop/target calculations"""
    
    def __init__(self, config_obj=None):
        self.config = config_obj or config
    
    def calculate_entry_levels(self, df: pd.DataFrame, 
                              confirmation_price: float = None) -> Dict[str, float]:
        """
        Calculate entry levels for breakout trades
        
        Entry options:
        1. Weekly close breakout (aggressive)
        2. Daily confirmation price (conservative)
        """
        if df.empty:
            return {}
        
        latest = df.iloc[-1]
        
        # Use confirmation price if provided, otherwise use weekly close
        entry_price = confirmation_price if confirmation_price else latest['close']
        
        # Calculate breakout level
        breakout_level = latest.get('breakout_level', latest['close'])
        
        return {
            'entry_price': entry_price,
            'breakout_level': breakout_level,
            'entry_type': 'daily_confirmation' if confirmation_price else 'weekly_breakout'
        }
    
    def calculate_stop_loss(self, df: pd.DataFrame, 
                           entry_price: float,
                           method: str = 'conservative') -> Dict[str, float]:
        """
        Calculate stop loss levels
        
        Methods:
        - conservative: stop = range_low - 0.5 * weekly_ATR OR stop = breakout_level - 1.5 * weekly_ATR
        - aggressive: below the nearest swing low
        - atr_based: entry - (2 * ATR)
        """
        if df.empty:
            return {}
        
        latest = df.iloc[-1]
        
        if method == 'conservative':
            # Conservative stop: range low or breakout level based
            range_low = latest.get(f'range_low_{self.config.RANGE_WEEKS}w', latest['close'])
            atr = latest.get(f'atr_{self.config.ATR_WEEKS}w', latest['close'] * 0.02)
            breakout_level = latest.get('breakout_level', latest['close'])
            
            stop1 = range_low - (0.5 * atr)
            stop2 = breakout_level - (1.5 * atr)
            
            stop_price = min(stop1, stop2)
            
        elif method == 'aggressive':
            # Aggressive stop: below nearest swing low
            swing_low = self._find_nearest_swing_low(df)
            stop_price = swing_low * 0.98  # 2% below swing low
            
        elif method == 'atr_based':
            # ATR-based stop
            atr = latest.get(f'atr_{self.config.ATR_WEEKS}w', latest['close'] * 0.02)
            stop_price = entry_price - (2 * atr)
            
        else:
            raise ValueError(f"Unknown stop loss method: {method}")
        
        # Ensure stop is not above entry
        stop_price = min(stop_price, entry_price * 0.95)  # Max 5% below entry
        
        return {
            'stop_price': stop_price,
            'stop_method': method,
            'stop_distance_pct': (entry_price - stop_price) / entry_price * 100
        }
    
    def _find_nearest_swing_low(self, df: pd.DataFrame, lookback: int = 20) -> float:
        """Find the nearest swing low for aggressive stop placement"""
        if df.empty:
            return 0.0
        
        # Look for swing lows in recent data
        recent_data = df.tail(lookback)
        
        # Find local minima
        swing_lows = []
        for i in range(2, len(recent_data) - 2):
            if (recent_data.iloc[i]['low'] < recent_data.iloc[i-1]['low'] and
                recent_data.iloc[i]['low'] < recent_data.iloc[i-2]['low'] and
                recent_data.iloc[i]['low'] < recent_data.iloc[i+1]['low'] and
                recent_data.iloc[i]['low'] < recent_data.iloc[i+2]['low']):
                swing_lows.append(recent_data.iloc[i]['low'])
        
        if swing_lows:
            return min(swing_lows)
        else:
            # Fallback to recent low
            return recent_data['low'].min()
    
    def calculate_target_levels(self, df: pd.DataFrame, 
                               entry_price: float,
                               method: str = 'measured_move',
                               fixed_percent: float = 10.0,
                               stop_price: float = None) -> Dict[str, float]:
        """
        Calculate target levels
        
        Methods:
        - fixed_percent: Simple percentage profit target (e.g., 10%)
        - measured_move: target = entry + (range_height * target_multiplier)
        - risk_reward: target = entry + (entry - stop) * risk_reward_ratio
        - fibonacci: target = entry + (range_height * fibonacci_extension)
        """
        if df.empty:
            return {}
        
        latest = df.iloc[-1]
        
        if method == 'fixed_percent':
            # Simple fixed percentage profit target
            target_price = entry_price * (1 + fixed_percent / 100)
            
        elif method == 'measured_move':
            # Measured move based on range height
            range_high = latest.get(f'range_high_{self.config.RANGE_WEEKS}w', latest['close'])
            range_low = latest.get(f'range_low_{self.config.RANGE_WEEKS}w', latest['close'])
            range_height = range_high - range_low
            
            target_price = entry_price + (range_height * self.config.TARGET_MULTIPLIER)
            
        elif method == 'risk_reward':
            # Risk-reward based target
            if stop_price is None:
                # If stop not provided, calculate it
                stop_price = self.calculate_stop_loss(df, entry_price)['stop_price']
            
            risk_amount = entry_price - stop_price
            risk_reward_ratio = 2.0  # 2:1 risk reward
            
            target_price = entry_price + (risk_amount * risk_reward_ratio)
            
        elif method == 'fibonacci':
            # Fibonacci extension
            range_high = latest.get(f'range_high_{self.config.RANGE_WEEKS}w', latest['close'])
            range_low = latest.get(f'range_low_{self.config.RANGE_WEEKS}w', latest['close'])
            range_height = range_high - range_low
            
            # 1.618 Fibonacci extension
            target_price = entry_price + (range_height * 1.618)
            
        else:
            raise ValueError(f"Unknown target method: {method}")
        
        return {
            'target_price': target_price,
            'target_method': method,
            'target_distance_pct': (target_price - entry_price) / entry_price * 100
        }
    
    def calculate_position_size(self, entry_price: float, 
                              stop_price: float,
                              account_capital: float = 100000) -> Dict[str, any]:
        """
        Calculate position size based on risk management rules
        
        Position sizing rules:
        1. Risk per trade = capital * RISK_PERCENT
        2. Position size = risk_amount / (entry - stop)
        3. Cap single position exposure (max 5-10% of capital)
        """
        if entry_price <= 0 or stop_price <= 0 or account_capital <= 0:
            return {'error': 'Invalid input parameters'}
        
        # Calculate risk per trade
        risk_per_trade = account_capital * self.config.RISK_PERCENT
        
        # Calculate risk per share
        risk_per_share = entry_price - stop_price
        
        if risk_per_share <= 0:
            return {'error': 'Stop loss must be below entry price'}
        
        # Calculate base position size
        base_position_size = risk_per_trade / risk_per_share
        
        # Apply position size cap
        max_position_value = account_capital * self.config.MAX_POSITION_PERCENT
        max_position_size = max_position_value / entry_price
        
        # Final position size
        position_size = min(base_position_size, max_position_size)
        position_size = max(0, int(position_size))  # Round down to whole shares
        
        # Calculate actual values
        position_value = position_size * entry_price
        actual_risk = position_size * risk_per_share
        actual_risk_pct = actual_risk / account_capital * 100
        
        return {
            'position_size_shares': position_size,
            'position_value': position_value,
            'position_value_pct': position_value / account_capital * 100,
            'risk_amount': actual_risk,
            'risk_pct': actual_risk_pct,
            'risk_per_share': risk_per_share,
            'max_position_size': max_position_size,
            'position_capped': position_size == max_position_size
        }
    
    def calculate_pyramid_levels(self, df: pd.DataFrame, 
                                base_entry: float,
                                base_stop: float) -> Dict[str, float]:
        """
        Calculate pyramid levels for adding to winning positions
        
        Pyramid rules:
        1. Add on new weekly highs
        2. Each addition should have its own stop
        3. Total position should not exceed max exposure
        """
        if df.empty:
            return {}
        
        latest = df.iloc[-1]
        
        # Calculate pyramid entry levels
        range_height = (latest.get(f'range_high_{self.config.RANGE_WEEKS}w', latest['close']) - 
                       latest.get(f'range_low_{self.config.RANGE_WEEKS}w', latest['close']))
        
        pyramid_levels = {
            'pyramid_1': base_entry + (range_height * 0.5),
            'pyramid_2': base_entry + (range_height * 1.0),
            'pyramid_3': base_entry + (range_height * 1.5)
        }
        
        # Calculate pyramid stops (trailing stops)
        pyramid_stops = {
            'pyramid_1_stop': base_entry + (range_height * 0.25),
            'pyramid_2_stop': base_entry + (range_height * 0.75),
            'pyramid_3_stop': base_entry + (range_height * 1.25)
        }
        
        return {**pyramid_levels, **pyramid_stops}
    
    def calculate_complete_trade_setup(self, df: pd.DataFrame,
                                     confirmation_price: float = None,
                                     account_capital: float = 100000) -> Dict[str, any]:
        """Calculate complete trade setup with all levels and position sizing"""
        if df.empty:
            return {'error': 'Empty dataframe'}
        
        # Calculate entry levels
        entry_levels = self.calculate_entry_levels(df, confirmation_price)
        entry_price = entry_levels['entry_price']
        
        # Calculate stop loss - AGGRESSIVE for live scanner
        stop_levels = self.calculate_stop_loss(df, entry_price, method='aggressive')
        stop_price = stop_levels['stop_price']
        
        # Calculate targets - FIBONACCI extension for bigger targets
        target_levels = self.calculate_target_levels(df, entry_price, method='fibonacci')
        target_price = target_levels['target_price']
        
        # Calculate position size
        position_info = self.calculate_position_size(entry_price, stop_price, account_capital)
        
        # Calculate pyramid levels
        pyramid_levels = self.calculate_pyramid_levels(df, entry_price, stop_price)
        
        # Calculate risk-reward ratios
        risk_amount = entry_price - stop_price
        reward_amount = target_price - entry_price
        risk_reward_ratio = reward_amount / risk_amount if risk_amount > 0 else 0
        
        return {
            'entry': entry_levels,
            'stop': stop_levels,
            'target': target_levels,
            'position': position_info,
            'pyramid': pyramid_levels,
            'risk_reward_ratio': risk_reward_ratio,
            'trade_summary': {
                'entry_price': entry_price,
                'stop_price': stop_price,
                'target_price': target_price,
                'position_size': position_info.get('position_size_shares', 0),
                'risk_amount': position_info.get('risk_amount', 0),
                'potential_reward': position_info.get('position_size_shares', 0) * reward_amount,
                'risk_reward_ratio': risk_reward_ratio
            }
        }
    
    def validate_trade_setup(self, trade_setup: Dict[str, any]) -> Dict[str, any]:
        """Validate trade setup for common issues"""
        if 'error' in trade_setup:
            return trade_setup
        
        issues = []
        warnings = []
        
        # Check entry price
        entry_price = trade_setup.get('entry', {}).get('entry_price', 0)
        if entry_price <= 0:
            issues.append('Invalid entry price')
        
        # Check stop loss
        stop_price = trade_setup.get('stop', {}).get('stop_price', 0)
        if stop_price <= 0:
            issues.append('Invalid stop price')
        
        # Check stop is below entry
        if stop_price >= entry_price:
            issues.append('Stop loss must be below entry price')
        
        # Check target
        target_price = trade_setup.get('target', {}).get('target_price', 0)
        if target_price <= entry_price:
            issues.append('Target price must be above entry price')
        
        # Check position size
        position_size = trade_setup.get('position', {}).get('position_size_shares', 0)
        if position_size <= 0:
            issues.append('Invalid position size')
        
        # Check risk-reward ratio
        risk_reward = trade_setup.get('risk_reward_ratio', 0)
        if risk_reward < 1.0:
            warnings.append('Risk-reward ratio below 1:1')
        elif risk_reward < 2.0:
            warnings.append('Risk-reward ratio below 2:1')
        
        # Check position size cap
        position_capped = trade_setup.get('position', {}).get('position_capped', False)
        if position_capped:
            warnings.append('Position size capped at maximum exposure')
        
        return {
            'valid': len(issues) == 0,
            'issues': issues,
            'warnings': warnings,
            'trade_setup': trade_setup
        }
