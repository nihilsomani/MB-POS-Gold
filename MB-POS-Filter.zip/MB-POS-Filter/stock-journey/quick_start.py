"""
Quick Start Script for Weekly→Daily Scanner
A simple example to get you started quickly
"""

from weekly_daily_scanner import WeeklyDailyScanner
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    """Quick start example"""
    print("🚀 Weekly→Daily Scanner - Quick Start")
    print("=" * 50)
    
    # Initialize scanner
    print("📊 Initializing scanner...")
    scanner = WeeklyDailyScanner()
    
    # Validate configuration
    validation = scanner.validate_configuration()
    if not validation['valid']:
        print(f"❌ Configuration issues: {validation['issues']}")
        print("Please fix the configuration issues before proceeding.")
        return
    
    print("✅ Scanner initialized successfully!")
    
    # Read symbols from CSV file (first 10 for quick scan)
    symbols_file = "data/MCAP-great2500.csv"
    try:
        import pandas as pd
        symbols_df = pd.read_csv(symbols_file)
        symbols = symbols_df['Symbol'].head(10).tolist()  # First 10 for quick scan
        print(f"✅ Loaded {len(symbols)} symbols from {symbols_file}")
    except Exception as e:
        print(f"❌ Error reading symbols from {symbols_file}: {e}")
        print("Using default symbol list as fallback...")
        symbols = [
            'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR',
            'ICICIBANK', 'KOTAKBANK', 'SBIN', 'BHARTIARTL', 'ITC'
        ]
    
    print(f"\n🔍 Scanning {len(symbols)} symbols...")
    print("Symbols:", ', '.join(symbols))
    
    # Run quick scan (faster, less detailed)
    print("\n⚡ Running quick scan...")
    quick_results = scanner.run_quick_scan(symbols, min_confidence=0.5)
    
    if not quick_results.empty:
        print(f"\n✅ Quick scan completed! Found {len(quick_results)} candidates")
        print("\n📈 Quick Scan Results:")
        print(quick_results[['symbol', 'stage', 'confidence_score', 'confidence_level']].to_string(index=False))
        
        # Show top 3 candidates
        top_candidates = quick_results.head(3)
        print(f"\n🏆 Top 3 Candidates:")
        for _, row in top_candidates.iterrows():
            print(f"   {row['symbol']}: {row['stage']} (Score: {row['confidence_score']:.3f})")
        
        print(f"\n💡 To run a full detailed scan, use:")
        print(f"   results = scanner.run_full_scan(symbols, account_capital=100000)")
        
    else:
        print("❌ No candidates found in quick scan")
        print("Try lowering the min_confidence parameter or check your data")
    
    print(f"\n🎉 Quick start completed!")
    print(f"📚 For more examples, see: example_usage.py")
    print(f"📖 For documentation, see: README.md")

if __name__ == "__main__":
    main()
