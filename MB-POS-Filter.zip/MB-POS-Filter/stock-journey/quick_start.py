"""
Quick Start Script for Weekly→Daily Scanner
A simple example to get you started quickly
"""

from weekly_daily_scanner import WeeklyDailyScanner
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    """Quick start example"""
    print("Weekly->Daily Scanner - Quick Start")
    print("=" * 50)
    
    # Initialize scanner
    print("Initializing scanner...")
    scanner = WeeklyDailyScanner()
    
    # Validate configuration
    validation = scanner.validate_configuration()
    if not validation['valid']:
        print(f"Configuration issues: {validation['issues']}")
        print("Please fix the configuration issues before proceeding.")
        return
    
    print("Scanner initialized successfully!")
    
    # Read symbols from CSV file (scan all symbols)
    symbols_file = "data/MCAP-great2500.csv"
    try:
        import pandas as pd
        symbols_df = pd.read_csv(symbols_file)
        symbols = symbols_df['Symbol'].tolist()  # All symbols from CSV
        print(f"Loaded {len(symbols)} symbols from {symbols_file}")
        print(f"Estimated scan time: {len(symbols) * 0.35 / 60:.1f} minutes")
    except Exception as e:
        print(f"Error reading symbols from {symbols_file}: {e}")
        print("Using default symbol list as fallback...")
        symbols = [
            'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR',
            'ICICIBANK', 'KOTAKBANK', 'SBIN', 'BHARTIARTL', 'ITC'
        ]
    
    print(f"\nScanning {len(symbols)} symbols...")
    print("Symbols:", ', '.join(symbols))
    
    # Run full scan (comprehensive analysis with position sizing)
    print("\nRunning full scan with detailed analysis...")
    scan_result = scanner.run_full_scan(symbols, account_capital=2000000)
    
    # Extract results from the returned dictionary
    if scan_result and scan_result.get('success'):
        quick_results = scan_result['output_dataframe']
        scan_summary = scan_result.get('scan_summary', {})
        
        if not quick_results.empty:
            print(f"\nFull scan completed! Found {len(quick_results)} candidates")
            print("\nFull Scan Results:")
            
            # Display key columns if they exist
            display_cols = []
            for col in ['symbol', 'stage', 'confidence_score', 'confidence_level']:
                if col in quick_results.columns:
                    display_cols.append(col)
            
            if display_cols:
                print(quick_results[display_cols].to_string(index=False))
            
            # Show top 3 candidates
            top_candidates = quick_results.head(3)
            print(f"\nTop 3 Candidates:")
            for _, row in top_candidates.iterrows():
                symbol = row.get('symbol', 'N/A')
                stage = row.get('stage', row.get('label', 'N/A'))
                score = row.get('confidence_score', 0)
                print(f"   {symbol}: {stage} (Score: {score:.3f})")
            
            print(f"\nResults saved to CSV file")
            print(f"Check the output/ folder for entry/exit levels and position sizing.")
            
            # Show scan summary if available
            if scan_summary:
                print(f"\nScan Summary:")
                print(f"   Processed: {scan_result.get('processed_symbols', 0)}/{scan_result.get('total_symbols', 0)} symbols")
                if 'high_confidence_count' in scan_summary:
                    print(f"   High Confidence: {scan_summary['high_confidence_count']}")
                if 'moderate_confidence_count' in scan_summary:
                    print(f"   Moderate Confidence: {scan_summary['moderate_confidence_count']}")
        else:
            print("No candidates found in full scan")
            print("Try adjusting the configuration parameters or check your data")
    else:
        print("Full scan failed or returned no data")
        print("Check the logs for errors")
    
    print(f"\nFull scan completed!")
    print(f"For more examples, see: example_usage.py")
    print(f"For documentation, see: README.md")

if __name__ == "__main__":
    main()
