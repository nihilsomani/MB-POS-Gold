"""
Kite Connect Data Fetcher with Caching
Handles API rate limits, caching, and data persistence
"""

import pandas as pd
import numpy as np
import requests
import json
import time
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
import sqlite3
from kiteconnect import KiteConnect

from config import config

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class KiteDataFetcher:
    """Handles data fetching from Kite Connect with intelligent caching"""
    
    def __init__(self):
        self.kite = KiteConnect(api_key=config.API_KEY)
        self.kite.set_access_token(config.ACCESS_TOKEN)
        
        # Create directories
        for dir_path in [config.DATA_DIR, config.CACHE_DIR, config.OUTPUT_DIR]:
            Path(dir_path).mkdir(exist_ok=True)
        
        # Initialize cache database
        self._init_cache_db()
        
        # Simple rate limiting - 0.35 second delay between calls
        self.last_request_time = 0
        self.min_request_interval = 0.35  # 0.35 seconds between requests
        
    def _init_cache_db(self):
        """Initialize SQLite cache database"""
        cache_db = f"{config.CACHE_DIR}/cache.db"
        # Use check_same_thread=False to allow cross-thread usage
        self.conn = sqlite3.connect(cache_db, check_same_thread=False)
        
        # Create tables
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS instruments (
                symbol TEXT PRIMARY KEY,
                instrument_token INTEGER,
                name TEXT,
                last_updated TIMESTAMP,
                data TEXT
            )
        ''')
        
        self.conn.execute('''
            CREATE TABLE IF NOT EXISTS historical_data (
                symbol TEXT,
                date TEXT,
                open REAL,
                high REAL,
                low REAL,
                close REAL,
                volume INTEGER,
                last_updated TIMESTAMP,
                PRIMARY KEY (symbol, date)
            )
        ''')
        
        self.conn.commit()
    
    def _rate_limit(self):
        """Simple rate limiting - 0.35 second delay between calls"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            time.sleep(self.min_request_interval - time_since_last)
        
        self.last_request_time = time.time()
    
    def get_instruments(self, force_refresh: bool = False) -> pd.DataFrame:
        """Get instruments list with caching"""
        cache_file = f"{config.CACHE_DIR}/instruments.json"
        
        # Check if cache is valid
        if not force_refresh and os.path.exists(cache_file):
            cache_time = os.path.getmtime(cache_file)
            if time.time() - cache_time < config.CACHE_TTL_HOURS * 3600:
                logger.info("Loading instruments from cache")
                with open(cache_file, 'r') as f:
                    instruments_data = json.load(f)
                return pd.DataFrame(instruments_data)
        
        # Fetch from API
        logger.info("Fetching instruments from Kite Connect API")
        self._rate_limit()
        
        try:
            instruments = self.kite.instruments()
            instruments_df = pd.DataFrame(instruments)
            
            # Filter for equity instruments only
            equity_instruments = instruments_df[
                (instruments_df['instrument_type'] == 'EQ') & 
                (instruments_df['exchange'] == 'NSE')
            ].copy()
            
            # Cache the data
            with open(cache_file, 'w') as f:
                json.dump(equity_instruments.to_dict('records'), f)
            
            logger.info(f"Fetched {len(equity_instruments)} equity instruments")
            return equity_instruments
            
        except Exception as e:
            logger.error(f"Error fetching instruments: {e}")
            raise
    
    def get_historical_data(self, symbol: str, instrument_token: int, 
                          from_date: str, to_date: str, 
                          interval: str = "day") -> pd.DataFrame:
        """Get historical data for a symbol with caching"""
        
        # Check cache first
        cache_key = f"{symbol}_{from_date}_{to_date}_{interval}"
        cached_data = self._get_cached_data(symbol, from_date, to_date)
        
        if cached_data is not None and not cached_data.empty:
            logger.debug(f"Using cached data for {symbol}")
            return cached_data
        
        # Fetch from API
        logger.debug(f"Fetching historical data for {symbol}")
        self._rate_limit()
        
        try:
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            if not data:
                logger.warning(f"No data returned for {symbol}")
                return pd.DataFrame()
            
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            
            # Cache the data
            self._cache_data(symbol, df)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return pd.DataFrame()
    
    def _get_cached_data(self, symbol: str, from_date: str, to_date: str) -> Optional[pd.DataFrame]:
        """Get cached historical data"""
        try:
            query = '''
                SELECT date, open, high, low, close, volume 
                FROM historical_data 
                WHERE symbol = ? AND date BETWEEN ? AND ?
                ORDER BY date
            '''
            
            df = pd.read_sql_query(
                query, 
                self.conn, 
                params=(symbol, from_date, to_date),
                parse_dates=['date'],
                index_col='date'
            )
            
            return df if not df.empty else None
            
        except Exception as e:
            logger.debug(f"Cache miss for {symbol}: {e}")
            return None
    
    def _cache_data(self, symbol: str, df: pd.DataFrame):
        """Cache historical data"""
        try:
            # Prepare data for insertion
            data_to_insert = []
            for date, row in df.iterrows():
                data_to_insert.append((
                    symbol,
                    date.strftime('%Y-%m-%d'),
                    row['open'],
                    row['high'],
                    row['low'],
                    row['close'],
                    row['volume'],
                    datetime.now().isoformat()
                ))
            
            # Insert or replace data with thread-safe approach
            with self.conn:
                self.conn.executemany('''
                    INSERT OR REPLACE INTO historical_data 
                    (symbol, date, open, high, low, close, volume, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ''', data_to_insert)
            
        except Exception as e:
            logger.error(f"Error caching data for {symbol}: {e}")
    
    def get_benchmark_data(self, benchmark_symbol: str = None) -> pd.DataFrame:
        """Get benchmark data (NIFTY 50) for relative strength calculation"""
        if benchmark_symbol is None:
            benchmark_symbol = config.BENCHMARK_SYMBOL
        
        # Get benchmark instrument token
        instruments = self.get_instruments()
        benchmark_instruments = instruments[
            instruments['name'].str.contains(benchmark_symbol, case=False, na=False)
        ]
        
        if benchmark_instruments.empty:
            logger.warning(f"Benchmark symbol {benchmark_symbol} not found")
            return pd.DataFrame()
        
        # Use the first match (usually NIFTY 50)
        benchmark_token = benchmark_instruments.iloc[0]['instrument_token']
        
        # Calculate date range
        to_date = datetime.now().strftime('%Y-%m-%d')
        from_date = (datetime.now() - timedelta(days=config.LOOKBACK_DAYS)).strftime('%Y-%m-%d')
        
        return self.get_historical_data(
            benchmark_symbol, 
            benchmark_token, 
            from_date, 
            to_date
        )
    
    def batch_fetch_data(self, symbols: List[str]) -> Dict[str, pd.DataFrame]:
        """Fetch data for multiple symbols with simple rate limiting"""
        instruments = self.get_instruments()
        symbol_to_token = dict(zip(instruments['tradingsymbol'], instruments['instrument_token']))
        
        # Calculate date range
        to_date = datetime.now().strftime('%Y-%m-%d')
        from_date = (datetime.now() - timedelta(days=config.LOOKBACK_DAYS)).strftime('%Y-%m-%d')
        
        results = {}
        total_symbols = len(symbols)
        
        logger.info(f"Fetching data for {total_symbols} symbols with 0.35-second delay between calls")
        
        # Process symbols sequentially with 0.35-second delay
        for i, symbol in enumerate(symbols, 1):
            if i % 50 == 0:  # Progress update every 50 symbols
                logger.info(f"Progress: {i}/{total_symbols} symbols processed")
            
            if symbol not in symbol_to_token:
                logger.warning(f"Symbol {symbol} not found in instruments")
                results[symbol] = pd.DataFrame()
                continue
            
            token = symbol_to_token[symbol]
            data = self.get_historical_data(symbol, token, from_date, to_date)
            results[symbol] = data
        
        logger.info(f"Completed fetch for {len(results)} symbols")
        return results
    
    def save_data_to_parquet(self, data_dict: Dict[str, pd.DataFrame], 
                           filepath: str, symbol_col: str = 'symbol'):
        """Save multiple dataframes to parquet with symbol column"""
        if not data_dict:
            logger.warning("No data to save")
            return
        
        # Combine all dataframes
        combined_data = []
        for symbol, df in data_dict.items():
            if df.empty:
                continue
            df_copy = df.copy()
            df_copy[symbol_col] = symbol
            df_copy.reset_index(inplace=True)
            combined_data.append(df_copy)
        
        if not combined_data:
            logger.warning("No valid data to save")
            return
        
        combined_df = pd.concat(combined_data, ignore_index=True)
        combined_df.to_parquet(filepath, index=False)
        logger.info(f"Saved data to {filepath}")
    
    def load_data_from_parquet(self, filepath: str, symbol_col: str = 'symbol') -> Dict[str, pd.DataFrame]:
        """Load data from parquet file and split by symbol"""
        if not os.path.exists(filepath):
            logger.warning(f"File {filepath} does not exist")
            return {}
        
        try:
            df = pd.read_parquet(filepath)
            df['date'] = pd.to_datetime(df['date'])
            
            # Split by symbol
            data_dict = {}
            for symbol in df[symbol_col].unique():
                symbol_data = df[df[symbol_col] == symbol].copy()
                symbol_data.set_index('date', inplace=True)
                symbol_data.drop(columns=[symbol_col], inplace=True)
                data_dict[symbol] = symbol_data
            
            logger.info(f"Loaded data for {len(data_dict)} symbols from {filepath}")
            return data_dict
            
        except Exception as e:
            logger.error(f"Error loading data from {filepath}: {e}")
            return {}
    
    def close(self):
        """Close database connections"""
        if hasattr(self, 'conn'):
            self.conn.close()
