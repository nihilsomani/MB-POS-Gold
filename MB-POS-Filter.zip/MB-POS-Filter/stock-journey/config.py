"""
Configuration settings for the Weekly→Daily Scanner
All parameters are tunable for different market conditions and strategies
"""

from dataclasses import dataclass
from typing import Dict, Any
import os
from dotenv import load_dotenv

load_dotenv()

@dataclass
class ScannerConfig:
    """Main configuration class for the scanner"""
    
    # Kite Connect API settings
    API_KEY: str = os.getenv('KITE_API_KEY', '')
    API_SECRET: str = os.getenv('KITE_API_SECRET', '')
    ACCESS_TOKEN: str = os.getenv('KITE_ACCESS_TOKEN', '')
    
    # Data settings
    BENCHMARK_SYMBOL: str = "NIFTY 50"  # or "NIFTY 500", "BANKNIFTY", etc.
    LOOKBACK_DAYS: int = 500  # Days of historical data to fetch
    CACHE_TTL_HOURS: int = 24  # Cache TTL for EOD data
    
    # Weekly timeframe settings
    MA_SHORT_WEEKS: int = 10  # Short-term moving average
    MA_LONG_WEEKS: int = 30   # Long-term moving average
    MA_TREND_WEEKS: int = 50  # Structural trend MA
    ATR_WEEKS: int = 20       # ATR calculation period
    RANGE_WEEKS: int = 20     # Range calculation period
    VOL_MA_WEEKS: int = 20    # Volume moving average period
    RS_WEEKS: int = 12        # Relative strength calculation period
    
    # Classification thresholds
    RANGE_PCT_THRESHOLD: float = 20.0  # Max range % for consolidation
    ATR_SHRINK_THRESHOLD: float = 0.7  # ATR shrink threshold
    WEEKLY_VOL_SPIKE: float = 1.8      # Volume spike for breakout
    BREAKOUT_BUFFER: float = 0.01      # 1% buffer above range high
    DAILY_VOL_CONFIRM: float = 1.2     # Daily volume confirmation
    
    # Scoring weights (must sum to 1.0)
    SCORING_WEIGHTS: Dict[str, float] = None
    
    # Risk management
    RISK_PERCENT: float = 0.01         # 1% risk per trade
    MAX_POSITION_PERCENT: float = 0.10 # 10% max position size
    TARGET_MULTIPLIER: float = 2.0     # Measured move multiplier
    
    # Daily confirmation settings
    DAILY_CONFIRM_DAYS: int = 3        # Days to wait for daily confirmation
    FAILURE_EXIT_WEEKS: int = 3        # Weeks to hold before failure exit
    
    # Data storage
    DATA_DIR: str = "data"
    CACHE_DIR: str = "cache"
    OUTPUT_DIR: str = "output"
    
    def __post_init__(self):
        """Initialize default scoring weights if not provided"""
        if self.SCORING_WEIGHTS is None:
            self.SCORING_WEIGHTS = {
                'trend_strength': 0.25,
                'range_breakout': 0.25,
                'volume_confirmation': 0.20,
                'relative_strength': 0.15,
                'atr_volatility': 0.10,
                'hhhl_pattern': 0.05
            }
        
        # Ensure weights sum to 1.0
        total_weight = sum(self.SCORING_WEIGHTS.values())
        if abs(total_weight - 1.0) > 0.01:
            raise ValueError(f"Scoring weights must sum to 1.0, got {total_weight}")
    
    def get_data_paths(self) -> Dict[str, str]:
        """Get standardized file paths for data storage"""
        return {
            'daily_data': f"{self.DATA_DIR}/daily_data.parquet",
            'weekly_data': f"{self.DATA_DIR}/weekly_data.parquet",
            'instruments': f"{self.CACHE_DIR}/instruments.json",
            'scanner_output': f"{self.OUTPUT_DIR}/scanner_results.csv",
            'backtest_results': f"{self.OUTPUT_DIR}/backtest_results.csv"
        }

# Global config instance
config = ScannerConfig()

# Confidence score mapping
CONFIDENCE_LEVELS = {
    'strong': 0.75,      # Strong breakout candidate
    'moderate': 0.55,    # Moderate candidate  
    'watchlist': 0.35,   # Watchlist / Base
    'ignore': 0.0        # Ignore / Not actionable
}

# Stage labels
STAGE_LABELS = {
    'UPTREND_CONT': 'Uptrend Continuation',
    'BASE_CONSOLIDATION': 'Base Consolidation', 
    'BASE_BREAKOUT': 'Base Breakout Candidate',
    'FAILED_BREAKOUT': 'Failed Breakout',
    'OTHER': 'Other/Downtrend'
}
