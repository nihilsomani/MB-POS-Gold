"""
Test Installation and Basic Functionality
Run this script to verify your installation is working correctly
"""

import sys
import importlib
import logging
from pathlib import Path

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_imports():
    """Test if all required modules can be imported"""
    print("🔍 Testing imports...")
    
    required_modules = [
        'pandas', 'numpy', 'scipy', 'requests', 
        'kiteconnect', 'dotenv', 'pyarrow'
    ]
    
    missing_modules = []
    
    for module in required_modules:
        try:
            importlib.import_module(module)
            print(f"   ✅ {module}")
        except ImportError as e:
            print(f"   ❌ {module}: {e}")
            missing_modules.append(module)
    
    if missing_modules:
        print(f"\n❌ Missing modules: {', '.join(missing_modules)}")
        print("Install them with: pip install -r requirements.txt")
        return False
    else:
        print("\n✅ All required modules imported successfully!")
        return True

def test_local_imports():
    """Test if local modules can be imported"""
    print("\n🔍 Testing local modules...")
    
    local_modules = [
        'config', 'data_fetcher', 'technical_indicators',
        'stage_classifier', 'scoring_engine', 'daily_confirmation',
        'position_sizing', 'csv_output', 'weekly_daily_scanner'
    ]
    
    missing_modules = []
    
    for module in local_modules:
        try:
            importlib.import_module(module)
            print(f"   ✅ {module}")
        except ImportError as e:
            print(f"   ❌ {module}: {e}")
            missing_modules.append(module)
    
    if missing_modules:
        print(f"\n❌ Missing local modules: {', '.join(missing_modules)}")
        return False
    else:
        print("\n✅ All local modules imported successfully!")
        return True

def test_configuration():
    """Test configuration loading"""
    print("\n🔍 Testing configuration...")
    
    try:
        from config import config, ScannerConfig
        
        # Test default config
        print(f"   ✅ Default config loaded")
        print(f"   📊 MA Short: {config.MA_SHORT_WEEKS} weeks")
        print(f"   📊 MA Long: {config.MA_LONG_WEEKS} weeks")
        print(f"   📊 Risk %: {config.RISK_PERCENT*100}%")
        
        # Test custom config
        custom_config = ScannerConfig(
            MA_SHORT_WEEKS=8,
            MA_LONG_WEEKS=24,
            RISK_PERCENT=0.005
        )
        print(f"   ✅ Custom config created")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Configuration error: {e}")
        return False

def test_scanner_initialization():
    """Test scanner initialization"""
    print("\n🔍 Testing scanner initialization...")
    
    try:
        from weekly_daily_scanner import WeeklyDailyScanner
        
        # Initialize scanner
        scanner = WeeklyDailyScanner()
        print(f"   ✅ Scanner initialized")
        
        # Test validation
        validation = scanner.validate_configuration()
        print(f"   📋 Configuration valid: {validation['valid']}")
        
        if validation['issues']:
            print(f"   ⚠️ Issues: {validation['issues']}")
        
        if validation['warnings']:
            print(f"   ⚠️ Warnings: {validation['warnings']}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Scanner initialization error: {e}")
        return False

def test_data_structures():
    """Test data structure creation"""
    print("\n🔍 Testing data structures...")
    
    try:
        import pandas as pd
        import numpy as np
        
        # Test DataFrame creation
        test_data = {
            'open': [99, 100, 101, 102, 103],
            'high': [101, 102, 103, 104, 105],
            'low': [98, 99, 100, 101, 102],
            'close': [100, 101, 102, 103, 104],
            'volume': [1000, 1100, 1200, 1300, 1400]
        }
        df = pd.DataFrame(test_data)
        print(f"   ✅ DataFrame created: {df.shape}")
        
        # Test technical indicators
        from technical_indicators import TechnicalIndicators
        ti = TechnicalIndicators()
        
        # Test weekly resampling
        weekly_df = ti.resample_to_weekly(df)
        print(f"   ✅ Weekly resampling: {weekly_df.shape}")
        
        # Test MA calculation
        weekly_df = ti.calculate_moving_averages(weekly_df)
        print(f"   ✅ Moving averages calculated")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Data structure error: {e}")
        return False

def test_directory_creation():
    """Test directory creation"""
    print("\n🔍 Testing directory creation...")
    
    try:
        from config import config
        
        directories = [config.DATA_DIR, config.CACHE_DIR, config.OUTPUT_DIR]
        
        for directory in directories:
            Path(directory).mkdir(exist_ok=True)
            if Path(directory).exists():
                print(f"   ✅ {directory} directory ready")
            else:
                print(f"   ❌ Failed to create {directory}")
                return False
        
        return True
        
    except Exception as e:
        print(f"   ❌ Directory creation error: {e}")
        return False

def main():
    """Run all tests"""
    print("🚀 Weekly→Daily Scanner - Installation Test")
    print("=" * 60)
    
    tests = [
        ("Import Required Modules", test_imports),
        ("Import Local Modules", test_local_imports),
        ("Configuration Loading", test_configuration),
        ("Scanner Initialization", test_scanner_initialization),
        ("Data Structures", test_data_structures),
        ("Directory Creation", test_directory_creation)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n📋 {test_name}")
        print("-" * 40)
        
        try:
            if test_func():
                passed += 1
                print(f"✅ {test_name} - PASSED")
            else:
                print(f"❌ {test_name} - FAILED")
        except Exception as e:
            print(f"❌ {test_name} - ERROR: {e}")
    
    print("\n" + "=" * 60)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Your installation is ready.")
        print("\nNext steps:")
        print("1. Set up your .env file with Kite Connect credentials")
        print("2. Run: python example_usage.py")
        print("3. Start scanning your universe!")
    else:
        print("⚠️ Some tests failed. Please fix the issues above.")
        print("\nCommon solutions:")
        print("1. Install missing modules: pip install -r requirements.txt")
        print("2. Check Python version: python --version (need 3.8+)")
        print("3. Ensure all files are in the same directory")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
