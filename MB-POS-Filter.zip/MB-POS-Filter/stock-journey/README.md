# Weekly→Daily Scanner for Kite Connect

A production-ready, nuanced scanner that identifies breakout candidates using weekly timeframe analysis with daily confirmation. Built specifically for Indian equity markets using Kite Connect API.

## 🎯 Objective

Detect stocks that are (on the weekly timeframe) in an uptrend or base consolidation and identify those showing signs of emerging strength (breakout candidates). Use daily data only for confirmation and fine entry timing.

## 🏗️ Architecture

### High-level Workflow

1. **Data Collection**: Pull historical daily OHLCV from Kite Connect
2. **Weekly Resampling**: Convert to weekly timeframe (Friday close)
3. **Technical Analysis**: Calculate comprehensive indicators and patterns
4. **Stage Classification**: Identify Uptrend, Base, Breakout, or Other stages
5. **Confidence Scoring**: Weighted scoring system for signal quality
6. **Daily Confirmation**: Validate breakouts with daily data
7. **Position Sizing**: Calculate entry/stop/target levels with risk management
8. **Output Generation**: Comprehensive CSV with actionable insights

### Key Components

- **`data_fetcher.py`**: Kite Connect API integration with intelligent caching
- **`technical_indicators.py`**: Weekly resampling and technical analysis
- **`stage_classifier.py`**: Market stage classification engine
- **`scoring_engine.py`**: Weighted confidence scoring system
- **`daily_confirmation.py`**: Daily confirmation logic
- **`position_sizing.py`**: Risk management and position sizing
- **`csv_output.py`**: Comprehensive output generation
- **`weekly_daily_scanner.py`**: Main orchestrator

## 🚀 Quick Start

### 1. Installation

```bash
pip install -r requirements.txt
```

### 2. Configuration

Create a `.env` file with your Kite Connect credentials:

```env
KITE_API_KEY=your_api_key
KITE_API_SECRET=your_api_secret
KITE_ACCESS_TOKEN=your_access_token
```

### 3. Basic Usage

```python
from weekly_daily_scanner import WeeklyDailyScanner

# Initialize scanner
scanner = WeeklyDailyScanner()

# Define your universe
symbols = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR']

# Run full scan
results = scanner.run_full_scan(symbols, account_capital=100000)

# Get top candidates
top_candidates = scanner.get_top_candidates(min_confidence=0.6, top_n=5)
print(top_candidates)
```

## 📊 Technical Indicators

### Weekly Indicators

- **Moving Averages**: 10-week, 30-week, 50-week with slope analysis
- **ATR**: 20-week Average True Range for volatility measurement
- **Range Metrics**: 20-week high/low with percentage calculations
- **Volume Analysis**: Volume spikes, Z-scores, and trend analysis
- **Relative Strength**: 12-week RS vs NIFTY 50
- **Pattern Recognition**: Higher Highs/Higher Lows detection

### Daily Confirmation

- **Breakout Validation**: Price above weekly breakout level
- **Volume Confirmation**: Daily volume ≥ 1.2x average
- **Gap Analysis**: Avoid entries with significant gap downs
- **Failure Detection**: Identify failed breakouts quickly

## 🎯 Stage Classification

### 1. Uptrend Continuation
- MA_short > MA_long AND
- MA_slope > 0 AND
- price > MA_short

### 2. Base Consolidation
- Range < 20% AND
- ATR shrinking AND
- Volume contraction AND
- Price within range bounds

### 3. Base Breakout Candidate
- Was in consolidation recently AND
- Price > range_high + buffer AND
- Volume spike ≥ 1.8x AND
- Positive relative strength

### 4. Failed Breakout
- Previous breakout candidate that failed
- Price back below breakout level

## 🏆 Scoring System

Weighted confidence score (0-1) based on:

- **Trend Strength** (25%): MA relationships and slope
- **Range Breakout** (25%): Breakout strength and range tightness
- **Volume Confirmation** (20%): Volume spikes and consistency
- **Relative Strength** (15%): Performance vs benchmark
- **ATR/Volatility** (10%): Volatility characteristics
- **HHHL Pattern** (5%): Pattern recognition

### Confidence Levels

- **≥0.75**: Strong breakout candidate
- **0.55-0.75**: Moderate candidate
- **0.35-0.55**: Watchlist/Base
- **<0.35**: Ignore/Not actionable

## 💰 Position Sizing & Risk Management

### Entry Levels
- **Conservative**: Daily confirmation price
- **Aggressive**: Weekly close breakout

### Stop Loss Methods
- **Conservative**: Range low - 0.5×ATR OR breakout level - 1.5×ATR
- **Aggressive**: Below nearest swing low
- **ATR-based**: Entry - 2×ATR

### Target Calculation
- **Measured Move**: Entry + (range_height × multiplier)
- **Risk-Reward**: Entry + (entry - stop) × ratio
- **Fibonacci**: Entry + (range_height × 1.618)

### Position Sizing Rules
- Risk per trade = Capital × Risk% (default 1%)
- Position size = Risk amount ÷ (Entry - Stop)
- Cap single position at Max% of capital (default 10%)

## 📈 CSV Output Schema

The scanner generates comprehensive CSV output with 50+ columns including:

### Basic Info
- `symbol`, `last_week_end`, `label`, `confidence_score`

### Weekly Data
- `weekly_close`, `weekly_open`, `weekly_high`, `weekly_low`, `weekly_volume`

### Technical Indicators
- `ma_short_10w`, `ma_long_30w`, `atr_20w`
- `range_high_20w`, `range_low_20w`, `range_pct_20w`
- `vol_spike_latest`, `rs_12w`

### Trade Setup
- `entry_suggested`, `stop_suggested`, `target_suggested`
- `position_size_shares`, `risk_amount`, `risk_reward_ratio`

### Analysis
- `daily_confirmed`, `confirmation_date`, `recommendation`
- `notes` (detailed analysis explanation)

## ⚙️ Configuration

All parameters are configurable via `config.py`:

```python
@dataclass
class ScannerConfig:
    # API Settings
    API_KEY: str = os.getenv('KITE_API_KEY', '')
    BENCHMARK_SYMBOL: str = "NIFTY 50"
    
    # Timeframe Settings
    MA_SHORT_WEEKS: int = 10
    MA_LONG_WEEKS: int = 30
    ATR_WEEKS: int = 20
    RANGE_WEEKS: int = 20
    
    # Classification Thresholds
    RANGE_PCT_THRESHOLD: float = 20.0
    WEEKLY_VOL_SPIKE: float = 1.8
    BREAKOUT_BUFFER: float = 0.01
    
    # Risk Management
    RISK_PERCENT: float = 0.01
    MAX_POSITION_PERCENT: float = 0.10
    TARGET_MULTIPLIER: float = 2.0
    
    # Scoring Weights
    SCORING_WEIGHTS: Dict[str, float] = {
        'trend_strength': 0.25,
        'range_breakout': 0.25,
        'volume_confirmation': 0.20,
        'relative_strength': 0.15,
        'atr_volatility': 0.10,
        'hhhl_pattern': 0.05
    }
```

## 🔧 Advanced Usage

### Custom Configuration

```python
from config import ScannerConfig

# Create custom config
custom_config = ScannerConfig(
    MA_SHORT_WEEKS=8,
    MA_LONG_WEEKS=24,
    RISK_PERCENT=0.005,  # 0.5% risk
    SCORING_WEIGHTS={
        'trend_strength': 0.30,
        'range_breakout': 0.25,
        'volume_confirmation': 0.25,
        'relative_strength': 0.15,
        'atr_volatility': 0.05
    }
)

scanner = WeeklyDailyScanner(custom_config)
```

### Quick Scan

```python
# For large universes
quick_results = scanner.run_quick_scan(symbols, min_confidence=0.5)
```

### Filtering Results

```python
# Get high confidence candidates
high_conf = scanner.csv_output.filter_by_criteria(
    results_df, min_confidence=0.7
)

# Get confirmed breakouts only
confirmed = scanner.csv_output.filter_by_criteria(
    results_df, confirmed_only=True
)

# Get good risk-reward setups
good_rr = scanner.csv_output.filter_by_criteria(
    results_df, min_risk_reward=2.0
)
```

## 📊 Example Output

```
symbol    label                confidence_score  recommendation
RELIANCE  BASE_BREAKOUT        0.847            BUY - Confirmed breakout
TCS       UPTREND_CONT         0.723            BUY - Confirmed breakout
HDFCBANK  BASE_CONSOLIDATION   0.456            WATCH - Pending confirmation
INFY      BASE_BREAKOUT        0.789            BUY - Confirmed breakout
HINDUNILVR OTHER               0.234            WATCH - Pending confirmation
```

## 🛡️ Risk Management Features

- **Position Size Caps**: Maximum exposure per position
- **Risk Per Trade**: Configurable risk percentage
- **Stop Loss Validation**: Multiple stop loss methods
- **Gap Protection**: Avoid entries with significant gaps
- **Failure Detection**: Quick identification of failed breakouts
- **Confirmation Required**: Daily validation before entry

## 🔍 Troubleshooting

### Common Issues

1. **API Rate Limits**: Scanner includes built-in rate limiting
2. **Data Quality**: Automatic validation and error handling
3. **Configuration**: Built-in validation system
4. **Memory Usage**: Efficient data structures and caching

### Validation

```python
# Validate configuration
validation = scanner.validate_configuration()
if not validation['valid']:
    print(f"Issues: {validation['issues']}")
```

## 📝 Logging

Comprehensive logging to both console and file:

```python
import logging
logging.basicConfig(level=logging.INFO)
```

Logs include:
- Data fetching progress
- Symbol processing status
- Error handling and debugging
- Performance metrics

## 🚀 Performance

- **Parallel Processing**: Concurrent data fetching
- **Intelligent Caching**: SQLite-based data persistence
- **Rate Limiting**: Respects Kite Connect limits
- **Memory Efficient**: Optimized data structures

## 📋 Requirements

- Python 3.8+
- Kite Connect API access
- Sufficient historical data (500+ days recommended)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## ⚠️ Disclaimer

This software is for educational and research purposes only. Trading involves substantial risk of loss and is not suitable for all investors. Past performance is not indicative of future results. Always do your own research and consider your risk tolerance before trading.

## 📞 Support

For questions, issues, or contributions:
- Create an issue on GitHub
- Check the troubleshooting section
- Review the example usage scripts

---

**Happy Trading! 📈**
