"""
Run Full Detailed Scan
A simple script to run a complete weekly→daily scan with detailed analysis
"""

from weekly_daily_scanner import WeeklyDailyScanner
import logging
import pandas as pd

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    """Run a full detailed scan"""
    print("🚀 Weekly→Daily Scanner - Full Detailed Scan")
    print("=" * 60)
    
    # Initialize scanner
    print("📊 Initializing scanner...")
    scanner = WeeklyDailyScanner()
    
    # Validate configuration
    validation = scanner.validate_configuration()
    if not validation['valid']:
        print(f"❌ Configuration issues: {validation['issues']}")
        return
    
    print("✅ Scanner initialized successfully!")
    
    # Read symbols from CSV file
    symbols_file = "data/MCAP-great2500.csv"
    try:
        symbols_df = pd.read_csv(symbols_file)
        symbols = symbols_df['Symbol'].tolist()
        print(f"✅ Loaded {len(symbols)} symbols from {symbols_file}")
        print(f"⚠️  This will take approximately {len(symbols) * 0.5 / 60:.1f} minutes due to rate limiting")
    except Exception as e:
        print(f"❌ Error reading symbols from {symbols_file}: {e}")
        print("Using default symbol list as fallback...")
        symbols = [
            'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR',
            'ICICIBANK', 'KOTAKBANK', 'SBIN', 'BHARTIARTL', 'ITC'
        ]
    
    print(f"\n🔍 Scanning {len(symbols)} symbols...")
    print("Symbols:", ', '.join(symbols))
    
    # Set your account capital (adjust as needed)
    account_capital = 100000  # ₹1,00,000
    
    print(f"\n💰 Account Capital: ₹{account_capital:,}")
    
    # Run full scan
    print("\n⚡ Running full detailed scan...")
    print("This may take a few minutes...")
    
    results = scanner.run_full_scan(symbols, account_capital=account_capital)
    
    if results['success']:
        print(f"\n✅ Scan completed successfully!")
        print(f"📊 Processed {results['processed_symbols']} out of {results['total_symbols']} symbols")
        
        # Get the output dataframe
        output_df = results['output_dataframe']
        
        if not output_df.empty:
            print(f"\n📈 Found {len(output_df)} candidates with data")
            
            # Show summary by stage
            stage_summary = output_df['label'].value_counts()
            print(f"\n📊 Stage Breakdown:")
            for stage, count in stage_summary.items():
                print(f"   {stage}: {count} symbols")
            
            # Show confidence levels
            confidence_summary = output_df['confidence_level'].value_counts()
            print(f"\n🎯 Confidence Levels:")
            for level, count in confidence_summary.items():
                print(f"   {level}: {count} symbols")
            
            # Show top candidates
            print(f"\n🏆 Top 10 Candidates:")
            top_candidates = output_df.head(10)
            display_cols = ['symbol', 'label', 'confidence_score', 'confidence_level', 'recommendation']
            print(top_candidates[display_cols].to_string(index=False))
            
            # Show confirmed breakouts
            confirmed = output_df[output_df['daily_confirmed'] == True]
            if not confirmed.empty:
                print(f"\n✅ Confirmed Breakouts ({len(confirmed)}):")
                print(confirmed[['symbol', 'confidence_score', 'entry_suggested', 'stop_suggested', 'target_suggested']].to_string(index=False))
            
            # Show failed breakouts
            failed = output_df[output_df['breakout_failed'] == True]
            if not failed.empty:
                print(f"\n❌ Failed Breakouts ({len(failed)}):")
                print(failed[['symbol', 'failure_reason']].to_string(index=False))
            
            # Export results
            output_file = scanner.export_results()
            print(f"\n💾 Results exported to: {output_file}")
            
            # Show scan summary
            scan_summary = results['scan_summary']
            print(f"\n⏱️ Scan Summary:")
            print(f"   Duration: {scan_summary['scan_timing']['duration_minutes']:.1f} minutes")
            print(f"   Data Quality: {scan_summary['data_quality']['data_completeness']*100:.1f}%")
            
        else:
            print("❌ No data returned from scan")
    
    else:
        print(f"❌ Scan failed: {results['error']}")
    
    print(f"\n🎉 Full scan completed!")
    print(f"📚 Check the output CSV for detailed analysis")

if __name__ == "__main__":
    main()
