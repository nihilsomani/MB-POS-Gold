"""
Daily Confirmation Logic
Implements daily confirmation for weekly breakout candidates
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
import logging
from datetime import datetime, timedelta

from config import config

logger = logging.getLogger(__name__)

class DailyConfirmation:
    """Handles daily confirmation logic for weekly breakout candidates"""
    
    def __init__(self, config_obj=None):
        self.config = config_obj or config
    
    def calculate_daily_volume_metrics(self, daily_df: pd.DataFrame) -> pd.DataFrame:
        """Calculate daily volume metrics for confirmation"""
        if daily_df.empty:
            return daily_df
        
        df = daily_df.copy()
        
        # Daily volume moving average
        df['daily_vol_ma'] = df['volume'].rolling(window=20).mean()
        
        # Daily volume spike
        df['daily_vol_spike'] = df['volume'] / df['daily_vol_ma']
        
        # Daily volume Z-score
        vol_std = df['volume'].rolling(window=20).std()
        df['daily_vol_z'] = (df['volume'] - df['daily_vol_ma']) / vol_std
        
        return df
    
    def check_daily_confirmation(self, daily_df: pd.DataFrame, 
                               weekly_breakout_level: float,
                               breakout_date: datetime) -> Dict[str, any]:
        """
        Check if daily data confirms the weekly breakout
        
        Confirmation criteria:
        1. Daily close > weekly_breakout_level within next 3 trading days
        2. Daily volume >= 1.2 * daily_vol_ma20
        3. No immediate large gap down on open (gap > ATR) that invalidates entry
        """
        if daily_df.empty:
            return {
                'confirmed': False,
                'confirmation_date': None,
                'confirmation_price': None,
                'confirmation_volume': None,
                'failure_reason': 'No daily data available'
            }
        
        # Calculate daily volume metrics
        daily_df = self.calculate_daily_volume_metrics(daily_df)
        
        # Find the breakout date in daily data
        breakout_daily_idx = daily_df.index.get_indexer([breakout_date], method='nearest')[0]
        if breakout_daily_idx == -1:
            return {
                'confirmed': False,
                'confirmation_date': None,
                'confirmation_price': None,
                'confirmation_volume': None,
                'failure_reason': 'Breakout date not found in daily data'
            }
        
        # Look for confirmation in the next 3 trading days
        lookahead_days = min(self.config.DAILY_CONFIRM_DAYS, len(daily_df) - breakout_daily_idx - 1)
        confirmation_window = daily_df.iloc[breakout_daily_idx:breakout_daily_idx + lookahead_days + 1]
        
        if confirmation_window.empty:
            return {
                'confirmed': False,
                'confirmation_date': None,
                'confirmation_price': None,
                'confirmation_volume': None,
                'failure_reason': 'No confirmation window available'
            }
        
        # Check for confirmation criteria
        for i, (date, row) in enumerate(confirmation_window.iterrows()):
            # Skip the breakout day itself
            if i == 0:
                continue
            
            # Check if daily close > breakout level
            if row['close'] > weekly_breakout_level:
                # Check volume confirmation
                if row['daily_vol_spike'] >= self.config.DAILY_VOL_CONFIRM:
                    # Check for gap down invalidation
                    prev_close = confirmation_window.iloc[i-1]['close']
                    gap_down = (row['open'] - prev_close) / prev_close
                    
                    # Calculate daily ATR for gap check
                    daily_atr = self._calculate_daily_atr(daily_df, date, period=14)
                    gap_threshold = -daily_atr / prev_close if daily_atr > 0 else -0.05  # 5% default
                    
                    if gap_down < gap_threshold:
                        return {
                            'confirmed': False,
                            'confirmation_date': date,
                            'confirmation_price': row['close'],
                            'confirmation_volume': row['volume'],
                            'failure_reason': f'Gap down invalidation: {gap_down:.2%} < {gap_threshold:.2%}'
                        }
                    
                    # Confirmation successful
                    return {
                        'confirmed': True,
                        'confirmation_date': date,
                        'confirmation_price': row['close'],
                        'confirmation_volume': row['volume'],
                        'daily_vol_spike': row['daily_vol_spike'],
                        'gap_down': gap_down,
                        'failure_reason': None
                    }
        
        # No confirmation found
        return {
            'confirmed': False,
            'confirmation_date': None,
            'confirmation_price': None,
            'confirmation_volume': None,
            'failure_reason': f'No confirmation within {self.config.DAILY_CONFIRM_DAYS} days'
        }
    
    def _calculate_daily_atr(self, daily_df: pd.DataFrame, end_date: datetime, period: int = 14) -> float:
        """Calculate daily ATR for gap validation"""
        if daily_df.empty:
            return 0.0
        
        # Get data up to end_date
        data_up_to_date = daily_df[daily_df.index <= end_date].tail(period + 1)
        
        if len(data_up_to_date) < 2:
            return 0.0
        
        # Calculate True Range
        data_up_to_date = data_up_to_date.copy()
        data_up_to_date['prev_close'] = data_up_to_date['close'].shift(1)
        data_up_to_date['tr1'] = data_up_to_date['high'] - data_up_to_date['low']
        data_up_to_date['tr2'] = abs(data_up_to_date['high'] - data_up_to_date['prev_close'])
        data_up_to_date['tr3'] = abs(data_up_to_date['low'] - data_up_to_date['prev_close'])
        
        data_up_to_date['tr'] = data_up_to_date[['tr1', 'tr2', 'tr3']].max(axis=1)
        
        # ATR is the mean of TR
        atr = data_up_to_date['tr'].mean()
        
        return atr if not pd.isna(atr) else 0.0
    
    def check_breakout_failure(self, daily_df: pd.DataFrame, 
                              weekly_breakout_level: float,
                              breakout_date: datetime) -> Dict[str, any]:
        """
        Check if weekly breakout has failed based on daily data
        
        Failure criteria:
        1. Weekly close back under breakout_level within 2-3 weeks
        2. Significant volume decline
        3. Price rejection at breakout level
        """
        if daily_df.empty:
            return {
                'failed': False,
                'failure_date': None,
                'failure_price': None,
                'failure_reason': 'No daily data available'
            }
        
        # Calculate daily volume metrics
        daily_df = self.calculate_daily_volume_metrics(daily_df)
        
        # Find the breakout date in daily data
        breakout_daily_idx = daily_df.index.get_indexer([breakout_date], method='nearest')[0]
        if breakout_daily_idx == -1:
            return {
                'failed': False,
                'failure_date': None,
                'failure_price': None,
                'failure_reason': 'Breakout date not found in daily data'
            }
        
        # Look for failure in the next few weeks (up to 15 trading days)
        lookahead_days = min(15, len(daily_df) - breakout_daily_idx - 1)
        failure_window = daily_df.iloc[breakout_daily_idx:breakout_daily_idx + lookahead_days + 1]
        
        if failure_window.empty:
            return {
                'failed': False,
                'failure_date': None,
                'failure_price': None,
                'failure_reason': 'No failure window available'
            }
        
        # Check for failure criteria
        for i, (date, row) in enumerate(failure_window.iterrows()):
            # Skip the breakout day itself
            if i == 0:
                continue
            
            # Check if price fell back below breakout level
            if row['close'] < weekly_breakout_level:
                # Check if it's a significant failure (not just a small pullback)
                pullback_pct = (weekly_breakout_level - row['close']) / weekly_breakout_level
                
                if pullback_pct > 0.02:  # 2% pullback threshold
                    return {
                        'failed': True,
                        'failure_date': date,
                        'failure_price': row['close'],
                        'pullback_pct': pullback_pct,
                        'failure_reason': f'Price fell {pullback_pct:.2%} below breakout level'
                    }
        
        # Check for volume decline (potential failure signal)
        recent_volume = failure_window['daily_vol_spike'].tail(5).mean()
        initial_volume = failure_window['daily_vol_spike'].iloc[1:4].mean()
        
        if recent_volume < initial_volume * 0.5:  # 50% volume decline
            return {
                'failed': True,
                'failure_date': failure_window.index[-1],
                'failure_price': failure_window['close'].iloc[-1],
                'volume_decline': recent_volume / initial_volume,
                'failure_reason': f'Significant volume decline: {recent_volume/initial_volume:.2%}'
            }
        
        # No failure detected
        return {
            'failed': False,
            'failure_date': None,
            'failure_price': None,
            'failure_reason': 'No failure criteria met'
        }
    
    def get_confirmation_summary(self, daily_df: pd.DataFrame, 
                                weekly_breakout_level: float,
                                breakout_date: datetime) -> Dict[str, any]:
        """Get comprehensive confirmation summary"""
        confirmation = self.check_daily_confirmation(daily_df, weekly_breakout_level, breakout_date)
        failure = self.check_breakout_failure(daily_df, weekly_breakout_level, breakout_date)
        
        return {
            'confirmation': confirmation,
            'failure': failure,
            'status': self._determine_status(confirmation, failure),
            'recommendation': self._get_recommendation(confirmation, failure)
        }
    
    def _determine_status(self, confirmation: Dict, failure: Dict) -> str:
        """Determine overall status based on confirmation and failure checks"""
        if failure['failed']:
            return 'FAILED'
        elif confirmation['confirmed']:
            return 'CONFIRMED'
        else:
            return 'PENDING'
    
    def _get_recommendation(self, confirmation: Dict, failure: Dict) -> str:
        """Get trading recommendation based on confirmation status"""
        if failure['failed']:
            return 'AVOID - Breakout failed'
        elif confirmation['confirmed']:
            return 'BUY - Confirmed breakout'
        else:
            return 'WATCH - Pending confirmation'
    
    def validate_daily_data(self, daily_df: pd.DataFrame) -> Dict[str, any]:
        """Validate daily data quality for confirmation analysis"""
        if daily_df.empty:
            return {'error': 'Empty daily dataframe'}
        
        diagnostics = {
            'total_days': len(daily_df),
            'date_range': {
                'start': daily_df.index.min(),
                'end': daily_df.index.max()
            },
            'missing_data': {},
            'data_quality_issues': []
        }
        
        # Check for missing data
        required_columns = ['open', 'high', 'low', 'close', 'volume']
        for col in required_columns:
            if col in daily_df.columns:
                missing_count = daily_df[col].isna().sum()
                diagnostics['missing_data'][col] = missing_count
                
                if missing_count > 0:
                    diagnostics['data_quality_issues'].append(f'Missing {missing_count} {col} values')
        
        # Check for data quality issues
        if 'close' in daily_df.columns:
            if (daily_df['close'] <= 0).any():
                diagnostics['data_quality_issues'].append('Non-positive close prices')
            
            if (daily_df['close'].pct_change().abs() > 0.5).any():
                diagnostics['data_quality_issues'].append('Extreme price movements detected')
        
        if 'volume' in daily_df.columns:
            if (daily_df['volume'] < 0).any():
                diagnostics['data_quality_issues'].append('Negative volume values')
        
        return diagnostics
