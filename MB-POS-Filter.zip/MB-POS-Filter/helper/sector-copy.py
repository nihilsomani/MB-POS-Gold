import pandas as pd

# Load the two CSV files
file1 = "data/Stage2Shortlist.csv"      # Has column 'Symbol'
file2 = "data/Sector-MCAP-great2500-output.csv"     # Has column 'symbol', plus Sector, Industry, Level_3, Level_4

df1 = pd.read_csv(file1)
df2 = pd.read_csv(file2)

# Merge using different key names
merged = pd.merge(df1, df2, left_on='Symbol', right_on='symbol', how='left')

# Drop duplicate 'symbol' column (if you don’t want it)
merged = merged.drop(columns=['symbol'])

# Save merged result
merged.to_csv("symbols_enriched.csv", index=False)

print("✅ Merged CSV saved as 'symbols_enriched.csv'")
