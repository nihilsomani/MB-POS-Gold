"""
Range Contraction & Insider Bar Scanner with Caching
Uses Kite Connect API to find stocks ready for range expansion
Includes intelligent caching to avoid redundant API calls
"""

from kiteconnect import KiteConnect
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import json
import os
import pickle
from pathlib import Path
import hashlib
import time
from collections import deque
from threading import Lock

# Configure logging
logging.basicConfig(level=logging.INFO)  # INFO level for normal operation
logger = logging.getLogger(__name__)


class CacheManager:
    """Manages data caching with expiry"""
    
    def __init__(self, cache_dir="./cache", cache_expiry_hours=24):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.cache_expiry_hours = cache_expiry_hours
        self.metadata_file = self.cache_dir / "cache_metadata.json"
        self.metadata = self._load_metadata()
        
    def _load_metadata(self):
        """Load cache metadata"""
        if self.metadata_file.exists():
            with open(self.metadata_file, 'r') as f:
                return json.load(f)
        return {}
    
    def _save_metadata(self):
        """Save cache metadata"""
        with open(self.metadata_file, 'w') as f:
            json.dump(self.metadata, f, indent=2)
    
    def _get_cache_key(self, instrument_token, days):
        """Generate cache key"""
        key_string = f"{instrument_token}_{days}"
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def _get_cache_path(self, cache_key):
        """Get cache file path"""
        return self.cache_dir / f"{cache_key}.pkl"
    
    def is_cache_valid(self, cache_key):
        """Check if cache is still valid"""
        if cache_key not in self.metadata:
            return False
        
        cached_time = datetime.fromisoformat(self.metadata[cache_key]['timestamp'])
        expiry_time = cached_time + timedelta(hours=self.cache_expiry_hours)
        
        return datetime.now() < expiry_time
    
    def get(self, instrument_token, days):
        """Get cached data if available and valid"""
        cache_key = self._get_cache_key(instrument_token, days)
        
        if not self.is_cache_valid(cache_key):
            return None
        
        cache_path = self._get_cache_path(cache_key)
        
        if not cache_path.exists():
            return None
        
        try:
            with open(cache_path, 'rb') as f:
                data = pickle.load(f)
            logger.debug(f"Cache HIT for token {instrument_token}")
            return data
        except Exception as e:
            logger.warning(f"Error reading cache: {e}")
            return None
    
    def set(self, instrument_token, days, data):
        """Save data to cache"""
        cache_key = self._get_cache_key(instrument_token, days)
        cache_path = self._get_cache_path(cache_key)
        
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump(data, f)
            
            self.metadata[cache_key] = {
                'instrument_token': instrument_token,
                'days': days,
                'timestamp': datetime.now().isoformat()
            }
            self._save_metadata()
            logger.debug(f"Cache SAVED for token {instrument_token}")
        except Exception as e:
            logger.warning(f"Error saving cache: {e}")
    
    def clear_expired(self):
        """Clear expired cache entries"""
        expired_keys = [
            key for key in self.metadata.keys()
            if not self.is_cache_valid(key)
        ]
        
        for key in expired_keys:
            cache_path = self._get_cache_path(key)
            if cache_path.exists():
                cache_path.unlink()
            del self.metadata[key]
        
        self._save_metadata()
        logger.info(f"Cleared {len(expired_keys)} expired cache entries")
    
    def clear_all(self):
        """Clear all cache"""
        for cache_file in self.cache_dir.glob("*.pkl"):
            cache_file.unlink()
        self.metadata = {}
        self._save_metadata()
        logger.info("All cache cleared")
    
    def get_stats(self):
        """Get cache statistics"""
        total = len(self.metadata)
        valid = sum(1 for key in self.metadata.keys() if self.is_cache_valid(key))
        expired = total - valid
        
        total_size = sum(
            f.stat().st_size 
            for f in self.cache_dir.glob("*.pkl")
        ) / (1024 * 1024)  # MB
        
        return {
            'total_entries': total,
            'valid_entries': valid,
            'expired_entries': expired,
            'total_size_mb': round(total_size, 2)
        }


class RateLimiter:
    """
    Rate limiter for Kite Connect API
    Kite limits: 3 requests/second, 10 historical data requests/second
    """
    
    def __init__(self, max_calls=10, time_window=1.0):
        """
        Initialize rate limiter
        
        Args:
            max_calls: Maximum number of calls allowed in time window
            time_window: Time window in seconds
        """
        self.max_calls = max_calls
        self.time_window = time_window
        self.calls = deque()
        self.lock = Lock()
        
    def wait_if_needed(self):
        """Wait if rate limit would be exceeded"""
        with self.lock:
            now = time.time()
            
            # Remove calls outside the time window
            while self.calls and self.calls[0] <= now - self.time_window:
                self.calls.popleft()
            
            # If at limit, wait
            if len(self.calls) >= self.max_calls:
                sleep_time = self.time_window - (now - self.calls[0])
                if sleep_time > 0:
                    logger.debug(f"Rate limit reached. Waiting {sleep_time:.2f}s")
                    time.sleep(sleep_time)
                    # Remove old calls after waiting
                    while self.calls and self.calls[0] <= time.time() - self.time_window:
                        self.calls.popleft()
            
            # Record this call
            self.calls.append(time.time())
    
    def get_stats(self):
        """Get current rate limiter statistics"""
        with self.lock:
            now = time.time()
            # Count calls in current window
            recent_calls = sum(1 for call_time in self.calls if call_time > now - self.time_window)
            return {
                'calls_in_window': recent_calls,
                'max_calls': self.max_calls,
                'time_window': self.time_window,
                'utilization_pct': (recent_calls / self.max_calls) * 100
            }


class RangeContractionScanner:
    def __init__(self, api_key, access_token, use_cache=True, cache_expiry_hours=6, 
                 rate_limit_calls=10, rate_limit_window=1.0):
        """
        Initialize Kite Connect with caching and rate limiting
        
        Args:
            api_key: Kite Connect API key
            access_token: Access token for authentication
            use_cache: Enable/disable caching
            cache_expiry_hours: Hours before cache expires
            rate_limit_calls: Max API calls per time window (default: 10/second for historical data)
            rate_limit_window: Time window in seconds (default: 1 second)
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.use_cache = use_cache
        self.cache_manager = CacheManager(cache_expiry_hours=cache_expiry_hours) if use_cache else None
        self.rate_limiter = RateLimiter(max_calls=rate_limit_calls, time_window=rate_limit_window)
        self.api_call_count = 0
        self.cache_hit_count = 0
        self.rate_limit_wait_time = 0
        
    def get_historical_data(self, instrument_token, days=90):
        """Fetch historical data with caching and rate limiting (90 calendar days = ~60 trading days)"""
        
        # Try cache first
        if self.use_cache:
            cached_data = self.cache_manager.get(instrument_token, days)
            if cached_data is not None:
                self.cache_hit_count += 1
                return cached_data
        
        # Apply rate limiting before API call
        start_wait = time.time()
        self.rate_limiter.wait_if_needed()
        wait_time = time.time() - start_wait
        self.rate_limit_wait_time += wait_time
        
        if wait_time > 0:
            logger.debug(f"Rate limit wait: {wait_time:.2f}s")
        
        # Fetch from API
        try:
            to_date = datetime.now()
            from_date = to_date - timedelta(days=days)
            
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            self.api_call_count += 1
            
            # Save to cache
            if self.use_cache:
                self.cache_manager.set(instrument_token, days, df)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {instrument_token}: {e}")
            return None
    
    def is_insider_bar(self, high, low, prev_high, prev_low):
        """Check if current bar is an insider bar"""
        return high <= prev_high and low >= prev_low
    
    def calculate_atr(self, df, period=14):
        """Calculate Average True Range"""
        df['H-L'] = df['high'] - df['low']
        df['H-PC'] = abs(df['high'] - df['close'].shift(1))
        df['L-PC'] = abs(df['low'] - df['close'].shift(1))
        df['TR'] = df[['H-L', 'H-PC', 'L-PC']].max(axis=1)
        df['ATR'] = df['TR'].rolling(window=period).mean()
        return df
    
    def calculate_volatility_contraction(self, df, lookback=10):
        """Calculate if volatility is contracting"""
        df['range'] = df['high'] - df['low']
        df['range_ma'] = df['range'].rolling(window=lookback).mean()
        
        # Check if recent ranges are smaller than average
        recent_avg = df['range'].tail(3).mean()
        overall_avg = df['range_ma'].iloc[-1]
        
        return recent_avg < overall_avg * 0.7  # 30% contraction
    
    def detect_insider_bars(self, df):
        """Detect consecutive insider bars"""
        insider_count = 0
        
        for i in range(len(df) - 1, max(len(df) - 6, 0), -1):
            if i > 0:
                is_insider = self.is_insider_bar(
                    df.iloc[i]['high'],
                    df.iloc[i]['low'],
                    df.iloc[i-1]['high'],
                    df.iloc[i-1]['low']
                )
                
                if is_insider:
                    insider_count += 1
                else:
                    break
        
        return insider_count
    
    def check_volume_contraction(self, df):
        """Check if volume is contracting"""
        avg_volume = df['volume'].tail(20).mean()
        recent_volume = df['volume'].tail(3).mean()
        
        return recent_volume < avg_volume * 0.8  # 20% lower than average
    
    def detect_expansion(self, df):
        """Detect if range expansion is happening TODAY"""
        if len(df) < 10:
            return False, {}
        
        # Current day (most recent)
        current_range = df['high'].iloc[-1] - df['low'].iloc[-1]
        current_volume = df['volume'].iloc[-1]
        
        # Previous 3-5 days average (the contraction period)
        contraction_range_avg = (df['high'].iloc[-4:-1] - df['low'].iloc[-4:-1]).mean()
        contraction_volume_avg = df['volume'].iloc[-4:-1].mean()
        
        # 20-day averages for comparison
        range_20d_avg = (df['high'].tail(20) - df['low'].tail(20)).mean()
        volume_20d_avg = df['volume'].tail(20).mean()
        
        # Expansion criteria
        range_expansion_ratio = current_range / contraction_range_avg if contraction_range_avg > 0 else 0
        volume_expansion_ratio = current_volume / contraction_volume_avg if contraction_volume_avg > 0 else 0
        
        # Strong expansion: range 2x+ and volume 3x+
        is_strong_expansion = (range_expansion_ratio >= 2.0 and volume_expansion_ratio >= 3.0)
        
        # Moderate expansion: range 1.5x+ and volume 2x+
        is_moderate_expansion = (range_expansion_ratio >= 1.5 and volume_expansion_ratio >= 2.0)
        
        # Check if previous days had contraction
        had_contraction = contraction_range_avg < range_20d_avg * 0.8
        
        expansion_data = {
            'is_expanding': is_strong_expansion or is_moderate_expansion,
            'is_strong_expansion': is_strong_expansion,
            'is_moderate_expansion': is_moderate_expansion,
            'had_prior_contraction': had_contraction,
            'range_expansion_ratio': range_expansion_ratio,
            'volume_expansion_ratio': volume_expansion_ratio,
            'current_range': current_range,
            'contraction_range_avg': contraction_range_avg,
            'current_volume': current_volume,
            'contraction_volume_avg': contraction_volume_avg
        }
        
        return (is_strong_expansion or is_moderate_expansion) and had_contraction, expansion_data
    
    def check_trend(self, df):
        """Check if stock is in uptrend (above 50 SMA)"""
        df['SMA_50'] = df['close'].rolling(window=50).mean()
        current_close = df['close'].iloc[-1]
        current_sma = df['SMA_50'].iloc[-1]
        
        return current_close > current_sma, current_sma
    
    def calculate_score(self, metrics):
        """Calculate quality score for the setup"""
        score = 0
        
        # EXPANSION PHASE (Higher priority - actively breaking out)
        if metrics.get('is_expanding', False):
            # Strong expansion - HIGHEST priority (60 points)
            if metrics.get('is_strong_expansion', False):
                score += 60
            # Moderate expansion (40 points)
            elif metrics.get('is_moderate_expansion', False):
                score += 40
            
            # Bonus: Had prior contraction (20 points)
            if metrics.get('had_prior_contraction', False):
                score += 20
            
            # Volume expansion ratio bonus (up to 20 points)
            vol_ratio = metrics.get('volume_expansion_ratio', 0)
            if vol_ratio >= 5:
                score += 20
            elif vol_ratio >= 3:
                score += 15
            elif vol_ratio >= 2:
                score += 10
        
        # CONTRACTION PHASE (Lower priority - waiting for breakout)
        else:
            # Insider bars (max 30 points)
            if metrics['insider_bars'] >= 2:
                score += 30
            elif metrics['insider_bars'] == 1:
                score += 15
            
            # Volatility contraction (15 points)
            if metrics['volatility_contraction']:
                score += 15
            
            # Volume contraction (10 points)
            if metrics['volume_contraction']:
                score += 10
            
            # Range contraction percentage (10 points)
            if metrics.get('range_contraction_pct', 0) > 40:
                score += 10
            elif metrics.get('range_contraction_pct', 0) > 25:
                score += 5
        
        # Common factors for both phases
        # Uptrend (15 points)
        if metrics['in_uptrend']:
            score += 15
        
        return score
    
    def analyze_stock(self, symbol, instrument_token):
        """Analyze a single stock for range contraction/expansion pattern"""
        try:
            df = self.get_historical_data(instrument_token)
            
            if df is None or len(df) < 30:
                return None
            
            # Calculate indicators
            df = self.calculate_atr(df)
            
            # Get metrics
            insider_bars = self.detect_insider_bars(df)
            volatility_contraction = self.calculate_volatility_contraction(df)
            volume_contraction = self.check_volume_contraction(df)
            in_uptrend, sma_50 = self.check_trend(df)
            
            # Detect expansion (NEW - priority detection)
            is_expanding, expansion_data = self.detect_expansion(df)
            
            # Calculate range contraction percentage
            current_range = df['high'].iloc[-1] - df['low'].iloc[-1]
            avg_range = df['range'].tail(20).mean()
            range_contraction_pct = ((avg_range - current_range) / avg_range) * 100
            
            metrics = {
                'symbol': symbol,
                'close': df['close'].iloc[-1],
                'insider_bars': insider_bars,
                'volatility_contraction': volatility_contraction,
                'volume_contraction': volume_contraction,
                'in_uptrend': in_uptrend,
                'sma_50': sma_50,
                'atr': df['ATR'].iloc[-1],
                'range_contraction_pct': range_contraction_pct,
                'current_range': current_range,
                'avg_range': avg_range,
                # Expansion data
                'is_expanding': expansion_data.get('is_expanding', False),
                'is_strong_expansion': expansion_data.get('is_strong_expansion', False),
                'is_moderate_expansion': expansion_data.get('is_moderate_expansion', False),
                'had_prior_contraction': expansion_data.get('had_prior_contraction', False),
                'range_expansion_ratio': expansion_data.get('range_expansion_ratio', 0),
                'volume_expansion_ratio': expansion_data.get('volume_expansion_ratio', 0),
            }
            
            # Calculate quality score
            metrics['score'] = self.calculate_score(metrics)
            
            # UPDATED Filter: Prioritize expansion stocks OR good contraction setups
            if is_expanding:
                # Always return expanding stocks
                return metrics
            elif insider_bars >= 1 or (volatility_contraction and range_contraction_pct > 30):
                # Return contraction setups
                return metrics
            
            return None
            
        except Exception as e:
            logger.error(f"Error analyzing {symbol}: {e}")
            return None
    
    def scan_from_csv(self, csv_path, symbol_column='Symbol'):
        """Scan stocks from CSV file"""
        try:
            # Read CSV
            df = pd.read_csv(csv_path)
            logger.info(f"Loaded {len(df)} symbols from {csv_path}")
            
            # Get symbols
            if symbol_column not in df.columns:
                logger.error(f"Column '{symbol_column}' not found in CSV")
                return []
            
            symbols = df[symbol_column].tolist()
            
            # Get instrument tokens
            all_instruments = self.kite.instruments("NSE")
            instrument_map = {
                inst['tradingsymbol']: inst['instrument_token']
                for inst in all_instruments
                if inst['segment'] == 'NSE' and inst['instrument_type'] == 'EQ'
            }
            
            # Filter valid symbols
            valid_symbols = [s for s in symbols if s in instrument_map]
            invalid_symbols = [s for s in symbols if s not in instrument_map]
            
            if invalid_symbols:
                logger.warning(f"Invalid symbols (not found): {invalid_symbols[:10]}...")
            
            logger.info(f"Scanning {len(valid_symbols)} valid symbols")
            logger.info(f"Rate limit: {self.rate_limiter.max_calls} calls per {self.rate_limiter.time_window}s")
            
            # Estimate time
            estimated_api_calls = len(valid_symbols) - (self.cache_hit_count if self.use_cache else 0)
            estimated_time = (estimated_api_calls / self.rate_limiter.max_calls) * self.rate_limiter.time_window
            logger.info(f"Estimated time (worst case): {estimated_time:.1f}s")
            
            # Scan stocks
            results = []
            start_time = time.time()
            
            for idx, symbol in enumerate(valid_symbols, 1):
                if idx % 10 == 0:
                    elapsed = time.time() - start_time
                    rate_stats = self.rate_limiter.get_stats()
                    logger.info(f"Progress: {idx}/{len(valid_symbols)} | "
                              f"API: {self.api_call_count} | "
                              f"Cache: {self.cache_hit_count} | "
                              f"Rate: {rate_stats['calls_in_window']}/{rate_stats['max_calls']} | "
                              f"Elapsed: {elapsed:.1f}s")
                
                result = self.analyze_stock(symbol, instrument_map[symbol])
                if result:
                    results.append(result)
            
            return results
            
        except Exception as e:
            logger.error(f"Error reading CSV: {e}")
            return []
    
    def scan_market(self, instruments_list):
        """Scan multiple instruments"""
        results = []
        
        logger.info(f"Scanning {len(instruments_list)} instruments...")
        logger.info(f"Rate limit: {self.rate_limiter.max_calls} calls per {self.rate_limiter.time_window}s")
        
        start_time = time.time()
        
        for idx, instrument in enumerate(instruments_list, 1):
            if idx % 10 == 0:
                elapsed = time.time() - start_time
                rate_stats = self.rate_limiter.get_stats()
                logger.info(f"Progress: {idx}/{len(instruments_list)} | "
                          f"API: {self.api_call_count} | "
                          f"Cache: {self.cache_hit_count} | "
                          f"Rate: {rate_stats['calls_in_window']}/{rate_stats['max_calls']} | "
                          f"Elapsed: {elapsed:.1f}s")
            
            result = self.analyze_stock(
                instrument['tradingsymbol'],
                instrument['instrument_token']
            )
            
            if result:
                results.append(result)
        
        # Sort by score
        results = sorted(results, key=lambda x: x['score'], reverse=True)
        
        return results
    
    def display_results(self, results, min_score=30):
        """Display scan results"""
        filtered = [r for r in results if r['score'] >= min_score]
        
        # Separate expansion and contraction stocks
        expanding_stocks = [r for r in filtered if r.get('is_expanding', False)]
        contraction_stocks = [r for r in filtered if not r.get('is_expanding', False)]
        
        print("\n" + "="*120)
        print("RANGE EXPANSION & CONTRACTION SCANNER RESULTS")
        print("="*120)
        
        # Show cache statistics
        if self.use_cache:
            cache_stats = self.cache_manager.get_stats()
            cache_hit_rate = (self.cache_hit_count / (self.cache_hit_count + self.api_call_count) * 100) if (self.cache_hit_count + self.api_call_count) > 0 else 0
            print(f"\n📊 Cache Statistics:")
            print(f"   API Calls: {self.api_call_count}")
            print(f"   Cache Hits: {self.cache_hit_count}")
            print(f"   Cache Hit Rate: {cache_hit_rate:.1f}%")
            print(f"   Total Cached: {cache_stats['valid_entries']} entries ({cache_stats['total_size_mb']} MB)")
        
        # Show rate limit statistics
        rate_stats = self.rate_limiter.get_stats()
        print(f"\n⚡ Rate Limit Statistics:")
        print(f"   Max Rate: {rate_stats['max_calls']} calls per {rate_stats['time_window']}s")
        print(f"   Current Utilization: {rate_stats['utilization_pct']:.1f}%")
        print(f"   Total Wait Time: {self.rate_limit_wait_time:.2f}s")
        
        print(f"\n✓ Found {len(filtered)} stocks meeting criteria (Score >= {min_score})")
        print(f"   🚀 EXPANDING NOW: {len(expanding_stocks)} stocks")
        print(f"   ⏳ IN CONTRACTION: {len(contraction_stocks)} stocks")
        print("\n")
        
        if not filtered:
            print("No stocks found meeting the criteria.")
            return
        
        # ========== EXPANSION STOCKS (PRIORITY) ==========
        if expanding_stocks:
            print("="*120)
            print("🚀 STOCKS IN ACTIVE EXPANSION (Buy Now - Breakout Happening!)")
            print("="*120)
            print(f"{'Symbol':<15} {'Score':<8} {'Price':<10} {'Status':<18} {'Range Exp':<12} {'Vol Exp':<12} {'Trend':<10}")
            print("-"*120)
            
            for stock in expanding_stocks:
                status = "🔥 STRONG" if stock.get('is_strong_expansion') else "📈 MODERATE"
                print(f"{stock['symbol']:<15} "
                      f"{stock['score']:<8} "
                      f"{stock['close']:<10.2f} "
                      f"{status:<18} "
                      f"{stock.get('range_expansion_ratio', 0):<12.2f}x "
                      f"{stock.get('volume_expansion_ratio', 0):<12.2f}x "
                      f"{'Up' if stock['in_uptrend'] else 'Down':<10}")
            
            # Detailed analysis for top expansion stocks
            print("\n" + "="*120)
            print("🔥 TOP EXPANSION STOCKS - DETAILED ANALYSIS")
            print("="*120)
            
            for stock in expanding_stocks[:5]:
                status = "STRONG EXPANSION" if stock.get('is_strong_expansion') else "MODERATE EXPANSION"
                print(f"\n🚀 {stock['symbol']} - Quality Score: {stock['score']}/115 [{status}]")
                print(f"  💰 Current Price: ₹{stock['close']:.2f}")
                print(f"  📊 Range Expansion: {stock.get('range_expansion_ratio', 0):.2f}x (current vs previous 3 days)")
                print(f"  📈 Volume Expansion: {stock.get('volume_expansion_ratio', 0):.2f}x (current vs previous 3 days)")
                print(f"  ⏮️  Had Prior Contraction: {'✓ Yes' if stock.get('had_prior_contraction') else '✗ No'}")
                print(f"  📉 Trend: {'✓ Uptrend' if stock['in_uptrend'] else '✗ Downtrend'} (50 SMA: ₹{stock['sma_50']:.2f})")
                print(f"  🎯 ATR: ₹{stock['atr']:.2f}")
                print(f"  📏 Current Range: ₹{stock['current_range']:.2f}")
        
        # ========== CONTRACTION STOCKS (Watch List) ==========
        if contraction_stocks:
            print("\n" + "="*120)
            print("⏳ STOCKS IN CONTRACTION (Watch List - Waiting for Breakout)")
            print("="*120)
            print(f"{'Symbol':<15} {'Score':<8} {'Price':<10} {'Insider':<10} {'Vol Cont':<10} {'Trend':<10} {'Range %':<10}")
            print("-"*120)
            
            for stock in contraction_stocks:
                print(f"{stock['symbol']:<15} "
                      f"{stock['score']:<8} "
                      f"{stock['close']:<10.2f} "
                      f"{stock['insider_bars']:<10} "
                      f"{'Yes' if stock['volume_contraction'] else 'No':<10} "
                      f"{'Up' if stock['in_uptrend'] else 'Down':<10} "
                      f"{stock['range_contraction_pct']:<10.1f}")
            
            # Detailed analysis for top contraction stocks
            print("\n" + "="*120)
            print("⏳ TOP CONTRACTION STOCKS - DETAILED ANALYSIS")
            print("="*120)
            
            for stock in contraction_stocks[:5]:
                print(f"\n⏳ {stock['symbol']} - Quality Score: {stock['score']}/100 [CONTRACTION SETUP]")
                print(f"  💰 Current Price: ₹{stock['close']:.2f}")
                print(f"  📊 Insider Bars: {stock['insider_bars']}")
                print(f"  📉 Volatility Contraction: {'✓ Yes' if stock['volatility_contraction'] else '✗ No'}")
                print(f"  📉 Volume Contraction: {'✓ Yes' if stock['volume_contraction'] else '✗ No'}")
                print(f"  📈 Trend: {'✓ Uptrend' if stock['in_uptrend'] else '✗ Downtrend'} (50 SMA: ₹{stock['sma_50']:.2f})")
                print(f"  📏 Range Contraction: {stock['range_contraction_pct']:.1f}%")
                print(f"  🎯 ATR: ₹{stock['atr']:.2f}")
                print(f"  📏 Current Range: ₹{stock['current_range']:.2f} vs Avg: ₹{stock['avg_range']:.2f}")
    
    def get_performance_stats(self):
        """Get performance statistics"""
        rate_stats = self.rate_limiter.get_stats()
        return {
            'api_calls': self.api_call_count,
            'cache_hits': self.cache_hit_count,
            'cache_hit_rate': (self.cache_hit_count / (self.cache_hit_count + self.api_call_count) * 100) 
                             if (self.cache_hit_count + self.api_call_count) > 0 else 0,
            'rate_limit_wait_time': self.rate_limit_wait_time,
            'rate_limit_utilization': rate_stats['utilization_pct']
        }


def main():
    """Main execution function"""
    
    # ============================================
    # CONFIGURATION
    # ============================================
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "Ugdu4KaylHzCMxHysqfKHX8FuFH24s3j"
    
    # Cache settings
    USE_CACHE = True  # Set to False to disable caching
    CACHE_EXPIRY_HOURS = 6  # Cache expires after 6 hours (intraday trading)
    CLEAR_CACHE_ON_START = True  # Set to True to fetch fresh data (NEEDED: cache has only 40 days)
    
    # Rate limiting settings (Kite Connect API limits)
    RATE_LIMIT_CALLS = 10  # Max calls per time window
    RATE_LIMIT_WINDOW = 1.0  # Time window in seconds (10 calls/second for historical data)
    
    # CSV input file
    CSV_FILE = "data\\Sector-MCAP-great2500-output.csv"  # Your CSV file with Symbol column
    SYMBOL_COLUMN = "symbol"  # Column name containing stock symbols
    
    # ============================================
    # Initialize scanner with caching and rate limiting
    # ============================================
    scanner = RangeContractionScanner(
        API_KEY, 
        ACCESS_TOKEN,
        use_cache=USE_CACHE,
        cache_expiry_hours=CACHE_EXPIRY_HOURS,
        rate_limit_calls=RATE_LIMIT_CALLS,
        rate_limit_window=RATE_LIMIT_WINDOW
    )
    
    # Clear cache if requested
    if USE_CACHE:
        if CLEAR_CACHE_ON_START:
            scanner.cache_manager.clear_all()
            logger.info("All cache cleared - fetching fresh data")
        else:
            scanner.cache_manager.clear_expired()
            logger.info("Expired cache cleared")
    
    # ============================================
    # Option 1: Scan from CSV file
    # ============================================
    if os.path.exists(CSV_FILE):
        logger.info(f"Scanning stocks from {CSV_FILE}")
        results = scanner.scan_from_csv(CSV_FILE, symbol_column=SYMBOL_COLUMN)
    else:
        # ============================================
        # Option 2: Scan from predefined list
        # ============================================
        logger.info("CSV not found, using predefined list")
        instruments = scanner.kite.instruments("NSE")
        equity_instruments = [
            inst for inst in instruments 
            if inst['segment'] == 'NSE' and inst['instrument_type'] == 'EQ'
        ]
        
        # Scan first 100 stocks for testing
        results = scanner.scan_market(equity_instruments[:100])
    
    # ============================================
    # Display results
    # ============================================
    scanner.display_results(results, min_score=30)  # Show quality setups
    
    # ============================================
    # Export to CSV
    # ============================================
    if results:
        df_results = pd.DataFrame(results)
        filename = f"range_contraction_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        df_results.to_csv(filename, index=False)
        print(f"\n✓ Results exported to: {filename}")
    
    # ============================================
    # Performance statistics
    # ============================================
    stats = scanner.get_performance_stats()
    print(f"\n📈 Performance Summary:")
    print(f"   Total API Calls: {stats['api_calls']}")
    print(f"   Cache Hits: {stats['cache_hits']}")
    print(f"   Cache Hit Rate: {stats['cache_hit_rate']:.1f}%")
    print(f"   Time Saved: ~{stats['cache_hits'] * 0.2:.1f} seconds")


if __name__ == "__main__":
    main()