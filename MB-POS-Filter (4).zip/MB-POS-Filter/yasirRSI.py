"""
RSI Trading Signal Scanner with Timeframe Flexibility
Supports both DAILY and WEEKLY timeframes with auto-adjusted parameters
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
import time
import os
from typing import Dict, List, Tuple, Optional
import logging
import pickle
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class TimeframeConfig:
    """Configuration class for different timeframes"""
    
    @staticmethod
    def get_config(timeframe: str) -> Dict:
        """Get timeframe-specific configuration"""
        configs = {
            'daily': {
                'interval': 'day',
                'lookback_days': 89,
                'buffer_days': 55,
                'rsi_length': 13,
                'ema_short': 8,
                'ema_mid': 21,
                'ema_long': 55,
                'atr_period': 14,
                'volume_lookback': 21,
                'trend_slope_lookback': 5,
                'min_candles': 55,
                'cache_duration_hours': 24,
                'display_name': 'Daily'
            },
            'weekly': {
                'interval': 'week',
                'lookback_days': 377,  # ~100 weeks
                'buffer_days': 144,    # ~60 weeks buffer
                'rsi_length': 13,
                'ema_short': 8,
                'ema_mid': 21,
                'ema_long': 55,
                'atr_period': 14,
                'volume_lookback': 21,
                'trend_slope_lookback': 5,
                'min_candles': 55,
                'cache_duration_hours': 168,  # 1 week
                'display_name': 'Weekly'
            }
        }
        
        if timeframe.lower() not in configs:
            raise ValueError(f"Invalid timeframe: {timeframe}. Choose 'daily' or 'weekly'")
        
        return configs[timeframe.lower()]


class RateLimiter:
    """Rate limiter for Kite Connect API calls"""
    
    def __init__(self, calls_per_second=3):
        self.calls_per_second = calls_per_second
        self.min_interval = 1.0 / calls_per_second
        self.last_call = 0
    
    def wait(self):
        """Wait if necessary to respect rate limits"""
        elapsed = time.time() - self.last_call
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_call = time.time()


class InstrumentCache:
    """Cache for NSE instruments with auto-refresh"""
    
    def __init__(self, cache_file='nse_instruments_cache.pkl', cache_duration_hours=24):
        self.cache_file = cache_file
        self.cache_duration = timedelta(hours=cache_duration_hours)
        self.instruments = None
        self.last_updated = None
    
    def is_cache_valid(self) -> bool:
        """Check if cache is still valid"""
        if not os.path.exists(self.cache_file):
            return False
        if self.last_updated is None:
            return False
        return datetime.now() - self.last_updated < self.cache_duration
    
    def load_cache(self) -> bool:
        """Load instruments from cache file"""
        try:
            if os.path.exists(self.cache_file):
                with open(self.cache_file, 'rb') as f:
                    cache_data = pickle.load(f)
                    self.instruments = cache_data['instruments']
                    self.last_updated = cache_data['timestamp']
                    logger.info(f"Loaded {len(self.instruments)} instruments from cache")
                    return True
        except Exception as e:
            logger.error(f"Error loading cache: {e}")
        return False
    
    def save_cache(self):
        """Save instruments to cache file"""
        try:
            cache_data = {
                'instruments': self.instruments,
                'timestamp': self.last_updated
            }
            with open(self.cache_file, 'wb') as f:
                pickle.dump(cache_data, f)
            logger.info(f"Saved {len(self.instruments)} instruments to cache")
        except Exception as e:
            logger.error(f"Error saving cache: {e}")
    
    def refresh(self, kite: KiteConnect):
        """Refresh instrument cache from Kite API"""
        try:
            logger.info("Fetching instruments from Kite API...")
            all_instruments = kite.instruments("NSE")
            self.instruments = pd.DataFrame(all_instruments)
            self.last_updated = datetime.now()
            self.save_cache()
            logger.info(f"Refreshed {len(self.instruments)} NSE instruments")
        except Exception as e:
            logger.error(f"Error refreshing instruments: {e}")
            raise
    
    def get_instruments(self, kite: KiteConnect) -> pd.DataFrame:
        """Get instruments with automatic cache management"""
        if not self.is_cache_valid():
            if not self.load_cache() or not self.is_cache_valid():
                self.refresh(kite)
        return self.instruments
    
    def search_instrument(self, symbol: str) -> Optional[Dict]:
        """Search for an instrument by symbol"""
        if self.instruments is None:
            return None
        matches = self.instruments[self.instruments['tradingsymbol'] == symbol]
        if len(matches) > 0:
            return matches.iloc[0].to_dict()
        return None


class RSIScanner:
    """
    Enhanced RSI Scanner with timeframe flexibility and distinct strategies:
    1. REVERSAL: Counter-trend trading (RSI extremes + engulfing patterns)
    2. TREND-FOLLOWING: With-trend trading (RSI pullbacks in established trends)
    """
    
    def __init__(self, api_key: str, access_token: str, timeframe: str = 'daily'):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.rate_limiter = RateLimiter(calls_per_second=3)
        self.instrument_cache = InstrumentCache()
        
        # Set timeframe and load configuration
        self.timeframe = timeframe.lower()
        self.config = TimeframeConfig.get_config(self.timeframe)
        
        # Apply timeframe-specific parameters
        self.rsi_length = self.config['rsi_length']
        self.ema_short = self.config['ema_short']
        self.ema_mid = self.config['ema_mid']
        self.ema_long = self.config['ema_long']
        self.atr_period = self.config['atr_period']
        
        # REVERSAL strategy parameters (counter-trend)
        self.reversal_rsi_overbought = 75
        self.reversal_rsi_oversold = 25
        
        # TREND-FOLLOWING strategy parameters (with-trend pullbacks)
        self.trend_rsi_buy_zone = (45, 60)
        self.trend_rsi_sell_zone = (55, 70)
        
        # Filtering parameters
        self.min_volume_ratio = 1.0
        self.min_strength_score = 50
        
        logger.info(f"Scanner initialized for {self.config['display_name']} timeframe")
    
    def fetch_historical_data(self, instrument_token: int, from_date: datetime, 
                            to_date: datetime) -> pd.DataFrame:
        """Fetch historical data with rate limiting"""
        self.rate_limiter.wait()
        
        try:
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=self.config['interval']
            )
            
            if not data:
                return pd.DataFrame()
            
            df = pd.DataFrame(data)
            
            # Data validation
            if df['close'].isnull().any():
                logger.warning(f"Missing data for token {instrument_token}")
                return pd.DataFrame()
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for token {instrument_token}: {e}")
            return pd.DataFrame()
    
    def calculate_rsi(self, prices: pd.Series, period: int = None) -> pd.Series:
        """Calculate RSI using exponential moving average (Wilder's method)"""
        if period is None:
            period = self.rsi_length
            
        delta = prices.diff()
        gains = delta.where(delta > 0, 0)
        losses = -delta.where(delta < 0, 0)
        
        # Use EMA with alpha = 1/period (Wilder's smoothing)
        avg_gains = gains.ewm(alpha=1/period, adjust=False).mean()
        avg_losses = losses.ewm(alpha=1/period, adjust=False).mean()
        
        rs = avg_gains / avg_losses
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def detect_trend(self, df: pd.DataFrame) -> Tuple[str, Dict]:
        """Detect overall trend using multiple EMAs"""
        if len(df) < self.ema_long:
            return 'UNKNOWN', {}
        
        latest = df.iloc[-1]
        
        ema_short = df['close'].ewm(span=self.ema_short, adjust=False).mean()
        ema_mid = df['close'].ewm(span=self.ema_mid, adjust=False).mean()
        ema_long = df['close'].ewm(span=self.ema_long, adjust=False).mean()
        
        ema_short_current = ema_short.iloc[-1]
        ema_mid_current = ema_mid.iloc[-1]
        ema_long_current = ema_long.iloc[-1]
        
        # Calculate slopes using lookback from config
        lookback = self.config['trend_slope_lookback']
        ema_mid_slope = ((ema_mid.iloc[-1] - ema_mid.iloc[-lookback]) / ema_mid.iloc[-lookback]) * 100
        ema_long_slope = ((ema_long.iloc[-1] - ema_long.iloc[-lookback]) / ema_long.iloc[-lookback]) * 100
        
        trend_metrics = {
            'ema_short': round(ema_short_current, 2),
            'ema_mid': round(ema_mid_current, 2),
            'ema_long': round(ema_long_current, 2),
            'ema_mid_slope': round(ema_mid_slope, 2),
            'ema_long_slope': round(ema_long_slope, 2),
            'price': latest['close']
        }
        
        # Strong uptrend: EMAs aligned + positive slopes
        if (latest['close'] > ema_short_current > ema_mid_current > ema_long_current and 
            ema_mid_slope > 0.5 and ema_long_slope > 0.3):
            return 'STRONG_UPTREND', trend_metrics
        
        # Uptrend: Price above key EMAs
        elif latest['close'] > ema_mid_current > ema_long_current:
            return 'UPTREND', trend_metrics
        
        # Strong downtrend: EMAs aligned + negative slopes
        elif (latest['close'] < ema_short_current < ema_mid_current < ema_long_current and 
              ema_mid_slope < -0.5 and ema_long_slope < -0.3):
            return 'STRONG_DOWNTREND', trend_metrics
        
        # Downtrend: Price below key EMAs
        elif latest['close'] < ema_mid_current < ema_long_current:
            return 'DOWNTREND', trend_metrics
        
        else:
            return 'SIDEWAYS', trend_metrics
    
    def calculate_atr(self, df: pd.DataFrame, period: int = None) -> pd.Series:
        """Calculate Average True Range"""
        if period is None:
            period = self.atr_period
            
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        
        ranges = pd.concat([high_low, high_close, low_close], axis=1)
        true_range = ranges.max(axis=1)
        atr = true_range.ewm(span=period, adjust=False).mean()
        
        return atr
    
    def detect_engulfing_patterns(self, df: pd.DataFrame) -> Tuple[pd.Series, pd.Series]:
        """Detect engulfing patterns"""
        bullish_engulfing = (
            (df['close'] > df['open']) &
            (df['close'].shift(1) < df['open'].shift(1)) &
            (df['close'] > df['open'].shift(1)) &
            (df['open'] < df['close'].shift(1))
        )
        
        bearish_engulfing = (
            (df['close'] < df['open']) &
            (df['close'].shift(1) > df['open'].shift(1)) &
            (df['close'] < df['open'].shift(1)) &
            (df['open'] > df['close'].shift(1))
        )
        
        return bullish_engulfing, bearish_engulfing
    
    def calculate_volume_ratio(self, df: pd.DataFrame) -> float:
        """Calculate current volume vs average volume"""
        if 'volume' not in df.columns or len(df) < self.config['volume_lookback']:
            return 1.0
        
        latest_volume = df.iloc[-1]['volume']
        avg_volume = df['volume'].tail(self.config['volume_lookback']).mean()
        
        if avg_volume > 0:
            return latest_volume / avg_volume
        return 1.0
    
    """
    IMPROVED analyze_strength METHOD
    Replace the existing analyze_strength method in your RSIScanner class with this version
    """

    def analyze_strength(self, df: pd.DataFrame, signal_type: str, strategy: str) -> Dict:
        """
        Calculate signal strength score (0-100) with REALISTIC scoring
        
        Key Changes:
        1. More generous point allocation
        2. Better handling of edge cases
        3. Bonus points for ideal conditions
        4. Progressive scoring (not binary)
        """
        latest = df.iloc[-1]
        prev = df.iloc[-2] if len(df) >= 2 else latest
        strength_score = 0
        factors = []
        
        # ========================================================================
        # COMPONENT 1: RSI POSITION (0-30 points)
        # ========================================================================
        if strategy == 'REVERSAL':
            # For reversals, reward extreme RSI values
            if signal_type == 'BUY':
                # Perfect score at RSI=20, declining to RSI=40
                if latest['rsi'] <= 20:
                    rsi_score = 30
                elif latest['rsi'] <= 35:
                    rsi_score = 25 + (35 - latest['rsi']) / 3  # 25-30 points
                elif latest['rsi'] <= 40:
                    rsi_score = 20 + (40 - latest['rsi'])  # 20-25 points
                else:
                    rsi_score = max(0, 20 - (latest['rsi'] - 40) * 0.5)  # Declining
            else:  # SELL
                if latest['rsi'] >= 80:
                    rsi_score = 30
                elif latest['rsi'] >= 65:
                    rsi_score = 25 + (latest['rsi'] - 65) / 3  # 25-30 points
                elif latest['rsi'] >= 60:
                    rsi_score = 20 + (latest['rsi'] - 60)  # 20-25 points
                else:
                    rsi_score = max(0, 20 - (60 - latest['rsi']) * 0.5)
            
            factors.append(f"RSI Extreme: {latest['rsi']:.1f} → {rsi_score:.1f}pts")
        
        else:  # TREND_FOLLOWING
            # For trend-following, reward ideal pullback zones
            if signal_type == 'BUY':
                # Ideal zone: 45-50 (sweet spot for pullbacks)
                if 45 <= latest['rsi'] <= 50:
                    rsi_score = 30  # Perfect pullback
                elif 40 <= latest['rsi'] <= 55:
                    rsi_score = 25  # Good pullback
                elif 35 <= latest['rsi'] <= 60:
                    rsi_score = 20  # Acceptable pullback
                else:
                    rsi_score = 15  # Marginal
            else:  # SELL
                if 50 <= latest['rsi'] <= 55:
                    rsi_score = 30
                elif 45 <= latest['rsi'] <= 60:
                    rsi_score = 25
                elif 40 <= latest['rsi'] <= 65:
                    rsi_score = 20
                else:
                    rsi_score = 15
            
            factors.append(f"RSI Pullback: {latest['rsi']:.1f} → {rsi_score:.1f}pts")
        
        strength_score += rsi_score
        
        # ========================================================================
        # COMPONENT 2: VOLUME CONFIRMATION (0-25 points)
        # ========================================================================
        vol_ratio = self.calculate_volume_ratio(df)
        
        # Progressive scoring based on volume
        if vol_ratio >= 2.0:
            vol_score = 25  # Exceptional volume
        elif vol_ratio >= 1.5:
            vol_score = 20 + (vol_ratio - 1.5) * 10  # 20-25 points
        elif vol_ratio >= 1.0:
            vol_score = 15 + (vol_ratio - 1.0) * 10  # 15-20 points
        elif vol_ratio >= 0.7:
            vol_score = 10 + (vol_ratio - 0.7) * 16.67  # 10-15 points
        else:
            vol_score = max(5, vol_ratio * 14.3)  # 5-10 points minimum
        
        strength_score += vol_score
        factors.append(f"Volume: {vol_ratio:.2f}x → {vol_score:.1f}pts")
        
        # ========================================================================
        # COMPONENT 3: CANDLE STRENGTH (0-20 points)
        # ========================================================================
        body_size = abs(latest['close'] - latest['open'])
        candle_range = latest['high'] - latest['low']
        
        if candle_range > 0:
            body_ratio = body_size / candle_range
            
            # Progressive scoring for candle body
            if body_ratio >= 0.7:
                candle_score = 20  # Strong decisive candle
            elif body_ratio >= 0.5:
                candle_score = 15 + (body_ratio - 0.5) * 25  # 15-20 points
            elif body_ratio >= 0.3:
                candle_score = 10 + (body_ratio - 0.3) * 25  # 10-15 points
            else:
                candle_score = body_ratio * 33.3  # 0-10 points
            
            # Bonus for correct direction
            if signal_type == 'BUY' and latest['close'] > latest['open']:
                candle_score = min(20, candle_score * 1.1)  # 10% bonus
            elif signal_type == 'SELL' and latest['close'] < latest['open']:
                candle_score = min(20, candle_score * 1.1)
            
            factors.append(f"Candle Body: {body_ratio:.2%} → {candle_score:.1f}pts")
        else:
            candle_score = 5  # Minimum for doji/narrow range
            factors.append(f"Candle: Doji → {candle_score:.1f}pts")
        
        strength_score += candle_score
        
        # ========================================================================
        # COMPONENT 4: TREND/MOMENTUM ALIGNMENT (0-25 points)
        # ========================================================================
        if strategy == 'TREND_FOLLOWING':
            # For trend-following, check trend strength
            ema_slope = abs(latest.get('ema_mid_slope', 0))
            
            if ema_slope >= 3.0:
                trend_score = 25  # Very strong trend
            elif ema_slope >= 2.0:
                trend_score = 20 + (ema_slope - 2.0) * 5  # 20-25 points
            elif ema_slope >= 1.0:
                trend_score = 15 + (ema_slope - 1.0) * 5  # 15-20 points
            elif ema_slope >= 0.5:
                trend_score = 10 + (ema_slope - 0.5) * 10  # 10-15 points
            else:
                trend_score = max(5, ema_slope * 20)  # 5-10 points minimum
            
            factors.append(f"Trend Strength: {ema_slope:.2f}% → {trend_score:.1f}pts")
        
        else:  # REVERSAL
            # For reversals, check momentum exhaustion
            if len(df) >= 5:
                # Calculate recent momentum
                price_change = (latest['close'] - df.iloc[-5]['close']) / df.iloc[-5]['close']
                momentum_pct = abs(price_change * 100)
                
                # Higher momentum = better reversal setup
                if momentum_pct >= 5.0:
                    momentum_score = 25  # Strong momentum to reverse
                elif momentum_pct >= 3.0:
                    momentum_score = 20 + (momentum_pct - 3.0) * 2.5  # 20-25 points
                elif momentum_pct >= 2.0:
                    momentum_score = 15 + (momentum_pct - 2.0) * 5  # 15-20 points
                elif momentum_pct >= 1.0:
                    momentum_score = 10 + (momentum_pct - 1.0) * 5  # 10-15 points
                else:
                    momentum_score = max(5, momentum_pct * 10)  # 5-10 points
                
                factors.append(f"Momentum: {momentum_pct:.2f}% → {momentum_score:.1f}pts")
            else:
                momentum_score = 10  # Default if insufficient data
                factors.append(f"Momentum: Limited data → {momentum_score:.1f}pts")
            
            trend_score = momentum_score
        
        strength_score += trend_score
        
        # ========================================================================
        # BONUS POINTS (0-10 extra points possible)
        # ========================================================================
        bonus_points = 0
        
        # Bonus 1: RSI divergence from previous bar (momentum building)
        rsi_change = abs(latest['rsi'] - prev['rsi'])
        if rsi_change >= 5:
            bonus = min(5, rsi_change / 2)
            bonus_points += bonus
            factors.append(f"BONUS - RSI Momentum: {rsi_change:.1f} → +{bonus:.1f}pts")
        
        # Bonus 2: Price near key EMAs (support/resistance)
        if 'ema_mid' in latest.index and 'ema_long' in latest.index:
            price = latest['close']
            ema_mid_val = latest.get('ema_mid', price)
            ema_long_val = latest.get('ema_long', price)
            
            # Check if price is near EMAs (within 2%)
            near_ema_mid = abs(price - ema_mid_val) / ema_mid_val < 0.02
            near_ema_long = abs(price - ema_long_val) / ema_long_val < 0.02
            
            if near_ema_mid or near_ema_long:
                bonus = 3
                bonus_points += bonus
                factors.append(f"BONUS - Near EMA Support: +{bonus:.1f}pts")
        
        # Bonus 3: Multiple timeframe alignment (if weekly matches daily direction)
        # This would require additional data, skipping for now
        
        strength_score += bonus_points
        
        # Cap at 100
        strength_score = min(100, strength_score)
        
        # ========================================================================
        # DETERMINE STRENGTH LEVEL
        # ========================================================================
        # Adjusted thresholds for more realistic classification
        if strength_score >= 70:
            level = 'STRONG'
        elif strength_score >= 55:
            level = 'MODERATE'
        elif strength_score >= 40:
            level = 'WEAK'
        else:
            level = 'VERY_WEAK'
        
        return {
            'score': round(strength_score, 2),
            'level': level,
            'factors': factors
        }

    
    def detect_reversal_signals(self, df: pd.DataFrame, trend: str) -> List[Dict]:
        """
        REVERSAL STRATEGY: Counter-trend signals
        - BUY: RSI extreme oversold + bullish engulfing in downtrend/sideways
        - SELL: RSI extreme overbought + bearish engulfing in uptrend/sideways
        """
        signals = []
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        
        # BUY REVERSAL: Extreme oversold + bullish pattern in downtrend
        if (latest['rsi'] <= self.reversal_rsi_oversold or 
            prev['rsi'] <= self.reversal_rsi_oversold):
            
            if latest['bullish_engulfing'] and trend in ['DOWNTREND', 'STRONG_DOWNTREND', 'SIDEWAYS']:
                strength = self.analyze_strength(df, 'BUY', 'REVERSAL')
                logger.info(f"strength score: {strength['score']}")
                if strength['score'] >= self.min_strength_score:
                    signals.append({
                        'type': 'BUY',
                        'strategy': 'REVERSAL',
                        'pattern': 'Bullish Engulfing',
                        'strength': strength,
                        'rsi': round(latest['rsi'], 2),
                        'entry_price': latest['close'],
                        'stop_loss': latest['close'] - (latest['atr'] * 2),
                        'take_profit': latest['close'] + (latest['atr'] * 3),
                        'description': 'Counter-trend buy in oversold downtrend'
                    })
        
        # SELL REVERSAL: Extreme overbought + bearish pattern in uptrend
        if (latest['rsi'] >= self.reversal_rsi_overbought or 
            prev['rsi'] >= self.reversal_rsi_overbought):
            
            if latest['bearish_engulfing'] and trend in ['UPTREND', 'STRONG_UPTREND', 'SIDEWAYS']:
                strength = self.analyze_strength(df, 'SELL', 'REVERSAL')
                logger.info(f"strength score: {strength['score']}")
                if strength['score'] >= self.min_strength_score:
                    signals.append({
                        'type': 'SELL',
                        'strategy': 'REVERSAL',
                        'pattern': 'Bearish Engulfing',
                        'strength': strength,
                        'rsi': round(latest['rsi'], 2),
                        'entry_price': latest['close'],
                        'stop_loss': latest['close'] + (latest['atr'] * 2),
                        'take_profit': latest['close'] - (latest['atr'] * 3),
                        'description': 'Counter-trend sell in overbought uptrend'
                    })
        
        return signals
    
    def detect_trend_following_signals(self, df: pd.DataFrame, trend: str) -> List[Dict]:
        """
        TREND-FOLLOWING STRATEGY: With-trend pullback entries
        - BUY: RSI pullback (40-55) in established uptrend + bullish candle
        - SELL: RSI pullback (45-60) in established downtrend + bearish candle
        """
        signals = []
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        
        # BUY TREND-FOLLOWING: Pullback in strong uptrend
        rsi_in_buy_zone = (self.trend_rsi_buy_zone[0] <= latest['rsi'] <= self.trend_rsi_buy_zone[1])
        
        if rsi_in_buy_zone and trend in ['UPTREND', 'STRONG_UPTREND']:
            is_bullish_candle = latest['close'] > latest['open']
            rsi_turning_up = latest['rsi'] > prev['rsi']
            
            if is_bullish_candle and rsi_turning_up:
                strength = self.analyze_strength(df, 'BUY', 'TREND_FOLLOWING')
                logger.info(f"strength score: {strength['score']}")
                if strength['score'] >= self.min_strength_score:
                    signals.append({
                        'type': 'BUY',
                        'strategy': 'TREND_FOLLOWING',
                        'pattern': 'Pullback Entry',
                        'strength': strength,
                        'rsi': round(latest['rsi'], 2),
                        'entry_price': latest['close'],
                        'stop_loss': latest['close'] - (latest['atr'] * 2),
                        'take_profit': latest['close'] + (latest['atr'] * 3),
                        'description': 'With-trend buy on pullback in uptrend'
                    })
        
        # SELL TREND-FOLLOWING: Pullback in strong downtrend
        rsi_in_sell_zone = (self.trend_rsi_sell_zone[0] <= latest['rsi'] <= self.trend_rsi_sell_zone[1])
        
        if rsi_in_sell_zone and trend in ['DOWNTREND', 'STRONG_DOWNTREND']:
            is_bearish_candle = latest['close'] < latest['open']
            rsi_turning_down = latest['rsi'] < prev['rsi']
            
            if is_bearish_candle and rsi_turning_down:
                strength = self.analyze_strength(df, 'SELL', 'TREND_FOLLOWING')
                logger.info(f"strength score: {strength['score']}")
                if strength['score'] >= self.min_strength_score:
                    signals.append({
                        'type': 'SELL',
                        'strategy': 'TREND_FOLLOWING',
                        'pattern': 'Pullback Entry',
                        'strength': strength,
                        'rsi': round(latest['rsi'], 2),
                        'entry_price': latest['close'],
                        'stop_loss': latest['close'] + (latest['atr'] * 2),
                        'take_profit': latest['close'] - (latest['atr'] * 3),
                        'description': 'With-trend sell on pullback in downtrend'
                    })
        
        return signals
    
    def scan_symbol(self, symbol: str) -> Optional[Dict]:
        """Scan single symbol for both reversal and trend-following signals"""
        try:
            instrument = self.instrument_cache.search_instrument(symbol)
            if instrument is None:
                return None
            
            to_date = datetime.now()
            from_date = to_date - timedelta(days=self.config['lookback_days'] + self.config['buffer_days'])
            
            df = self.fetch_historical_data(
                instrument_token=instrument['instrument_token'],
                from_date=from_date,
                to_date=to_date
            )
            
            if df.empty or len(df) < self.config['min_candles']:
                return None
            
            # Calculate indicators
            df['rsi'] = self.calculate_rsi(df['close'])
            df['atr'] = self.calculate_atr(df)
            df['bullish_engulfing'], df['bearish_engulfing'] = self.detect_engulfing_patterns(df)
            
            # Detect trend
            trend, trend_metrics = self.detect_trend(df)
            
            # Store trend metrics in latest row for strength calculation
            df.loc[df.index[-1], 'ema_mid_slope'] = trend_metrics.get('ema_mid_slope', 0)
            
            # Detect signals using both strategies
            reversal_signals = self.detect_reversal_signals(df, trend)
            trend_following_signals = self.detect_trend_following_signals(df, trend)
            
            all_signals = reversal_signals + trend_following_signals
            
            if not all_signals:
                return None
            
            latest = df.iloc[-1]
            
            return {
                'symbol': symbol,
                'last_price': latest['close'],
                'rsi': round(latest['rsi'], 2),
                'atr': round(latest['atr'], 2),
                'date': latest['date'],
                'trend': trend,
                'trend_metrics': trend_metrics,
                'volume_ratio': self.calculate_volume_ratio(df),
                'signals': all_signals
            }
            
        except Exception as e:
            logger.error(f"Error processing {symbol}: {e}")
            return None
    
    def scan_multiple(self, symbols: List[str]) -> List[Dict]:
        """Scan multiple symbols"""
        self.instrument_cache.get_instruments(self.kite)
        
        results = []
        total = len(symbols)
        
        for idx, symbol in enumerate(symbols, 1):
            logger.info(f"Processing {symbol} ({idx}/{total})...")
            result = self.scan_symbol(symbol)
            if result:
                results.append(result)
        
        return results
    
    def generate_report(self, results: List[Dict], filename: str = None) -> str:
        """Generate comprehensive report"""
        if filename is None:
            filename = f"rsi_scanner_{self.timeframe}_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        
        report = []
        report.append("=" * 120)
        report.append(f"RSI SCANNER - {self.config['display_name'].upper()} TIMEFRAME - DUAL STRATEGY REPORT")
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("=" * 120)
        
        # Timeframe info
        report.append(f"\nTIMEFRAME: {self.config['display_name']}")
        report.append(f"Interval: {self.config['interval']}")
        report.append(f"RSI Length: {self.rsi_length}")
        report.append(f"EMAs: {self.ema_short}/{self.ema_mid}/{self.ema_long}")
        report.append(f"ATR Period: {self.atr_period}")
        
        # Strategy descriptions
        report.append("\nSTRATEGY OVERVIEW:")
        report.append("-" * 120)
        report.append("\n1. REVERSAL STRATEGY (Counter-Trend):")
        report.append("   - BUY: RSI ≤ 30 + Bullish Engulfing in Downtrend/Sideways")
        report.append("   - SELL: RSI ≥ 70 + Bearish Engulfing in Uptrend/Sideways")
        report.append("   - Goal: Catch market reversals at extremes")
        
        report.append("\n2. TREND-FOLLOWING STRATEGY (With-Trend):")
        report.append("   - BUY: RSI 40-55 pullback in Uptrend + Bullish candle turning up")
        report.append("   - SELL: RSI 45-60 pullback in Downtrend + Bearish candle turning down")
        report.append("   - Goal: Enter on pullbacks in established trends")
        report.append("")
        
        # Summary statistics
        reversal_count = sum(len([s for s in r['signals'] if s['strategy'] == 'REVERSAL']) for r in results)
        trend_following_count = sum(len([s for s in r['signals'] if s['strategy'] == 'TREND_FOLLOWING']) for r in results)
        
        report.append(f"\nSUMMARY:")
        report.append(f"  Total Symbols Scanned: {len(results)}")
        report.append(f"  Reversal Signals: {reversal_count}")
        report.append(f"  Trend-Following Signals: {trend_following_count}")
        report.append(f"  Total Signals: {reversal_count + trend_following_count}")
        report.append("")
        
        report.append("=" * 120)
        report.append("\nDETAILED SIGNALS:")
        report.append("=" * 120)
        
        # Sort by signal strength
        for result in sorted(results, key=lambda x: max([s['strength']['score'] for s in x['signals']]), reverse=True):
            report.append(f"\n{'-'*120}")
            report.append(f"SYMBOL: {result['symbol']}")
            report.append(f"Price: Rs.{result['last_price']:.2f} | RSI: {result['rsi']} | ATR: {result['atr']:.2f}")
            report.append(f"Trend: {result['trend']} | Volume: {result['volume_ratio']:.2f}x")
            report.append(f"Date: {result['date']}")
            
            # Trend metrics
            tm = result['trend_metrics']
            report.append(f"\nTrend Metrics:")
            report.append(f"  EMA {self.ema_mid}: {tm['ema_mid']:.2f} (Slope: {tm['ema_mid_slope']:.2f}%)")
            report.append(f"  EMA {self.ema_long}: {tm['ema_long']:.2f} (Slope: {tm['ema_long_slope']:.2f}%)")
            
            # Signals
            for sig in result['signals']:
                report.append(f"\n  {'>'*3} {sig['strategy']} - {sig['type']} SIGNAL {'<'*3}")
                report.append(f"      Pattern: {sig['pattern']}")
                report.append(f"      Description: {sig['description']}")
                report.append(f"      Strength: {sig['strength']['score']:.1f}/100 ({sig['strength']['level']})")
                report.append(f"      Factors: {', '.join(sig['strength']['factors'])}")
                report.append(f"\n      Entry Price: Rs.{sig['entry_price']:.2f}")
                report.append(f"      Stop Loss: Rs.{sig['stop_loss']:.2f} (Risk: {abs(sig['entry_price']-sig['stop_loss']):.2f})")
                report.append(f"      Take Profit: Rs.{sig['take_profit']:.2f} (Reward: {abs(sig['take_profit']-sig['entry_price']):.2f})")
                report.append(f"      Risk:Reward Ratio: 1:{abs(sig['take_profit']-sig['entry_price'])/abs(sig['entry_price']-sig['stop_loss']):.2f}")
        
        report.append(f"\n{'='*120}")
        report.append("\nDISCLAIMER:")
        report.append("This is for educational purposes only. Past performance does not guarantee future results.")
        report.append("Always do your own research and consult with a financial advisor before trading.")
        report.append("=" * 120)
        
        report_text = "\n".join(report)
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        logger.info(f"Report saved to {filename}")
        return report_text
    
    def generate_csv(self, results: List[Dict], filename: str = None) -> str:
        """Generate CSV with all signals"""
        if filename is None:
            filename = f"rsi_scanner_{self.timeframe}_signals_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        rows = []
        
        for result in results:
            for sig in result['signals']:
                row = {
                    'Symbol': result['symbol'],
                    'Date': result['date'],
                    'Timeframe': self.config['display_name'],
                    'Price': result['last_price'],
                    'RSI': result['rsi'],
                    'ATR': result['atr'],
                    'Trend': result['trend'],
                    'Volume_Ratio': result['volume_ratio'],
                    'Signal_Type': sig['type'],
                    'Strategy': sig['strategy'],
                    'Pattern': sig['pattern'],
                    'Description': sig['description'],
                    'Strength_Score': sig['strength']['score'],
                    'Strength_Level': sig['strength']['level'],
                    'Entry_Price': sig['entry_price'],
                    'Stop_Loss': sig['stop_loss'],
                    'Take_Profit': sig['take_profit'],
                    'Risk_Amount': abs(sig['entry_price'] - sig['stop_loss']),
                    'Reward_Amount': abs(sig['take_profit'] - sig['entry_price']),
                    'Risk_Reward_Ratio': round(abs(sig['take_profit'] - sig['entry_price']) / abs(sig['entry_price'] - sig['stop_loss']), 2),
                    f'EMA_{self.ema_mid}': result['trend_metrics']['ema_mid'],
                    f'EMA_{self.ema_long}': result['trend_metrics']['ema_long'],
                    f'EMA_{self.ema_mid}_Slope': result['trend_metrics']['ema_mid_slope']
                }
                rows.append(row)
        
        df = pd.DataFrame(rows)
        
        if not df.empty:
            # Sort by strength score
            df = df.sort_values('Strength_Score', ascending=False)
            df.to_csv(filename, index=False)
            logger.info(f"CSV saved to {filename}")
        
        return filename


# Main execution
if __name__ == "__main__":
    import argparse
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='RSI Scanner with Timeframe Flexibility')
    parser.add_argument('--timeframe', type=str, default='daily', choices=['daily', 'weekly'],
                       help='Timeframe for scanning (default: daily)')
    parser.add_argument('--input', type=str, default='data\\MCAP-great2500.csv',
                       help='Input CSV file path (default: data\\MCAP-great2500.csv)')
    args = parser.parse_args()
    
    # Load credentials
    API_KEY = os.getenv('KITE_API_KEY', '3bi2yh8g830vq3y6')
    ACCESS_TOKEN = os.getenv('KITE_ACCESS_TOKEN', 'dzOazDfZI0xhF5DomxEtHG78exMZnU7P')
    
    # Initialize scanner with timeframe
    scanner = RSIScanner(API_KEY, ACCESS_TOKEN, timeframe=args.timeframe)
    
    # Configure parameters (can be overridden)
    scanner.reversal_rsi_overbought = 65
    scanner.reversal_rsi_oversold = 35
    scanner.trend_rsi_buy_zone = (35, 62)
    scanner.trend_rsi_sell_zone = (40, 65)
    scanner.min_volume_ratio = 0.75
    scanner.min_strength_score = 50
    
    print("\n" + "="*120)
    print(f"RSI SCANNER - {scanner.config['display_name'].upper()} TIMEFRAME - DUAL STRATEGY SYSTEM")
    print("="*120)
    print(f"\nTIMEFRAME CONFIGURATION:")
    print(f"  Timeframe: {scanner.config['display_name']}")
    print(f"  Interval: {scanner.config['interval']}")
    print(f"  Lookback Period: {scanner.config['lookback_days']} days (~{scanner.config['lookback_days']//7} weeks)")
    print(f"  Min Candles Required: {scanner.config['min_candles']}")
    
    print(f"\nTECHNICAL INDICATORS:")
    print(f"  RSI Length: {scanner.rsi_length}")
    print(f"  EMAs: {scanner.ema_short} / {scanner.ema_mid} / {scanner.ema_long}")
    print(f"  ATR Period: {scanner.atr_period}")
    print(f"  Volume Lookback: {scanner.config['volume_lookback']}")
    
    print(f"\nREVERSAL STRATEGY (Counter-Trend):")
    print(f"  RSI Overbought: {scanner.reversal_rsi_overbought}")
    print(f"  RSI Oversold: {scanner.reversal_rsi_oversold}")
    print(f"  Entry: Extreme RSI + Engulfing pattern in opposite trend")
    
    print(f"\nTREND-FOLLOWING STRATEGY (With-Trend):")
    print(f"  Buy Pullback Zone: RSI {scanner.trend_rsi_buy_zone[0]}-{scanner.trend_rsi_buy_zone[1]} in uptrend")
    print(f"  Sell Pullback Zone: RSI {scanner.trend_rsi_sell_zone[0]}-{scanner.trend_rsi_sell_zone[1]} in downtrend")
    print(f"  Entry: RSI turning + momentum candle in trend direction")
    
    print(f"\nFILTERS:")
    print(f"  Min Volume Ratio: {scanner.min_volume_ratio}x")
    print(f"  Min Strength Score: {scanner.min_strength_score}/100")
    
    print(f"\nRISK MANAGEMENT:")
    print(f"  Stop Loss: 2x ATR")
    print(f"  Take Profit: 3x ATR")
    print(f"  Risk:Reward = 1:1.5")
    print("="*120 + "\n")
    
    # Load symbols
    try:
        input_df = pd.read_csv(args.input)
        input_df.columns = input_df.columns.str.strip()
        
        if 'Symbol' not in input_df.columns:
            raise ValueError("CSV must have 'Symbol' column")
        
        symbols_to_scan = input_df['Symbol'].str.strip().dropna().unique().tolist()
        
        print(f"Loaded {len(symbols_to_scan)} symbols from {args.input}\n")
        
    except FileNotFoundError:
        print(f"Error: {args.input} not found!")
        print("Please ensure the file exists")
        exit(1)
    except Exception as e:
        print(f"Error reading input CSV: {e}")
        exit(1)
    
    # Run scan
    print(f"Starting {scanner.config['display_name']} timeframe scan...\n")
    results = scanner.scan_multiple(symbols_to_scan)
    
    if not results:
        print("No signals found matching the criteria.")
        exit(0)
    
    # Generate reports
    print("\nGenerating reports...")
    
    # Text report
    report_text = scanner.generate_report(results)
    print("\n" + report_text)
    
    # CSV report
    csv_file = scanner.generate_csv(results)
    
    print(f"\n{'='*120}")
    print(f"SCAN COMPLETE - {scanner.config['display_name'].upper()} TIMEFRAME")
    print(f"{'='*120}")
    print(f"  Symbols Scanned: {len(symbols_to_scan)}")
    print(f"  Symbols with Signals: {len(results)}")
    
    # Count signals by strategy
    reversal_signals = sum(len([s for s in r['signals'] if s['strategy'] == 'REVERSAL']) for r in results)
    trend_signals = sum(len([s for s in r['signals'] if s['strategy'] == 'TREND_FOLLOWING']) for r in results)
    
    print(f"\n  SIGNAL BREAKDOWN:")
    print(f"    Reversal Signals: {reversal_signals}")
    print(f"    Trend-Following Signals: {trend_signals}")
    print(f"    Total Signals: {reversal_signals + trend_signals}")
    
    print(f"\n  FILES GENERATED:")
    txt_files = [f for f in os.listdir('.') if f.startswith(f'rsi_scanner_{scanner.timeframe}_report_')]
    print(f"    - Detailed Report: {txt_files[-1] if txt_files else 'N/A'}")
    print(f"    - CSV Export: {csv_file}")
    
    print(f"\n{'='*120}")
    print(f"\nTIMEFRAME CONSIDERATIONS - {scanner.config['display_name'].upper()}:")
    print("-" * 120)
    
    if scanner.timeframe == 'daily':
        print("\nDAILY TIMEFRAME:")
        print("  ✓ Better for short-term trading and swing trades")
        print("  ✓ More signals, faster entries and exits")
        print("  ✓ Requires daily monitoring")
        print("  ✗ More noise, higher false signal rate")
        print("  ✗ Higher trading frequency = more costs")
    else:
        print("\nWEEKLY TIMEFRAME:")
        print("  ✓ Better for position trading and long-term holds")
        print("  ✓ Less noise, higher quality signals")
        print("  ✓ Less monitoring required (weekly check-ins)")
        print("  ✓ Lower trading frequency = lower costs")
        print("  ✗ Fewer signals, slower to react")
        print("  ✗ Larger stop losses (higher capital requirement)")
    
    print(f"\n{'='*120}")
    print("\nUSAGE EXAMPLES:")
    print(f"  python yasirRSI.py --timeframe daily    # Run daily scan")
    print(f"  python yasirRSI.py --timeframe weekly   # Run weekly scan")
    print(f"  python yasirRSI.py --timeframe daily --input custom_stocks.csv")
    print(f"\n{'='*120}\n")