import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
import time

class WeeklyStage2Scanner:
    def __init__(self, api_key: str, access_token: str):
        """
        Initialize the scanner with Kite Connect credentials
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.instrument_cache = {}
        self.cache_file = 'nse_instruments_cache.json'
        
    def load_instrument_cache(self):
        """Load cached NSE instrument tokens"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    cache_data = json.load(f)
                    # Check if cache is from today
                    cache_date = cache_data.get('date', '')
                    if cache_date == datetime.now().strftime('%Y-%m-%d'):
                        self.instrument_cache = cache_data.get('instruments', {})
                        print(f"Loaded {len(self.instrument_cache)} instruments from cache")
                        return True
            except Exception as e:
                print(f"Error loading cache: {e}")
        return False
    
    def save_instrument_cache(self):
        """Save instrument tokens to cache"""
        cache_data = {
            'date': datetime.now().strftime('%Y-%m-%d'),
            'instruments': self.instrument_cache
        }
        try:
            with open(self.cache_file, 'w') as f:
                json.dump(cache_data, f)
            print("Instrument cache saved successfully")
        except Exception as e:
            print(f"Error saving cache: {e}")
    
    def build_instrument_cache(self):
        """Build cache of NSE instrument tokens"""
        if self.load_instrument_cache():
            return
            
        print("Building NSE instrument cache...")
        try:
            instruments = self.kite.instruments("NSE")
            for instrument in instruments:
                if instrument['instrument_type'] == 'EQ':
                    self.instrument_cache[instrument['tradingsymbol']] = {
                        'instrument_token': instrument['instrument_token'],
                        'name': instrument['name']
                    }
            self.save_instrument_cache()
            print(f"Built cache with {len(self.instrument_cache)} NSE equity instruments")
        except Exception as e:
            print(f"Error building instrument cache: {e}")
            raise
    
    def get_instrument_token(self, symbol: str) -> int:
        """Get instrument token for a symbol"""
        if symbol in self.instrument_cache:
            return self.instrument_cache[symbol]['instrument_token']
        return None
    
    def calculate_moving_average(self, prices: List[float], period: int) -> float:
        """Calculate simple moving average without TALIB"""
        if len(prices) < period:
            return None
        return sum(prices[-period:]) / period
    
    def calculate_roc(self, prices: List[float], period: int) -> float:
        """Calculate Rate of Change without TALIB"""
        if len(prices) < period + 1:
            return None
        current_price = prices[-1]
        past_price = prices[-(period + 1)]
        if past_price == 0:
            return None
        return ((current_price - past_price) / past_price) * 100
    
    def get_historical_data(self, instrument_token: int, days: int = 100) -> pd.DataFrame:
        """Fetch historical data for analysis"""
        try:
            to_date = datetime.now()
            from_date = to_date - timedelta(days=days)
            
            historical_data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if not historical_data:
                return None
                
            df = pd.DataFrame(historical_data)
            df['date'] = pd.to_datetime(df['date'])
            df = df.sort_values('date')
            return df
            
        except Exception as e:
            print(f"Error fetching historical data for token {instrument_token}: {e}")
            return None
    
    def analyze_weekly_pattern(self, df: pd.DataFrame, symbol: str = None) -> Dict:
        """
        Analyze weekly pattern with debug information
        """
        if df is None or len(df) < 50:
            if symbol:
                print(f"{symbol}: Insufficient daily data ({len(df) if df is not None else 0} days)")
            return None
        
        # Convert daily to weekly data
        df_weekly = df.resample('W-FRI', on='date').agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        }).dropna()
        
        if len(df_weekly) < 20:
            if symbol:
                print(f"{symbol}: Insufficient weekly data ({len(df_weekly)} weeks)")
            return None
        
        # Calculate 10-week moving average
        closes = df_weekly['close'].tolist()
        wma_10 = self.calculate_moving_average(closes, 10)
        
        if wma_10 is None:
            if symbol:
                print(f"{symbol}: Cannot calculate 10-week MA")
            return None
        
        # Get current week's high and low
        current_high = df_weekly['high'].iloc[-1]
        current_low = df_weekly['low'].iloc[-1]
        current_close = df_weekly['close'].iloc[-1]
        
        # Weekly scan criteria: High > 10-WMA, Low < 10-WMA
        high_above_wma = current_high > wma_10
        low_below_wma = current_low < wma_10
        
        # Calculate ROC (Rate of Change) - 12 weeks
        roc_12w = self.calculate_roc(closes, 12)
        
        # Calculate additional metrics for ranking
        roc_4w = self.calculate_roc(closes, 4)
        roc_26w = self.calculate_roc(closes, 26)
        
        # Volume analysis - compare recent volume to average
        volumes = df_weekly['volume'].tolist()
        avg_volume_10w = self.calculate_moving_average(volumes, 10)
        current_volume = volumes[-1]
        volume_ratio = current_volume / avg_volume_10w if avg_volume_10w > 0 else 0
        
        # Price position analysis
        price_vs_wma = ((current_close - wma_10) / wma_10) * 100
        
        # Calculate median action strength (price stability)
        recent_closes = closes[-5:]  # Last 5 weeks
        median_price = np.median(recent_closes)
        price_deviation = np.std(recent_closes) / median_price * 100 if median_price > 0 else 100
        
        # Stage 2 validation - trend strength
        wma_5 = self.calculate_moving_average(closes, 5)
        trend_strength = ((wma_5 - wma_10) / wma_10) * 100 if wma_10 > 0 else 0
        
        return {
            'current_price': current_close,
            'wma_10': wma_10,
            'high_above_wma': high_above_wma,
            'low_below_wma': low_below_wma,
            'roc_12w': roc_12w,
            'roc_4w': roc_4w,
            'roc_26w': roc_26w,
            'volume_ratio': volume_ratio,
            'price_vs_wma': price_vs_wma,
            'trend_strength': trend_strength,
            'price_deviation': price_deviation,
            'current_high': current_high,
            'current_low': current_low,
            'median_action_score': 100 - price_deviation  # Higher is better (more stable)
        }
        """
        Analyze weekly pattern for Stage 2 criteria:
        - High > 10-WMA, Low < 10-WMA
        - ROC and median action analysis
        """
        if df is None or len(df) < 50:
            return None
        
        # Convert daily to weekly data
        df_weekly = df.resample('W-FRI', on='date').agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        }).dropna()
        
        if len(df_weekly) < 20:
            return None
        
        # Calculate 10-week moving average
        closes = df_weekly['close'].tolist()
        wma_10 = self.calculate_moving_average(closes, 10)
        
        if wma_10 is None:
            return None
        
        # Get current week's high and low
        current_high = df_weekly['high'].iloc[-1]
        current_low = df_weekly['low'].iloc[-1]
        current_close = df_weekly['close'].iloc[-1]
        
        # Weekly scan criteria: High > 10-WMA, Low < 10-WMA
        high_above_wma = current_high > wma_10
        low_below_wma = current_low < wma_10
        
        if not (high_above_wma and low_below_wma):
            return None
        
        # Calculate ROC (Rate of Change) - 12 weeks
        roc_12w = self.calculate_roc(closes, 12)
        
        # Calculate additional metrics for ranking
        roc_4w = self.calculate_roc(closes, 4)
        roc_26w = self.calculate_roc(closes, 26)
        
        # Volume analysis - compare recent volume to average
        volumes = df_weekly['volume'].tolist()
        avg_volume_10w = self.calculate_moving_average(volumes, 10)
        current_volume = volumes[-1]
        volume_ratio = current_volume / avg_volume_10w if avg_volume_10w > 0 else 0
        
        # Price position analysis
        price_vs_wma = ((current_close - wma_10) / wma_10) * 100
        
        # Calculate median action strength (price stability)
        recent_closes = closes[-5:]  # Last 5 weeks
        median_price = np.median(recent_closes)
        price_deviation = np.std(recent_closes) / median_price * 100 if median_price > 0 else 100
        
        # Stage 2 validation - trend strength
        wma_5 = self.calculate_moving_average(closes, 5)
        trend_strength = ((wma_5 - wma_10) / wma_10) * 100 if wma_10 > 0 else 0
        
        return {
            'current_price': current_close,
            'wma_10': wma_10,
            'high_above_wma': high_above_wma,
            'low_below_wma': low_below_wma,
            'roc_12w': roc_12w,
            'roc_4w': roc_4w,
            'roc_26w': roc_26w,
            'volume_ratio': volume_ratio,
            'price_vs_wma': price_vs_wma,
            'trend_strength': trend_strength,
            'price_deviation': price_deviation,
            'current_high': current_high,
            'current_low': current_low,
            'median_action_score': 100 - price_deviation  # Higher is better (more stable)
        }
    
    def scan_universe(self, universe_file: str, debug_mode: bool = True) -> pd.DataFrame:
        """
        Scan the universe of stocks for weekly Stage 2 setups
        """
        # Load universe
        try:
            universe_df = pd.read_csv(universe_file)
            if 'Symbol' not in universe_df.columns:
                raise ValueError("CSV must contain 'Symbol' column")
            symbols = universe_df['Symbol'].tolist()
        except Exception as e:
            print(f"Error loading universe file: {e}")
            return pd.DataFrame()
        
        # Build instrument cache
        self.build_instrument_cache()
        
        results = []
        debug_stats = {
            'total_processed': 0,
            'data_fetched': 0,
            'insufficient_data': 0,
            'criteria_failed': 0,
            'high_above_wma_fail': 0,
            'low_below_wma_fail': 0,
            'both_criteria_fail': 0,
            'criteria_passed': 0
        }
        
        total_symbols = len(symbols)
        processed = 0
        
        print(f"Scanning {total_symbols} symbols...")
        
        for symbol in symbols:
            try:
                processed += 1
                debug_stats['total_processed'] += 1
                
                if processed % 10 == 0:
                    print(f"Processed {processed}/{total_symbols} symbols...")
                
                # Get instrument token
                instrument_token = self.get_instrument_token(symbol)
                if not instrument_token:
                    if debug_mode:
                        print(f"Instrument token not found for {symbol}")
                    continue
                
                # Get historical data
                df = self.get_historical_data(instrument_token, days=200)  # Increased to 200 days
                if df is None:
                    continue
                
                debug_stats['data_fetched'] += 1
                
                # Analyze weekly pattern with debug info
                analysis = self.analyze_weekly_pattern(df, symbol if debug_mode else None)
                if analysis is None:
                    debug_stats['insufficient_data'] += 1
                    continue
                
                # Check criteria with detailed tracking
                high_above_wma = analysis['high_above_wma']
                low_below_wma = analysis['low_below_wma']
                
                if not high_above_wma and not low_below_wma:
                    debug_stats['both_criteria_fail'] += 1
                elif not high_above_wma:
                    debug_stats['high_above_wma_fail'] += 1
                elif not low_below_wma:
                    debug_stats['low_below_wma_fail'] += 1
                
                if not (high_above_wma and low_below_wma):
                    debug_stats['criteria_failed'] += 1
                    if debug_mode and processed <= 5:  # Show first 5 failures
                        print(f"{symbol}: High>{analysis['wma_10']:.2f}? {high_above_wma} ({analysis['current_high']:.2f}), Low<{analysis['wma_10']:.2f}? {low_below_wma} ({analysis['current_low']:.2f})")
                    continue
                
                debug_stats['criteria_passed'] += 1
                
                # Add to results
                result = {
                    'Symbol': symbol,
                    'Name': self.instrument_cache[symbol]['name'],
                    'Current_Price': round(analysis['current_price'], 2),
                    'WMA_10': round(analysis['wma_10'], 2),
                    'High_Above_WMA': analysis['high_above_wma'],
                    'Low_Below_WMA': analysis['low_below_wma'],
                    'ROC_12W': round(analysis['roc_12w'], 2) if analysis['roc_12w'] else None,
                    'ROC_4W': round(analysis['roc_4w'], 2) if analysis['roc_4w'] else None,
                    'ROC_26W': round(analysis['roc_26w'], 2) if analysis['roc_26w'] else None,
                    'Volume_Ratio': round(analysis['volume_ratio'], 2),
                    'Price_vs_WMA': round(analysis['price_vs_wma'], 2),
                    'Trend_Strength': round(analysis['trend_strength'], 2),
                    'Median_Action_Score': round(analysis['median_action_score'], 2),
                    'Price_Deviation': round(analysis['price_deviation'], 2),
                    'Weekly_High': round(analysis['current_high'], 2),
                    'Weekly_Low': round(analysis['current_low'], 2),
                    'Scan_Date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                results.append(result)
                
                if debug_mode:
                    print(f"✓ {symbol} PASSED: High={analysis['current_high']:.2f} > WMA={analysis['wma_10']:.2f}, Low={analysis['current_low']:.2f} < WMA={analysis['wma_10']:.2f}")
                
                # Rate limiting - avoid hitting API limits
                time.sleep(0.1)
                
            except Exception as e:
                print(f"Error processing {symbol}: {e}")
                continue
        
        # Print debug statistics
        if debug_mode:
            print("\n" + "="*50)
            print("DEBUG STATISTICS")
            print("="*50)
            print(f"Total symbols processed: {debug_stats['total_processed']}")
            print(f"Data successfully fetched: {debug_stats['data_fetched']}")
            print(f"Insufficient data: {debug_stats['insufficient_data']}")
            print(f"Failed criteria breakdown:")
            print(f"  - High NOT above WMA only: {debug_stats['high_above_wma_fail']}")
            print(f"  - Low NOT below WMA only: {debug_stats['low_below_wma_fail']}")
            print(f"  - Both criteria failed: {debug_stats['both_criteria_fail']}")
            print(f"  - Total criteria failures: {debug_stats['criteria_failed']}")
            print(f"PASSED all criteria: {debug_stats['criteria_passed']}")
            print("="*50)
        
        # Convert to DataFrame and sort by ROC and median action
        results_df = pd.DataFrame(results)
        
        if not results_df.empty:
            # Sort by ROC_12W (descending) and Median_Action_Score (descending)
            results_df = results_df.sort_values(
                ['ROC_12W', 'Median_Action_Score'], 
                ascending=[False, False]
            ).reset_index(drop=True)
            
            print(f"Found {len(results_df)} stocks meeting weekly Stage 2 criteria")
        else:
            print("No stocks found meeting the criteria")
        
        return results_df
    
    def save_results(self, results_df: pd.DataFrame, output_file: str = None):
        """Save results to CSV with nuanced analysis"""
        if output_file is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = f'weekly_stage2_scan_{timestamp}.csv'
        
        try:
            results_df.to_csv(output_file, index=False)
            print(f"Results saved to {output_file}")
            return output_file
        except Exception as e:
            print(f"Error saving results: {e}")
            return None

# Usage Example
def main():
    """
    Main function to run the weekly scanner
    """
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "KnnlDGAIyN9vvE7IA8DZetZYVm22yMkE"
    UNIVERSE_FILE = "data/MBAug-Shortlisted.csv"
    
    # Initialize scanner
    scanner = WeeklyStage2Scanner(API_KEY, ACCESS_TOKEN)
    
    # Run scan with debug mode enabled
    results = scanner.scan_universe(UNIVERSE_FILE, debug_mode=True)
    
    # Save results
    if not results.empty:
        output_file = scanner.save_results(results)
        
        # Display summary
        print("\n" + "="*60)
        print("WEEKLY STAGE 2 SCAN SUMMARY")
        print("="*60)
        print(f"Total candidates found: {len(results)}")
        
        if len(results) > 0:
            print(f"Top 5 by ROC_12W:")
            top_5 = results.head(5)[['Symbol', 'Name', 'Current_Price', 'ROC_12W', 'Median_Action_Score']]
            print(top_5.to_string(index=False))
            
            print(f"\nAverage ROC_12W: {results['ROC_12W'].mean():.2f}%")
            print(f"Average Median Action Score: {results['Median_Action_Score'].mean():.2f}")
    
    return results

if __name__ == "__main__":
    results = main()