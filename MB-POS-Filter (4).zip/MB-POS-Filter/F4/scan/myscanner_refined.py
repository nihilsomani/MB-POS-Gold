"""
EMA Pullback Scanner - SIMPLE REFINED VERSION (FINAL)

Final configuration after extensive backtesting:
- BETWEEN_21_55_EMA removed (14.66% win rate)
- BOUNCED_FROM_EMA checked first (41% win rate)
- Quality filtering (only trade quality ≥ 1)
- Market regime filter (only trade in favorable conditions)
- Moderate 2:1 R:R (4% SL / 8% Target)
- ALL STOCK-LEVEL FILTERS DISABLED (proven redundant/harmful)

Proven Performance (2-year backtest):
- Win Rate: 41%
- CAGR: ~230%
- Return: 1,340%
- Drawdown: ~38%
- Philosophy: Simple > Complex. Trust the setup. Manage with R:R.
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import time
from datetime import datetime, timedelta
import logging
from market_regime_filter import MarketRegimeFilter

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class EMAPullbackScannerRefined:
    def __init__(self, api_key, access_token):
        """Initialize refined scanner with Kite Connect credentials"""
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = 0.35
        
        # Cache for instruments
        self.instruments_cache = None
        self.symbol_token_map = {}
        
        # Market regime filter
        self.regime_filter = MarketRegimeFilter(self.kite)
        
        # Trading parameters (Moderate 2:1 - best from analysis)
        self.stop_loss_pct = 0.04  # 4% stop loss
        self.target_pct = 0.08     # 8% target (2:1 R:R)
        self.min_quality_score = 1 # Only trade quality ≥ 1
        
        # ALL FILTERS DISABLED (proven redundant or harmful in backtesting)
        # Backtesting showed: All filters either over-filtered or had no impact
        # Final configuration: Simple Refined Strategy (no filters)
        self.enable_relative_strength = False  # DISABLED - over-filtered good setups
        self.enable_volume_confirmation = False  # DISABLED - over-filtered good setups
        self.enable_price_position = False  # DISABLED - over-filtered good setups
        
        # Legacy threshold values (not used when filters disabled)
        self.min_relative_strength = 1.0
        self.volume_multiplier = 0.8
        self.price_position_min = 0.15
        self.price_position_max = 0.95
        
        # Nifty data cache (for relative strength)
        self.nifty_data = None
        self.nifty_token = 256265
        
    def _rate_limit(self):
        """Enforce rate limiting"""
        current_time = time.time()
        time_since_last_request = current_time - self.last_request_time
        
        if time_since_last_request < self.min_request_interval:
            sleep_time = self.min_request_interval - time_since_last_request
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def load_instruments_cache(self):
        """Load NSE instruments and create symbol-token mapping"""
        logger.info("Loading NSE instruments cache...")
        self._rate_limit()
        
        try:
            instruments = self.kite.instruments("NSE")
            self.instruments_cache = pd.DataFrame(instruments)
            
            for _, row in self.instruments_cache.iterrows():
                if row['segment'] == 'NSE':
                    self.symbol_token_map[row['tradingsymbol']] = row['instrument_token']
            
            logger.info(f"Loaded {len(self.symbol_token_map)} NSE instruments")
            return True
        except Exception as e:
            logger.error(f"Error loading instruments: {e}")
            return False
    
    def get_historical_data(self, symbol, days=100):
        """Fetch historical data for a symbol"""
        if symbol not in self.symbol_token_map:
            logger.warning(f"Symbol {symbol} not found in NSE instruments")
            return None
        
        instrument_token = self.symbol_token_map[symbol]
        to_date = datetime.now()
        from_date = to_date - timedelta(days=days)
        
        self._rate_limit()
        
        try:
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                df = df.sort_values('date').reset_index(drop=True)
            return df
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def get_nifty_data(self, days=100):
        """
        Fetch Nifty 50 data for relative strength calculation
        Cached to avoid repeated API calls
        """
        if self.nifty_data is not None:
            return self.nifty_data  # Use cached data
        
        to_date = datetime.now()
        from_date = to_date - timedelta(days=days)
        
        self._rate_limit()
        
        try:
            data = self.kite.historical_data(
                instrument_token=self.nifty_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                df = df.sort_values('date').reset_index(drop=True)
                self.nifty_data = df  # Cache for reuse
            return df
        except Exception as e:
            logger.error(f"Error fetching Nifty data: {e}")
            return None
    
    def calculate_ema(self, data, period):
        """Calculate EMA for given period"""
        return data['close'].ewm(span=period, adjust=False).mean()
    
    def calculate_atr(self, df, period=14):
        """
        Calculate Average True Range (ATR) - better volatility measure
        """
        if len(df) < period + 1:
            return None
        
        high = df['high']
        low = df['low']
        close = df['close'].shift(1)
        
        tr1 = high - low
        tr2 = abs(high - close)
        tr3 = abs(low - close)
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=period).mean()
        
        return atr
    
    def detect_consolidation(self, df, lookback=5):
        """
        Detect price consolidation using ATR for better accuracy
        
        Args:
            df: DataFrame with OHLC data
            lookback: Number of days to check
        
        Returns:
            (is_consolidating, volatility_pct)
        """
        if len(df) < lookback:
            return False, 0
        
        # Method 1: ATR-based (more accurate)
        atr = self.calculate_atr(df, period=14)
        if atr is not None and len(atr) > 0:
            recent_atr = atr.iloc[-lookback:].mean()
            current_price = df['close'].iloc[-1]
            
            # Consolidation if ATR is less than 2% of price
            atr_pct = (recent_atr / current_price) * 100
            is_consolidating_atr = atr_pct < 2.0
            
            return is_consolidating_atr, round(atr_pct, 2)
        
        # Method 2: Simple range (fallback if not enough data for ATR)
        recent_prices = df['close'].iloc[-lookback:].values
        volatility = (recent_prices.max() - recent_prices.min()) / recent_prices.mean()
        is_consolidating = volatility < 0.02
        return is_consolidating, round(volatility * 100, 2)
    
    def detect_volume_drying(self, volumes, lookback=5):
        """Detect decreasing volume trend"""
        if len(volumes) < lookback:
            return False, 0
        
        recent_volume = volumes[-lookback:]
        earlier_volume = volumes[-lookback*2:-lookback] if len(volumes) >= lookback*2 else volumes[:-lookback]
        
        if len(earlier_volume) == 0:
            return False, 0
        
        recent_avg = recent_volume.mean()
        earlier_avg = earlier_volume.mean()
        volume_decrease = ((earlier_avg - recent_avg) / earlier_avg) * 100
        is_drying = volume_decrease > 20
        return is_drying, round(volume_decrease, 2)
    
    def check_price_near_ema(self, price, ema, tolerance=0.015):
        """Check if price is near EMA"""
        distance = abs(price - ema) / ema
        return distance <= tolerance, round(distance * 100, 2)
    
    def calculate_relative_strength(self, symbol_df, nifty_df, period=20):
        """
        Calculate Relative Strength vs Nifty
        Returns RS score (>1 = outperforming, <1 = underperforming)
        """
        if len(symbol_df) < period or len(nifty_df) < period:
            return None
        
        # Calculate returns
        stock_return = (symbol_df['close'].iloc[-1] / symbol_df['close'].iloc[-period]) - 1
        nifty_return = (nifty_df['close'].iloc[-1] / nifty_df['close'].iloc[-period]) - 1
        
        # Relative strength
        if abs(nifty_return) > 0.0001:  # Avoid division by zero
            rs = (1 + stock_return) / (1 + nifty_return)
        else:
            rs = 1.0
        
        return rs
    
    def check_volume_surge(self, df, multiplier=1.3):
        """
        Check if recent volume is above average (confirmation)
        """
        if len(df) < 20:
            return False, 0
        
        recent_volume = df['volume'].iloc[-1]
        avg_volume_20 = df['volume'].iloc[-20:].mean()
        
        surge_ratio = recent_volume / avg_volume_20 if avg_volume_20 > 0 else 0
        has_surge = surge_ratio >= multiplier
        
        return has_surge, round(surge_ratio, 2)
    
    def check_price_position(self, df, days=252):
        """
        Check where price is relative to 52-week range
        Returns position (0-1, where 0=low, 1=high)
        Sweet spot: 0.30 - 0.85
        """
        if len(df) < 60:  # Need at least 60 days
            days = len(df)
        
        current_price = df['close'].iloc[-1]
        period_high = df['high'].iloc[-days:].max()
        period_low = df['low'].iloc[-days:].min()
        
        if period_high == period_low:
            return 0.5
        
        position = (current_price - period_low) / (period_high - period_low)
        return position
    
    def analyze_symbol(self, symbol):
        """
        Analyze a single symbol for EMA pullback setups (REFINED VERSION)
        
        Changes from original:
        - BOUNCED_FROM_EMA checked FIRST (best win rate: 41%)
        - BETWEEN_21_55_EMA REMOVED (poor win rate: 14.66%)
        - Quality filtering applied
        - Stop loss and target adjusted to optimal 4%/8%
        """
        logger.info(f"Analyzing {symbol}...")
        
        # Fetch historical data
        df = self.get_historical_data(symbol, days=100)
        
        if df is None or len(df) < 60:
            return {
                'Symbol': symbol,
                'Status': 'INSUFFICIENT_DATA',
                'Setup_Type': 'N/A',
                'Quality_Score': 0,
                'Current_Price': 0,
                'Stop_Loss': 0,
                'Target': 0,
                'Notes': 'Insufficient historical data'
            }
        
        # Calculate EMAs (using actual periods, not span+1)
        df['EMA_10'] = self.calculate_ema(df, 10)
        df['EMA_21'] = self.calculate_ema(df, 21)
        df['EMA_55'] = self.calculate_ema(df, 55)
        
        # Get latest values
        latest = df.iloc[-1]
        current_price = latest['close']
        ema_10 = latest['EMA_10']
        ema_21 = latest['EMA_21']
        ema_55 = latest['EMA_55']
        
        result = {
            'Symbol': symbol,
            'Status': 'NO_SETUP',
            'Setup_Type': 'N/A',
            'Quality_Score': 0,
            'Current_Price': round(current_price, 2),
            'EMA_10': round(ema_10, 2),
            'EMA_21': round(ema_21, 2),
            'EMA_55': round(ema_55, 2),
            'Stop_Loss': 0,
            'Target': 0,
            'Risk': 0,
            'Reward': 0,
            'R:R': '0:0',
            'Notes': ''
        }
        
        # Primary condition: 21 EMA must be above 55 EMA
        if ema_21 <= ema_55:
            result['Notes'] = f"21 EMA not above 55 EMA (downtrend/consolidation)"
            return result
        
        ema_21_55_spread = round(((ema_21 - ema_55) / ema_55) * 100, 2)
        
        # Check consolidation (using ATR) and volume
        is_consolidating, consol_pct = self.detect_consolidation(df, lookback=5)
        is_volume_drying, vol_decrease = self.detect_volume_drying(df['volume'], lookback=5)
        
        # PHASE 1 FILTERS: Apply additional quality checks
        filter_results = {
            'relative_strength': None,
            'volume_surge': None,
            'price_position': None,
            'filters_passed': True,
            'filter_notes': []
        }
        
        # Filter 1: Relative Strength (vs Nifty)
        if self.enable_relative_strength:
            nifty_df = self.get_nifty_data()
            if nifty_df is not None:
                rs = self.calculate_relative_strength(df, nifty_df, period=20)
                filter_results['relative_strength'] = round(rs, 2) if rs else None
                if rs and rs < self.min_relative_strength:
                    filter_results['filters_passed'] = False
                    filter_results['filter_notes'].append(f"Weak RS: {rs:.2f} (need ≥{self.min_relative_strength})")
                elif rs:
                    filter_results['filter_notes'].append(f"✓ Strong RS: {rs:.2f}")
        
        # Filter 2: Volume Confirmation
        if self.enable_volume_confirmation:
            has_volume, vol_ratio = self.check_volume_surge(df, self.volume_multiplier)
            filter_results['volume_surge'] = vol_ratio
            if not has_volume:
                filter_results['filters_passed'] = False
                filter_results['filter_notes'].append(f"Low volume: {vol_ratio}x (need ≥{self.volume_multiplier}x)")
            else:
                filter_results['filter_notes'].append(f"✓ Volume surge: {vol_ratio}x")
        
        # Filter 3: Price Position (52-week range)
        if self.enable_price_position:
            price_pos = self.check_price_position(df)
            filter_results['price_position'] = round(price_pos, 2)
            if price_pos < self.price_position_min:
                filter_results['filters_passed'] = False
                filter_results['filter_notes'].append(f"Too low: {price_pos*100:.0f}% of range (need >{self.price_position_min*100:.0f}%)")
            elif price_pos > self.price_position_max:
                filter_results['filters_passed'] = False
                filter_results['filter_notes'].append(f"Too high: {price_pos*100:.0f}% of range (avoid >{self.price_position_max*100:.0f}%)")
            else:
                filter_results['filter_notes'].append(f"✓ Good position: {price_pos*100:.0f}% of 52W range")
        
        # SETUP 1: Bounced from EMA (Check FIRST - best win rate: 41%)
        # Quality Score: Always 2 (best setup)
        # Rationale: Confirmed momentum + bounce from support = highest probability
        # Backtest showed 41% WR vs 34.81% for PULLBACK
        lookback = 5
        if len(df) >= lookback:
            recent_df = df.tail(lookback)
            
            touched_10_ema = any(
                abs(row['close'] - row['EMA_10']) / row['EMA_10'] < 0.015 
                for _, row in recent_df.iloc[:-1].iterrows()
            )
            
            touched_21_ema = any(
                abs(row['close'] - row['EMA_21']) / row['EMA_21'] < 0.015 
                for _, row in recent_df.iloc[:-1].iterrows()
            )
            
            price_above_10 = current_price > ema_10
            price_above_21 = current_price > ema_21
            
            recent_prices = recent_df['close'].values
            is_rising = len(recent_prices) >= 2 and recent_prices[-1] > recent_prices[-2]
            
            if (touched_10_ema or touched_21_ema) and price_above_10 and is_rising:
                # Quality = 2 (always) because:
                # 1. Already bounced (proven support)
                # 2. Momentum confirmed (price rising)
                # 3. Best win rate in backtests (41%)
                quality_score = 2
                
                # PHASE 1: Apply advanced filters
                if not filter_results['filters_passed']:
                    # Setup found but failed filters
                    result.update({
                        'Status': 'FILTERED_OUT',
                        'Setup_Type': 'BOUNCED_FROM_EMA',
                        'Quality_Score': quality_score,
                        'Current_Price': round(current_price, 2),
                        'Notes': f"Setup found but filtered: {' | '.join(filter_results['filter_notes'])}"
                    })
                    return result
                
                # Calculate stop loss and target
                stop_loss = current_price * (1 - self.stop_loss_pct)
                target = current_price * (1 + self.target_pct)
                risk = current_price - stop_loss
                reward = target - current_price
                
                notes = []
                if touched_10_ema:
                    notes.append("✓ Touched 10 EMA")
                if touched_21_ema:
                    notes.append("✓ Touched 21 EMA")
                notes.append("✓ Upward momentum confirmed")
                notes.append(f"21-55 spread: {ema_21_55_spread}%")
                
                # Add filter confirmation
                notes.extend(filter_results['filter_notes'])
                
                result.update({
                    'Status': 'SETUP_FOUND',
                    'Setup_Type': 'BOUNCED_FROM_EMA',
                    'Quality_Score': quality_score,
                    'Stop_Loss': round(stop_loss, 2),
                    'Target': round(target, 2),
                    'Risk': round(risk, 2),
                    'Reward': round(reward, 2),
                    'R:R': '1:2',
                    'Relative_Strength': filter_results['relative_strength'],
                    'Volume_Ratio': filter_results['volume_surge'],
                    'Price_Position': filter_results['price_position'],
                    'Notes': " | ".join(notes)
                })
                return result
        
        # SETUP 2: Pullback to 21 EMA (secondary - 34.81% win rate)
        # Quality Score: Variable (0-2) based on conditions
        # Rationale: Base setup is okay, but quality improves with:
        #   +1 if consolidating (low volatility = cleaner setup)
        #   +1 if volume drying (less selling pressure)
        # Backtest showed quality 2 PULLBACK performs better than quality 0
        near_21_ema, dist_21 = self.check_price_near_ema(current_price, ema_21, tolerance=0.02)
        
        if near_21_ema:
            # Start at 0, add points for favorable conditions
            quality_score = 0
            if is_consolidating:
                quality_score += 1  # Tighter price action = better setup
            if is_volume_drying:
                quality_score += 1  # Less selling pressure = better setup
            
            # PHASE 1: Apply advanced filters
            if not filter_results['filters_passed']:
                # Setup found but failed filters
                result.update({
                    'Status': 'FILTERED_OUT',
                    'Setup_Type': 'PULLBACK_TO_21_EMA',
                    'Quality_Score': quality_score,
                    'Current_Price': round(current_price, 2),
                    'Notes': f"Setup found but filtered: {' | '.join(filter_results['filter_notes'])}"
                })
                return result
            
            # Calculate stop loss and target
            stop_loss = current_price * (1 - self.stop_loss_pct)
            target = current_price * (1 + self.target_pct)
            risk = current_price - stop_loss
            reward = target - current_price
            
            notes = []
            notes.append(f"Price {dist_21}% from 21 EMA")
            if is_consolidating:
                notes.append("✓ Consolidating")
            if is_volume_drying:
                notes.append("✓ Volume drying")
            notes.append(f"21-55 spread: {ema_21_55_spread}%")
            
            # Add filter confirmation
            notes.extend(filter_results['filter_notes'])
            
            result.update({
                'Status': 'SETUP_FOUND',
                'Setup_Type': 'PULLBACK_TO_21_EMA',
                'Quality_Score': quality_score,
                'Stop_Loss': round(stop_loss, 2),
                'Target': round(target, 2),
                'Risk': round(risk, 2),
                'Reward': round(reward, 2),
                'R:R': '1:2',
                'Relative_Strength': filter_results['relative_strength'],
                'Volume_Ratio': filter_results['volume_surge'],
                'Price_Position': filter_results['price_position'],
                'Notes': " | ".join(notes)
            })
            return result
        
        # No setup found
        result['Notes'] = f"21 EMA above 55 EMA by {ema_21_55_spread}% but no pullback/bounce setup yet"
        return result
    
    def scan_symbols(self, input_csv, output_csv):
        """Scan all symbols from input CSV with market regime filter"""
        
        # Check market regime FIRST
        print("\n" + "="*80)
        print("⭐ SIMPLE REFINED EMA PULLBACK SCANNER - FINAL")
        print("="*80)
        print("Configuration:")
        print("  • Stop Loss: 4% | Target: 8% (2:1 R:R)")
        print("  • Quality Filter: ≥1 (good setups only)")
        print("  • Setup Focus: BOUNCED (41% WR) + PULLBACK (39% WR)")
        print("  • BETWEEN setup removed (was 14.66% WR)")
        print("  • ALL Stock-Level Filters: DISABLED (proven redundant)")
        print("\nProven Performance (2-year backtest):")
        print("  • Win Rate: 41% | CAGR: 230% | Return: 1,340%")
        print("  • Philosophy: Simple > Complex. Trust the setup.")
        print("="*80)
        
        # Check market regime
        regime_filter = MarketRegimeFilter(self.kite)
        regime, details = regime_filter.get_market_regime()
        
        print("\n" + "="*80)
        print("📊 MARKET REGIME CHECK")
        print("="*80)
        print(f"Current Regime: {regime}")
        print(f"Nifty: {details['nifty_price']} (21 EMA: {details['ema_21']}, 50 EMA: {details['ema_50']})")
        print(f"Trend Strength: {details['trend_score']}/100")
        print(f"Recent Return (20d): {details['recent_return_20d']}%")
        if details['vix']:
            print(f"VIX: {details['vix']}")
        
        # Determine if we should trade based on regime
        should_trade = regime_filter.should_trade(regime)
        
        if regime == 'STRONG_TRENDING':
            print("\n✅ EXCELLENT market conditions - Trade aggressively!")
        elif regime == 'TRENDING':
            print("\n✅ GOOD market conditions - Trade normally")
        elif regime == 'CONSOLIDATING':
            print("\n⚠️  MARGINAL conditions - Trade selectively (quality=2 only)")
            self.min_quality_score = 2  # Raise quality bar in consolidation
        elif regime == 'WEAK':
            print("\n❌ POOR market conditions - Consider sitting out")
        else:
            print("\n⚠️  UNKNOWN conditions - Be cautious")
        
        print("="*80)
        
        # Ask user if they want to continue when conditions not favorable
        if not should_trade:
            response = input("\n⚠️  Market conditions not ideal. Continue scanning anyway? (y/n): ")
            if response.lower() != 'y':
                print("Scan cancelled. Wait for better market conditions.")
                return
        
        # Proceed with scan
        logger.info(f"\nReading symbols from {input_csv}")
        
        try:
            input_df = pd.read_csv(input_csv)
            
            if 'Symbol' not in input_df.columns:
                logger.error("Input CSV must have 'Symbol' column")
                return
            
            symbols = input_df['Symbol'].dropna().unique().tolist()
            logger.info(f"Found {len(symbols)} symbols to scan")
            
            # Load instruments cache
            if not self.load_instruments_cache():
                logger.error("Failed to load instruments cache")
                return
            
            # Analyze each symbol
            results = []
            filtered_setups = []  # Track filtered setups for analysis
            
            for i, symbol in enumerate(symbols, 1):
                logger.info(f"Processing {i}/{len(symbols)}: {symbol}")
                result = self.analyze_symbol(symbol)
                
                # Track all setups (found and filtered)
                if result['Status'] == 'SETUP_FOUND':
                    if result['Quality_Score'] >= self.min_quality_score:
                        results.append(result)
                    else:
                        logger.info(f"  Skipped: Quality score {result['Quality_Score']} < {self.min_quality_score}")
                elif result['Status'] == 'FILTERED_OUT':
                    filtered_setups.append(result)
                    logger.info(f"  Filtered: {result['Notes'][:60]}...")
                
                # Progress update every 10 symbols
                if i % 10 == 0:
                    setups_found = len(results)
                    logger.info(f"Progress: {i}/{len(symbols)} | Setups found: {setups_found} | Filtered: {len(filtered_setups)}")
            
            # Create output DataFrame
            output_df = pd.DataFrame(results)
            
            if len(output_df) == 0:
                print("\n" + "="*80)
                print("❌ NO SETUPS FOUND")
                print("="*80)
                print("Possible reasons:")
                print("  • Market not trending (21 EMA not above 55 EMA)")
                print("  • No pullbacks/bounces at the moment")
                print("  • Quality filter too strict")
                print(f"  • Current regime: {regime}")
                print("\nTry again later or adjust parameters")
                print("="*80)
                return
            
            # Sort by quality score and setup type
            setup_order = {'BOUNCED_FROM_EMA': 1, 'PULLBACK_TO_21_EMA': 2}
            output_df['_sort'] = output_df['Setup_Type'].map(setup_order).fillna(999)
            output_df = output_df.sort_values(['Quality_Score', '_sort'], ascending=[False, True])
            output_df = output_df.drop('_sort', axis=1)
            
            # Save to CSV
            output_df.to_csv(output_csv, index=False)
            logger.info(f"Results saved to {output_csv}")
            
            # Summary
            print("\n" + "="*80)
            print("✅ SCAN COMPLETE - SIMPLE REFINED STRATEGY")
            print("="*80)
            print(f"Market Regime: {regime}")
            print(f"Total symbols scanned: {len(symbols)}")
            print(f"\nResults:")
            print(f"  Setups found: {len(output_df)}")
            if len(filtered_setups) > 0:
                print(f"  Setups filtered: {len(filtered_setups)} (quality or regime)")
            print(f"\nSetup Distribution:")
            print(f"  - BOUNCED_FROM_EMA: {len(output_df[output_df['Setup_Type'] == 'BOUNCED_FROM_EMA'])}")
            print(f"  - PULLBACK_TO_21_EMA: {len(output_df[output_df['Setup_Type'] == 'PULLBACK_TO_21_EMA'])}")
            print(f"\nQuality Distribution:")
            print(f"  - Quality 2 (Best): {len(output_df[output_df['Quality_Score'] == 2])}")
            print(f"  - Quality 1 (Good): {len(output_df[output_df['Quality_Score'] == 1])}")
            print(f"\nRisk/Reward:")
            print(f"  - Stop Loss: {self.stop_loss_pct*100}%")
            print(f"  - Target: {self.target_pct*100}%")
            print(f"  - R:R Ratio: 1:2")
            print(f"\nEnhancements Active:")
            print(f"  {'✓' if self.enable_relative_strength else '✗'} Relative Strength Filter (min RS: {self.min_relative_strength})")
            print(f"  {'✓' if self.enable_volume_confirmation else '✗'} Volume Confirmation (min: {self.volume_multiplier}x)")
            print(f"  {'✓' if self.enable_price_position else '✗'} Price Position Filter ({self.price_position_min*100:.0f}%-{self.price_position_max*100:.0f}%)")
            print(f"\nResults saved to: {output_csv}")
            print("="*80)
            
            # Show top 5 setups
            if len(output_df) > 0:
                print("\n🎯 TOP 5 SETUPS:")
                print("-" * 80)
                for idx, row in output_df.head(5).iterrows():
                    print(f"\n{idx+1}. {row['Symbol']} - {row['Setup_Type']} (Quality: {row['Quality_Score']})")
                    print(f"   Price: ₹{row['Current_Price']} | Stop Loss: ₹{row['Stop_Loss']} | Target: ₹{row['Target']}")
                    print(f"   Risk: ₹{row['Risk']} | Reward: ₹{row['Reward']} | {row['R:R']}")
                    print(f"   {row['Notes']}")
                print("-" * 80)
            
        except Exception as e:
            logger.error(f"Error during scanning: {e}")
            raise


# Example usage
if __name__ == "__main__":
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "FA1b5XJp65D7nfmUOYxafYAcfKqneMyg"
    
    INPUT_CSV = "data\\Stage2Shortlist.csv"
    OUTPUT_CSV = f"ema_pullback_refined_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    
    # Create refined scanner
    scanner = EMAPullbackScannerRefined(API_KEY, ACCESS_TOKEN)
    
    # Run scan
    scanner.scan_symbols(INPUT_CSV, OUTPUT_CSV)

