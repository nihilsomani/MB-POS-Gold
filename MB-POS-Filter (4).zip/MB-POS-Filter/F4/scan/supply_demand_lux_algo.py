
import pandas as pd
from kiteconnect import KiteConnect
import time
import math
import logging
from datetime import date, timedelta
import os
import numpy as np # For ATR calculation

# --- Configuration ---
API_KEY = "3bi2yh8g830vq3y6"  # Replace with your API Key
API_SECRET = "YOUR_API_SECRET" # Replace with your API Secret
ACCESS_TOKEN = "Vr2430kD46LHy7ZyLxRmnqLzOeUt11Sc" # Replace with your generated Access Token

INPUT_CSV = 'data/FNOStock.csv'
OUTPUT_CSV = f'lux_enhanced_detailed_scan_results_FNOStock_13Aug.csv'
TIMEFRAME = 'day'
LOOKBACK_PERIOD = 50 # Number of bars for S/D calculation (ending day before yesterday)
ATR_PERIOD = 14 # Period for ATR calculation
EQUILIBRIUM_RESOLUTION = 50
VOLUME_THRESHOLD_PERCENT = 10.0
# --- Tolerances now ATR based ---
CROSSING_TOLERANCE_ATR_MULTIPLIER = 0.25 # e.g., 0.25 * ATR for nearness
EDGE_NEARNESS_ATR_MULTIPLIER = 1.0    # e.g., LTP must be within 1 * ATR of a demand zone for "Was_Near_Demand_Yesterday"

# Logging Setup
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# --- Kite Connect Initialization ---
try:
    kite = KiteConnect(api_key=API_KEY)
    kite.set_access_token(ACCESS_TOKEN)
    logging.info("Kite Connect session initialized successfully.")
except Exception as e:
    logging.error(f"Error initializing Kite Connect: {e}")
    exit()

# --- Helper Functions ---

def get_instrument_token(symbol_list):
    try:
        instruments = kite.instruments("NSE")
        token_map = {item['tradingsymbol']: item['instrument_token'] for item in instruments if item['tradingsymbol'] in symbol_list and item['exchange'] == 'NSE'}
        missing = [s for s in symbol_list if s not in token_map]
        if missing:
            logging.warning(f"Could not find instrument tokens for: {', '.join(missing)}")
        return token_map
    except Exception as e:
        logging.error(f"Error fetching instrument tokens: {e}")
        return {}

def calculate_atr(df, period=ATR_PERIOD):
    """Calculates Average True Range."""
    if df is None or len(df) < period:
        return None

    high_low = df['high'] - df['low']
    high_close_prev = np.abs(df['high'] - df['close'].shift(1))
    low_close_prev = np.abs(df['low'] - df['close'].shift(1))

    tr = pd.DataFrame({'hl': high_low, 'hc': high_close_prev, 'lc': low_close_prev}).max(axis=1)
    atr = tr.rolling(window=period).mean().iloc[-1]
    return atr if pd.notna(atr) else None


def get_historical_data(instrument_token, lookback_bars, atr_period, timeframe):
    """
    Fetches historical data.
    Fetches enough bars for lookback_bars for S/D calc + ATR period + a buffer.
    """
    try:
        # Bars needed: lookback_bars (for S/D base) + atr_period (for ATR calc on that base)
        # + 1 (for prev_close) + 1 (for prev_prev_close)
        # The S/D base ends at T-2, ATR is calc on this base. prev_close is T-1, prev_prev_close is T-2.
        bars_for_calc_base = lookback_bars + atr_period
        total_bars_needed = bars_for_calc_base + 2 # +2 for prev_close and prev_prev_close

        to_date = date.today()
        # Estimate from_date with a generous buffer
        multiplier = 1.8 if timeframe in ['day', 'week', 'month'] else 3.0
        from_date = to_date - timedelta(days=total_bars_needed * multiplier * 1.5) # Increased buffer

        data = kite.historical_data(instrument_token, from_date, to_date, timeframe, continuous=False, oi=False)
        time.sleep(0.35) # API call delay

        df = pd.DataFrame(data)
        if not df.empty:
            df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
            df = df.tail(total_bars_needed).reset_index(drop=True) # Ensure we have enough most recent bars
            if len(df) < total_bars_needed: # Check if we actually got enough bars
                logging.warning(f"Token {instrument_token}: Insufficient data ({len(df)}/{total_bars_needed} bars) fetched.")
                return None
            return df
        else:
            logging.warning(f"Token {instrument_token}: No historical data received.")
            return None
    except Exception as e:
        logging.error(f"Error fetching historical data for token {instrument_token}: {e}")
        return None


def calculate_levels_and_conditions(df_full, lookback_period_sd, resolution, threshold_percent, edge_near_atr_mult):
    """
    Calculates S/D, equilibrium levels, and conditions.
    S/D zones are calculated based on `df_hist` (data ending at T-2, day before yesterday).
    Conditions like "Crossed_Edge_Yesterday" are based on `prev_close` (T-1, yesterday) and `prev_prev_close` (T-2).
    """
    if df_full is None or len(df_full) < lookback_period_sd + 2: # Need enough for S/D base + prev_close + prev_prev_close
        logging.warning("Insufficient data for detailed calculation.")
        return None

    # --- Identify relevant bars ---
    # Yesterday's data (T-1)
    prev_bar = df_full.iloc[-1]
    prev_close = prev_bar['close']
    prev_volume = prev_bar['volume']

    # Day before yesterday's data (T-2)
    prev_prev_bar = df_full.iloc[-2]
    prev_prev_close = prev_prev_bar['close']

    # Calculation base for S/D zones: data ending at T-2 (day before yesterday)
    # This ensures zones are known *before* "yesterday's" price action
    df_hist_sd_base = df_full.iloc[-(lookback_period_sd + 2) : -2].copy()
    if len(df_hist_sd_base) < lookback_period_sd:
        logging.warning(f"Not enough data for S/D base calculation after slicing: got {len(df_hist_sd_base)}, need {lookback_period_sd}")
        return None

    # Calculate ATR on the S/D calculation base period
    current_atr = calculate_atr(df_hist_sd_base, ATR_PERIOD) # ATR based on data ending T-2

    # --- Calculate S/D and Equilibrium based on df_hist_sd_base ---
    max_price = df_hist_sd_base['high'].max()
    min_price = df_hist_sd_base['low'].min()
    total_volume_lookback = df_hist_sd_base['volume'].sum()
    avg_volume_lookback = df_hist_sd_base['volume'].mean() # For volume confirmation
    equi_avg_calc = (max_price + min_price) / 2 if max_price != min_price else max_price

    results = {
        'max_lookback': max_price, 'min_lookback': min_price, 'total_volume_lookback': total_volume_lookback,
        'supply_lvl_bottom': None, 'demand_lvl_top': None,
        'supply_wavg': None, 'demand_wavg': None,
        'supply_strength_score': 0.0, 'demand_strength_score': 0.0,
        'equi_avg': equi_avg_calc, 'equi_wavg': None,
        'supply_found': False, 'demand_found': False,
        'prev_close': prev_close,
        'prev_prev_close': prev_prev_close,
        'atr_calc_base': current_atr if current_atr is not None else 0.0,
        'Crossed_Supply_Edge_Yesterday': False,
        'Crossed_Demand_Edge_Yesterday': False,
        'Supply_Cross_Vol_Confirmed_Yesterday': False,
        'Demand_Cross_Vol_Confirmed_Yesterday': False,
        'Was_Near_Demand_Yesterday_ATR': False, # ATR based
        'Was_Near_Supply_Yesterday_ATR': False  # ATR based
    }

    if total_volume_lookback == 0 or max_price == min_price or resolution <= 1:
        logging.debug("S/D Calculation skipped: Zero volume, zero price range, or invalid resolution.")
        return results

    price_range_step = (max_price - min_price) / resolution
    if price_range_step == 0: # Avoid issues if max_price is very close to min_price
        price_range_step = (max_price * 0.001) if max_price > 0 else 0.001


    # Supply calculation
    current_supply_level_top = max_price
    supply_volume_in_zone_bins = 0
    supply_weighted_sum = 0.0
    supply_num_bins = 0
    for i in range(resolution):
        current_supply_level_bottom = max(min_price, current_supply_level_top - price_range_step)
        supply_mask = (df_hist_sd_base['high'] < current_supply_level_top) & (df_hist_sd_base['high'] >= current_supply_level_bottom)
        current_bin_volume = df_hist_sd_base.loc[supply_mask, 'volume'].sum()

        if current_bin_volume > 0:
            supply_volume_in_zone_bins += current_bin_volume
            supply_weighted_sum += ((current_supply_level_bottom + current_supply_level_top) / 2) * current_bin_volume
            supply_num_bins +=1

        if total_volume_lookback > 0 and (supply_volume_in_zone_bins / total_volume_lookback * 100.0) >= threshold_percent:
            results['supply_found'] = True
            results['supply_lvl_bottom'] = current_supply_level_bottom
            results['supply_wavg'] = supply_weighted_sum / supply_volume_in_zone_bins if supply_volume_in_zone_bins > 0 else None
            # Strength Score: (Proportion of Volume) * (Relative Tightness of Bins)
            zone_tightness_factor = (max_price - min_price) / (results['supply_lvl_bottom'] * supply_num_bins) if results['supply_lvl_bottom'] > 0 and supply_num_bins > 0 else 1
            zone_tightness_factor = min(max(zone_tightness_factor, 0.1), 10) # Bound the factor
            results['supply_strength_score'] = (supply_volume_in_zone_bins / total_volume_lookback) / zone_tightness_factor
            break
        current_supply_level_top = current_supply_level_bottom
        if current_supply_level_top <= min_price : break


    # Demand calculation
    current_demand_level_bottom = min_price
    demand_volume_in_zone_bins = 0
    demand_weighted_sum = 0.0
    demand_num_bins = 0
    for i in range(resolution):
        current_demand_level_top = min(max_price, current_demand_level_bottom + price_range_step)
        demand_mask = (df_hist_sd_base['low'] > current_demand_level_bottom) & (df_hist_sd_base['low'] <= current_demand_level_top)
        current_bin_volume = df_hist_sd_base.loc[demand_mask, 'volume'].sum()

        if current_bin_volume > 0:
            demand_volume_in_zone_bins += current_bin_volume
            demand_weighted_sum += ((current_demand_level_top + current_demand_level_bottom) / 2) * current_bin_volume
            demand_num_bins +=1

        if total_volume_lookback > 0 and (demand_volume_in_zone_bins / total_volume_lookback * 100.0) >= threshold_percent:
            results['demand_found'] = True
            results['demand_lvl_top'] = current_demand_level_top
            results['demand_wavg'] = demand_weighted_sum / demand_volume_in_zone_bins if demand_volume_in_zone_bins > 0 else None
            zone_tightness_factor = (max_price - min_price) / (results['demand_lvl_top'] * demand_num_bins) if results['demand_lvl_top'] > 0 and demand_num_bins > 0 else 1
            zone_tightness_factor = min(max(zone_tightness_factor, 0.1), 10)
            results['demand_strength_score'] = (demand_volume_in_zone_bins / total_volume_lookback) / zone_tightness_factor
            break
        current_demand_level_bottom = current_demand_level_top
        if current_demand_level_bottom >= max_price: break


    if results['supply_wavg'] is not None and results['demand_wavg'] is not None:
        results['equi_wavg'] = (results['supply_wavg'] + results['demand_wavg']) / 2


    # --- Conditions based on YESTERDAY's close (prev_close) vs zones from DAY BEFORE YESTERDAY ---
    # Condition 1: Did yesterday's close cross ABOVE the calculated Supply_Lvl_Bottom?
    if results['supply_lvl_bottom'] is not None and prev_prev_close < results['supply_lvl_bottom'] <= prev_close:
        results['Crossed_Supply_Edge_Yesterday'] = True
        if prev_volume > avg_volume_lookback * 1.2: # Volume confirmation (e.g. 20% above avg)
            results['Supply_Cross_Vol_Confirmed_Yesterday'] = True

    # Condition 2: Did yesterday's close cross BELOW the calculated Demand_Lvl_Top?
    if results['demand_lvl_top'] is not None and prev_prev_close > results['demand_lvl_top'] >= prev_close:
        results['Crossed_Demand_Edge_Yesterday'] = True
        if prev_volume > avg_volume_lookback * 1.2:
            results['Demand_Cross_Vol_Confirmed_Yesterday'] = True

    # Condition 3 & 4: Was yesterday's close NEAR demand/supply using ATR?
    if current_atr is not None and current_atr > 0:
        if results['demand_lvl_top'] is not None:
            # prev_close is above demand_lvl_top but within X * ATR
            if results['demand_lvl_top'] < prev_close <= (results['demand_lvl_top'] + edge_near_atr_mult * current_atr):
                results['Was_Near_Demand_Yesterday_ATR'] = True
        if results['supply_lvl_bottom'] is not None:
            # prev_close is below supply_lvl_bottom but within X * ATR
            if results['supply_lvl_bottom'] > prev_close >= (results['supply_lvl_bottom'] - edge_near_atr_mult * current_atr):
                results['Was_Near_Supply_Yesterday_ATR'] = True
    return results


def check_crossing_status_atr(ltp, prev_close, target_price, atr_value, atr_multiplier, context=""):
    """Checks if LTP has crossed or is near the target price using ATR for tolerance."""
    if target_price is None or math.isnan(target_price) or ltp is None or prev_close is None or atr_value is None or atr_value <= 0:
        return "N/A (Invalid Data for ATR check)"

    tolerance = atr_value * atr_multiplier
    upper_bound = target_price + tolerance
    lower_bound = target_price - tolerance
    status = "Neutral"

    if prev_close < target_price <= ltp: status = "Crossed Above"
    elif prev_close > target_price >= ltp: status = "Crossed Below"
    elif lower_bound <= ltp <= upper_bound: # Price is within the tolerance zone
        if ltp > target_price: status = "Near Above (ATR)"
        elif ltp < target_price: status = "Near Below (ATR)"
        else: status = "At Level (ATR)"
    elif ltp > upper_bound: status = f"Above {context} (ATR)" if context else "Above (ATR)"
    elif ltp < lower_bound: status = f"Below {context} (ATR)" if context else "Below (ATR)"
    return status

# --- Main Execution ---
if __name__ == "__main__":
    if not os.path.exists(INPUT_CSV):
        logging.error(f"Input file not found: {INPUT_CSV}")
        exit()
    try:
        symbols_df = pd.read_csv(INPUT_CSV)
        if 'Symbol' not in symbols_df.columns:
            logging.error("Input CSV must contain a 'Symbol' column.")
            exit()
        symbols_to_scan = symbols_df['Symbol'].unique().tolist()
        logging.info(f"Found {len(symbols_to_scan)} unique symbols to scan.")
    except Exception as e:
        logging.error(f"Error reading input CSV {INPUT_CSV}: {e}")
        exit()

    token_map = get_instrument_token(symbols_to_scan)
    if not token_map:
        logging.error("Could not fetch any instrument tokens. Exiting.")
        exit()

    scan_results = []
    processed_count = 0
    total_symbols = len(token_map)

    for symbol, token in token_map.items():
        processed_count += 1
        logging.info(f"Processing {symbol} ({processed_count}/{total_symbols})... Token: {token}")

        hist_df_full = get_historical_data(token, LOOKBACK_PERIOD, ATR_PERIOD, TIMEFRAME)

        if hist_df_full is None:
            logging.warning(f"Skipping {symbol} due to insufficient historical data.")
            continue

        level_data = calculate_levels_and_conditions(
            hist_df_full,
            LOOKBACK_PERIOD, # lookback for S/D calculation
            EQUILIBRIUM_RESOLUTION,
            VOLUME_THRESHOLD_PERCENT,
            EDGE_NEARNESS_ATR_MULTIPLIER
        )

        if level_data is None:
            logging.warning(f"Could not calculate levels/conditions for {symbol}.")
            continue

        prev_close_for_ltp_check = level_data['prev_close'] # This is T-1 close
        atr_for_ltp_check = level_data['atr_calc_base'] # ATR calculated on T-2 data

        ltp = None
        try:
            ltp_dict = kite.ltp(f"NSE:{symbol}")
            if f"NSE:{symbol}" in ltp_dict:
                ltp = ltp_dict[f"NSE:{symbol}"]['last_price']
                logging.debug(f"{symbol} LTP: {ltp:.2f}")
            else:
                logging.warning(f"Could not fetch LTP for NSE:{symbol}.")
            time.sleep(0.35) # API call delay
        except Exception as e:
            logging.error(f"Error fetching LTP for {symbol}: {e}")

        # --- Check *Today's* Crossing Statuses (LTP vs Prev_Close, using ATR based tolerance) ---
        status_equi_avg = "N/A"
        status_equi_wavg = "N/A"
        status_supply_wavg = "N/A"
        status_demand_wavg = "N/A"
        status_supply_edge = "N/A"
        status_demand_edge = "N/A"

        if ltp is not None and prev_close_for_ltp_check is not None and atr_for_ltp_check is not None and atr_for_ltp_check > 0:
            status_equi_avg = check_crossing_status_atr(ltp, prev_close_for_ltp_check, level_data['equi_avg'], atr_for_ltp_check, CROSSING_TOLERANCE_ATR_MULTIPLIER, "Equi Avg")
            status_equi_wavg = check_crossing_status_atr(ltp, prev_close_for_ltp_check, level_data['equi_wavg'], atr_for_ltp_check, CROSSING_TOLERANCE_ATR_MULTIPLIER, "Equi WAvg")
            status_supply_wavg = check_crossing_status_atr(ltp, prev_close_for_ltp_check, level_data['supply_wavg'], atr_for_ltp_check, CROSSING_TOLERANCE_ATR_MULTIPLIER, "Supply WAvg")
            status_demand_wavg = check_crossing_status_atr(ltp, prev_close_for_ltp_check, level_data['demand_wavg'], atr_for_ltp_check, CROSSING_TOLERANCE_ATR_MULTIPLIER, "Demand WAvg")
            status_supply_edge = check_crossing_status_atr(ltp, prev_close_for_ltp_check, level_data['supply_lvl_bottom'], atr_for_ltp_check, CROSSING_TOLERANCE_ATR_MULTIPLIER, "Supply Edge")
            status_demand_edge = check_crossing_status_atr(ltp, prev_close_for_ltp_check, level_data['demand_lvl_top'], atr_for_ltp_check, CROSSING_TOLERANCE_ATR_MULTIPLIER, "Demand Edge")
        elif atr_for_ltp_check is None or atr_for_ltp_check <= 0:
            logging.warning(f"{symbol}: ATR is zero or None, cannot perform ATR-based status checks for LTP.")


        scan_results.append({
            'Timestamp': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'),
            'Symbol': symbol,
            'LTP': f"{ltp:.2f}" if ltp is not None else 'N/A',
            'Prev_Close (T-1)': f"{level_data['prev_close']:.2f}" if level_data['prev_close'] is not None else 'N/A',
            'Prev_Prev_Close (T-2)': f"{level_data['prev_prev_close']:.2f}" if level_data['prev_prev_close'] is not None else 'N/A',
            'ATR_LookbackBase': f"{level_data['atr_calc_base']:.2f}" if level_data['atr_calc_base'] is not None and level_data['atr_calc_base'] > 0 else 'N/A',

            'Crossed_Supply_Edge_Yesterday': level_data['Crossed_Supply_Edge_Yesterday'],
            'Supply_Cross_Vol_Confirmed_Yesterday': level_data['Supply_Cross_Vol_Confirmed_Yesterday'],
            'Crossed_Demand_Edge_Yesterday': level_data['Crossed_Demand_Edge_Yesterday'],
            'Demand_Cross_Vol_Confirmed_Yesterday': level_data['Demand_Cross_Vol_Confirmed_Yesterday'],
            'Was_Near_Demand_Yesterday_ATR': level_data['Was_Near_Demand_Yesterday_ATR'],
            'Was_Near_Supply_Yesterday_ATR': level_data['Was_Near_Supply_Yesterday_ATR'],

            'Status_Equi_Avg': status_equi_avg,
            'Status_Equi_Wavg': status_equi_wavg,
            'Status_Supply_Wavg': status_supply_wavg,
            'Status_Demand_Wavg': status_demand_wavg,
            'Status_Supply_Edge': status_supply_edge,
            'Status_Demand_Edge': status_demand_edge,

            'Supply_Lvl_Bottom': f"{level_data['supply_lvl_bottom']:.2f}" if level_data['supply_lvl_bottom'] is not None else 'N/A',
            'Supply_Wavg': f"{level_data['supply_wavg']:.2f}" if level_data['supply_wavg'] is not None else 'N/A',
            'Supply_Strength_Score': f"{level_data['supply_strength_score']:.4f}",
            'Demand_Lvl_Top': f"{level_data['demand_lvl_top']:.2f}" if level_data['demand_lvl_top'] is not None else 'N/A',
            'Demand_Wavg': f"{level_data['demand_wavg']:.2f}" if level_data['demand_wavg'] is not None else 'N/A',
            'Demand_Strength_Score': f"{level_data['demand_strength_score']:.4f}",
            'Equi_Avg': f"{level_data['equi_avg']:.2f}" if level_data['equi_avg'] is not None else 'N/A',
            'Equi_Wavg': f"{level_data['equi_wavg']:.2f}" if level_data['equi_wavg'] is not None else 'N/A',
            'Lookback_High': f"{level_data['max_lookback']:.2f}",
            'Lookback_Low': f"{level_data['min_lookback']:.2f}",
        })

        # Log alerts
        interesting_statuses = ["Crossed Above", "Crossed Below", "Near Above (ATR)", "Near Below (ATR)", "At Level (ATR)"]
        current_statuses_today = [status_equi_avg, status_equi_wavg, status_supply_wavg, status_demand_wavg, status_supply_edge, status_demand_edge]
        yesterday_conditions_met = level_data['Crossed_Supply_Edge_Yesterday'] or \
                                   level_data['Crossed_Demand_Edge_Yesterday'] or \
                                   level_data['Was_Near_Demand_Yesterday_ATR'] or \
                                   level_data['Was_Near_Supply_Yesterday_ATR']

        if any(any(s in str(status) for s in interesting_statuses) for status in current_statuses_today): # Check if any interesting status is part of the string
             logging.info(f"*** {symbol}: Current Interaction with S/D Level (ATR Based) ***")
        elif yesterday_conditions_met:
             logging.info(f"--- {symbol}: Condition from Yesterday Met (ATR Based) ---")


    if scan_results:
        results_df = pd.DataFrame(scan_results)
        cols_order = [
            'Timestamp', 'Symbol', 'LTP', 'Prev_Close (T-1)', 'Prev_Prev_Close (T-2)', 'ATR_LookbackBase',
            'Crossed_Supply_Edge_Yesterday', 'Supply_Cross_Vol_Confirmed_Yesterday',
            'Was_Near_Supply_Yesterday_ATR',
            'Crossed_Demand_Edge_Yesterday', 'Demand_Cross_Vol_Confirmed_Yesterday',
            'Was_Near_Demand_Yesterday_ATR',
            'Status_Supply_Edge', 'Status_Supply_Wavg',
            'Status_Demand_Edge', 'Status_Demand_Wavg',
            'Status_Equi_Avg', 'Status_Equi_Wavg',
            'Supply_Lvl_Bottom', 'Supply_Wavg', 'Supply_Strength_Score',
            'Demand_Lvl_Top', 'Demand_Wavg', 'Demand_Strength_Score',
            'Equi_Avg', 'Equi_Wavg',
            'Lookback_High', 'Lookback_Low'
            ]
        # Ensure all columns in cols_order exist in results_df, add if not (with N/A or default)
        for col in cols_order:
            if col not in results_df.columns:
                results_df[col] = 'N/A'

        results_df = results_df.reindex(columns=cols_order) # Reorder and ensure all are present
        results_df.to_csv(OUTPUT_CSV, index=False)
        logging.info(f"Scan complete. Results saved to {OUTPUT_CSV}")
    else:
        logging.info("Scan complete. No symbols processed successfully or no results generated.")