"""
Risk/Reward Ratio Comparison Script

Tests different stop loss and target combinations to find optimal settings
"""

import pandas as pd
from datetime import datetime, timedelta
from backtest_scanner import EMAPullbackBacktester
import logging

# Reduce logging noise
logging.getLogger().setLevel(logging.WARNING)


def run_comparison(api_key, access_token, input_csv, start_date, end_date):
    """
    Test multiple stop loss and target combinations
    """
    
    print("\n" + "="*80)
    print("🔬 RISK/REWARD RATIO COMPARISON")
    print("="*80)
    print(f"Period: {start_date.date()} to {end_date.date()}")
    print(f"Testing REFINED version (quality≥1: BOUNCED + good PULLBACK)")
    print(f"Finding optimal stop loss and target settings")
    print("="*80 + "\n")
    
    # Define test configurations
    # Format: (name, stop_loss_pct, target_pct, description)
    configs = [
        ("Conservative 2:1", 0.02, 0.04, "Tight stops, small targets"),
        ("Current 2:1", 0.03, 0.06, "Balanced approach ⭐"),
        ("Moderate 2:1", 0.04, 0.08, "More room, bigger targets"),
        ("Aggressive 2:1", 0.05, 0.10, "Wide stops, large targets"),
        ("Higher R:R 3:1", 0.03, 0.09, "Risk ₹3 to make ₹9"),
        ("Extreme R:R 4:1", 0.03, 0.12, "Risk ₹3 to make ₹12"),
        ("Tighter 3:1", 0.02, 0.06, "Small risk, good reward"),
    ]
    
    results = []
    
    for i, (name, stop_loss, target, desc) in enumerate(configs, 1):
        print(f"\n[{i}/{len(configs)}] Testing: {name}")
        print(f"   Settings: {stop_loss*100:.1f}% SL / {target*100:.1f}% Target ({desc})")
        
        try:
            # Create new backtester
            backtester = EMAPullbackBacktester(api_key, access_token)
            
            # Set parameters
            backtester.initial_capital = 1000000
            backtester.max_position_size = 0.05
            backtester.stop_loss_pct = stop_loss
            backtester.target_pct = target
            backtester.max_holding_days = 20
            backtester.min_quality_score = 1  # Refined: BOUNCED + good PULLBACK
            
            # Run backtest
            backtester.run_backtest(input_csv, start_date, end_date, output_dir='temp_comparison')
            
            # Collect results
            if len(backtester.trades) > 0:
                trades_df = pd.DataFrame(backtester.trades)
                
                total_trades = len(trades_df)
                winning_trades = len(trades_df[trades_df['Net_PnL'] > 0])
                win_rate = (winning_trades / total_trades) * 100
                
                total_return = ((backtester.current_capital - backtester.initial_capital) / 
                               backtester.initial_capital) * 100
                
                # Profit factor
                gross_profit = trades_df[trades_df['Net_PnL'] > 0]['Net_PnL'].sum()
                gross_loss = abs(trades_df[trades_df['Net_PnL'] < 0]['Net_PnL'].sum())
                profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
                
                # Max drawdown
                trades_df['Cumulative_PnL'] = trades_df['Net_PnL'].cumsum()
                trades_df['Cumulative_Peak'] = trades_df['Cumulative_PnL'].cummax()
                trades_df['Drawdown'] = trades_df['Cumulative_PnL'] - trades_df['Cumulative_Peak']
                max_drawdown = trades_df['Drawdown'].min()
                max_drawdown_pct = (max_drawdown / backtester.initial_capital) * 100
                
                # Average metrics
                avg_win = trades_df[trades_df['Net_PnL'] > 0]['Net_PnL'].mean() if winning_trades > 0 else 0
                avg_loss = trades_df[trades_df['Net_PnL'] < 0]['Net_PnL'].mean() if (total_trades - winning_trades) > 0 else 0
                avg_pnl = trades_df['Net_PnL'].mean()
                
                # Exit reason counts
                targets_hit = len(trades_df[trades_df['Exit_Reason'] == 'TARGET'])
                stops_hit = len(trades_df[trades_df['Exit_Reason'] == 'STOP_LOSS'])
                max_hold = len(trades_df[trades_df['Exit_Reason'] == 'MAX_HOLDING'])
                
                target_pct = (targets_hit / total_trades) * 100
                stop_pct = (stops_hit / total_trades) * 100
                
                # Risk-adjusted return
                risk_adj_return = total_return / abs(max_drawdown_pct) if max_drawdown_pct != 0 else 0
                
                result = {
                    'Name': name,
                    'Stop_Loss': f"{stop_loss*100:.1f}%",
                    'Target': f"{target*100:.1f}%",
                    'R:R_Ratio': f"1:{target/stop_loss:.1f}",
                    'Total_Trades': total_trades,
                    'Win_Rate': round(win_rate, 2),
                    'Total_Return': round(total_return, 2),
                    'Final_Capital': round(backtester.current_capital, 2),
                    'Profit_Factor': round(profit_factor, 2),
                    'Max_Drawdown': round(max_drawdown_pct, 2),
                    'Risk_Adj_Return': round(risk_adj_return, 2),
                    'Avg_Win': round(avg_win, 2),
                    'Avg_Loss': round(avg_loss, 2),
                    'Avg_Trade': round(avg_pnl, 2),
                    'Target_Hit_%': round(target_pct, 1),
                    'Stop_Hit_%': round(stop_pct, 1),
                }
                
                results.append(result)
                
                # Quick summary
                print(f"   ✓ Return: {total_return:.1f}% | Win Rate: {win_rate:.1f}% | PF: {profit_factor:.2f} | Drawdown: {max_drawdown_pct:.1f}%")
            else:
                print(f"   ✗ No trades executed")
                
        except Exception as e:
            print(f"   ✗ Error: {e}")
            continue
    
    # Restore normal logging
    logging.getLogger().setLevel(logging.INFO)
    
    if len(results) == 0:
        print("\n❌ No successful backtests completed")
        return None
    
    # Create results DataFrame
    results_df = pd.DataFrame(results)
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_file = f"risk_reward_comparison_{timestamp}.csv"
    results_df.to_csv(output_file, index=False)
    
    # Display results
    print("\n" + "="*80)
    print("📊 COMPARISON RESULTS")
    print("="*80)
    
    # Sort by total return
    results_sorted = results_df.sort_values('Total_Return', ascending=False)
    
    print("\n🏆 RANKED BY TOTAL RETURN:")
    print("-" * 80)
    for i, row in results_sorted.iterrows():
        rank = list(results_sorted.index).index(i) + 1
        symbol = "⭐" if "Current" in row['Name'] else "  "
        print(f"{rank}. {symbol} {row['Name']}")
        print(f"   {row['Stop_Loss']} SL / {row['Target']} Target ({row['R:R_Ratio']})")
        print(f"   Return: {row['Total_Return']}% | Win Rate: {row['Win_Rate']}% | "
              f"PF: {row['Profit_Factor']} | Drawdown: {row['Max_Drawdown']}%")
        print(f"   Target Hit: {row['Target_Hit_%']}% | Stop Hit: {row['Stop_Hit_%']}%")
        print()
    
    # Sort by risk-adjusted return
    print("\n💎 RANKED BY RISK-ADJUSTED RETURN (Return/Drawdown):")
    print("-" * 80)
    results_sorted = results_df.sort_values('Risk_Adj_Return', ascending=False)
    for i, row in results_sorted.head(3).iterrows():
        rank = list(results_sorted.index).index(i) + 1
        print(f"{rank}. {row['Name']}: {row['Risk_Adj_Return']:.2f}")
        print(f"   ({row['Total_Return']}% return with {row['Max_Drawdown']}% drawdown)")
    
    # Sort by profit factor
    print("\n🎯 RANKED BY PROFIT FACTOR:")
    print("-" * 80)
    results_sorted = results_df.sort_values('Profit_Factor', ascending=False)
    for i, row in results_sorted.head(3).iterrows():
        rank = list(results_sorted.index).index(i) + 1
        print(f"{rank}. {row['Name']}: {row['Profit_Factor']}")
        print(f"   (Win Rate: {row['Win_Rate']}%, Avg Win: ₹{row['Avg_Win']:.0f}, Avg Loss: ₹{row['Avg_Loss']:.0f})")
    
    # Best overall recommendation
    print("\n" + "="*80)
    print("🏅 RECOMMENDATION")
    print("="*80)
    
    # Find best by multiple criteria
    best_return = results_df.loc[results_df['Total_Return'].idxmax()]
    best_risk_adj = results_df.loc[results_df['Risk_Adj_Return'].idxmax()]
    best_win_rate = results_df.loc[results_df['Win_Rate'].idxmax()]
    best_pf = results_df.loc[results_df['Profit_Factor'].idxmax()]
    
    print(f"\n🥇 Best Total Return: {best_return['Name']}")
    print(f"   {best_return['Total_Return']}% return with {best_return['Win_Rate']}% win rate")
    
    print(f"\n🥈 Best Risk-Adjusted: {best_risk_adj['Name']}")
    print(f"   {best_risk_adj['Total_Return']}% return with only {best_risk_adj['Max_Drawdown']}% drawdown")
    
    print(f"\n🥉 Best Win Rate: {best_win_rate['Name']}")
    print(f"   {best_win_rate['Win_Rate']}% win rate with {best_win_rate['Total_Return']}% return")
    
    # Overall best pick
    print(f"\n⭐ OVERALL BEST PICK:")
    # Score each config: 40% return, 30% risk-adj, 20% profit factor, 10% win rate
    results_df['Score'] = (
        (results_df['Total_Return'] / results_df['Total_Return'].max() * 40) +
        (results_df['Risk_Adj_Return'] / results_df['Risk_Adj_Return'].max() * 30) +
        (results_df['Profit_Factor'] / results_df['Profit_Factor'].max() * 20) +
        (results_df['Win_Rate'] / results_df['Win_Rate'].max() * 10)
    )
    
    best_overall = results_df.loc[results_df['Score'].idxmax()]
    print(f"   {best_overall['Name']}")
    print(f"   {best_overall['Stop_Loss']} SL / {best_overall['Target']} Target ({best_overall['R:R_Ratio']})")
    print(f"   Return: {best_overall['Total_Return']}% | Win Rate: {best_overall['Win_Rate']}%")
    print(f"   Profit Factor: {best_overall['Profit_Factor']} | Drawdown: {best_overall['Max_Drawdown']}%")
    
    print("\n" + "="*80)
    print(f"Full results saved to: {output_file}")
    print("="*80 + "\n")
    
    return results_df


if __name__ == "__main__":
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "RcFSX2nfdWmuiF02bjuO1gUdSEMnVF8z"
    INPUT_CSV = "data\\sector_marketcap_20251022_225409.csv"
    
    # Test period (last 2 years)
    END_DATE = datetime.now()
    START_DATE = END_DATE - timedelta(days=730)
    
    print("\n⏱️  This will take 15-20 minutes to test all configurations")
    print("☕ Perfect time for a coffee break!\n")
    
    # Run comparison
    results = run_comparison(API_KEY, ACCESS_TOKEN, INPUT_CSV, START_DATE, END_DATE)
    
    if results is not None:
        print("\n✅ Comparison complete!")
        print(f"   Tested {len(results)} different risk/reward configurations")
        print(f"   Review the results above to choose your optimal settings")
    else:
        print("\n❌ Comparison failed")

