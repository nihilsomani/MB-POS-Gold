"""
Parameter Optimization Script for EMA Pullback Strategy

This script helps you find the optimal parameters by testing
multiple combinations and comparing results.
"""

import pandas as pd
from datetime import datetime, timedelta
from backtest_scanner import EMAPullbackBacktester
import json
import os
from itertools import product


class StrategyOptimizer:
    """
    Test multiple parameter combinations and identify best settings
    """
    
    def __init__(self, api_key, access_token):
        self.api_key = api_key
        self.access_token = access_token
        
    def run_optimization(self, 
                        input_csv, 
                        start_date, 
                        end_date,
                        output_dir='optimization_results'):
        """
        Run optimization across multiple parameter combinations
        """
        
        os.makedirs(output_dir, exist_ok=True)
        
        # Define parameter grid
        param_grid = {
            'max_position_size': [0.02, 0.05, 0.10],
            'stop_loss_pct': [0.02, 0.03, 0.05],
            'target_pct': [0.04, 0.06, 0.10],
            'min_quality_score': [0, 1, 2],
            'max_holding_days': [10, 20, 30]
        }
        
        # Generate all combinations
        param_names = list(param_grid.keys())
        param_values = list(param_grid.values())
        combinations = list(product(*param_values))
        
        print(f"\n{'='*70}")
        print(f"PARAMETER OPTIMIZATION")
        print(f"{'='*70}")
        print(f"Testing {len(combinations)} parameter combinations")
        print(f"Period: {start_date.date()} to {end_date.date()}")
        print(f"This may take a while...")
        print(f"{'='*70}\n")
        
        results = []
        
        for i, combo in enumerate(combinations, 1):
            params = dict(zip(param_names, combo))
            
            # Skip invalid combinations (target should be at least 1.5x stop loss)
            if params['target_pct'] < params['stop_loss_pct'] * 1.5:
                continue
            
            print(f"\n[{i}/{len(combinations)}] Testing: {params}")
            
            try:
                # Create new backtester instance
                backtester = EMAPullbackBacktester(self.api_key, self.access_token)
                
                # Set parameters
                backtester.max_position_size = params['max_position_size']
                backtester.stop_loss_pct = params['stop_loss_pct']
                backtester.target_pct = params['target_pct']
                backtester.min_quality_score = params['min_quality_score']
                backtester.max_holding_days = params['max_holding_days']
                
                # Suppress detailed logging for optimization
                import logging
                logging.getLogger().setLevel(logging.WARNING)
                
                # Run backtest
                backtester.run_backtest(input_csv, start_date, end_date, output_dir=f"{output_dir}/temp")
                
                # Extract results
                if len(backtester.trades) > 0:
                    trades_df = pd.DataFrame(backtester.trades)
                    
                    total_trades = len(trades_df)
                    winning_trades = len(trades_df[trades_df['Net_PnL'] > 0])
                    win_rate = (winning_trades / total_trades) * 100
                    
                    total_pnl = trades_df['Net_PnL'].sum()
                    total_return_pct = ((backtester.current_capital - backtester.initial_capital) / 
                                       backtester.initial_capital) * 100
                    
                    # Calculate profit factor
                    gross_profit = trades_df[trades_df['Net_PnL'] > 0]['Net_PnL'].sum()
                    gross_loss = abs(trades_df[trades_df['Net_PnL'] < 0]['Net_PnL'].sum())
                    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
                    
                    # Calculate max drawdown
                    trades_df['Cumulative_PnL'] = trades_df['Net_PnL'].cumsum()
                    trades_df['Cumulative_Peak'] = trades_df['Cumulative_PnL'].cummax()
                    trades_df['Drawdown'] = trades_df['Cumulative_PnL'] - trades_df['Cumulative_Peak']
                    max_drawdown = trades_df['Drawdown'].min()
                    max_drawdown_pct = (max_drawdown / backtester.initial_capital) * 100
                    
                    # Calculate Sharpe-like ratio (return / drawdown)
                    risk_adjusted_return = total_return_pct / abs(max_drawdown_pct) if max_drawdown_pct != 0 else 0
                    
                    avg_holding = trades_df['Holding_Days'].mean()
                    
                    result = {
                        **params,
                        'Total_Trades': total_trades,
                        'Win_Rate': round(win_rate, 2),
                        'Total_Return_Pct': round(total_return_pct, 2),
                        'Total_PnL': round(total_pnl, 2),
                        'Profit_Factor': round(profit_factor, 2),
                        'Max_Drawdown_Pct': round(max_drawdown_pct, 2),
                        'Risk_Adjusted_Return': round(risk_adjusted_return, 2),
                        'Avg_Holding_Days': round(avg_holding, 2),
                        'Final_Capital': round(backtester.current_capital, 2)
                    }
                    
                    results.append(result)
                    
                    print(f"  ✓ Return: {total_return_pct:.2f}% | Win Rate: {win_rate:.2f}% | "
                          f"Profit Factor: {profit_factor:.2f} | Trades: {total_trades}")
                else:
                    print(f"  ✗ No trades executed")
                    
            except Exception as e:
                print(f"  ✗ Error: {e}")
                continue
        
        # Restore logging
        logging.getLogger().setLevel(logging.INFO)
        
        # Analyze results
        if len(results) == 0:
            print("\n❌ No successful backtests completed")
            return
        
        results_df = pd.DataFrame(results)
        
        # Save all results
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        results_file = f"{output_dir}/optimization_results_{timestamp}.csv"
        results_df.to_csv(results_file, index=False)
        
        # Find best parameters by different criteria
        best_return = results_df.loc[results_df['Total_Return_Pct'].idxmax()]
        best_win_rate = results_df.loc[results_df['Win_Rate'].idxmax()]
        best_profit_factor = results_df.loc[results_df['Profit_Factor'].idxmax()]
        best_risk_adjusted = results_df.loc[results_df['Risk_Adjusted_Return'].idxmax()]
        
        # Filter for good strategies (basic criteria)
        good_strategies = results_df[
            (results_df['Total_Return_Pct'] > 10) &
            (results_df['Win_Rate'] > 50) &
            (results_df['Profit_Factor'] > 1.3) &
            (results_df['Total_Trades'] >= 20)
        ].sort_values('Risk_Adjusted_Return', ascending=False)
        
        # Print results
        print(f"\n{'='*70}")
        print(f"OPTIMIZATION RESULTS")
        print(f"{'='*70}")
        print(f"\nTotal configurations tested: {len(results_df)}")
        print(f"Results saved to: {results_file}")
        
        print(f"\n--- BEST BY TOTAL RETURN ---")
        self._print_config(best_return)
        
        print(f"\n--- BEST BY WIN RATE ---")
        self._print_config(best_win_rate)
        
        print(f"\n--- BEST BY PROFIT FACTOR ---")
        self._print_config(best_profit_factor)
        
        print(f"\n--- BEST BY RISK-ADJUSTED RETURN ---")
        self._print_config(best_risk_adjusted)
        
        if len(good_strategies) > 0:
            print(f"\n--- TOP 5 BALANCED STRATEGIES ---")
            print(f"(Return > 10%, Win Rate > 50%, PF > 1.3, Trades >= 20)")
            for i, row in good_strategies.head(5).iterrows():
                print(f"\n{i+1}.")
                self._print_config(row)
            
            # Save top strategies
            top_file = f"{output_dir}/top_strategies_{timestamp}.json"
            top_strategies = good_strategies.head(5).to_dict('records')
            with open(top_file, 'w') as f:
                json.dump(top_strategies, f, indent=4)
            print(f"\nTop strategies saved to: {top_file}")
        else:
            print(f"\n⚠️  No strategies met balanced criteria")
            print(f"   Consider:")
            print(f"   - Extending backtest period")
            print(f"   - Adding more symbols")
            print(f"   - Adjusting parameter ranges")
        
        print(f"\n{'='*70}\n")
        
        return results_df
    
    def _print_config(self, row):
        """Print a configuration in a readable format"""
        print(f"Position Size: {row['max_position_size']*100:.0f}% | "
              f"Stop Loss: {row['stop_loss_pct']*100:.0f}% | "
              f"Target: {row['target_pct']*100:.0f}% | "
              f"Min Quality: {row['min_quality_score']} | "
              f"Max Days: {row['max_holding_days']}")
        print(f"Return: {row['Total_Return_Pct']:.2f}% | "
              f"Win Rate: {row['Win_Rate']:.2f}% | "
              f"PF: {row['Profit_Factor']:.2f} | "
              f"Drawdown: {row['Max_Drawdown_Pct']:.2f}% | "
              f"Trades: {row['Total_Trades']}")
        print(f"Risk-Adjusted Return: {row['Risk_Adjusted_Return']:.2f} | "
              f"Avg Holding: {row['Avg_Holding_Days']:.1f} days")
    
    def compare_periods(self, 
                       input_csv, 
                       best_params,
                       periods_to_test,
                       output_dir='comparison_results'):
        """
        Test best parameters across different time periods
        to validate robustness
        """
        
        os.makedirs(output_dir, exist_ok=True)
        
        print(f"\n{'='*70}")
        print(f"ROBUSTNESS TESTING ACROSS PERIODS")
        print(f"{'='*70}")
        print(f"Testing parameters: {best_params}")
        print(f"Across {len(periods_to_test)} different periods")
        print(f"{'='*70}\n")
        
        results = []
        
        for period_name, (start_date, end_date) in periods_to_test.items():
            print(f"\nTesting: {period_name} ({start_date.date()} to {end_date.date()})")
            
            try:
                backtester = EMAPullbackBacktester(self.api_key, self.access_token)
                
                # Set best parameters
                backtester.max_position_size = best_params['max_position_size']
                backtester.stop_loss_pct = best_params['stop_loss_pct']
                backtester.target_pct = best_params['target_pct']
                backtester.min_quality_score = best_params['min_quality_score']
                backtester.max_holding_days = best_params['max_holding_days']
                
                # Suppress detailed logging
                import logging
                logging.getLogger().setLevel(logging.WARNING)
                
                backtester.run_backtest(input_csv, start_date, end_date, output_dir=f"{output_dir}/temp")
                
                if len(backtester.trades) > 0:
                    trades_df = pd.DataFrame(backtester.trades)
                    
                    total_trades = len(trades_df)
                    winning_trades = len(trades_df[trades_df['Net_PnL'] > 0])
                    win_rate = (winning_trades / total_trades) * 100
                    total_return_pct = ((backtester.current_capital - backtester.initial_capital) / 
                                       backtester.initial_capital) * 100
                    
                    gross_profit = trades_df[trades_df['Net_PnL'] > 0]['Net_PnL'].sum()
                    gross_loss = abs(trades_df[trades_df['Net_PnL'] < 0]['Net_PnL'].sum())
                    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
                    
                    result = {
                        'Period': period_name,
                        'Start_Date': start_date.date(),
                        'End_Date': end_date.date(),
                        'Total_Trades': total_trades,
                        'Win_Rate': round(win_rate, 2),
                        'Total_Return_Pct': round(total_return_pct, 2),
                        'Profit_Factor': round(profit_factor, 2)
                    }
                    
                    results.append(result)
                    print(f"  ✓ Return: {total_return_pct:.2f}% | Win Rate: {win_rate:.2f}% | Trades: {total_trades}")
                else:
                    print(f"  ✗ No trades")
                    
            except Exception as e:
                print(f"  ✗ Error: {e}")
        
        # Restore logging
        logging.getLogger().setLevel(logging.INFO)
        
        if len(results) > 0:
            results_df = pd.DataFrame(results)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            comparison_file = f"{output_dir}/period_comparison_{timestamp}.csv"
            results_df.to_csv(comparison_file, index=False)
            
            print(f"\n{'='*70}")
            print(f"ROBUSTNESS RESULTS")
            print(f"{'='*70}")
            print(results_df.to_string(index=False))
            print(f"\nResults saved to: {comparison_file}")
            print(f"{'='*70}\n")
            
            return results_df


# Example usage
if __name__ == "__main__":
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "gfG1Mq3uGRYdYe0Uzqa9S8ROVOWRVQ7U"
    INPUT_CSV = "data\\MB_symbols_enriched_sector.csv"
    
    optimizer = StrategyOptimizer(API_KEY, ACCESS_TOKEN)
    
    # Define backtest period
    END_DATE = datetime.now()
    START_DATE = END_DATE - timedelta(days=730)  # 2 years
    
    # Run optimization
    print("\n🚀 Starting parameter optimization...")
    print("⏱️  This will take 30-60 minutes depending on data and symbols")
    print("☕ Grab a coffee and relax!\n")
    
    results_df = optimizer.run_optimization(INPUT_CSV, START_DATE, END_DATE)
    
    # Optional: Test best parameters across different periods
    if results_df is not None and len(results_df) > 0:
        # Get best risk-adjusted parameters
        best_params = results_df.loc[results_df['Risk_Adjusted_Return'].idxmax()].to_dict()
        
        # Define periods for robustness testing
        periods = {
            'Last_6_Months': (datetime.now() - timedelta(days=180), datetime.now()),
            'Last_Year': (datetime.now() - timedelta(days=365), datetime.now()),
            'Year_2023': (datetime(2023, 1, 1), datetime(2023, 12, 31)),
            'Year_2024': (datetime(2024, 1, 1), datetime(2024, 12, 31))
        }
        
        print("\n\n🔍 Testing robustness across different periods...")
        optimizer.compare_periods(INPUT_CSV, best_params, periods)
    
    print("\n✅ Optimization complete!")

