import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
import logging
from typing import Dict, List, Tuple, Optional
import warnings
import argparse
import time
import pickle
import os
from ratelimit import limits, sleep_and_retry
warnings.filterwarnings('ignore')

# Rate limit configurations
HISTORICAL_RATE_LIMIT = 2  # 2 requests/second (more conservative)
QUOTE_RATE_LIMIT = 5       # 5 requests/second (more conservative)
ONE_SECOND = 1

# Session cache for data
session_cache = {}

def get_cached_data(key):
    """Retrieves data from session cache if available. Returns a copy."""
    cached_item = session_cache.get(key)
    if cached_item is not None:
        return cached_item.copy() if isinstance(cached_item, pd.DataFrame) else cached_item
    return None

def set_cached_data(key, data):
    """Adds/updates data in the session cache."""
    data_to_cache = data.copy() if isinstance(data, pd.DataFrame) else data
    session_cache[key] = data_to_cache

class StockRegimeAnalyzer:
    """
    Stock Regime Framework - Analyzes market regimes using multiple technical layers
    """
    
    # Trading style parameter configurations
    TRADING_STYLES = {
        'swing_trade': {
            'name': 'Swing Trade (1-3 weeks)',
            'data_days': 120,  # 24 weeks (need enough for 15-week MA)
            'ma_periods': [5, 10, 20],  # Standard periods: 5-week, 10-week, 20-week
            'rsi_period': 7,
            'roc_period': 3,
            'atr_period': 7,
            'bb_period': 10,
            'volume_period': 3,
            'range_period': 5,
            'breakout_threshold': 1.5,
            'volume_surge_threshold': 0.25,  # 25%
            'range_expansion_threshold': 0.15,  # 15%
            'conviction_thresholds': {'high': 1.8, 'medium': 1.2, 'low': 0.8},
            'regime_thresholds': {'uptrend': 2.0, 'downtrend': -2.0, 'breakout_emerging': 1.5},
            'scoring_weights': {'momentum': 0.4, 'trend': 0.3, 'breakout': 0.2, 'relative': 0.1}
        },
        'positional_trade': {
            'name': 'Positional Trade (3-8 weeks)',
            'data_days': 180,  # 36 weeks (need enough for 25-week MA)
            'ma_periods': [10, 20, 50],  # Standard periods: 10-week, 20-week, 50-week
            'rsi_period': 10,
            'roc_period': 5,
            'atr_period': 10,
            'bb_period': 15,
            'volume_period': 5,
            'range_period': 8,
            'breakout_threshold': 1.8,
            'volume_surge_threshold': 0.30,  # 30%
            'range_expansion_threshold': 0.18,  # 18%
            'conviction_thresholds': {'high': 2.2, 'medium': 1.5, 'low': 1.0},
            'regime_thresholds': {'uptrend': 2.5, 'downtrend': -2.5, 'breakout_emerging': 2.0},
            'scoring_weights': {'momentum': 0.35, 'trend': 0.3, 'breakout': 0.2, 'relative': 0.15}
        },
        'short_term': {
            'name': 'Short Term (3-13 weeks)',
            'data_days': 240,  # 48 weeks (need enough for 34-week MA)
            'ma_periods': [10, 21, 50],  # Standard periods: 10-week, 21-week, 50-week
            'rsi_period': 14,
            'roc_period': 5,
            'atr_period': 14,
            'bb_period': 20,
            'volume_period': 8,
            'range_period': 12,
            'breakout_threshold': 2.0,
            'volume_surge_threshold': 0.30,  # 30%
            'range_expansion_threshold': 0.20,  # 20%
            'conviction_thresholds': {'high': 2.5, 'medium': 1.5, 'low': 1.0},
            'regime_thresholds': {'uptrend': 3.0, 'downtrend': -3.0, 'breakout_emerging': 2.0},
            'scoring_weights': {'momentum': 0.3, 'trend': 0.3, 'breakout': 0.2, 'relative': 0.2}
        },
        'long_term': {
            'name': 'Long Term (up to 9 months)',
            'data_days': 450,  # 90 weeks (need enough for 60-week MA)
            'ma_periods': [20, 50, 100], # Standard long-term periods: 20-week, 50-week, 100-week
            'rsi_period': 14,
            'roc_period': 5,
            'atr_period': 14,
            'bb_period': 20,
            'volume_period': 20,
            'range_period': 20,
            'breakout_threshold': 2.5,
            'volume_surge_threshold': 0.30,  # 30%
            'range_expansion_threshold': 0.20,  # 20%
            'conviction_thresholds': {'high': 2.5, 'medium': 1.5, 'low': 1.0},
            'regime_thresholds': {'uptrend': 3.0, 'downtrend': -3.0, 'breakout_emerging': 2.0},
            'scoring_weights': {'momentum': 0.25, 'trend': 0.3, 'breakout': 0.2, 'relative': 0.25}
        },
        # NEW: Ultra Short-Term for day traders extending to swing
        'ultra_short': {
            'name': 'Ultra Short (5-20 days)',
            'data_days': 100,
            'ma_periods': [5, 10, 20],
            'rsi_period': 7,
            'roc_period': 3,
            'atr_period': 7,
            'bb_period': 10,
            'volume_period': 3,
            'range_period': 5,
            'breakout_threshold': 1.8,
            'volume_surge_threshold': 0.30,  # Keep current - works well
            'range_expansion_threshold': 0.15,  # Keep current - works well
            'conviction_thresholds': {'high': 2.0, 'medium': 1.3, 'low': 0.8},
            'regime_thresholds': {'uptrend': 2.2, 'downtrend': -2.2, 'breakout_emerging': 1.8},
            'scoring_weights': {'momentum': 0.45, 'trend': 0.25, 'breakout': 0.20, 'relative': 0.10}
        }
    }
    
    # RSI thresholds based on trading style
    RSI_THRESHOLDS = {
        'ultra_short': {'overbought': 75, 'oversold': 25, 'bullish': 55, 'bearish': 45},
        'swing_trade': {'overbought': 70, 'oversold': 30, 'bullish': 60, 'bearish': 40},
        'positional_trade': {'overbought': 70, 'oversold': 30, 'bullish': 60, 'bearish': 40},
        'short_term': {'overbought': 65, 'oversold': 35, 'bullish': 55, 'bearish': 45},
        'long_term': {'overbought': 60, 'oversold': 40, 'bullish': 52, 'bearish': 48}
    }
    
    # ROC thresholds based on trading style
    ROC_THRESHOLDS = {
        'ultra_short': {'strong_bullish': 5, 'bullish': 2, 'bearish': -2, 'strong_bearish': -5},
        'swing_trade': {'strong_bullish': 4, 'bullish': 1.5, 'bearish': -1.5, 'strong_bearish': -4},
        'positional_trade': {'strong_bullish': 3, 'bullish': 1, 'bearish': -1, 'strong_bearish': -3},
        'short_term': {'strong_bullish': 2.5, 'bullish': 0.8, 'bearish': -0.8, 'strong_bearish': -2.5},
        'long_term': {'strong_bullish': 2, 'bullish': 0.5, 'bearish': -0.5, 'strong_bearish': -2}
    }
    
    # Market regime calibration
    MARKET_CALIBRATION = {
        'bull_market': {
            'regime_multiplier': 0.8,  # Lower thresholds in bull markets
            'breakout_multiplier': 0.9
        },
        'bear_market': {
            'regime_multiplier': 1.2,  # Higher thresholds in bear markets
            'breakout_multiplier': 1.3
        },
        'neutral_market': {
            'regime_multiplier': 1.0,  # Standard thresholds
            'breakout_multiplier': 1.0
        }
    }
    
    def __init__(self, api_key: str, access_token: str, trading_style: str = 'short_term'):
        """
        Initialize with Kite Connect credentials and trading style
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.trading_style = trading_style
        
        # Validate trading style
        if trading_style not in self.TRADING_STYLES:
            raise ValueError(f"Invalid trading style. Choose from: {list(self.TRADING_STYLES.keys())}")
        
        # Load parameters for selected trading style
        self.params = self.TRADING_STYLES[trading_style]
        
        # Set regime thresholds
        self.UPTREND_THRESHOLD = self.params['regime_thresholds']['uptrend']
        self.DOWNTREND_THRESHOLD = self.params['regime_thresholds']['downtrend']
        self.BREAKOUT_EMERGING_THRESHOLD = self.params['regime_thresholds']['breakout_emerging']
        self.STRONG_CONVICTION = self.params['conviction_thresholds']['high']
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
        # Load instrument cache
        self.instrument_map = self._load_instruments()
        
        self.logger.info(f"Initialized for {self.params['name']} trading style")
    
    def _load_instruments(self):
        """Load and cache instrument tokens to avoid repeated API calls"""
        if not self.kite:
            self.logger.error("Kite object not initialized. Cannot load instruments.")
            return {}
        
        self.logger.info("Loading instrument tokens from Kite API...")
        try:
            instruments = self.kite.instruments("NSE")
            instrument_map = {}
            
            for instrument in instruments:
                if (instrument and 
                    instrument.get('exchange') == 'NSE' and 
                    instrument.get('segment') == 'NSE' and 
                    instrument.get('instrument_type') == 'EQ'):
                    instrument_map[instrument['tradingsymbol']] = instrument['instrument_token']
            
            self.logger.info(f"Loaded {len(instrument_map)} NSE equity instruments")
            return instrument_map
            
        except Exception as e:
            self.logger.error(f"Failed to load instruments: {e}")
            return {}
    
    @sleep_and_retry
    @limits(calls=HISTORICAL_RATE_LIMIT, period=ONE_SECOND)
    def fetch_data(self, symbol: str, days: int = None) -> pd.DataFrame:
        """
        Fetch OHLCV data from Kite Connect with caching and rate limiting
        """
        try:
            # Use trading style specific data days if not specified
            if days is None:
                days = self.params['data_days']
                
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            # Create cache key
            cache_key = f"{symbol}_weekly_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}"
            
            # Check cache first
            cached_data = get_cached_data(cache_key)
            if cached_data is not None:
                self.logger.debug(f"Cache hit for {symbol}")
                return cached_data
            
            # Get instrument token from cache
            instrument_token = self.instrument_map.get(symbol)
            if not instrument_token:
                # Try symbol variations
                symbol_variations = {
                    "NIFTY50": "NIFTY 50",
                    "HDFC": "HDFCBANK",
                    "NIFTY": "NIFTY 50",
                    "BANKNIFTY": "NIFTY BANK",
                    "FINNIFTY": "NIFTY FIN SERVICE"
                }
                
                if symbol in symbol_variations:
                    instrument_token = self.instrument_map.get(symbol_variations[symbol])
                
                if not instrument_token:
                    raise ValueError(f"Symbol {symbol} not found in instrument cache")
            
            # Fetch weekly data
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=start_date,
                to_date=end_date,
                interval="week"
            )
            
            # Add small delay to be more conservative with rate limiting
            time.sleep(0.1)
            
            if not data:
                self.logger.warning(f"No data returned for {symbol}")
                return pd.DataFrame()
            
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            
            result_df = df[['open', 'high', 'low', 'close', 'volume']]
            
            # Cache the result
            set_cached_data(cache_key, result_df)
            
            return result_df
            
        except ValueError as e:
            self.logger.error(f"Symbol not found: {symbol} - {e}")
            return pd.DataFrame()
        except Exception as e:
            self.logger.error(f"Error fetching data for {symbol}: {e}")
            return pd.DataFrame()
    
    
    def calculate_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate all technical indicators for the analysis
        """
        if df.empty:
            return df
        
        # Moving Averages (using trading style specific periods)
        ma_periods = self.params['ma_periods']
        df[f'MA_{ma_periods[0]}'] = df['close'].rolling(window=ma_periods[0]).mean()
        df[f'MA_{ma_periods[1]}'] = df['close'].rolling(window=ma_periods[1]).mean()
        df[f'MA_{ma_periods[2]}'] = df['close'].rolling(window=ma_periods[2]).mean()
        
        # VWAP (Volume Weighted Average Price)
        df['VWAP'] = (df['close'] * df['volume']).cumsum() / df['volume'].cumsum()
        
        # RSI (using trading style specific period)
        df['RSI'] = self._calculate_rsi(df['close'], self.params['rsi_period'])
        
        # Rate of Change (using trading style specific period)
        df['ROC'] = df['close'].pct_change(periods=self.params['roc_period']) * 100
        
        # On Balance Volume
        df['OBV'] = self._calculate_obv(df['close'], df['volume'])
        
        # Average True Range (using trading style specific period)
        df['ATR'] = self._calculate_atr(df, self.params['atr_period'])
        df['ATR_percentile'] = df['ATR'].rolling(window=self.params['atr_period']).apply(
            lambda x: (x.iloc[-1] - x.min()) / (x.max() - x.min()) * 100
        )
        
        # Bollinger Bands (using trading style specific period)
        bb_upper, bb_lower, bb_middle = self._calculate_bollinger_bands(df['close'], self.params['bb_period'])
        df['BB_upper'] = bb_upper
        df['BB_lower'] = bb_lower
        df['BB_middle'] = bb_middle
        df['BB_squeeze'] = (bb_upper - bb_lower) / bb_middle < 0.1  # Squeeze condition
        
        # 52-week high/low
        df['52W_high'] = df['high'].rolling(window=52).max()
        df['52W_low'] = df['low'].rolling(window=52).min()
        df['price_vs_52W'] = (df['close'] - df['52W_low']) / (df['52W_high'] - df['52W_low'])
        
        return df
    
    def _calculate_rsi(self, prices: pd.Series, window: int = 14) -> pd.Series:
        """Calculate RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))
    
    def _calculate_obv(self, prices: pd.Series, volumes: pd.Series) -> pd.Series:
        """Calculate On Balance Volume"""
        obv = pd.Series(index=prices.index, dtype=float)
        obv.iloc[0] = volumes.iloc[0]
        
        for i in range(1, len(prices)):
            if prices.iloc[i] > prices.iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] + volumes.iloc[i]
            elif prices.iloc[i] < prices.iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] - volumes.iloc[i]
            else:
                obv.iloc[i] = obv.iloc[i-1]
        
        return obv
    
    def _calculate_atr(self, df: pd.DataFrame, window: int = 14) -> pd.Series:
        """Calculate Average True Range"""
        high_low = df['high'] - df['low']
        high_close_prev = np.abs(df['high'] - df['close'].shift())
        low_close_prev = np.abs(df['low'] - df['close'].shift())
        
        true_range = pd.concat([high_low, high_close_prev, low_close_prev], axis=1).max(axis=1)
        return true_range.rolling(window=window).mean()
    
    def _calculate_bollinger_bands(self, prices: pd.Series, window: int = 20, num_std: float = 2):
        """Calculate Bollinger Bands"""
        rolling_mean = prices.rolling(window=window).mean()
        rolling_std = prices.rolling(window=window).std()
        
        upper_band = rolling_mean + (rolling_std * num_std)
        lower_band = rolling_mean - (rolling_std * num_std)
        
        return upper_band, lower_band, rolling_mean
    
    def analyze_trend_layer(self, df: pd.DataFrame) -> Dict[str, int]:
        """
        Core Technical Layer Analysis
        Returns signals: +1 bullish, -1 bearish, 0 neutral
        """
        ma_periods = self.params['ma_periods']
        if len(df) < ma_periods[2]:  # Need enough data for longest MA
            self.logger.debug(f"Insufficient data: {len(df)} rows, need {ma_periods[2]} for MA analysis")
            return {'trend_score': 0, 'momentum_score': 0, 'consolidation_score': 0}
        
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        
        signals = {}
        
        # Trend Analysis
        trend_signals = []
        
        # MA Slope and Position (using first MA period)
        if latest[f'MA_{ma_periods[0]}'] > prev[f'MA_{ma_periods[0]}']:
            trend_signals.append(1)
        elif latest[f'MA_{ma_periods[0]}'] < prev[f'MA_{ma_periods[0]}']:
            trend_signals.append(-1)
        else:
            trend_signals.append(0)
        
        # MA Crossovers (using trading style specific MA periods)
        if latest['close'] > latest[f'MA_{ma_periods[0]}'] > latest[f'MA_{ma_periods[1]}'] > latest[f'MA_{ma_periods[2]}']:
            trend_signals.append(1)
        elif latest['close'] < latest[f'MA_{ma_periods[0]}'] < latest[f'MA_{ma_periods[1]}'] < latest[f'MA_{ma_periods[2]}']:
            trend_signals.append(-1)
        else:
            trend_signals.append(0)
        
        # Price vs VWAP
        if latest['close'] > latest['VWAP']:
            trend_signals.append(1)
        elif latest['close'] < latest['VWAP']:
            trend_signals.append(-1)
        else:
            trend_signals.append(0)
        
        signals['trend_score'] = sum(trend_signals)
        
        # Momentum Analysis
        momentum_signals = []
        
        # RSI (using trading style specific thresholds)
        rsi_thresholds = self.RSI_THRESHOLDS.get(self.trading_style, self.RSI_THRESHOLDS['short_term'])
        if latest['RSI'] > rsi_thresholds['bullish']:
            momentum_signals.append(1)
        elif latest['RSI'] < rsi_thresholds['bearish']:
            momentum_signals.append(-1)
        else:
            momentum_signals.append(0)
        
        # ROC (using trading style specific thresholds)
        roc_thresholds = self.ROC_THRESHOLDS.get(self.trading_style, self.ROC_THRESHOLDS['short_term'])
        if latest['ROC'] > roc_thresholds['bullish']:
            momentum_signals.append(1)
        elif latest['ROC'] < roc_thresholds['bearish']:
            momentum_signals.append(-1)
        else:
            momentum_signals.append(0)
        
        # 52-week position
        if latest['price_vs_52W'] > 0.8:
            momentum_signals.append(1)
        elif latest['price_vs_52W'] < 0.2:
            momentum_signals.append(-1)
        else:
            momentum_signals.append(0)
        
        signals['momentum_score'] = sum(momentum_signals)
        
        # Consolidation Analysis
        consolidation_signals = []
        
        # ATR percentile (low volatility = consolidation)
        if latest['ATR_percentile'] < 20:
            consolidation_signals.append(1)  # Consolidating
        elif latest['ATR_percentile'] > 80:
            consolidation_signals.append(-1)  # High volatility, trending
        else:
            consolidation_signals.append(0)
        
        # Bollinger Band Squeeze
        if latest['BB_squeeze']:
            consolidation_signals.append(1)
        else:
            consolidation_signals.append(0)
        
        signals['consolidation_score'] = sum(consolidation_signals)
        
        # Debug output
        self.logger.debug(f"Technical signals: trend={signals['trend_score']}, momentum={signals['momentum_score']}, consolidation={signals['consolidation_score']}")
        
        return signals
    
    def analyze_relative_strength(self, stock_df: pd.DataFrame, benchmark_symbol: str = "NIFTY 50") -> int:
        """
        Relative Strength Analysis vs Benchmark
        """
        try:
            # Check if benchmark symbol exists in instrument cache
            if benchmark_symbol not in self.instrument_map:
                # Try common variations
                benchmark_variations = {
                    "NIFTY 50": "NIFTY50",
                    "NIFTY50": "NIFTY 50",
                    "NIFTY": "NIFTY 50"
                }
                
                for original, variation in benchmark_variations.items():
                    if benchmark_symbol == original and variation in self.instrument_map:
                        benchmark_symbol = variation
                        break
                else:
                    # If still not found, skip relative strength analysis
                    self.logger.debug(f"Benchmark {benchmark_symbol} not found, skipping relative strength analysis")
                    return 0
            
            benchmark_df = self.fetch_data(benchmark_symbol)
            
            if benchmark_df.empty or stock_df.empty:
                return 0
            
            # Align dates
            common_dates = stock_df.index.intersection(benchmark_df.index)
            if len(common_dates) < 10:
                return 0
            
            stock_aligned = stock_df.loc[common_dates]
            benchmark_aligned = benchmark_df.loc[common_dates]
            
            # Calculate relative strength
            stock_returns = stock_aligned['close'].pct_change(periods=5).fillna(0)
            benchmark_returns = benchmark_aligned['close'].pct_change(periods=5).fillna(0)
            
            relative_strength = (stock_returns - benchmark_returns).rolling(window=10).mean().iloc[-1]
            
            if relative_strength > 0.02:  # Outperforming by 2%
                return 1
            elif relative_strength < -0.02:  # Underperforming by 2%
                return -1
            else:
                return 0
                
        except Exception as e:
            self.logger.debug(f"Error in relative strength analysis: {e}")
            return 0
    
    def calculate_regime_score(self, symbol: str) -> Dict:
        """
        Calculate overall regime score and classification
        """
        # Fetch data
        df = self.fetch_data(symbol)
        
        if df.empty:
            return {
                'symbol': symbol,
                'regime': 'NO_DATA',
                'score': 0,
                'conviction': 'Low',
                'factors': []
            }
        
        # Calculate indicators
        df = self.calculate_technical_indicators(df)
        
        # Get technical signals
        tech_signals = self.analyze_trend_layer(df)
        
        # Get relative strength
        relative_score = self.analyze_relative_strength(df)
        
        # Get breakout context analysis
        breakout_context = self.analyze_breakout_context(df)
        
        # Calculate weighted score (using trading style specific weights)
        weights = self.params['scoring_weights']
        total_score = (
            tech_signals['trend_score'] * weights['trend'] +
            tech_signals['momentum_score'] * weights['momentum'] +
            tech_signals['consolidation_score'] * 0.1 +
            relative_score * weights['relative'] +
            breakout_context['breakout_score'] * weights['breakout']
        )
        
        # Determine regime
        if total_score >= self.UPTREND_THRESHOLD:
            regime = 'UPTREND'
        elif total_score <= self.DOWNTREND_THRESHOLD:
            regime = 'DOWNTREND'
        elif total_score >= self.BREAKOUT_EMERGING_THRESHOLD and breakout_context['breakout_score'] >= 3:
            regime = 'BREAKOUT_EMERGING'
        else:
            regime = 'CONSOLIDATION'
        
        # Determine conviction (using trading style specific thresholds)
        conviction_thresholds = self.params['conviction_thresholds']
        if abs(total_score) >= conviction_thresholds['high']:
            conviction = 'High'
        elif abs(total_score) >= conviction_thresholds['medium']:
            conviction = 'Medium'
        else:
            conviction = 'Low'
        
        # Build supporting factors
        factors = self._build_supporting_factors(df, tech_signals, relative_score)
        
        # Add breakout context factors
        factors.extend(breakout_context['breakout_factors'])
        
        return {
            'symbol': symbol,
            'regime': regime,
            'score': round(total_score, 2),
            'conviction': conviction,
            'factors': factors,
            'technical_breakdown': tech_signals,
            'relative_strength': relative_score,
            'breakout_context': breakout_context
        }
    
    def _build_supporting_factors(self, df: pd.DataFrame, tech_signals: Dict, relative_score: int) -> List[str]:
        """
        Build list of supporting factors for transparency
        """
        if df.empty:
            return []
        
        factors = []
        latest = df.iloc[-1]
        ma_periods = self.params['ma_periods']
        
        # Trend factors (using trading style specific MA periods)
        if latest['close'] > latest[f'MA_{ma_periods[1]}']:
            factors.append(f"Price above {ma_periods[1]}-week MA")
        if latest['close'] > latest['VWAP']:
            factors.append("Price above VWAP")
        
        # Momentum factors (using trading style specific thresholds)
        rsi_thresholds = self.RSI_THRESHOLDS.get(self.trading_style, self.RSI_THRESHOLDS['short_term'])
        if latest['RSI'] > rsi_thresholds['bullish']:
            factors.append(f"RSI in bullish zone (>{rsi_thresholds['bullish']})")
        elif latest['RSI'] < rsi_thresholds['bearish']:
            factors.append(f"RSI in bearish zone (<{rsi_thresholds['bearish']})")
        
        if latest['price_vs_52W'] > 0.8:
            factors.append("Near 52-week high")
        elif latest['price_vs_52W'] < 0.2:
            factors.append("Near 52-week low")
        
        # Consolidation factors
        if latest['BB_squeeze']:
            factors.append("Bollinger Band squeeze detected")
        
        if latest['ATR_percentile'] < 20:
            factors.append("Low volatility regime")
        
        # Relative strength
        if relative_score > 0:
            factors.append("Outperforming benchmark")
        elif relative_score < 0:
            factors.append("Underperforming benchmark")
        
        return factors
    
    def detect_range_expansion(self, df: pd.DataFrame) -> bool:
        """
        Detect range expansion vs previous range (trading style specific)
        """
        range_period = self.params['range_period']
        if len(df) < range_period * 2:  # Need at least 2x range period of data
            return False
        
        # Recent range
        recent_high = df['high'].tail(range_period).max()
        recent_low = df['low'].tail(range_period).min()
        recent_range = recent_high - recent_low
        
        # Previous range
        prev_high = df['high'].iloc[-range_period*2:-range_period].max()
        prev_low = df['low'].iloc[-range_period*2:-range_period].min()
        prev_range = prev_high - prev_low
        
        if prev_range == 0:
            return False
        
        expansion_ratio = (recent_range - prev_range) / prev_range
        threshold = self.params['range_expansion_threshold']
        return expansion_ratio >= threshold
    
    def detect_volume_confirmation(self, df: pd.DataFrame) -> bool:
        """
        Detect volume increase during recent moves (trading style specific)
        """
        volume_period = self.params['volume_period']
        if len(df) < volume_period * 2:
            return False
        
        # Recent volume
        recent_volume = df['volume'].tail(volume_period).mean()
        
        # Previous volume
        prev_volume = df['volume'].iloc[-volume_period*2:-volume_period].mean()
        
        if prev_volume == 0:
            return False
        
        volume_increase = (recent_volume - prev_volume) / prev_volume
        threshold = self.params['volume_surge_threshold']
        return volume_increase >= threshold
    
    def detect_ma_divergence(self, df: pd.DataFrame) -> bool:
        """
        Detect when MAs shift from convergence to divergence
        """
        ma_periods = self.params['ma_periods']
        if len(df) < ma_periods[1]:
            return False
        
        # Calculate MA spread (using first two MA periods)
        recent_spread = abs(df[f'MA_{ma_periods[0]}'].iloc[-1] - df[f'MA_{ma_periods[1]}'].iloc[-1])
        prev_spread = abs(df[f'MA_{ma_periods[0]}'].iloc[-10] - df[f'MA_{ma_periods[1]}'].iloc[-10])
        
        # Check if MAs are diverging (spread increasing)
        return recent_spread > prev_spread * 1.2  # 20%+ divergence
    
    def detect_consolidation_breakthrough(self, df: pd.DataFrame) -> bool:
        """
        Detect 2%+ break above/below previous consolidation range
        """
        if len(df) < 20:
            return False
        
        # Define consolidation range (previous 20 weeks)
        consolidation_high = df['high'].iloc[-20:-1].max()
        consolidation_low = df['low'].iloc[-20:-1].min()
        consolidation_mid = (consolidation_high + consolidation_low) / 2
        
        current_price = df['close'].iloc[-1]
        
        # Check for 2%+ break above or below consolidation range
        break_above = current_price > consolidation_high * 1.02
        break_below = current_price < consolidation_low * 0.98
        
        return break_above or break_below
    
    def detect_higher_highs_pattern(self, df: pd.DataFrame) -> bool:
        """
        Confirm if stock is making progressive higher highs after consolidation
        """
        if len(df) < 15:
            return False
        
        # Look for higher highs in recent 10 weeks
        recent_highs = df['high'].tail(10)
        
        # Check if we have at least 2 higher highs
        higher_highs = 0
        for i in range(1, len(recent_highs)):
            if recent_highs.iloc[i] > recent_highs.iloc[i-1]:
                higher_highs += 1
        
        return higher_highs >= 2
    
    def analyze_breakout_context(self, df: pd.DataFrame) -> Dict:
        """
        Comprehensive breakout context analysis
        """
        if df.empty:
            return {'breakout_score': 0, 'breakout_factors': []}
        
        factors = []
        score = 0
        
        # Range expansion (weight: 3)
        if self.detect_range_expansion(df):
            factors.append("🚀 Range expansion detected (20%+ vs previous range)")
            score += 3
        
        # Volume confirmation (weight: 2)
        if self.detect_volume_confirmation(df):
            factors.append("⚡ Volume surge confirmed (30%+ increase)")
            score += 2
        
        # MA divergence (weight: 2)
        if self.detect_ma_divergence(df):
            factors.append("📈 Moving average divergence detected")
            score += 2
        
        # Consolidation breakthrough (weight: 4)
        if self.detect_consolidation_breakthrough(df):
            factors.append("💥 Consolidation range breakthrough (2%+ break)")
            score += 4
        
        # Higher highs pattern (weight: 2)
        if self.detect_higher_highs_pattern(df):
            factors.append("⬆️ Higher highs pattern confirmed")
            score += 2
        
        return {
            'breakout_score': score,
            'breakout_factors': factors
        }
    
    def detect_breakout_candidates(self, df_results: pd.DataFrame) -> List[str]:
        """
        Detect breakout candidates based on new BREAKOUT_EMERGING regime and advanced criteria
        """
        breakout_candidates = []
        
        for _, row in df_results.iterrows():
            # Primary: BREAKOUT_EMERGING regime
            if row['regime'] == 'BREAKOUT_EMERGING':
                breakout_candidates.append(row['symbol'])
            
            # Secondary: High-scoring consolidation with breakout signals
            elif row['regime'] == 'CONSOLIDATION' and row['score'] > 1.5:
                factors = row['factors']
                breakout_signals = [
                    '🚀 Range expansion detected',
                    '⚡ Volume surge confirmed',
                    '💥 Consolidation range breakthrough',
                    '⬆️ Higher highs pattern confirmed'
                ]
                
                if any(signal in str(factors) for signal in breakout_signals):
                    breakout_candidates.append(row['symbol'])
        
        return breakout_candidates
    
    def generate_market_summary(self, df_results: pd.DataFrame) -> Dict:
        """
        Generate overall market sentiment and distribution analysis
        """
        # Basic statistics
        total_stocks = len(df_results)
        avg_score = df_results['score'].mean()
        
        # Regime distribution
        regime_dist = df_results['regime'].value_counts().to_dict()
        
        # Conviction distribution
        conviction_dist = df_results['conviction'].value_counts().to_dict()
        
        # Top and bottom performers
        top_performers = df_results.nlargest(3, 'score')['symbol'].tolist()
        bottom_performers = df_results.nsmallest(3, 'score')['symbol'].tolist()
        
        # Breakout candidates
        breakout_candidates = self.detect_breakout_candidates(df_results)
        
        # Market sentiment
        if avg_score > 1:
            sentiment = "Bullish Consolidation"
        elif avg_score < -1:
            sentiment = "Bearish Consolidation"
        else:
            sentiment = "Neutral Consolidation"
        
        return {
            'total_stocks': total_stocks,
            'avg_score': round(avg_score, 2),
            'sentiment': sentiment,
            'regime_distribution': regime_dist,
            'conviction_distribution': conviction_dist,
            'top_performers': top_performers,
            'bottom_performers': bottom_performers,
            'breakout_candidates': breakout_candidates
        }
    
    def add_regime_ranking(self, df_results: pd.DataFrame) -> pd.DataFrame:
        """
        Add ranking within each regime
        """
        df_results['regime_rank'] = 0
        
        for regime in df_results['regime'].unique():
            regime_mask = df_results['regime'] == regime
            regime_data = df_results[regime_mask].copy()
            regime_data = regime_data.sort_values('score', ascending=False)
            regime_data['regime_rank'] = range(1, len(regime_data) + 1)
            df_results.loc[regime_mask, 'regime_rank'] = regime_data['regime_rank']
        
        return df_results
    
    def scan_multiple_stocks(self, symbols: List[str], batch_size: int = 50) -> pd.DataFrame:
        """
        Scan multiple stocks and return regime analysis with progress tracking
        """
        results = []
        total_symbols = len(symbols)
        successful_count = 0
        failed_count = 0
        
        self.logger.info(f"Starting analysis of {total_symbols} symbols...")
        
        for i, symbol in enumerate(symbols, 1):
            try:
                self.logger.info(f"Analyzing {symbol}... ({i}/{total_symbols})")
                result = self.calculate_regime_score(symbol)
                results.append(result)
                successful_count += 1
                    
                # Progress update and batch delay
                if i % 10 == 0:
                    self.logger.info(f"Progress: {i}/{total_symbols} completed, {successful_count} successful, {failed_count} failed")
                
                # Batch processing delay
                if i % batch_size == 0:
                    self.logger.info(f"Completed batch {i//batch_size}, taking a longer break...")
                    time.sleep(2)  # Longer delay between batches
                
            except Exception as e:
                self.logger.debug(f"Failed to analyze {symbol}: {e}")
                failed_count += 1
                # Add failed result
                results.append({
                    'symbol': symbol,
                    'regime': 'ERROR',
                    'score': 0,
                    'conviction': 'Low',
                    'factors': [f"Error: {str(e)}"],
                    'technical_breakdown': {'trend_score': 0, 'momentum_score': 0, 'consolidation_score': 0},
                    'relative_strength': 0,
                    'breakout_context': {'breakout_score': 0, 'breakout_factors': []}
                })
        
        self.logger.info(f"Analysis complete: {successful_count} successful, {failed_count} failed")
        
        # Convert to DataFrame
        df_results = pd.DataFrame(results)
        
        # Add regime ranking
        df_results = self.add_regime_ranking(df_results)
        
        # Sort by conviction and score
        df_results['abs_score'] = df_results['score'].abs()
        df_results = df_results.sort_values(['conviction', 'abs_score'], 
                                          ascending=[False, False])
        
        return df_results.drop('abs_score', axis=1)

def read_symbols_from_csv(csv_file: str, symbol_column: str = 'Symbol', max_symbols: int = 50) -> List[str]:
    """
    Read stock symbols from CSV file
    """
    try:
        # Check if file exists
        import os
        if not os.path.exists(csv_file):
            print(f"Warning: CSV file '{csv_file}' not found. Using default symbols.")
            return []
        
        # Read CSV file
        df = pd.read_csv(csv_file)
        
        # Check if symbol column exists
        if symbol_column not in df.columns:
            print(f"Warning: Column '{symbol_column}' not found in CSV. Available columns: {list(df.columns)}")
            return []
        
        # Extract symbols and clean them
        symbols = df[symbol_column].dropna().astype(str).tolist()
        
        # Remove any empty strings or invalid symbols
        symbols = [s.strip() for s in symbols if s.strip() and s.strip() != 'nan']
        
        # Limit to max_symbols (0 means no limit)
        if max_symbols > 0 and len(symbols) > max_symbols:
            symbols = symbols[:max_symbols]
            print(f"Limited to first {max_symbols} symbols from CSV file.")
        elif max_symbols == 0:
            print(f"Loading all {len(symbols)} symbols from CSV file (no limit).")
        
        print(f"Loaded {len(symbols)} symbols from {csv_file}")
        print(f"First 5 symbols: {symbols[:5]}")
        return symbols
        
    except Exception as e:
        print(f"Error reading CSV file '{csv_file}': {e}")
        return []

# Usage Example
def main():
    """
    Example usage of the Stock Regime Framework with command line arguments
    """
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Stock Regime Analysis Scanner - Flexible trading style analysis with CSV symbol support')
    parser.add_argument('--style', '-s', 
                       choices=['ultra_short', 'swing_trade', 'positional_trade', 'short_term', 'long_term'],
                       default='short_term',
                       help='Trading style: ultra_short (5-20 days), swing_trade (1-3 weeks), positional_trade (3-8 weeks), short_term (2-12 weeks), long_term (3-12 months)')
    parser.add_argument('--symbols', '-st', nargs='+', 
                       help='List of stock symbols to analyze (overrides CSV file)')
    parser.add_argument('--csv-file', '-csv', 
                       default='data/MCAP-great2500.csv',
                       help='CSV file containing stock symbols (default: data/MCAP-great2500.csv)')
    parser.add_argument('--symbol-column', '-col', 
                       default='Symbol',
                       help='Column name containing symbols in CSV (default: Symbol)')
    parser.add_argument('--max-symbols', '-max', type=int, 
                       default=100,
                       help='Maximum number of symbols to analyze from CSV (default: 100, use 0 for no limit)')
    parser.add_argument('--batch-size', '-batch', type=int, 
                       default=50,
                       help='Process symbols in batches with delays (default: 50)')
    
    args = parser.parse_args()
    
    # Initialize (replace with your actual API credentials)
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "TYwf95Z3yAqnA1aNcmfZkQ8x8MgjGylv"
    
    analyzer = StockRegimeAnalyzer(API_KEY, ACCESS_TOKEN, args.style)
    
    # Define your stock universe (using command line args, CSV file, or default)
    if args.symbols:
        stock_symbols = args.symbols
        print(f"Using {len(stock_symbols)} symbols from command line arguments")
    else:
        # Try to read from CSV file first
        stock_symbols = read_symbols_from_csv(args.csv_file, args.symbol_column, args.max_symbols)
        
        # If CSV reading failed or returned empty, use default symbols
        if not stock_symbols:
            print("Using default stock universe...")
            stock_symbols = [
                "M&MFIN","MAITHANALL","MAHABANK","PNB","CIEINDIA","IOC","KOTAKBANK","SBIN","CENTRALBK","MTARTECH","SBCL","SCHAEFFLER","HAPPYFORGE","JSWINFRA","LT","KNRCON","BALKRISIND","KIRLOSIND","NETWEB","AVANTEL","CENTUM","SUBROS","PARAGMILK","ABCAPITAL","JMFINANCIL","LUMAXTECH","ASKAUTOLTD","TI","FEDFINA","GABRIEL","HLEGLAS","PROTEAN","TIMETECHNO","WELCORP","WELSPUNLIV"
            ]
    
    # Run the scan
    print(f"Starting Stock Regime Analysis for {analyzer.params['name']}...")
    print(f"Trading Style: {args.style}")
    print(f"Analyzing {len(stock_symbols)} stocks in batches of {args.batch_size}...")
    results = analyzer.scan_multiple_stocks(stock_symbols, args.batch_size)
    
    # Generate market summary
    market_summary = analyzer.generate_market_summary(results)
    
    # Display market summary
    print("\n" + "="*80)
    print("MARKET SUMMARY")
    print("="*80)
    print(f"Total Stocks Analyzed: {market_summary['total_stocks']}")
    print(f"Market Sentiment: {market_summary['sentiment']} (Avg Score: {market_summary['avg_score']})")
    print(f"Regime Distribution: {market_summary['regime_distribution']}")
    print(f"Top Performers: {', '.join(market_summary['top_performers'])}")
    print(f"Bottom Performers: {', '.join(market_summary['bottom_performers'])}")
    if market_summary['breakout_candidates']:
        print(f"⚡ Breakout Candidates: {', '.join(market_summary['breakout_candidates'])}")
    print("="*80)
    
    # Display detailed results
    print("\nDETAILED STOCK ANALYSIS")
    print("="*80)
    
    for _, row in results.iterrows():
        rank_info = f" (Rank #{int(row['regime_rank'])} in {row['regime']})" if 'regime_rank' in row else ""
        print(f"\nSymbol: {row['symbol']}{rank_info}")
        print(f"Regime: {row['regime']} (Score: {row['score']})")
        print(f"Conviction: {row['conviction']}")
        print("Supporting Factors:")
        for factor in row['factors']:
            print(f"  • {factor}")
        print("-" * 40)
    
    # Trading insights
    print("\n" + "="*80)
    print("🎯 TRADING OPPORTUNITIES")
    print("="*80)
    
    # Breakout candidates analysis
    if market_summary['breakout_candidates']:
        print("🚀 BREAKOUT CANDIDATES:")
        for symbol in market_summary['breakout_candidates']:
            stock_data = results[results['symbol'] == symbol].iloc[0]
            print(f"  • {symbol}: {stock_data['regime']} (Score: {stock_data['score']})")
            print(f"    Key factors: {', '.join(stock_data['factors'][:3])}")
    
    # Bearish candidates
    bearish_stocks = results[results['score'] < -0.5]
    if not bearish_stocks.empty:
        print("\n⚠️  AVOID/SHORT CANDIDATES:")
        for _, row in bearish_stocks.iterrows():
            print(f"  • {row['symbol']}: {row['regime']} (Score: {row['score']})")
            print(f"    Key factors: {', '.join(row['factors'][:3])}")
    
    # Market context
    print(f"\n📊 MARKET CONTEXT:")
    print(f"  • Market appears to be in a 'coiling' phase with low volatility")
    print(f"  • {len(market_summary['breakout_candidates'])} stocks showing breakout potential")
    print(f"  • Relative strength clearly differentiating winners from losers")
    print(f"  • Average conviction: {market_summary['conviction_distribution']}")
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results.to_csv(f"regime_analysis_{timestamp}.csv", index=False)
    
    # Save market summary
    summary_df = pd.DataFrame([market_summary])
    summary_df.to_csv(f"market_summary_{timestamp}.csv", index=False)
    
    # Cache statistics
    print(f"\nCache Statistics:")
    print(f"  • Session cache contained {len(session_cache)} items")
    print(f"  • Instrument cache contained {len(analyzer.instrument_map)} symbols")
    
    print(f"\nResults saved to CSV files.")

if __name__ == "__main__":
    main()