"""
MultiBeggar (MB) Strategy Backtester
====================================
Longer-term hold strategy based on Monthly + Weekly multi-timeframe analysis
Tests various parameter configurations to find optimal settings for CAGR maximization

Strategy Philosophy:
- Monthly timeframe for trend identification (TRIX, KC, SMA crossovers, Bearish Fractal breakouts)
- Weekly timeframe for entry timing (RSI, Volume, Fractal patterns)
- Long hold periods (multibagger approach - weeks to months)
- Multiple exit strategies tested (TRIX deterioration, fractal breaks, trailing stops)

Parameter Testing Focus:
1. Monthly TRIX thresholds (0.5, 1.0, 1.5, 2.0)
2. KC distance thresholds (0.5%, 1.0%, 2.0%)
3. Weekly RSI thresholds (60, 65, 70, 75)
4. Weekly volume ratio (0.8, 1.0, 1.2)
5. Entry conditions (3/6, 4/6, 5/6 required)
6. Exit strategies (TRIX flip, fractal break, trailing stop)
7. Position sizing (equal weight, volatility adjusted, conviction-based)

Author: Quant Strategy System
Date: 2025-10-23
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import warnings
import time
import json
import os
import pickle
from typing import Dict, List, Optional, Tuple
import matplotlib.pyplot as plt
import pandas_ta as ta
import logging
from itertools import product

warnings.filterwarnings('ignore')

# =============================================================================
# LOGGING SETUP
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('mb_backtest.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# =============================================================================
# CONFIGURATION SECTION
# =============================================================================

# API Configuration
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "RcFSX2nfdWmuiF02bjuO1gUdSEMnVF8z"

# Backtest Period
BACKTEST_START_DATE = "2022-01-01"      # Start date for backtest
BACKTEST_END_DATE = "2025-10-23"        # End date for backtest
REBALANCE_FREQUENCY = 'monthly'         # How often to check for new signals

# Portfolio Configuration
PORTFOLIO_SIZE = 10                     # Maximum number of positions
INITIAL_CAPITAL = 2000000               # Starting capital (Rs.20 Lakhs)
POSITION_SIZING_METHOD = 'equal_weight' # 'equal_weight', 'volatility_adjusted', 'conviction_based'
MAX_POSITION_SIZE_PCT = 0.15            # Maximum 15% per position

# Transaction Costs (Realistic - same as RRG)
TOTAL_COST_PER_TRADE = 0.01            # 1.0% total per round trip (buy + sell)

# =============================================================================
# PARAMETER TESTING GRID
# =============================================================================
# Define parameter ranges to test for optimization

# Monthly Filter Parameters
MONTHLY_PARAMS = {
    'trix_threshold': [0.5, 1.0, 1.5, 2.0],         # Lower = more signals
    'kc_distance_threshold': [0.5, 1.0, 2.0],       # Distance from KC Middle (%)
    'kc_slope_required': [True, False],             # Require positive KC slope?
    'trix_momentum_required': [True, False],        # Require positive TRIX momentum?
    'bearish_fractal_bonus': [True, False],         # Give bonus for BF breakout?
}

# Weekly Filter Parameters
WEEKLY_PARAMS = {
    'rsi_threshold': [60, 65, 70, 75],              # RSI upper limit
    'volume_ratio_threshold': [0.8, 1.0, 1.2],      # Minimum volume ratio
    'atr_percent_threshold': [6.0, 8.0, 10.0],      # Maximum ATR % (volatility)
    'entry_conditions_required': [3, 4, 5],         # Out of 6 conditions
    'fractal_strength_required': [True, False],     # Require fractal breakout?
}

# Exit Strategy Parameters
EXIT_PARAMS = {
    'exit_strategy': [
        'trix_deterioration',       # Exit when TRIX flips negative
        'fractal_break',            # Exit when bearish fractal forms
        'trailing_stop',            # Trailing stop loss
        'hybrid'                    # Combination of signals
    ],
    'trailing_stop_pct': [0.10, 0.15, 0.20],        # Trailing stop % (from peak)
    'hold_period_min': [4, 8, 12],                  # Minimum hold period (weeks)
    'hold_period_max': [26, 39, 52],                # Maximum hold period (weeks)
}

# Position Sizing Parameters
SIZING_PARAMS = {
    'conviction_multiplier': [1.0, 1.5, 2.0],       # Boost size for high conviction
    'volatility_target': [0.02, 0.03, 0.04],        # Target daily volatility
}

# =============================================================================
# DEFAULT CONFIGURATION (Starting Point)
# =============================================================================
DEFAULT_CONFIG = {
    # Monthly
    'trix_threshold': 1.5,
    'kc_distance_threshold': 0.5,
    'kc_slope_required': True,
    'trix_momentum_required': True,
    'bearish_fractal_bonus': True,
    
    # Weekly
    'rsi_threshold': 70,
    'volume_ratio_threshold': 0.8,
    'atr_percent_threshold': 8.0,
    'entry_conditions_required': 4,
    'fractal_strength_required': True,
    
    # Exit
    'exit_strategy': 'hybrid',
    'trailing_stop_pct': 0.15,
    'hold_period_min': 4,
    'hold_period_max': 52,
    
    # Sizing
    'conviction_multiplier': 1.5,
    'volatility_target': 0.03,
}

# Benchmark
BENCHMARK_INDEX = 'NIFTY 500'

# Data Configuration
SYMBOLS_CSV = 'data/sector_marketcap_great8000.csv'
CACHE_DIR = 'cache/mb_backtest'
OUTPUT_DIR = 'mb_backtest_results'

# Create directories if they don't exist
for dir_path in [CACHE_DIR, OUTPUT_DIR]:
    os.makedirs(dir_path, exist_ok=True)

# =============================================================================
# TESTING MODES
# =============================================================================
# Control which tests to run
RUN_PARAMETER_SWEEP = True              # Test all parameter combinations
RUN_QUICK_TEST = False                  # Quick test with default config
RUN_SENSITIVITY_ANALYSIS = True         # Test each parameter individually
RUN_MONTE_CARLO = False                 # Random parameter sampling (for large grids)
MONTE_CARLO_RUNS = 100

# Out-of-sample validation
TRAIN_START = "2022-01-01"
TRAIN_END = "2024-01-01"
TEST_START = "2024-01-01"
TEST_END = "2025-10-23"
RUN_OUT_OF_SAMPLE = True

# =============================================================================
# KITE API WRAPPER
# =============================================================================

class KiteDataFetcher:
    """Handles all Kite API interactions with caching"""
    
    def __init__(self, api_key: str, access_token: str):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.instrument_map = self._load_instruments()
        logger.info(f"Kite API initialized. Loaded {len(self.instrument_map)} instruments.")
    
    def _load_instruments(self) -> Dict[str, int]:
        """Load instrument tokens for symbols"""
        try:
            instruments = self.kite.instruments("NSE")
            instrument_map = {}
            for inst in instruments:
                if inst['exchange'] == 'NSE' and inst['segment'] == 'NSE' and inst['instrument_type'] == 'EQ':
                    instrument_map[inst['tradingsymbol']] = inst['instrument_token']
            return instrument_map
        except Exception as e:
            logger.error(f"Error loading instruments: {e}")
            return {}
    
    def get_instrument_token(self, symbol: str) -> Optional[int]:
        """Get instrument token for a symbol"""
        return self.instrument_map.get(symbol)
    
    def fetch_historical_data(self, symbol: str, from_date: datetime, to_date: datetime, 
                             interval: str, use_cache: bool = True) -> pd.DataFrame:
        """
        Fetch historical data with caching
        interval: 'day', 'week', 'month'
        """
        cache_file = os.path.join(CACHE_DIR, f"{symbol}_{interval}_{from_date.date()}_{to_date.date()}.pkl")
        
        # Try cache first
        if use_cache and os.path.exists(cache_file):
            try:
                df = pd.read_pickle(cache_file)
                logger.debug(f"Loaded {symbol} {interval} data from cache")
                return df
            except Exception as e:
                logger.warning(f"Cache read failed for {symbol}: {e}")
        
        # Fetch from API
        instrument_token = self.get_instrument_token(symbol)
        if not instrument_token:
            logger.warning(f"No instrument token for {symbol}")
            return pd.DataFrame()
        
        try:
            time.sleep(0.35)  # Rate limiting
            
            # For monthly data, fetch daily and resample
            if interval == 'month':
                data = self.kite.historical_data(
                    instrument_token,
                    from_date.strftime('%Y-%m-%d'),
                    to_date.strftime('%Y-%m-%d'),
                    'day',
                    continuous=False
                )
                df = pd.DataFrame(data)
                if df.empty:
                    return df
                
                df['date'] = pd.to_datetime(df['date'])
                # Convert to timezone-naive (remove timezone info)
                if df['date'].dt.tz is not None:
                    df['date'] = df['date'].dt.tz_localize(None)
                df = df.set_index('date')
                
                # Resample to month-end
                df_monthly = pd.DataFrame({
                    'open': df['open'].resample('M').first(),
                    'high': df['high'].resample('M').max(),
                    'low': df['low'].resample('M').min(),
                    'close': df['close'].resample('M').last(),
                    'volume': df['volume'].resample('M').sum()
                })
                df_monthly = df_monthly.reset_index()
                # Strip timezone after resample
                if df_monthly['date'].dt.tz is not None:
                    df_monthly['date'] = df_monthly['date'].dt.tz_localize(None)
                df = df_monthly
            
            elif interval == 'week':
                # For weekly, also fetch daily and resample
                data = self.kite.historical_data(
                    instrument_token,
                    from_date.strftime('%Y-%m-%d'),
                    to_date.strftime('%Y-%m-%d'),
                    'day',
                    continuous=False
                )
                df = pd.DataFrame(data)
                if df.empty:
                    return df
                
                df['date'] = pd.to_datetime(df['date'])
                # Convert to timezone-naive (remove timezone info)
                if df['date'].dt.tz is not None:
                    df['date'] = df['date'].dt.tz_localize(None)
                df = df.set_index('date')
                
                # Resample to week-end
                df_weekly = pd.DataFrame({
                    'open': df['open'].resample('W').first(),
                    'high': df['high'].resample('W').max(),
                    'low': df['low'].resample('W').min(),
                    'close': df['close'].resample('W').last(),
                    'volume': df['volume'].resample('W').sum()
                })
                df_weekly = df_weekly.reset_index()
                # Strip timezone after resample
                if df_weekly['date'].dt.tz is not None:
                    df_weekly['date'] = df_weekly['date'].dt.tz_localize(None)
                df = df_weekly
            
            else:
                # Daily or other intervals
                data = self.kite.historical_data(
                    instrument_token,
                    from_date.strftime('%Y-%m-%d'),
                    to_date.strftime('%Y-%m-%d'),
                    interval,
                    continuous=False
                )
                df = pd.DataFrame(data)
                if not df.empty:
                    df['date'] = pd.to_datetime(df['date'])
                    # Convert to timezone-naive (remove timezone info)
                    if df['date'].dt.tz is not None:
                        df['date'] = df['date'].dt.tz_localize(None)
            
            # Save to cache
            if not df.empty and use_cache:
                df.to_pickle(cache_file)
                logger.debug(f"Cached {symbol} {interval} data")
            
            return df
        
        except Exception as e:
            logger.error(f"Error fetching {symbol} {interval} data: {e}")
            return pd.DataFrame()

# =============================================================================
# INDICATOR CALCULATIONS (Same as Scanner)
# =============================================================================

def calculate_monthly_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate monthly timeframe indicators"""
    if df is None or df.empty or len(df) < 30:
        return df
    
    df = df.copy()
    
    # SMAs
    df['sma3'] = ta.sma(df['close'], length=3)
    df['sma10'] = ta.sma(df['close'], length=10)
    
    # TRIX (10-period)
    log_close = np.log(df['close'])
    ema1 = ta.ema(log_close, length=10)
    ema2 = ta.ema(ema1, length=10)
    ema3 = ta.ema(ema2, length=10)
    df['trix'] = 10000 * ema3.diff(1)
    df['trix_signal'] = ta.sma(df['trix'], length=5)
    df['trix_momentum'] = df['trix'].diff(1)
    
    # Keltner Channels
    kc = ta.kc(df['high'], df['low'], df['close'], length=10, scalar=0.5, mamode='ema')
    if kc is not None and not kc.empty:
        # Find KC columns
        kc_cols = [col for col in kc.columns if 'KCL' in col or 'KCB' in col or 'KCU' in col or 'KCM' in col]
        if len(kc_cols) >= 3:
            df['kc_lower'] = kc[kc_cols[0]]
            df['kc_middle'] = kc[kc_cols[1]]
            df['kc_upper'] = kc[kc_cols[2]]
    
    # KC Slope
    df['kc_middle_slope'] = df['kc_middle'].diff(3) / 3
    
    # Distance from KC Middle
    df['distance_from_kc_middle'] = ((df['close'] - df['kc_middle']) / df['kc_middle']) * 100
    
    # Bearish Fractal Analysis
    lows = df['low']
    highs = df['high']
    
    df['bearish_fractal'] = (
        (lows < lows.shift(1)) & (lows < lows.shift(2)) &
        (lows < lows.shift(-1)) & (lows < lows.shift(-2))
    )
    df['bearish_fractal'] = df['bearish_fractal'].fillna(False)
    
    # Bearish Fractal Breakout
    df['last_month_bearish_fractal'] = df['bearish_fractal'].shift(1)
    df['last_month_high'] = highs.shift(1)
    df['bearish_fractal_breakout'] = (
        (df['last_month_bearish_fractal'] == True) &
        (df['close'] > df['last_month_high'])
    )
    
    return df

def calculate_weekly_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Calculate weekly timeframe indicators"""
    if df is None or df.empty or len(df) < 40:
        return df
    
    df = df.copy()
    
    # SMAs
    df['sma3'] = ta.sma(df['close'], length=3)
    df['sma10'] = ta.sma(df['close'], length=10)
    
    # RSI
    df['rsi12'] = ta.rsi(df['close'], length=12)
    df['rsi24'] = ta.rsi(df['close'], length=24)
    
    # TRIX (5-period for weekly)
    log_close = np.log(df['close'])
    ema1 = ta.ema(log_close, length=5)
    ema2 = ta.ema(ema1, length=5)
    ema3 = ta.ema(ema2, length=5)
    df['trix'] = 10000 * ema3.diff(1)
    df['trix_signal'] = ta.sma(df['trix'], length=3)
    
    # ATR
    df['atr'] = ta.atr(df['high'], df['low'], df['close'], length=14)
    df['atr_percent'] = (df['atr'] / df['close']) * 100
    
    # Volume
    df['volume_sma'] = df['volume'].rolling(window=20, min_periods=1).mean()
    df['volume_ratio'] = df['volume'] / df['volume_sma']
    
    # VWAP
    df['vwap'] = (df['close'] * df['volume']).rolling(window=20, min_periods=1).sum() / df['volume'].rolling(window=20, min_periods=1).sum()
    df['price_vs_vwap'] = ((df['close'] - df['vwap']) / df['vwap']) * 100
    
    # Fractal Analysis
    highs = df['high']
    lows = df['low']
    
    # Bullish Fractal
    df['bullish_fractal'] = (
        (highs > highs.shift(1)) & (highs > highs.shift(2)) &
        (highs > highs.shift(-1)) & (highs > highs.shift(-2))
    )
    df['bullish_fractal'] = df['bullish_fractal'].fillna(False)
    
    # Bearish Fractal
    df['bearish_fractal'] = (
        (lows < lows.shift(1)) & (lows < lows.shift(2)) &
        (lows < lows.shift(-1)) & (lows < lows.shift(-2))
    )
    df['bearish_fractal'] = df['bearish_fractal'].fillna(False)
    
    # Fractal counts
    df['bullish_fractal_count'] = df['bullish_fractal'].rolling(window=5, min_periods=1).sum()
    df['bearish_fractal_count'] = df['bearish_fractal'].rolling(window=5, min_periods=1).sum()
    
    # Fractal breakout
    df['recent_bearish_fractal_high'] = df['high'].rolling(window=5, min_periods=1).max().shift(1)
    df['fractal_breakout'] = df['close'] > df['recent_bearish_fractal_high']
    
    return df

# =============================================================================
# SIGNAL GENERATION (Configurable with parameter grid)
# =============================================================================

def generate_monthly_signal(row: pd.Series, config: Dict) -> bool:
    """
    Generate monthly filter signal based on configuration
    Returns True if passes monthly filter
    """
    # Check data availability
    required_cols = ['sma3', 'sma10', 'kc_middle', 'trix', 'kc_middle_slope', 'distance_from_kc_middle']
    if any(pd.isna(row.get(col)) for col in required_cols):
        return False
    
    # 1. SMA3 crosses above KC Middle (or already above)
    sma3_above_kc = row['sma3'] > row['kc_middle']
    
    # 2. TRIX check (not overbought)
    trix_ok = row['trix'] < config['trix_threshold']
    
    # 3. KC Slope check (optional)
    if config['kc_slope_required']:
        kc_slope_ok = row['kc_middle_slope'] > 0
    else:
        kc_slope_ok = True
    
    # 4. Distance check
    distance_ok = row['distance_from_kc_middle'] > config['kc_distance_threshold']
    
    # 5. TRIX Momentum check (optional)
    if config['trix_momentum_required']:
        trix_momentum_ok = row.get('trix_momentum', 0) > -0.5
    else:
        trix_momentum_ok = True
    
    # 6. Bearish Fractal Breakout bonus (optional)
    if config['bearish_fractal_bonus']:
        bf_bonus = row.get('bearish_fractal_breakout', False)
    else:
        bf_bonus = False
    
    # Primary conditions
    primary_pass = sma3_above_kc and trix_ok and kc_slope_ok and distance_ok
    
    # If BF breakout, relax one condition
    if bf_bonus and sma3_above_kc and trix_ok:
        return True
    
    # Otherwise need all primary + momentum
    return primary_pass and trix_momentum_ok

def generate_weekly_signal(row: pd.Series, config: Dict) -> Tuple[bool, int]:
    """
    Generate weekly entry signal based on configuration
    Returns (signal, conditions_met_count)
    """
    # Check data availability
    required_cols = ['close', 'sma3', 'sma10', 'rsi12', 'volume_ratio', 'atr_percent']
    if any(pd.isna(row.get(col)) for col in required_cols):
        return False, 0
    
    conditions_met = 0
    
    # 1. Price momentum (close > sma3 > sma10)
    if row['close'] > row['sma3'] and row['sma3'] > row['sma10']:
        conditions_met += 1
    
    # 2. RSI not overbought
    if 30 <= row['rsi12'] <= config['rsi_threshold']:
        conditions_met += 1
    
    # 3. Volume confirmation
    if row['volume_ratio'] > config['volume_ratio_threshold']:
        conditions_met += 1
    
    # 4. Volatility check
    if row['atr_percent'] < config['atr_percent_threshold']:
        conditions_met += 1
    
    # 5. Fractal strength (optional)
    if config['fractal_strength_required']:
        fractal_strength = (
            row.get('bearish_fractal_count', 0) >= 1 and
            row.get('fractal_breakout', False)
        )
        if fractal_strength:
            conditions_met += 1
    else:
        # If not required, just check fractal breakout
        if row.get('fractal_breakout', False):
            conditions_met += 1
    
    # 6. TRIX check (weekly)
    if pd.notna(row.get('trix')):
        if row['trix'] > -1.0:  # Weekly TRIX threshold
            conditions_met += 1
    
    # Entry signal if enough conditions met
    signal = conditions_met >= config['entry_conditions_required']
    
    return signal, conditions_met

def generate_exit_signal(position: Dict, current_date: datetime, 
                        monthly_data: pd.DataFrame, weekly_data: pd.DataFrame,
                        config: Dict) -> Tuple[bool, str]:
    """
    Generate exit signal based on configuration
    Returns (should_exit, exit_reason)
    """
    # Ensure current_date is timezone-naive (safety check)
    if hasattr(current_date, 'tzinfo') and current_date.tzinfo is not None:
        current_date = current_date.replace(tzinfo=None)
    
    exit_strategy = config['exit_strategy']
    entry_date = position['entry_date']
    entry_price = position['entry_price']
    current_price = position['current_price']
    peak_price = position.get('peak_price', entry_price)
    
    # Calculate hold period
    hold_weeks = (current_date - entry_date).days / 7
    
    # Minimum hold period check
    if hold_weeks < config['hold_period_min']:
        return False, ""
    
    # Maximum hold period check
    if hold_weeks > config['hold_period_max']:
        return True, "Max Hold Period"
    
    # Get current indicators
    monthly_row = monthly_data[monthly_data['date'] <= current_date].iloc[-1] if len(monthly_data) > 0 else None
    weekly_row = weekly_data[weekly_data['date'] <= current_date].iloc[-1] if len(weekly_data) > 0 else None
    
    # Update peak price
    if current_price > peak_price:
        position['peak_price'] = current_price
        peak_price = current_price
    
    # Strategy-specific exits
    if exit_strategy == 'trix_deterioration':
        # Exit if TRIX flips negative and momentum deteriorating
        if monthly_row is not None:
            if (pd.notna(monthly_row.get('trix')) and monthly_row['trix'] < -1.0 and
                pd.notna(monthly_row.get('trix_momentum')) and monthly_row['trix_momentum'] < -0.5):
                return True, "TRIX Deterioration"
    
    elif exit_strategy == 'fractal_break':
        # Exit if bearish fractal forms on monthly
        if monthly_row is not None:
            if monthly_row.get('bearish_fractal', False):
                return True, "Bearish Fractal"
    
    elif exit_strategy == 'trailing_stop':
        # Trailing stop from peak
        drawdown_from_peak = (peak_price - current_price) / peak_price
        if drawdown_from_peak > config['trailing_stop_pct']:
            return True, f"Trailing Stop ({config['trailing_stop_pct']*100:.0f}%)"
    
    elif exit_strategy == 'hybrid':
        # Combination of signals
        # 1. Trailing stop
        drawdown_from_peak = (peak_price - current_price) / peak_price
        if drawdown_from_peak > config['trailing_stop_pct']:
            return True, f"Trailing Stop ({config['trailing_stop_pct']*100:.0f}%)"
        
        # 2. TRIX deterioration (monthly)
        if monthly_row is not None:
            if (pd.notna(monthly_row.get('trix')) and monthly_row['trix'] < -2.0 and
                pd.notna(monthly_row.get('trix_momentum')) and monthly_row['trix_momentum'] < -1.0):
                return True, "TRIX Severe Deterioration"
        
        # 3. Bearish fractal on weekly (faster exit)
        if weekly_row is not None:
            if weekly_row.get('bearish_fractal', False) and drawdown_from_peak > 0.05:
                return True, "Weekly Bearish Fractal + Drawdown"
    
    return False, ""

# =============================================================================
# BACKTESTING ENGINE
# =============================================================================

class MBBacktester:
    """Main backtesting engine for MultiBeggar strategy"""
    
    def __init__(self, config: Dict, data_fetcher: KiteDataFetcher):
        self.config = config
        self.data_fetcher = data_fetcher
        self.capital = INITIAL_CAPITAL
        self.positions = {}  # symbol -> position dict
        self.trade_history = []
        self.equity_curve = []
        self.cash = INITIAL_CAPITAL
        
        logger.info(f"Backtester initialized with config: {config}")
    
    def load_symbols(self) -> List[str]:
        """Load symbols from CSV"""
        try:
            df = pd.read_csv(SYMBOLS_CSV)
            symbols = df['Symbol'].dropna().astype(str).str.strip().unique().tolist()
            logger.info(f"Loaded {len(symbols)} symbols from {SYMBOLS_CSV}")
            return symbols
        except Exception as e:
            logger.error(f"Error loading symbols: {e}")
            return []
    
    def prepare_data(self, symbols: List[str], start_date: datetime, end_date: datetime) -> Dict:
        """
        Prepare all required data for backtesting
        Returns: dict of symbol -> {'monthly': df, 'weekly': df, 'daily': df}
        """
        logger.info(f"Preparing data for {len(symbols)} symbols from {start_date.date()} to {end_date.date()}")
        
        # Fetch with lookback for indicator calculation
        lookback_months = 36  # 3 years for TRIX(10)
        fetch_start = start_date - relativedelta(months=lookback_months)
        
        data_dict = {}
        for i, symbol in enumerate(symbols):
            if i % 50 == 0:
                logger.info(f"Fetching data: {i+1}/{len(symbols)}")
            
            try:
                # Fetch monthly data
                monthly_df = self.data_fetcher.fetch_historical_data(symbol, fetch_start, end_date, 'month')
                if monthly_df.empty or len(monthly_df) < 30:
                    continue
                
                # Fetch weekly data
                weekly_df = self.data_fetcher.fetch_historical_data(symbol, fetch_start, end_date, 'week')
                if weekly_df.empty or len(weekly_df) < 40:
                    continue
                
                # Fetch daily data (for exit monitoring)
                daily_df = self.data_fetcher.fetch_historical_data(symbol, start_date, end_date, 'day')
                if daily_df.empty:
                    continue
                
                # Calculate indicators
                monthly_df = calculate_monthly_indicators(monthly_df)
                weekly_df = calculate_weekly_indicators(weekly_df)
                
                # CRITICAL: Ensure ALL dates are timezone-naive after all processing
                for df_name, df in [('monthly', monthly_df), ('weekly', weekly_df), ('daily', daily_df)]:
                    if df is not None and not df.empty and 'date' in df.columns:
                        if df['date'].dtype.name.startswith('datetime'):
                            if hasattr(df['date'].dtype, 'tz') and df['date'].dt.tz is not None:
                                df['date'] = df['date'].dt.tz_localize(None)
                                logger.debug(f"Stripped timezone from {symbol} {df_name} data")
                
                data_dict[symbol] = {
                    'monthly': monthly_df,
                    'weekly': weekly_df,
                    'daily': daily_df
                }
            
            except Exception as e:
                logger.warning(f"Error preparing data for {symbol}: {e}")
                continue
        
        logger.info(f"Data prepared for {len(data_dict)} symbols")
        return data_dict
    
    def scan_for_signals(self, current_date: datetime, data_dict: Dict) -> List[Tuple[str, float]]:
        """
        Scan all symbols for entry signals at current_date
        Returns list of (symbol, conviction_score) tuples
        """
        signals = []
        
        # Ensure current_date is timezone-naive (safety check)
        if hasattr(current_date, 'tzinfo') and current_date.tzinfo is not None:
            current_date = current_date.replace(tzinfo=None)
        
        for symbol, data in data_dict.items():
            monthly_df = data['monthly']
            weekly_df = data['weekly']
            
            # Get latest data up to current_date
            monthly_row = monthly_df[monthly_df['date'] <= current_date]
            weekly_row = weekly_df[weekly_df['date'] <= current_date]
            
            if monthly_row.empty or weekly_row.empty:
                continue
            
            monthly_row = monthly_row.iloc[-1]
            weekly_row = weekly_row.iloc[-1]
            
            # Generate signals
            monthly_signal = generate_monthly_signal(monthly_row, self.config)
            weekly_signal, conditions_met = generate_weekly_signal(weekly_row, self.config)
            
            if monthly_signal and weekly_signal:
                # Calculate conviction score
                conviction_score = conditions_met  # Simple: use number of conditions met
                signals.append((symbol, conviction_score))
        
        # Sort by conviction score (highest first)
        signals.sort(key=lambda x: x[1], reverse=True)
        
        return signals
    
    def calculate_position_size(self, symbol: str, conviction_score: float, 
                               current_price: float, atr: float) -> float:
        """Calculate position size based on config"""
        method = POSITION_SIZING_METHOD
        available_cash = self.cash
        num_existing_positions = len(self.positions)
        target_positions = PORTFOLIO_SIZE
        
        if method == 'equal_weight':
            # Equal weight across target portfolio size
            base_size = available_cash / (target_positions - num_existing_positions)
            max_size = self.capital * MAX_POSITION_SIZE_PCT
            position_value = min(base_size, max_size)
        
        elif method == 'conviction_based':
            # Adjust by conviction multiplier
            base_size = available_cash / (target_positions - num_existing_positions)
            multiplier = self.config['conviction_multiplier'] if conviction_score >= 5 else 1.0
            position_value = base_size * multiplier
            max_size = self.capital * MAX_POSITION_SIZE_PCT
            position_value = min(position_value, max_size)
        
        elif method == 'volatility_adjusted':
            # Size based on volatility target
            daily_volatility = atr / current_price
            target_vol = self.config['volatility_target']
            vol_multiplier = min(target_vol / daily_volatility, 2.0) if daily_volatility > 0 else 1.0
            base_size = available_cash / (target_positions - num_existing_positions)
            position_value = base_size * vol_multiplier
            max_size = self.capital * MAX_POSITION_SIZE_PCT
            position_value = min(position_value, max_size)
        
        else:
            position_value = available_cash / (target_positions - num_existing_positions)
        
        # Calculate number of shares
        shares = int(position_value / current_price)
        
        return shares
    
    def execute_entry(self, symbol: str, entry_date: datetime, entry_price: float, 
                     shares: int, conviction_score: float):
        """Execute entry trade"""
        position_value = shares * entry_price
        transaction_cost = position_value * TOTAL_COST_PER_TRADE
        total_cost = position_value + transaction_cost
        
        if total_cost > self.cash:
            logger.warning(f"Insufficient cash for {symbol}: need {total_cost:.2f}, have {self.cash:.2f}")
            return
        
        self.cash -= total_cost
        
        self.positions[symbol] = {
            'symbol': symbol,
            'entry_date': entry_date,
            'entry_price': entry_price,
            'shares': shares,
            'conviction_score': conviction_score,
            'current_price': entry_price,
            'peak_price': entry_price,
            'transaction_cost': transaction_cost
        }
        
        logger.debug(f"ENTRY: {symbol} @ {entry_price:.2f} x {shares} shares = {position_value:.2f} (cost: {transaction_cost:.2f})")
    
    def execute_exit(self, symbol: str, exit_date: datetime, exit_price: float, exit_reason: str):
        """Execute exit trade"""
        if symbol not in self.positions:
            return
        
        position = self.positions[symbol]
        shares = position['shares']
        entry_price = position['entry_price']
        entry_date = position['entry_date']
        
        position_value = shares * exit_price
        transaction_cost = position_value * TOTAL_COST_PER_TRADE
        net_proceeds = position_value - transaction_cost
        
        self.cash += net_proceeds
        
        # Record trade
        hold_days = (exit_date - entry_date).days
        pnl = net_proceeds - (shares * entry_price)
        pnl_pct = (exit_price / entry_price - 1) * 100
        
        trade = {
            'symbol': symbol,
            'entry_date': entry_date,
            'exit_date': exit_date,
            'hold_days': hold_days,
            'entry_price': entry_price,
            'exit_price': exit_price,
            'shares': shares,
            'pnl': pnl,
            'pnl_pct': pnl_pct,
            'exit_reason': exit_reason,
            'conviction_score': position['conviction_score']
        }
        self.trade_history.append(trade)
        
        # Remove position
        del self.positions[symbol]
        
        logger.debug(f"EXIT: {symbol} @ {exit_price:.2f} | PnL: {pnl:.2f} ({pnl_pct:.2f}%) | Reason: {exit_reason}")
    
    def update_positions(self, current_date: datetime, data_dict: Dict):
        """Update current prices and check exit conditions"""
        # Ensure current_date is timezone-naive (safety check)
        if hasattr(current_date, 'tzinfo') and current_date.tzinfo is not None:
            current_date = current_date.replace(tzinfo=None)
        
        for symbol in list(self.positions.keys()):
            if symbol not in data_dict:
                continue
            
            # Get current price from daily data
            daily_df = data_dict[symbol]['daily']
            daily_row = daily_df[daily_df['date'] <= current_date]
            
            if daily_row.empty:
                continue
            
            current_price = daily_row.iloc[-1]['close']
            self.positions[symbol]['current_price'] = current_price
            
            # Check exit conditions
            monthly_df = data_dict[symbol]['monthly']
            weekly_df = data_dict[symbol]['weekly']
            
            should_exit, exit_reason = generate_exit_signal(
                self.positions[symbol],
                current_date,
                monthly_df,
                weekly_df,
                self.config
            )
            
            if should_exit:
                self.execute_exit(symbol, current_date, current_price, exit_reason)
    
    def record_equity(self, current_date: datetime):
        """Record current portfolio value"""
        portfolio_value = self.cash
        for position in self.positions.values():
            portfolio_value += position['shares'] * position['current_price']
        
        self.equity_curve.append({
            'date': current_date,
            'equity': portfolio_value,
            'cash': self.cash,
            'num_positions': len(self.positions)
        })
    
    def run_backtest(self, start_date: datetime, end_date: datetime) -> Dict:
        """
        Run full backtest
        Returns performance metrics dict
        """
        logger.info(f"Running backtest from {start_date.date()} to {end_date.date()}")
        
        # Load symbols and prepare data
        symbols = self.load_symbols()
        if not symbols:
            logger.error("No symbols loaded")
            return {}
        
        data_dict = self.prepare_data(symbols, start_date, end_date)
        if not data_dict:
            logger.error("No data prepared")
            return {}
        
        # Generate trading dates (monthly rebalancing)
        current_date = start_date
        trading_dates = []
        while current_date <= end_date:
            trading_dates.append(current_date)
            current_date += relativedelta(months=1)
        
        logger.info(f"Backtesting across {len(trading_dates)} rebalance dates")
        
        # Run backtest
        for i, trade_date in enumerate(trading_dates):
            logger.info(f"\n--- Rebalance {i+1}/{len(trading_dates)}: {trade_date.date()} ---")
            
            # Update existing positions with current prices
            self.update_positions(trade_date, data_dict)
            
            # Scan for new entry signals
            signals = self.scan_for_signals(trade_date, data_dict)
            logger.info(f"Found {len(signals)} entry signals")
            
            # Enter new positions (up to portfolio size limit)
            num_open_slots = PORTFOLIO_SIZE - len(self.positions)
            for symbol, conviction_score in signals[:num_open_slots]:
                if symbol in self.positions:
                    continue  # Already holding
                
                # Get current price and ATR
                daily_df = data_dict[symbol]['daily']
                weekly_df = data_dict[symbol]['weekly']
                
                daily_row = daily_df[daily_df['date'] <= trade_date]
                weekly_row = weekly_df[weekly_df['date'] <= trade_date]
                
                if daily_row.empty or weekly_row.empty:
                    continue
                
                entry_price = daily_row.iloc[-1]['close']
                atr = weekly_row.iloc[-1].get('atr', entry_price * 0.03)
                
                # Calculate position size
                shares = self.calculate_position_size(symbol, conviction_score, entry_price, atr)
                
                if shares > 0:
                    self.execute_entry(symbol, trade_date, entry_price, shares, conviction_score)
            
            # Record equity curve
            self.record_equity(trade_date)
            
            # Log status
            portfolio_value = self.equity_curve[-1]['equity']
            logger.info(f"Portfolio Value: Rs.{portfolio_value:,.0f} | Cash: Rs.{self.cash:,.0f} | Positions: {len(self.positions)}")
        
        # Close all remaining positions at end date
        logger.info("\n--- Closing all positions at backtest end ---")
        for symbol in list(self.positions.keys()):
            if symbol not in data_dict:
                continue
            daily_df = data_dict[symbol]['daily']
            daily_row = daily_df[daily_df['date'] <= end_date]
            if daily_row.empty:
                continue
            exit_price = daily_row.iloc[-1]['close']
            self.execute_exit(symbol, end_date, exit_price, "Backtest End")
        
        # Calculate performance metrics
        metrics = self.calculate_performance_metrics()
        
        return metrics
    
    def calculate_performance_metrics(self) -> Dict:
        """Calculate comprehensive performance metrics"""
        equity_df = pd.DataFrame(self.equity_curve)
        trades_df = pd.DataFrame(self.trade_history)
        
        if equity_df.empty:
            return {}
        
        # Portfolio metrics
        final_equity = equity_df.iloc[-1]['equity']
        total_return = (final_equity / INITIAL_CAPITAL - 1) * 100
        
        # CAGR
        days = (equity_df.iloc[-1]['date'] - equity_df.iloc[0]['date']).days
        years = days / 365.25
        cagr = (pow(final_equity / INITIAL_CAPITAL, 1/years) - 1) * 100 if years > 0 else 0
        
        # Drawdown
        equity_df['cum_max'] = equity_df['equity'].cummax()
        equity_df['drawdown'] = (equity_df['equity'] - equity_df['cum_max']) / equity_df['cum_max']
        max_drawdown = equity_df['drawdown'].min() * 100
        
        # Sharpe Ratio (assuming daily equity curve interpolation)
        equity_df = equity_df.set_index('date')
        equity_daily = equity_df['equity'].resample('D').ffill()
        daily_returns = equity_daily.pct_change().dropna()
        sharpe = daily_returns.mean() / daily_returns.std() * np.sqrt(252) if daily_returns.std() > 0 else 0
        
        # Trade metrics
        if not trades_df.empty:
            num_trades = len(trades_df)
            winning_trades = trades_df[trades_df['pnl'] > 0]
            win_rate = len(winning_trades) / num_trades * 100 if num_trades > 0 else 0
            avg_win = winning_trades['pnl_pct'].mean() if len(winning_trades) > 0 else 0
            avg_loss = trades_df[trades_df['pnl'] <= 0]['pnl_pct'].mean() if len(trades_df[trades_df['pnl'] <= 0]) > 0 else 0
            profit_factor = winning_trades['pnl'].sum() / abs(trades_df[trades_df['pnl'] < 0]['pnl'].sum()) if len(trades_df[trades_df['pnl'] < 0]) > 0 else 0
            avg_hold_days = trades_df['hold_days'].mean()
        else:
            num_trades = 0
            win_rate = 0
            avg_win = 0
            avg_loss = 0
            profit_factor = 0
            avg_hold_days = 0
        
        metrics = {
            'final_equity': final_equity,
            'total_return': total_return,
            'cagr': cagr,
            'max_drawdown': max_drawdown,
            'sharpe_ratio': sharpe,
            'num_trades': num_trades,
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
            'avg_hold_days': avg_hold_days,
        }
        
        return metrics

# =============================================================================
# PARAMETER TESTING FRAMEWORK
# =============================================================================

def generate_parameter_combinations(param_grid: Dict, mode: str = 'full') -> List[Dict]:
    """
    Generate parameter combinations for testing
    mode: 'full' = all combinations, 'sensitivity' = one-at-a-time
    """
    if mode == 'full':
        # Full grid search - all combinations
        keys = list(param_grid.keys())
        values = [param_grid[k] for k in keys]
        combinations = list(product(*values))
        configs = [dict(zip(keys, combo)) for combo in combinations]
        return configs
    
    elif mode == 'sensitivity':
        # One-at-a-time sensitivity analysis
        configs = []
        base_config = {k: v[0] for k, v in param_grid.items()}  # Use first value as base
        
        for param_name in param_grid.keys():
            for param_value in param_grid[param_name]:
                config = base_config.copy()
                config[param_name] = param_value
                configs.append(config)
        
        return configs
    
    elif mode == 'random':
        # Random sampling (for Monte Carlo)
        configs = []
        for _ in range(MONTE_CARLO_RUNS):
            config = {k: np.random.choice(v) for k, v in param_grid.items()}
            configs.append(config)
        return configs
    
    return []

def run_parameter_tests(data_fetcher: KiteDataFetcher):
    """Run comprehensive parameter testing"""
    logger.info("\n" + "="*80)
    logger.info("STARTING PARAMETER TESTING FRAMEWORK")
    logger.info("="*80)
    
    # Combine all parameter grids
    all_params = {}
    all_params.update(MONTHLY_PARAMS)
    all_params.update(WEEKLY_PARAMS)
    all_params.update(EXIT_PARAMS)
    all_params.update(SIZING_PARAMS)
    
    # Generate configurations based on mode
    if RUN_QUICK_TEST:
        logger.info("\n--- Running Quick Test (Default Config) ---")
        configs = [DEFAULT_CONFIG]
    
    elif RUN_SENSITIVITY_ANALYSIS:
        logger.info("\n--- Running Sensitivity Analysis (One-at-a-time) ---")
        configs = generate_parameter_combinations(all_params, mode='sensitivity')
    
    elif RUN_MONTE_CARLO:
        logger.info(f"\n--- Running Monte Carlo ({MONTE_CARLO_RUNS} random combinations) ---")
        configs = generate_parameter_combinations(all_params, mode='random')
    
    else:
        logger.info("\n--- Running Full Parameter Sweep ---")
        configs = generate_parameter_combinations(all_params, mode='full')
    
    logger.info(f"Testing {len(configs)} parameter configurations")
    
    # Run backtests for each configuration
    results = []
    
    for i, config in enumerate(configs):
        logger.info(f"\n{'='*80}")
        logger.info(f"TEST {i+1}/{len(configs)}")
        logger.info(f"Config: {config}")
        logger.info(f"{'='*80}")
        
        try:
            # Run in-sample backtest
            backtester = MBBacktester(config, data_fetcher)
            in_sample_metrics = backtester.run_backtest(
                datetime.strptime(TRAIN_START, '%Y-%m-%d'),
                datetime.strptime(TRAIN_END, '%Y-%m-%d')
            )
            
            # Run out-of-sample backtest if enabled
            if RUN_OUT_OF_SAMPLE:
                oos_backtester = MBBacktester(config, data_fetcher)
                oos_metrics = oos_backtester.run_backtest(
                    datetime.strptime(TEST_START, '%Y-%m-%d'),
                    datetime.strptime(TEST_END, '%Y-%m-%d')
                )
            else:
                oos_metrics = {}
            
            # Store results
            result = {
                'config': config,
                'in_sample': in_sample_metrics,
                'out_of_sample': oos_metrics
            }
            results.append(result)
            
            # Log summary
            logger.info(f"\nIn-Sample: CAGR: {in_sample_metrics.get('cagr', 0):.2f}% | "
                       f"Max DD: {in_sample_metrics.get('max_drawdown', 0):.2f}% | "
                       f"Sharpe: {in_sample_metrics.get('sharpe_ratio', 0):.2f} | "
                       f"Win Rate: {in_sample_metrics.get('win_rate', 0):.2f}%")
            
            if oos_metrics:
                logger.info(f"Out-of-Sample: CAGR: {oos_metrics.get('cagr', 0):.2f}% | "
                           f"Max DD: {oos_metrics.get('max_drawdown', 0):.2f}% | "
                           f"Sharpe: {oos_metrics.get('sharpe_ratio', 0):.2f} | "
                           f"Win Rate: {oos_metrics.get('win_rate', 0):.2f}%")
        
        except Exception as e:
            logger.error(f"Error running test {i+1}: {e}", exc_info=True)
            continue
    
    # Save results
    results_df = pd.DataFrame(results)
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results_file = os.path.join(OUTPUT_DIR, f'parameter_test_results_{timestamp}.pkl')
    results_df.to_pickle(results_file)
    logger.info(f"\nResults saved to {results_file}")
    
    # Generate summary report
    generate_summary_report(results_df, timestamp)
    
    return results_df

def generate_summary_report(results_df: pd.DataFrame, timestamp: str):
    """Generate summary report from test results"""
    logger.info("\n" + "="*80)
    logger.info("PARAMETER TESTING SUMMARY")
    logger.info("="*80)
    
    # Extract metrics - iterate over DataFrame rows properly
    in_sample_cagr = []
    in_sample_sharpe = []
    in_sample_dd = []
    oos_cagr = []
    oos_sharpe = []
    oos_dd = []
    
    for idx, row in results_df.iterrows():
        if row['in_sample']:
            in_sample_cagr.append(row['in_sample'].get('cagr', 0))
            in_sample_sharpe.append(row['in_sample'].get('sharpe_ratio', 0))
            in_sample_dd.append(row['in_sample'].get('max_drawdown', 0))
        
        if RUN_OUT_OF_SAMPLE and row['out_of_sample']:
            oos_cagr.append(row['out_of_sample'].get('cagr', 0))
            oos_sharpe.append(row['out_of_sample'].get('sharpe_ratio', 0))
            oos_dd.append(row['out_of_sample'].get('max_drawdown', 0))
    
    if in_sample_cagr:
        logger.info(f"\nIn-Sample Performance (n={len(in_sample_cagr)}):")
        logger.info(f"  CAGR: {np.mean(in_sample_cagr):.2f}% ± {np.std(in_sample_cagr):.2f}% (range: {np.min(in_sample_cagr):.2f}% to {np.max(in_sample_cagr):.2f}%)")
        logger.info(f"  Sharpe: {np.mean(in_sample_sharpe):.2f} ± {np.std(in_sample_sharpe):.2f} (range: {np.min(in_sample_sharpe):.2f} to {np.max(in_sample_sharpe):.2f})")
        logger.info(f"  Max DD: {np.mean(in_sample_dd):.2f}% ± {np.std(in_sample_dd):.2f}% (range: {np.min(in_sample_dd):.2f}% to {np.max(in_sample_dd):.2f}%)")
    
    if RUN_OUT_OF_SAMPLE and oos_cagr:
        logger.info(f"\nOut-of-Sample Performance (n={len(oos_cagr)}):")
        logger.info(f"  CAGR: {np.mean(oos_cagr):.2f}% ± {np.std(oos_cagr):.2f}% (range: {np.min(oos_cagr):.2f}% to {np.max(oos_cagr):.2f}%)")
        logger.info(f"  Sharpe: {np.mean(oos_sharpe):.2f} ± {np.std(oos_sharpe):.2f} (range: {np.min(oos_sharpe):.2f} to {np.max(oos_sharpe):.2f})")
        logger.info(f"  Max DD: {np.mean(oos_dd):.2f}% ± {np.std(oos_dd):.2f}% (range: {np.min(oos_dd):.2f}% to {np.max(oos_dd):.2f}%)")
    
    # Find top configurations
    logger.info("\n" + "="*80)
    logger.info("TOP 10 CONFIGURATIONS BY CAGR")
    logger.info("="*80)
    
    # Sort by in-sample CAGR
    results_sorted = sorted(results_df.to_dict('records'), 
                           key=lambda x: x['in_sample'].get('cagr', 0) if x['in_sample'] else 0,
                           reverse=True)
    
    for i, result in enumerate(results_sorted[:10]):
        config = result['config']
        in_sample = result['in_sample']
        oos = result['out_of_sample']
        
        logger.info(f"\n#{i+1} Configuration:")
        logger.info(f"  Config: {config}")
        logger.info(f"  In-Sample: CAGR: {in_sample.get('cagr', 0):.2f}%, Sharpe: {in_sample.get('sharpe_ratio', 0):.2f}, Max DD: {in_sample.get('max_drawdown', 0):.2f}%")
        if oos:
            logger.info(f"  Out-of-Sample: CAGR: {oos.get('cagr', 0):.2f}%, Sharpe: {oos.get('sharpe_ratio', 0):.2f}, Max DD: {oos.get('max_drawdown', 0):.2f}%")
    
    # Save summary to file
    summary_file = os.path.join(OUTPUT_DIR, f'summary_report_{timestamp}.txt')
    with open(summary_file, 'w') as f:
        f.write("MultiBeggar Strategy - Parameter Testing Summary\n")
        f.write("="*80 + "\n")
        f.write(f"Test Date: {datetime.now()}\n")
        f.write(f"Configurations Tested: {len(results_df)}\n")
        f.write(f"Backtest Period: {BACKTEST_START_DATE} to {BACKTEST_END_DATE}\n")
        f.write("\nTop 10 Configurations by CAGR:\n")
        for i, result in enumerate(results_sorted[:10]):
            f.write(f"\n#{i+1}: CAGR: {result['in_sample'].get('cagr', 0):.2f}%\n")
            f.write(f"Config: {result['config']}\n")
    
    logger.info(f"\nSummary report saved to {summary_file}")

# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Main execution function"""
    logger.info("\n" + "="*80)
    logger.info("MULTIBEGGAR STRATEGY BACKTESTER")
    logger.info("="*80)
    logger.info(f"Start Time: {datetime.now()}")
    logger.info(f"Backtest Period: {BACKTEST_START_DATE} to {BACKTEST_END_DATE}")
    logger.info(f"Initial Capital: Rs.{INITIAL_CAPITAL:,}")
    logger.info(f"Portfolio Size: {PORTFOLIO_SIZE} positions")
    logger.info(f"Position Sizing: {POSITION_SIZING_METHOD}")
    
    # Initialize Kite API
    logger.info("\nInitializing Kite API...")
    data_fetcher = KiteDataFetcher(API_KEY, ACCESS_TOKEN)
    
    # Run parameter tests
    if RUN_PARAMETER_SWEEP or RUN_SENSITIVITY_ANALYSIS or RUN_MONTE_CARLO or RUN_QUICK_TEST:
        results_df = run_parameter_tests(data_fetcher)
    else:
        logger.info("\nNo testing mode selected. Set RUN_PARAMETER_SWEEP or RUN_QUICK_TEST to True.")
    
    logger.info(f"\nEnd Time: {datetime.now()}")
    logger.info("="*80)

if __name__ == "__main__":
    main()

