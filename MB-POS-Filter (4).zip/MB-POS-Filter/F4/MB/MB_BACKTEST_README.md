# MultiBeggar Strategy Backtester

## Overview

Comprehensive backtesting framework for the MultiBeggar (MB) long-term hold strategy. Tests various parameter configurations to find optimal settings for CAGR maximization.

## Quick Start

### 1. Run Default Configuration
```bash
python run_mb_backtest.py --scenario default
```

### 2. Compare Multiple Scenarios
```bash
python run_mb_backtest.py --compare default aggressive conservative
```

### 3. Sensitivity Analysis
Test impact of a single parameter:
```bash
python run_mb_backtest.py --sensitivity trix_threshold --param-values 0.5 1.0 1.5 2.0
```

## Predefined Scenarios

### Default
- Uses exact settings from `MBSystemGemini.py` scanner
- Balanced risk/reward
- **Best for**: Starting point, validation against live scanner

### Aggressive
- Looser filters (more signals)
- Shorter hold periods (2-26 weeks)
- Tighter trailing stop (12%)
- **Best for**: High-frequency trading, smaller account sizes

### Conservative
- Stricter filters (fewer signals)
- Longer hold periods (8-52 weeks)
- Wider trailing stop (20%)
- **Best for**: Lower risk tolerance, larger account sizes

### Fractal Focus
- Heavy emphasis on bearish fractal breakouts
- Volume confirmation required
- Exit on bearish fractal formation
- **Best for**: Testing fractal pattern effectiveness

### Trend Rider
- Enter early, hold long (12-104 weeks)
- Wide trailing stop (25%)
- Exit only on TRIX deterioration
- **Best for**: Multibagger approach, patient capital

## Parameter Grid Search

Run comprehensive parameter sweep:

```python
# Edit MBBacktester.py
RUN_PARAMETER_SWEEP = True
RUN_SENSITIVITY_ANALYSIS = False
RUN_QUICK_TEST = False

# Run
python MBBacktester.py
```

### Parameters Tested

#### Monthly Filter
- `trix_threshold`: [0.5, 1.0, 1.5, 2.0]
- `kc_distance_threshold`: [0.5%, 1.0%, 2.0%]
- `kc_slope_required`: [True, False]
- `trix_momentum_required`: [True, False]
- `bearish_fractal_bonus`: [True, False]

#### Weekly Filter
- `rsi_threshold`: [60, 65, 70, 75]
- `volume_ratio_threshold`: [0.8, 1.0, 1.2]
- `atr_percent_threshold`: [6.0, 8.0, 10.0]
- `entry_conditions_required`: [3, 4, 5] out of 6
- `fractal_strength_required`: [True, False]

#### Exit Strategy
- `exit_strategy`: ['trix_deterioration', 'fractal_break', 'trailing_stop', 'hybrid']
- `trailing_stop_pct`: [10%, 15%, 20%]
- `hold_period_min`: [4, 8, 12 weeks]
- `hold_period_max`: [26, 39, 52 weeks]

#### Position Sizing
- `conviction_multiplier`: [1.0, 1.5, 2.0]
- `volatility_target`: [2%, 3%, 4%]

## Output Files

### Results
- `parameter_test_results_YYYYMMDD_HHMMSS.pkl` - Full results (all configs)
- `summary_report_YYYYMMDD_HHMMSS.txt` - Top 10 configurations
- `scenario_comparison_YYYYMMDD_HHMMSS.csv` - Scenario comparison table

### Trades
- `trades_SCENARIO_YYYYMMDD_HHMMSS.csv` - Individual trade history
  - Entry/Exit dates, prices, PnL, hold period, exit reason

### Visualizations
- `sensitivity_PARAMETER_YYYYMMDD_HHMMSS.png` - Sensitivity plots
- `equity_curve_YYYYMMDD_HHMMSS.png` - Portfolio equity curve

## Performance Metrics

### Primary Metrics
- **CAGR**: Compound Annual Growth Rate (target: 30%+)
- **Max Drawdown**: Maximum peak-to-trough decline (target: <25%)
- **Sharpe Ratio**: Risk-adjusted return (target: 1.5+)

### Trading Metrics
- **Win Rate**: % of profitable trades (target: 55%+)
- **Avg Win / Avg Loss**: Average gains vs losses
- **Profit Factor**: Gross profit / Gross loss (target: 2.0+)
- **Avg Hold Period**: Days per trade

## Analysis Workflow

### Step 1: Validate Scanner Settings
```bash
# Test default config matches live scanner
python run_mb_backtest.py --scenario default
```

**Expected**: Similar signals to live scanner output

### Step 2: Compare Strategies
```bash
# Test risk profiles
python run_mb_backtest.py --compare default aggressive conservative trend_rider
```

**Goal**: Find best risk/reward profile for your account

### Step 3: Optimize Key Parameters
```bash
# Test TRIX threshold
python run_mb_backtest.py --sensitivity trix_threshold --param-values 0.5 1.0 1.5 2.0 2.5

# Test RSI threshold
python run_mb_backtest.py --sensitivity rsi_threshold --param-values 60 65 70 75 80

# Test trailing stop
python run_mb_backtest.py --sensitivity trailing_stop_pct --param-values 0.10 0.12 0.15 0.18 0.20
```

**Goal**: Find optimal balance between signal frequency and quality

### Step 4: Full Parameter Sweep
```bash
# Edit MBBacktester.py
RUN_PARAMETER_SWEEP = True

# Run (WARNING: Takes hours for full grid)
python MBBacktester.py
```

**Goal**: Discover unexpected optimal parameter combinations

### Step 5: Out-of-Sample Validation
```bash
# Edit MBBacktester.py
RUN_OUT_OF_SAMPLE = True
TRAIN_START = "2022-01-01"
TRAIN_END = "2024-01-01"
TEST_START = "2024-01-01"
TEST_END = "2025-10-23"

# Run
python MBBacktester.py
```

**Goal**: Validate parameters don't overfit to historical data

## Key Insights from Testing

### What to Look For

1. **CAGR > 30%**: MultiBeggar approach targets high returns
2. **Max DD < 25%**: Long holds mean accepting drawdowns
3. **Sharpe > 1.5**: Risk-adjusted performance matters
4. **Win Rate > 50%**: Need more winners than losers
5. **Avg Hold > 30 days**: Not a short-term strategy

### Red Flags

- **CAGR too high (>100%)**: Likely overfitting or survivorship bias
- **Max DD > 40%**: Risk of ruin, need tighter stops
- **Win Rate < 40%**: Filters too loose, catching bad signals
- **Too few trades (<10)**: Not enough data to validate
- **Too many trades (>100)**: Not a "long hold" strategy

## Troubleshooting

### "No data prepared"
- Check API credentials in `MBBacktester.py`
- Ensure `SYMBOLS_CSV` path is correct
- Verify Kite API access token is valid

### "Insufficient cash for entry"
- Reduce `PORTFOLIO_SIZE` (try 5 instead of 10)
- Increase `INITIAL_CAPITAL`
- Check transaction costs aren't too high

### "Results identical across configs"
- Check parameter grid has variation
- Verify config is being passed to signal generation
- Ensure data has enough history for indicators

## Advanced Usage

### Custom Parameter Grid
```python
# Edit MBBacktester.py

CUSTOM_PARAMS = {
    'trix_threshold': [1.0, 1.2, 1.5, 1.8, 2.0, 2.5],
    'rsi_threshold': [65, 70, 75],
    'exit_strategy': ['hybrid', 'trailing_stop'],
    # ... add more
}

# Replace MONTHLY_PARAMS / WEEKLY_PARAMS / EXIT_PARAMS
```

### Monte Carlo Testing
```python
# Edit MBBacktester.py
RUN_MONTE_CARLO = True
MONTE_CARLO_RUNS = 100

# Run
python MBBacktester.py
```

Tests random parameter combinations (faster than full grid)

### Position Sizing Methods
```python
# Edit MBBacktester.py
POSITION_SIZING_METHOD = 'conviction_based'  # or 'volatility_adjusted'

# conviction_based: Bigger positions on high-conviction setups
# volatility_adjusted: Size inversely to volatility (Kelly-style)
# equal_weight: Same size for all positions (default)
```

## Next Steps

1. **Run default scenario** - Validate against live scanner
2. **Compare 5 scenarios** - Find best strategy for your profile
3. **Sensitivity analysis** - Optimize key parameters
4. **Out-of-sample test** - Validate robustness
5. **Live paper trading** - Test with real data before real money

## Support

Questions? Check:
- `mb_backtest.log` - Detailed execution log
- `OUTPUT_DIR/summary_report_*.txt` - Results summary
- Scanner code: `MBSystemGemini.py` - Live scanner logic

---

**Remember**: Past performance doesn't guarantee future results. Backtest thoroughly, validate out-of-sample, and paper trade before risking real capital.

