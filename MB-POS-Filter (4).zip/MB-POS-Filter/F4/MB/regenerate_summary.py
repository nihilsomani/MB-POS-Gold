"""
Regenerate Summary Report from Saved Results
=============================================
Use this to generate summary after a test run completes
"""

import pandas as pd
import numpy as np
import sys
import os

def regenerate_summary(results_file):
    """Regenerate summary from pickle file"""
    
    print("="*80)
    print("MULTIBEGGAR BACKTEST - SUMMARY REPORT")
    print("="*80)
    
    # Load results
    results_df = pd.read_pickle(results_file)
    print(f"\nLoaded {len(results_df)} test results from {results_file}")
    
    # Extract metrics
    in_sample_cagr = []
    in_sample_sharpe = []
    in_sample_dd = []
    in_sample_win_rate = []
    in_sample_trades = []
    oos_cagr = []
    oos_sharpe = []
    oos_dd = []
    oos_win_rate = []
    
    for idx, row in results_df.iterrows():
        if row['in_sample']:
            in_sample_cagr.append(row['in_sample'].get('cagr', 0))
            in_sample_sharpe.append(row['in_sample'].get('sharpe_ratio', 0))
            in_sample_dd.append(row['in_sample'].get('max_drawdown', 0))
            in_sample_win_rate.append(row['in_sample'].get('win_rate', 0))
            in_sample_trades.append(row['in_sample'].get('num_trades', 0))
        
        if row['out_of_sample']:
            oos_cagr.append(row['out_of_sample'].get('cagr', 0))
            oos_sharpe.append(row['out_of_sample'].get('sharpe_ratio', 0))
            oos_dd.append(row['out_of_sample'].get('max_drawdown', 0))
            oos_win_rate.append(row['out_of_sample'].get('win_rate', 0))
    
    # In-Sample Summary
    if in_sample_cagr:
        print("\n" + "-"*80)
        print("IN-SAMPLE PERFORMANCE (2022-2024)")
        print("-"*80)
        print(f"Configurations Tested: {len(in_sample_cagr)}")
        print(f"\nCAGR:")
        print(f"  Mean:   {np.mean(in_sample_cagr):>7.2f}%")
        print(f"  Median: {np.median(in_sample_cagr):>7.2f}%")
        print(f"  Std:    {np.std(in_sample_cagr):>7.2f}%")
        print(f"  Range:  {np.min(in_sample_cagr):>7.2f}% to {np.max(in_sample_cagr):.2f}%")
        
        print(f"\nSharpe Ratio:")
        print(f"  Mean:   {np.mean(in_sample_sharpe):>7.2f}")
        print(f"  Range:  {np.min(in_sample_sharpe):>7.2f} to {np.max(in_sample_sharpe):.2f}")
        
        print(f"\nMax Drawdown:")
        print(f"  Mean:   {np.mean(in_sample_dd):>7.2f}%")
        print(f"  Range:  {np.min(in_sample_dd):>7.2f}% to {np.max(in_sample_dd):.2f}%")
        
        print(f"\nWin Rate:")
        print(f"  Mean:   {np.mean(in_sample_win_rate):>7.2f}%")
        print(f"  Range:  {np.min(in_sample_win_rate):>7.2f}% to {np.max(in_sample_win_rate):.2f}%")
        
        print(f"\nNumber of Trades:")
        print(f"  Mean:   {np.mean(in_sample_trades):>7.1f}")
        print(f"  Range:  {int(np.min(in_sample_trades))} to {int(np.max(in_sample_trades))}")
    
    # Out-of-Sample Summary
    if oos_cagr:
        print("\n" + "-"*80)
        print("OUT-OF-SAMPLE PERFORMANCE (2024-2025)")
        print("-"*80)
        print(f"Configurations Tested: {len(oos_cagr)}")
        print(f"\nCAGR:")
        print(f"  Mean:   {np.mean(oos_cagr):>7.2f}%")
        print(f"  Median: {np.median(oos_cagr):>7.2f}%")
        print(f"  Std:    {np.std(oos_cagr):>7.2f}%")
        print(f"  Range:  {np.min(oos_cagr):>7.2f}% to {np.max(oos_cagr):.2f}%")
        
        print(f"\nSharpe Ratio:")
        print(f"  Mean:   {np.mean(oos_sharpe):>7.2f}")
        print(f"  Range:  {np.min(oos_sharpe):>7.2f} to {np.max(oos_sharpe):.2f}")
        
        print(f"\nMax Drawdown:")
        print(f"  Mean:   {np.mean(oos_dd):>7.2f}%")
        print(f"  Range:  {np.min(oos_dd):>7.2f}% to {np.max(oos_dd):.2f}%")
        
        print(f"\nWin Rate:")
        print(f"  Mean:   {np.mean(oos_win_rate):>7.2f}%")
        print(f"  Range:  {np.min(oos_win_rate):>7.2f}% to {np.max(oos_win_rate):.2f}%")
    
    # Top Configurations
    print("\n" + "="*80)
    print("TOP 10 CONFIGURATIONS BY IN-SAMPLE CAGR")
    print("="*80)
    
    # Sort by in-sample CAGR
    results_sorted = []
    for idx, row in results_df.iterrows():
        if row['in_sample']:
            results_sorted.append({
                'config': row['config'],
                'is_cagr': row['in_sample'].get('cagr', 0),
                'is_sharpe': row['in_sample'].get('sharpe_ratio', 0),
                'is_dd': row['in_sample'].get('max_drawdown', 0),
                'is_win_rate': row['in_sample'].get('win_rate', 0),
                'is_trades': row['in_sample'].get('num_trades', 0),
                'oos_cagr': row['out_of_sample'].get('cagr', 0) if row['out_of_sample'] else 0,
                'oos_sharpe': row['out_of_sample'].get('sharpe_ratio', 0) if row['out_of_sample'] else 0,
                'oos_dd': row['out_of_sample'].get('max_drawdown', 0) if row['out_of_sample'] else 0,
            })
    
    results_sorted = sorted(results_sorted, key=lambda x: x['is_cagr'], reverse=True)
    
    for i, result in enumerate(results_sorted[:10]):
        print(f"\n{'='*80}")
        print(f"RANK #{i+1}")
        print(f"{'='*80}")
        
        print(f"\nIn-Sample (2022-2024):")
        print(f"  CAGR:       {result['is_cagr']:>7.2f}%")
        print(f"  Sharpe:     {result['is_sharpe']:>7.2f}")
        print(f"  Max DD:     {result['is_dd']:>7.2f}%")
        print(f"  Win Rate:   {result['is_win_rate']:>7.2f}%")
        print(f"  Trades:     {result['is_trades']:>7.0f}")
        
        if result['oos_cagr'] > 0:
            print(f"\nOut-of-Sample (2024-2025):")
            print(f"  CAGR:       {result['oos_cagr']:>7.2f}%")
            print(f"  Sharpe:     {result['oos_sharpe']:>7.2f}")
            print(f"  Max DD:     {result['oos_dd']:>7.2f}%")
            
            # Degradation analysis
            cagr_decay = ((result['is_cagr'] - result['oos_cagr']) / result['is_cagr'] * 100) if result['is_cagr'] > 0 else 0
            print(f"  CAGR Decay: {cagr_decay:>7.1f}% (lower is better)")
        
        print(f"\nConfiguration:")
        config = result['config']
        
        # Group config by category
        print(f"  Monthly Filters:")
        print(f"    TRIX Threshold:     {config.get('trix_threshold', 'N/A')}")
        print(f"    KC Distance:        {config.get('kc_distance_threshold', 'N/A')}%")
        print(f"    KC Slope Required:  {config.get('kc_slope_required', 'N/A')}")
        print(f"    TRIX Mom Required:  {config.get('trix_momentum_required', 'N/A')}")
        print(f"    BF Breakout Bonus:  {config.get('bearish_fractal_bonus', 'N/A')}")
        
        print(f"  Weekly Filters:")
        print(f"    RSI Threshold:      {config.get('rsi_threshold', 'N/A')}")
        print(f"    Volume Ratio:       {config.get('volume_ratio_threshold', 'N/A')}")
        print(f"    ATR % Threshold:    {config.get('atr_percent_threshold', 'N/A')}")
        print(f"    Conditions Needed:  {config.get('entry_conditions_required', 'N/A')}/6")
        print(f"    Fractal Required:   {config.get('fractal_strength_required', 'N/A')}")
        
        print(f"  Exit Strategy:")
        print(f"    Strategy:           {config.get('exit_strategy', 'N/A')}")
        print(f"    Trailing Stop:      {config.get('trailing_stop_pct', 0)*100:.0f}%")
        print(f"    Min Hold (weeks):   {config.get('hold_period_min', 'N/A')}")
        print(f"    Max Hold (weeks):   {config.get('hold_period_max', 'N/A')}")
        
        print(f"  Position Sizing:")
        print(f"    Conviction Mult:    {config.get('conviction_multiplier', 'N/A')}x")
        print(f"    Volatility Target:  {config.get('volatility_target', 0)*100:.1f}%")
    
    # Key Insights
    print("\n" + "="*80)
    print("KEY INSIGHTS")
    print("="*80)
    
    if in_sample_cagr and oos_cagr:
        avg_is_cagr = np.mean(in_sample_cagr)
        avg_oos_cagr = np.mean(oos_cagr)
        avg_decay = ((avg_is_cagr - avg_oos_cagr) / avg_is_cagr * 100) if avg_is_cagr > 0 else 0
        
        print(f"\nStrategy Robustness:")
        print(f"  Average CAGR Decay (IS → OOS): {avg_decay:.1f}%")
        
        if avg_decay < 30:
            print(f"  ✅ EXCELLENT - Strategy generalizes well (<30% decay)")
        elif avg_decay < 50:
            print(f"  ✅ GOOD - Acceptable generalization (<50% decay)")
        elif avg_decay < 70:
            print(f"  ⚠️  MODERATE - Some overfitting (50-70% decay)")
        else:
            print(f"  ❌ POOR - High overfitting risk (>70% decay)")
        
        # Best OOS performance
        best_oos_idx = np.argmax(oos_cagr)
        print(f"\nBest Out-of-Sample Config:")
        print(f"  OOS CAGR: {oos_cagr[best_oos_idx]:.2f}%")
        print(f"  IS CAGR:  {in_sample_cagr[best_oos_idx]:.2f}%")
        print(f"  Config:   {results_sorted[best_oos_idx]['config']}")
    
    print("\n" + "="*80)
    print("Summary regeneration complete!")
    print("="*80)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        results_file = sys.argv[1]
    else:
        # Find latest results file
        import glob
        files = glob.glob('mb_backtest_results/parameter_test_results_*.pkl')
        if files:
            results_file = max(files, key=os.path.getctime)
            print(f"Using latest results file: {results_file}")
        else:
            print("No results files found!")
            print("Usage: python regenerate_summary.py <path_to_results.pkl>")
            sys.exit(1)
    
    regenerate_summary(results_file)

