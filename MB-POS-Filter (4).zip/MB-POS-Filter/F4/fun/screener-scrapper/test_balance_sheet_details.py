#!/usr/bin/env python3
"""
Test script to check what balance sheet details are available on screener.in
"""

import requests
from bs4 import BeautifulSoup
import time

def test_company_balance_sheet(symbol):
    """Test what balance sheet details we can extract"""
    
    url = f"https://www.screener.in/company/{symbol}/"
    
    print(f"\n{'='*70}")
    print(f"Testing: {symbol}")
    print(f"URL: {url}")
    print(f"{'='*70}")
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    response = requests.get(url, headers=headers, timeout=30)
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Find balance sheet section
    bs_section = soup.find('section', id='balance-sheet')
    if not bs_section:
        print("[X] No balance sheet section found")
        return
    
    print("[OK] Balance sheet section found\n")
    
    # Find the table
    table = bs_section.find('table', class_='data-table')
    if not table:
        print("[X] No data table found")
        return
    
    print("[OK] Data table found\n")
    
    # Get all rows
    tbody = table.find('tbody')
    if tbody:
        rows = tbody.find_all('tr', recursive=False)  # Only direct children
        
        print(f"Found {len(rows)} rows in balance sheet:\n")
        
        for i, row in enumerate(rows, 1):
            # Get the metric name
            cells = row.find_all(['td', 'th'])
            if cells:
                metric = cells[0].get_text().strip()
                
                # Check if it's expandable
                is_expandable = '+' in metric
                
                # Check for child rows (nested table or sub-rows)
                # Some websites use classes like 'sub-row', 'child-row', etc.
                row_class = row.get('class', [])
                
                print(f"{i:2d}. {metric:<40} ", end='')
                if is_expandable:
                    print("[EXPANDABLE +]", end='')
                if row_class:
                    print(f" Classes: {row_class}", end='')
                print()
                
                # Try to find child/nested rows
                # Check if next rows are children (common pattern: indented or have specific class)
                next_sibling = row.find_next_sibling('tr')
                child_count = 0
                
                while next_sibling:
                    next_cells = next_sibling.find_all(['td', 'th'])
                    if next_cells:
                        next_metric = next_cells[0].get_text().strip()
                        
                        # If indented or starts with whitespace, it's likely a child
                        # Or if it doesn't have a '+', it might be a detail row
                        if next_metric.startswith('  ') or next_metric.startswith('\t'):
                            child_count += 1
                            print(f"     └─ {next_metric}")
                            next_sibling = next_sibling.find_next_sibling('tr')
                        else:
                            break
                    else:
                        break
    
    # Also check for any hidden elements or data attributes
    print(f"\n{'='*70}")
    print("Checking for expandable content mechanisms...")
    print(f"{'='*70}\n")
    
    # Check for JavaScript data
    scripts = soup.find_all('script')
    for script in scripts:
        if script.string and 'balance' in script.string.lower() and 'receivable' in script.string.lower():
            print("Found JavaScript with balance sheet data!")
            print(script.string[:500])
            break
    
    # Check for data attributes
    expandable_rows = tbody.find_all('tr', attrs={'data-parent': True})
    if expandable_rows:
        print(f"\nFound {len(expandable_rows)} rows with data-parent attribute")
        for row in expandable_rows[:3]:
            print(f"  {row.get('data-parent')}: {row.find('th').get_text().strip()}")


if __name__ == "__main__":
    # Test with a few companies
    test_companies = ['JSLL', 'RELIANCE', 'INFY']
    
    for symbol in test_companies:
        test_company_balance_sheet(symbol)
        time.sleep(2)  # Be polite
    
    print(f"\n{'='*70}")
    print("Analysis complete!")
    print(f"{'='*70}")

