#!/usr/bin/env python3
"""
Configuration file for custom company lists
Modify the lists below to scrape your desired companies
"""

# Your custom company list - modify this list with the companies you want to scrape
CUSTOM_COMPANIES = [
    'MOSCHIP',
'SWIGGY',
'CEIGALL',
'EUREKAFORB',
'RAYMONDLSL',
'PROTEAN',
'OLAELEC',
'CARYSIL',
'SKFINDIA',
'HEMIPROP',
'RTNINDIA',
'HLEGLAS',
'LANDMARK',
'HINDWAREAP',
'KIOCL',
'STLTECH',
'MSUMI',
'SUPRAJIT',
'JAMNAAUTO',
'KOLTEPATIL',
'SANGHVIMOV',
'NAVNETEDUL',
'CHENNPETRO',
'MUTHOOTMF',
'MAITHANALL',
'IIFL',
'SSWL',
'IDFCFIRSTB',
'ASIANPAINT',
'SAKSOFT',
'JKPAPER',
'DEVYANI',
'MOLDTKPAC',
'ACI',
'MASFIN',
'SAGCEM',
'RAMKY',
'SHANTIGEAR',
'EVEREADY',
'INDIAMART',
'SUPREMEIND',
'POONAWALLA',
'HONDAPOWER',
'NESTLEIND',
'DELHIVERY',
'CGCL',
'MHRIL',
'AARTIDRUGS',
'FINEORG',
'GSFC',
'MIDHANI',
'OLECTRA',
'BIRLACORPN',
'DABUR',
'ALKYLAMINE',
'CREDITACC',
'HINDUNILVR',
'UJJIVANSFB',
'ZFCVINDIA',
'RSYSTEMS',
'KAJARIACER',
'NRBBEARING',
'DOMS',
'PSPPROJECT',
'VIPIND',
'BAJAJCON'
]

# Companies organized by sector (for sector-based scraping)
SECTOR_COMPANIES = {
    'Banking': [
        'BANDHANBNK', 'UJJIVANSFB', 'AUBANK', 'RBLBANK', 'IDFCFIRSTB', 'YESBANK', 'J&KBANK', 'BANKINDIA', 'EQUITASBNK'
    ],
    'IT': [
        'TATAELXSI', 'MTARTECH', 'AVANTEL', 'NETWORK18'
    ],
    'Energy': [
        'MRPL', 'GNFC', 'GESHIP', 'GPPL'
    ],
    'Automobile': [
        'JAMNAAUTO', 'JKTYRE', 'MAHSEAMLES', 'HONDAPOWER'
    ],
    'FMCG': [
        'NESTLEIND', 'TITAN', 'SANOFI', 'SURYAROSNI'
    ],
    'Pharma': [
        'MANKIND', 'IOLCP', 'CONCORDBIO', 'SANOFI'
    ]
}

# Scraper configuration
SCRAPER_CONFIG = {
    'max_workers': 2,           # Number of parallel workers
    'delay_range': (2, 5),      # Slightly higher delay to avoid rate limits
    'timeout': 30,              # Request timeout (seconds)
    'retry_attempts': 3,        # Number of retry attempts
}

# Output configuration
OUTPUT_CONFIG = {
    'output_filename': 'my_custom_companies.csv',
    'include_summary': True,
    'reorder_columns': True,
}

# Example usage functions
def get_custom_companies(limit: int | None = 50):
    """Get the custom company list (optionally limited)"""
    return CUSTOM_COMPANIES[:limit] if isinstance(limit, int) else CUSTOM_COMPANIES

def get_sector_companies():
    """Get companies organized by sector"""
    return SECTOR_COMPANIES

def get_scraper_config():
    """Get scraper configuration"""
    return SCRAPER_CONFIG

def get_output_config():
    """Get output configuration"""
    return OUTPUT_CONFIG

# Example: How to use this configuration
if __name__ == "__main__":
    print("Custom Companies Configuration")
    print("=" * 40)
    
    print(f"Total companies in custom list: {len(CUSTOM_COMPANIES)}")
    print("Companies:", ", ".join(CUSTOM_COMPANIES[:5]) + "...")
    
    print(f"\nSectors available: {list(SECTOR_COMPANIES.keys())}")
    
    print(f"\nScraper config: {SCRAPER_CONFIG}")
    print(f"Output config: {OUTPUT_CONFIG}") 