#!/usr/bin/env python3
"""
Script to fix existing CSV file with proper JSON handling
"""

import pandas as pd
import json
import os
import logging
from robust_csv_saver import RobustCSVSaver, create_robust_csv_from_existing

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def analyze_existing_csv(filepath: str):
    """
    Analyze the existing CSV file to understand its structure and issues
    
    Args:
        filepath: Path to the existing CSV file
    """
    try:
        # Try to read the CSV file
        df = pd.read_csv(filepath, encoding='utf-8-sig')
        
        logger.info(f"Successfully loaded CSV with {len(df)} rows and {len(df.columns)} columns")
        logger.info(f"Columns: {list(df.columns)}")
        
        # Check for JSON columns
        json_columns = ['quarterly_data', 'pnl_data', 'balance_sheet_data']
        
        for col in json_columns:
            if col in df.columns:
                logger.info(f"\nAnalyzing {col} column:")
                
                # Check for non-empty values
                non_empty = df[col].notna().sum()
                logger.info(f"Non-empty values: {non_empty}/{len(df)}")
                
                # Check for valid JSON strings
                valid_json_count = 0
                for idx, value in df[col].items():
                    if pd.notna(value) and value != "":
                        try:
                            # Try to parse as JSON
                            if isinstance(value, str):
                                json.loads(value)
                                valid_json_count += 1
                            elif isinstance(value, dict):
                                # Already a dict, so it's valid
                                valid_json_count += 1
                        except (json.JSONDecodeError, TypeError):
                            logger.warning(f"Invalid JSON in row {idx}: {str(value)[:100]}...")
                
                logger.info(f"Valid JSON values: {valid_json_count}/{non_empty}")
                
        return df
        
    except Exception as e:
        logger.error(f"Error analyzing CSV file: {e}")
        return None

def fix_csv_issues(filepath: str, output_filepath: str = None):
    """
    Fix issues in the existing CSV file
    
    Args:
        filepath: Path to the existing CSV file
        output_filepath: Path for the fixed CSV file
    """
    try:
        # Load the existing data
        df = pd.read_csv(filepath, encoding='utf-8-sig')
        
        logger.info(f"Loaded {len(df)} rows from {filepath}")
        
        # Create robust CSV saver
        saver = RobustCSVSaver()
        
        # Validate the data
        validation_results = saver.validate_json_data(df)
        
        logger.info(f"Validation results:")
        logger.info(f"Valid companies: {len(validation_results['valid_companies'])}")
        logger.info(f"Invalid companies: {len(validation_results['invalid_companies'])}")
        
        if validation_results['invalid_companies']:
            logger.warning(f"Companies with issues: {validation_results['invalid_companies']}")
        
        # Save as robust CSV
        if output_filepath is None:
            base_name = os.path.splitext(os.path.basename(filepath))[0]
            output_filepath = f"output/{base_name}_fixed.csv"
        
        # Create output directory
        os.makedirs(os.path.dirname(output_filepath), exist_ok=True)
        
        # Save with robust handling
        fixed_filepath = saver.save_to_csv(df, output_filepath)
        
        logger.info(f"Fixed CSV saved to: {fixed_filepath}")
        
        # Test loading the fixed file
        test_df = saver.load_from_csv(fixed_filepath)
        logger.info(f"Successfully loaded fixed CSV with {len(test_df)} rows")
        
        return fixed_filepath
        
    except Exception as e:
        logger.error(f"Error fixing CSV file: {e}")
        return None

def create_sample_analysis(filepath: str):
    """
    Create a sample analysis of the fixed CSV data
    
    Args:
        filepath: Path to the fixed CSV file
    """
    try:
        saver = RobustCSVSaver()
        df = saver.load_from_csv(filepath)
        
        if df.empty:
            logger.error("No data loaded for analysis")
            return
        
        logger.info(f"\n=== SAMPLE ANALYSIS ===")
        logger.info(f"Total companies: {len(df)}")
        
        # Analyze JSON data availability
        json_columns = ['quarterly_data', 'pnl_data', 'balance_sheet_data']
        
        for col in json_columns:
            if col in df.columns:
                valid_count = 0
                total_count = 0
                
                for idx, row in df.iterrows():
                    data = row[col]
                    if isinstance(data, dict) and data:
                        if col == 'quarterly_data' and 'data' in data and data['data']:
                            valid_count += 1
                        elif col == 'pnl_data' and 'data' in data and data['data']:
                            valid_count += 1
                        elif col == 'balance_sheet_data' and 'data' in data and data['data']:
                            valid_count += 1
                    total_count += 1
                
                logger.info(f"{col}: {valid_count}/{total_count} companies have valid data")
        
        # Show sample of companies with complete data
        complete_data_companies = []
        for idx, row in df.iterrows():
            has_quarterly = isinstance(row.get('quarterly_data'), dict) and row['quarterly_data'].get('data')
            has_pnl = isinstance(row.get('pnl_data'), dict) and row['pnl_data'].get('data')
            has_balance = isinstance(row.get('balance_sheet_data'), dict) and row['balance_sheet_data'].get('data')
            
            if has_quarterly and has_pnl and has_balance:
                company_name = row.get('company_url', f'Company_{idx}').split('/')[-2]
                complete_data_companies.append(company_name)
        
        logger.info(f"Companies with complete data: {len(complete_data_companies)}")
        if complete_data_companies:
            logger.info(f"Sample companies: {complete_data_companies[:5]}")
        
    except Exception as e:
        logger.error(f"Error in sample analysis: {e}")

def main():
    """Main function to fix the existing CSV file"""
    
    # Input file
    input_file = "output/part1 - custom_companies_parallel_results.csv"
    
    if not os.path.exists(input_file):
        logger.error(f"Input file not found: {input_file}")
        return
    
    logger.info(f"Analyzing existing CSV file: {input_file}")
    
    # Analyze the existing file
    df = analyze_existing_csv(input_file)
    
    if df is None:
        logger.error("Failed to analyze CSV file")
        return
    
    # Fix the CSV issues
    logger.info("\nFixing CSV issues...")
    fixed_file = fix_csv_issues(input_file)
    
    if fixed_file:
        logger.info(f"\nCSV fixed successfully: {fixed_file}")
        
        # Create sample analysis
        create_sample_analysis(fixed_file)
        
        logger.info(f"\nYou can now use the fixed CSV file: {fixed_file}")
        logger.info("This file has proper JSON handling and should work correctly with pandas.")
    else:
        logger.error("Failed to fix CSV file")

if __name__ == "__main__":
    main() 