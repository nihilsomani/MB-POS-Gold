#!/usr/bin/env python3
"""
Simple verification script for Balance Sheet extraction
"""

from advanced_screener_scraper import AdvancedScreenerScraper

def verify_balance_sheet_feature():
    """Verify that the Balance Sheet extraction feature is working"""
    
    print("Verifying Balance Sheet Extraction Feature")
    print("=" * 50)
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Test with a single company
    company_symbol = 'RELIANCE'
    print(f"Testing with {company_symbol}...")
    
    try:
        metrics = scraper.scrape_single_company(company_symbol)
        
        if metrics and metrics.get('status') == 'success':
            print("✓ Successfully scraped company data")
            
            # Check all data types
            has_balance_sheet = metrics.get('has_balance_sheet_data', False)
            has_pnl = metrics.get('has_pnl_data', False)
            has_quarterly = metrics.get('has_quarterly_data', False)
            
            print(f"\nData Availability:")
            print(f"  Balance Sheet: {'✓' if has_balance_sheet else '✗'}")
            print(f"  Profit & Loss: {'✓' if has_pnl else '✗'}")
            print(f"  Quarterly Data: {'✓' if has_quarterly else '✗'}")
            
            if has_balance_sheet:
                balance_sheet_data = metrics.get('balance_sheet_data', {})
                print(f"\nBalance Sheet Details:")
                print(f"  Years: {balance_sheet_data.get('total_years', 0)}")
                print(f"  Metrics: {balance_sheet_data.get('total_metrics', 0)}")
                
                # Show sample metrics
                if 'data' in balance_sheet_data and balance_sheet_data['data']:
                    print(f"\nSample Balance Sheet metrics:")
                    for i, row in enumerate(balance_sheet_data['data'][:3]):
                        metric_name = row.get('metric', 'Unknown')
                        print(f"  {i+1}. {metric_name}")
            
            # Test CSV output
            print(f"\nTesting CSV output...")
            import pandas as pd
            df = pd.DataFrame([metrics])
            output_file = scraper.save_to_csv(df, "verify_balance_sheet.csv")
            print(f"✓ CSV saved to: {output_file}")
            
        else:
            print("✗ Failed to scrape company data")
            print(f"Status: {metrics.get('status', 'unknown')}")
            print(f"Error: {metrics.get('error', 'No error details')}")
            
    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    verify_balance_sheet_feature()
    print("\n" + "="*50)
    print("Verification completed!") 