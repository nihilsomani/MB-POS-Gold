"""
Fast Concall Analyzer - Optimized for Small Language Models
Works with: qwen2.5:1.5b, qwen2.5:0.5b, phi3.5, tinyllama
"""

import os
import json
import re
from pathlib import Path
from datetime import datetime
import requests

class FastConcallAnalyzer:
    def __init__(self, model: str = "qwen2.5:1.5b", downloads_dir: str = "downloads"):
        """
        Initialize with small/fast model
        
        Recommended models (fastest to slowest):
        - qwen2.5:0.5b  (ultra-fast, good enough)
        - qwen2.5:1.5b  (fast, better quality) ⭐ RECOMMENDED
        - phi3.5:mini   (fast, good quality)
        - tinyllama     (fastest, lower quality)
        """
        self.model = model
        self.ollama_url = "http://localhost:11434"
        self.api_endpoint = f"{self.ollama_url}/api/generate"
        self.concalls_dir = Path(downloads_dir) / "concalls"
        
        print(f"✓ Fast Analyzer initialized with {model}")
        self._check_model()
    
    def _check_model(self):
        """Check if model is available"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            if response.status_code == 200:
                models = [m['name'] for m in response.json().get('models', [])]
                if self.model not in models:
                    print(f"\n⚠️  Model '{self.model}' not found!")
                    print(f"   Available: {', '.join(models)}")
                    print(f"\n   Download it with: ollama pull {self.model}")
                    print(f"   Or try: qwen2.5:1.5b (recommended)\n")
                else:
                    print(f"   ✓ Model ready: {self.model}")
        except:
            print("   ⚠️  Could not check Ollama status")
    
    def _query_llm(self, prompt: str, max_tokens: int = 500) -> str:
        """Query LLM with aggressive timeout"""
        try:
            payload = {
                "model": self.model,
                "prompt": prompt,
                "stream": False,
                "options": {
                    "num_predict": max_tokens,
                    "temperature": 0,  # Deterministic for speed
                    "top_p": 0.9
                }
            }
            
            # Short timeout - if it can't do it in 60s, model is too slow
            response = requests.post(self.api_endpoint, json=payload, timeout=60)
            
            if response.status_code == 200:
                return response.json()['response']
            else:
                return ""
        except requests.exceptions.Timeout:
            print(f"   ⏱️  Timeout after 60s - try smaller model")
            return ""
        except Exception as e:
            print(f"   ❌ Error: {e}")
            return ""
    
    def _extract_pdf_text(self, pdf_path: str, max_pages: int = 5) -> str:
        """Extract text from first few pages only"""
        try:
            import PyPDF2
            text = ""
            with open(pdf_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                pages = min(max_pages, len(reader.pages))
                print(f"   📄 Reading first {pages} pages for speed...")
                
                for i in range(pages):
                    text += reader.pages[i].extract_text() + "\n"
            
            return text
        except Exception as e:
            print(f"   ✗ Error: {e}")
            return ""
    
    def read_concall(self, symbol: str) -> str:
        """Read concall"""
        concalls = list(self.concalls_dir.glob(f"{symbol}*"))
        if not concalls:
            return ""
        
        print(f"   ✓ Found: {concalls[0].name}")
        
        if concalls[0].suffix.lower() == '.pdf':
            return self._extract_pdf_text(str(concalls[0]))
        else:
            text = concalls[0].read_text(encoding='utf-8', errors='ignore')
            return text[:15000]  # Limit text file too
    
    def analyze_tone(self, text: str) -> dict:
        """Analyze tone - ultra-short prompt"""
        snippet = text[:1000]  # VERY short
        
        prompt = f"""Rate management tone (0-100 each):

{snippet}

JSON only:
{{"confidence": 75, "outlook": 70, "summary": "one sentence"}}"""

        result = self._query_llm(prompt, max_tokens=200)
        
        try:
            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            return {"confidence": 50, "outlook": 50, "summary": "Could not parse"}
        except:
            return {"confidence": 50, "outlook": 50, "summary": "Parse failed"}
    
    def extract_guidance(self, text: str) -> dict:
        """Extract guidance - focused search"""
        # Find guidance section
        text_lower = text.lower()
        guidance_start = max(
            text_lower.find('guidance'),
            text_lower.find('outlook'),
            text_lower.find('target'),
            0
        )
        
        snippet = text[guidance_start:guidance_start+1500]
        
        prompt = f"""Find forward guidance:

{snippet}

JSON only:
{{"revenue": "X% growth", "margin": "Y%", "initiatives": ["item1"]}}"""

        result = self._query_llm(prompt, max_tokens=300)
        
        try:
            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
            return {"revenue": "Not found", "margin": "Not found"}
        except:
            return {"revenue": "Parse error", "margin": "Parse error"}
    
    def identify_catalysts(self, text: str) -> list:
        """Find catalysts - keyword based + LLM"""
        text_lower = text.lower()
        
        # Quick keyword scan
        catalysts = []
        if 'order' in text_lower and 'book' in text_lower:
            catalysts.append("Order book mentioned")
        if 'new product' in text_lower or 'launch' in text_lower:
            catalysts.append("New products/launches")
        if 'expansion' in text_lower:
            catalysts.append("Expansion plans")
        if 'ev ' in text_lower or 'electric' in text_lower:
            catalysts.append("EV opportunity")
        
        return catalysts if catalysts else ["General growth initiatives"]
    
    def assess_risks(self, text: str) -> dict:
        """Assess risks - keyword based"""
        text_lower = text.lower()
        
        risks = []
        risk_map = {
            'competition': 'Competitive pressure',
            'raw material': 'Raw material costs',
            'supply chain': 'Supply chain issues',
            'demand': 'Demand uncertainty',
            'margin': 'Margin pressure',
            'debt': 'Leverage concerns'
        }
        
        for keyword, risk in risk_map.items():
            if keyword in text_lower:
                risks.append(risk)
        
        severity = "high" if len(risks) >= 4 else "moderate" if len(risks) >= 2 else "low"
        
        return {
            "risks": risks if risks else ["Standard business risks"],
            "severity": severity
        }
    
    def analyze(self, company: str, symbol: str, industry: str) -> dict:
        """Fast analysis"""
        print(f"\n{'='*70}")
        print(f"FAST ANALYSIS: {company} ({symbol})")
        print(f"Model: {self.model}")
        print(f"{'='*70}\n")
        
        print("📞 Reading concall...")
        text = self.read_concall(symbol)
        
        if not text:
            print("❌ No concall found")
            return {"error": "No concall"}
        
        print(f"   ✓ Loaded {len(text)} characters\n")
        
        print("🎯 Analyzing tone (LLM)...")
        tone = self.analyze_tone(text)
        
        print("📊 Extracting guidance (LLM)...")
        guidance = self.extract_guidance(text)
        
        print("🚀 Finding catalysts (hybrid)...")
        catalysts = self.identify_catalysts(text)
        
        print("⚠️  Assessing risks (keywords)...")
        risks = self.assess_risks(text)
        
        print("✅ Done!\n")
        
        return {
            'company': company,
            'symbol': symbol,
            'industry': industry,
            'model_used': self.model,
            'tone': tone,
            'guidance': guidance,
            'catalysts': catalysts,
            'risks': risks,
            'analyzed_at': datetime.now().isoformat()
        }
    
    def print_report(self, result: dict):
        """Print report"""
        if 'error' in result:
            print(f"❌ {result['error']}")
            return
        
        print(f"{'='*70}")
        print(f"ANALYSIS REPORT".center(70))
        print(f"{'='*70}")
        
        print(f"\n📊 {result['company']} ({result['symbol']})")
        print(f"   Industry: {result['industry']}")
        print(f"   Model: {result['model_used']}")
        
        print(f"\n{'─'*70}")
        print("🎙️  MANAGEMENT TONE")
        print(f"{'─'*70}")
        tone = result['tone']
        print(f"\n   Confidence: {tone.get('confidence', 'N/A')}/100")
        print(f"   Outlook: {tone.get('outlook', 'N/A')}/100")
        print(f"   {tone.get('summary', '')}")
        
        print(f"\n{'─'*70}")
        print("📈 GUIDANCE")
        print(f"{'─'*70}")
        guidance = result['guidance']
        print(f"\n   Revenue: {guidance.get('revenue', 'N/A')}")
        print(f"   Margin: {guidance.get('margin', 'N/A')}")
        if guidance.get('initiatives'):
            print(f"   Initiatives: {', '.join(guidance['initiatives'][:3])}")
        
        print(f"\n{'─'*70}")
        print("🚀 CATALYSTS")
        print(f"{'─'*70}\n")
        for cat in result['catalysts']:
            print(f"   ✅ {cat}")
        
        print(f"\n{'─'*70}")
        print("⚠️  RISKS")
        print(f"{'─'*70}")
        risks = result['risks']
        print(f"\n   Level: {risks['severity'].upper()}")
        for risk in risks['risks']:
            print(f"   🚩 {risk}")
        
        print(f"\n{'='*70}")
        print("💡 VERDICT")
        print(f"{'='*70}\n")
        
        if tone.get('confidence', 50) > 65:
            print("   ✅ POSITIVE outlook")
        elif tone.get('confidence', 50) > 45:
            print("   ⚠️  NEUTRAL stance")
        else:
            print("   🚩 CAUTIOUS tone")
        
        print(f"\n{'='*70}\n")


def main():
    import sys
    if sys.platform == 'win32':
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except:
            pass
    
    print("="*70)
    print("FAST CONCALL ANALYZER (Small Language Models)".center(70))
    print("="*70)
    
    print("\n📋 Recommended models:")
    print("   1. qwen2.5:1.5b  (best balance) ⭐")
    print("   2. qwen2.5:0.5b  (ultra-fast)")
    print("   3. phi3.5:mini   (good quality)")
    print("   4. tinyllama     (speed demon)\n")
    
    # Model selection
    print("Choose model:")
    print("   1. qwen2.5:1.5b (recommended)")
    print("   2. qwen2.5:0.5b (faster)")
    print("   3. phi3.5:mini")
    print("   4. Custom\n")
    
    choice = input("Enter choice (1-4) [1]: ").strip() or "1"
    
    models = {
        "1": "qwen2.5:1.5b",
        "2": "qwen2.5:0.5b",
        "3": "phi3.5:mini"
    }
    
    if choice in models:
        model = models[choice]
    else:
        model = input("Enter model name: ").strip()
    
    analyzer = FastConcallAnalyzer(model=model)
    
    print()
    company = input("Company name: ").strip()
    symbol = input("Symbol: ").strip().upper()
    industry = input("Industry: ").strip()
    
    result = analyzer.analyze(company, symbol, industry)
    analyzer.print_report(result)
    
    # Save option
    save = input("\n💾 Save? (y/n): ").strip().lower()
    if save == 'y':
        filename = f"{symbol}_{model.replace(':', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(filename, 'w') as f:
            json.dump(result, f, indent=2)
        print(f"✅ Saved: {filename}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Interrupted")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

