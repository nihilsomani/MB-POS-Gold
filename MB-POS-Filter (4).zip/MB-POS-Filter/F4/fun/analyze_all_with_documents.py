#!/usr/bin/env python3
"""
Analyze All Companies with Documents
=====================================

Analyzes ALL companies that have:
1. Composite_Score >= 60 (good fundamentals)
2. Downloaded concalls/annual reports available

No limit - analyzes all qualifying companies!
"""

import os
import re
import pandas as pd
from pathlib import Path
from typing import Dict
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


def extract_pdf_text(pdf_path: str) -> str:
    """Extract text from PDF"""
    try:
        import PyPDF2
        text = ""
        with open(pdf_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                text += page.extract_text() + "\n"
        return text
    except Exception as e:
        logger.error(f"   Error reading PDF: {e}")
        return ""


def analyze_document_quality(text: str) -> Dict:
    """
    Analyze document with analyst perspective - Enhanced version
    Looks at: Strategic Updates, Guidance, Earning Triggers, Management Consistency
    """
    
    if not text or len(text) < 100:
        return {'score': 50, 'insights': [], 'breakdown': {}}
    
    text_lower = text.lower()
    insights = []
    breakdown = {}
    
    # === 1. MANAGEMENT QUALITY (-50 to +50) ===
    mgmt_score = 0
    
    # Capital Allocation Language (+20)
    capital_keywords = ['capital allocation', 'roce', 'roic', 'free cash flow', 
                      'fcf', 'buyback', 'shareholder value', 'return on capital']
    cap_count = sum(text_lower.count(k) for k in capital_keywords)
    
    if cap_count > 10:
        mgmt_score += 20
        insights.append("✅ Capital-focused management")
    elif cap_count > 5:
        mgmt_score += 10
    
    # Transparency (+15)
    transparency = ['challenge', 'headwind', 'admitted', 'acknowledged', 
                   'difficult', 'setback', 'temporary']
    trans_count = sum(text_lower.count(k) for k in transparency)
    
    if trans_count > 5:
        mgmt_score += 15
        insights.append("✅ Transparent - acknowledges challenges")
    elif trans_count > 2:
        mgmt_score += 8
    
    # Execution Track Record (+15)
    execution = ['achieved', 'delivered', 'completed', 'exceeded', 
                'commissioned', 'launched', 'executed']
    exec_count = sum(text_lower.count(k) for k in execution)
    
    if exec_count > 8:
        mgmt_score += 15
        insights.append("✅ Strong execution track record")
    elif exec_count > 4:
        mgmt_score += 8
    
    # Excuse-Making (-20)
    excuses = ['external factors', 'macroeconomic', 'geopolitical', 
              'beyond our control', 'market conditions']
    excuse_count = sum(text_lower.count(k) for k in excuses)
    
    if excuse_count > 5:
        mgmt_score -= 20
        insights.append("🚩 Excessive excuse-making")
    elif excuse_count > 2:
        mgmt_score -= 10
    
    # Accounting Red Flags (-25)
    accounting_flags = ['one-time charge', 'exceptional item', 'goodwill impairment',
                      'restructuring charge', 'write-off', 'provision']
    accounting_count = sum(text_lower.count(k) for k in accounting_flags)
    
    if accounting_count > 3:
        mgmt_score -= 25
        insights.append("🚩 Multiple one-time charges (red flag)")
    elif accounting_count > 1:
        mgmt_score -= 10
    
    breakdown['management'] = max(-50, min(50, mgmt_score))
    
    # === 2. STRATEGIC UPDATES (0 to +20) ===
    strategy_score = 0
    
    # Strategic Initiatives (+10)
    strategy_keywords = ['new product launch', 'market expansion', 'capacity expansion',
                       'digital transformation', 'automation', 'technology upgrade',
                       'new facility', 'greenfield', 'brownfield']
    strategy_count = sum(text_lower.count(k) for k in strategy_keywords)
    
    if strategy_count > 3:
        strategy_score += 10
        insights.append("✅ Clear strategic initiatives outlined")
    elif strategy_count > 1:
        strategy_score += 5
    
    # Geographic/Market Expansion (+5)
    expansion_keywords = ['international expansion', 'export growth', 'new markets',
                        'market share gain', 'penetration']
    expansion_count = sum(text_lower.count(k) for k in expansion_keywords)
    
    if expansion_count > 2:
        strategy_score += 5
        insights.append("✅ Geographic/market expansion plans")
    
    # Innovation/R&D (+5)
    innovation_keywords = ['r&d', 'research and development', 'innovation', 
                         'patent', 'new technology', 'product pipeline']
    innovation_count = sum(text_lower.count(k) for k in innovation_keywords)
    
    if innovation_count > 3:
        strategy_score += 5
        insights.append("✅ Strong R&D/innovation focus")
    
    breakdown['strategic_updates'] = strategy_score
    
    # === 3. GUIDANCE & OUTLOOK (-15 to +20) ===
    guidance_score = 0
    
    # Extract Quantitative Revenue Growth Guidance (+15)
    revenue_patterns = [
        r'fy\d{2,4}.*?revenue.*?(\d{1,2})%',
        r'revenue.*?growth.*?(\d{1,2})%',
        r'guided.*?(\d{1,2})%.*?growth',
        r'targeting.*?(\d{1,2})%.*?revenue',
        r'growth.*?(\d{1,2})%\+'
    ]
    
    revenue_guidance = []
    for pattern in revenue_patterns:
        matches = re.findall(pattern, text_lower)
        revenue_guidance.extend([int(m) for m in matches if m.isdigit()])
    
    if revenue_guidance:
        max_guidance = max(revenue_guidance)
        if max_guidance >= 25:
            guidance_score += 15
            insights.append(f"✅ Strong revenue guidance ({max_guidance}%+ growth)")
        elif max_guidance >= 15:
            guidance_score += 10
            insights.append(f"✅ Positive revenue guidance ({max_guidance}% growth)")
        elif max_guidance >= 10:
            guidance_score += 5
    
    # Profitability Guidance (+15)
    profitability_patterns = [
        r'return to profitability', r'positive ebitda', r'breakeven',
        r'profitable.*?(?:by|in|from)', r'expect.*?profitable'
    ]
    
    for pattern in profitability_patterns:
        if re.search(pattern, text_lower):
            guidance_score += 12
            insights.append("✅ Profitability expected")
            break
    
    # Margin Expansion (+10)
    margin_patterns = [
        r'ebitda.*?margin.*?(\d{1,2})[–-](\d{1,2})%',
        r'margin.*?improv.*?(\d{1,2})%',
        r'margin.*?target.*?(\d{1,2})%',
        r'targeting.*?(\d{1,2})%.*?margin'
    ]
    
    margin_found = False
    for pattern in margin_patterns:
        matches = re.findall(pattern, text_lower)
        if matches:
            if isinstance(matches[0], tuple):
                margin_high = int(matches[0][1])
                if margin_high >= 25:
                    guidance_score += 10
                    insights.append(f"✅ Strong margin guidance ({matches[0][0]}-{matches[0][1]}%)")
                    margin_found = True
                    break
            elif matches[0].isdigit() and int(matches[0]) >= 20:
                guidance_score += 5
                margin_found = True
                break
    
    if not margin_found and sum(text_lower.count(k) for k in ['margin improvement', 'margins improving']) > 2:
        guidance_score += 5
        insights.append("✅ Margin improvement expected")
    
    # Debt Reduction Roadmap (+10)
    if any(k in text_lower for k in ['debt free by', 'debt-free by', 'debt reduction plan', 'deleveraging roadmap']):
        guidance_score += 10
        insights.append("✅ Debt reduction roadmap outlined")
    
    # Balance Sheet Strength (+5)
    balance_sheet_patterns = [
        r'net cash.*?₹?(\d+\.?\d*)\s*bn',
        r'debt free',
        r'zero debt',
        r'cash.*?₹?(\d+\.?\d*)\s*bn'
    ]
    
    for pattern in balance_sheet_patterns:
        if re.search(pattern, text_lower):
            guidance_score += 5
            insights.append("✅ Strong balance sheet (net cash/low debt)")
            break
    
    # Negative Guidance (-15)
    negative_guidance = ['guidance cut', 'lowered guidance', 'downgraded outlook',
                       'expect weakness', 'expect decline', 'challenging outlook']
    neg_count = sum(text_lower.count(k) for k in negative_guidance)
    
    if neg_count > 2:
        guidance_score -= 15
        insights.append("🚩 Guidance cut or negative outlook")
    elif neg_count > 0:
        guidance_score -= 8
    
    breakdown['guidance_outlook'] = guidance_score
    
    # === 4. EARNING TRIGGERS (0 to +40) - ORDER BOOK HEAVILY WEIGHTED! ===
    triggers_score = 0
    
    # Order Book Size - Quantified (+15)
    orderbook_patterns = [
        r'order\s+book.*?₹?(\d+\.?\d*)\s*(?:cr|bn)',
        r'backlog.*?₹?(\d+\.?\d*)\s*(?:cr|bn)'
    ]
    
    orderbook_value = []
    for pattern in orderbook_patterns:
        matches = re.findall(pattern, text_lower)
        orderbook_value.extend([float(m) for m in matches if m])
    
    if orderbook_value:
        triggers_score += 15
        insights.append(f"💰 Order book ₹{max(orderbook_value):.0f} Cr (visibility)")
    
    # Order Book Growth (+15)
    if re.search(r'order\s+book.*?(?:all.time.high|record|highest)', text_lower):
        triggers_score += 15
        insights.append("🚀 Order book at all-time high")
    elif re.search(r'order\s+book.*?(?:increased|grew).*?(\d+\.?\d*)x', text_lower):
        triggers_score += 15
        insights.append("🚀 Order book surged (multi-bagger growth)")
    
    # Revenue Visibility (+10)
    visibility_patterns = [r'(?:visibility|booked).*?(\d+)\s*(?:quarters?|months?)']
    visibility = []
    for pattern in visibility_patterns:
        matches = re.findall(pattern, text_lower)
        visibility.extend([int(m) for m in matches if m.isdigit()])
    
    if visibility and max(visibility) >= 6:
        triggers_score += 10
        insights.append(f"✅ Revenue visibility ({max(visibility)} months)")
    
    # Fallback: Generic order book mentions
    if not orderbook_value:
        contract_count = sum(text_lower.count(k) for k in ['order book', 'order intake', 'contract win'])
        if contract_count > 3:
            triggers_score += 8
            insights.append("✅ Order book mentioned")
    
    # Capacity Utilization/Expansion (+8)
    capacity_keywords = ['capacity utilization', 'operating at.*%', 'full capacity',
                       'capacity addition', 'ramp up', 'scaling up']
    capacity_count = sum(text_lower.count(k) for k in capacity_keywords)
    
    if capacity_count > 2:
        triggers_score += 8
        insights.append("✅ Capacity expansion/high utilization")
    elif capacity_count > 0:
        triggers_score += 4
    
    # Product Launches (+7)
    product_keywords = ['new product', 'product launch', 'product pipeline',
                      'product portfolio', 'new offering']
    product_count = sum(text_lower.count(k) for k in product_keywords)
    
    if product_count > 2:
        triggers_score += 7
        insights.append("✅ New product launches/strong pipeline")
    elif product_count > 0:
        triggers_score += 3
    
    breakdown['earning_triggers'] = triggers_score
    
    # === 5. MANAGEMENT CONSISTENCY (-20 to +20) ===
    consistency_score = 0
    
    # Meeting Commitments (+20)
    delivery_keywords = ['as committed', 'as promised', 'as guided', 'delivered on',
                       'met our guidance', 'achieved our target', 'on track']
    delivery_count = sum(text_lower.count(k) for k in delivery_keywords)
    
    if delivery_count > 3:
        consistency_score += 20
        insights.append("✅ Consistently delivers on commitments")
    elif delivery_count > 1:
        consistency_score += 10
    
    # Missing Commitments (-20)
    miss_keywords = ['missed guidance', 'fell short', 'did not achieve', 
                    'below guidance', 'delayed from original']
    miss_count = sum(text_lower.count(k) for k in miss_keywords)
    
    if miss_count > 2:
        consistency_score -= 20
        insights.append("🚩 Frequently misses commitments")
    elif miss_count > 0:
        consistency_score -= 10
    
    # Changing Narrative (-10)
    narrative_keywords = ['revised approach', 'change in strategy', 'different from',
                        'pivoting', 'reconsidering']
    narrative_count = sum(text_lower.count(k) for k in narrative_keywords)
    
    if narrative_count > 3:
        consistency_score -= 10
        insights.append("⚠️ Frequently changing narrative")
    
    breakdown['consistency'] = consistency_score
    
    # === 6. QUARTERLY MOMENTUM (-10 to +20) ===
    # (Copy logic from integrated_analyzer.py)
    momentum_score = 0
    
    sequential_keywords = ['sequentially', 'quarter-on-quarter', 'qoq', 'q-o-q']
    seq_count = sum(text_lower.count(k) for k in sequential_keywords)
    
    qoq_patterns = [r'sequential.*?growth.*?(\d{1,2})%', r'qoq.*?(\d{1,2})%']
    qoq_growth = []
    for pattern in qoq_patterns:
        matches = re.findall(pattern, text_lower)
        qoq_growth.extend([int(m) for m in matches if m.isdigit()])
    
    if qoq_growth and max(qoq_growth) > 10:
        momentum_score += 15
        insights.append(f"🚀 Strong QoQ momentum ({max(qoq_growth)}%)")
    elif seq_count > 2:
        momentum_score += 8
    
    inflection_keywords = ['inflection', 'turning point', 'momentum building', 'acceleration']
    if sum(text_lower.count(k) for k in inflection_keywords) > 2:
        momentum_score += 10
        insights.append("✅ Inflection point identified")
    
    breakdown['momentum'] = momentum_score
    
    # === 7. FORWARD CONFIDENCE (-15 to +20) ===
    confidence_score = 0
    
    confidence_keywords = ['confident', 'well positioned', 'optimistic', 'strong visibility']
    conf_count = sum(text_lower.count(k) for k in confidence_keywords)
    
    if conf_count > 8:
        confidence_score += 20
        insights.append("✅ Management highly confident")
    elif conf_count > 4:
        confidence_score += 12
    
    breakdown['confidence'] = confidence_score
    
    # === 8. SECTOR TAILWINDS (0 to +15) ===
    tailwind_score = 0
    
    govt_keywords = ['pli scheme', 'government support', 'make in india']
    if sum(text_lower.count(k) for k in govt_keywords) > 2:
        tailwind_score += 10
        insights.append("✅ Government support/PLI")
    
    demand_keywords = ['structural demand', 'secular growth', 'industry tailwind']
    if sum(text_lower.count(k) for k in demand_keywords) > 2:
        tailwind_score += 8
        insights.append("✅ Structural tailwinds")
    
    breakdown['tailwinds'] = tailwind_score
    
    # === 9. DEBT TRAJECTORY (-10 to +15) ===
    debt_score = 0
    
    if sum(text_lower.count(k) for k in ['debt reduction', 'deleveraging']) > 2:
        debt_score += 10
        insights.append("✅ Active deleveraging")
    
    breakdown['debt_trajectory'] = debt_score
    
    # === 10. PREMIUMIZATION (0 to +15) ===
    premium_score = 0
    
    premium_keywords = ['premiumization', 'premium segment', 'moving upmarket']
    if sum(text_lower.count(k) for k in premium_keywords) > 2:
        premium_score += 15
        insights.append("✅ Premiumization strategy")
    
    breakdown['premiumization'] = premium_score
    
    # === 11. TRANSFORMATION (0 to +25) ===
    transform_score = 0
    
    divest_keywords = ['divest', 'divestiture', 'sold business', 'exited', 'asset sale']
    if sum(text_lower.count(k) for k in divest_keywords) > 2:
        transform_score += 10
        insights.append("✅ Divestiture/simplification")
    
    leadership_keywords = ['new ceo', 'new management', 'leadership change']
    if sum(text_lower.count(k) for k in leadership_keywords) > 0:
        transform_score += 8
        insights.append("✅ New leadership")
    
    pivot_keywords = ['strategic pivot', 'repositioning', 'transformation']
    if sum(text_lower.count(k) for k in pivot_keywords) > 2:
        transform_score += 10
        insights.append("✅ Strategic transformation")
    
    breakdown['transformation'] = transform_score
    
    # === CALCULATE TOTAL SCORE (ENHANCED - FORWARD FOCUSED) ===
    total_score = (50 
                  + breakdown['management']         # -50 to +50
                  + breakdown['strategic_updates']  # 0 to +20
                  + breakdown['guidance_outlook']   # -15 to +25
                  + breakdown['earning_triggers']   # 0 to +40 (ENHANCED - order book!)
                  + breakdown['consistency']        # -20 to +20
                  + breakdown['momentum']           # -10 to +20 (NEW)
                  + breakdown['confidence']         # -15 to +20 (NEW)
                  + breakdown['tailwinds']          # 0 to +15 (NEW)
                  + breakdown['debt_trajectory']    # -10 to +15 (NEW)
                  + breakdown['premiumization']     # 0 to +15 (NEW)
                  + breakdown['transformation'])    # 0 to +25 (NEW)
    
    # Theoretical max: 50 + 50 + 20 + 25 + 40 + 20 + 20 + 20 + 15 + 15 + 15 + 25 = 315
    # Allow scores >100 for exceptional forward momentum
    
    return {
        'score': max(0, total_score),  # No upper cap - let exceptional cases shine!
        'insights': insights,
        'word_count': len(text.split()),
        'breakdown': breakdown
    }


def analyze_all_companies_with_documents():
    """Analyze all companies with score >= 60 and available documents"""
    
    logger.info("=" * 80)
    logger.info("ANALYZING ALL COMPANIES WITH DOCUMENTS (Score >= 60)")
    logger.info("=" * 80)
    
    # Load financial scan
    financial_csv = "output/financial_scan_20251016_121356.csv"
    if not os.path.exists(financial_csv):
        # Try alternate file
        import glob
        files = glob.glob("output/financial_scan_*.csv")
        if files:
            financial_csv = files[0]
        else:
            logger.error("❌ Financial scan file not found")
            return None
    
    df_financial = pd.read_csv(financial_csv)
    logger.info(f"\n✅ Loaded financial data: {len(df_financial)} companies")
    
    # Don't filter by score - analyze ALL companies with documents
    # (Documents might reveal hidden gems with lower quant scores!)
    qualified = df_financial  # Use all companies
    logger.info(f"   Analyzing ALL companies (no score filter)")
    
    # Get available documents
    concalls_dir = "downloads/concalls"
    reports_dir = "downloads/annual_reports"
    
    concalls = {f.stem.replace('_Concall', ''): f for f in Path(concalls_dir).glob("*.pdf")}
    reports = {f.stem.split('_')[0]: f for f in Path(reports_dir).glob("*.pdf")}
    
    logger.info(f"   Total concalls available: {len(concalls)}")
    logger.info(f"   Total reports available: {len(reports)}")
    
    # Find qualified companies with documents
    qualified_companies = qualified['Company'].tolist()
    companies_with_docs = [c for c in qualified_companies if c in concalls or c in reports]
    
    logger.info(f"\n🎯 Companies to analyze (Score ≥60 + Has documents): {len(companies_with_docs)}")
    
    if not companies_with_docs:
        logger.warning("❌ No qualifying companies with documents found")
        return None
    
    logger.info("\nStarting analysis...")
    logger.info("=" * 80)
    
    # Analyze each company
    results = []
    
    for i, company in enumerate(companies_with_docs, 1):
        logger.info(f"\n[{i}/{len(companies_with_docs)}] {company}")
        
        # Get financial data
        company_data = qualified[qualified['Company'] == company].iloc[0]
        
        # Analyze documents
        concall_score = 50
        report_score = 50
        concall_analyzed = False
        report_analyzed = False
        all_insights = []
        
        # Analyze concall
        if company in concalls:
            concall_path = concalls[company]
            logger.info(f"   📄 Reading concall...")
            text = extract_pdf_text(str(concall_path))
            
            if text and len(text) > 100:
                analysis = analyze_document_quality(text)
                concall_score = analysis['score']
                concall_analyzed = True
                all_insights.extend(analysis['insights'])
                breakdown = analysis.get('breakdown', {})
                
                logger.info(f"      ✅ Analyzed ({analysis['word_count']:,} words) - Score: {concall_score:.1f}")
                if breakdown:
                    logger.info(f"      📈 Breakdown: Mgmt{breakdown.get('management', 0):+d} | Strategy{breakdown.get('strategic_updates', 0):+d} | Guidance{breakdown.get('guidance_outlook', 0):+d} | Triggers{breakdown.get('earning_triggers', 0):+d} | Consistency{breakdown.get('consistency', 0):+d}")
        
        # Analyze report
        if company in reports:
            report_path = reports[company]
            logger.info(f"   📄 Reading annual report...")
            text = extract_pdf_text(str(report_path))
            
            if text and len(text) > 100:
                analysis = analyze_document_quality(text)
                report_score = analysis['score']
                report_analyzed = True
                all_insights.extend(analysis['insights'])
                breakdown = analysis.get('breakdown', {})
                
                logger.info(f"      ✅ Analyzed ({analysis['word_count']:,} words) - Score: {report_score:.1f}")
                if breakdown:
                    logger.info(f"      📈 Breakdown: Mgmt{breakdown.get('management', 0):+d} | Strategy{breakdown.get('strategic_updates', 0):+d} | Guidance{breakdown.get('guidance_outlook', 0):+d} | Triggers{breakdown.get('earning_triggers', 0):+d} | Consistency{breakdown.get('consistency', 0):+d}")
        
        # Calculate combined qualitative score
        if concall_analyzed and report_analyzed:
            qual_score = (concall_score * 0.6 + report_score * 0.4)
        elif concall_analyzed:
            qual_score = concall_score
        elif report_analyzed:
            qual_score = report_score
        else:
            qual_score = 50
        
        # Calculate integrated score (60% quant, 40% qual)
        quant_score = company_data['Composite_Score']
        integrated_score = (quant_score * 0.6) + (qual_score * 0.4)
        
        logger.info(f"   📊 Quant: {quant_score:.2f} | Qual: {qual_score:.2f} | Integrated: {integrated_score:.2f}")
        
        # Store result
        result = {
            'Company': company,
            'Original_Rank': company_data['Rank'],
            'Quantitative_Score': quant_score,
            'Qualitative_Score': round(qual_score, 2),
            'Integrated_Score': round(integrated_score, 2),
            
            'Concall_Analyzed': concall_analyzed,
            'Report_Analyzed': report_analyzed,
            'Concall_Score': round(concall_score, 2),
            'Report_Score': round(report_score, 2),
            
            # Financial metrics
            'OPM_%': company_data['OPM_%'],
            'ROE_%': company_data['ROE_%'],
            'Sales_CAGR_5Y_%': company_data['Sales_CAGR_5Y_%'],
            'Debt_Equity': company_data['Debt_Equity'],
            'Red_Flag_Count': company_data['Red_Flag_Count'],
            
            # Category scores
            'Balance_Sheet_Score': company_data['Balance_Sheet_Score'],
            'Operational_Score': company_data['Operational_Score'],
            'Growth_Score': company_data['Growth_Score'],
            'Cash_Flow_Score': company_data['Cash_Flow_Score'],
            
            'Key_Insights': ' | '.join(all_insights[:3]) if all_insights else ''
        }
        
        results.append(result)
    
    # Create DataFrame and rank
    df = pd.DataFrame(results)
    df = df.sort_values('Integrated_Score', ascending=False)
    df['Final_Rank'] = range(1, len(df) + 1)
    
    # Save
    timestamp = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"complete_analysis_{timestamp}.csv"
    df.to_csv(output_file, index=False, encoding='utf-8-sig')
    
    # Display results
    logger.info("\n" + "=" * 80)
    logger.info("✅ ANALYSIS COMPLETE!")
    logger.info("=" * 80)
    logger.info(f"\n📊 Summary:")
    logger.info(f"   Total companies analyzed: {len(df)}")
    logger.info(f"   With concalls: {df['Concall_Analyzed'].sum()}")
    logger.info(f"   With reports: {df['Report_Analyzed'].sum()}")
    logger.info(f"   Average Qual Score: {df['Qualitative_Score'].mean():.2f}")
    logger.info(f"   Average Integrated Score: {df['Integrated_Score'].mean():.2f}")
    
    logger.info(f"\n🏆 TOP 15 BY INTEGRATED SCORE:")
    logger.info("-" * 80)
    
    for idx, (_, row) in enumerate(df.head(15).iterrows(), 1):
        docs = []
        if row['Concall_Analyzed']:
            docs.append('C')
        if row['Report_Analyzed']:
            docs.append('R')
        docs_str = '+'.join(docs) if docs else 'None'
        
        logger.info(f"{idx:2d}. {row['Company']:<15} Score: {row['Integrated_Score']:5.2f} "
                   f"(Q:{row['Quantitative_Score']:5.2f} + Qual:{row['Qualitative_Score']:5.2f}) "
                   f"[{docs_str}]")
    
    logger.info(f"\n📁 Results saved: {output_file}")
    logger.info(f"\n💡 Open in Excel and sort by 'Integrated_Score' to see final rankings!")
    logger.info("=" * 80)
    
    return df


if __name__ == "__main__":
    print("\n" + "🤖 " * 35)
    print("\nINTELLIGENT ANALYZER - All Qualified Companies")
    print("Analyzing ALL companies with Score ≥60 AND available documents")
    print("\n" + "🤖 " * 35)
    
    # Check PyPDF2
    try:
        import PyPDF2
    except ImportError:
        print("\n❌ PyPDF2 not installed. Installing...")
        import subprocess, sys
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'PyPDF2', '--quiet'])
        print("✅ PyPDF2 installed!")
    
    print("\n⏱️ Estimated time: 3-5 minutes (analyzing ~100+ PDFs)")
    input("\nPress Enter to start analysis...")
    
    # Run analysis
    df = analyze_all_companies_with_documents()
    
    if df is not None:
        print("\n✅ SUCCESS! Check the CSV file for complete rankings!")

