#!/usr/bin/env python3
"""
Comprehensive Financial Scanner & Analyzer
===========================================

A unified, sophisticated financial analysis framework that scans and evaluates companies using:
- Balance Sheet Quality: debt levels, cash reserves, asset efficiency
- Operational Excellence: margins, profitability, consistency
- Growth Dynamics: revenue/profit CAGR, scalability indicators
- Cash Flow Strength: operating cash flow quality and trends
- Turnaround Signals: quarterly momentum, margin recovery
- Risk Assessment: comprehensive red flag identification
- Valuation Context: sector-relative metrics

Author: Consolidated Financial Analysis Framework
Date: 2025-10-16
"""

import pandas as pd
import numpy as np
import os
import glob
import warnings
from datetime import datetime
import json
from typing import Dict, List, Tuple, Any, Optional
import logging

warnings.filterwarnings('ignore')

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class FinancialScanner:
    """
    Comprehensive financial scanner for multi-dimensional company analysis
    """
    
    def __init__(
        self,
        data_dir: str = "output",
        config: Optional[Dict] = None,
        market_data_file: Optional[str] = None,
        auto_detect_market_data: bool = True,
    ):
        """
        Initialize the financial scanner
        
        Args:
            data_dir: Directory containing financial data
            config: Optional configuration dictionary for customizing analysis weights
        """
        self.data_dir = data_dir
        self.companies = []
        self.analysis_results = []
        self.market_data_file = market_data_file
        self.auto_detect_market_data = auto_detect_market_data
        self.market_data_by_symbol: Dict[str, Dict[str, float]] = {}
        self.market_data_by_name: Dict[str, Dict[str, float]] = {}
        self.market_data_by_normalized: Dict[str, Dict[str, float]] = {}
        self.market_data_source: Optional[str] = None
        
        # Default configuration - can be overridden
        self.config = config or {
            'weights': {
                'balance_sheet': 0.15,
                'operational': 0.20,
                'growth': 0.15,
                'cash_flow': 0.25,  # Increased - Khemka's priority
                'working_capital': 0.15,  # NEW - Khemka Framework
                'turnaround': 0.10
            },
            'thresholds': {
                'excellent_opm': 20,
                'good_opm': 15,
                'excellent_roe': 20,
                'good_roe': 15,
                'high_debt_equity': 1.0,
                'low_liquidity': 1.0,
                'high_cagr': 20,
                'good_cagr': 15,
                'strong_qoq': 10,
                'good_qoq': 5
            },
            'red_flag_penalty': 10
        }

        self._initialize_market_data()
    
    def _normalize_company_key(self, value: Optional[str]) -> str:
        if not value or (isinstance(value, float) and np.isnan(value)):
            return ""
        return "".join(ch.lower() for ch in str(value) if ch.isalnum())

    def _initialize_market_data(self) -> None:
        try:
            market_entries = self._load_market_data()
            if not market_entries:
                return

            for entry in market_entries:
                self._record_market_entry(entry)

            total_entries = len(self.market_data_by_symbol) or len(self.market_data_by_normalized)
            if total_entries:
                logger.info(
                    f"Loaded market data for {total_entries} companies "
                    f"from {self.market_data_source}"
                )
        except Exception as exc:
            logger.warning(f"Unable to initialize market data: {exc}")

    def _load_market_data(self) -> List[Dict[str, Any]]:
        """
        Load market data (market cap, enterprise value, etc.) from the latest scraper output.
        """
        candidate_paths: List[str] = []

        if self.market_data_file and os.path.exists(self.market_data_file):
            candidate_paths.append(self.market_data_file)

        if self.auto_detect_market_data:
            base_dir = os.path.dirname(os.path.abspath(__file__))
            default_pattern = os.path.join(base_dir, "screener-scrapper", "output", "stage2_shortlist_*.csv")
            candidate_paths.extend(sorted(glob.glob(default_pattern)))

            # Also look in the workspace root relative to data_dir for convenience
            alt_pattern = os.path.join(self.data_dir, "stage2_shortlist_*.csv")
            candidate_paths.extend(sorted(glob.glob(alt_pattern)))

        # Deduplicate while keeping order (latest files presumed last in sorted list)
        seen = set()
        unique_paths = []
        for path in reversed(candidate_paths):  # prefer the most recent first
            if path not in seen and os.path.exists(path):
                unique_paths.append(path)
                seen.add(path)

        if not unique_paths:
            logger.info("No market data files detected for valuation metrics")
            return []

        selected_path = unique_paths[0]
        try:
            df = pd.read_csv(selected_path)
            df.columns = [col.strip().lower() for col in df.columns]
        except Exception as exc:
            logger.warning(f"Failed to load market data from {selected_path}: {exc}")
            return []

        self.market_data_source = selected_path

        entries: List[Dict[str, Any]] = []
        for _, row in df.iterrows():
            entry: Dict[str, Any] = {}

            symbol = (
                row.get('symbol')
                or row.get('ticker')
                or row.get('nse_symbol')
                or row.get('company_symbol')
                or row.get('nse_code')
            )
            company_name = (
                row.get('company_name')
                or row.get('name')
                or row.get('company')
            )

            entry['symbol'] = str(symbol).strip().upper() if symbol else ""
            entry['company_name'] = str(company_name).strip() if company_name else ""
            entry['market_cap'] = self.parse_financial_value(row.get('market_cap', 0))
            entry['enterprise_value'] = self.parse_financial_value(row.get('enterprise_value', 0))
            entry['current_price'] = self.parse_financial_value(row.get('current_price', 0))
            entry['promoter_holding'] = self.parse_financial_value(row.get('promoter_holding', 0))
            entry['latest_fcf'] = self.parse_financial_value(row.get('latest_fcf', 0))
            entry['avg_fcf_3y'] = self.parse_financial_value(row.get('avg_fcf_3y', 0))

            entries.append(entry)

        return entries

    def _record_market_entry(self, entry: Dict[str, Any]) -> None:
        if not entry:
            return

        data = {
            'market_cap': entry.get('market_cap', 0.0),
            'enterprise_value': entry.get('enterprise_value', 0.0),
            'current_price': entry.get('current_price', 0.0),
            'promoter_holding': entry.get('promoter_holding', 0.0),
            'latest_fcf': entry.get('latest_fcf', 0.0),
            'avg_fcf_3y': entry.get('avg_fcf_3y', 0.0),
            'company_name': entry.get('company_name', ""),
        }

        symbol = entry.get('symbol', "")
        company_name = entry.get('company_name', "")
        normalized_symbol = self._normalize_company_key(symbol)
        normalized_name = self._normalize_company_key(company_name)

        if symbol:
            self.market_data_by_symbol[symbol.upper()] = data
        if company_name:
            self.market_data_by_name[company_name.lower()] = data
        if normalized_symbol:
            self.market_data_by_normalized[normalized_symbol] = data
        if normalized_name:
            self.market_data_by_normalized[normalized_name] = data

    def _lookup_market_data(self, company_symbol: str, fallback_name: Optional[str] = None) -> Optional[Dict[str, Any]]:
        if not (self.market_data_by_symbol or self.market_data_by_normalized or self.market_data_by_name):
            return None

        if company_symbol:
            symbol_key = company_symbol.upper()
            if symbol_key in self.market_data_by_symbol:
                return self.market_data_by_symbol[symbol_key]

            normalized_symbol = self._normalize_company_key(company_symbol)
            if normalized_symbol in self.market_data_by_normalized:
                return self.market_data_by_normalized[normalized_symbol]

        if fallback_name:
            lower_name = fallback_name.lower()
            if lower_name in self.market_data_by_name:
                return self.market_data_by_name[lower_name]

            normalized_name = self._normalize_company_key(fallback_name)
            if normalized_name in self.market_data_by_normalized:
                return self.market_data_by_normalized[normalized_name]

        return None

    def _enrich_with_market_data(self, company_symbol: str, metrics: Dict[str, Any]) -> None:
        market_entry = self._lookup_market_data(company_symbol, metrics.get('company_name'))
        if not market_entry:
            return

        ocf = metrics.get('operating_cash_flow', 0.0)
        normalized_ocf = metrics.get('normalized_ocf', 0.0)
        fcf = metrics.get('free_cash_flow', 0.0)

        market_cap = market_entry.get('market_cap', 0.0)
        enterprise_value = market_entry.get('enterprise_value', 0.0)
        current_price = market_entry.get('current_price', 0.0)
        latest_fcf = market_entry.get('latest_fcf', 0.0)
        promoter_holding = market_entry.get('promoter_holding', 0.0)
        avg_fcf_3y = market_entry.get('avg_fcf_3y', 0.0)

        if market_cap > 0:
            metrics['market_cap'] = market_cap
            if ocf > 0:
                metrics['ocf_yield_pct'] = (ocf / market_cap) * 100
                metrics['price_to_ocf'] = market_cap / ocf
            if normalized_ocf and normalized_ocf > 0:
                metrics['normalized_ocf_yield_pct'] = (normalized_ocf / market_cap) * 100
                metrics['price_to_normalized_ocf'] = market_cap / normalized_ocf
            if fcf > 0:
                metrics['price_to_fcf'] = market_cap / fcf
                metrics['fcf_yield_pct'] = (fcf / market_cap) * 100
            if latest_fcf and latest_fcf > 0:
                metrics['price_to_fcf_scraper'] = market_cap / latest_fcf
                metrics['fcf_yield_pct_scraper'] = (latest_fcf / market_cap) * 100
            if avg_fcf_3y and avg_fcf_3y > 0:
                metrics['fcf_yield_pct_avg_3y'] = (avg_fcf_3y / market_cap) * 100

        if enterprise_value > 0:
            metrics['enterprise_value'] = enterprise_value
            if ocf > 0:
                metrics['ev_to_ocf'] = enterprise_value / ocf
            if normalized_ocf and normalized_ocf > 0:
                metrics['ev_to_normalized_ocf'] = enterprise_value / normalized_ocf

        if current_price > 0:
            metrics['market_price'] = current_price

        if promoter_holding:
            metrics['promoter_holding'] = promoter_holding

        if self.market_data_source:
            metrics['market_data_source'] = self.market_data_source

    def load_company_data(self, company_symbol: str) -> Optional[Dict[str, pd.DataFrame]]:
        """Load all financial data for a company"""
        try:
            data = {}
            
            # Load P&L data
            pnl_file = os.path.join(self.data_dir, "pnl_data", f"{company_symbol}_pnl.csv")
            if os.path.exists(pnl_file):
                data['pnl'] = pd.read_csv(pnl_file)
            
            # Load Balance Sheet data
            bs_file = os.path.join(self.data_dir, "balance_sheet_data", f"{company_symbol}_balance_sheet.csv")
            if os.path.exists(bs_file):
                data['balance_sheet'] = pd.read_csv(bs_file)
            
            # Load Cash Flow data
            cf_file = os.path.join(self.data_dir, "cash_flow_data", f"{company_symbol}_cash_flow.csv")
            if os.path.exists(cf_file):
                data['cash_flow'] = pd.read_csv(cf_file)
            
            # Load Quarterly data
            q_file = os.path.join(self.data_dir, "quarterly_data", f"{company_symbol}_quarterly.csv")
            if os.path.exists(q_file):
                data['quarterly'] = pd.read_csv(q_file)
            
            return data if data else None
            
        except Exception as e:
            logger.error(f"Error loading data for {company_symbol}: {e}")
            return None
    
    def parse_financial_value(self, value) -> float:
        """
        Robust financial value parser handling multiple formats
        
        Handles: commas, quotes, percentages, parentheses (negative), nulls
        """
        if pd.isna(value) or value == '' or value == '-':
            return 0.0
        
        # Already numeric
        if isinstance(value, (int, float)):
            return float(value)
        
        # String processing
        value_str = str(value).strip()
        
        # Remove common formatting
        value_str = value_str.replace('"', '').replace(',', '').replace('₹', '').replace('%', '')
        
        # Handle parentheses as negative
        if value_str.startswith('(') and value_str.endswith(')'):
            value_str = '-' + value_str[1:-1]
        
        try:
            return float(value_str)
        except (ValueError, TypeError):
            return 0.0
    
    def extract_metric_value(self, df: pd.DataFrame, metric_name: str, 
                           year: str = 'Mar 2024') -> float:
        """
        Extract metric value with intelligent column selection
        
        Prefers _raw columns if available for more accurate values
        """
        try:
            metric_row = df[df['metric'] == metric_name]
            if metric_row.empty:
                return 0.0
            
            # Try raw column first
            raw_col = f"{year}_raw"
            if raw_col in metric_row.columns:
                value = metric_row[raw_col].iloc[0]
            elif year in metric_row.columns:
                value = metric_row[year].iloc[0]
            else:
                return 0.0
            
            return self.parse_financial_value(value)
            
        except Exception as e:
            logger.debug(f"Error extracting {metric_name} for {year}: {e}")
            return 0.0
    
    def extract_time_series(self, df: pd.DataFrame, metric_name: str,
                           years: List[str]) -> List[float]:
        """Extract a time series of values for trend analysis"""
        values = []
        for year in years:
            value = self.extract_metric_value(df, metric_name, year)
            values.append(value)
        return values
    
    def calculate_cagr(self, start_value: float, end_value: float, 
                       periods: int) -> float:
        """Calculate Compound Annual Growth Rate"""
        if start_value <= 0 or end_value <= 0 or periods <= 0:
            return 0.0
        try:
            return ((end_value / start_value) ** (1 / periods) - 1) * 100
        except:
            return 0.0
    
    def calculate_financial_metrics(self, data: Dict[str, pd.DataFrame], company_symbol: str) -> Dict[str, Any]:
        """
        Extract and calculate comprehensive financial metrics
        """
        metrics = {
            'company_symbol': company_symbol,
            'company_name': company_symbol
        }
        sales_series: List[float] = []
        
        try:
            # === P&L Metrics ===
            if 'pnl' in data:
                pnl = data['pnl']
                
                # Revenue metrics
                sales = self.extract_metric_value(pnl, 'Sales +', 'Mar 2024')
                metrics['sales'] = sales
                
                # Revenue growth (5-year CAGR)
                sales_series = self.extract_time_series(
                    pnl, 'Sales +', 
                    ['Mar 2020', 'Mar 2021', 'Mar 2022', 'Mar 2023', 'Mar 2024']
                )
                if len(sales_series) >= 2:
                    metrics['sales_cagr_5y'] = self.calculate_cagr(
                        sales_series[0], sales_series[-1], 4
                    )
                    metrics['sales_cagr_3y'] = self.calculate_cagr(
                        sales_series[-3], sales_series[-1], 2
                    ) if len(sales_series) >= 3 else 0.0
                
                # Profitability metrics
                op_profit = self.extract_metric_value(pnl, 'Operating Profit', 'Mar 2024')
                net_profit = self.extract_metric_value(pnl, 'Net Profit +', 'Mar 2024')
                ebitda = self.extract_metric_value(pnl, 'EBITDA', 'Mar 2024')
                
                metrics['op_profit'] = op_profit
                metrics['net_profit'] = net_profit
                metrics['ebitda'] = ebitda if ebitda != 0 else op_profit
                
                # Margin calculations
                metrics['opm'] = (op_profit / sales * 100) if sales > 0 else 0.0
                metrics['npm'] = (net_profit / sales * 100) if sales > 0 else 0.0
                metrics['ebitda_margin'] = (metrics['ebitda'] / sales * 100) if sales > 0 else 0.0
                
                # Margin trends
                opm_series = []
                for year in ['Mar 2020', 'Mar 2021', 'Mar 2022', 'Mar 2023', 'Mar 2024']:
                    s = self.extract_metric_value(pnl, 'Sales +', year)
                    op = self.extract_metric_value(pnl, 'Operating Profit', year)
                    opm_series.append((op / s * 100) if s > 0 else 0.0)
                
                if len(opm_series) >= 2:
                    metrics['opm_trend'] = 'improving' if opm_series[-1] > opm_series[0] else 'declining'
                    metrics['margin_recovery'] = opm_series[-1] - opm_series[0]
                    metrics['margin_consistency'] = np.std(opm_series) if len(opm_series) > 1 else 0.0
                    metrics['avg_opm_3y'] = np.mean(opm_series[-3:]) if len(opm_series) >= 3 else metrics['opm']
            
            # === Balance Sheet Metrics ===
            if 'balance_sheet' in data:
                bs = data['balance_sheet']
                
                total_assets = self.extract_metric_value(bs, 'Total Assets', 'Mar 2024')
                total_equity = self.extract_metric_value(bs, 'Total Equity', 'Mar 2024')
                borrowings = self.extract_metric_value(bs, 'Borrowings +', 'Mar 2024')
                cash = self.extract_metric_value(bs, 'Cash +', 'Mar 2024')
                
                # Try alternative equity calculation if needed
                if total_equity == 0:
                    equity_capital = self.extract_metric_value(bs, 'Equity Capital', 'Mar 2024')
                    reserves = self.extract_metric_value(bs, 'Reserves', 'Mar 2024')
                    total_equity = equity_capital + reserves
                
                metrics['total_assets'] = total_assets
                metrics['total_equity'] = total_equity
                metrics['borrowings'] = borrowings
                metrics['cash'] = cash
                
                # Ratios
                metrics['debt_equity'] = (borrowings / total_equity) if total_equity > 0 else 0.0
                metrics['cash_ratio'] = (cash / total_assets * 100) if total_assets > 0 else 0.0
                metrics['asset_turnover'] = (metrics.get('sales', 0) / total_assets) if total_assets > 0 else 0.0
                
                # Debt trend
                debt_series = self.extract_time_series(
                    bs, 'Borrowings +',
                    ['Mar 2022', 'Mar 2023', 'Mar 2024']
                )
                if len(debt_series) >= 2:
                    metrics['debt_trend'] = 'increasing' if debt_series[-1] > debt_series[0] else 'decreasing'
                
                # Current ratio (proxy using Other Assets/Other Liabilities)
                current_assets = self.extract_metric_value(bs, 'Other Assets +', 'Mar 2024')
                current_liabilities = self.extract_metric_value(bs, 'Other Liabilities +', 'Mar 2024')
                metrics['current_ratio'] = (current_assets / current_liabilities) if current_liabilities > 0 else 0.0
                
                # ROE and ROA
                if total_equity > 0 and 'net_profit' in metrics:
                    metrics['roe'] = (metrics['net_profit'] / total_equity * 100)
                if total_assets > 0 and 'net_profit' in metrics:
                    metrics['roa'] = (metrics['net_profit'] / total_assets * 100)
            
            # === Cash Flow Metrics ===
            if 'cash_flow' in data:
                cf = data['cash_flow']
                
                ocf = self.extract_metric_value(cf, 'Cash from Operating Activity +', 'Mar 2024')
                metrics['operating_cash_flow'] = ocf
                
                # OCF time series
                ocf_series = self.extract_time_series(
                    cf, 'Cash from Operating Activity +',
                    ['Mar 2022', 'Mar 2023', 'Mar 2024']
                )
                if len(ocf_series) >= 2:
                    metrics['ocf_trend'] = 'improving' if ocf_series[-1] > ocf_series[0] else 'declining'
                    metrics['avg_ocf_3y'] = np.mean(ocf_series)
                
                # Cash flow quality
                if 'net_profit' in metrics and metrics['net_profit'] > 0:
                    metrics['cf_quality'] = ocf / metrics['net_profit']
                
                # === ENHANCED CASH FLOW ANALYSIS (Khemka Framework) ===
                # OCF to Net Profit ratio
                if 'net_profit' in metrics and metrics['net_profit'] > 0:
                    metrics['ocf_to_np_ratio'] = ocf / metrics['net_profit']
                else:
                    metrics['ocf_to_np_ratio'] = 0.0
                
                # OCF to Revenue %
                if sales > 0:
                    metrics['ocf_to_revenue_pct'] = (ocf / sales * 100)
                else:
                    metrics['ocf_to_revenue_pct'] = 0.0
                
                # Free Cash Flow (if available from scraper)
                # Try to calculate from investing activity
                icf = self.extract_metric_value(cf, 'Cash from Investing Activity +', 'Mar 2024')
                capex = abs(icf) if icf < 0 else 0
                fcf = ocf - capex
                metrics['free_cash_flow'] = fcf
                
                # FCF time series for streak analysis
                fcf_series = []
                for year in ['Mar 2020', 'Mar 2021', 'Mar 2022', 'Mar 2023', 'Mar 2024']:
                    ocf_year = self.extract_metric_value(cf, 'Cash from Operating Activity +', year)
                    icf_year = self.extract_metric_value(cf, 'Cash from Investing Activity +', year)
                    capex_year = abs(icf_year) if icf_year < 0 else 0
                    fcf_year = ocf_year - capex_year
                    fcf_series.append(fcf_year)
                
                # Count years of positive FCF
                positive_fcf_years = sum(1 for f in fcf_series if f > 0)
                metrics['fcf_positive_years'] = positive_fcf_years
                metrics['fcf_streak'] = 'excellent' if positive_fcf_years >= 4 else 'good' if positive_fcf_years >= 3 else 'moderate'

                # Incremental cash efficiency and normalization
                delta_ocf = 0.0
                ocf_growth_pct = 0.0
                if len(ocf_series) >= 2:
                    prev_ocf = ocf_series[-2]
                    latest_ocf = ocf_series[-1]
                    delta_ocf = latest_ocf - prev_ocf
                    if abs(prev_ocf) > 1e-9:
                        ocf_growth_pct = (delta_ocf / abs(prev_ocf)) * 100
                metrics['ocf_growth_pct'] = ocf_growth_pct

                delta_sales = 0.0
                revenue_growth_pct = 0.0
                if sales_series and len(sales_series) >= 2:
                    prev_sales = sales_series[-2]
                    latest_sales = sales_series[-1]
                else:
                    prev_sales = metrics.get('sales', 0.0)
                    latest_sales = metrics.get('sales', 0.0)

                delta_sales = latest_sales - prev_sales
                if abs(prev_sales) > 1e-9:
                    revenue_growth_pct = (delta_sales / abs(prev_sales)) * 100

                if abs(delta_sales) > 1e-9:
                    metrics['incremental_ocf_margin'] = delta_ocf / delta_sales
                else:
                    metrics['incremental_ocf_margin'] = 0.0

                metrics['ocf_growth_vs_revenue_pct'] = ocf_growth_pct - revenue_growth_pct

                incremental_quality = 'mixed'
                incremental_ratio = metrics['incremental_ocf_margin']
                if incremental_ratio > 0.8:
                    incremental_quality = 'excellent'
                elif incremental_ratio > 0.6:
                    incremental_quality = 'strong'
                elif incremental_ratio > 0.3:
                    incremental_quality = 'healthy'
                elif incremental_ratio > 0.0:
                    incremental_quality = 'weak_positive'
                elif incremental_ratio < -0.2:
                    incremental_quality = 'deteriorating'
                metrics['incremental_ocf_quality'] = incremental_quality

                valid_ocf_values = [float(v) for v in ocf_series if isinstance(v, (int, float))]
                if not valid_ocf_values:
                    valid_ocf_values = [ocf]

                recent_window = valid_ocf_values[-3:] if len(valid_ocf_values) >= 3 else valid_ocf_values
                normalized_ocf = float(np.median(recent_window)) if recent_window else ocf
                ocf_volatility = float(np.std(recent_window)) if len(recent_window) > 1 else 0.0

                metrics['normalized_ocf'] = normalized_ocf
                metrics['normalized_ocf_volatility'] = ocf_volatility
                deviation_pct = 0.0
                if abs(normalized_ocf) > 1e-9:
                    deviation_pct = ((ocf - normalized_ocf) / abs(normalized_ocf)) * 100
                metrics['normalized_ocf_deviation_pct'] = deviation_pct
                metrics['ocf_anomaly_flag'] = abs(deviation_pct) >= 30
            
            # === WORKING CAPITAL EFFICIENCY (Khemka Framework) ===
            if 'balance_sheet' in data and 'pnl' in data:
                bs = data['balance_sheet']
                pnl = data['pnl']
                
                # Get working capital components
                receivables = self.extract_metric_value(bs, 'Trade receivables', 'Mar 2024')
                if receivables == 0:
                    receivables = self.extract_metric_value(bs, 'Debtors', 'Mar 2024')
                
                inventory = self.extract_metric_value(bs, 'Inventories', 'Mar 2024')
                if inventory == 0:
                    inventory = self.extract_metric_value(bs, 'Raw materials', 'Mar 2024')
                    inventory += self.extract_metric_value(bs, 'Finished goods', 'Mar 2024')
                    inventory += self.extract_metric_value(bs, 'Work-in-progress', 'Mar 2024')
                
                payables = self.extract_metric_value(bs, 'Trade payables', 'Mar 2024')
                if payables == 0:
                    payables = self.extract_metric_value(bs, 'Creditors', 'Mar 2024')
                
                # Get revenue and COGS
                revenue = sales
                cogs = self.extract_metric_value(pnl, 'Cost Of Materials Consumed +', 'Mar 2024')
                if cogs == 0:
                    # Estimate COGS as Sales - Gross Profit
                    gross_profit = self.extract_metric_value(pnl, 'Operating Profit', 'Mar 2024')
                    cogs = revenue - gross_profit if revenue > gross_profit else revenue * 0.6
                
                # Calculate working capital days
                if revenue > 0:
                    metrics['receivables_days'] = (receivables / revenue * 365)
                else:
                    metrics['receivables_days'] = 0.0
                
                if cogs > 0:
                    metrics['inventory_days'] = (inventory / cogs * 365)
                    metrics['payables_days'] = (payables / cogs * 365)
                else:
                    metrics['inventory_days'] = 0.0
                    metrics['payables_days'] = 0.0
                
                # Cash Conversion Cycle (Khemka's key metric!)
                metrics['cash_conversion_cycle'] = (
                    metrics['receivables_days'] + 
                    metrics['inventory_days'] - 
                    metrics['payables_days']
                )
                
                # Working capital quality assessment
                ccc = metrics['cash_conversion_cycle']
                if ccc < 0:
                    metrics['wc_quality'] = 'excellent'  # Negative CCC = uses supplier money
                elif ccc < 30:
                    metrics['wc_quality'] = 'very_good'
                elif ccc < 60:
                    metrics['wc_quality'] = 'good'
                elif ccc < 90:
                    metrics['wc_quality'] = 'moderate'
                else:
                    metrics['wc_quality'] = 'poor'
                
                # Calculate Working Capital
                current_assets = self.extract_metric_value(bs, 'Other Assets +', 'Mar 2024')
                current_liabilities = self.extract_metric_value(bs, 'Other Liabilities +', 'Mar 2024')
                metrics['working_capital'] = current_assets - current_liabilities
            
            # === OPERATING LEVERAGE DETECTION (Khemka Framework) ===
            # Key for branded generics: EBITDA should grow faster than revenue
            # Calculate: EBITDA growth / Revenue growth over multiple years
            if 'pnl' in data and 'balance_sheet' in data:
                pnl = data['pnl']
                bs = data['balance_sheet']
                
                # Get EBITDA and Revenue for multiple years
                revenue_years = []
                ebitda_years = []
                
                # Try to get 5-10 years of data
                available_years = [col for col in pnl.columns if col not in ['metric']]
                
                for year in sorted(available_years, reverse=True)[:10]:  # Last 10 years
                    try:
                        rev = self.extract_metric_value(pnl, 'Sales +', year)
                        eb = self.extract_metric_value(pnl, 'PBIT', year)
                        
                        if rev > 0 and eb > 0:
                            revenue_years.append({'year': year, 'revenue': rev})
                            ebitda_years.append({'year': year, 'ebitda': eb})
                    except:
                        continue
                
                # Calculate operating leverage (EBITDA growth / Revenue growth)
                operating_leverage_ratios = []
                for i in range(1, len(revenue_years)):
                    if revenue_years[i]['revenue'] > 0 and revenue_years[i-1]['revenue'] > 0:
                        rev_growth = (revenue_years[i]['revenue'] - revenue_years[i-1]['revenue']) / revenue_years[i-1]['revenue'] * 100
                        
                        if ebitda_years[i]['ebitda'] > 0 and ebitda_years[i-1]['ebitda'] > 0:
                            ebitda_growth = (ebitda_years[i]['ebitda'] - ebitda_years[i-1]['ebitda']) / ebitda_years[i-1]['ebitda'] * 100
                            
                            if rev_growth > 0.5:  # Only if meaningful revenue growth
                                leverage = ebitda_growth / rev_growth
                                operating_leverage_ratios.append(leverage)
                
                if operating_leverage_ratios:
                    metrics['avg_operating_leverage'] = np.mean(operating_leverage_ratios)
                    metrics['operating_leverage_quality'] = 'high' if metrics['avg_operating_leverage'] > 1.3 else 'moderate' if metrics['avg_operating_leverage'] > 1.1 else 'low'
            
            # === ASSET-LIGHT BUSINESS IDENTIFIER (Khemka Framework) ===
            # ROE = (Net Profit / Revenue) * (Revenue / Assets) * (Assets / Equity)
            # Asset Turnover = Revenue / Total Assets
            # High turnover + High margins = Branded generic
            if 'pnl' in data and 'balance_sheet' in data:
                pnl = data['pnl']
                bs = data['balance_sheet']
                
                # Get latest year's data
                available_years = [col for col in pnl.columns if col not in ['metric']]
                latest_year = sorted(available_years, reverse=True)[0] if available_years else None
                
                if latest_year:
                    revenue = self.extract_metric_value(pnl, 'Sales +', latest_year)
                    net_profit = self.extract_metric_value(pnl, 'Net Profit', latest_year)
                    total_assets = self.extract_metric_value(bs, 'Total Assets', latest_year)
                    
                    if revenue > 0 and total_assets > 0:
                        metrics['asset_turnover'] = revenue / total_assets
                        
                        # Net Margin
                        net_margin = (net_profit / revenue * 100) if revenue > 0 else 0
                        metrics['net_margin'] = net_margin
                        
                        # Branded generic indicator: High turnover (>1.0) + High margins (>15%)
                        if metrics['asset_turnover'] > 1.0 and net_margin > 15:
                            metrics['business_model'] = 'asset_light_branded'
                        elif metrics['asset_turnover'] > 0.8 and net_margin > 10:
                            metrics['business_model'] = 'asset_light'
                        else:
                            metrics['business_model'] = 'asset_heavy'
            
            # === CAPITAL ALLOCATION QUALITY ===
            # Track buyback vs dividend vs capex
            # Note: Buyback announcements would require parsing annual reports
            # For now, track dividend payout and capex efficiency
            if 'pnl' in data and 'cash_flow' in data:
                pnl = data['pnl']
                cf = data['cash_flow']
                
                available_years = [col for col in pnl.columns if col not in ['metric']]
                
                dividend_total = 0
                buyback_years = []
                
                # Check dividend payout
                for year in sorted(available_years, reverse=True)[:5]:  # Last 5 years
                    div = self.extract_metric_value(cf, 'Dividend Payout', year)
                    if div and div > 0:
                        dividend_total += div
                
                metrics['total_dividends_5y'] = dividend_total
                
                # Capex efficiency (from cash flow)
                capex_years = []
                for year in sorted(available_years, reverse=True)[:5]:
                    capex = self.extract_metric_value(cf, 'Capex', year)
                    if capex:
                        capex_years.append(abs(capex))
                
                metrics['total_capex_5y'] = sum(capex_years) if capex_years else 0
                
                # Capital allocation score
                if metrics.get('free_cash_flow', 0) > 0:
                    fcf_5y = metrics.get('free_cash_flow', 0) * 5  # Rough estimate
                    total_returned = dividend_total + metrics.get('total_capex_5y', 0)
                    
                    if fcf_5y > 0:
                        metrics['capital_allocation_ratio'] = total_returned / fcf_5y
                    else:
                        metrics['capital_allocation_ratio'] = 0
            
            # === Quarterly Metrics ===
            if 'quarterly' in data:
                qtr = data['quarterly']
                
                # Recent quarterly growth
                qtr_sales = []
                qtr_opm = []
                
                # Try to get last 4 quarters
                available_qtrs = [col for col in qtr.columns if col not in ['metric']]
                recent_qtrs = available_qtrs[-4:] if len(available_qtrs) >= 4 else available_qtrs
                
                for qtr_col in recent_qtrs:
                    q_sales = self.extract_metric_value(qtr, 'Sales +', qtr_col)
                    q_op = self.extract_metric_value(qtr, 'Operating Profit', qtr_col)
                    qtr_sales.append(q_sales)
                    qtr_opm.append((q_op / q_sales * 100) if q_sales > 0 else 0.0)
                
                # QoQ growth
                if len(qtr_sales) >= 2:
                    qoq_growth_rates = []
                    for i in range(1, len(qtr_sales)):
                        if qtr_sales[i-1] > 0:
                            growth = ((qtr_sales[i] - qtr_sales[i-1]) / qtr_sales[i-1]) * 100
                            qoq_growth_rates.append(growth)
                    
                    if qoq_growth_rates:
                        metrics['qoq_growth'] = np.mean(qoq_growth_rates)
                        metrics['recent_qtr_opm'] = np.mean(qtr_opm[-2:]) if len(qtr_opm) >= 2 else qtr_opm[-1]

            # Enrich core metrics with market valuation data if available
            self._enrich_with_market_data(company_symbol, metrics)
            return metrics
        except Exception as e:
            logger.error(f"Error calculating metrics: {e}")
            return metrics
    
    def analyze_balance_sheet_quality(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze balance sheet strength and quality"""
        analysis = {
            'category': 'balance_sheet',
            'score': 0,
            'max_score': 100
        }
        
        score = 0
        
        # Debt assessment (30 points)
        debt_equity = metrics.get('debt_equity', 0)
        if debt_equity < 0.3:
            score += 30
            analysis['debt_quality'] = 'excellent'
        elif debt_equity < 0.5:
            score += 25
            analysis['debt_quality'] = 'very_good'
        elif debt_equity < 1.0:
            score += 20
            analysis['debt_quality'] = 'good'
        elif debt_equity < 2.0:
            score += 10
            analysis['debt_quality'] = 'concerning'
        else:
            analysis['debt_quality'] = 'poor'
        
        # Cash reserves (25 points)
        cash_ratio = metrics.get('cash_ratio', 0)
        if cash_ratio > 15:
            score += 25
            analysis['cash_strength'] = 'excellent'
        elif cash_ratio > 10:
            score += 20
            analysis['cash_strength'] = 'very_good'
        elif cash_ratio > 5:
            score += 15
            analysis['cash_strength'] = 'good'
        elif cash_ratio > 2:
            score += 10
            analysis['cash_strength'] = 'adequate'
        else:
            analysis['cash_strength'] = 'weak'
        
        # Asset efficiency (25 points)
        asset_turnover = metrics.get('asset_turnover', 0)
        if asset_turnover > 2.0:
            score += 25
            analysis['asset_efficiency'] = 'excellent'
        elif asset_turnover > 1.5:
            score += 20
            analysis['asset_efficiency'] = 'very_good'
        elif asset_turnover > 1.0:
            score += 15
            analysis['asset_efficiency'] = 'good'
        elif asset_turnover > 0.5:
            score += 10
            analysis['asset_efficiency'] = 'moderate'
        else:
            analysis['asset_efficiency'] = 'poor'
        
        # Liquidity (20 points)
        current_ratio = metrics.get('current_ratio', 0)
        if current_ratio > 2.0:
            score += 20
            analysis['liquidity'] = 'excellent'
        elif current_ratio > 1.5:
            score += 15
            analysis['liquidity'] = 'good'
        elif current_ratio > 1.0:
            score += 10
            analysis['liquidity'] = 'adequate'
        else:
            analysis['liquidity'] = 'weak'
        
        analysis['score'] = score
        return analysis
    
    def analyze_operational_excellence(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze operational efficiency and profitability"""
        analysis = {
            'category': 'operational',
            'score': 0,
            'max_score': 100
        }
        
        score = 0
        
        # Operating margins (30 points)
        opm = metrics.get('opm', 0)
        if opm > 25:
            score += 30
            analysis['margin_quality'] = 'excellent'
        elif opm > 20:
            score += 25
            analysis['margin_quality'] = 'very_good'
        elif opm > 15:
            score += 20
            analysis['margin_quality'] = 'good'
        elif opm > 10:
            score += 12
            analysis['margin_quality'] = 'average'
        elif opm > 5:
            score += 5
            analysis['margin_quality'] = 'below_average'
        else:
            analysis['margin_quality'] = 'poor'
        
        # ROE (25 points)
        roe = metrics.get('roe', 0)
        if roe > 25:
            score += 25
            analysis['roe_quality'] = 'excellent'
        elif roe > 20:
            score += 20
            analysis['roe_quality'] = 'very_good'
        elif roe > 15:
            score += 15
            analysis['roe_quality'] = 'good'
        elif roe > 10:
            score += 8
            analysis['roe_quality'] = 'average'
        else:
            analysis['roe_quality'] = 'poor'
        
        # Operating Leverage (NEW - Khemka) - 25 points
        avg_leverage = metrics.get('avg_operating_leverage', 0)
        if avg_leverage > 1.3:
            score += 25
            analysis['leverage_quality'] = 'high'
        elif avg_leverage > 1.1:
            score += 18
            analysis['leverage_quality'] = 'moderate'
        elif avg_leverage > 1.0:
            score += 10
            analysis['leverage_quality'] = 'low'
        else:
            analysis['leverage_quality'] = 'negative'
        
        # Asset-Light Business Model (NEW - Khemka) - 10 points
        business_model = metrics.get('business_model', '')
        if business_model == 'asset_light_branded':
            score += 10
            analysis['business_model_quality'] = 'branded_generic'
        elif business_model == 'asset_light':
            score += 5
            analysis['business_model_quality'] = 'asset_light'
        else:
            analysis['business_model_quality'] = 'asset_heavy'
        
        # Margin consistency (10 points)
        margin_consistency = metrics.get('margin_consistency', 0)
        if margin_consistency < 3:
            score += 10
            analysis['margin_stability'] = 'very_stable'
        elif margin_consistency < 5:
            score += 7
            analysis['margin_stability'] = 'stable'
        elif margin_consistency < 10:
            score += 3
            analysis['margin_stability'] = 'moderate'
        else:
            analysis['margin_stability'] = 'volatile'
        
        analysis['score'] = score
        return analysis
    
    def analyze_growth_dynamics(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze growth sustainability and momentum"""
        analysis = {
            'category': 'growth',
            'score': 0,
            'max_score': 100
        }
        
        score = 0
        
        # Revenue CAGR (50 points)
        sales_cagr = metrics.get('sales_cagr_5y', 0)
        if sales_cagr > 30:
            score += 50
            analysis['growth_rate'] = 'exceptional'
        elif sales_cagr > 20:
            score += 40
            analysis['growth_rate'] = 'excellent'
        elif sales_cagr > 15:
            score += 30
            analysis['growth_rate'] = 'very_good'
        elif sales_cagr > 10:
            score += 20
            analysis['growth_rate'] = 'good'
        elif sales_cagr > 5:
            score += 10
            analysis['growth_rate'] = 'moderate'
        else:
            analysis['growth_rate'] = 'low'
        
        # Growth acceleration (25 points) - 3y vs 5y CAGR
        cagr_3y = metrics.get('sales_cagr_3y', 0)
        if cagr_3y > sales_cagr:
            score += 25
            analysis['growth_momentum'] = 'accelerating'
        elif cagr_3y > sales_cagr - 5:
            score += 15
            analysis['growth_momentum'] = 'stable'
        else:
            analysis['growth_momentum'] = 'decelerating'
        
        # Scalability (25 points) - high turnover + high margins
        asset_turnover = metrics.get('asset_turnover', 0)
        opm = metrics.get('opm', 0)
        
        if asset_turnover > 1.5 and opm > 15:
            score += 25
            analysis['scalability'] = 'high'
        elif asset_turnover > 1.0 and opm > 10:
            score += 15
            analysis['scalability'] = 'medium'
        elif asset_turnover > 0.5 and opm > 5:
            score += 5
            analysis['scalability'] = 'low'
        else:
            analysis['scalability'] = 'very_low'
        
        analysis['score'] = score
        return analysis
    
    def analyze_cash_flow_strength(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze cash generation and quality (Enhanced with Khemka Framework)"""
        analysis = {
            'category': 'cash_flow',
            'score': 0,
            'max_score': 100
        }
        
        score = 0
        
        # OCF to NP ratio - Khemka's #1 priority (35 points)
        ocf_to_np = metrics.get('ocf_to_np_ratio', 0)
        if ocf_to_np > 1.5:
            score += 35
            analysis['cf_quality'] = 'excellent'
        elif ocf_to_np > 1.2:
            score += 30
            analysis['cf_quality'] = 'very_good'
        elif ocf_to_np > 1.0:
            score += 25
            analysis['cf_quality'] = 'good'
        elif ocf_to_np > 0.8:
            score += 15
            analysis['cf_quality'] = 'adequate'
        elif ocf_to_np > 0.5:
            score += 5
            analysis['cf_quality'] = 'weak'
        else:
            analysis['cf_quality'] = 'poor'
        
        # FCF consistency - years of positive FCF (25 points)
        fcf_positive_years = metrics.get('fcf_positive_years', 0)
        if fcf_positive_years >= 5:
            score += 25
            analysis['fcf_consistency'] = 'excellent'
        elif fcf_positive_years >= 4:
            score += 20
            analysis['fcf_consistency'] = 'very_good'
        elif fcf_positive_years >= 3:
            score += 15
            analysis['fcf_consistency'] = 'good'
        elif fcf_positive_years >= 2:
            score += 10
            analysis['fcf_consistency'] = 'moderate'
        else:
            analysis['fcf_consistency'] = 'weak'
        
        # OCF to Revenue % (20 points)
        ocf_to_rev = metrics.get('ocf_to_revenue_pct', 0)
        if ocf_to_rev > 15:
            score += 20
            analysis['ocf_efficiency'] = 'excellent'
        elif ocf_to_rev > 10:
            score += 15
            analysis['ocf_efficiency'] = 'very_good'
        elif ocf_to_rev > 7:
            score += 10
            analysis['ocf_efficiency'] = 'good'
        elif ocf_to_rev > 5:
            score += 5
            analysis['ocf_efficiency'] = 'moderate'
        else:
            analysis['ocf_efficiency'] = 'weak'
        
        # OCF trend (adjusted to 15 points to accommodate incremental conversion scoring)
        ocf_trend = metrics.get('ocf_trend')
        if ocf_trend == 'improving':
            score += 15
            analysis['ocf_trend'] = 'improving'
        elif ocf_trend == 'declining':
            score += 5
            analysis['ocf_trend'] = 'declining'
        else:
            score += 10
            analysis['ocf_trend'] = 'stable'

        # Incremental OCF conversion quality (5 points)
        incremental_ratio = metrics.get('incremental_ocf_margin', 0)
        if incremental_ratio > 0.8:
            score += 5
            analysis['incremental_conversion'] = 'excellent'
        elif incremental_ratio > 0.6:
            score += 4
            analysis['incremental_conversion'] = 'strong'
        elif incremental_ratio > 0.3:
            score += 3
            analysis['incremental_conversion'] = 'healthy'
        elif incremental_ratio > 0.0:
            score += 2
            analysis['incremental_conversion'] = 'modest'
        else:
            score += 1
            analysis['incremental_conversion'] = 'weak'
        
        analysis['score'] = score
        return analysis
    
    def analyze_working_capital_efficiency(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze working capital efficiency (Khemka Framework)"""
        analysis = {
            'category': 'working_capital',
            'score': 0,
            'max_score': 100
        }
        
        score = 0
        
        # Cash Conversion Cycle - Khemka's key metric (60 points)
        ccc = metrics.get('cash_conversion_cycle', 999)
        
        if ccc < 0:
            # Negative CCC = Company uses supplier money! (Best case - hospitals, retailers)
            score += 60
            analysis['ccc_quality'] = 'exceptional'
        elif ccc < 30:
            score += 50
            analysis['ccc_quality'] = 'excellent'
        elif ccc < 60:
            score += 40
            analysis['ccc_quality'] = 'very_good'
        elif ccc < 90:
            score += 30
            analysis['ccc_quality'] = 'good'
        elif ccc < 120:
            score += 15
            analysis['ccc_quality'] = 'moderate'
        else:
            score += 5
            analysis['ccc_quality'] = 'poor'
        
        # Receivables efficiency (20 points)
        rec_days = metrics.get('receivables_days', 0)
        if rec_days < 30:
            score += 20
            analysis['receivables_efficiency'] = 'excellent'
        elif rec_days < 60:
            score += 15
            analysis['receivables_efficiency'] = 'good'
        elif rec_days < 90:
            score += 10
            analysis['receivables_efficiency'] = 'moderate'
        else:
            analysis['receivables_efficiency'] = 'slow'
        
        # Inventory efficiency (20 points)
        inv_days = metrics.get('inventory_days', 0)
        if inv_days < 30:
            score += 20
            analysis['inventory_efficiency'] = 'excellent'
        elif inv_days < 60:
            score += 15
            analysis['inventory_efficiency'] = 'good'
        elif inv_days < 90:
            score += 10
            analysis['inventory_efficiency'] = 'moderate'
        else:
            analysis['inventory_efficiency'] = 'slow'
        
        analysis['score'] = score
        return analysis
    
    def analyze_turnaround_signals(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze recent momentum and turnaround indicators"""
        analysis = {
            'category': 'turnaround',
            'score': 0,
            'max_score': 100
        }
        
        score = 0
        
        # Recent quarterly growth (50 points)
        qoq_growth = metrics.get('qoq_growth', 0)
        if qoq_growth > 20:
            score += 50
            analysis['recent_momentum'] = 'very_strong'
        elif qoq_growth > 15:
            score += 40
            analysis['recent_momentum'] = 'strong'
        elif qoq_growth > 10:
            score += 30
            analysis['recent_momentum'] = 'good'
        elif qoq_growth > 5:
            score += 20
            analysis['recent_momentum'] = 'moderate'
        elif qoq_growth > 0:
            score += 10
            analysis['recent_momentum'] = 'weak_positive'
        elif qoq_growth > -10:
            analysis['recent_momentum'] = 'weak_negative'
        else:
            analysis['recent_momentum'] = 'declining'
        
        # Margin recovery (50 points)
        margin_recovery = metrics.get('margin_recovery', 0)
        if margin_recovery > 5:
            score += 50
            analysis['margin_recovery'] = 'strong'
        elif margin_recovery > 2:
            score += 35
            analysis['margin_recovery'] = 'good'
        elif margin_recovery > 0:
            score += 20
            analysis['margin_recovery'] = 'moderate'
        elif margin_recovery > -2:
            score += 5
            analysis['margin_recovery'] = 'stable'
        else:
            analysis['margin_recovery'] = 'declining'
        
        analysis['score'] = score
        return analysis
    
    def identify_red_flags(self, metrics: Dict[str, Any]) -> List[str]:
        """Comprehensive red flag identification"""
        red_flags = []
        
        # Debt concerns
        if metrics.get('debt_equity', 0) > 2.0:
            red_flags.append("Very High Debt-to-Equity Ratio (>2.0)")
        elif metrics.get('debt_equity', 0) > 1.0:
            red_flags.append("High Debt-to-Equity Ratio (>1.0)")
        
        # Liquidity concerns
        if metrics.get('current_ratio', 0) < 0.8:
            red_flags.append("Critical Liquidity (Current Ratio <0.8)")
        elif metrics.get('current_ratio', 0) < 1.0:
            red_flags.append("Low Liquidity (Current Ratio <1.0)")
        
        # Cash flow concerns
        if metrics.get('cf_quality', 0) < 0.3:
            red_flags.append("Very Poor Cash Flow Quality (<0.3)")
        elif metrics.get('cf_quality', 0) < 0.5:
            red_flags.append("Poor Cash Flow Quality (<0.5)")
        
        if metrics.get('ocf_trend') == 'declining':
            red_flags.append("Declining Operating Cash Flow")

        if metrics.get('ocf_anomaly_flag'):
            red_flags.append("Operating Cash Flow Anomaly (>30% deviation vs normalized)")

        if metrics.get('incremental_ocf_margin', 0) < 0:
            red_flags.append("Negative Incremental OCF Conversion (Cash lagging revenue)")
        
        # Profitability concerns
        if metrics.get('opm', 0) < 3:
            red_flags.append("Very Low Operating Margins (<3%)")
        elif metrics.get('opm', 0) < 5:
            red_flags.append("Low Operating Margins (<5%)")
        
        if metrics.get('roe', 0) < 5 and metrics.get('roe', 0) != 0:
            red_flags.append("Low Return on Equity (<5%)")
        
        # Margin concerns
        if metrics.get('margin_recovery', 0) < -8:
            red_flags.append("Severe Margin Decline (>8% drop)")
        elif metrics.get('margin_recovery', 0) < -5:
            red_flags.append("Significant Margin Decline (>5% drop)")
        
        if metrics.get('margin_consistency', 0) > 15:
            red_flags.append("Very High Margin Volatility")
        elif metrics.get('margin_consistency', 0) > 10:
            red_flags.append("High Margin Volatility")
        
        # Growth concerns
        if metrics.get('qoq_growth', 0) < -20:
            red_flags.append("Severe Revenue Decline (>20% QoQ)")
        elif metrics.get('qoq_growth', 0) < -10:
            red_flags.append("Significant Revenue Decline (>10% QoQ)")
        
        if metrics.get('sales_cagr_5y', 0) < -5:
            red_flags.append("Negative Revenue CAGR")
        
        # Asset efficiency concerns
        if metrics.get('asset_turnover', 0) < 0.3:
            red_flags.append("Very Poor Asset Utilization (<0.3)")
        elif metrics.get('asset_turnover', 0) < 0.5:
            red_flags.append("Poor Asset Utilization (<0.5)")
        
        # Debt trend concerns
        if metrics.get('debt_trend') == 'increasing' and metrics.get('debt_equity', 0) > 0.5:
            red_flags.append("Rising Debt Levels")
        
        # Working Capital concerns (Khemka Framework)
        if metrics.get('cash_conversion_cycle', 0) > 150:
            red_flags.append("Very High Cash Conversion Cycle (>150 days)")
        elif metrics.get('cash_conversion_cycle', 0) > 120:
            red_flags.append("High Cash Conversion Cycle (>120 days)")
        
        if metrics.get('receivables_days', 0) > 120:
            red_flags.append("Very Slow Receivables Collection (>120 days)")
        
        if metrics.get('inventory_days', 0) > 150:
            red_flags.append("Very High Inventory Days (>150 days)")
        
        # Free Cash Flow concerns (Khemka's #1 priority)
        if metrics.get('free_cash_flow', 0) < 0:
            red_flags.append("Negative Free Cash Flow (Cash Burn)")
        
        if metrics.get('fcf_positive_years', 0) < 2:
            red_flags.append("Inconsistent FCF Generation (<2 years positive)")
        
        if metrics.get('ocf_to_np_ratio', 0) < 0.7:
            red_flags.append("Low OCF/Net Profit Ratio (<0.7)")
        
        # Operating Leverage concerns (Khemka Framework)
        if metrics.get('avg_operating_leverage', 0) < 0.5:
            red_flags.append("Very Low/No Operating Leverage (<0.5x)")
        
        # Capital Allocation concerns
        if metrics.get('capital_allocation_ratio', 0) < 0.3:
            red_flags.append("Poor Capital Allocation (<30% of FCF returned)")
        
        return red_flags
    
    def calculate_composite_score(self, analyses: Dict[str, Any], 
                                  red_flags: List[str]) -> float:
        """Calculate weighted composite score (Enhanced with Khemka Framework)"""
        
        weights = self.config['weights']
        
        # Get individual category scores
        balance_sheet_score = analyses.get('balance_sheet', {}).get('score', 0)
        operational_score = analyses.get('operational', {}).get('score', 0)
        growth_score = analyses.get('growth', {}).get('score', 0)
        cash_flow_score = analyses.get('cash_flow', {}).get('score', 0)
        working_capital_score = analyses.get('working_capital', {}).get('score', 0)  # NEW
        turnaround_score = analyses.get('turnaround', {}).get('score', 0)
        
        # Calculate weighted score
        composite = (
            balance_sheet_score * weights['balance_sheet'] +
            operational_score * weights['operational'] +
            growth_score * weights['growth'] +
            cash_flow_score * weights['cash_flow'] +
            working_capital_score * weights.get('working_capital', 0) +  # NEW
            turnaround_score * weights['turnaround']
        )
        
        # Apply red flag penalty
        red_flag_penalty = len(red_flags) * self.config['red_flag_penalty']
        composite = max(0, composite - red_flag_penalty)
        
        return composite
    
    def analyze_company(self, company_symbol: str) -> Optional[Dict[str, Any]]:
        """Perform comprehensive analysis for a single company"""
        logger.info(f"Analyzing {company_symbol}...")
        
        # Load data
        data = self.load_company_data(company_symbol)
        if not data:
            logger.warning(f"No data available for {company_symbol}")
            return None
        
        # Calculate metrics
        metrics = self.calculate_financial_metrics(data, company_symbol)
        if not metrics:
            logger.warning(f"Could not calculate metrics for {company_symbol}")
            return None
        
        # Perform multi-dimensional analysis
        analyses = {
            'balance_sheet': self.analyze_balance_sheet_quality(metrics),
            'operational': self.analyze_operational_excellence(metrics),
            'growth': self.analyze_growth_dynamics(metrics),
            'cash_flow': self.analyze_cash_flow_strength(metrics),
            'working_capital': self.analyze_working_capital_efficiency(metrics),  # NEW - Khemka
            'turnaround': self.analyze_turnaround_signals(metrics)
        }
        
        # Identify red flags
        red_flags = self.identify_red_flags(metrics)
        
        # Calculate composite score
        composite_score = self.calculate_composite_score(analyses, red_flags)
        
        return {
            'company': company_symbol,
            'composite_score': composite_score,
            'metrics': metrics,
            'analyses': analyses,
            'red_flags': red_flags,
            'red_flag_count': len(red_flags),
            'analysis_date': datetime.now().isoformat()
        }
    
    def scan_all_companies(self) -> List[Dict[str, Any]]:
        """Scan and analyze all companies in the dataset"""
        logger.info("Starting comprehensive financial scan...")
        
        # Get list of companies
        pnl_dir = os.path.join(self.data_dir, "pnl_data")
        if not os.path.exists(pnl_dir):
            logger.error(f"Data directory not found: {pnl_dir}")
            return []
        
        companies = [
            f.replace('_pnl.csv', '') 
            for f in os.listdir(pnl_dir) 
            if f.endswith('_pnl.csv')
        ]
        
        logger.info(f"Found {len(companies)} companies to analyze")
        
        results = []
        for i, company in enumerate(companies, 1):
            logger.info(f"Processing {i}/{len(companies)}: {company}")
            result = self.analyze_company(company)
            if result:
                results.append(result)
        
        # Sort by composite score
        results.sort(key=lambda x: x['composite_score'], reverse=True)
        
        self.analysis_results = results
        logger.info(f"Scan completed. Analyzed {len(results)} companies successfully")
        
        return results
    
    def generate_report(self, results: Optional[List[Dict]] = None, 
                       top_n: int = 25) -> str:
        """Generate comprehensive text report"""
        
        if results is None:
            results = self.analysis_results
        
        if not results:
            return "No analysis results available"

        def _fmt(value: Optional[float], fmt: str = "{:5.1f}") -> str:
            if value is None:
                return "N/A"
            try:
                if isinstance(value, (float, np.floating)) and np.isnan(value):
                    return "N/A"
            except Exception:
                pass
            try:
                return fmt.format(value)
            except Exception:
                return "N/A"
        
        report_lines = []
        report_lines.append("=" * 120)
        report_lines.append("COMPREHENSIVE FINANCIAL SCANNER REPORT".center(120))
        report_lines.append("=" * 120)
        report_lines.append(f"Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append(f"Total Companies Scanned: {len(results)}")
        report_lines.append(f"Average Composite Score: {np.mean([r['composite_score'] for r in results]):.1f}")
        report_lines.append("")
        
        # Top performers
        report_lines.append(f"TOP {min(top_n, len(results))} COMPANIES BY COMPOSITE SCORE")
        report_lines.append("-" * 120)
        
        for i, result in enumerate(results[:top_n], 1):
            company = result['company']
            score = result['composite_score']
            metrics = result['metrics']
            analyses = result['analyses']
            red_flags = result['red_flags']
            
            report_lines.append(f"\n{i:2d}. {company:<20} Composite Score: {score:6.1f}/100")
            
            # Key metrics
            report_lines.append(f"    Financial Metrics:")
            report_lines.append(f"      Revenue: ₹{metrics.get('sales', 0):,.0f} Cr  |  "
                              f"Net Profit: ₹{metrics.get('net_profit', 0):,.0f} Cr  |  "
                              f"Cash: ₹{metrics.get('cash', 0):,.0f} Cr")
            
            # Profitability
            report_lines.append(f"    Profitability:")
            report_lines.append(f"      OPM: {metrics.get('opm', 0):5.1f}%  |  "
                              f"NPM: {metrics.get('npm', 0):5.1f}%  |  "
                              f"ROE: {metrics.get('roe', 0):5.1f}%")
            
            # Growth
            report_lines.append(f"    Growth:")
            report_lines.append(f"      5Y CAGR: {metrics.get('sales_cagr_5y', 0):5.1f}%  |  "
                              f"QoQ Growth: {metrics.get('qoq_growth', 0):5.1f}%  |  "
                              f"Margin Trend: {metrics.get('opm_trend', 'N/A')}")
            
            # Balance Sheet
            report_lines.append(f"    Balance Sheet:")
            report_lines.append(f"      D/E: {metrics.get('debt_equity', 0):4.2f}  |  "
                              f"Current Ratio: {metrics.get('current_ratio', 0):4.2f}  |  "
                              f"CF Quality: {metrics.get('cf_quality', 0):4.2f}")

            # Valuation (if available)
            if metrics.get('ev_to_ocf') or metrics.get('ocf_yield_pct') or metrics.get('fcf_yield_pct'):
                report_lines.append(f"    Valuation:")
                report_lines.append(
                    f"      EV/OCF: {_fmt(metrics.get('ev_to_ocf'))}x  |  "
                    f"OCF Yield: {_fmt(metrics.get('ocf_yield_pct'))}%  |  "
                    f"FCF Yield: {_fmt(metrics.get('fcf_yield_pct') or metrics.get('fcf_yield_pct_scraper'))}%"
                )
            
            # Category scores
            report_lines.append(f"    Category Scores:")
            report_lines.append(f"      Balance Sheet: {analyses['balance_sheet']['score']}/100  |  "
                              f"Operations: {analyses['operational']['score']}/100  |  "
                              f"Growth: {analyses['growth']['score']}/100")
            report_lines.append(f"      Cash Flow: {analyses['cash_flow']['score']}/100  |  "
                              f"Working Capital: {analyses['working_capital']['score']}/100  |  "
                              f"Turnaround: {analyses['turnaround']['score']}/100")
            
            # Red flags
            if red_flags:
                report_lines.append(f"    ⚠ Red Flags ({len(red_flags)}): {', '.join(red_flags[:3])}")
                if len(red_flags) > 3:
                    report_lines.append(f"       ... and {len(red_flags) - 3} more")
            else:
                report_lines.append(f"    ✓ No Red Flags Identified")
        
        # Summary statistics
        report_lines.append("\n" + "=" * 120)
        report_lines.append("SUMMARY STATISTICS")
        report_lines.append("-" * 120)
        
        # Red flag distribution
        all_red_flags = {}
        for result in results:
            for flag in result['red_flags']:
                all_red_flags[flag] = all_red_flags.get(flag, 0) + 1
        
        report_lines.append(f"\nMost Common Red Flags:")
        for flag, count in sorted(all_red_flags.items(), key=lambda x: x[1], reverse=True)[:10]:
            report_lines.append(f"  • {flag}: {count} companies ({count/len(results)*100:.1f}%)")
        
        return "\n".join(report_lines)
    
    def save_results(self, filename: Optional[str] = None) -> str:
        """Save analysis results to CSV and JSON"""
        
        if not self.analysis_results:
            logger.warning("No results to save")
            return ""
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_filename = filename or f"financial_scan_{timestamp}"
        
        # Prepare CSV data
        csv_data = []
        for rank, result in enumerate(self.analysis_results, 1):
            metrics = result['metrics']
            analyses = result['analyses']
            
            row = {
                'Rank': rank,
                'Company': result['company'],
                'Composite_Score': result['composite_score'],
                
                # Profitability
                'OPM_%': metrics.get('opm', 0),
                'NPM_%': metrics.get('npm', 0),
                'EBITDA_Margin_%': metrics.get('ebitda_margin', 0),
                'ROE_%': metrics.get('roe', 0),
                'ROA_%': metrics.get('roa', 0),
                
                # Growth
                'Sales_CAGR_5Y_%': metrics.get('sales_cagr_5y', 0),
                'Sales_CAGR_3Y_%': metrics.get('sales_cagr_3y', 0),
                'QoQ_Growth_%': metrics.get('qoq_growth', 0),
                'Margin_Recovery_%': metrics.get('margin_recovery', 0),
                
                # Balance Sheet
                'Debt_Equity': metrics.get('debt_equity', 0),
                'Current_Ratio': metrics.get('current_ratio', 0),
                'Asset_Turnover': metrics.get('asset_turnover', 0),
                'Cash_Ratio_%': metrics.get('cash_ratio', 0),
                
                # Cash Flow
                'CF_Quality': metrics.get('cf_quality', 0),
                'OCF_Trend': metrics.get('ocf_trend', 'N/A'),
                
                # Enhanced Cash Flow (Khemka Framework)
                'OCF_to_NP_Ratio': metrics.get('ocf_to_np_ratio', 0),
                'OCF_to_Revenue_%': metrics.get('ocf_to_revenue_pct', 0),
                'Free_Cash_Flow': metrics.get('free_cash_flow', 0),
                'FCF_Positive_Years': metrics.get('fcf_positive_years', 0),
                'FCF_Streak': metrics.get('fcf_streak', 'N/A'),
                'OCF_Yield_%': metrics.get('ocf_yield_pct', 0),
                'Normalized_OCF': metrics.get('normalized_ocf', 0),
                'Normalized_OCF_Yield_%': metrics.get('normalized_ocf_yield_pct', 0),
                'Normalized_OCF_Deviation_%': metrics.get('normalized_ocf_deviation_pct', 0),
                'OCF_Growth_%': metrics.get('ocf_growth_pct', 0),
                'OCF_vs_Revenue_Gap_%': metrics.get('ocf_growth_vs_revenue_pct', 0),
                'Incremental_OCF_Margin': metrics.get('incremental_ocf_margin', 0),
                'Incremental_OCF_Quality': metrics.get('incremental_ocf_quality', 'N/A'),
                'OCF_Anomaly_Flag': metrics.get('ocf_anomaly_flag', False),
                
                # Working Capital Efficiency (Khemka Framework)
                'Receivables_Days': metrics.get('receivables_days', 0),
                'Inventory_Days': metrics.get('inventory_days', 0),
                'Payables_Days': metrics.get('payables_days', 0),
                'Cash_Conversion_Cycle': metrics.get('cash_conversion_cycle', 0),
                'WC_Quality': metrics.get('wc_quality', 'N/A'),
                'Working_Capital': metrics.get('working_capital', 0),
                
                # Operating Leverage (Khemka Framework)
                'Operating_Leverage': metrics.get('avg_operating_leverage', 0),
                'Leverage_Quality': metrics.get('operating_leverage_quality', 'N/A'),
                
                # Asset-Light Business Model (Khemka Framework)
                'Asset_Turnover_New': metrics.get('asset_turnover', 0),
                'Net_Margin_%': metrics.get('net_margin', 0),
                'Business_Model': metrics.get('business_model', 'N/A'),
                
                # Capital Allocation Quality
                'Total_Dividends_5Y_Cr': metrics.get('total_dividends_5y', 0) / 100 if metrics.get('total_dividends_5y') else 0,
                'Total_Capex_5Y_Cr': metrics.get('total_capex_5y', 0) / 100 if metrics.get('total_capex_5y') else 0,
                'Capital_Allocation_Ratio': metrics.get('capital_allocation_ratio', 0),
                
                # Category Scores
                'Balance_Sheet_Score': analyses['balance_sheet']['score'],
                'Operational_Score': analyses['operational']['score'],
                'Growth_Score': analyses['growth']['score'],
                'Cash_Flow_Score': analyses['cash_flow']['score'],
                'Working_Capital_Score': analyses['working_capital']['score'],  # NEW
                'Turnaround_Score': analyses['turnaround']['score'],
                
                # Financials (in Crores)
                'Sales_Cr': metrics.get('sales', 0) / 100,
                'Net_Profit_Cr': metrics.get('net_profit', 0) / 100,
                'Total_Assets_Cr': metrics.get('total_assets', 0) / 100,
                'Cash_Cr': metrics.get('cash', 0) / 100,

                # Market & Valuation
                'Market_Cap': metrics.get('market_cap', 0),
                'Enterprise_Value': metrics.get('enterprise_value', 0),
                'Market_Price': metrics.get('market_price', 0),
                'EV_to_OCF': metrics.get('ev_to_ocf', 0),
                'EV_to_Normalized_OCF': metrics.get('ev_to_normalized_ocf', 0),
                'Price_to_FCF': metrics.get('price_to_fcf', 0),
                'Price_to_FCF_Scraper': metrics.get('price_to_fcf_scraper', 0),
                'Price_to_Normalized_OCF': metrics.get('price_to_normalized_ocf', 0),
                'FCF_Yield_%': metrics.get('fcf_yield_pct', 0),
                'FCF_Yield_Scraper_%': metrics.get('fcf_yield_pct_scraper', 0),
                'FCF_Yield_Avg_3Y_%': metrics.get('fcf_yield_pct_avg_3y', 0),
                'Market_Data_Source': metrics.get('market_data_source', 'N/A'),
                
                # Red Flags
                'Red_Flag_Count': result['red_flag_count'],
                'Red_Flags': '; '.join(result['red_flags'])
            }
            csv_data.append(row)
        
        # Save CSV
        csv_filename = f"{base_filename}.csv"
        df = pd.DataFrame(csv_data)
        df.to_csv(csv_filename, index=False)
        logger.info(f"Results saved to {csv_filename}")
        
        # Save detailed JSON
        json_filename = f"{base_filename}.json"
        with open(json_filename, 'w') as f:
            json.dump(self.analysis_results, f, indent=2, default=str)
        logger.info(f"Detailed results saved to {json_filename}")
        
        # Save text report
        report_filename = f"{base_filename}_report.txt"
        report = self.generate_report()
        with open(report_filename, 'w', encoding='utf-8') as f:
            f.write(report)
        logger.info(f"Report saved to {report_filename}")
        
        return csv_filename


def main():
    """Main execution function"""
    
    # Initialize scanner
    scanner = FinancialScanner(data_dir="output")
    
    # Run comprehensive scan
    results = scanner.scan_all_companies()
    
    if not results:
        logger.error("No companies could be analyzed")
        return
    
    # Generate and display report
    report = scanner.generate_report(top_n=25)
    print(report)
    
    # Save results
    output_file = scanner.save_results()
    
    print(f"\n{'=' * 120}")
    print(f"SCAN COMPLETE!")
    print(f"Total Companies Analyzed: {len(results)}")
    print(f"Results saved to: {output_file}")
    print(f"{'=' * 120}")


if __name__ == "__main__":
    main()

