#!/usr/bin/env python3
"""
Integrated Quantitative + Qualitative Analyzer
===============================================

Combines:
1. Investment Filter (Quant pyramid)
2. Document Analysis (Qual insights)
3. Final decision with high confidence ratings

Philosophy: Numbers tell you WHAT, Documents tell you WHY
"""

import os
import re
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional
import logging

# Import our components
import sys
sys.path.append(os.path.dirname(__file__))

from investment_filter import InvestmentFilter

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


class QualitativeAnalyzer:
    """
    Professional-grade document analyzer
    Reuses code from analyze_all_with_documents.py and document_analyzer.py
    """
    
    def __init__(self, downloads_dir: str = "downloads"):
        self.downloads_dir = downloads_dir
        self.concalls_dir = os.path.join(downloads_dir, "concalls")
        self.reports_dir = os.path.join(downloads_dir, "annual_reports")
    
    def extract_pdf_text(self, pdf_path: str) -> str:
        """Extract text from PDF (reused from existing code)"""
        try:
            import PyPDF2
            text = ""
            with open(pdf_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                for page in reader.pages:
                    text += page.extract_text() + "\n"
            return text
        except Exception as e:
            logger.error(f"   ❌ Error reading PDF: {e}")
            return ""
    
    def score_management_quality(self, text: str) -> Tuple[int, List[str]]:
        """
        Analyze management communication quality
        Returns: (score -50 to +50, insights)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        insights = []
        
        # POSITIVE SIGNALS (Khemka-inspired)
        
        # 1. Capital Allocation Language (+20)
        capital_keywords = ['capital allocation', 'roce', 'roic', 'free cash flow', 
                          'fcf', 'buyback', 'shareholder value', 'return on capital']
        cap_count = sum(text_lower.count(k) for k in capital_keywords)
        
        if cap_count > 10:
            score += 20
            insights.append("✅ Capital-focused management")
        elif cap_count > 5:
            score += 10
        
        # 2. Transparency - Acknowledges problems (+15)
        transparency = ['challenge', 'headwind', 'admitted', 'acknowledged', 
                       'difficult', 'setback', 'temporary']
        trans_count = sum(text_lower.count(k) for k in transparency)
        
        if trans_count > 5:
            score += 15
            insights.append("✅ Transparent - acknowledges challenges")
        elif trans_count > 2:
            score += 8
        
        # 3. Execution Track Record (+15)
        execution = ['achieved', 'delivered', 'completed', 'exceeded', 
                    'commissioned', 'launched', 'executed']
        exec_count = sum(text_lower.count(k) for k in execution)
        
        if exec_count > 8:
            score += 15
            insights.append("✅ Strong execution track record")
        elif exec_count > 4:
            score += 8
        
        # NEGATIVE SIGNALS
        
        # 4. Excuse-Making (-20)
        excuses = ['external factors', 'macroeconomic', 'geopolitical', 
                  'beyond our control', 'market conditions']
        excuse_count = sum(text_lower.count(k) for k in excuses)
        
        if excuse_count > 5:
            score -= 20
            insights.append("🚩 Excessive excuse-making")
        elif excuse_count > 2:
            score -= 10
        
        # 5. Accounting Red Flags (-25)
        accounting_flags = ['one-time charge', 'exceptional item', 'goodwill impairment',
                          'restructuring charge', 'write-off', 'provision']
        accounting_count = sum(text_lower.count(k) for k in accounting_flags)
        
        if accounting_count > 3:
            score -= 25
            insights.append("🚩 Multiple one-time charges (red flag)")
        elif accounting_count > 1:
            score -= 10
        
        # 6. Corporate Jargon Overload (-15)
        jargon = ['synergy', 'transformational', 'strategic', 'leverage', 'going forward']
        jargon_count = sum(text_lower.count(k) for k in jargon)
        
        if jargon_count > 30:
            score -= 15
            insights.append("⚠️ Heavy corporate jargon")
        
        return max(-50, min(50, score)), insights
    
    def validate_moat_from_text(self, text: str, quant_moat_rating: str) -> Tuple[int, List[str]]:
        """
        Validate quantitative moat with qualitative evidence
        Returns: (score -30 to +30, evidence)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        evidence = []
        
        # 1. Network Effects (+10)
        network = ['platform', 'network effect', 'marketplace', 'ecosystem', 
                  'two-sided', 'users connect']
        network_count = sum(text_lower.count(k) for k in network)
        
        if network_count > 3:
            score += 10
            evidence.append("✅ Network effects mentioned")
        
        # 2. Switching Costs (+10)
        switching = ['customer retention', 'sticky', 'embedded', 'integration',
                    'lifetime value', 'switching cost', 'lock-in']
        switch_count = sum(text_lower.count(k) for k in switching)
        
        if switch_count > 3:
            score += 10
            evidence.append("✅ High switching costs")
        
        # 3. Brand/Pricing Power (+10)
        brand = ['brand equity', 'premium pricing', 'brand value', 'pricing power',
                'market leader', 'brand recognition']
        brand_count = sum(text_lower.count(k) for k in brand)
        
        if brand_count > 3:
            score += 10
            evidence.append("✅ Brand/pricing power")
        
        # 4. Competitive Pressure (negative)
        competition = ['intense competition', 'competitive pressure', 'price war',
                      'margin pressure', 'commoditized']
        comp_count = sum(text_lower.count(k) for k in competition)
        
        if comp_count > 3:
            score -= 20
            evidence.append("🚩 Intense competitive pressure")
        elif comp_count > 1:
            score -= 10
        
        # Cross-validate with quant
        if quant_moat_rating == 'Strong Moat' and score < 10:
            evidence.append("⚠️ Quant moat not confirmed qualitatively")
        elif quant_moat_rating == 'No Moat' and score > 20:
            evidence.append("✅ Hidden moat found in documents!")
        
        return max(-30, min(30, score)), evidence
    
    def check_capital_allocation_history(self, text: str) -> Tuple[int, List[str]]:
        """
        Validate capital allocation from documents
        Returns: (score -20 to +20, findings)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        findings = []
        
        # 1. Shareholder-Friendly Actions (+20)
        shareholder_actions = ['buyback', 'share buyback', 'share repurchase',
                             'dividend increase', 'special dividend']
        action_count = sum(text_lower.count(k) for k in shareholder_actions)
        
        if action_count > 3:
            score += 20
            findings.append("✅ Active shareholder returns (buybacks/dividends)")
        elif action_count > 1:
            score += 10
        
        # 2. Value-Destroying M&A (-20)
        ma_flags = ['acquisition', 'acquired', 'merger', 'consolidation', 
                   'diversification', 'new vertical']
        ma_count = sum(text_lower.count(k) for k in ma_flags)
        
        if ma_count > 5:
            score -= 15
            findings.append("⚠️ Frequent M&A activity (potential value destruction)")
        elif ma_count > 2:
            score -= 5
        
        # 3. Discipline Language (+10)
        discipline = ['disciplined approach', 'selective', 'focused', 
                     'core competency', 'return threshold']
        disc_count = sum(text_lower.count(k) for k in discipline)
        
        if disc_count > 3:
            score += 10
            findings.append("✅ Disciplined capital allocation")
        
        return max(-20, min(20, score)), findings
    
    def extract_strategic_updates(self, text: str) -> Tuple[int, List[str]]:
        """
        Extract strategic initiatives and growth plans from concall
        Returns: (score 0 to +20, strategic insights)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        insights = []
        
        # 1. Clear Strategic Initiatives (+10)
        strategy_keywords = ['new product launch', 'market expansion', 'capacity expansion',
                           'digital transformation', 'automation', 'technology upgrade',
                           'new facility', 'greenfield', 'brownfield']
        strategy_count = sum(text_lower.count(k) for k in strategy_keywords)
        
        if strategy_count > 3:
            score += 10
            insights.append("✅ Clear strategic initiatives outlined")
        elif strategy_count > 1:
            score += 5
        
        # 2. Geographic/Market Expansion (+5)
        expansion_keywords = ['international expansion', 'export growth', 'new markets',
                            'market share gain', 'penetration']
        expansion_count = sum(text_lower.count(k) for k in expansion_keywords)
        
        if expansion_count > 2:
            score += 5
            insights.append("✅ Geographic/market expansion plans")
        
        # 3. Innovation/R&D Focus (+5)
        innovation_keywords = ['r&d', 'research and development', 'innovation', 
                             'patent', 'new technology', 'product pipeline']
        innovation_count = sum(text_lower.count(k) for k in innovation_keywords)
        
        if innovation_count > 3:
            score += 5
            insights.append("✅ Strong R&D/innovation focus")
        
        return min(20, score), insights
    
    def extract_guidance_outlook(self, text: str) -> Tuple[int, List[str]]:
        """
        Extract forward guidance and outlook from concall (ENHANCED - catches all formats)
        Returns: (score -15 to +25, guidance insights)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        insights = []
        
        # 1. Extract Quantitative Revenue Growth Guidance (+15)
        revenue_patterns = [
            # Percentage patterns
            r'fy\d{2,4}.*?revenue.*?(\d{1,2})%',
            r'revenue.*?growth.*?(\d{1,2})%',
            r'guided.*?(\d{1,2})%.*?growth',
            r'targeting.*?(\d{1,2})%.*?revenue',
            r'growth.*?(\d{1,2})%\+',
            r'expect.*?revenue.*?(\d{1,2})%',
            r'top.*?line.*?growth.*?(\d{1,2})%',
            # Absolute growth patterns
            r'revenue.*?₹.*?(\d+).*?cr',
            r'targeting.*?₹.*?(\d+).*?cr.*?revenue'
        ]
        
        revenue_guidance = []
        for pattern in revenue_patterns:
            matches = re.findall(pattern, text_lower)
            revenue_guidance.extend([int(m) for m in matches if m.isdigit()])
        
        if revenue_guidance:
            max_guidance = max(revenue_guidance)
            if max_guidance >= 25:
                score += 15
                insights.append(f"✅ Strong revenue guidance ({max_guidance}%+ growth)")
            elif max_guidance >= 15:
                score += 10
                insights.append(f"✅ Positive revenue guidance ({max_guidance}% growth)")
            elif max_guidance >= 10:
                score += 5
        
        # 2. Profitability Return/Achievement Guidance (+15)
        # Catches: "Return to profitability", "Positive EBITDA", "Breakeven"
        profitability_patterns = [
            r'return to profitability',
            r'positive ebitda',
            r'positive operating profit',
            r'breakeven',
            r'profitable.*?(?:by|in|from)\s+(?:q[1-4]|fy\d{2})',
            r'ebitda.*?positive.*?(?:by|in|from)\s+(?:q[1-4]|fy\d{2})',
            r'expect.*?profitable',
            r'targeting.*?profitability'
        ]
        
        profitability_found = False
        for pattern in profitability_patterns:
            if re.search(pattern, text_lower):
                profitability_found = True
                # Extract timing if possible
                timing_match = re.search(r'(?:by|in|from)\s+(q[1-4]|fy\d{2}|\d+\s*months?)', text_lower)
                if timing_match:
                    score += 15
                    insights.append(f"✅ Profitability targeted {timing_match.group(1)}")
                else:
                    score += 12
                    insights.append("✅ Return to profitability expected")
                break
        
        # 3. Extract Margin Expansion Guidance (+10)
        margin_patterns = [
            # Percentage range patterns
            r'ebitda.*?margin.*?(\d{1,2})[–-](\d{1,2})%',
            r'margin.*?improv.*?(\d{1,2})%',
            r'margin.*?expan.*?(\d{1,2})%',
            r'opm.*?(\d{1,2})[–-](\d{1,2})%',
            # Target patterns
            r'margin.*?target.*?(\d{1,2})%',
            r'targeting.*?(\d{1,2})%.*?margin',
            r'expect.*?margin.*?(\d{1,2})%',
            # Improvement patterns (non-specific)
            r'margin.*?(?:improvement|improving|expansion)',
            r'positive.*?operating.*?leverage'
        ]
        
        margin_found = False
        for pattern in margin_patterns:
            matches = re.findall(pattern, text_lower)
            if matches:
                if isinstance(matches[0], tuple):
                    # Range like "28-30%"
                    margin_high = int(matches[0][1])
                    if margin_high >= 25:
                        score += 10
                        insights.append(f"✅ Strong margin guidance ({matches[0][0]}-{matches[0][1]}%)")
                        margin_found = True
                        break
                    elif margin_high >= 20:
                        score += 5
                        margin_found = True
                        break
                elif matches[0].isdigit():
                    # Single number
                    margin_val = int(matches[0])
                    if margin_val >= 25:
                        score += 10
                        insights.append(f"✅ Strong margin target ({margin_val}%)")
                        margin_found = True
                        break
                    elif margin_val >= 20:
                        score += 5
                        margin_found = True
                        break
        
        # If no specific numbers, check for qualitative margin improvement
        if not margin_found:
            margin_improvement_keywords = ['margin improvement', 'margin expansion', 
                                          'margins improving', 'positive operating leverage']
            margin_imp_count = sum(text_lower.count(k) for k in margin_improvement_keywords)
            if margin_imp_count > 2:
                score += 5
                insights.append("✅ Margin improvement expected")
        
        # 4. Debt Reduction Roadmap (+10)
        # Catches: "Debt reduction from ₹500 Cr to ₹200 Cr", "Debt-free by FY26"
        debt_roadmap_patterns = [
            r'debt.*?(?:reduction|reduced).*?(?:from|by).*?₹?(\d+).*?(?:cr|bn)',
            r'debt.*?free.*?(?:by|in)\s+(q[1-4]|fy\d{2}|\d+\s*months?)',
            r'target.*?debt.*?₹?(\d+).*?(?:cr|bn)',
            r'deleverag.*?plan',
            r'debt.*?roadmap',
            r'net.*?debt.*?(?:zero|nil).*?(?:by|in)'
        ]
        
        debt_roadmap_found = False
        for pattern in debt_roadmap_patterns:
            match = re.search(pattern, text_lower)
            if match:
                debt_roadmap_found = True
                # Try to extract specific numbers or timeline
                if 'debt free' in text_lower or 'debt-free' in text_lower:
                    score += 12
                    timing = re.search(r'(?:by|in)\s+(q[1-4]|fy\d{2}|\d+\s*months?)', text_lower)
                    if timing:
                        insights.append(f"✅ Debt-free targeted {timing.group(1)}")
                    else:
                        insights.append("✅ Debt-free roadmap outlined")
                else:
                    score += 10
                    insights.append("✅ Debt reduction plan outlined")
                break
        
        # 5. Balance Sheet Strength (Net Cash/Low Debt) (+5)
        balance_sheet_patterns = [
            r'net cash.*?₹?(\d+\.?\d*)\s*bn',
            r'debt free',
            r'zero debt',
            r'cash.*?₹?(\d+\.?\d*)\s*bn'
        ]
        
        for pattern in balance_sheet_patterns:
            if re.search(pattern, text_lower):
                score += 5
                insights.append("✅ Strong balance sheet (net cash/low debt)")
                break
        
        # 6. Positive Guidance Keywords - Catch-all (+8)
        positive_guidance = ['guidance raised', 'upgraded guidance', 'expect growth',
                           'improving outlook', 'positive momentum', 'expect improvement',
                           'margin expansion expected', 'targeting growth', 'outlook positive',
                           'expect strong', 'anticipate growth']
        pos_count = sum(text_lower.count(k) for k in positive_guidance)
        
        if pos_count > 3:
            score += 8
            if not any('guidance' in i for i in insights):
                insights.append("✅ Positive forward guidance")
        elif pos_count > 1:
            score += 4
        
        # 7. Negative Guidance Detection (-15)
        negative_guidance = ['guidance cut', 'lowered guidance', 'downgraded outlook',
                           'expect weakness', 'expect decline', 'challenging outlook',
                           'guidance revised down', 'downgrade forecast', 'weak outlook',
                           'expect pressure', 'headwinds expected']
        neg_count = sum(text_lower.count(k) for k in negative_guidance)
        
        if neg_count > 2:
            score -= 15
            insights.append("🚩 Guidance cut or negative outlook")
        elif neg_count > 0:
            score -= 8
            insights.append("⚠️ Cautious guidance")
        
        return max(-15, min(25, score)), insights  # Increased max from 20 to 25
    
    def extract_earning_triggers(self, text: str) -> Tuple[int, List[str]]:
        """
        Identify potential earning catalysts/triggers from concall (ENHANCED - Order Book Focus)
        Returns: (score 0 to +40, triggers identified)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        triggers = []
        
        # 1. ORDER BOOK ANALYSIS - LEADING INDICATOR (0-25 pts) ⭐ MASSIVELY ENHANCED!
        
        # 1a. Quantitative Order Book Size (+15)
        # Extract: "Order book of ₹500 Cr", "Backlog at ₹2,000 Cr"
        orderbook_size_patterns = [
            r'order\s+book.*?₹?(\d+\.?\d*)\s*(?:cr|bn)',
            r'backlog.*?₹?(\d+\.?\d*)\s*(?:cr|bn)',
            r'order.*?intake.*?₹?(\d+\.?\d*)\s*(?:cr|bn)',
            r'unexecuted.*?orders.*?₹?(\d+\.?\d*)\s*(?:cr|bn)'
        ]
        
        orderbook_value = []
        for pattern in orderbook_size_patterns:
            matches = re.findall(pattern, text_lower)
            for match in matches:
                try:
                    val = float(match)
                    orderbook_value.append(val)
                except:
                    pass
        
        if orderbook_value:
            max_ob = max(orderbook_value)
            score += 15
            triggers.append(f"💰 Order book ₹{max_ob:.0f} Cr (quantified visibility)")
        
        # 1b. Order Book Growth/Record Highs (+15)
        # Extract: "Order book increased 3x YoY", "All-time high order book"
        orderbook_growth_patterns = [
            r'order\s+book.*?(?:increased|grew).*?(\d+\.?\d*)x',
            r'backlog.*?(?:up|increased).*?(\d+)%',
            r'order\s+book.*?(\d+)%.*?(?:higher|growth)',
            r'order.*?intake.*?(\d+)%.*?(?:yoy|year)',
            r'all.time.high.*?order\s+book',
            r'record.*?order\s+book',
            r'highest.*?order\s+book'
        ]
        
        orderbook_growth = []
        record_high = False
        
        for pattern in orderbook_growth_patterns:
            if 'all.time.high' in pattern or 'record' in pattern or 'highest' in pattern:
                if re.search(pattern, text_lower):
                    record_high = True
            else:
                matches = re.findall(pattern, text_lower)
                for match in matches:
                    try:
                        if 'x' in pattern:
                            # Multiplier: "3x" = 300%
                            orderbook_growth.append(float(match) * 100)
                        else:
                            orderbook_growth.append(float(match))
                    except:
                        pass
        
        if record_high:
            score += 15
            triggers.append("🚀 Order book at all-time high (strong demand)")
        elif orderbook_growth and max(orderbook_growth) >= 100:
            # 2x or more growth
            score += 15
            triggers.append(f"🚀 Order book surged {max(orderbook_growth):.0f}% (explosive growth)")
        elif orderbook_growth and max(orderbook_growth) >= 30:
            score += 10
            triggers.append(f"✅ Order book up {max(orderbook_growth):.0f}%")
        
        # 1c. Revenue Visibility/Coverage (+10)
        # Extract: "2 quarters booked", "Visibility for 6 months", "90% capacity booked"
        visibility_patterns = [
            r'(?:visibility|booked|covered).*?(\d+)\s*(?:quarters?|months?)',
            r'(\d+)\s*(?:quarters?|months?).*?(?:visibility|booked)',
            r'(\d+)%.*?capacity.*?booked',
            r'order.*?cover.*?(\d+)\s*(?:quarters?|months?)'
        ]
        
        visibility_months = []
        for pattern in visibility_patterns:
            matches = re.findall(pattern, text_lower)
            for match in matches:
                try:
                    val = int(match)
                    # Convert quarters to months
                    if 'quarter' in text_lower[max(0, text_lower.find(match)-20):text_lower.find(match)+20]:
                        val = val * 3
                    visibility_months.append(val)
                except:
                    pass
        
        if visibility_months and max(visibility_months) >= 6:
            # 6+ months visibility
            score += 10
            triggers.append(f"✅ Strong revenue visibility ({max(visibility_months)} months)")
        elif visibility_months and max(visibility_months) >= 3:
            score += 6
            triggers.append(f"✅ Revenue visibility ({max(visibility_months)} months)")
        
        # Fallback: Generic order book mentions
        if not orderbook_value and not orderbook_growth and not record_high:
            contract_keywords = ['order book', 'order intake', 'contract win', 'order backlog',
                               'new contract', 'awarded', 'won order']
            contract_count = sum(text_lower.count(k) for k in contract_keywords)
            
            if contract_count > 3:
                score += 8
                triggers.append("✅ Order book/contract wins mentioned")
            elif contract_count > 1:
                score += 4
        
        
        # 2. Capacity Utilization/Expansion (+8)
        capacity_keywords = ['capacity utilization', 'operating at.*%', 'full capacity',
                           'capacity addition', 'ramp up', 'scaling up']
        capacity_count = sum(text_lower.count(k) for k in capacity_keywords)
        
        if capacity_count > 2:
            score += 8
            triggers.append("✅ Capacity expansion/high utilization")
        elif capacity_count > 0:
            score += 4
        
        # 3. Product Launches/Pipeline (+7)
        product_keywords = ['new product', 'product launch', 'product pipeline',
                          'product portfolio', 'new offering']
        product_count = sum(text_lower.count(k) for k in product_keywords)
        
        if product_count > 2:
            score += 7
            triggers.append("✅ New product launches/strong pipeline")
        elif product_count > 0:
            score += 3
        
        return min(40, score), triggers  # Increased from 25 to 40 (order book heavily weighted)
    
    def check_management_consistency(self, text: str) -> Tuple[int, List[str]]:
        """
        Check if management delivers on previous promises
        Returns: (score -20 to +20, consistency notes)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        notes = []
        
        # 1. Meeting Commitments (+20)
        delivery_keywords = ['as committed', 'as promised', 'as guided', 'delivered on',
                           'met our guidance', 'achieved our target', 'on track']
        delivery_count = sum(text_lower.count(k) for k in delivery_keywords)
        
        if delivery_count > 3:
            score += 20
            notes.append("✅ Consistently delivers on commitments")
        elif delivery_count > 1:
            score += 10
        
        # 2. Missing Commitments (-20)
        miss_keywords = ['missed guidance', 'fell short', 'did not achieve', 
                        'below guidance', 'delayed from original']
        miss_count = sum(text_lower.count(k) for k in miss_keywords)
        
        if miss_count > 2:
            score -= 20
            notes.append("🚩 Frequently misses commitments")
        elif miss_count > 0:
            score -= 10
        
        # 3. Changing Narrative (-10)
        narrative_keywords = ['revised approach', 'change in strategy', 'different from',
                            'pivoting', 'reconsidering']
        narrative_count = sum(text_lower.count(k) for k in narrative_keywords)
        
        if narrative_count > 3:
            score -= 10
            notes.append("⚠️ Frequently changing narrative")
        
        return max(-20, min(20, score)), notes
    
    def analyze_quarterly_momentum(self, text: str) -> Tuple[int, List[str]]:
        """
        Detect recent quarterly acceleration/inflection points
        Returns: (score -10 to +20, momentum signals)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        signals = []
        
        # 1. Sequential Quarter Acceleration (+15)
        sequential_keywords = ['sequentially', 'quarter-on-quarter', 'qoq', 'q-o-q',
                             'sequential growth', 'compared to previous quarter']
        seq_count = sum(text_lower.count(k) for k in sequential_keywords)
        
        # Look for specific QoQ growth mentions
        qoq_patterns = [
            r'sequential.*?growth.*?(\d{1,2})%',
            r'qoq.*?(\d{1,2})%',
            r'quarter.*?grew.*?(\d{1,2})%'
        ]
        
        qoq_growth = []
        for pattern in qoq_patterns:
            matches = re.findall(pattern, text_lower)
            qoq_growth.extend([int(m) for m in matches if m.isdigit()])
        
        if qoq_growth and max(qoq_growth) > 10:
            score += 15
            signals.append(f"🚀 Strong QoQ momentum ({max(qoq_growth)}%)")
        elif seq_count > 2:
            score += 8
            signals.append("✅ Sequential quarter acceleration")
        
        # 2. Inflection Point Language (+10)
        inflection_keywords = ['inflection', 'turning point', 'momentum building',
                             'gaining traction', 'acceleration', 'picking up pace',
                             'improving trajectory']
        infl_count = sum(text_lower.count(k) for k in inflection_keywords)
        
        if infl_count > 2:
            score += 10
            signals.append("✅ Inflection point identified")
        elif infl_count > 0:
            score += 5
        
        # 3. Recent Deceleration (-10)
        decel_keywords = ['slowing down', 'deceleration', 'momentum slowed',
                        'growth moderation', 'tapering']
        decel_count = sum(text_lower.count(k) for k in decel_keywords)
        
        if decel_count > 2:
            score -= 10
            signals.append("🚩 Momentum slowing")
        
        return max(-10, min(20, score)), signals
    
    def detect_forward_confidence(self, text: str) -> Tuple[int, List[str]]:
        """
        Detect management confidence in forward outlook
        Returns: (score -15 to +20, confidence signals)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        signals = []
        
        # 1. Strong Confidence Language (+20)
        confidence_keywords = ['confident', 'well positioned', 'optimistic', 'bullish',
                             'strong visibility', 'positive outlook', 'expect strong',
                             'momentum continues', 'acceleration ahead']
        conf_count = sum(text_lower.count(k) for k in confidence_keywords)
        
        if conf_count > 8:
            score += 20
            signals.append("✅ Management highly confident in outlook")
        elif conf_count > 4:
            score += 12
            signals.append("✅ Management confident")
        elif conf_count > 1:
            score += 6
        
        # 2. Cautious/Uncertain Language (-15)
        caution_keywords = ['uncertain', 'cautious', 'wait and see', 'remain watchful',
                          'difficult to predict', 'unclear outlook', 'volatile environment']
        caut_count = sum(text_lower.count(k) for k in caution_keywords)
        
        if caut_count > 5:
            score -= 15
            signals.append("🚩 Management cautious/uncertain")
        elif caut_count > 2:
            score -= 8
        
        return max(-15, min(20, score)), signals
    
    def detect_sector_tailwinds(self, text: str) -> Tuple[int, List[str]]:
        """
        Identify sector/macro tailwinds benefiting the company
        Returns: (score 0 to +15, tailwinds identified)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        tailwinds = []
        
        # 1. Government Support/PLI (+10)
        govt_keywords = ['pli scheme', 'government support', 'policy support',
                        'subsidies', 'incentives', 'government backing',
                        'make in india', 'atmanirbhar']
        govt_count = sum(text_lower.count(k) for k in govt_keywords)
        
        if govt_count > 2:
            score += 10
            tailwinds.append("✅ Government support/PLI benefits")
        elif govt_count > 0:
            score += 5
        
        # 2. Structural Demand Drivers (+8)
        demand_keywords = ['structural demand', 'secular growth', 'industry tailwind',
                         'favorable demographics', 'urbanization', 'penetration increasing',
                         'market underpenetrated']
        demand_count = sum(text_lower.count(k) for k in demand_keywords)
        
        if demand_count > 2:
            score += 8
            tailwinds.append("✅ Structural demand tailwinds")
        elif demand_count > 0:
            score += 4
        
        # 3. Import Substitution (+5)
        import_keywords = ['import substitution', 'china plus one', 'localization',
                         'domestic manufacturing', 'replacing imports']
        import_count = sum(text_lower.count(k) for k in import_keywords)
        
        if import_count > 1:
            score += 5
            tailwinds.append("✅ Import substitution opportunity")
        
        return min(15, score), tailwinds
    
    def track_debt_trajectory(self, text: str) -> Tuple[int, List[str]]:
        """
        Track debt reduction trajectory (QoQ improvement)
        Returns: (score -10 to +15, debt insights)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        insights = []
        
        # 1. Debt Reduction Mentioned (+15)
        reduction_keywords = ['debt reduction', 'deleveraging', 'reduced debt',
                            'debt paydown', 'becoming debt free', 'net debt reduced']
        reduction_count = sum(text_lower.count(k) for k in reduction_keywords)
        
        # Extract specific debt reduction numbers
        debt_patterns = [
            r'debt.*?reduced.*?(\d{1,2})%',
            r'deleverag.*?(\d{1,2})%',
            r'net debt.*?down.*?(\d{1,2})%'
        ]
        
        debt_reduction_pct = []
        for pattern in debt_patterns:
            matches = re.findall(pattern, text_lower)
            debt_reduction_pct.extend([int(m) for m in matches if m.isdigit()])
        
        if debt_reduction_pct and max(debt_reduction_pct) > 20:
            score += 15
            insights.append(f"✅ Significant debt reduction ({max(debt_reduction_pct)}%)")
        elif reduction_count > 2:
            score += 10
            insights.append("✅ Active deleveraging")
        elif reduction_count > 0:
            score += 5
        
        # 2. Debt Concern/Increasing (-10)
        concern_keywords = ['debt levels increased', 'borrowing increased',
                          'leverage rising', 'debt pressure']
        concern_count = sum(text_lower.count(k) for k in concern_keywords)
        
        if concern_count > 2:
            score -= 10
            insights.append("🚩 Debt levels increasing")
        
        return max(-10, min(15, score)), insights
    
    def detect_premiumization(self, text: str) -> Tuple[int, List[str]]:
        """
        Detect premium positioning and value migration
        Returns: (score 0 to +15, positioning insights)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        insights = []
        
        # 1. Premiumization Strategy (+15)
        premium_keywords = ['premiumization', 'premium segment', 'premium products',
                          'moving upmarket', 'premium portfolio', 'luxury segment',
                          'high-end products', 'premium pricing']
        premium_count = sum(text_lower.count(k) for k in premium_keywords)
        
        if premium_count > 3:
            score += 15
            insights.append("✅ Premiumization strategy (moving upmarket)")
        elif premium_count > 1:
            score += 8
            insights.append("✅ Premium segment focus")
        
        # 2. Market Leadership (+8)
        leadership_keywords = ['market leader', 'leading position', 'number one',
                             '#1 in', 'largest player', 'dominant position']
        leader_count = sum(text_lower.count(k) for k in leadership_keywords)
        
        if leader_count > 2:
            score += 8
            insights.append("✅ Market leadership position")
        elif leader_count > 0:
            score += 4
        
        return min(15, score), insights
    
    def detect_recent_transformation(self, text: str) -> Tuple[int, List[str]]:
        """
        Detect recent business transformations (last 12 months)
        Returns: (score 0 to +25, transformation signals)
        """
        if not text or len(text) < 100:
            return 0, []
        
        text_lower = text.lower()
        score = 0
        signals = []
        
        # 1. Divestiture/Asset Sale (Simplification) (+10)
        divestiture_keywords = ['divest', 'divestiture', 'sold business', 'exited',
                              'disposed', 'hive off', 'demerger', 'asset sale',
                              'non-core business sold']
        divest_count = sum(text_lower.count(k) for k in divestiture_keywords)
        
        if divest_count > 2:
            score += 10
            signals.append("✅ Divestiture/simplification (focus on core)")
        elif divest_count > 0:
            score += 5
        
        # 2. New Leadership/Management Change (+8)
        leadership_keywords = ['new ceo', 'new management', 'appointed ceo', 'leadership change',
                             'management restructure', 'new leadership team']
        leadership_count = sum(text_lower.count(k) for k in leadership_keywords)
        
        if leadership_count > 1:
            score += 8
            signals.append("✅ New leadership/management change")
        
        # 3. Strategic Pivot/Repositioning (+10)
        pivot_keywords = ['strategic pivot', 'repositioning', 'business transformation',
                        'shift to', 'focus on', 'strategic shift', 'realignment']
        pivot_count = sum(text_lower.count(k) for k in pivot_keywords)
        
        if pivot_count > 3:
            score += 10
            signals.append("✅ Strategic pivot/business transformation")
        elif pivot_count > 1:
            score += 5
        
        # 4. Debt Restructuring (+7)
        restructure_keywords = ['debt restructuring', 'refinancing', 'restructured debt',
                              'one-time settlement', 'debt resolution']
        restructure_count = sum(text_lower.count(k) for k in restructure_keywords)
        
        if restructure_count > 1:
            score += 7
            signals.append("✅ Debt restructuring completed")
        
        return min(25, score), signals
    
    def analyze_company_documents(self, company_symbol: str) -> Dict:
        """
        Complete document analysis for a company
        """
        # Find documents
        concall_path = None
        report_path = None
        
        # Search for concall
        concalls_list = list(Path(self.concalls_dir).glob(f"{company_symbol}*.pdf"))
        if concalls_list:
            concall_path = concalls_list[0]
        
        # Search for report
        reports_list = list(Path(self.reports_dir).glob(f"{company_symbol}*.pdf"))
        if reports_list:
            report_path = reports_list[0]
        
        if not concall_path and not report_path:
            return {
                'has_documents': False,
                'qual_score': 0,
                'confidence': 'No Documents',
                'insights': [],
                'red_flags': []
            }
        
        # Extract text
        all_text = ""
        docs_analyzed = []
        
        if concall_path:
            logger.info(f"   📄 Reading concall...")
            concall_text = self.extract_pdf_text(str(concall_path))
            all_text += concall_text
            if concall_text and len(concall_text) > 100:
                docs_analyzed.append('Concall')
        
        if report_path:
            logger.info(f"   📄 Reading annual report...")
            report_text = self.extract_pdf_text(str(report_path))
            all_text += report_text
            if report_text and len(report_text) > 100:
                docs_analyzed.append('Annual Report')
        
        if not all_text or len(all_text) < 100:
            return {
                'has_documents': True,
                'qual_score': 0,
                'confidence': 'Unreadable Documents',
                'insights': [],
                'red_flags': []
            }
        
        # Analyze all dimensions (ENHANCED - Forward-Looking)
        mgmt_score, mgmt_insights = self.score_management_quality(all_text)
        strategy_score, strategy_insights = self.extract_strategic_updates(all_text)
        guidance_score, guidance_insights = self.extract_guidance_outlook(all_text)
        triggers_score, triggers_insights = self.extract_earning_triggers(all_text)
        consistency_score, consistency_notes = self.check_management_consistency(all_text)
        
        # NEW: Forward-looking analyzers (catch market momentum)
        momentum_score, momentum_signals = self.analyze_quarterly_momentum(all_text)
        confidence_score, confidence_signals = self.detect_forward_confidence(all_text)
        tailwind_score, tailwind_insights = self.detect_sector_tailwinds(all_text)
        debt_traj_score, debt_insights = self.track_debt_trajectory(all_text)
        premium_score, premium_insights = self.detect_premiumization(all_text)
        transform_score, transform_signals = self.detect_recent_transformation(all_text)
        
        # Store for later moat/capital validation
        self._last_text = all_text
        self._docs_analyzed = docs_analyzed
        
        # Calculate comprehensive qualitative score (ENHANCED - FORWARD-LOOKING)
        # Base 50, then add/subtract from ALL dimensions
        qual_score = (50 
                     + mgmt_score           # -50 to +50
                     + strategy_score       # 0 to +20
                     + guidance_score       # -15 to +25 (ENHANCED - profitability, margin, debt roadmaps)
                     + triggers_score       # 0 to +40 (ENHANCED - order book heavily weighted!)
                     + consistency_score    # -20 to +20
                     + momentum_score       # -10 to +20 (NEW - QoQ inflection points)
                     + confidence_score     # -15 to +20 (NEW - forward confidence)
                     + tailwind_score       # 0 to +15 (NEW - sector tailwinds)
                     + debt_traj_score      # -10 to +15 (NEW - debt trajectory)
                     + premium_score        # 0 to +15 (NEW - premiumization)
                     + transform_score)     # 0 to +25 (NEW - recent transformation)
        
        # Theoretical max: 50 + 50 + 20 + 25 + 40 + 20 + 20 + 20 + 15 + 15 + 15 + 25 = 315
        # Practical range: 0-200, with most companies 40-120
        # Normalize to 0-100 for display (but allow >100 for exceptional cases)
        
        # Combine all insights
        all_insights = (mgmt_insights + strategy_insights + guidance_insights 
                       + triggers_insights + consistency_notes + momentum_signals
                       + confidence_signals + tailwind_insights + debt_insights
                       + premium_insights + transform_signals)
        
        return {
            'has_documents': True,
            'qual_score': max(0, min(100, qual_score)),
            
            # Score breakdown (for transparency)
            'management_score': mgmt_score,
            'strategy_score': strategy_score,
            'guidance_score': guidance_score,
            'triggers_score': triggers_score,
            'consistency_score': consistency_score,
            'momentum_score': momentum_score,           # NEW
            'confidence_score': confidence_score,       # NEW
            'tailwind_score': tailwind_score,           # NEW
            'debt_trajectory_score': debt_traj_score,   # NEW
            'premium_score': premium_score,             # NEW
            'transformation_score': transform_score,    # NEW
            
            'docs_analyzed': docs_analyzed,
            'insights': all_insights,
            'word_count': len(all_text.split())
        }
    
    def enhance_with_context(self, qual_result: Dict, quant_metrics: Dict) -> Dict:
        """
        Enhance qualitative analysis with quantitative context
        """
        if not hasattr(self, '_last_text') or not self._last_text:
            return qual_result
        
        text = self._last_text
        qual_score = qual_result['qual_score']
        
        # Moat validation
        quant_moat = quant_metrics.get('moat_rating', 'Unknown')
        moat_score, moat_evidence = self.validate_moat_from_text(text, quant_moat)
        qual_score += moat_score
        qual_result['insights'].extend(moat_evidence)
        
        # Capital allocation validation
        cap_score, cap_findings = self.check_capital_allocation_history(text)
        qual_score += cap_score
        qual_result['insights'].extend(cap_findings)
        
        # Update final score
        qual_result['qual_score'] = max(0, min(100, qual_score))
        qual_result['moat_validation_score'] = moat_score
        qual_result['capital_allocation_score'] = cap_score
        
        return qual_result


class IntegratedAnalyzer:
    """
    Combines quantitative filter with qualitative analysis
    """
    
    def __init__(self, data_dir: str = "output", downloads_dir: str = "downloads"):
        self.quant_filter = InvestmentFilter(data_dir=data_dir)
        self.qual_analyzer = QualitativeAnalyzer(downloads_dir=downloads_dir)
        self.results = []
    
    def analyze_company(self, company_symbol: str) -> Optional[Dict]:
        """
        Complete integrated analysis
        """
        logger.info(f"\n{'='*70}")
        logger.info(f"INTEGRATED ANALYSIS: {company_symbol}")
        logger.info(f"{'='*70}")
        
        # STEP 1: Quantitative Analysis
        logger.info("\n📊 QUANTITATIVE FILTER (4-Tier Pyramid)...")
        quant_result = self.quant_filter.analyze_company(company_symbol)
        
        if not quant_result:
            logger.warning(f"❌ No quantitative data for {company_symbol}")
            return None
        
        # STEP 2: Qualitative Analysis (for ALL companies to understand WHY)
        qual_result = None
        
        # Always analyze documents to get complete picture
        logger.info("\n📚 QUALITATIVE ANALYSIS (Documents)...")
        qual_result = self.qual_analyzer.analyze_company_documents(company_symbol)
        
        if qual_result and qual_result['has_documents']:  # Only enhance if docs found
            logger.info(f"   ✅ Analyzed: {', '.join(qual_result['docs_analyzed'])}")
            logger.info(f"   📊 Qual Score: {qual_result['qual_score']:.1f}/100")
            logger.info(f"   📄 Words analyzed: {qual_result.get('word_count', 0):,}")
            
            # Show score breakdown (NEW - Forward-Looking Components)
            logger.info(f"\n   📈 Score Breakdown (Forward-Looking Analysis):")
            logger.info(f"      Management:      {qual_result.get('management_score', 0):+4d}")
            logger.info(f"      Strategy:        {qual_result.get('strategy_score', 0):+4d}")
            logger.info(f"      Guidance:        {qual_result.get('guidance_score', 0):+4d}")
            logger.info(f"      Triggers:        {qual_result.get('triggers_score', 0):+4d}")
            logger.info(f"      Consistency:     {qual_result.get('consistency_score', 0):+4d}")
            logger.info(f"      Momentum (QoQ):  {qual_result.get('momentum_score', 0):+4d}  ⭐ NEW!")
            logger.info(f"      Confidence:      {qual_result.get('confidence_score', 0):+4d}  ⭐ NEW!")
            logger.info(f"      Tailwinds:       {qual_result.get('tailwind_score', 0):+4d}  ⭐ NEW!")
            logger.info(f"      Debt Trajectory: {qual_result.get('debt_trajectory_score', 0):+4d}  ⭐ NEW!")
            logger.info(f"      Premiumization:  {qual_result.get('premium_score', 0):+4d}  ⭐ NEW!")
            logger.info(f"      Transformation:  {qual_result.get('transformation_score', 0):+4d}  ⭐ NEW!")
            
            # Enhance with context
            qual_result = self.qual_analyzer.enhance_with_context(
                qual_result, 
                quant_result['metrics']
            )
            
            # Show insights
            if qual_result['insights']:
                logger.info(f"\n   💡 Key Insights (Top 8):")
                for insight in qual_result['insights'][:8]:
                    logger.info(f"      {insight}")
        else:
            logger.info("   ⚠️ No documents available")
        
        # STEP 3: Final Decision
        logger.info(f"\n{'='*70}")
        logger.info("FINAL DECISION:")
        logger.info(f"{'='*70}")
        
        final_decision = self._make_integrated_decision(quant_result, qual_result)
        
        logger.info(f"\n{final_decision['final_action']}")
        logger.info(f"Confidence: {final_decision['confidence']}")
        logger.info(f"Reason: {final_decision['final_reason']}")
        logger.info(f"{'='*70}")
        
        return final_decision
    
    def _make_integrated_decision(self, quant_result: Dict, 
                                  qual_result: Optional[Dict]) -> Dict:
        """
        Integrate quant + qual for final decision (Enhanced for Turnarounds)
        
        Decision Matrix:
        ┌─────────────────┬──────────────────┬─────────────────────────────────┐
        │  Quant Decision │ Qual Score       │ Final Decision                  │
        ├─────────────────┼──────────────────┼─────────────────────────────────┤
        │  BUY            │ >70              │ HIGH CONV BUY ⭐⭐⭐              │
        │  BUY            │ 50-70            │ BUY                             │
        │  BUY            │ <50              │ WATCH (qual concerns)           │
        │  WATCH          │ >80              │ BUY (mgmt worth premium)        │
        │  WATCH          │ 50-80            │ WATCH                           │
        │  WATCH          │ <50              │ PASS                            │
        │  PASS           │ >85 + turnaround │ WATCH (turnaround + guidance) ← NEW!
        │  PASS           │ >85              │ WATCH (exceptional qual)        │
        │  PASS           │ <85              │ PASS                            │
        └─────────────────┴──────────────────┴─────────────────────────────────┘
        """
        
        quant_decision = quant_result['decision']
        qual_score = qual_result['qual_score'] if qual_result and qual_result['has_documents'] else 50
        quant_metrics = quant_result.get('metrics', {})
        
        # Check if this is a turnaround story
        is_turnaround = quant_metrics.get('is_turnaround', False)
        margin_improving = quant_metrics.get('margin_improving', False)
        moat_score = quant_metrics.get('moat_score', 0)
        
        # Decision logic
        if quant_decision == 'PASS':
            # Enhanced logic for turnarounds with strong qualitative signals
            if qual_score > 85 and (is_turnaround or margin_improving) and moat_score >= 50:
                final = 'WATCH'
                confidence = 'Medium'
                reason = "Turnaround story: Weak historical numbers BUT strong forward guidance + improving margins"
                action = "⚠️ WATCH - Turnaround with exceptional management"
            elif qual_score > 85:
                final = 'WATCH'
                confidence = 'Medium'
                reason = "Weak historical numbers BUT exceptional management + strong forward guidance"
                action = "⚠️ WATCH - Exceptional qual despite weak quant"
            else:
                final = 'PASS'
                confidence = 'High'
                reason = quant_result['reason']
                action = "🚫 PASS"
        
        elif quant_decision == 'BUY':
            if qual_score > 70:
                final = 'HIGH_CONVICTION_BUY'
                confidence = 'Very High'
                reason = f"{quant_result['reason']} + Exceptional management quality"
                action = "⭐⭐⭐ HIGH CONVICTION BUY"
            elif qual_score > 50:
                final = 'BUY'
                confidence = 'High'
                reason = quant_result['reason']
                action = "✅ BUY"
            else:
                final = 'WATCH'
                confidence = 'Medium'
                reason = "Good numbers, but management/qualitative concerns"
                action = "⚠️ WATCH - Qual concerns despite good numbers"
        
        elif quant_decision == 'WATCH':
            if qual_score > 80:
                # Exceptional management can justify premium
                final = 'BUY'
                confidence = 'Medium-High'
                reason = "Slightly expensive but exceptional management quality"
                action = "✅ BUY - Quality management worth premium"
            elif qual_score > 50:
                final = 'WATCH'
                confidence = 'Medium'
                reason = quant_result['reason']
                action = "⚠️ WATCH"
            else:
                final = 'PASS'
                confidence = 'Medium'
                reason = "Average quality + Management concerns"
                action = "🚫 PASS - Better opportunities elsewhere"
        
        else:
            final = quant_decision
            confidence = 'Medium'
            reason = quant_result['reason']
            action = quant_result['action']
        
        # Combine results
        integrated = {
            **quant_result,
            'final_decision': final,
            'final_action': action,
            'final_reason': reason,
            'confidence': confidence,
            'qual_score': qual_score,
            'qual_insights': qual_result['insights'] if qual_result else [],
            'has_documents': qual_result['has_documents'] if qual_result else False
        }
        
        return integrated
    
    def scan_all_companies(self) -> pd.DataFrame:
        """
        Analyze all companies with integrated approach
        """
        logger.info(f"\n{'🚀 '*35}")
        logger.info("INTEGRATED ANALYZER - Quantitative + Qualitative")
        logger.info(f"{'🚀 '*35}")
        
        # Get all companies
        pnl_dir = os.path.join(self.quant_filter.data_dir, "pnl_data")
        if not os.path.exists(pnl_dir):
            logger.error(f"Data directory not found: {pnl_dir}")
            return pd.DataFrame()
        
        companies = [
            f.replace('_pnl.csv', '')
            for f in os.listdir(pnl_dir)
            if f.endswith('_pnl.csv')
        ]
        
        logger.info(f"\n📊 Found {len(companies)} companies to analyze")
        logger.info(f"⏱️  Estimated time: {len(companies) * 5 / 60:.1f} minutes\n")
        
        results = []
        for i, company in enumerate(companies, 1):
            logger.info(f"\n[{i}/{len(companies)}] {company}")
            result = self.analyze_company(company)
            if result:
                results.append(result)
        
        # Convert to DataFrame
        df = self._results_to_dataframe(results)
        
        return df
    
    def _results_to_dataframe(self, results: List[Dict]) -> pd.DataFrame:
        """Convert results to structured DataFrame"""
        
        rows = []
        for r in results:
            m = r['metrics']
            
            row = {
                'Company': r['company'],
                'Final_Decision': r['final_decision'],
                'Final_Action': r['final_action'],
                'Confidence': r['confidence'],
                'Reason': r['final_reason'],
                
                # Quant
                'Quality_Grade': r['quality_grade'],
                'Moat_Rating': r['moat_rating'],
                'Valuation': r['valuation'],
                
                # Qual
                'Qual_Score': r['qual_score'],
                'Has_Documents': r['has_documents'],
                
                # Key Metrics
                'ROIC_%': m.get('roic', 0),
                'FCF_Conversion': m.get('fcf_conversion', 0),
                'Revenue_CAGR_5Y_%': m.get('revenue_cagr_5y', 0),
                'Gross_Margin_%': m.get('gross_margin', 0),
                'Asset_Turnover': m.get('asset_turnover', 0),
                'CCC_Days': m.get('ccc', 0),
                'Debt_Equity': m.get('debt_equity', 0),
                'P/E': m.get('pe_ratio', 0),
                'PEG': m.get('peg', 0),
                
                # Insights
                'Strengths': ' | '.join(r['strengths'][:3]),
                'Qual_Insights': ' | '.join(r['qual_insights'][:3])
            }
            
            rows.append(row)
        
        df = pd.DataFrame(rows)
        
        # Sort by decision priority
        decision_order = {
            'HIGH_CONVICTION_BUY': 0,
            'BUY': 1,
            'WATCH': 2,
            'PASS': 3
        }
        df['_sort'] = df['Final_Decision'].map(decision_order)
        df = df.sort_values(['_sort', 'Qual_Score'], ascending=[True, False])
        df = df.drop('_sort', axis=1)
        df.insert(0, 'Rank', range(1, len(df) + 1))
        
        return df
    
    def generate_report(self, df: pd.DataFrame):
        """Generate final actionable report"""
        
        print("\n" + "="*90)
        print("INTEGRATED ANALYSIS RESULTS - Quant + Qual".center(90))
        print("="*90)
        
        # Check if DataFrame is empty
        if df.empty:
            print("\n⚠️  No companies analyzed. Please check:")
            print("   1. Data directory contains PNL files")
            print("   2. Path to data directory is correct")
            return
        
        # Summary
        high_conv = len(df[df['Final_Decision'] == 'HIGH_CONVICTION_BUY'])
        buy = len(df[df['Final_Decision'] == 'BUY'])
        watch = len(df[df['Final_Decision'] == 'WATCH'])
        pass_count = len(df[df['Final_Decision'] == 'PASS'])
        
        print(f"\n📊 Investment Actions:")
        print(f"   ⭐⭐⭐ HIGH CONVICTION BUY: {high_conv} companies")
        print(f"   ✅ BUY: {buy} companies")
        print(f"   ⚠️  WATCH: {watch} companies")
        print(f"   🚫 PASS: {pass_count} companies")
        
        with_docs = len(df[df['Has_Documents'] == True])
        print(f"\n📚 Document Coverage: {with_docs}/{len(df)} companies")
        
        # HIGH CONVICTION BUYS
        if high_conv > 0:
            print(f"\n{'='*90}")
            print("⭐⭐⭐ HIGH CONVICTION BUYS (Quant + Qual Aligned)")
            print("="*90)
            
            hc_df = df[df['Final_Decision'] == 'HIGH_CONVICTION_BUY']
            for idx, row in hc_df.iterrows():
                print(f"\n{row['Company']}")
                print(f"   Confidence: {row['Confidence']}")
                print(f"   Quality: {row['Quality_Grade']} | Moat: {row['Moat_Rating']} | Valuation: {row['Valuation']}")
                print(f"   Qual Score: {row['Qual_Score']:.1f}/100")
                print(f"   📈 ROIC: {row['ROIC_%']:.1f}% | FCF Conv: {row['FCF_Conversion']:.2f}x | Growth: {row['Revenue_CAGR_5Y_%']:.1f}%")
                if row['Qual_Insights']:
                    print(f"   💡 {row['Qual_Insights'][:150]}...")
        
        # REGULAR BUYS
        if buy > 0:
            print(f"\n{'='*90}")
            print("✅ BUY RECOMMENDATIONS")
            print("="*90)
            
            buy_df = df[df['Final_Decision'] == 'BUY'].head(10)
            for idx, row in buy_df.iterrows():
                print(f"\n{row['Company']}")
                print(f"   Quality: {row['Quality_Grade']} | Moat: {row['Moat_Rating']} | Valuation: {row['Valuation']}")
                print(f"   📈 ROIC: {row['ROIC_%']:.1f}% | Growth: {row['Revenue_CAGR_5Y_%']:.1f}%")
        
        print(f"\n{'='*90}")
    
    def save_results(self, df: pd.DataFrame):
        """Save results to CSV"""
        if df.empty:
            print("\n⚠️  No results to save (DataFrame is empty)")
            return None
            
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"integrated_analysis_{timestamp}.csv"
        
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        
        print(f"\n📁 Results saved: {filename}")
        print("="*90)
        
        return filename


def main():
    """Run integrated analysis"""
    
    # Check dependencies
    try:
        import PyPDF2
    except ImportError:
        print("Installing PyPDF2...")
        import subprocess, sys
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'PyPDF2', '--quiet'])
    
    # Initialize
    analyzer = IntegratedAnalyzer(data_dir="output", downloads_dir="downloads")
    
    # Scan all companies
    df = analyzer.scan_all_companies()
    
    # Generate report
    analyzer.generate_report(df)
    
    # Save
    analyzer.save_results(df)


if __name__ == "__main__":
    main()

