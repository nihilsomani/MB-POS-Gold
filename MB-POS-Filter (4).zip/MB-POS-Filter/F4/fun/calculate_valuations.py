#!/usr/bin/env python3
"""
Valuation Calculator - Merges scraper data with financial scanner to calculate EV/OCF metrics
Implements Aditya Khemka's valuation framework
"""

import pandas as pd
import numpy as np
import glob
import os
import logging

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)


def calculate_valuation_metrics(financial_scan_csv, scraper_csv):
    """
    Calculate valuation metrics by merging financial scan with scraper data
    
    Args:
        financial_scan_csv: Path to financial_scan_*.csv (from financial_scanner.py)
        scraper_csv: Path to stage2_shortlist_*.csv (from my_scraper.py)
    """
    
    logger.info("="*80)
    logger.info("VALUATION METRICS CALCULATOR - Khemka Framework")
    logger.info("="*80)
    
    # Load data
    logger.info(f"\n📊 Loading data...")
    df_financial = pd.read_csv(financial_scan_csv)
    df_scraper = pd.read_csv(scraper_csv)
    
    logger.info(f"   Financial scan: {len(df_financial)} companies")
    logger.info(f"   Scraper data: {len(df_scraper)} companies")
    
    # Merge on company symbol/name
    df_merged = df_financial.merge(
        df_scraper[['company_name', 'market_cap', 'enterprise_value', 'current_price', 
                    'promoter_holding', 'latest_fcf', 'avg_fcf_3y']],
        left_on='Company',
        right_on='company_name',
        how='left'
    )
    
    logger.info(f"   Merged: {len(df_merged)} companies\n")
    
    # Calculate valuation metrics
    logger.info("🧮 Calculating valuation metrics...")
    
    # 1. EV/OCF - Khemka's primary valuation metric
    df_merged['EV_to_OCF'] = np.where(
        df_merged['enterprise_value'].notna() & (df_merged['Sales_Cr'] > 0),
        df_merged['enterprise_value'] / (df_merged['Sales_Cr'] * df_merged['OCF_to_Revenue_%'] / 100),
        np.nan
    )
    
    # Alternative: If we have OCF directly
    # For companies where we can calculate OCF from revenue and OCF%
    df_merged['Calculated_OCF'] = df_merged['Sales_Cr'] * 100 * df_merged['OCF_to_Revenue_%'] / 100
    df_merged['EV_to_OCF'] = np.where(
        df_merged['Calculated_OCF'] > 0,
        df_merged['enterprise_value'] / df_merged['Calculated_OCF'],
        np.nan
    )
    
    # 2. Price to FCF (using Market Cap)
    df_merged['Price_to_FCF'] = np.where(
        (df_merged['market_cap'] > 0) & (df_merged['Free_Cash_Flow'] > 0),
        df_merged['market_cap'] / df_merged['Free_Cash_Flow'],
        np.nan
    )
    
    # If FCF from scraper is available
    df_merged['Price_to_FCF_Scraper'] = np.where(
        (df_merged['market_cap'] > 0) & (df_merged['latest_fcf'].notna()) & (df_merged['latest_fcf'] > 0),
        df_merged['market_cap'] / df_merged['latest_fcf'],
        np.nan
    )
    
    # Use scraper FCF if available, otherwise scanner FCF
    df_merged['Price_to_FCF_Final'] = df_merged['Price_to_FCF_Scraper'].fillna(df_merged['Price_to_FCF'])
    
    # 3. OCF Yield = OCF / Market Cap (%)
    df_merged['OCF_Yield_%'] = np.where(
        (df_merged['market_cap'] > 0) & (df_merged['Calculated_OCF'] > 0),
        (df_merged['Calculated_OCF'] / df_merged['market_cap']) * 100,
        np.nan
    )
    
    # 4. FCF Yield = FCF / Market Cap (%)
    df_merged['FCF_Yield_%'] = np.where(
        (df_merged['market_cap'] > 0) & (df_merged['Free_Cash_Flow'] > 0),
        (df_merged['Free_Cash_Flow'] / df_merged['market_cap']) * 100,
        np.nan
    )
    
    # If FCF from scraper
    df_merged['FCF_Yield_Scraper_%'] = np.where(
        (df_merged['market_cap'] > 0) & (df_merged['latest_fcf'].notna()) & (df_merged['latest_fcf'] > 0),
        (df_merged['latest_fcf'] / df_merged['market_cap']) * 100,
        np.nan
    )
    
    df_merged['FCF_Yield_Final_%'] = df_merged['FCF_Yield_Scraper_%'].fillna(df_merged['FCF_Yield_%'])
    
    # 5. Valuation Quality Score (Khemka Framework)
    # Low EV/OCF + High FCF Yield = Undervalued
    df_merged['Valuation_Score'] = 0
    
    # EV/OCF scoring (pharma target: <35x, general: <25x)
    df_merged.loc[df_merged['EV_to_OCF'] < 15, 'Valuation_Score'] += 40  # Excellent
    df_merged.loc[(df_merged['EV_to_OCF'] >= 15) & (df_merged['EV_to_OCF'] < 25), 'Valuation_Score'] += 30
    df_merged.loc[(df_merged['EV_to_OCF'] >= 25) & (df_merged['EV_to_OCF'] < 35), 'Valuation_Score'] += 20
    df_merged.loc[(df_merged['EV_to_OCF'] >= 35) & (df_merged['EV_to_OCF'] < 50), 'Valuation_Score'] += 10
    
    # FCF Yield scoring
    df_merged.loc[df_merged['FCF_Yield_Final_%'] > 8, 'Valuation_Score'] += 35  # Excellent
    df_merged.loc[(df_merged['FCF_Yield_Final_%'] >= 5) & (df_merged['FCF_Yield_Final_%'] <= 8), 'Valuation_Score'] += 25
    df_merged.loc[(df_merged['FCF_Yield_Final_%'] >= 3) & (df_merged['FCF_Yield_Final_%'] < 5), 'Valuation_Score'] += 15
    
    # OCF Yield scoring
    df_merged.loc[df_merged['OCF_Yield_%'] > 10, 'Valuation_Score'] += 25
    df_merged.loc[(df_merged['OCF_Yield_%'] >= 7) & (df_merged['OCF_Yield_%'] <= 10), 'Valuation_Score'] += 15
    df_merged.loc[(df_merged['OCF_Yield_%'] >= 5) & (df_merged['OCF_Yield_%'] < 7), 'Valuation_Score'] += 10
    
    # Valuation Rating
    df_merged['Valuation_Rating'] = 'N/A'
    df_merged.loc[df_merged['Valuation_Score'] >= 80, 'Valuation_Rating'] = 'Excellent'
    df_merged.loc[(df_merged['Valuation_Score'] >= 60) & (df_merged['Valuation_Score'] < 80), 'Valuation_Rating'] = 'Good'
    df_merged.loc[(df_merged['Valuation_Score'] >= 40) & (df_merged['Valuation_Score'] < 60), 'Valuation_Rating'] = 'Fair'
    df_merged.loc[df_merged['Valuation_Score'] < 40, 'Valuation_Rating'] = 'Expensive'
    
    # Calculate Khemka Combined Score: Quality (70%) + Valuation (30%)
    df_merged['Khemka_Score'] = (
        df_merged['Composite_Score'] * 0.70 +
        df_merged['Valuation_Score'] * 0.30
    )
    
    logger.info("   ✅ Calculated:")
    logger.info("      - EV/OCF")
    logger.info("      - Price to FCF")
    logger.info("      - OCF Yield %")
    logger.info("      - FCF Yield %")
    logger.info("      - Valuation Score (0-100)")
    logger.info("      - Khemka Combined Score (Quality 70% + Valuation 30%)")
    
    # Save results
    from datetime import datetime
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = f"khemka_valuation_analysis_{timestamp}.csv"
    
    # Select key columns for output
    output_cols = [
        'Rank', 'Company', 'Composite_Score', 'Khemka_Score', 'Valuation_Score', 'Valuation_Rating',
        
        # Valuation Metrics
        'EV_to_OCF', 'Price_to_FCF_Final', 'OCF_Yield_%', 'FCF_Yield_Final_%',
        
        # Quality Metrics
        'OCF_to_NP_Ratio', 'FCF_Positive_Years', 'Cash_Conversion_Cycle', 'promoter_holding',
        
        # Profitability
        'OPM_%', 'ROE_%', 'Sales_CAGR_5Y_%',
        
        # Balance Sheet
        'Debt_Equity', 'Current_Ratio',
        
        # Cash Flow
        'Free_Cash_Flow', 'OCF_to_Revenue_%',
        
        # Working Capital
        'Receivables_Days', 'Inventory_Days', 'Payables_Days',
        
        # Category Scores
        'Cash_Flow_Score', 'Working_Capital_Score', 'Operational_Score', 'Growth_Score',
        
        # Market Data
        'market_cap', 'enterprise_value', 'current_price',
        
        # Red Flags
        'Red_Flag_Count', 'Red_Flags'
    ]
    
    # Only include columns that exist
    available_cols = [col for col in output_cols if col in df_merged.columns]
    df_output = df_merged[available_cols].copy()
    
    # Sort by Khemka Score
    df_output = df_output.sort_values('Khemka_Score', ascending=False, na_position='last')
    df_output['Khemka_Rank'] = range(1, len(df_output) + 1)
    
    # Save
    df_output.to_csv(output_file, index=False, encoding='utf-8-sig')
    
    logger.info(f"\n{'='*80}")
    logger.info(f"✅ VALUATION ANALYSIS COMPLETE!")
    logger.info(f"{'='*80}")
    logger.info(f"\n📁 Output saved: {output_file}")
    logger.info(f"   Total companies: {len(df_output)}")
    logger.info(f"   Companies with EV/OCF: {df_output['EV_to_OCF'].notna().sum()}")
    logger.info(f"   Companies with FCF Yield: {df_output['FCF_Yield_Final_%'].notna().sum()}")
    
    # Show top 10 by Khemka Score
    logger.info(f"\n🏆 TOP 10 BY KHEMKA SCORE (Quality 70% + Valuation 30%):")
    logger.info("-"*80)
    
    top_10 = df_output.head(10)
    for idx, row in top_10.iterrows():
        logger.info(f"{row['Khemka_Rank']:2d}. {row['Company']:<15} "
                   f"Khemka: {row['Khemka_Score']:5.1f} "
                   f"(Q:{row['Composite_Score']:5.1f} + V:{row['Valuation_Score']:5.1f}) "
                   f"| EV/OCF: {row['EV_to_OCF']:5.1f}x "
                   f"| FCF Yield: {row['FCF_Yield_Final_%']:4.1f}% "
                   f"| CCC: {row['Cash_Conversion_Cycle']:4.0f}d")
    
    # Show best valuations (low EV/OCF)
    logger.info(f"\n💰 TOP 10 BEST VALUATIONS (Lowest EV/OCF):")
    logger.info("-"*80)
    
    best_val = df_output[df_output['EV_to_OCF'].notna()].nsmallest(10, 'EV_to_OCF')
    for idx, (_, row) in enumerate(best_val.iterrows(), 1):
        logger.info(f"{idx:2d}. {row['Company']:<15} "
                   f"EV/OCF: {row['EV_to_OCF']:5.1f}x "
                   f"| FCF Yield: {row['FCF_Yield_Final_%']:4.1f}% "
                   f"| OCF/NP: {row['OCF_to_NP_Ratio']:4.2f} "
                   f"| Quality: {row['Composite_Score']:5.1f}")
    
    # Show best FCF yields
    logger.info(f"\n🎯 TOP 10 BEST FCF YIELDS:")
    logger.info("-"*80)
    
    best_fcf = df_output[df_output['FCF_Yield_Final_%'].notna()].nlargest(10, 'FCF_Yield_Final_%')
    for idx, (_, row) in enumerate(best_fcf.iterrows(), 1):
        logger.info(f"{idx:2d}. {row['Company']:<15} "
                   f"FCF Yield: {row['FCF_Yield_Final_%']:4.1f}% "
                   f"| EV/OCF: {row['EV_to_OCF']:5.1f}x "
                   f"| CCC: {row['Cash_Conversion_Cycle']:4.0f}d "
                   f"| Quality: {row['Composite_Score']:5.1f}")
    
    # Khemka's dream companies (Quality + Valuation)
    logger.info(f"\n⭐ KHEMKA'S DREAM COMPANIES (Quality + Cheap Valuation):")
    logger.info("-"*80)
    
    dream = df_output[
        (df_output['Composite_Score'] > 70) &         # High quality
        (df_output['EV_to_OCF'] < 35) &               # Reasonable valuation
        (df_output['OCF_to_NP_Ratio'] > 1.0) &        # Cash conversion
        (df_output['FCF_Positive_Years'] >= 3) &      # Consistent FCF
        (df_output['Cash_Conversion_Cycle'] < 90)     # Efficient WC
    ].sort_values('Khemka_Score', ascending=False)
    
    if len(dream) > 0:
        for idx, (_, row) in enumerate(dream.head(15).iterrows(), 1):
            logger.info(f"{idx:2d}. {row['Company']:<15} "
                       f"Khemka: {row['Khemka_Score']:5.1f} "
                       f"| EV/OCF: {row['EV_to_OCF']:5.1f}x "
                       f"| FCF Yield: {row['FCF_Yield_Final_%']:4.1f}% "
                       f"| Promoter: {row['promoter_holding']:4.1f}%")
    else:
        logger.info("   No companies meet all criteria")
    
    logger.info(f"\n{'='*80}")
    logger.info(f"📊 Summary Statistics:")
    logger.info(f"   Average EV/OCF: {df_output['EV_to_OCF'].mean():.1f}x")
    logger.info(f"   Median EV/OCF: {df_output['EV_to_OCF'].median():.1f}x")
    logger.info(f"   Average FCF Yield: {df_output['FCF_Yield_Final_%'].mean():.2f}%")
    logger.info(f"   Average OCF Yield: {df_output['OCF_Yield_%'].mean():.2f}%")
    logger.info(f"\n   Companies with EV/OCF < 35x: {(df_output['EV_to_OCF'] < 35).sum()}")
    logger.info(f"   Companies with FCF Yield > 5%: {(df_output['FCF_Yield_Final_%'] > 5).sum()}")
    logger.info(f"   Khemka Dream Companies: {len(dream)}")
    logger.info(f"{'='*80}")
    
    return df_output


def main():
    """Main function"""
    
    # Find latest files
    financial_files = glob.glob("financial_scan_*.csv")
    scraper_files = glob.glob("screener-scrapper/output/stage2_shortlist_*.csv")
    
    if not scraper_files:
        scraper_files = glob.glob("screener-scrapper/stage2_shortlist_*.csv")
    
    if not financial_files:
        logger.error("❌ No financial_scan_*.csv found")
        logger.error("   Run: python financial_scanner.py")
        return
    
    if not scraper_files:
        logger.error("❌ No stage2_shortlist_*.csv found")
        logger.error("   Run: cd screener-scrapper && python my_scraper.py")
        return
    
    # Use most recent files
    financial_csv = sorted(financial_files)[-1]
    scraper_csv = sorted(scraper_files)[-1]
    
    logger.info(f"\n📂 Using files:")
    logger.info(f"   Financial scan: {financial_csv}")
    logger.info(f"   Scraper data: {scraper_csv}\n")
    
    # Calculate
    df = calculate_valuation_metrics(financial_csv, scraper_csv)
    
    logger.info(f"\n💡 Usage:")
    logger.info(f"   1. Open: khemka_valuation_analysis_*.csv")
    logger.info(f"   2. Sort by: Khemka_Score (descending)")
    logger.info(f"   3. Filter: EV_to_OCF < 35, FCF_Yield_Final_% > 5%")
    logger.info(f"   4. Focus on: High quality + Good valuation")
    

if __name__ == "__main__":
    main()

