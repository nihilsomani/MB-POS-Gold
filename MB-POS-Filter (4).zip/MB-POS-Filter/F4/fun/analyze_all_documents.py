#!/usr/bin/env python3
"""
analyze_all_documents_improved.py

Improved version of analyze_all_documents.py
- Robust PDF text extraction: PyPDF2 -> pdfplumber -> OCR (pytesseract + pdf2image)
- Parallelized processing with configurable worker count
- Progress bar with tqdm
- Safer merge with financial data using fuzzy matching (rapidfuzz)
- Cleaner logging and output (CSV + debug JSON)
- Optional NLP embedding hook (commented; uses sentence-transformers)

Usage:
    python analyze_all_documents_improved.py --downloads downloads/ --output_dir output/ --workers 6

Dependencies (install before running):
    pip install PyPDF2 pdfplumber pdf2image pytesseract rapidfuzz tqdm pandas python-dateutil

Notes:
 - OCR fallback requires poppler (for pdf2image). On Linux: `sudo apt-get install poppler-utils`.
 - Tesseract OCR engine must be installed for pytesseract. On Linux: `sudo apt-get install tesseract-ocr`.
 - The script is defensive: missing packages result in informative logs and degraded (but functional) behavior.
"""

import os
import re
import json
import math
import time
import logging
import argparse
from pathlib import Path
from typing import Dict, Optional, Tuple, List
from concurrent.futures import ProcessPoolExecutor, as_completed

# Third-party libs (ensure installed; script checks available features)
try:
    import PyPDF2
except Exception:
    PyPDF2 = None

try:
    import pdfplumber
except Exception:
    pdfplumber = None

try:
    from pdf2image import convert_from_path
except Exception:
    convert_from_path = None

try:
    import pytesseract
except Exception:
    pytesseract = None

try:
    from rapidfuzz import fuzz, process as rf_process
except Exception:
    fuzz = None
    rf_process = None

try:
    import pandas as pd
except Exception:
    pd = None

try:
    from tqdm import tqdm
except Exception:
    tqdm = None

from datetime import datetime

# ---------- Logging ----------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("docs_analyzer")


# ---------- Utilities ----------
def normalize_company_name(name: str) -> str:
    """Normalize company name for safer joins (strip punctuation, lower, remove common suffixes)."""
    if not name:
        return ""
    s = name.lower()
    # common tokens to remove
    for token in [" limited", " ltd", " ltd.", " inc", " inc.", " co", " co.", " limited.", " pvt", " pvt."]:
        s = s.replace(token, " ")
    s = re.sub(r"[^a-z0-9]", "", s)
    return s.strip()


def safe_count(substr: str, text: str) -> int:
    return text.count(substr) if text else 0


# ---------- PDF Text Extraction ----------
def extract_text_with_pypdf2(pdf_path: str) -> str:
    """Try PyPDF2 text extraction; returns empty string on failure."""
    if PyPDF2 is None:
        return ""
    try:
        reader = PyPDF2.PdfReader(open(pdf_path, "rb"))
        text_parts = []
        for page in reader.pages:
            try:
                page_text = page.extract_text() or ""
            except Exception:
                page_text = ""
            text_parts.append(page_text)
        return "\n".join(text_parts).strip()
    except Exception as e:
        logger.debug(f"PyPDF2 failed for {pdf_path}: {e}")
        return ""


def extract_text_with_pdfplumber(pdf_path: str) -> str:
    if pdfplumber is None:
        return ""
    try:
        text_parts = []
        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                try:
                    page_text = page.extract_text() or ""
                except Exception:
                    page_text = ""
                text_parts.append(page_text)
        return "\n".join(text_parts).strip()
    except Exception as e:
        logger.debug(f"pdfplumber failed for {pdf_path}: {e}")
        return ""


def ocr_pdf_pages(pdf_path: str, dpi: int = 200, max_pages: Optional[int] = None) -> str:
    """Convert PDF to images and OCR each page with pytesseract. Returns concatenated text."""
    if convert_from_path is None or pytesseract is None:
        return ""
    try:
        images = convert_from_path(pdf_path, dpi=dpi)
        if max_pages:
            images = images[:max_pages]
        texts = []
        for idx, img in enumerate(images):
            try:
                page_text = pytesseract.image_to_string(img)
            except Exception as e:
                logger.debug(f"OCR page {idx} failed: {e}")
                page_text = ""
            texts.append(page_text)
        return "\n".join(texts).strip()
    except Exception as e:
        logger.debug(f"pdf2image/pytesseract pipeline failed for {pdf_path}: {e}")
        return ""


def extract_pdf_text_best_effort(pdf_path: str, ocr_on_fail: bool = True) -> Tuple[str, List[str]]:
    """
    Try multiple extractors in order and return the extracted text plus provenance tags.
    Provenance tags indicate which method succeeded.
    """
    provenance = []
    text = ""

    # 1) PyPDF2
    text = extract_text_with_pypdf2(pdf_path)
    if text and len(text) > 50:
        provenance.append("pypdf2")
        return text, provenance

    # 2) pdfplumber
    text = extract_text_with_pdfplumber(pdf_path)
    if text and len(text) > 50:
        provenance.append("pdfplumber")
        return text, provenance

    # 3) OCR fallback (may be slow)
    if ocr_on_fail:
        text = ocr_pdf_pages(pdf_path)
        if text and len(text) > 20:
            provenance.append("ocr")
            return text, provenance

    # final return (may be empty)
    provenance.append("none")
    return text or "", provenance


# ---------- Document Analysis / Scoring (wrapped original logic) ----------
def analyze_document_quality(text: str) -> Dict:
    """
    Port of the original scoring logic with small improvements:
    - returns structured dict with score, insights, red_flags, word_count
    - safe even if text is empty
    """
    if not text or len(text.strip()) < 100:
        return {'score': 30, 'insights': ['⚠️ Insufficient data'], 'red_flags': [], 'word_count': 0}

    text_lower = text.lower()
    word_count = len(text.split())
    score = 40
    insights = []
    red_flags = []

    # CRITICAL RED FLAGS
    critical_negatives = {
        'loss': safe_count('net loss', text_lower) + safe_count('reported loss', text_lower),
        'litigation': safe_count('litigation', text_lower) + safe_count('legal proceeding', text_lower),
        'default': safe_count('default', text_lower) + safe_count('npa', text_lower),
        'fraud': safe_count('fraud', text_lower) + safe_count('investigation', text_lower),
        'going_concern': safe_count('going concern', text_lower) + safe_count('continuity risk', text_lower)
    }
    for issue, cnt in critical_negatives.items():
        if cnt > 2:
            score -= 20
            red_flags.append(f"🚨 {issue.title()} issues")

    # NEGATIVE INDICATORS
    negatives = {
        'debt_problems': ['high debt', 'debt burden', 'leverage concern', 'debt restructuring'],
        'margin_issues': ['margin pressure', 'margin compression', 'declining margin'],
        'demand_weak': ['weak demand', 'demand slowdown', 'volume decline', 'sales decline'],
        'competition': ['intense competition', 'pricing pressure', 'market share loss'],
        'guidance_cut': ['revised guidance', 'lowered outlook', 'reduced forecast']
    }
    for category, keywords in negatives.items():
        count = sum(safe_count(k, text_lower) for k in keywords)
        if count > 2:
            score -= 10
            red_flags.append(f"⚠️ {category.replace('_',' ').title()}")
        elif count > 0:
            score -= 3

    # MANAGEMENT QUALITY
    execution_proof = ['achieved', 'delivered', 'completed', 'commissioned', 'launched successfully']
    exec_count = sum(safe_count(k, text_lower) for k in execution_proof)
    if exec_count > 15:
        score += 20
        insights.append("✅ Proven execution")
    elif exec_count > 8:
        score += 10
    elif exec_count > 3:
        score += 5

    transparency = safe_count('challenge', text_lower) + safe_count('headwind', text_lower) + safe_count('difficult', text_lower)
    hiding = safe_count('cannot disclose', text_lower) + safe_count('proprietary', text_lower) * 2
    net_transparency = transparency - hiding
    if net_transparency > 5:
        score += 10
        insights.append("✅ Transparent")
    elif net_transparency < -2:
        score -= 5
        red_flags.append("Lacks transparency")

    # GROWTH QUALITY
    revenue_growth = re.findall(r'revenue\s+(?:growth|up|increased)\s+(?:by\s+)?(\d+)%', text_lower)
    max_growth = max([int(g) for g in revenue_growth], default=0)
    if max_growth > 30:
        score += 25
        insights.append(f"🚀 High growth: {max_growth}%")
    elif max_growth > 20:
        score += 15
    elif max_growth > 10:
        score += 8
    elif max_growth < 5:
        score -= 5
        red_flags.append("Low growth")

    concrete_expansion = safe_count('new plant', text_lower) + safe_count('greenfield', text_lower) + safe_count('acquisition completed', text_lower)
    if concrete_expansion > 3:
        score += 10
        insights.append("✅ Concrete expansion")

    # FINANCIAL DISCIPLINE
    discipline_strong = {
        'debt_free': safe_count('debt free', text_lower) + safe_count('zero debt', text_lower),
        'high_roce': re.findall(r'roce\s+(?:of\s+)?(\d+)%', text_lower),
        'dividend': safe_count('dividend', text_lower) if safe_count('dividend', text_lower) < 20 else 0
    }
    roce_values = [int(r) for r in discipline_strong['high_roce']]
    max_roce = max(roce_values, default=0)
    if discipline_strong['debt_free'] > 0 or max_roce > 20:
        score += 10
        insights.append("✅ Financial discipline")
    if discipline_strong['dividend'] > 3 and discipline_strong['dividend'] < 15:
        score += 5
        insights.append("✅ Dividend paying")

    # MOAT
    moat_indicators = ['market leader', 'number one', '#1', 'dominant player', 'competitive advantage', 'moat']
    moat_count = sum(safe_count(k, text_lower) for k in moat_indicators)
    if moat_count > 5:
        score += 15
        insights.append("✅ Strong moat")
    elif moat_count > 2:
        score += 8

    # PENALTIES
    vague = safe_count('going forward', text_lower) + safe_count('in due course', text_lower) + safe_count('strategic review', text_lower)
    if vague > 10:
        score -= 5
        red_flags.append("Vague language")
    buzzwords = safe_count('digital transformation', text_lower) + safe_count('synergy', text_lower) + safe_count('paradigm', text_lower)
    if buzzwords > 8:
        score -= 5
        red_flags.append("Buzzword overload")

    final_score = max(20, min(100, score))
    return {
        'score': final_score,
        'insights': insights,
        'red_flags': red_flags,
        'word_count': word_count
    }


# ---------- Worker function for parallel execution ----------
def analyze_single_company(company: str, concall_path: Optional[str], report_path: Optional[str], ocr_on_fail: bool = True) -> Dict:
    """
    Analyze a single company's available documents and return a dict containing scores and info.
    This is intentionally serial per-company to keep scoring logic clear, but the outer
    orchestration runs these in parallel.
    """
    start = time.time()
    all_insights = []
    concall_score = None
    report_score = None
    concall_prov = []
    report_prov = []
    debug = {'company': company, 'errors': [], 'provenance': {}}

    # Analyze concall
    if concall_path:
        try:
            text, prov = extract_pdf_text_best_effort(concall_path, ocr_on_fail=ocr_on_fail)
            concall_prov = prov
            if text:
                analysis = analyze_document_quality(text)
                concall_score = analysis['score']
                all_insights.extend(analysis['insights'])
            else:
                debug['errors'].append(f"No text extracted from concall: {concall_path}")
        except Exception as e:
            logger.debug(f"Concall analysis error for {company}: {e}")
            debug['errors'].append(str(e))

    # Analyze report
    if report_path:
        try:
            text, prov = extract_pdf_text_best_effort(report_path, ocr_on_fail=ocr_on_fail)
            report_prov = prov
            if text:
                analysis = analyze_document_quality(text)
                report_score = analysis['score']
                all_insights.extend(analysis['insights'])
            else:
                debug['errors'].append(f"No text extracted from report: {report_path}")
        except Exception as e:
            logger.debug(f"Report analysis error for {company}: {e}")
            debug['errors'].append(str(e))

    # Combine
    if concall_score and report_score:
        qual_score = (concall_score * 0.6 + report_score * 0.4)
        source = "Both"
    elif concall_score:
        qual_score = concall_score
        source = "Concall"
    elif report_score:
        qual_score = report_score
        source = "Report"
    else:
        qual_score = 50.0
        source = "None"

    end = time.time()
    debug['provenance']['concall'] = concall_prov
    debug['provenance']['report'] = report_prov
    debug['time_seconds'] = round(end - start, 2)

    result = {
        'Company': company,
        'Qualitative_Score': round(float(qual_score), 2),
        'Concall_Score': round(float(concall_score), 2) if concall_score else None,
        'Report_Score': round(float(report_score), 2) if report_score else None,
        'Has_Concall': bool(concall_path),
        'Has_Report': bool(report_path),
        'Concall_Analyzed': concall_score is not None,
        'Report_Analyzed': report_score is not None,
        'Key_Insights': ' | '.join(all_insights[:6]),
        'Data_Source': source,
        'Debug': debug
    }
    return result


# ---------- Merge functions ----------
def fuzzy_merge_financial(df_qual: "pd.DataFrame", financial_csv_path: str, company_col_fin: str = "Company") -> "pd.DataFrame":
    """
    Merge the qualitative df with the financial CSV using fuzzy matching on normalized names.
    Returns new merged dataframe with 'Composite_Score' columns preserved when present.
    """
    if pd is None:
        raise RuntimeError("pandas is required for merging")

    if rf_process is None:
        logger.warning("rapidfuzz not installed: performing simple exact merge on normalized names.")
        df_fin = pd.read_csv(financial_csv_path)
        df_fin['company_norm'] = df_fin[company_col_fin].astype(str).apply(normalize_company_name)
        df_qual['company_norm'] = df_qual['Company'].astype(str).apply(normalize_company_name)
        merged = df_qual.merge(df_fin, left_on='company_norm', right_on='company_norm', how='left', suffixes=('', '_fin'))
        return merged

    # Load financial CSV
    df_fin = pd.read_csv(financial_csv_path)
    df_fin['company_norm'] = df_fin[company_col_fin].astype(str).apply(normalize_company_name)
    df_qual['company_norm'] = df_qual['Company'].astype(str).apply(normalize_company_name)

    # build choices for rapidfuzz
    choices = dict(zip(df_fin['company_norm'].tolist(), df_fin.index.tolist()))
    fin_keys = list(choices.keys())

    matched_indices = []
    matched_scores = []
    matched_fin_idx = []

    for idx, row in df_qual.iterrows():
        key = row['company_norm']
        if not key:
            matched_indices.append(None)
            matched_scores.append(0)
            matched_fin_idx.append(None)
            continue

        # exact quick check
        if key in choices:
            fin_idx = choices[key]
            matched_indices.append(fin_idx)
            matched_scores.append(100)
            matched_fin_idx.append(fin_idx)
            continue

        # fuzzy match top choice
        best = rf_process.extractOne(key, fin_keys, scorer=fuzz.token_sort_ratio)
        if best and best[1] >= 85:  # threshold (tuneable)
            matched_norm = best[0]
            fin_idx = choices[matched_norm]
            matched_indices.append(fin_idx)
            matched_scores.append(best[1])
            matched_fin_idx.append(fin_idx)
        else:
            matched_indices.append(None)
            matched_scores.append(best[1] if best else 0)
            matched_fin_idx.append(None)

    df_qual['_fin_match_idx'] = matched_indices
    df_qual['_fin_match_score'] = matched_scores

    # create mapping index -> financial row
    df_fin_indexed = df_fin.reset_index()
    df_joined = df_qual.copy()
    # for matched rows, attach the financial row by index
    def attach_fin(i):
        if pd.isna(i):
            return {}
        try:
            return df_fin_indexed.loc[int(i)].to_dict()
        except Exception:
            return {}

    fin_data = [attach_fin(i) if i is not None else {} for i in df_qual['_fin_match_idx']]
    df_fin_expanded = pd.DataFrame(fin_data).fillna("")
    # Avoid duplicate columns conflict; suffix financial cols
    for c in df_fin_expanded.columns:
        if c in df_joined.columns:
            df_fin_expanded = df_fin_expanded.rename(columns={c: f"{c}_fin"})
    merged = pd.concat([df_joined.reset_index(drop=True), df_fin_expanded.reset_index(drop=True)], axis=1)
    # Compute Integrated_Score if Composite_Score present
    try:
        if 'Composite_Score' in merged.columns:
            merged['Integrated_Score'] = merged.apply(
                lambda row: round((float(row.get('Composite_Score', 0)) * 0.6 + float(row['Qualitative_Score']) * 0.4), 2)
                if row.get('Composite_Score') not in [None, "", "nan"] else None,
                axis=1
            )
    except Exception as e:
        logger.debug(f"Could not compute Integrated_Score automatically: {e}")

    return merged


# ---------- Main orchestration ----------
def analyze_all_documents(downloads_dir: str, output_dir: str, workers: int = 4, ocr_on_fail: bool = True, financial_csv: Optional[str] = None) -> "pd.DataFrame":
    downloads = Path(downloads_dir)
    concalls_dir = downloads / "concalls"
    reports_dir = downloads / "annual_reports"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    concall_files = list(concalls_dir.glob("*.pdf")) if concalls_dir.exists() else []
    report_files = list(reports_dir.glob("*.pdf")) if reports_dir.exists() else []

    logger.info(f"Found concalls: {len(concall_files)}, reports: {len(report_files)}")

    # map companies
    company_docs = {}
    for pdf in concall_files:
        company = pdf.stem.replace('_Concall', '').strip()
        if company not in company_docs:
            company_docs[company] = {'concall': None, 'report': None}
        company_docs[company]['concall'] = str(pdf)

    for pdf in report_files:
        # attempt to deduce company symbol/name gracefully
        company = pdf.stem.split('_')[0].strip()
        if company not in company_docs:
            company_docs[company] = {'concall': None, 'report': None}
        company_docs[company]['report'] = str(pdf)

    companies = list(company_docs.items())
    logger.info(f"Unique companies discovered: {len(companies)}")

    results = []
    debug_list = []

    # progress bar wrapper
    use_tqdm = tqdm is not None

    logger.info(f"Starting analysis with {workers} workers (OCR on fail = {ocr_on_fail})")
    start_all = time.time()

    if workers > 1:
        with ProcessPoolExecutor(max_workers=workers) as exe:
            futures = {}
            for comp, docs in companies:
                futures[exe.submit(analyze_single_company, comp, docs['concall'], docs['report'], ocr_on_fail)] = (comp, docs)
            if use_tqdm:
                pbar = tqdm(total=len(futures), desc="Companies")
            for fut in as_completed(futures):
                try:
                    res = fut.result()
                    results.append(res)
                    debug_list.append(res.get('Debug', {}))
                except Exception as e:
                    comp, docs = futures[fut]
                    logger.exception(f"Error analyzing {comp}: {e}")
                finally:
                    if use_tqdm:
                        pbar.update(1)
            if use_tqdm:
                pbar.close()
    else:
        # serial fallback
        it = companies
        if use_tqdm:
            it = tqdm(companies, desc="Companies")
        for comp, docs in it:
            try:
                res = analyze_single_company(comp, docs['concall'], docs['report'], ocr_on_fail)
                results.append(res)
                debug_list.append(res.get('Debug', {}))
            except Exception as e:
                logger.exception(f"Error analyzing {comp}: {e}")

    end_all = time.time()
    logger.info(f"Document analysis completed in {round(end_all - start_all, 1)}s")

    # Build dataframe
    if pd is None:
        raise RuntimeError("pandas is required to build the output CSV")

    df = pd.DataFrame(results)
    df = df.sort_values('Qualitative_Score', ascending=False).reset_index(drop=True)
    df['Qual_Rank'] = range(1, len(df) + 1)

    # Attempt to merge with financial CSV if provided
    if financial_csv:
        try:
            merged = fuzzy_merge_financial(df, financial_csv)
            out_df = merged
            logger.info("Merged qualitative results with financial CSV.")
        except Exception as e:
            logger.exception(f"Failed to merge with financial CSV: {e}")
            out_df = df
    else:
        out_df = df

    # Save outputs
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = output_dir / f"all_documents_analysis_{timestamp}.csv"
    debug_path = output_dir / f"all_documents_debug_{timestamp}.json"
    out_df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    with open(debug_path, "w", encoding="utf-8") as fh:
        json.dump(debug_list, fh, indent=2)

    logger.info(f"Results saved: {csv_path}")
    logger.info(f"Debug info saved: {debug_path}")
    return out_df


# ---------- CLI ----------
def parse_args():
    p = argparse.ArgumentParser(description="Analyze all documents (concall + annual reports)")
    p.add_argument("--downloads", default="downloads", help="Base downloads folder (contains concalls/ annual_reports/)")
    p.add_argument("--output_dir", default="output", help="Directory to write CSV & debug files")
    p.add_argument("--workers", type=int, default=4, help="Number of parallel workers (set 1 for serial)")
    p.add_argument("--ocr_on_fail", action="store_true", help="Enable OCR fallback when text extraction fails")
    p.add_argument("--financial_csv", default=None, help="Path to financial CSV for merging (optional)")
    return p.parse_args()


if __name__ == "__main__":
    args = parse_args()
    logger.info("Starting improved document analysis")
    logger.info(f"Python executable: {os.sys.executable}")
    # quick environment hints
    logger.info("Feature availability:")
    logger.info(f"  PyPDF2: {'yes' if PyPDF2 else 'no'}")
    logger.info(f"  pdfplumber: {'yes' if pdfplumber else 'no'}")
    logger.info(f"  pdf2image: {'yes' if convert_from_path else 'no'}")
    logger.info(f"  pytesseract: {'yes' if pytesseract else 'no'}")
    logger.info(f"  rapidfuzz: {'yes' if rf_process else 'no'}")
    logger.info(f"  pandas: {'yes' if pd else 'no'}")
    logger.info(f"  tqdm: {'yes' if tqdm else 'no'}")

    df_out = analyze_all_documents(
        downloads_dir=args.downloads,
        output_dir=args.output_dir,
        workers=max(1, args.workers),
        ocr_on_fail=args.ocr_on_fail,
        financial_csv=args.financial_csv
    )
    logger.info("Done.")
