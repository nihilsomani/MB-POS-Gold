# MBI-RRG Sector Scanner (Draft)

This module blends the **MBI Equity Momentum** pipeline with the existing **RRG sector universe**.  
The goal is to score each sector with the same pocket-pivot based EM framework we use for the broad market, then optionally layer the RRG relative-strength signal on top.

## High-Level Flow

1. Load sector membership from `helper/output/sector_marketcap_great8000.csv`.
2. Fetch historical OHLCV for every symbol in scope using the existing `MBIEMDashboard` data loaders.
3. Detect Pocket Pivot Days with the optimized detector and track follow-through to compute sector-level EM.
4. Aggregate EM into short-term trend deltas (`EM_chng`, `EM_chng_3d`, `EM_chng_5d`), then classify each sector with the V3 regime classifier.
5. Export a summary table (and optional CSV/Excel) showing sector, latest EM, regime, confidence, and supporting stats.

## Status

- ✅ Data loader + pipeline scaffolding in place
- ✅ Sector-level EM + regime classification for the latest trading day
- 🚧 TODO: enrich with RRG rankings, sector index awareness, and euphoria detection
- 🚧 TODO: add tests and a notebook to visualise sector trends over time

Run the scanner from the repository root:

```bash
python MB-POS-Filter/F4/MBI-RRG/sector_mbi_rrg_scanner.py --days 180 --min-members 5
```

Outputs are saved under `MB-POS-Filter/F4/MBI-RRG/output/`.

