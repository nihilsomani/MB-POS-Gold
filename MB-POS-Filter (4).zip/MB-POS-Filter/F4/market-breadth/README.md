# Market Breadth Scanners

Two complementary breadth analysis tools for Nifty 50 stocks.

## 📊 Overview

| Scanner | Purpose | Frequency | Output | Best For |
|---------|---------|-----------|--------|----------|
| **MarketBreadthRegime.py** | Market regime & health assessment | Weekly | Health Score (0-100), Regime, JSON/CSV | Long-term positioning, portfolio sizing |
| **MarketBreadthTactical.py** | Daily trading signals | Daily | Signal Score (-10 to +10), NH/NL, CSV | Short-term trades, momentum shifts |

---

## 🎯 MarketBreadthRegime.py

### Purpose
Comprehensive multi-dimensional market regime analyzer for **long-term strategic decisions**.

### Key Features
✅ Multi-timeframe breadth (10/20/50/100/200-day MAs)  
✅ Market cap-weighted breadth (institutional perspective)  
✅ Sector-normalized breadth (anti-concentration bias)  
✅ Volume-weighted breadth (money flow)  
✅ **Health Score (0-100)** - Composite strength indicator  
✅ **Regime Classification** - STRONG_BULL, BULL, NEUTRAL, BEAR, STRONG_BEAR  
✅ Trend alignment confidence score  

### Output Files
```
output/
├── regime_breadth.json           # Latest breadth metrics
├── regime_breadth_history.csv    # Historical tracking
cache/
└── regime_YYYYMMDD.json          # Daily snapshots
```

### Usage
```bash
# Run on all Nifty 50 stocks
python MarketBreadthRegime.py

# Test with sample
python MarketBreadthRegime.py --sample 10
```

### Interpretation

| Health Score | Regime | Action | Position Sizing |
|--------------|--------|--------|-----------------|
| 70-100 | STRONG_BULL | Aggressive Long | 100% deployed |
| 60-70 | BULL | Long | 75-100% |
| 55-60 | WEAK_BULL | Selective Long | 50-75% |
| 45-55 | NEUTRAL | Wait/Reduce | 25-50% |
| 40-45 | WEAK_BEAR | Selective Short | 25-50% cash |
| 30-40 | BEAR | Short/Defensive | 50-75% cash |
| 0-30 | STRONG_BEAR | Aggressive Short/Cash | 75-100% cash |

### When to Run
- **Weekly**: Sunday evening for next week's positioning
- **Monthly**: First of month for portfolio rebalancing
- **After major events**: Fed decisions, budget, major announcements

---

## ⚡ MarketBreadthTactical.py

### Purpose
Daily trading signal generator based on **New Highs/New Lows** and **Advance/Decline** momentum.

### Key Features
✅ New Highs/New Lows (13-week lookback)  
✅ Advance/Decline ratio tracking  
✅ 4-day trend analysis (T, T-1, T-2, T-3)  
✅ **Signal Score (-10 to +10)** - Weighted momentum indicator  
✅ Per-stock rankings and insights  
✅ SQLite caching for fast performance  

### Output Files
```
output/
└── tactical_detail_YYYYMMDD.csv   # Detailed per-stock analysis
cache/
├── instrument_cache.json          # API cache
└── historical_data.db             # SQLite price cache
```

### Usage
```bash
# Daily run
python MarketBreadthTactical.py
```

### Interpretation

| Signal Score | Market Pulse | Action | Confidence |
|--------------|--------------|--------|------------|
| +4 to +10 | STRONG BULLISH | Buy aggressively | High |
| +2 to +4 | BULLISH | Buy selectively | Medium-High |
| 0 to +2 | MODERATELY BULLISH | Buy cautiously | Medium |
| -2 to 0 | MODERATELY BEARISH | Reduce longs | Medium |
| -4 to -2 | BEARISH | Exit longs, consider shorts | Medium-High |
| -10 to -4 | STRONG BEARISH | Short aggressively | High |

### Key Metrics
- **NH/NL Spread**: New Highs - New Lows (positive = bullish)
- **A/D Ratio**: Advances / Declines (>1.5 = bullish, <0.7 = bearish)
- **% Above MA50**: Breadth strength (>70% = strong, <30% = weak)

### When to Run
- **Daily**: Before market open (9:00 AM)
- **Intraday**: After lunch for next day signals
- **After volatility**: Post major gap moves

---

## 🎯 Combined Strategy

### Daily Routine

#### Morning (9:00 AM)
```bash
python MarketBreadthTactical.py
```
- Check **Signal Score** for today's bias
- Review NH/NL changes
- Identify top gainers/losers for watchlist

#### Weekly (Sunday Evening)
```bash
python MarketBreadthRegime.py
```
- Check **Health Score** and **Regime**
- Adjust portfolio sizing
- Plan week's strategy

### Decision Framework

| Regime Scanner | Tactical Scanner | Combined Action |
|----------------|------------------|-----------------|
| Health >70 | Signal >+3 | 🟢 AGGRESSIVE LONG - Full deployment |
| Health 60-70 | Signal >0 | 🟢 LONG - 75% deployed |
| Health 55-70 | Signal <-3 | 🟡 CAUTION - Divergence, reduce |
| Health <45 | Signal <-3 | 🔴 DEFENSIVE - Cash/shorts |
| Health <45 | Signal >+3 | 🟡 EARLY REVERSAL - Small positions |
| Health >60 | Signal <-4 | ⚠️ WARNING - Hidden weakness |

### Example Scenarios

**Scenario 1: Perfect Alignment**
- Regime: Health 75, STRONG_BULL
- Tactical: Signal +5, STRONG BULLISH
- **Action**: Full deployment, aggressive longs

**Scenario 2: Divergence Warning**
- Regime: Health 65, BULL  
- Tactical: Signal -4, STRONG BEARISH
- **Action**: Reduce exposure, watch closely (deterioration beneath surface)

**Scenario 3: Early Recovery**
- Regime: Health 42, WEAK_BEAR
- Tactical: Signal +3, BULLISH
- **Action**: Small exploratory positions (possible reversal)

---

## 📁 File Structure

```
MB-POS-Filter/F4/market-breadth/
├── MarketBreadthRegime.py          # Weekly regime scanner
├── MarketBreadthTactical.py        # Daily signal scanner
├── README.md                        # This file
├── output/
│   ├── regime_breadth.json          # Latest regime data
│   ├── regime_breadth_history.csv   # Regime history
│   └── tactical_detail_YYYYMMDD.csv # Daily stock details
├── cache/
│   ├── instrument_cache.json        # Kite tokens
│   ├── historical_data.db           # Price cache (Tactical)
│   └── regime_YYYYMMDD.json         # Daily regime snapshots
└── logs/
    ├── regime_breadth.log           # Regime scanner log
    └── tactical_breadth.log         # Tactical scanner log
```

---

## ⚙️ Configuration

### Data Source
Both scanners use: `../../../data/Nifty50stocks.csv`

Required columns:
- **Symbol** (required)
- **Sector** (optional, defaults to "Unknown")
- **market_cap_crores** (optional, uses equal weight if missing)

### API Configuration
Edit the following in each scanner:
```python
API_KEY = "your_api_key"
ACCESS_TOKEN = "your_access_token"
```

---

## 🚀 Quick Start

### First Time Setup
```bash
cd C:\nihil\finance_ai_ws\MB-POS-Filter\F4\market-breadth

# Test regime scanner
python MarketBreadthRegime.py --sample 5

# Test tactical scanner
python MarketBreadthTactical.py
```

### Daily Workflow
```bash
# Morning routine
python MarketBreadthTactical.py

# Review output/tactical_detail_YYYYMMDD.csv
# Check Signal Score and NH/NL spread
```

### Weekly Workflow
```bash
# Sunday evening
python MarketBreadthRegime.py

# Review output/regime_breadth.json
# Adjust portfolio sizing based on Health Score
```

---

## 📊 Performance Notes

### Regime Scanner
- Runtime: ~30-60 seconds for 50 stocks
- API calls: ~50 (one per stock)
- No caching (always fresh data for regime assessment)

### Tactical Scanner  
- Runtime: ~10-30 seconds (cached) or ~60 seconds (first run)
- API calls: ~50 first run, ~0-5 on subsequent runs (SQLite cache)
- Cache speeds up daily runs significantly

---

## 🎓 Learning Resources

### Key Breadth Concepts

**New Highs/New Lows (NH/NL)**
- Classic breadth indicator
- 13-week lookback = ~52 trading days (quarterly trend)
- Rising NH with falling NL = strong bullish
- Rising NL with falling NH = strong bearish

**Advance/Decline (A/D)**
- Daily momentum indicator
- >1.5 ratio = strong day
- <0.7 ratio = weak day
- Tracks participation breadth

**Multi-Timeframe Alignment**
- 10d = Very short-term swing
- 50d = Medium-term trend
- 200d = Long-term bull/bear market
- All aligned = high confidence

**Health Score Components**
- 25% Simple breadth (equal weight)
- 30% Weighted breadth (market cap)
- 20% Momentum score (distance from MA)
- 15% Sector normalized (balance)
- 10% Volume weighted (money flow)

---

## 🔧 Troubleshooting

### "No data fetched!"
- Check: CSV file path is correct
- Check: API_KEY and ACCESS_TOKEN are valid
- Try: `python MarketBreadthRegime.py --sample 5`

### "Cached data insufficient"
- Normal: First run or stale cache
- Action: Let it fetch fresh data

### Slow performance
- Regime: Expected (always fetches fresh)
- Tactical: Should be fast after first run (SQLite cache)

---

## 📝 Notes

- **Regime Scanner**: Use for big picture, weekly planning
- **Tactical Scanner**: Use for daily execution, signal generation
- **Best Together**: Weekly regime sets context, daily tactical times entries
- **Nifty 50 Only**: Both scanners configured for Nifty 50 stocks (no market cap filtering)

---

## 🆘 Support

For issues or questions:
1. Check logs: `regime_breadth.log` or `tactical_breadth.log`
2. Test with sample: `--sample 5` or `--sample 10`
3. Verify data file: `../../../data/Nifty50stocks.csv`

---

**Version**: 1.0.0  
**Last Updated**: October 2025  
**Compatible**: Python 3.7+, Kite Connect API

