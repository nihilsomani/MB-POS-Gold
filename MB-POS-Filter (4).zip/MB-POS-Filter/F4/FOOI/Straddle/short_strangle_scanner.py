#!/usr/bin/env python3
"""
SHORT STRANGLE SCANNER - Premium Collection Strategy
Hold Period: 3-5 weeks
Strategy: Sell OTM Call + Sell OTM Put, collect premium from range-bound stocks

Key Principles:
- Want HIGH IV (expensive premium to collect)
- Want SIDEWAYS market (no strong trends)
- Want LOW volatility (quiet, range-bound)
- Want NO upcoming events (earnings, etc.)
- Profit from theta decay over 3-5 weeks

Author: Claude & Nihil
Date: 2025-11-28
"""

import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
from kiteconnect import KiteConnect
import time

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class ShortStrangleConfig:
    """Configuration for Short Strangle Scanner"""
    
    # IV Requirements (OPPOSITE of long options - want HIGH IV)
    # INDIA VIX Context:
    # - INDIA VIX 12-16: PERFECT for short strangles ✅
    # - INDIA VIX 10-12: Borderline, lower threshold to find best setups ← Current: 11.6
    # - INDIA VIX <10: Too low, avoid strangles
    # - INDIA VIX >16: Too high, risky for strangles
    
    # Current INDIA VIX: 11.6 (borderline)
    # Lowering threshold to 35% to find exceptional setups
    MIN_IV_PERCENTILE = 35        # Lowered for INDIA VIX 11.6 (normally 50)
    IDEAL_IV_PERCENTILE = 50      # Ideal threshold
    EXCELLENT_IV_PERCENTILE = 65  # Excellent premium collection
    
    # For INDIA VIX 11.6: Look for stocks with relatively high IV
    # Even if not ideal, can find 5-10 decent setups
    
    # Trend Requirements (want SIDEWAYS, NOT trending)
    MAX_TREND_STRENGTH = 0.3      # R² must be < 0.3 (sideways)
    MODERATE_TREND_MAX = 0.5      # Penalty zone
    
    # Volatility Requirements (want QUIET)
    MAX_ATR_PERCENT = 2.5         # Max daily ATR% (want calm stocks)
    IDEAL_ATR_PERCENT = 2.0       # Ideal threshold
    
    # Range Requirements
    MAX_RANGE_PERCENT = 0.05      # Max 5% range over 30 days (tight)
    IDEAL_RANGE_PERCENT = 0.03    # Ideal tight range
    
    # PCR Requirements (want BALANCED sentiment)
    PCR_MIN = 0.9                 # Minimum PCR (not too bullish)
    PCR_MAX = 1.2                 # Maximum PCR (not too bearish)
    
    # Futures Activity (want LOW activity)
    MAX_FUT_OI_CHANGE = 3.0       # Max 3% futures OI change
    
    # Option Selection
    MIN_DAYS_TO_EXPIRY = 25       # Need time for theta decay
    MAX_DAYS_TO_EXPIRY = 35       # Not too far out
    IDEAL_DAYS_MIN = 28           # Ideal range start
    IDEAL_DAYS_MAX = 32           # Ideal range end
    
    # Strike Selection (OTM on both sides)
    # At INDIA VIX 11.6: Go slightly tighter to collect more premium
    # Trade-off: Less protection but better premium collection
    CALL_OTM_PERCENT = 0.05       # 5% OTM for call strike (was 6%)
    PUT_OTM_PERCENT = 0.05        # 5% OTM for put strike (was 6%)
    # This gives us ~10% total range vs 12%, but better premium
    
    # Premium Requirements
    MIN_TOTAL_PREMIUM_PCT = 1.8   # Lowered for INDIA VIX 11.6 (normally 2.0)
    IDEAL_PREMIUM_PCT = 2.5       # Ideal premium
    
    # Scoring
    MIN_SCORE = 6                 # Lowered for INDIA VIX 11.6 (normally 8)
    # At INDIA VIX 11.6, need to be more flexible to find setups
    # Will still prioritize high-scoring setups, but allow score 6-8
    
    # Risk Management
    MAX_LOSS_MULTIPLE = 2.0       # Exit if loss = 2× premium collected
    PROFIT_TARGET_PCT = 0.60      # Target 60% of premium (theta decay)
    ADJUSTMENT_DELTA = 0.30       #// Adjust if option delta > 0.30
    
    # Logging
    LOG_LEVEL = logging.INFO


def calculate_trend_strength(prices: List[float]) -> Tuple[float, str]:
    """
    Calculate trend strength using linear regression
    Returns (R-squared, direction)
    
    For Short Strangle: WANT LOW R² (< 0.3) = sideways/no trend
    """
    if len(prices) < 5:
        return 0.0, 'SIDEWAYS'
    
    x = np.arange(len(prices))
    y = np.array(prices)
    
    # Linear regression
    coeffs = np.polyfit(x, y, 1)
    slope = coeffs[0]
    
    # Calculate R-squared
    y_pred = np.polyval(coeffs, x)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    
    if ss_tot == 0:
        r_squared = 0
    else:
        r_squared = 1 - (ss_res / ss_tot)
    
    # Determine direction
    if abs(slope) < 0.01:
        direction = 'SIDEWAYS'
    elif slope > 0:
        direction = 'UP'
    else:
        direction = 'DOWN'
    
    return abs(r_squared), direction


def calculate_atr_percent(df: pd.DataFrame, period: int = 14) -> float:
    """
    Calculate Average True Range as percentage of price
    
    For Short Strangle: WANT LOW ATR (< 2.5%) = quiet stock
    """
    if len(df) < period + 1:
        return 0.0
    
    high = df['high']
    low = df['low']
    close = df['close']
    
    tr1 = high - low
    tr2 = abs(high - close.shift(1))
    tr3 = abs(low - close.shift(1))
    
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    atr = tr.rolling(window=period).mean().iloc[-1]
    
    current_price = close.iloc[-1]
    atr_percent = (atr / current_price) * 100
    
    return atr_percent


def calculate_range_tightness(df: pd.DataFrame, period: int = 30) -> float:
    """
    Calculate how tight the price range is over period
    
    For Short Strangle: WANT TIGHT range (< 5%) = consolidating
    """
    if len(df) < period:
        return 1.0
    
    recent_high = df['high'].tail(period).max()
    recent_low = df['low'].tail(period).min()
    current_close = df['close'].iloc[-1]
    
    range_pct = (recent_high - recent_low) / current_close
    
    return range_pct


class ShortStrangleScanner:
    """
    Scanner for Short Strangle opportunities
    Identifies range-bound stocks with high IV for premium collection
    """
    
    def __init__(self, api_key: str, access_token: str, event_data_path: str):
        """Initialize scanner with Kite credentials and event data"""
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Load event data
        logger.info(f"Loading event data from {event_data_path}...")
        self.event_data = pd.read_csv(event_data_path)
        logger.info(f"Loaded event data for {len(self.event_data)} instruments")
        
        # Cache for instruments
        self.instrument_cache = {}
        
        # Initialize
        self._load_instruments()
        logger.info("ShortStrangleScanner initialized successfully")
        logger.info(f"Target hold period: 3-5 weeks")
        logger.info(f"Days to expiry range: {ShortStrangleConfig.MIN_DAYS_TO_EXPIRY}-{ShortStrangleConfig.MAX_DAYS_TO_EXPIRY}")
    
    def _load_instruments(self):
        """Load instrument master from Kite"""
        logger.info("Loading instrument master...")
        
        # Load NSE instruments
        nse_instruments = self.kite.instruments("NSE")
        for instrument in nse_instruments:
            self.instrument_cache[instrument['tradingsymbol']] = {
                'token': instrument['instrument_token'],
                'exchange': 'NSE',
                'name': instrument['name'],
                'instrument_type': instrument['instrument_type']
            }
        
        # Load NFO instruments (options)
        nfo_instruments = self.kite.instruments("NFO")
        for instrument in nfo_instruments:
            self.instrument_cache[instrument['tradingsymbol']] = {
                'token': instrument['instrument_token'],
                'exchange': 'NFO',
                'name': instrument['name'],
                'instrument_type': instrument['instrument_type'],
                'strike': instrument['strike'],
                'expiry': instrument['expiry']
            }
        
        logger.info(f"Loaded {len(self.instrument_cache)} instruments")
    
    def _get_event_info(self, symbol: str) -> Optional[Dict]:
        """
        Get event data for symbol
        Returns dict with IV percentile, event, PCR, etc.
        """
        event_row = self.event_data[self.event_data['Instrument'] == symbol]
        
        if event_row.empty:
            logger.debug(f"{symbol}: No event data found")
            return None
        
        return {
            'iv_percentile': event_row['IVPercentile'].values[0],
            'event': event_row['Event'].values[0],
            'atmiv': event_row['ATMIV'].values[0],
            'atmiv_change': event_row['ATMIVChange'].values[0],
            'pcr': event_row['PCR'].values[0],
            'fut_oi_change': event_row['FutureOIPercentChange'].values[0],
            'volume_multiple': event_row['VolumeMultiple'].values[0],
            'max_pain': event_row['MaxPain'].values[0],
            'future_price': event_row['FuturePrice'].values[0]
        }
    
    def _fetch_historical_data(self, instrument_token: int, from_date: datetime, 
                              to_date: datetime, interval: str) -> pd.DataFrame:
        """Fetch historical data from Kite"""
        try:
            data = self.kite.historical_data(
                instrument_token,
                from_date,
                to_date,
                interval,
                continuous=False,
                oi=False
            )
            
            if not data:
                return pd.DataFrame()
            
            df = pd.DataFrame(data)
            return df
            
        except Exception as e:
            logger.error(f"Error fetching historical data: {e}")
            return pd.DataFrame()
    
    def _find_strangle_strikes(self, underlying_symbol: str, spot_price: float,
                              days_to_expiry_range: Tuple[int, int]) -> Optional[Dict]:
        """
        Find OTM call and put strikes for short strangle
        Returns dict with both strikes and their details
        """
        # Find options matching criteria
        options = []
        for symbol, data in self.instrument_cache.items():
            if (data['exchange'] == 'NFO' and
                data['instrument_type'] in ['CE', 'PE'] and
                symbol.startswith(underlying_symbol)):
                
                expiry = data.get('expiry')
                if expiry:
                    days_left = (expiry - datetime.now().date()).days
                    
                    if days_to_expiry_range[0] <= days_left <= days_to_expiry_range[1]:
                        options.append({
                            'symbol': symbol,
                            'strike': data['strike'],
                            'expiry': expiry,
                            'type': data['instrument_type'],
                            'days_to_expiry': days_left
                        })
        
        if not options:
            logger.debug(f"{underlying_symbol}: No options in expiry range")
            return None
        
        # Find nearest expiry
        options_df = pd.DataFrame(options)
        nearest_expiry = options_df['expiry'].min()
        nearest_options = options_df[options_df['expiry'] == nearest_expiry]
        
        # Calculate target strikes (OTM on both sides)
        call_target = spot_price * (1 + ShortStrangleConfig.CALL_OTM_PERCENT)
        put_target = spot_price * (1 - ShortStrangleConfig.PUT_OTM_PERCENT)
        
        # Find nearest strikes
        strikes = sorted(nearest_options['strike'].unique())
        call_strike = min(strikes, key=lambda x: abs(x - call_target) if x > spot_price else float('inf'))
        put_strike = min(strikes, key=lambda x: abs(x - put_target) if x < spot_price else float('inf'))
        
        # Get option symbols
        ce_options = nearest_options[nearest_options['type'] == 'CE']
        pe_options = nearest_options[nearest_options['type'] == 'PE']
        
        call_symbol = ce_options[ce_options['strike'] == call_strike]['symbol'].values
        put_symbol = pe_options[pe_options['strike'] == put_strike]['symbol'].values
        
        if len(call_symbol) == 0 or len(put_symbol) == 0:
            return None
        
        return {
            'expiry': nearest_expiry,
            'days_to_expiry': nearest_options['days_to_expiry'].iloc[0],
            'call_strike': call_strike,
            'put_strike': put_strike,
            'call_symbol': call_symbol[0],
            'put_symbol': put_symbol[0],
            'spot_price': spot_price
        }
    
    def _evaluate_short_strangle(self, symbol: str, spot_price: float,
                                df_daily: pd.DataFrame, event_info: Dict,
                                strangle_data: Dict) -> Optional[Dict]:
        """
        Evaluate and score short strangle setup
        
        Scoring (need 8/14 points):
        - IV Percentile: 0-3 pts
        - No Event: +2 pts
        - Sideways trend: 0-2 pts
        - Low ATR: 0-2 pts
        - Tight range: 0-1 pt
        - Balanced PCR: 0-1 pt
        - Low futures activity: 0-1 pt
        - IV declining: 0-1 pt
        - Ideal expiry: 0-1 pt
        - Good premium: 0-1 pt
        """
        score = 0
        reasons = []
        
        # 1. IV Percentile (0-3 pts) - CRITICAL
        iv_pct = event_info['iv_percentile']
        if iv_pct >= ShortStrangleConfig.EXCELLENT_IV_PERCENTILE:
            score += 3
            reasons.append(f"Excellent IV {iv_pct}% (premium rich)")
        elif iv_pct >= ShortStrangleConfig.IDEAL_IV_PERCENTILE:
            score += 2
            reasons.append(f"High IV {iv_pct}% (good premium)")
        elif iv_pct >= ShortStrangleConfig.MIN_IV_PERCENTILE:
            score += 1
            reasons.append(f"Moderate IV {iv_pct}%")
        else:
            # Too low IV - not worth selling
            return None
        
        # 2. No Event (+2 pts) - CRITICAL
        if event_info['event'] == '-':
            score += 2
            reasons.append("No upcoming events ✅")
        else:
            # Has event - auto reject
            logger.info(f"{symbol}: REJECTED - Event '{event_info['event']}' detected")
            return None
        
        # 3. Trend Strength (0-2 pts or -3 penalty)
        closes = df_daily['close'].tail(30).values.tolist()
        trend_strength, trend_direction = calculate_trend_strength(closes)
        
        if trend_strength < ShortStrangleConfig.MAX_TREND_STRENGTH:
            score += 2
            reasons.append(f"Sideways (R² {trend_strength:.2f})")
        elif trend_strength < ShortStrangleConfig.MODERATE_TREND_MAX:
            score += 1
            reasons.append(f"Weak trend (R² {trend_strength:.2f})")
        else:
            # Strong trend - dangerous for short strangle
            score -= 3
            reasons.append(f"⚠️ Strong {trend_direction} trend (R² {trend_strength:.2f})")
        
        # 4. ATR (0-2 pts)
        atr_pct = calculate_atr_percent(df_daily)
        if atr_pct < ShortStrangleConfig.IDEAL_ATR_PERCENT:
            score += 2
            reasons.append(f"Very low ATR {atr_pct:.1f}% (quiet)")
        elif atr_pct < ShortStrangleConfig.MAX_ATR_PERCENT:
            score += 1
            reasons.append(f"Low ATR {atr_pct:.1f}%")
        
        # 5. Range Tightness (0-1 pt)
        range_pct = calculate_range_tightness(df_daily)
        if range_pct < ShortStrangleConfig.IDEAL_RANGE_PERCENT:
            score += 1
            reasons.append(f"Very tight range {range_pct*100:.1f}%")
        elif range_pct < ShortStrangleConfig.MAX_RANGE_PERCENT:
            score += 0.5
            reasons.append(f"Tight range {range_pct*100:.1f}%")
        
        # 6. PCR Balance (0-1 pt)
        pcr = event_info['pcr']
        if ShortStrangleConfig.PCR_MIN <= pcr <= ShortStrangleConfig.PCR_MAX:
            score += 1
            reasons.append(f"Balanced PCR {pcr:.2f}")
        
        # 7. Low Futures Activity (0-1 pt)
        fut_oi_change = abs(event_info['fut_oi_change'])
        if fut_oi_change < ShortStrangleConfig.MAX_FUT_OI_CHANGE:
            score += 1
            reasons.append(f"Low futures activity {event_info['fut_oi_change']:.1f}%")
        
        # 8. IV Declining (0-1 pt)
        if event_info['atmiv_change'] < 0:
            score += 1
            reasons.append(f"IV declining ({event_info['atmiv_change']:.1f})")
        
        # 9. Ideal Days to Expiry (0-1 pt)
        days = strangle_data['days_to_expiry']
        if ShortStrangleConfig.IDEAL_DAYS_MIN <= days <= ShortStrangleConfig.IDEAL_DAYS_MAX:
            score += 1
            reasons.append(f"Ideal expiry {days} days")
        elif ShortStrangleConfig.MIN_DAYS_TO_EXPIRY <= days <= ShortStrangleConfig.MAX_DAYS_TO_EXPIRY:
            score += 0.5
            reasons.append(f"{days} days to expiry")
        
        # 10. Get option prices and calculate premium
        try:
            call_key = f"NFO:{strangle_data['call_symbol']}"
            put_key = f"NFO:{strangle_data['put_symbol']}"
            
            quotes = self.kite.quote([call_key, put_key])
            call_price = quotes[call_key]['last_price']
            put_price = quotes[put_key]['last_price']
            
            total_premium = call_price + put_price
            premium_pct = (total_premium / spot_price) * 100
            
            if premium_pct >= ShortStrangleConfig.IDEAL_PREMIUM_PCT:
                score += 1
                reasons.append(f"Good premium {premium_pct:.1f}%")
            elif premium_pct >= ShortStrangleConfig.MIN_TOTAL_PREMIUM_PCT:
                score += 0.5
                reasons.append(f"Acceptable premium {premium_pct:.1f}%")
            else:
                # Premium too low
                return None
            
        except Exception as e:
            logger.error(f"{symbol}: Failed to get option prices: {e}")
            return None
        
        # Check minimum score
        if score < ShortStrangleConfig.MIN_SCORE:
            logger.debug(f"{symbol}: Score {score:.1f}/14 too low (need {ShortStrangleConfig.MIN_SCORE})")
            return None
        
        # Calculate breakevens
        upper_breakeven = strangle_data['call_strike'] + total_premium
        lower_breakeven = strangle_data['put_strike'] - total_premium
        range_width_pct = (upper_breakeven - lower_breakeven) / spot_price * 100
        
        # Calculate profit target (collect 60% of premium)
        target_profit_per_share = total_premium * ShortStrangleConfig.PROFIT_TARGET_PCT
        
        return {
            'strategy': 'SHORT STRANGLE',
            'score': round(score, 1),
            'reasons': reasons,
            'call_symbol': strangle_data['call_symbol'],
            'put_symbol': strangle_data['put_symbol'],
            'call_strike': strangle_data['call_strike'],
            'put_strike': strangle_data['put_strike'],
            'call_price': call_price,
            'put_price': put_price,
            'total_premium': total_premium,
            'premium_pct': round(premium_pct, 2),
            'spot_price': spot_price,
            'days_to_expiry': days,
            'expiry_date': strangle_data['expiry'],
            'iv_percentile': iv_pct,
            'atmiv': event_info['atmiv'],
            'pcr': pcr,
            'trend_strength': round(trend_strength, 2),
            'trend_direction': trend_direction,
            'atr_pct': round(atr_pct, 2),
            'range_pct': round(range_pct * 100, 2),
            'upper_breakeven': round(upper_breakeven, 2),
            'lower_breakeven': round(lower_breakeven, 2),
            'range_width_pct': round(range_width_pct, 2),
            'target_profit': round(target_profit_per_share, 2),
            'max_loss_trigger': round(total_premium * ShortStrangleConfig.MAX_LOSS_MULTIPLE, 2),
            'hold_period': '3-5 weeks',
            'event_status': event_info['event']
        }
    
    def scan_symbol(self, symbol: str) -> Optional[Dict]:
        """
        Scan a single symbol for short strangle opportunity
        """
        logger.info(f"Scanning {symbol} for short strangle setup...")
        
        # Get event data FIRST (fast filter)
        event_info = self._get_event_info(symbol)
        if not event_info:
            logger.debug(f"{symbol}: No event data available")
            return None
        
        # Quick reject: Event present
        if event_info['event'] != '-':
            logger.info(f"{symbol}: REJECTED - Event '{event_info['event']}' detected")
            return None
        
        # Quick reject: IV too low
        if event_info['iv_percentile'] < ShortStrangleConfig.MIN_IV_PERCENTILE:
            logger.debug(f"{symbol}: REJECTED - IV percentile {event_info['iv_percentile']}% too low")
            return None
        
        # Get spot price
        nse_key = f"NSE:{symbol}"
        try:
            quote = self.kite.quote([nse_key])
            spot_price = quote[nse_key]['last_price']
        except Exception as e:
            logger.error(f"{symbol}: Failed to get spot price: {e}")
            return None
        
        # Get historical data
        token = self.instrument_cache.get(symbol, {}).get('token')
        if not token:
            logger.warning(f"{symbol}: Token not found")
            return None
        
        now = datetime.now()
        from_date = now - timedelta(days=60)
        df_daily = self._fetch_historical_data(token, from_date, now, 'day')
        
        if df_daily.empty or len(df_daily) < 30:
            logger.warning(f"{symbol}: Insufficient historical data")
            return None
        
        # Find strangle strikes
        days_range = (ShortStrangleConfig.MIN_DAYS_TO_EXPIRY, 
                     ShortStrangleConfig.MAX_DAYS_TO_EXPIRY)
        strangle_data = self._find_strangle_strikes(symbol, spot_price, days_range)
        
        if not strangle_data:
            logger.debug(f"{symbol}: No suitable options found")
            return None
        
        logger.info(f"{symbol}: Found strangle - Call {strangle_data['call_strike']}, Put {strangle_data['put_strike']}, {strangle_data['days_to_expiry']} days")
        
        # Evaluate setup
        setup = self._evaluate_short_strangle(symbol, spot_price, df_daily, 
                                              event_info, strangle_data)
        
        if setup:
            logger.info(f"{symbol}: SHORT STRANGLE - Score {setup['score']:.1f}/14 ✅")
            return {**setup, 'symbol': symbol}
        
        return None
    
    def scan_universe(self, symbols: List[str]) -> pd.DataFrame:
        """
        Scan multiple symbols and return results
        """
        results = []
        total = len(symbols)
        
        # Diagnostic counters
        reject_reasons = {
            'no_event_data': 0,
            'has_event': 0,
            'iv_too_low': 0,
            'no_spot_price': 0,
            'no_historical_data': 0,
            'no_options': 0,
            'failed_evaluation': 0,
            'score_too_low': 0
        }
        
        # Sample rejections for detailed analysis
        sample_rejections = []
        
        for i, symbol in enumerate(symbols, 1):
            if i <= 5 or i % 50 == 0:  # Log first 5 and every 50th
                logger.info(f"Processing {i}/{total}: {symbol}")
            
            try:
                # Track rejection reasons with samples
                event_info = self._get_event_info(symbol)
                if not event_info:
                    reject_reasons['no_event_data'] += 1
                    if len(sample_rejections) < 10:
                        sample_rejections.append(f"{symbol}: No event data in CSV")
                    continue
                
                if event_info['event'] != '-':
                    reject_reasons['has_event'] += 1
                    if len(sample_rejections) < 10:
                        sample_rejections.append(f"{symbol}: Event '{event_info['event']}'")
                    continue
                
                if event_info['iv_percentile'] < ShortStrangleConfig.MIN_IV_PERCENTILE:
                    reject_reasons['iv_too_low'] += 1
                    if len(sample_rejections) < 10:
                        sample_rejections.append(f"{symbol}: IV {event_info['iv_percentile']}% (need {ShortStrangleConfig.MIN_IV_PERCENTILE}%+)")
                    continue
                
                # If passed quick filters, do full scan
                logger.debug(f"{symbol}: Passed quick filters (IV {event_info['iv_percentile']}%), doing full scan...")
                
                setup = self.scan_symbol(symbol)
                if setup:
                    results.append(setup)
                    logger.info(f"✅ {symbol}: QUALIFIED with score {setup['score']:.1f}/14")
                else:
                    reject_reasons['failed_evaluation'] += 1
                    if len(sample_rejections) < 10:
                        sample_rejections.append(f"{symbol}: Failed trend/score checks (IV was OK at {event_info['iv_percentile']}%)")
                
                # Rate limiting
                time.sleep(0.3)
                
            except Exception as e:
                logger.error(f"{symbol}: Error during scan: {e}")
                continue
        
        # Log diagnostic summary
        logger.info("\n" + "=" * 80)
        logger.info("SCAN DIAGNOSTICS:")
        logger.info("=" * 80)
        logger.info("\nREJECTION BREAKDOWN:")
        logger.info("-" * 80)
        logger.info(f"  No event data in CSV:        {reject_reasons['no_event_data']:3d} stocks")
        logger.info(f"  Has upcoming event:          {reject_reasons['has_event']:3d} stocks")
        logger.info(f"  IV too low (<{ShortStrangleConfig.MIN_IV_PERCENTILE}%):       {reject_reasons['iv_too_low']:3d} stocks")
        logger.info(f"  Failed trend/score checks:   {reject_reasons['failed_evaluation']:3d} stocks")
        logger.info("-" * 80)
        logger.info(f"  Total rejected:              {sum(reject_reasons.values()):3d} stocks")
        logger.info(f"  Total qualified:             {len(results):3d} stocks")
        logger.info("=" * 80)
        
        if sample_rejections:
            logger.info("\nSAMPLE REJECTIONS (first 10):")
            logger.info("-" * 80)
            for rejection in sample_rejections:
                logger.info(f"  {rejection}")
            logger.info("=" * 80 + "\n")
        
        if not results:
            logger.warning("\n⚠️  NO SETUPS FOUND!")
            logger.warning("\nPossible reasons:")
            if reject_reasons['iv_too_low'] > 100:
                logger.warning(f"  → Even at lowered threshold (35%), IV still too low")
                logger.warning(f"  → INDIA VIX 11.6 is borderline - may need to wait")
                logger.warning(f"  → Alternative: Focus on long options (buy cheap)")
            if reject_reasons['has_event'] > 50:
                logger.warning(f"  → Earnings season (many stocks have events)")
            if reject_reasons['failed_evaluation'] > 50:
                logger.warning(f"  → Market trending strongly (not range-bound)")
                logger.warning(f"  → Check Nifty trend - if R² > 0.5, wait for consolidation")
            logger.warning("")
            return pd.DataFrame()
        
        # Convert to DataFrame and sort by score
        df = pd.DataFrame(results)
        df = df.sort_values('score', ascending=False)
        
        return df


def main():
    """Main execution"""
    import sys
    
    # Configuration
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "IIyA1VyxcQxaiRlmlVbMaabOb27Kzi12"
    EVENT_DATA_PATH = "options_screener_2025-12-03-01-59-28.csv"  # Path to your event data file
    UNIVERSE_FILE = "data/FNOStock.csv"
    
    logger.info("=" * 80)
    logger.info("SHORT STRANGLE SCANNER - Premium Collection Strategy")
    logger.info("Hold Period: 3-5 weeks")
    logger.info("Strategy: Sell OTM Call + Sell OTM Put on range-bound stocks")
    logger.info("-" * 80)
    logger.info("CURRENT MARKET CONDITIONS:")
    logger.info("  INDIA VIX: ~11.6 (Borderline - lower threshold active)")
    logger.info("  Settings adjusted: MIN_IV=35%, MIN_SCORE=6/14, 5% OTM strikes")
    logger.info("  Expect: 5-15 setups with moderate premium (1.8-2.5%)")
    logger.info("  Note: Be selective - only trade score 7+ if possible")
    logger.info("=" * 80)
    
    # Load universe
    try:
        universe_df = pd.read_csv(UNIVERSE_FILE)
        universe = universe_df['Symbol'].tolist()
        logger.info(f"Loaded {len(universe)} symbols from {UNIVERSE_FILE}")
    except Exception as e:
        logger.error(f"Failed to load universe: {e}")
        sys.exit(1)
    
    # Initialize scanner
    try:
        scanner = ShortStrangleScanner(API_KEY, ACCESS_TOKEN, EVENT_DATA_PATH)
    except Exception as e:
        logger.error(f"Failed to initialize scanner: {e}")
        sys.exit(1)
    
    # Run scan
    logger.info(f"Starting short strangle scan of {len(universe)} symbols...")
    start_time = datetime.now()
    
    results_df = scanner.scan_universe(universe)
    
    duration = (datetime.now() - start_time).total_seconds()
    
    # Display results
    logger.info("=" * 80)
    logger.info(f"SCAN COMPLETE - Duration: {duration:.1f} seconds")
    logger.info(f"Symbols scanned: {len(universe)}")
    logger.info(f"Setups found: {len(results_df)}")
    logger.info("=" * 80)
    
    if not results_df.empty:
        # Save to CSV
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"/mnt/user-data/outputs/short_strangle_results_{timestamp}.csv"
        results_df.to_csv(output_file, index=False)
        logger.info(f"Results saved to: {output_file}")
        
        # Display top 10
        logger.info("\n🎯 TOP 10 SHORT STRANGLE SETUPS (by score):")
        logger.info("-" * 80)
        
        for idx, row in results_df.head(10).iterrows():
            logger.info(f"\n{row['symbol']} - SHORT STRANGLE (Score: {row['score']:.1f}/14)")
            logger.info(f"  Sell: {row['call_strike']} Call @ Rs.{row['call_price']:.2f}")
            logger.info(f"  Sell: {row['put_strike']} Put @ Rs.{row['put_price']:.2f}")
            logger.info(f"  Total Premium: Rs.{row['total_premium']:.2f} ({row['premium_pct']:.1f}% of spot)")
            logger.info(f"  Spot: Rs.{row['spot_price']:.2f}")
            logger.info(f"  Breakevens: Rs.{row['lower_breakeven']:.2f} - Rs.{row['upper_breakeven']:.2f}")
            logger.info(f"  Range Width: {row['range_width_pct']:.1f}%")
            logger.info(f"  Days to Expiry: {row['days_to_expiry']}")
            logger.info(f"  IV Percentile: {row['iv_percentile']}%")
            logger.info(f"  PCR: {row['pcr']:.2f}")
            logger.info(f"  Reasons: {', '.join(row['reasons'])}")
        
        logger.info("-" * 80)
        logger.info(f"\n⚠️  RISK WARNING:")
        logger.info(f"  - Max Loss: UNLIMITED (if stock moves sharply)")
        logger.info(f"  - Exit if loss exceeds 2× premium collected")
        logger.info(f"  - Adjust positions if delta breaches 0.30")
        logger.info(f"  - Close by 7 days before expiry (gamma risk)")
        logger.info(f"  - Diversify across sectors (max 20% per stock)")
        logger.info("-" * 80)
    else:
        logger.info("No suitable short strangle setups found in current market conditions")


if __name__ == "__main__":
    main()
