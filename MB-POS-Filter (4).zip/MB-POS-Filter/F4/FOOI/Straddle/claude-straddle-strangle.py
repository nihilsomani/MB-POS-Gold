import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
from scipy.stats import percentileofscore
import warnings
import time
warnings.filterwarnings('ignore')

api_key = "3bi2yh8g830vq3y6"
access_token = "IIyA1VyxcQxaiRlmlVbMaabOb27Kzi12"
kite = KiteConnect(api_key=api_key)
kite.set_access_token(access_token)

fno_stocks = pd.read_csv('data/FNOStock.csv')
symbols = fno_stocks['Symbol'].tolist()

LOOKBACK_DAYS = 90
ATR_PERIOD = 14
HISTORICAL_OPTION_DAYS = 45
API_DELAY = 0.33
MIN_DATA_DAYS = 40

NSE_INSTRUMENTS_CACHE = None
NFO_INSTRUMENTS_CACHE = None
INSTRUMENT_TOKEN_CACHE = {}

def initialize_instrument_cache():
    """Load all instruments once at startup"""
    global NSE_INSTRUMENTS_CACHE, NFO_INSTRUMENTS_CACHE
    
    print("=" * 100)
    print("INITIALIZING INSTRUMENT CACHE")
    print("=" * 100)
    
    try:
        print("  Loading NSE instruments...", end=' ', flush=True)
        NSE_INSTRUMENTS_CACHE = kite.instruments("NSE")
        print(f"✅ {len(NSE_INSTRUMENTS_CACHE)} instruments loaded")
        time.sleep(0.5)
        
        print("  Loading NFO instruments...", end=' ', flush=True)
        NFO_INSTRUMENTS_CACHE = kite.instruments("NFO")
        print(f"✅ {len(NFO_INSTRUMENTS_CACHE)} instruments loaded")
        time.sleep(0.5)
        
        print("=" * 100)
        return True
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def get_instrument_token(symbol, exchange="NSE"):
    """Get instrument token with caching"""
    global INSTRUMENT_TOKEN_CACHE
    
    cache_key = f"{exchange}:{symbol}"
    
    if cache_key in INSTRUMENT_TOKEN_CACHE:
        return INSTRUMENT_TOKEN_CACHE[cache_key]
    
    try:
        instruments = NSE_INSTRUMENTS_CACHE if exchange == "NSE" else NFO_INSTRUMENTS_CACHE
        
        if instruments is None:
            return None
        
        for inst in instruments:
            if inst['tradingsymbol'] == symbol and inst['segment'] == exchange:
                INSTRUMENT_TOKEN_CACHE[cache_key] = inst['instrument_token']
                return inst['instrument_token']
        
        INSTRUMENT_TOKEN_CACHE[cache_key] = None
        return None
        
    except Exception as e:
        return None

def get_historical_data(instrument_token, days=90, retries=2):
    for attempt in range(retries):
        try:
            to_date = datetime.now().date()
            from_date = to_date - timedelta(days=days)
            
            data = kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if data and len(data) > 0:
                df = pd.DataFrame(data)
                df['date'] = pd.to_datetime(df['date'])
                return df
            
        except Exception as e:
            if "Too many requests" in str(e):
                time.sleep(2)
            if attempt < retries - 1:
                time.sleep(1)
                continue
            return None
    
    return None

def calculate_atr(df, period=14):
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = np.max(ranges, axis=1)
    atr = true_range.rolling(period).mean()
    return atr

def calculate_bollinger_bands(df, period=20, std_dev=2):
    sma = df['close'].rolling(period).mean()
    std = df['close'].rolling(period).std()
    upper = sma + (std_dev * std)
    lower = sma - (std_dev * std)
    return upper, sma, lower

def calculate_rsi(df, period=14):
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def identify_regime(df):
    current_price = df['close'].iloc[-1]
    sma20 = df['close'].rolling(20).mean().iloc[-1]
    sma50 = df['close'].rolling(50).mean().iloc[-1] if len(df) >= 50 else sma20
    
    atr = calculate_atr(df).iloc[-1]
    atr_pct = (atr / current_price) * 100
    
    if current_price > sma20 > sma50:
        trend = "UPTREND"
    elif current_price < sma20 < sma50:
        trend = "DOWNTREND"
    else:
        trend = "SIDEWAYS"
    
    if atr_pct < 2:
        vol_regime = "LOW"
    elif atr_pct > 4:
        vol_regime = "HIGH"
    else:
        vol_regime = "MEDIUM"
    
    return trend, vol_regime, atr_pct

def get_option_chain(symbol, expiry_date):
    """Get option chain using cached NFO instruments"""
    try:
        if NFO_INSTRUMENTS_CACHE is None:
            return []
        
        options = [inst for inst in NFO_INSTRUMENTS_CACHE 
                  if inst['name'] == symbol 
                  and inst['expiry'] == expiry_date
                  and inst['instrument_type'] in ['CE', 'PE']]
        return options
    except:
        return []

def get_atm_strike(current_price):
    if current_price < 100:
        strike_diff = 2.5
    elif current_price < 500:
        strike_diff = 5
    elif current_price < 1000:
        strike_diff = 10
    elif current_price < 2000:
        strike_diff = 25
    elif current_price < 5000:
        strike_diff = 50
    else:
        strike_diff = 100
    
    return round(current_price / strike_diff) * strike_diff

def calculate_premium_pct(strike, premium):
    return (premium / strike) * 100

def get_option_quotes(trading_symbols, retries=2):
    for attempt in range(retries):
        try:
            if not trading_symbols:
                return {}
            quotes = kite.quote([f"NFO:{ts}" for ts in trading_symbols])
            return quotes
        except Exception as e:
            if "Too many requests" in str(e):
                time.sleep(2)
            if attempt < retries - 1:
                time.sleep(1)
            continue
    return {}

def get_optimal_expiries(symbol):
    """
    Get optimal expiries for different strategies:
    - weekly_expiry: For straddles and naked options (2-10 DTE)
    - monthly_expiry: For strangles (current month, 14-30 DTE)
    
    FIXED: Now correctly selects current month expiry, not next month!
    """
    try:
        if NFO_INSTRUMENTS_CACHE is None:
            return None, None
        
        expiries = sorted(list(set([inst['expiry'] for inst in NFO_INSTRUMENTS_CACHE 
                                   if inst['name'] == symbol 
                                   and inst['instrument_type'] in ['CE', 'PE']])))
        
        today = datetime.now().date()
        future_expiries = [exp for exp in expiries if exp >= today]
        
        if not future_expiries:
            return None, None
        
        # Calculate DTE for all expiries
        expiries_with_dte = [(exp, (exp - today).days) for exp in future_expiries]
        
        # === WEEKLY EXPIRY (for straddles and naked options) ===
        # Target: 2-10 DTE (weekly options)
        weekly_candidates = [(exp, dte) for exp, dte in expiries_with_dte if 2 <= dte <= 10]
        
        if weekly_candidates:
            # Prefer 3-7 DTE range
            weekly_expiry = min(weekly_candidates, key=lambda x: abs(x[1] - 5))[0]
        else:
            # Fallback: nearest expiry
            weekly_expiry = future_expiries[0]
        
        # === MONTHLY EXPIRY (for strangles) ===
        # Target: 14-30 DTE (CURRENT MONTH monthly expiry)
        # This is the KEY FIX - we want current month, not next month!
        monthly_candidates = [(exp, dte) for exp, dte in expiries_with_dte if 14 <= dte <= 30]
        
        if monthly_candidates:
            # Prefer 20-25 DTE (optimal for 2-4 week hold)
            monthly_expiry = min(monthly_candidates, key=lambda x: abs(x[1] - 23))[0]
        else:
            # If no expiry in 14-30 range, find closest to 20 DTE
            monthly_expiry = min(expiries_with_dte, key=lambda x: abs(x[1] - 20))[0]
        
        return weekly_expiry, monthly_expiry
        
    except Exception as e:
        return None, None

def get_historical_option_prices(symbol, strike, option_type, expiry, days=45):
    try:
        if NFO_INSTRUMENTS_CACHE is None:
            return None
        
        option = [inst for inst in NFO_INSTRUMENTS_CACHE 
                 if inst['name'] == symbol 
                 and inst['strike'] == strike
                 and inst['instrument_type'] == option_type
                 and inst['expiry'] == expiry]
        
        if not option:
            return None
        
        instrument_token = option[0]['instrument_token']
        
        to_date = datetime.now().date()
        from_date = to_date - timedelta(days=days)
        
        data = kite.historical_data(
            instrument_token=instrument_token,
            from_date=from_date,
            to_date=to_date,
            interval="day"
        )
        
        if not data or len(data) < 3:
            return None
        
        df = pd.DataFrame(data)
        return df['close'].values
        
    except Exception as e:
        if "Too many requests" in str(e):
            time.sleep(2)
        return None

def analyze_strategy_history(ce_history, pe_history, current_ce_ltp, current_pe_ltp):
    if ce_history is None or pe_history is None:
        return None
    
    if len(ce_history) < 3 or len(pe_history) < 3:
        return None
    
    min_len = min(len(ce_history), len(pe_history))
    ce_history = ce_history[-min_len:]
    pe_history = pe_history[-min_len:]
    
    strategy_history = ce_history + pe_history
    current_strategy_price = current_ce_ltp + current_pe_ltp
    
    if len(strategy_history) < 3:
        return None
    
    strategy_vol = np.std(strategy_history) / np.mean(strategy_history) if np.mean(strategy_history) > 0 else 999
    
    max_price = np.max(strategy_history)
    min_price = np.min(strategy_history)
    expansion_ratio = max_price / min_price if min_price > 0 else 999
    
    entry_percentile = percentileofscore(strategy_history, current_strategy_price)
    
    recent_avg = np.mean(strategy_history[-3:])
    older_avg = np.mean(strategy_history[:-3]) if len(strategy_history) > 3 else recent_avg
    
    if older_avg > 0:
        iv_trend = "FALLING" if recent_avg < older_avg * 0.95 else ("RISING" if recent_avg > older_avg * 1.05 else "STABLE")
    else:
        iv_trend = "STABLE"
    
    ce_weight = np.mean(ce_history / strategy_history)
    
    return {
        'strategy_vol': strategy_vol,
        'expansion_ratio': expansion_ratio,
        'entry_percentile': entry_percentile,
        'iv_trend': iv_trend,
        'ce_weight': ce_weight,
        'pe_weight': 1 - ce_weight,
        'historical_mean': np.mean(strategy_history),
        'historical_max': max_price,
        'historical_min': min_price
    }

def evaluate_strategy_quality(analysis):
    if analysis is None:
        return "UNKNOWN", []
    
    issues = []
    
    if analysis['strategy_vol'] > 0.65:
        issues.append("High vol")
    
    if analysis['expansion_ratio'] > 4.0:
        issues.append("High expansion")
    
    if analysis['entry_percentile'] > 80:
        issues.append("Expensive")
    
    if analysis['entry_percentile'] < 10:
        issues.append("Very low prem")
    
    if analysis['iv_trend'] == "RISING":
        issues.append("IV rising")
    
    if analysis['ce_weight'] > 0.80 or analysis['ce_weight'] < 0.20:
        issues.append("Imbalanced")
    
    if len(issues) == 0:
        return "EXCELLENT", issues
    elif len(issues) <= 1:
        return "GOOD", issues
    elif len(issues) <= 2:
        return "ACCEPTABLE", issues
    else:
        return "POOR", issues

def scan_short_straddle(symbol, df, current_price, weekly_expiry):
    """
    Scan for short straddle with WEEKLY expiry (2-10 DTE)
    For very short-term trades (2-5 days)
    """
    if weekly_expiry is None:
        return None
    
    days_to_expiry = (weekly_expiry - datetime.now().date()).days
    
    # Straddles need very short DTE (weekly options)
    if days_to_expiry > 10 or days_to_expiry < 2:
        return None
    
    trend, vol_regime, atr_pct = identify_regime(df)
    
    if trend != "SIDEWAYS" or vol_regime == "HIGH":
        return None
    
    sma20 = df['close'].rolling(20).mean().iloc[-1]
    sma50 = df['close'].rolling(50).mean().iloc[-1] if len(df) >= 50 else sma20
    
    price_from_sma20 = abs((current_price - sma20) / sma20) * 100
    price_from_sma50 = abs((current_price - sma50) / sma50) * 100
    
    if price_from_sma20 > 3 or price_from_sma50 > 5:
        return None
    
    atm_strike = get_atm_strike(current_price)
    
    options = get_option_chain(symbol, weekly_expiry)
    if not options:
        return None
    
    atm_ce = [opt for opt in options if opt['strike'] == atm_strike and opt['instrument_type'] == 'CE']
    atm_pe = [opt for opt in options if opt['strike'] == atm_strike and opt['instrument_type'] == 'PE']
    
    if not atm_ce or not atm_pe:
        return None
    
    ce_symbol = atm_ce[0]['tradingsymbol']
    pe_symbol = atm_pe[0]['tradingsymbol']
    
    time.sleep(API_DELAY)
    quotes = get_option_quotes([ce_symbol, pe_symbol])
    
    if f"NFO:{ce_symbol}" not in quotes or f"NFO:{pe_symbol}" not in quotes:
        return None
    
    ce_ltp = quotes[f"NFO:{ce_symbol}"]["last_price"]
    pe_ltp = quotes[f"NFO:{pe_symbol}"]["last_price"]
    
    if ce_ltp <= 0 or pe_ltp <= 0:
        return None
    
    total_premium = ce_ltp + pe_ltp
    premium_pct = (total_premium / atm_strike) * 100
    
    # For weekly straddles, need minimum premium
    min_premium_pct = 0.5 if days_to_expiry <= 5 else 1.0
    
    if premium_pct < min_premium_pct:
        return None
    
    time.sleep(API_DELAY)
    ce_history = get_historical_option_prices(symbol, atm_strike, 'CE', weekly_expiry, 30)
    time.sleep(API_DELAY)
    pe_history = get_historical_option_prices(symbol, atm_strike, 'PE', weekly_expiry, 30)
    
    analysis = analyze_strategy_history(ce_history, pe_history, ce_ltp, pe_ltp)
    quality, issues = evaluate_strategy_quality(analysis)
    
    if quality == "POOR":
        return None
    
    atr = calculate_atr(df).iloc[-1]
    expected_range_upper = current_price + (1.5 * atr)
    expected_range_lower = current_price - (1.5 * atr)
    
    base_score = premium_pct * 10 + (3 - min(atr_pct, 3)) * 5
    
    if analysis:
        if quality == "EXCELLENT":
            base_score += 20
        elif quality == "GOOD":
            base_score += 10
        
        if analysis['entry_percentile'] < 50:
            base_score += 5
        
        if analysis['iv_trend'] == "FALLING":
            base_score += 10
    
    result = {
        'Symbol': symbol,
        'Strategy': 'SHORT_STRADDLE',
        'Hold': f'{days_to_expiry}d',
        'Price': round(current_price, 2),
        'Strike': atm_strike,
        'CE': ce_symbol,
        'CE_Prem': round(ce_ltp, 2),
        'PE': pe_symbol,
        'PE_Prem': round(pe_ltp, 2),
        'Total_Prem': round(total_premium, 2),
        'Prem_%': round(premium_pct, 2),
        'DTE': days_to_expiry,
        'Trend': trend,
        'Vol': vol_regime,
        'ATR%': round(atr_pct, 2),
        'Range': f"{round(expected_range_lower, 1)}-{round(expected_range_upper, 1)}",
        'Quality': quality,
        'Score': round(base_score, 1)
    }
    
    if analysis:
        result.update({
            'Strat_Vol%': round(analysis['strategy_vol'] * 100, 1),
            'Max_Exp': round(analysis['expansion_ratio'], 2),
            'Entry_%ile': round(analysis['entry_percentile'], 1),
            'IV': analysis['iv_trend'],
            'CE_Wt%': round(analysis['ce_weight'] * 100, 1),
            'Issues': ';'.join(issues) if issues else '-'
        })
    
    return result

def scan_short_strangle(symbol, df, current_price, monthly_expiry):
    """
    Scan for short strangle with MONTHLY expiry (14-30 DTE)
    FIXED: Now uses current month expiry for true 2-4 week hold
    """
    if monthly_expiry is None:
        return None
    
    days_to_expiry = (monthly_expiry - datetime.now().date()).days
    
    # Strangles need 14-30 DTE (current month monthly)
    # This is the KEY FIX!
    if days_to_expiry > 30 or days_to_expiry < 14:
        return None
    
    trend, vol_regime, atr_pct = identify_regime(df)
    
    if vol_regime == "LOW":
        return None
    
    upper_bb, middle_bb, lower_bb = calculate_bollinger_bands(df)
    
    bb_upper = upper_bb.iloc[-1]
    bb_lower = lower_bb.iloc[-1]
    bb_width = ((bb_upper - bb_lower) / middle_bb.iloc[-1]) * 100
    
    if bb_width < 4:
        return None
    
    atr = calculate_atr(df).iloc[-1]
    
    otm_call_strike = get_atm_strike(current_price + (1.5 * atr))
    otm_put_strike = get_atm_strike(current_price - (1.5 * atr))
    
    options = get_option_chain(symbol, monthly_expiry)
    if not options:
        return None
    
    otm_ce = [opt for opt in options if opt['strike'] == otm_call_strike and opt['instrument_type'] == 'CE']
    otm_pe = [opt for opt in options if opt['strike'] == otm_put_strike and opt['instrument_type'] == 'PE']
    
    if not otm_ce or not otm_pe:
        return None
    
    ce_symbol = otm_ce[0]['tradingsymbol']
    pe_symbol = otm_pe[0]['tradingsymbol']
    
    time.sleep(API_DELAY)
    quotes = get_option_quotes([ce_symbol, pe_symbol])
    
    if f"NFO:{ce_symbol}" not in quotes or f"NFO:{pe_symbol}" not in quotes:
        return None
    
    ce_ltp = quotes[f"NFO:{ce_symbol}"]["last_price"]
    pe_ltp = quotes[f"NFO:{pe_symbol}"]["last_price"]
    
    if ce_ltp <= 0 or pe_ltp <= 0:
        return None
    
    total_premium = ce_ltp + pe_ltp
    
    ce_premium_pct = calculate_premium_pct(otm_call_strike, ce_ltp)
    pe_premium_pct = calculate_premium_pct(otm_put_strike, pe_ltp)
    
    # For monthly strangles (14-30 DTE), adjust minimum premium
    min_premium = 1.2 if days_to_expiry >= 20 else 1.0
    
    if ce_premium_pct < min_premium or pe_premium_pct < min_premium:
        return None
    
    time.sleep(API_DELAY)
    ce_history = get_historical_option_prices(symbol, otm_call_strike, 'CE', monthly_expiry, HISTORICAL_OPTION_DAYS)
    time.sleep(API_DELAY)
    pe_history = get_historical_option_prices(symbol, otm_put_strike, 'PE', monthly_expiry, HISTORICAL_OPTION_DAYS)
    
    analysis = analyze_strategy_history(ce_history, pe_history, ce_ltp, pe_ltp)
    quality, issues = evaluate_strategy_quality(analysis)
    
    if quality == "POOR":
        return None
    
    base_score = (ce_premium_pct + pe_premium_pct) * 5 + bb_width
    
    if analysis:
        if quality == "EXCELLENT":
            base_score += 20
        elif quality == "GOOD":
            base_score += 10
        
        if analysis['entry_percentile'] < 50:
            base_score += 5
    
    result = {
        'Symbol': symbol,
        'Strategy': 'SHORT_STRANGLE',
        'Hold': f'{days_to_expiry}d',
        'Price': round(current_price, 2),
        'Call_Strike': otm_call_strike,
        'CE': ce_symbol,
        'CE_Prem': round(ce_ltp, 2),
        'CE_%': round(ce_premium_pct, 2),
        'Put_Strike': otm_put_strike,
        'PE': pe_symbol,
        'PE_Prem': round(pe_ltp, 2),
        'PE_%': round(pe_premium_pct, 2),
        'Total': round(total_premium, 2),
        'DTE': days_to_expiry,
        'Trend': trend,
        'Vol': vol_regime,
        'ATR%': round(atr_pct, 2),
        'BB_Width': round(bb_width, 2),
        'Quality': quality,
        'Score': round(base_score, 1)
    }
    
    if analysis:
        result.update({
            'Strat_Vol%': round(analysis['strategy_vol'] * 100, 1),
            'Max_Exp': round(analysis['expansion_ratio'], 2),
            'Entry_%ile': round(analysis['entry_percentile'], 1),
            'IV': analysis['iv_trend'],
            'Issues': ';'.join(issues) if issues else '-'
        })
    
    return result

def scan_naked_options(symbol, df, current_price, weekly_expiry):
    """
    Scan for naked call/put with WEEKLY expiry (2-10 DTE)
    For very short-term directional trades (1-3 days)
    """
    if weekly_expiry is None:
        return None
    
    days_to_expiry = (weekly_expiry - datetime.now().date()).days
    
    # Naked options need short DTE (weekly)
    if days_to_expiry > 10 or days_to_expiry < 2:
        return None
    
    trend, vol_regime, atr_pct = identify_regime(df)
    
    if trend == "SIDEWAYS" or vol_regime == "LOW":
        return None
    
    results = []
    
    rsi = calculate_rsi(df)
    current_rsi = rsi.iloc[-1]
    
    atr = calculate_atr(df).iloc[-1]
    
    options = get_option_chain(symbol, weekly_expiry)
    if not options:
        return None
    
    if current_rsi > 65 and trend in ["DOWNTREND", "SIDEWAYS"]:
        otm_call_strike = get_atm_strike(current_price + atr)
        
        otm_ce = [opt for opt in options if opt['strike'] == otm_call_strike and opt['instrument_type'] == 'CE']
        
        if otm_ce:
            ce_symbol = otm_ce[0]['tradingsymbol']
            
            time.sleep(API_DELAY)
            quotes = get_option_quotes([ce_symbol])
            
            if f"NFO:{ce_symbol}" in quotes:
                ce_ltp = quotes[f"NFO:{ce_symbol}"]["last_price"]
                
                if ce_ltp > 0:
                    ce_premium_pct = calculate_premium_pct(otm_call_strike, ce_ltp)
                    
                    min_premium = 0.5 if days_to_expiry <= 5 else 1.0
                    
                    if ce_premium_pct >= min_premium:
                        time.sleep(API_DELAY)
                        ce_history = get_historical_option_prices(symbol, otm_call_strike, 'CE', weekly_expiry, 20)
                        
                        quality = "UNKNOWN"
                        ce_vol = None
                        ce_percentile = None
                        
                        if ce_history is not None and len(ce_history) >= 3:
                            ce_vol = np.std(ce_history) / np.mean(ce_history) if np.mean(ce_history) > 0 else 999
                            ce_percentile = percentileofscore(ce_history, ce_ltp)
                            quality = "GOOD" if ce_vol < 0.7 and 20 < ce_percentile < 80 else "ACCEPTABLE"
                        
                        base_score = ce_premium_pct * 10 + (current_rsi - 65) * 1.5
                        
                        if quality == "GOOD":
                            base_score += 10
                        
                        results.append({
                            'Symbol': symbol,
                            'Strategy': 'SHORT_CALL',
                            'Hold': f'{days_to_expiry}d',
                            'Price': round(current_price, 2),
                            'Strike': otm_call_strike,
                            'Option': ce_symbol,
                            'Prem': round(ce_ltp, 2),
                            'Prem_%': round(ce_premium_pct, 2),
                            'DTE': days_to_expiry,
                            'Trend': trend,
                            'RSI': round(current_rsi, 1),
                            'Vol': vol_regime,
                            'ATR%': round(atr_pct, 2),
                            'Reason': 'Overbought',
                            'Quality': quality,
                            'Opt_Vol%': round(ce_vol * 100, 1) if ce_vol and ce_vol < 10 else 'N/A',
                            'Entry_%ile': round(ce_percentile, 1) if ce_percentile else 'N/A',
                            'Score': round(base_score, 1)
                        })
    
    if current_rsi < 35 and trend in ["UPTREND", "SIDEWAYS"]:
        otm_put_strike = get_atm_strike(current_price - atr)
        
        otm_pe = [opt for opt in options if opt['strike'] == otm_put_strike and opt['instrument_type'] == 'PE']
        
        if otm_pe:
            pe_symbol = otm_pe[0]['tradingsymbol']
            
            time.sleep(API_DELAY)
            quotes = get_option_quotes([pe_symbol])
            
            if f"NFO:{pe_symbol}" in quotes:
                pe_ltp = quotes[f"NFO:{pe_symbol}"]["last_price"]
                
                if pe_ltp > 0:
                    pe_premium_pct = calculate_premium_pct(otm_put_strike, pe_ltp)
                    
                    min_premium = 0.5 if days_to_expiry <= 5 else 1.0
                    
                    if pe_premium_pct >= min_premium:
                        time.sleep(API_DELAY)
                        pe_history = get_historical_option_prices(symbol, otm_put_strike, 'PE', weekly_expiry, 20)
                        
                        quality = "UNKNOWN"
                        pe_vol = None
                        pe_percentile = None
                        
                        if pe_history is not None and len(pe_history) >= 3:
                            pe_vol = np.std(pe_history) / np.mean(pe_history) if np.mean(pe_history) > 0 else 999
                            pe_percentile = percentileofscore(pe_history, pe_ltp)
                            quality = "GOOD" if pe_vol < 0.7 and 20 < pe_percentile < 80 else "ACCEPTABLE"
                        
                        base_score = pe_premium_pct * 10 + (35 - current_rsi) * 1.5
                        
                        if quality == "GOOD":
                            base_score += 10
                        
                        results.append({
                            'Symbol': symbol,
                            'Strategy': 'SHORT_PUT',
                            'Hold': f'{days_to_expiry}d',
                            'Price': round(current_price, 2),
                            'Strike': otm_put_strike,
                            'Option': pe_symbol,
                            'Prem': round(pe_ltp, 2),
                            'Prem_%': round(pe_premium_pct, 2),
                            'DTE': days_to_expiry,
                            'Trend': trend,
                            'RSI': round(current_rsi, 1),
                            'Vol': vol_regime,
                            'ATR%': round(atr_pct, 2),
                            'Reason': 'Oversold',
                            'Quality': quality,
                            'Opt_Vol%': round(pe_vol * 100, 1) if pe_vol and pe_vol < 10 else 'N/A',
                            'Entry_%ile': round(pe_percentile, 1) if pe_percentile else 'N/A',
                            'Score': round(base_score, 1)
                        })
    
    return results

def run_scanner():
    all_opportunities = {
        'straddles': [],
        'strangles': [],
        'naked_options': []
    }
    
    print("\n" + "=" * 100)
    print("PREMIUM SELLING SCANNER - FIXED EXPIRY SELECTION")
    print("=" * 100)
    
    if not initialize_instrument_cache():
        print("❌ Failed to initialize instrument cache. Exiting.")
        return
    
    print("\n" + "=" * 100)
    print(f"SCANNING {len(symbols)} SYMBOLS")
    print("=" * 100)
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Min data requirement: {MIN_DATA_DAYS} trading days")
    print("\nEXPIRY LOGIC (FIXED):")
    print("  • Straddles: Weekly expiry (2-10 DTE)")
    print("  • Strangles: Current month monthly (14-30 DTE) ← FIXED!")
    print("  • Naked Options: Weekly expiry (2-10 DTE)")
    print("-" * 100)
    
    success_count = 0
    fail_count = 0
    
    for idx, symbol in enumerate(symbols):
        try:
            print(f"[{idx+1}/{len(symbols)}] {symbol}...", end=' ', flush=True)
            
            instrument_token = get_instrument_token(symbol)
            if not instrument_token:
                print("❌ No token")
                fail_count += 1
                continue
            
            time.sleep(API_DELAY)
            df = get_historical_data(instrument_token, LOOKBACK_DAYS)
            
            if df is None or len(df) < MIN_DATA_DAYS:
                print(f"❌ Data: {len(df) if df is not None else 0}d")
                fail_count += 1
                continue
            
            current_price = df['close'].iloc[-1]
            
            # Get BOTH weekly and monthly expiries
            weekly_expiry, monthly_expiry = get_optimal_expiries(symbol)
            
            if weekly_expiry is None and monthly_expiry is None:
                print("❌ No expiry")
                fail_count += 1
                continue
            
            success_count += 1
            found_any = False
            
            # SHORT STRADDLE: Use weekly (2-10 DTE)
            if weekly_expiry:
                straddle = scan_short_straddle(symbol, df, current_price, weekly_expiry)
                if straddle:
                    all_opportunities['straddles'].append(straddle)
                    print(f"✅ Straddle[{straddle['Quality']}|{straddle['DTE']}d]", end=' ', flush=True)
                    found_any = True
            
            # SHORT STRANGLE: Use monthly (14-30 DTE) ← KEY FIX!
            if monthly_expiry:
                strangle = scan_short_strangle(symbol, df, current_price, monthly_expiry)
                if strangle:
                    all_opportunities['strangles'].append(strangle)
                    print(f"✅ Strangle[{strangle['Quality']}|{strangle['DTE']}d]", end=' ', flush=True)
                    found_any = True
            
            # NAKED OPTIONS: Use weekly (2-10 DTE)
            if weekly_expiry:
                naked = scan_naked_options(symbol, df, current_price, weekly_expiry)
                if naked:
                    all_opportunities['naked_options'].extend(naked)
                    print(f"✅ Naked({len(naked)})", end=' ', flush=True)
                    found_any = True
            
            if not found_any:
                print("⚪", end='', flush=True)
            
            print()
            
        except Exception as e:
            print(f"❌ {str(e)[:40]}")
            fail_count += 1
            continue
    
    print("\n" + "=" * 100)
    print(f"SCAN COMPLETE - Success: {success_count}/{len(symbols)}, Failed: {fail_count}")
    print("=" * 100)
    
    for strategy_name, opportunities in [
        ('SHORT STRADDLE (Weekly Expiry)', all_opportunities['straddles']),
        ('SHORT STRANGLE (Monthly Expiry - FIXED!)', all_opportunities['strangles']),
        ('NAKED OPTIONS (Weekly Expiry)', all_opportunities['naked_options'])
    ]:
        print(f"\n{'='*100}")
        print(f"{strategy_name}: {len(opportunities)} opportunities")
        print(f"{'='*100}")
        
        if opportunities:
            df_result = pd.DataFrame(opportunities)
            df_result = df_result.sort_values('Score', ascending=False)
            
            pd.set_option('display.max_columns', None)
            pd.set_option('display.width', 200)
            pd.set_option('display.max_colwidth', 25)
            
            print(df_result.to_string(index=False))
            
            filename = strategy_name.split()[0].lower() + '_opportunities.csv'
            df_result.to_csv(filename, index=False)
            print(f"\n✅ Saved to {filename}")
            
            if 'Quality' in df_result.columns:
                print(f"\n📊 QUALITY BREAKDOWN:")
                for q, c in df_result['Quality'].value_counts().items():
                    print(f"   {q}: {c}")
            
            if 'DTE' in df_result.columns:
                print(f"\n⏱️  DTE RANGE:")
                print(f"   Min: {df_result['DTE'].min()} days")
                print(f"   Max: {df_result['DTE'].max()} days")
                print(f"   Avg: {df_result['DTE'].mean():.1f} days")
        else:
            print("No opportunities found.")
    
    print(f"\n{'='*100}")
    print("TOP OPPORTUNITIES")
    print(f"{'='*100}")
    
    for strat_type, opps in all_opportunities.items():
        if opps:
            top = pd.DataFrame(opps).nlargest(3, 'Score')
            print(f"\n🏆 {strat_type.upper()}:")
            for _, row in top.iterrows():
                dte = row.get('DTE', 'N/A')
                print(f"  {row['Symbol']}: Score={row['Score']} | Quality={row.get('Quality', 'N/A')} | DTE={dte}d")
    
    print(f"\n{'='*100}")
    print("KEY CHANGES IN THIS VERSION:")
    print(f"{'='*100}")
    print("✅ FIXED: Strangles now use current month expiry (14-30 DTE)")
    print("✅ FIXED: Straddles use weekly expiry (2-10 DTE)")
    print("✅ FIXED: Actual DTE matches hold period description")
    print("✅ Strangles are TRUE 2-4 week trades now (not 8 weeks!)")
    print(f"\n{'='*100}")
    print(f"Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*100}")

if __name__ == "__main__":
    run_scanner()