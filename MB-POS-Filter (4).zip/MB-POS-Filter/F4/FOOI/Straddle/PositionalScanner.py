"""
Positional Options Scanner - 2-3 Day Holds
Supports multiple strategies: Straddle, Strangle, Directional, Spreads
Optimized for end-of-day scanning and overnight positions
"""

import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
import pandas as pd
import numpy as np
from kiteconnect import KiteConnect

# ==================== HELPER FUNCTIONS ====================

def get_futures_oi_buildup(kite: KiteConnect, symbol: str, instrument_cache: dict, days: int = 5) -> Tuple[float, str]:
    """
    Analyze futures OI buildup over last N days
    
    NOTE: Kite API does NOT provide historical OI in historical_data()
    Using manual overrides for known explosive stocks + volume proxy for others
    
    Long-term solution: Use daily_oi_collector.py to build historical database
    
    Args:
        kite: KiteConnect instance
        symbol: Underlying symbol
        instrument_cache: Cache of instruments
        days: Number of days to analyze
    
    Returns:
        (oi_change_pct, signal_strength)
    """
    
    # Real OI data is now available via oi=True parameter!
    # No manual overrides needed anymore ✅
    
    # For other symbols, use real historical OI data
    try:
        # Find current month futures
        futures = [
            (sym, info) for sym, info in instrument_cache.items()
            if info.get('underlying') == symbol 
            and info.get('instrument_type') == 'FUT'
            and info.get('expiry')  # Current month
        ]
        
        if not futures:
            return 0.0, 'NONE'
        
        # Get nearest expiry (current month)
        futures.sort(key=lambda x: x[1]['expiry'])
        fut_symbol, fut_info = futures[0]
        
        # Get historical data for last N+2 days (extra for safety)
        to_date = datetime.now()
        from_date = to_date - timedelta(days=days+2)
        
        try:
            hist_data = kite.historical_data(
                fut_info['instrument_token'],
                from_date,
                to_date,
                'day',
                oi=True  # CRITICAL: Request OI data!
            )
            
            if not hist_data or len(hist_data) < 2:
                return 0.0, 'NONE'
            
            # Extract OI data (NOW with oi=True parameter!)
            oi_data = [(d['date'], d.get('oi', 0)) for d in hist_data if 'oi' in d]
            
            if len(oi_data) < 2:
                logging.debug(f"{symbol}: Insufficient OI data")
                return 0.0, 'NONE'
            
            # Get most recent OI vs N days ago
            latest_oi = oi_data[-1][1]
            
            # Try to get OI from N days ago
            if len(oi_data) >= days:
                old_oi = oi_data[-days][1]
            else:
                old_oi = oi_data[0][1]
            
            if old_oi == 0:
                return 0.0, 'NONE'
            
            # Calculate TRUE OI change percentage
            oi_change_pct = ((latest_oi - old_oi) / old_oi) * 100
            
            logging.info(f"{symbol} FUT OI: {old_oi:,.0f} → {latest_oi:,.0f} ({oi_change_pct:+.1f}%)")
            
            # Classify signal strength (ADJUSTED TO REALITY)
            # Based on actual Kite data: Most stocks show 10-30% changes over 5 days
            if oi_change_pct >= 40:  # Very rare - truly explosive
                signal_strength = 'EXPLOSIVE'
                logging.info(f"{symbol}: 🚀🚀🚀 EXPLOSIVE OI buildup!")
            elif oi_change_pct >= 25:  # Strong buildup (like TVSMOTOR)
                signal_strength = 'STRONG'
                logging.info(f"{symbol}: 💪 STRONG OI buildup!")
            elif oi_change_pct >= 15:  # Moderate buildup
                signal_strength = 'MODERATE'
            elif oi_change_pct >= 5:  # Weak but positive
                signal_strength = 'WEAK'
            else:
                signal_strength = 'NONE'
            
            return oi_change_pct, signal_strength
            
        except Exception as e:
            logging.debug(f"Could not get historical data for {fut_symbol}: {e}")
            return 0.0, 'NONE'
    
    except Exception as e:
        logging.debug(f"Error in futures OI analysis for {symbol}: {e}")
        return 0.0, 'NONE'

# ==================== CONFIGURATION ====================

class PositionalConfig:
    """Configuration for positional trading (2-3 day holds)"""
    
    # API Credentials
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "IIyA1VyxcQxaiRlmlVbMaabOb27Kzi12"
    
    # File paths
    UNIVERSE_CSV = "data/FNOStock.csv"
    OUTPUT_DIR = "positional_outputs"
    
    # Time horizons (POSITIONAL - different from intraday)
    DAILY_BARS_LOOKBACK = 10              # Look at last 10 days
    HOURLY_BARS_LOOKBACK = 20             # Last 20 hours (4 hours data for 5 days)
    WEEKLY_BARS_LOOKBACK = 12             # Last 12 weeks for IV context
    
    # Option selection criteria
    MIN_DAYS_TO_EXPIRY = 5                # Need at least 5 days (allow weekly options)
    MAX_DAYS_TO_EXPIRY = 35               # Up to 35 days (covers Dec 30 from Nov 28)
    PREFERRED_DAYS_TO_EXPIRY = (5, 35)    # Sweet spot: 5-35 days
    
    # Multi-day thresholds (BIGGER moves expected)
    THRESH_DAILY_TREND_DAYS = 3           # Trending for 3+ days
    THRESH_DAILY_MOVE_PCT = 0.015         # 1.5% daily move
    THRESH_MULTI_DAY_MOVE_PCT = 0.04      # 4% move over 3-5 days
    THRESH_DAILY_OI_BUILD_PCT = 0.08      # 8% OI build in 1 day
    
    # IV (Implied Volatility) analysis
    IV_RANK_THRESHOLD_LOW = 30            # Below 30 = low IV (good for buying)
    IV_RANK_THRESHOLD_HIGH = 70           # Above 70 = high IV (good for selling)
    IV_PERCENTILE_LOOKBACK = 52           # 52 weeks for IV rank calculation
    
    # Strategy-specific thresholds
    
    # STRADDLE/STRANGLE (Non-directional)
    STRADDLE_MIN_IV_RANK = 40             # Need some IV for non-directional
    STRADDLE_MAX_DAYS_OUT = 30            # Wider range for straddles (was 15)
    STRADDLE_DAILY_MOVE_THRESHOLD = 0.02  # 2% daily volatility
    
    # DIRECTIONAL (Call/Put buying)
    DIRECTIONAL_MIN_TREND_STRENGTH = 0.6  # 0-1 scale, 0.6 = moderate trend
    DIRECTIONAL_MIN_IV_RANK = 20          # Lower IV better for buying
    DIRECTIONAL_MAX_IV_RANK = 60          # Don't buy in very high IV
    
    # CREDIT SPREADS (Selling premium)
    CREDIT_SPREAD_MIN_IV_RANK = 60        # High IV good for selling
    CREDIT_SPREAD_WIDTH_PERCENT = 0.05    # 5% wide spreads
    CREDIT_SPREAD_TARGET_DELTA = 0.30     # Sell 30 delta options
    
    # IRON CONDOR (Range-bound)
    IRON_CONDOR_MIN_IV_RANK = 50          # Need elevated IV
    IRON_CONDOR_RANGE_DAYS = 5            # Check 5-day trading range
    IRON_CONDOR_RANGE_THRESHOLD = 0.03    # 3% range = good for condor
    
    # Risk management
    MAX_LOSS_PERCENT = 0.30               # 30% max loss (trailing stop)
    TARGET_PROFIT_PERCENT = 0.50          # 50% target profit
    POSITION_SIZE_PERCENT = 0.05          # 5% of portfolio per trade
    
    # API settings
    API_SLEEP_SECONDS = 0.3
    BATCH_SIZE = 10
    
    # Market hours
    MARKET_OPEN_HOUR = 9
    MARKET_OPEN_MINUTE = 15
    MARKET_CLOSE_HOUR = 15
    MARKET_CLOSE_MINUTE = 30
    
    # Logging
    LOG_LEVEL = logging.INFO  # Back to INFO level


# ==================== LOGGING SETUP ====================

def setup_logging():
    """Configure logging"""
    logging.basicConfig(
        level=PositionalConfig.LOG_LEVEL,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f'positional_scanner_{datetime.now().strftime("%Y%m%d")}.log'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

logger = setup_logging()


# ==================== UTILITY FUNCTIONS ====================

def load_universe(path: str) -> List[str]:
    """Load stock symbols from CSV"""
    try:
        df = pd.read_csv(path)
        if 'Symbol' not in df.columns:
            raise ValueError("CSV must have 'Symbol' column")
        symbols = df['Symbol'].astype(str).str.strip().unique().tolist()
        logger.info(f"Loaded {len(symbols)} symbols from {path}")
        return symbols
    except Exception as e:
        logger.error(f"Failed to load universe: {e}")
        raise


def calculate_iv_rank(current_iv: float, iv_history: List[float]) -> float:
    """
    Calculate IV Rank (0-100)
    Shows where current IV stands relative to 52-week range
    
    IV Rank = (Current IV - 52w Low) / (52w High - 52w Low) * 100
    
    Low IV Rank (0-30): Good for BUYING options
    High IV Rank (70-100): Good for SELLING options
    """
    if not iv_history or len(iv_history) < 10:
        return 50.0  # Default to middle if insufficient data
    
    iv_min = min(iv_history)
    iv_max = max(iv_history)
    
    if iv_max == iv_min:
        return 50.0
    
    iv_rank = ((current_iv - iv_min) / (iv_max - iv_min)) * 100
    return max(0, min(100, iv_rank))


def calculate_trend_strength(prices: List[float]) -> Tuple[float, str]:
    """
    Calculate trend strength using linear regression
    Returns: (strength 0-1, direction 'UP'/'DOWN'/'SIDEWAYS')
    
    Strength:
    0.0-0.3: Weak/Sideways
    0.3-0.6: Moderate trend
    0.6-1.0: Strong trend
    """
    if len(prices) < 5:
        return 0.0, 'SIDEWAYS'
    
    # Linear regression
    x = np.arange(len(prices))
    y = np.array(prices)
    
    # Remove NaN
    mask = ~np.isnan(y)
    x = x[mask]
    y = y[mask]
    
    if len(x) < 3:
        return 0.0, 'SIDEWAYS'
    
    # Fit line
    z = np.polyfit(x, y, 1)
    slope = z[0]
    
    # R-squared for trend strength
    y_pred = np.polyval(z, x)
    ss_res = np.sum((y - y_pred) ** 2)
    ss_tot = np.sum((y - np.mean(y)) ** 2)
    
    if ss_tot == 0:
        r_squared = 0
    else:
        r_squared = 1 - (ss_res / ss_tot)
    
    # Determine direction
    pct_change = (prices[-1] - prices[0]) / prices[0]
    
    if abs(pct_change) < 0.015:  # Less than 1.5% = sideways
        direction = 'SIDEWAYS'
        strength = 0.0
    elif pct_change > 0:
        direction = 'UP'
        strength = r_squared
    else:
        direction = 'DOWN'
        strength = r_squared
    
    return float(strength), direction


def calculate_atr_percent(df_ohlc: pd.DataFrame, period: int = 14) -> float:
    """
    Calculate Average True Range as percentage of price
    Measures volatility - higher ATR = more volatile
    """
    if len(df_ohlc) < period:
        return 0.0
    
    high = df_ohlc['high'].values
    low = df_ohlc['low'].values
    close = df_ohlc['close'].values
    
    tr_list = []
    for i in range(1, len(df_ohlc)):
        tr = max(
            high[i] - low[i],
            abs(high[i] - close[i-1]),
            abs(low[i] - close[i-1])
        )
        tr_list.append(tr)
    
    atr = np.mean(tr_list[-period:])
    atr_pct = (atr / close[-1]) * 100
    
    return float(atr_pct)


# ==================== MAIN POSITIONAL SCANNER ====================

class PositionalScanner:
    """
    Multi-strategy positional scanner for 2-3 day holds
    Supports: Straddle, Strangle, Long Call/Put, Credit Spreads, Iron Condor
    """
    
    def __init__(self, api_key: str, access_token: str):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Caches
        self.instrument_cache: Dict = {}
        self.token_to_symbol: Dict = {}
        self.equity_tokens: Dict = {}
        
        # Historical IV tracking
        self.iv_history: Dict[str, List[float]] = defaultdict(list)
        
        # Initialize
        self._load_instruments()
        logger.info("PositionalScanner initialized successfully")
        logger.info(f"Mode: 2-3 day holds, Days to expiry range: {PositionalConfig.MIN_DAYS_TO_EXPIRY}-{PositionalConfig.MAX_DAYS_TO_EXPIRY}")
    
    def _load_instruments(self):
        """Load NSE (equities) and NFO (options) instruments"""
        logger.info("Loading instrument master...")
        try:
            # Load both NSE and NFO
            nse_instruments = self.kite.instruments("NSE")
            nfo_instruments = self.kite.instruments("NFO")
            
            # Process NSE instruments
            for inst in nse_instruments:
                symbol = inst.get('tradingsymbol')
                token = inst.get('instrument_token')
                
                if inst.get('instrument_type') == 'EQ':
                    self.equity_tokens[symbol] = token
                
                self.instrument_cache[symbol] = {
                    'token': token,
                    'exchange': inst.get('exchange'),
                    'instrument_type': inst.get('instrument_type'),
                    'strike': inst.get('strike'),
                    'expiry': inst.get('expiry'),
                    'lot_size': inst.get('lot_size', 0),
                    'name': inst.get('name', '')
                }
                
                self.token_to_symbol[token] = symbol
            
            # Process NFO instruments
            for inst in nfo_instruments:
                symbol = inst.get('tradingsymbol')
                token = inst.get('instrument_token')
                
                self.instrument_cache[symbol] = {
                    'token': token,
                    'exchange': inst.get('exchange'),
                    'instrument_type': inst.get('instrument_type'),
                    'strike': inst.get('strike'),
                    'expiry': inst.get('expiry'),
                    'lot_size': inst.get('lot_size', 0),
                    'name': inst.get('name', '')
                }
                
                self.token_to_symbol[token] = symbol
            
            logger.info(f"Loaded {len(self.instrument_cache)} instruments")
            
        except Exception as e:
            logger.error(f"Failed to load instruments: {e}")
            raise
    
    def _fetch_historical_data(self, instrument_token, from_dt: datetime, 
                               to_dt: datetime, interval: str) -> pd.DataFrame:
        """Fetch historical OHLC data"""
        try:
            data = self.kite.historical_data(instrument_token, from_dt, to_dt, interval)
            df = pd.DataFrame(data)
            
            if not df.empty:
                if 'date' in df.columns:
                    df['datetime'] = pd.to_datetime(df['date'])
                else:
                    df['datetime'] = pd.to_datetime(df['datetime'])
            
            return df
            
        except Exception as e:
            logger.error(f"Historical data fetch failed for {instrument_token}: {e}")
            return pd.DataFrame()
    
    def _find_positional_options(self, underlying_symbol: str, spot_price: float, 
                                 days_to_expiry: Tuple[int, int]) -> Dict:
        """
        Find suitable options for positional trading
        Returns dict with ATM, ITM, OTM strikes for both CE and PE
        """
        # Filter options for this underlying from NFO
        options = []
        
        # Debug: Count total NFO options AND show sample symbols
        nfo_samples = []
        total_nfo = 0
        for symbol, data in self.instrument_cache.items():
            if data['exchange'] == 'NFO' and data['instrument_type'] in ['CE', 'PE']:
                total_nfo += 1
                if total_nfo <= 10:  # Collect first 10 samples
                    nfo_samples.append(f"{symbol} (name: {data.get('name', 'N/A')}, strike: {data.get('strike')})")
        
        logger.debug(f"Total NFO options available: {total_nfo}")
        logger.debug(f"Sample NFO symbols: {nfo_samples[:5]}")
        
        # Debug: Show what we're looking for
        logger.debug(f"Looking for options matching: '{underlying_symbol}'")
        
        # Try to find ANY options matching this underlying
        matching_count = 0
        for symbol, data in self.instrument_cache.items():
            if (data['exchange'] == 'NFO' and 
                data['instrument_type'] in ['CE', 'PE'] and
                data['strike'] is not None):
                
                # Match by symbol prefix (more reliable than 'name' field)
                if symbol.startswith(underlying_symbol):
                    matching_count += 1
                    if matching_count <= 3:
                        logger.debug(f"  Found matching option: {symbol}, expiry={data.get('expiry')}")
                    
                    # Check expiry
                    expiry = data.get('expiry')
                    if expiry:
                        days_left = (expiry - datetime.now().date()).days
                        
                        if matching_count <= 3:
                            logger.debug(f"    Days to expiry: {days_left}")
                        
                        # Filter by days to expiry
                        if days_to_expiry[0] <= days_left <= days_to_expiry[1]:
                            options.append({
                                'symbol': symbol,
                                'strike': data['strike'],
                                'expiry': expiry,
                                'type': data['instrument_type'],
                                'days_to_expiry': days_left
                            })
        
        logger.debug(f"{underlying_symbol}: Total matching symbols: {matching_count}, In expiry range: {len(options)}")
        
        if not options:
            logger.warning(f"{underlying_symbol}: No options found with {days_to_expiry[0]}-{days_to_expiry[1]} days expiry (matched {matching_count} total)")
            return {}
        
        logger.info(f"{underlying_symbol}: Found {len(options)} options in expiry range")
        
        # Convert to DataFrame
        options_df = pd.DataFrame(options)
        
        # Find nearest expiry within range
        nearest_expiry = options_df['expiry'].min()
        nearest_options = options_df[options_df['expiry'] == nearest_expiry]
        
        logger.debug(f"{underlying_symbol}: Using expiry {nearest_expiry}, {len(nearest_options)} options available")
        
        # Find strikes relative to spot
        strikes = sorted(nearest_options['strike'].unique())
        atm_strike = min(strikes, key=lambda x: abs(x - spot_price))
        
        # Get ATM, ITM, OTM strikes
        atm_idx = strikes.index(atm_strike)
        
        result = {
            'expiry': nearest_expiry,
            'days_to_expiry': nearest_options['days_to_expiry'].iloc[0],
            'atm_strike': atm_strike
        }
        
        # CE strikes
        ce_options = nearest_options[nearest_options['type'] == 'CE']
        ce_atm = ce_options[ce_options['strike'] == atm_strike]['symbol'].values
        result['ce_atm'] = ce_atm[0] if len(ce_atm) > 0 else None
        
        # CE OTM (above spot)
        if atm_idx < len(strikes) - 1:
            ce_otm_strike = strikes[atm_idx + 1]
            ce_otm = ce_options[ce_options['strike'] == ce_otm_strike]['symbol'].values
            result['ce_otm'] = ce_otm[0] if len(ce_otm) > 0 else None
            result['ce_otm_strike'] = ce_otm_strike
        
        # CE ITM (below spot - rarely used)
        if atm_idx > 0:
            ce_itm_strike = strikes[atm_idx - 1]
            ce_itm = ce_options[ce_options['strike'] == ce_itm_strike]['symbol'].values
            result['ce_itm'] = ce_itm[0] if len(ce_itm) > 0 else None
            result['ce_itm_strike'] = ce_itm_strike
        
        # PE strikes
        pe_options = nearest_options[nearest_options['type'] == 'PE']
        pe_atm = pe_options[pe_options['strike'] == atm_strike]['symbol'].values
        result['pe_atm'] = pe_atm[0] if len(pe_atm) > 0 else None
        
        # PE OTM (below spot)
        if atm_idx > 0:
            pe_otm_strike = strikes[atm_idx - 1]
            pe_otm = pe_options[pe_options['strike'] == pe_otm_strike]['symbol'].values
            result['pe_otm'] = pe_otm[0] if len(pe_otm) > 0 else None
            result['pe_otm_strike'] = pe_otm_strike
        
        # PE ITM (above spot - rarely used)
        if atm_idx < len(strikes) - 1:
            pe_itm_strike = strikes[atm_idx + 1]
            pe_itm = pe_options[pe_options['strike'] == pe_itm_strike]['symbol'].values
            result['pe_itm'] = pe_itm[0] if len(pe_itm) > 0 else None
            result['pe_itm_strike'] = pe_itm_strike
        
        logger.info(f"{underlying_symbol}: ATM Strike={atm_strike}, Days={result['days_to_expiry']}, CE={result.get('ce_atm')}, PE={result.get('pe_atm')}")
        
        return result
    
    def _calculate_implied_volatility_proxy(self, option_price: float, spot_price: float,
                                           strike: float, days_to_expiry: int,
                                           option_type: str) -> float:
        """
        Rough IV calculation without full Black-Scholes
        Good enough for IV rank calculation
        
        Uses premium as % of spot as proxy for IV
        """
        if days_to_expiry <= 0 or spot_price <= 0:
            return 0.0
        
        # Intrinsic value
        if option_type == 'CE':
            intrinsic = max(0, spot_price - strike)
        else:  # PE
            intrinsic = max(0, strike - spot_price)
        
        # Time value
        time_value = max(0, option_price - intrinsic)
        
        # Annualized volatility proxy
        # IV ~ (Time Value / Spot) * sqrt(365 / Days)
        iv_proxy = (time_value / spot_price) * np.sqrt(365 / days_to_expiry) * 100
        
        return float(iv_proxy)
    
    def _evaluate_straddle_setup(self, symbol: str, spot_price: float, 
                                 df_daily: pd.DataFrame, options_data: Dict) -> Optional[Dict]:
        """
        Evaluate STRADDLE/STRANGLE setup for 2-3 day hold
        
        Good when:
        - Expecting big move but don't know direction
        - Low-moderate IV (room to expand)
        - Recent consolidation before breakout
        - 10-15 days to expiry (sweet spot)
        - PREMIUM EXPANDING (above VWAP)
        """
        if not options_data or 'ce_atm' not in options_data:
            return None
        
        # Check days to expiry
        days_to_expiry = options_data.get('days_to_expiry', 0)
        if days_to_expiry > PositionalConfig.STRADDLE_MAX_DAYS_OUT:
            return None
        
        # Get ATM options
        ce_symbol = options_data['ce_atm']
        pe_symbol = options_data['pe_atm']
        
        if not ce_symbol or not pe_symbol:
            return None
        
        # Get option prices and VWAP
        ce_key = f"NFO:{ce_symbol}"
        pe_key = f"NFO:{pe_symbol}"
        
        try:
            quotes = self.kite.quote([ce_key, pe_key])
            ce_ltp = quotes[ce_key]['last_price']
            pe_ltp = quotes[pe_key]['last_price']
            
            # Get option tokens for historical data
            ce_token = self.instrument_cache.get(ce_symbol, {}).get('token')
            pe_token = self.instrument_cache.get(pe_symbol, {}).get('token')
            
            if not ce_token or not pe_token:
                logger.warning(f"{symbol}: Could not find option tokens for VWAP - REJECTING setup")
                return None
            
            # Fetch TODAY's data from market open for accurate VWAP
            now = datetime.now()
            market_open_today = now.replace(hour=9, minute=15, second=0, microsecond=0)
            
            # If before market open, use yesterday
            if now.hour < 9 or (now.hour == 9 and now.minute < 15):
                market_open_today = market_open_today - timedelta(days=1)
            
            df_ce = self._fetch_historical_data(ce_token, market_open_today, now, '5minute')
            df_pe = self._fetch_historical_data(pe_token, market_open_today, now, '5minute')
            
            if df_ce.empty or df_pe.empty or len(df_ce) < 10 or len(df_pe) < 10:
                logger.warning(f"{symbol}: Insufficient option history for straddle VWAP - REJECTING setup")
                logger.debug(f"{symbol}: CE data points: {len(df_ce) if not df_ce.empty else 0}, PE data points: {len(df_pe) if not df_pe.empty else 0}")
                # REJECT - VWAP validation is critical for straddles too
                return None
            
            # Calculate straddle VWAP from full day
            # Ensure both arrays have same length (handle data mismatches)
            min_len = min(len(df_ce), len(df_pe))
            df_ce_aligned = df_ce.iloc[:min_len].copy()
            df_pe_aligned = df_pe.iloc[:min_len].copy()
            
            df_ce_aligned['straddle_price'] = df_ce_aligned['close'] + df_pe_aligned['close'].values
            df_ce_aligned['straddle_vwap'] = (df_ce_aligned['straddle_price'] * df_ce_aligned['volume']).cumsum() / df_ce_aligned['volume'].cumsum()
            
            straddle_vwap = df_ce_aligned['straddle_vwap'].iloc[-1]
            straddle_ltp = ce_ltp + pe_ltp
            straddle_vs_vwap_pct = (straddle_ltp - straddle_vwap) / straddle_vwap
            
            logger.info(f"{symbol} STRADDLE: Rs.{straddle_ltp:.2f} vs VWAP Rs.{straddle_vwap:.2f} ({straddle_vs_vwap_pct*100:+.1f}%) [Full Day]")
                    
        except Exception as e:
            logger.error(f"{symbol}: Failed to get straddle data: {e}")
            return None
        
        straddle_cost = ce_ltp + pe_ltp
        
        # Calculate recent volatility (ATR)
        atr_pct = calculate_atr_percent(df_daily, period=5)
        
        # Calculate IV proxy
        iv_proxy = self._calculate_implied_volatility_proxy(
            straddle_cost / 2, spot_price, options_data['atm_strike'], 
            days_to_expiry, 'CE'
        )
        
        # Store for IV rank
        self.iv_history[symbol].append(iv_proxy)
        
        # Calculate IV rank
        iv_rank = calculate_iv_rank(iv_proxy, self.iv_history[symbol][-52:])
        
        # Check multi-day range
        if len(df_daily) >= 5:
            recent_high = df_daily['high'].tail(5).max()
            recent_low = df_daily['low'].tail(5).min()
            range_pct = (recent_high - recent_low) / recent_low
        else:
            range_pct = 0
        
        # STRADDLE SCORING (now includes premium validation)
        score = 0
        reasons = []
        
        # 1. Moderate volatility (ATR 2-5%)
        if 2.0 <= atr_pct <= 5.0:
            score += 1
            reasons.append(f"Good volatility (ATR {atr_pct:.1f}%)")
        
        # 2. IV not too high (room to expand)
        if iv_rank < 60:
            score += 1
            reasons.append(f"IV rank {iv_rank:.0f} (room to expand)")
        
        # 3. Recent consolidation (< 3% range)
        if range_pct < 0.03:
            score += 1
            reasons.append(f"Tight range {range_pct*100:.1f}% (breakout setup)")
        
        # 4. Good days to expiry
        if 10 <= days_to_expiry <= 15:
            score += 1
            reasons.append(f"Optimal expiry ({days_to_expiry} days)")
        
        # 5. Reasonable cost (< 5% of spot)
        cost_pct = (straddle_cost / spot_price) * 100
        if cost_pct < 5.0:
            score += 1
            reasons.append(f"Reasonable cost ({cost_pct:.1f}% of spot)")
        
        # 6. PREMIUM ABOVE VWAP (CRITICAL - from intraday scanner)
        if straddle_vs_vwap_pct > 0.03:  # More than 3% above VWAP
            score += 1
            reasons.append(f"Premium expanding ({straddle_vs_vwap_pct*100:+.1f}% vs VWAP) ✅")
        elif straddle_vs_vwap_pct < -0.05:  # More than 5% below VWAP
            score -= 2  # Major penalty - IV crush!
            reasons.append(f"⚠️ IV CRUSH WARNING: Premium {straddle_vs_vwap_pct*100:.1f}% below VWAP")
            logger.warning(f"{symbol} STRADDLE: IV CRUSH detected - premium below VWAP!")
        
        # 7. VOLUME CHECK (liquidity)
        try:
            # Check both CE and PE volume
            ce_vol = df_ce_option['volume'].iloc[-1] if not df_ce_option.empty else 0
            pe_vol = df_pe_option['volume'].iloc[-1] if not df_pe_option.empty else 0
            avg_ce_vol = df_ce_option['volume'].mean() if not df_ce_option.empty and len(df_ce_option) >= 5 else 0
            avg_pe_vol = df_pe_option['volume'].mean() if not df_pe_option.empty and len(df_pe_option) >= 5 else 0
            
            if ce_vol >= avg_ce_vol * 0.25 and pe_vol >= avg_pe_vol * 0.25 and avg_ce_vol > 50:
                score += 1
                reasons.append(f"Healthy volume (CE: {ce_vol:.0f}, PE: {pe_vol:.0f})")
        except:
            pass
        
        # Need at least 4/8 for signal (raised from 3/6)
        if score < 4:
            return None
        
        # Calculate breakevens and targets
        upper_be = options_data['atm_strike'] + straddle_cost
        lower_be = options_data['atm_strike'] - straddle_cost
        
        target_move = straddle_cost * 0.5  # Need 50% profit
        upper_target = options_data['atm_strike'] + target_move
        lower_target = options_data['atm_strike'] - target_move
        
        return {
            'strategy': 'STRADDLE',
            'score': score,
            'reasons': reasons,
            'ce_symbol': ce_symbol,
            'pe_symbol': pe_symbol,
            'ce_price': ce_ltp,
            'pe_price': pe_ltp,
            'total_cost': straddle_cost,
            'straddle_vwap': straddle_vwap,
            'premium_vs_vwap_pct': round(straddle_vs_vwap_pct * 100, 2),
            'cost_pct': cost_pct,
            'atm_strike': options_data['atm_strike'],
            'days_to_expiry': days_to_expiry,
            'iv_rank': iv_rank,
            'atr_pct': atr_pct,
            'upper_breakeven': upper_be,
            'lower_breakeven': lower_be,
            'upper_target': upper_target,
            'lower_target': lower_target,
            'hold_days': '2-3'
        }
    
    def _evaluate_directional_setup(self, symbol: str, spot_price: float,
                                    df_daily: pd.DataFrame, options_data: Dict) -> Optional[Dict]:
        """
        Evaluate DIRECTIONAL (Long Call/Put) setup
        
        Good when:
        - Clear trend (3+ days)
        - Low-moderate IV (cheap options)
        - Momentum continuing
        - Good R:R setup
        - PREMIUM ABOVE VWAP (IV building, not collapsing)
        """
        if not options_data or len(df_daily) < 5:
            return None
        
        # Calculate trend
        closes = df_daily['close'].tail(10).values.tolist()
        trend_strength, trend_direction = calculate_trend_strength(closes)
        
        # Need clear trend
        if trend_strength < PositionalConfig.DIRECTIONAL_MIN_TREND_STRENGTH:
            return None
        
        if trend_direction == 'SIDEWAYS':
            return None
        
        # Get appropriate option (ITM or ATM based on aggressiveness)
        if trend_direction == 'UP':
            # Bullish - buy Call
            option_symbol = options_data.get('ce_atm')  # ATM for balanced risk
            option_type = 'CALL'
            strike = options_data.get('atm_strike')
        else:
            # Bearish - buy Put
            option_symbol = options_data.get('pe_atm')
            option_type = 'PUT'
            strike = options_data.get('atm_strike')
        
        if not option_symbol or not strike:
            return None
        
        # Get option price and calculate VWAP (CRITICAL VALIDATION)
        option_key = f"NFO:{option_symbol}"
        
        try:
            quote = self.kite.quote([option_key])
            option_price = quote[option_key]['last_price']
            option_oi = quote[option_key].get('oi', 0)
            
            # Fetch option historical data for VWAP calculation
            # Use FULL DAY data for accurate VWAP (not just last 2 hours)
            option_token = self.instrument_cache.get(option_symbol, {}).get('token')
            if not option_token:
                logger.warning(f"{symbol}: Could not find token for {option_symbol}")
                return None
            
            # Get TODAY's data from market open for accurate VWAP
            now = datetime.now()
            market_open_today = now.replace(hour=9, minute=15, second=0, microsecond=0)
            
            # If before market open, use yesterday
            if now.hour < 9 or (now.hour == 9 and now.minute < 15):
                market_open_today = market_open_today - timedelta(days=1)
            
            df_option = self._fetch_historical_data(option_token, market_open_today, now, '5minute')
            
            if df_option.empty or len(df_option) < 10:
                logger.warning(f"{symbol}: Insufficient option history for VWAP calculation - REJECTING setup")
                logger.debug(f"{symbol}: Need 10+ data points, got {len(df_option) if not df_option.empty else 0}")
                # REJECT instead of continuing - VWAP validation is CRITICAL
                # Without it, we can't detect IV crush (like SUNPHARMA example)
                return None
            
            # Calculate option VWAP from full day
            df_option['vwap'] = (df_option['close'] * df_option['volume']).cumsum() / df_option['volume'].cumsum()
            option_vwap = df_option['vwap'].iloc[-1]
            premium_vs_vwap_pct = (option_price - option_vwap) / option_vwap
            
            logger.info(f"{symbol} {option_type}: Premium Rs.{option_price:.2f} vs VWAP Rs.{option_vwap:.2f} ({premium_vs_vwap_pct*100:+.1f}%) [Full Day]")
            
        except Exception as e:
            logger.error(f"{symbol}: Failed to get option data: {e}")
            return None
        
        days_to_expiry = options_data.get('days_to_expiry', 0)
        
        # Calculate IV
        iv_proxy = self._calculate_implied_volatility_proxy(
            option_price, spot_price, strike, days_to_expiry, 
            'CE' if option_type == 'CALL' else 'PE'
        )
        
        iv_rank = calculate_iv_rank(iv_proxy, self.iv_history[symbol][-52:])
        
        # DIRECTIONAL SCORING (now includes premium validation)
        score = 0
        reasons = []
        
        # 1. Strong trend
        if trend_strength >= 0.7:
            score += 2
            reasons.append(f"Strong {trend_direction} trend ({trend_strength:.2f})")
        elif trend_strength >= 0.5:
            score += 1
            reasons.append(f"Moderate {trend_direction} trend ({trend_strength:.2f})")
        
        # 2. Low IV (cheap options)
        if iv_rank < PositionalConfig.DIRECTIONAL_MAX_IV_RANK:
            score += 1
            reasons.append(f"Low IV rank {iv_rank:.0f} (cheap options)")
        
        # 3. Multi-day momentum
        recent_move = (closes[-1] - closes[-3]) / closes[-3]
        if abs(recent_move) > PositionalConfig.THRESH_MULTI_DAY_MOVE_PCT:
            score += 1
            reasons.append(f"Strong 3-day momentum ({recent_move*100:.1f}%)")
        
        # 4. Close near high/low (confirming momentum)
        latest_bar = df_daily.iloc[-1]
        close_range = (latest_bar['close'] - latest_bar['low']) / (latest_bar['high'] - latest_bar['low']) if latest_bar['high'] != latest_bar['low'] else 0.5
        
        if option_type == 'CALL' and close_range > 0.7:  # Close near high
            score += 1
            reasons.append(f"Close near high ({close_range*100:.0f}% of range)")
        elif option_type == 'PUT' and close_range < 0.3:  # Close near low
            score += 1
            reasons.append(f"Close near low ({close_range*100:.0f}% of range)")
        
        # 6. Good days to expiry
        if days_to_expiry >= PositionalConfig.MIN_DAYS_TO_EXPIRY:
            score += 1
            reasons.append(f"{days_to_expiry} days to expiry")
        
        # 7. PREMIUM ABOVE VWAP (CRITICAL - from intraday scanner)
        if premium_vs_vwap_pct > 0.02:  # More than 2% above VWAP
            score += 1
            reasons.append(f"Premium expanding ({premium_vs_vwap_pct*100:+.1f}% vs VWAP) ✅")
        elif premium_vs_vwap_pct < -0.05:  # More than 5% below VWAP
            score -= 2  # Major penalty - IV crush detected!
            reasons.append(f"⚠️ IV CRUSH WARNING: Premium {premium_vs_vwap_pct*100:.1f}% below VWAP")
            logger.warning(f"{symbol} {option_type}: IV CRUSH detected - premium below VWAP!")
        
        # 7. FUTURES OI BUILDUP (NEW - CRITICAL FOR DETECTING EXPLOSIVE SETUPS!)
        futures_oi_pct, futures_signal = get_futures_oi_buildup(
            self.kite, symbol, self.instrument_cache, days=5
        )
        
        if futures_signal == 'EXPLOSIVE':
            score += 3  # MASSIVE bonus for explosive OI buildup!
            reasons.append(f"🚀 EXPLOSIVE futures OI buildup ({futures_oi_pct:.0f}%+)!")
        elif futures_signal == 'STRONG':
            score += 2  # Strong bonus
            reasons.append(f"💪 Strong futures OI buildup ({futures_oi_pct:.0f}%)")
        elif futures_signal == 'MODERATE':
            score += 1  # Moderate bonus
            reasons.append(f"Futures OI building ({futures_oi_pct:.0f}%)")
        # WEAK or NONE: no bonus
        
        # 8. FUTURES BASIS (Premium/Discount expansion)
        try:
            # Get futures price
            fut_symbol = [sym for sym, info in self.instrument_cache.items() 
                         if info.get('underlying') == symbol 
                         and info.get('instrument_type') == 'FUT'][0]
            fut_key = f"NFO:{fut_symbol}"
            fut_quote = self.kite.quote([fut_key])
            fut_price = fut_quote[fut_key]['last_price']
            
            basis_pct = ((fut_price - spot_price) / spot_price) * 100
            
            # Get historical basis to check expansion
            # For now, simple check: positive basis = bullish, negative = bearish
            if option_type == 'CALL' and basis_pct > 0.3:  # Futures at premium
                score += 1
                reasons.append(f"Futures at premium ({basis_pct:.2f}%) - bullish")
            elif option_type == 'PUT' and basis_pct < -0.3:  # Futures at discount
                score += 1
                reasons.append(f"Futures at discount ({basis_pct:.2f}%) - bearish")
            elif option_type == 'CALL' and basis_pct < -0.5:  # Contradicts
                score -= 1
                reasons.append(f"⚠️ Futures discount ({basis_pct:.2f}%) contradicts call")
            elif option_type == 'PUT' and basis_pct > 0.5:  # Contradicts
                score -= 1
                reasons.append(f"⚠️ Futures premium ({basis_pct:.2f}%) contradicts put")
        except:
            pass  # Skip if futures data unavailable
        
        # 9. WRITER VS BUYER DETECTION (for CALL options only)
        writer_buyer_pattern = 'N/A'
        if option_type == 'CALL':
            dist_from_strike_pct = abs((spot_price - strike) / strike * 100)
            
            # CASE 1: Price stuck at strike = Writers creating resistance
            if dist_from_strike_pct < 0.3:  # Within 0.3% of strike
                score -= 2  # Penalty - bearish resistance
                reasons.append(f"⚠️ Price stuck at {strike} strike - Writer resistance (BEARISH)")
                writer_buyer_pattern = 'WRITER_RESISTANCE'
            
            # CASE 2: Price breaking above strike = Buyers adding (bullish)
            elif spot_price > strike * 1.01:  # Price 1%+ above strike
                score += 1  # Bonus - bullish breakout
                reasons.append(f"🚀 Price breaking above {strike} - Buyer breakout (BULLISH)")
                writer_buyer_pattern = 'BUYER_BREAKOUT'
            
            # CASE 3: Price well below strike = Normal buildup
            else:
                writer_buyer_pattern = 'NEUTRAL'
        
        # 10. ATM OI BEHAVIOR (check if ATM OI building against our position)
        try:
            # Get ATM strike OI for opposite side
            atm_strike = options_data.get('atm_strike')
            if option_type == 'CALL':
                # Check ATM Put OI (bearish signal against our call)
                opposite_symbol = options_data.get('pe_atm')
            else:
                # Check ATM Call OI (bullish signal against our put)
                opposite_symbol = options_data.get('ce_atm')
            
            if opposite_symbol:
                opp_key = f"NFO:{opposite_symbol}"
                opp_quote = self.kite.quote([opp_key])
                opp_oi = opp_quote[opp_key].get('oi', 0)
                
                # If ATM opposite side has massive OI (>50% higher than our side)
                if opp_oi > option_oi * 1.5:
                    score -= 1
                    reasons.append(f"⚠️ Heavy ATM {opposite_symbol.split()[-1]} OI against position")
        except:
            pass
        
        # 11. OPTION LIQUIDITY (Volume check)
        try:
            # Get average volume from historical data (if available)
            if not df_option.empty and len(df_option) >= 5:
                avg_volume = df_option['volume'].mean()
                latest_volume = df_option['volume'].iloc[-1]
                
                if latest_volume >= avg_volume * 0.25 and avg_volume > 100:  # At least 25% of avg
                    score += 1
                    reasons.append(f"Healthy volume ({latest_volume:.0f} vs avg {avg_volume:.0f})")
                elif latest_volume < avg_volume * 0.1:  # Very low
                    score -= 1
                    reasons.append(f"⚠️ Low liquidity ({latest_volume:.0f} vs avg {avg_volume:.0f})")
        except:
            pass
        
        # Need 6/15 for signal (raised from 4)
        # Max score now ~15 with all enhancements
        if score < 6:
            return None
        
        # Calculate target and stop
        if option_type == 'CALL':
            target_spot = strike + (option_price * 2)  # 100% profit on option
            stop_spot = spot_price * 0.97  # 3% stop on stock
        else:
            target_spot = strike - (option_price * 2)
            stop_spot = spot_price * 1.03
        
        return {
            'strategy': f'LONG {option_type}',
            'direction': trend_direction,
            'score': score,
            'reasons': reasons,
            'option_symbol': option_symbol,
            'option_type': option_type,
            'strike': strike,
            'option_price': option_price,
            'option_vwap': option_vwap,
            'premium_vs_vwap_pct': round(premium_vs_vwap_pct * 100, 2),
            'spot_price': spot_price,
            'days_to_expiry': days_to_expiry,
            'iv_rank': iv_rank,
            'trend_strength': trend_strength,
            'futures_oi_signal': futures_signal,  # NEW: EXPLOSIVE/STRONG/MODERATE/WEAK/NONE
            'futures_oi_pct': round(futures_oi_pct, 1),  # NEW: OI buildup %
            'writer_buyer_pattern': writer_buyer_pattern,  # NEW: WRITER_RESISTANCE/BUYER_BREAKOUT/NEUTRAL/N/A
            'target_spot': target_spot,
            'stop_spot': stop_spot,
            'expected_return_pct': 100,  # Target 100% on option
            'hold_days': '2-3',
            'oi': option_oi
        }
    
    def _evaluate_credit_spread_setup(self, symbol: str, spot_price: float,
                                     df_daily: pd.DataFrame, options_data: Dict) -> Optional[Dict]:
        """
        Evaluate CREDIT SPREAD setup (Bull Put / Bear Call Spread)
        
        Good when:
        - High IV (expensive options = good for selling)
        - Clear support/resistance
        - Trending or range-bound
        - Collect premium with defined risk
        """
        if not options_data or len(df_daily) < 5:
            return None
        
        # Get current IV rank
        days_to_expiry = options_data.get('days_to_expiry', 0)
        
        # Need high IV for credit spreads
        ce_atm = options_data.get('ce_atm')
        if not ce_atm:
            return None
        
        try:
            quote = self.kite.quote([f"NFO:{ce_atm}"])
            ce_price = quote[f"NFO:{ce_atm}"]['last_price']
        except:
            return None
        
        iv_proxy = self._calculate_implied_volatility_proxy(
            ce_price, spot_price, options_data['atm_strike'], 
            days_to_expiry, 'CE'
        )
        
        iv_rank = calculate_iv_rank(iv_proxy, self.iv_history[symbol][-52:])
        
        # Only set up credit spreads in high IV
        if iv_rank < PositionalConfig.CREDIT_SPREAD_MIN_IV_RANK:
            return None
        
        # Determine trend
        closes = df_daily['close'].tail(5).values.tolist()
        trend_strength, trend_direction = calculate_trend_strength(closes)
        
        # Setup appropriate spread
        if trend_direction == 'UP' or trend_direction == 'SIDEWAYS':
            # Bull Put Spread (bullish/neutral)
            # Sell Put OTM, Buy Put further OTM
            sell_strike_symbol = options_data.get('pe_otm')
            buy_strike = options_data.get('pe_otm_strike', 0) * 0.95  # 5% lower
            spread_type = 'BULL PUT SPREAD'
        else:
            # Bear Call Spread (bearish)
            # Sell Call OTM, Buy Call further OTM
            sell_strike_symbol = options_data.get('ce_otm')
            buy_strike = options_data.get('ce_otm_strike', 0) * 1.05  # 5% higher
            spread_type = 'BEAR CALL SPREAD'
        
        if not sell_strike_symbol:
            return None
        
        # This is a simplified example - full implementation would need:
        # - Find buy strike option
        # - Calculate net credit
        # - Calculate max profit/loss
        # - Check margin requirements
        
        return {
            'strategy': spread_type,
            'score': 3,  # Placeholder
            'reasons': [f'High IV rank {iv_rank:.0f}', 'Credit spread opportunity'],
            'sell_option': sell_strike_symbol,
            'buy_strike': buy_strike,
            'iv_rank': iv_rank,
            'days_to_expiry': days_to_expiry,
            'note': 'Credit spread - sell premium in high IV'
        }
    
    def scan_symbol(self, symbol: str) -> Optional[Dict]:
        """
        Scan single symbol for ALL positional strategies
        Returns best setup found
        """
        try:
            logger.info(f"Scanning {symbol} for positional setups...")
            
            # Check if symbol exists
            if symbol not in self.equity_tokens:
                logger.warning(f"Symbol {symbol} not found")
                return None
            
            # Get current spot price
            spot_key = f"NSE:{symbol}"
            spot_quote = self.kite.ltp(spot_key)
            spot_price = spot_quote[spot_key]['last_price']
            
            # Fetch daily data (last 10 days)
            spot_token = self.equity_tokens[symbol]
            now = datetime.now()
            from_dt = now - timedelta(days=PositionalConfig.DAILY_BARS_LOOKBACK)
            to_dt = now
            
            df_daily = self._fetch_historical_data(spot_token, from_dt, to_dt, 'day')
            
            if df_daily.empty or len(df_daily) < 5:
                logger.warning(f"Insufficient daily data for {symbol}")
                return None
            
            # Find suitable options (10-20 days expiry)
            options_data = self._find_positional_options(
                symbol, spot_price, 
                PositionalConfig.PREFERRED_DAYS_TO_EXPIRY
            )
            
            if not options_data:
                logger.warning(f"No suitable options found for {symbol}")
                return None
            
            # Evaluate all strategies
            strategies = []
            
            # 1. Straddle/Strangle
            straddle_setup = self._evaluate_straddle_setup(
                symbol, spot_price, df_daily, options_data
            )
            if straddle_setup:
                strategies.append(straddle_setup)
            
            # 2. Directional (Call/Put)
            directional_setup = self._evaluate_directional_setup(
                symbol, spot_price, df_daily, options_data
            )
            if directional_setup:
                strategies.append(directional_setup)
            
            # 3. Credit Spread
            credit_setup = self._evaluate_credit_spread_setup(
                symbol, spot_price, df_daily, options_data
            )
            if credit_setup:
                strategies.append(credit_setup)
            
            # Return best strategy (highest score)
            if not strategies:
                return None
            
            best_strategy = max(strategies, key=lambda x: x['score'])
            best_strategy['symbol'] = symbol
            best_strategy['spot_price'] = spot_price
            best_strategy['timestamp'] = now.isoformat()
            
            logger.info(f"{symbol}: {best_strategy['strategy']} - Score {best_strategy['score']}")
            
            return best_strategy
            
        except Exception as e:
            logger.error(f"Error scanning {symbol}: {e}", exc_info=True)
            return None
    
    def scan_universe(self, symbols: List[str]) -> pd.DataFrame:
        """Scan all symbols and return results"""
        results = []
        
        for i, symbol in enumerate(symbols, 1):
            logger.info(f"Processing {i}/{len(symbols)}: {symbol}")
            
            setup = self.scan_symbol(symbol)
            if setup:
                results.append(setup)
            
            time.sleep(PositionalConfig.API_SLEEP_SECONDS)
        
        df = pd.DataFrame(results)
        return df


# ==================== MAIN EXECUTION ====================

def main():
    """Main execution function"""
    
    logger.info("="*80)
    logger.info("POSITIONAL OPTIONS SCANNER - 2-3 Day Holds")
    logger.info("Strategies: Straddle, Long Call/Put, Credit Spreads")
    logger.info("="*80)
    
    # Load universe
    try:
        universe = load_universe(PositionalConfig.UNIVERSE_CSV)
    except Exception as e:
        logger.error(f"Failed to load universe: {e}")
        return
    
    # Initialize scanner
    logger.info("Initializing positional scanner...")
    scanner = PositionalScanner(PositionalConfig.API_KEY, PositionalConfig.ACCESS_TOKEN)
    
    # Run scan
    logger.info(f"Starting positional scan of {len(universe)} symbols...")
    start_time = datetime.now()
    
    results_df = scanner.scan_universe(universe)
    
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_file = f"positional_results_{timestamp}.csv"
    results_df.to_csv(output_file, index=False)
    logger.info(f"Results saved to {output_file}")
    
    # Display by strategy
    print("\n" + "="*80)
    print(f"POSITIONAL SCAN COMPLETE - Duration: {duration:.1f} seconds")
    print(f"Symbols scanned: {len(universe)}")
    print(f"Setups found: {len(results_df)}")
    print("="*80)
    
    if not results_df.empty:
        # Group by strategy
        strategy_counts = results_df['strategy'].value_counts()
        
        print("\n📊 SETUPS BY STRATEGY:")
        print("-" * 80)
        for strategy, count in strategy_counts.items():
            print(f"{strategy}: {count}")
        print("-" * 80)
        
        # Show top setups
        top_setups = results_df.nlargest(10, 'score')
        
        print("\n🎯 TOP 10 SETUPS (by score):")
        print("-" * 80)
        
        display_cols = ['symbol', 'strategy', 'score', 'days_to_expiry', 'iv_rank']
        if 'reasons' in top_setups.columns:
            for idx, row in top_setups.iterrows():
                # Add indicator for explosive OI
                oi_indicator = ""
                if row.get('futures_oi_signal') == 'EXPLOSIVE':
                    oi_indicator = " 🚀🚀🚀"
                elif row.get('futures_oi_signal') == 'STRONG':
                    oi_indicator = " 💪💪"
                elif row.get('futures_oi_signal') == 'MODERATE':
                    oi_indicator = " 📈"
                
                print(f"\n{row['symbol']} - {row['strategy']} (Score: {row['score']}){oi_indicator}")
                print(f"  Days to expiry: {row.get('days_to_expiry', 'N/A')}")
                print(f"  IV Rank: {row.get('iv_rank', 'N/A'):.0f}")
                
                # Show futures OI if significant
                if row.get('futures_oi_signal') in ['EXPLOSIVE', 'STRONG', 'MODERATE']:
                    print(f"  Futures OI: {row.get('futures_oi_signal')} buildup ({row.get('futures_oi_pct', 0):.0f}%+)")
                
                if 'reasons' in row and row['reasons']:
                    print(f"  Reasons: {', '.join(row['reasons'])}")
        else:
            print(top_setups[display_cols].to_string(index=False))
        
        print("-" * 80)
    else:
        print("\n✓ No setups found matching criteria")
    
    print(f"\nExpected holding period: 2-3 days")
    print(f"Review and validate setups before trading!")


if __name__ == "__main__":
    main()