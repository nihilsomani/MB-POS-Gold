import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
from scipy.stats import percentileofscore
import warnings
import time
warnings.filterwarnings('ignore')

api_key = "3bi2yh8g830vq3y6"
access_token = "IIyA1VyxcQxaiRlmlVbMaabOb27Kzi12"
kite = KiteConnect(api_key=api_key)
kite.set_access_token(access_token)

fno_stocks = pd.read_csv('data/FNOStock.csv')
symbols = fno_stocks['Symbol'].tolist()

LOOKBACK_DAYS = 90
ATR_PERIOD = 14
HISTORICAL_OPTION_DAYS = 45
API_DELAY = 0.33
MIN_DATA_DAYS = 40

NSE_INSTRUMENTS_CACHE = None
NFO_INSTRUMENTS_CACHE = None
INSTRUMENT_TOKEN_CACHE = {}

# LONG OPTIONS SCANNER CONFIGURATION
LONG_MAX_ENTRY_PERCENTILE = 30    # Only show if premium < 30th percentile (cheap!)
LONG_MIN_STRATEGY_VOL = 15         # Need at least 15% historical volatility
LONG_RSI_OVERSOLD = 35             # For long calls
LONG_RSI_OVERBOUGHT = 65           # For long puts
LONG_MAX_PREMIUM_PCT = 3.5         # Max 3.5% of stock price
LONG_MIN_DTE = 20                  # At least 20 days
LONG_PREFERRED_DTE_MIN = 45        # Prefer 45-70 DTE (next month)
LONG_PREFERRED_DTE_MAX = 70

def initialize_instrument_cache():
    """Load all instruments once at startup"""
    global NSE_INSTRUMENTS_CACHE, NFO_INSTRUMENTS_CACHE
    
    print("=" * 100)
    print("INITIALIZING INSTRUMENT CACHE")
    print("=" * 100)
    
    try:
        print("  Loading NSE instruments...", end=' ', flush=True)
        NSE_INSTRUMENTS_CACHE = kite.instruments("NSE")
        print(f"✅ {len(NSE_INSTRUMENTS_CACHE)} instruments loaded")
        time.sleep(0.5)
        
        print("  Loading NFO instruments...", end=' ', flush=True)
        NFO_INSTRUMENTS_CACHE = kite.instruments("NFO")
        print(f"✅ {len(NFO_INSTRUMENTS_CACHE)} instruments loaded")
        time.sleep(0.5)
        
        print("=" * 100)
        return True
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def get_instrument_token(symbol, exchange="NSE"):
    """Get instrument token with caching"""
    global INSTRUMENT_TOKEN_CACHE
    
    cache_key = f"{exchange}:{symbol}"
    
    if cache_key in INSTRUMENT_TOKEN_CACHE:
        return INSTRUMENT_TOKEN_CACHE[cache_key]
    
    try:
        instruments = NSE_INSTRUMENTS_CACHE if exchange == "NSE" else NFO_INSTRUMENTS_CACHE
        
        if instruments is None:
            return None
        
        for inst in instruments:
            if inst['tradingsymbol'] == symbol and inst['segment'] == exchange:
                INSTRUMENT_TOKEN_CACHE[cache_key] = inst['instrument_token']
                return inst['instrument_token']
        
        INSTRUMENT_TOKEN_CACHE[cache_key] = None
        return None
        
    except Exception as e:
        return None

def get_historical_data(instrument_token, days=90, retries=2):
    for attempt in range(retries):
        try:
            to_date = datetime.now().date()
            from_date = to_date - timedelta(days=days)
            
            data = kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if data and len(data) > 0:
                df = pd.DataFrame(data)
                df['date'] = pd.to_datetime(df['date'])
                return df
            
        except Exception as e:
            if "Too many requests" in str(e):
                time.sleep(2)
            if attempt < retries - 1:
                time.sleep(1)
                continue
            return None
    
    return None

def calculate_atr(df, period=14):
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = np.max(ranges, axis=1)
    atr = true_range.rolling(period).mean()
    return atr

def calculate_bollinger_bands(df, period=20, std_dev=2):
    sma = df['close'].rolling(period).mean()
    std = df['close'].rolling(period).std()
    upper = sma + (std_dev * std)
    lower = sma - (std_dev * std)
    return upper, sma, lower

def calculate_rsi(df, period=14):
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def identify_regime(df):
    current_price = df['close'].iloc[-1]
    sma20 = df['close'].rolling(20).mean().iloc[-1]
    sma50 = df['close'].rolling(50).mean().iloc[-1] if len(df) >= 50 else sma20
    
    atr = calculate_atr(df).iloc[-1]
    atr_pct = (atr / current_price) * 100
    
    if current_price > sma20 > sma50:
        trend = "UPTREND"
    elif current_price < sma20 < sma50:
        trend = "DOWNTREND"
    else:
        trend = "SIDEWAYS"
    
    if atr_pct < 2:
        vol_regime = "LOW"
    elif atr_pct > 4:
        vol_regime = "HIGH"
    else:
        vol_regime = "MEDIUM"
    
    return trend, vol_regime, atr_pct

def get_option_chain(symbol, expiry_date):
    """Get option chain using cached NFO instruments"""
    try:
        if NFO_INSTRUMENTS_CACHE is None:
            return []
        
        options = [inst for inst in NFO_INSTRUMENTS_CACHE 
                  if inst['name'] == symbol 
                  and inst['expiry'] == expiry_date
                  and inst['instrument_type'] in ['CE', 'PE']]
        return options
    except:
        return []

def get_atm_strike(current_price):
    if current_price < 100:
        strike_diff = 2.5
    elif current_price < 500:
        strike_diff = 5
    elif current_price < 1000:
        strike_diff = 10
    elif current_price < 2000:
        strike_diff = 25
    elif current_price < 5000:
        strike_diff = 50
    else:
        strike_diff = 100
    
    return round(current_price / strike_diff) * strike_diff

def calculate_premium_pct(strike, premium):
    return (premium / strike) * 100

def get_option_quotes(trading_symbols, retries=2):
    for attempt in range(retries):
        try:
            if not trading_symbols:
                return {}
            quotes = kite.quote([f"NFO:{ts}" for ts in trading_symbols])
            return quotes
        except Exception as e:
            if "Too many requests" in str(e):
                time.sleep(2)
            if attempt < retries - 1:
                time.sleep(1)
            continue
    return {}

def get_expiries_for_long_options(symbol):
    """
    Get expiries optimized for LONG (BUY) options:
    - preferred_expiry: Next month (45-70 DTE) - RECOMMENDED
    - alternative_expiry: Current month (20-35 DTE) - ALTERNATIVE
    """
    try:
        if NFO_INSTRUMENTS_CACHE is None:
            return None, None
        
        expiries = sorted(list(set([inst['expiry'] for inst in NFO_INSTRUMENTS_CACHE 
                                   if inst['name'] == symbol 
                                   and inst['instrument_type'] in ['CE', 'PE']])))
        
        today = datetime.now().date()
        future_expiries = [exp for exp in expiries if exp >= today]
        
        if not future_expiries:
            return None, None
        
        expiries_with_dte = [(exp, (exp - today).days) for exp in future_expiries]
        
        # PREFERRED: Next month (45-70 DTE) for LONG options
        preferred_candidates = [(exp, dte) for exp, dte in expiries_with_dte 
                               if LONG_PREFERRED_DTE_MIN <= dte <= LONG_PREFERRED_DTE_MAX]
        
        if preferred_candidates:
            # Target around 55 DTE (middle of range)
            preferred_expiry = min(preferred_candidates, key=lambda x: abs(x[1] - 55))[0]
        else:
            # Fallback: closest to 55 DTE
            preferred_expiry = min(expiries_with_dte, key=lambda x: abs(x[1] - 55))[0]
        
        # ALTERNATIVE: Current month (20-35 DTE) for aggressive traders
        alternative_candidates = [(exp, dte) for exp, dte in expiries_with_dte 
                                 if 20 <= dte <= 35]
        
        if alternative_candidates:
            # Target around 25 DTE
            alternative_expiry = min(alternative_candidates, key=lambda x: abs(x[1] - 25))[0]
        else:
            alternative_expiry = None
        
        return preferred_expiry, alternative_expiry
        
    except Exception as e:
        return None, None

def get_historical_option_prices(symbol, strike, option_type, expiry, days=45):
    try:
        if NFO_INSTRUMENTS_CACHE is None:
            return None
        
        option = [inst for inst in NFO_INSTRUMENTS_CACHE 
                 if inst['name'] == symbol 
                 and inst['strike'] == strike
                 and inst['instrument_type'] == option_type
                 and inst['expiry'] == expiry]
        
        if not option:
            return None
        
        instrument_token = option[0]['instrument_token']
        
        to_date = datetime.now().date()
        from_date = to_date - timedelta(days=days)
        
        data = kite.historical_data(
            instrument_token=instrument_token,
            from_date=from_date,
            to_date=to_date,
            interval="day"
        )
        
        if not data or len(data) < 3:
            return None
        
        df = pd.DataFrame(data)
        return df['close'].values
        
    except Exception as e:
        if "Too many requests" in str(e):
            time.sleep(2)
        return None

def analyze_option_history(option_history, current_ltp):
    """Analyze single option historical prices"""
    if option_history is None or len(option_history) < 3:
        return None
    
    option_vol = np.std(option_history) / np.mean(option_history) if np.mean(option_history) > 0 else 999
    
    max_price = np.max(option_history)
    min_price = np.min(option_history)
    expansion_ratio = max_price / min_price if min_price > 0 else 999
    
    entry_percentile = percentileofscore(option_history, current_ltp)
    
    recent_avg = np.mean(option_history[-3:])
    older_avg = np.mean(option_history[:-3]) if len(option_history) > 3 else recent_avg
    
    if older_avg > 0:
        iv_trend = "FALLING" if recent_avg < older_avg * 0.95 else ("RISING" if recent_avg > older_avg * 1.05 else "STABLE")
    else:
        iv_trend = "STABLE"
    
    return {
        'option_vol': option_vol,
        'expansion_ratio': expansion_ratio,
        'entry_percentile': entry_percentile,
        'iv_trend': iv_trend,
        'historical_mean': np.mean(option_history),
        'historical_max': max_price,
        'historical_min': min_price
    }

def analyze_straddle_history(ce_history, pe_history, current_ce_ltp, current_pe_ltp):
    """Analyze straddle/strangle historical prices"""
    if ce_history is None or pe_history is None:
        return None
    
    if len(ce_history) < 3 or len(pe_history) < 3:
        return None
    
    min_len = min(len(ce_history), len(pe_history))
    ce_history = ce_history[-min_len:]
    pe_history = pe_history[-min_len:]
    
    strategy_history = ce_history + pe_history
    current_strategy_price = current_ce_ltp + current_pe_ltp
    
    if len(strategy_history) < 3:
        return None
    
    strategy_vol = np.std(strategy_history) / np.mean(strategy_history) if np.mean(strategy_history) > 0 else 999
    
    max_price = np.max(strategy_history)
    min_price = np.min(strategy_history)
    expansion_ratio = max_price / min_price if min_price > 0 else 999
    
    entry_percentile = percentileofscore(strategy_history, current_strategy_price)
    
    recent_avg = np.mean(strategy_history[-3:])
    older_avg = np.mean(strategy_history[:-3]) if len(strategy_history) > 3 else recent_avg
    
    if older_avg > 0:
        iv_trend = "FALLING" if recent_avg < older_avg * 0.95 else ("RISING" if recent_avg > older_avg * 1.05 else "STABLE")
    else:
        iv_trend = "STABLE"
    
    return {
        'strategy_vol': strategy_vol,
        'expansion_ratio': expansion_ratio,
        'entry_percentile': entry_percentile,
        'iv_trend': iv_trend,
        'historical_mean': np.mean(strategy_history),
        'historical_max': max_price,
        'historical_min': min_price
    }

def evaluate_long_quality(analysis, premium_pct, days_to_expiry):
    """Evaluate quality for LONG options (opposite of SHORT logic)"""
    if analysis is None:
        return "UNKNOWN", []
    
    strengths = []
    concerns = []
    
    # For LONG: LOW entry percentile is GOOD (cheap premium)
    if analysis['entry_percentile'] < 15:
        strengths.append("Very cheap premium")
    elif analysis['entry_percentile'] < 25:
        strengths.append("Cheap premium")
    elif analysis['entry_percentile'] > 40:
        concerns.append("Premium not cheap enough")
    
    # For LONG: HIGH volatility is GOOD (movement expected)
    if analysis.get('strategy_vol', analysis.get('option_vol', 0)) > 0.30:
        strengths.append("High movement expected")
    elif analysis.get('strategy_vol', analysis.get('option_vol', 0)) < 0.15:
        concerns.append("Low movement expected")
    
    # For LONG: LOW IV is GOOD (room for expansion)
    if analysis['iv_trend'] == "FALLING" and analysis['entry_percentile'] < 20:
        strengths.append("IV crushed - expansion likely")
    elif analysis['iv_trend'] == "RISING":
        concerns.append("IV already rising")
    
    # Premium cost check
    if premium_pct > 3.5:
        concerns.append("Premium expensive")
    elif premium_pct < 2.0:
        strengths.append("Affordable premium")
    
    # Time check
    if days_to_expiry < 20:
        concerns.append("Not enough time")
    elif days_to_expiry > 60:
        strengths.append("Plenty of time")
    
    # Quality rating
    if len(concerns) == 0 and len(strengths) >= 3:
        return "EXCELLENT", strengths, concerns
    elif len(concerns) <= 1 and len(strengths) >= 2:
        return "GOOD", strengths, concerns
    elif len(concerns) <= 2:
        return "ACCEPTABLE", strengths, concerns
    else:
        return "POOR", strengths, concerns

def scan_long_straddle(symbol, df, current_price, expiry, expiry_label):
    """
    Scan for LONG STRADDLE opportunities (BUY ATM CE + ATM PE)
    For volatility expansion plays
    """
    if expiry is None:
        return None
    
    days_to_expiry = (expiry - datetime.now().date()).days
    
    if days_to_expiry < LONG_MIN_DTE:
        return None
    
    trend, vol_regime, atr_pct = identify_regime(df)
    
    # For LONG straddle: Want consolidation (coiled spring)
    upper_bb, middle_bb, lower_bb = calculate_bollinger_bands(df)
    bb_width = ((upper_bb.iloc[-1] - lower_bb.iloc[-1]) / middle_bb.iloc[-1]) * 100
    
    # Prefer sideways/consolidation for straddles
    if trend not in ["SIDEWAYS", "UPTREND", "DOWNTREND"]:
        return None
    
    atm_strike = get_atm_strike(current_price)
    
    options = get_option_chain(symbol, expiry)
    if not options:
        return None
    
    atm_ce = [opt for opt in options if opt['strike'] == atm_strike and opt['instrument_type'] == 'CE']
    atm_pe = [opt for opt in options if opt['strike'] == atm_strike and opt['instrument_type'] == 'PE']
    
    if not atm_ce or not atm_pe:
        return None
    
    ce_symbol = atm_ce[0]['tradingsymbol']
    pe_symbol = atm_pe[0]['tradingsymbol']
    
    time.sleep(API_DELAY)
    quotes = get_option_quotes([ce_symbol, pe_symbol])
    
    if f"NFO:{ce_symbol}" not in quotes or f"NFO:{pe_symbol}" not in quotes:
        return None
    
    ce_ltp = quotes[f"NFO:{ce_symbol}"]["last_price"]
    pe_ltp = quotes[f"NFO:{pe_symbol}"]["last_price"]
    
    if ce_ltp <= 0 or pe_ltp <= 0:
        return None
    
    total_premium = ce_ltp + pe_ltp
    premium_pct = (total_premium / current_price) * 100
    
    # For LONG: Want cheap premium (low cost)
    if premium_pct > LONG_MAX_PREMIUM_PCT:
        return None
    
    time.sleep(API_DELAY)
    ce_history = get_historical_option_prices(symbol, atm_strike, 'CE', expiry, HISTORICAL_OPTION_DAYS)
    time.sleep(API_DELAY)
    pe_history = get_historical_option_prices(symbol, atm_strike, 'PE', expiry, HISTORICAL_OPTION_DAYS)
    
    analysis = analyze_straddle_history(ce_history, pe_history, ce_ltp, pe_ltp)
    
    if analysis and analysis['entry_percentile'] > LONG_MAX_ENTRY_PERCENTILE:
        return None
    
    quality, strengths, concerns = evaluate_long_quality(analysis, premium_pct, days_to_expiry)
    
    if quality == "POOR":
        return None
    
    # Calculate expected move and breakevens
    atr = calculate_atr(df).iloc[-1]
    expected_move_pct = (atr / current_price) * 100 * 2  # 2 ATR move
    expected_move_value = atr * 2
    
    upper_be = atm_strike + total_premium
    lower_be = atm_strike - total_premium
    
    # Calculate daily theta (rough estimate)
    daily_theta = total_premium / days_to_expiry
    
    # Scoring for LONG straddles (opposite of SHORT logic)
    base_score = 100 - (analysis['entry_percentile'] if analysis else 50)  # Lower percentile = higher score
    
    if analysis:
        if quality == "EXCELLENT":
            base_score += 20
        elif quality == "GOOD":
            base_score += 10
        
        if analysis['strategy_vol'] > 0.25:
            base_score += 10
        
        if analysis['iv_trend'] == "FALLING":
            base_score += 10
    
    # Bonus for consolidation (BB squeeze)
    if bb_width < 8:
        base_score += 5
    
    result = {
        'Symbol': symbol,
        'Strategy': 'LONG_STRADDLE',
        'Expiry': expiry_label,
        'DTE': days_to_expiry,
        'Price': round(current_price, 2),
        'Strike': atm_strike,
        'CE': ce_symbol,
        'CE_Prem': round(ce_ltp, 2),
        'PE': pe_symbol,
        'PE_Prem': round(pe_ltp, 2),
        'Total_Cost': round(total_premium, 2),
        'Cost_%': round(premium_pct, 2),
        'Daily_Theta': round(daily_theta, 2),
        'Upper_BE': round(upper_be, 2),
        'Lower_BE': round(lower_be, 2),
        'BE_Move_%': round((total_premium / current_price) * 100, 2),
        'Expected_Move_%': round(expected_move_pct, 2),
        'Trend': trend,
        'Vol': vol_regime,
        'BB_Width': round(bb_width, 2),
        'Quality': quality,
        'Score': round(base_score, 1)
    }
    
    if analysis:
        result.update({
            'Entry_%ile': round(analysis['entry_percentile'], 1),
            'Strat_Vol%': round(analysis['strategy_vol'] * 100, 1),
            'IV': analysis['iv_trend'],
            'Hist_Mean': round(analysis['historical_mean'], 2),
            'Expansion_Potential': round((analysis['historical_max'] / total_premium - 1) * 100, 1),
            'Strengths': '; '.join(strengths) if strengths else '-',
            'Concerns': '; '.join(concerns) if concerns else '-'
        })
    
    return result

def scan_long_strangle(symbol, df, current_price, expiry, expiry_label):
    """
    Scan for LONG STRANGLE opportunities (BUY OTM CE + OTM PE)
    Cheaper than straddle, wider breakevens
    """
    if expiry is None:
        return None
    
    days_to_expiry = (expiry - datetime.now().date()).days
    
    if days_to_expiry < LONG_MIN_DTE:
        return None
    
    trend, vol_regime, atr_pct = identify_regime(df)
    
    upper_bb, middle_bb, lower_bb = calculate_bollinger_bands(df)
    bb_width = ((upper_bb.iloc[-1] - lower_bb.iloc[-1]) / middle_bb.iloc[-1]) * 100
    
    atr = calculate_atr(df).iloc[-1]
    
    # For strangle: strikes 1.5 ATR away
    otm_call_strike = get_atm_strike(current_price + (1.5 * atr))
    otm_put_strike = get_atm_strike(current_price - (1.5 * atr))
    
    options = get_option_chain(symbol, expiry)
    if not options:
        return None
    
    otm_ce = [opt for opt in options if opt['strike'] == otm_call_strike and opt['instrument_type'] == 'CE']
    otm_pe = [opt for opt in options if opt['strike'] == otm_put_strike and opt['instrument_type'] == 'PE']
    
    if not otm_ce or not otm_pe:
        return None
    
    ce_symbol = otm_ce[0]['tradingsymbol']
    pe_symbol = otm_pe[0]['tradingsymbol']
    
    time.sleep(API_DELAY)
    quotes = get_option_quotes([ce_symbol, pe_symbol])
    
    if f"NFO:{ce_symbol}" not in quotes or f"NFO:{pe_symbol}" not in quotes:
        return None
    
    ce_ltp = quotes[f"NFO:{ce_symbol}"]["last_price"]
    pe_ltp = quotes[f"NFO:{pe_symbol}"]["last_price"]
    
    if ce_ltp <= 0 or pe_ltp <= 0:
        return None
    
    total_premium = ce_ltp + pe_ltp
    premium_pct = (total_premium / current_price) * 100
    
    if premium_pct > LONG_MAX_PREMIUM_PCT:
        return None
    
    time.sleep(API_DELAY)
    ce_history = get_historical_option_prices(symbol, otm_call_strike, 'CE', expiry, HISTORICAL_OPTION_DAYS)
    time.sleep(API_DELAY)
    pe_history = get_historical_option_prices(symbol, otm_put_strike, 'PE', expiry, HISTORICAL_OPTION_DAYS)
    
    analysis = analyze_straddle_history(ce_history, pe_history, ce_ltp, pe_ltp)
    
    if analysis and analysis['entry_percentile'] > LONG_MAX_ENTRY_PERCENTILE:
        return None
    
    quality, strengths, concerns = evaluate_long_quality(analysis, premium_pct, days_to_expiry)
    
    if quality == "POOR":
        return None
    
    upper_be = otm_call_strike + total_premium
    lower_be = otm_put_strike - total_premium
    
    daily_theta = total_premium / days_to_expiry
    
    expected_move_pct = (atr / current_price) * 100 * 2
    
    base_score = 100 - (analysis['entry_percentile'] if analysis else 50)
    
    if analysis:
        if quality == "EXCELLENT":
            base_score += 20
        elif quality == "GOOD":
            base_score += 10
        
        if analysis['strategy_vol'] > 0.25:
            base_score += 10
        
        if analysis['iv_trend'] == "FALLING":
            base_score += 10
    
    if bb_width < 8:
        base_score += 5
    
    result = {
        'Symbol': symbol,
        'Strategy': 'LONG_STRANGLE',
        'Expiry': expiry_label,
        'DTE': days_to_expiry,
        'Price': round(current_price, 2),
        'Call_Strike': otm_call_strike,
        'CE': ce_symbol,
        'CE_Prem': round(ce_ltp, 2),
        'Put_Strike': otm_put_strike,
        'PE': pe_symbol,
        'PE_Prem': round(pe_ltp, 2),
        'Total_Cost': round(total_premium, 2),
        'Cost_%': round(premium_pct, 2),
        'Daily_Theta': round(daily_theta, 2),
        'Upper_BE': round(upper_be, 2),
        'Lower_BE': round(lower_be, 2),
        'BE_Move_%': round(((upper_be - current_price) / current_price) * 100, 2),
        'Expected_Move_%': round(expected_move_pct, 2),
        'Trend': trend,
        'Vol': vol_regime,
        'BB_Width': round(bb_width, 2),
        'Quality': quality,
        'Score': round(base_score, 1)
    }
    
    if analysis:
        result.update({
            'Entry_%ile': round(analysis['entry_percentile'], 1),
            'Strat_Vol%': round(analysis['strategy_vol'] * 100, 1),
            'IV': analysis['iv_trend'],
            'Hist_Mean': round(analysis['historical_mean'], 2),
            'Expansion_Potential': round((analysis['historical_max'] / total_premium - 1) * 100, 1),
            'Strengths': '; '.join(strengths) if strengths else '-',
            'Concerns': '; '.join(concerns) if concerns else '-'
        })
    
    return result

def scan_long_call(symbol, df, current_price, expiry, expiry_label):
    """
    Scan for LONG CALL opportunities (BUY call for bullish play)
    Look for oversold + support + cheap IV
    """
    if expiry is None:
        return None
    
    days_to_expiry = (expiry - datetime.now().date()).days
    
    if days_to_expiry < LONG_MIN_DTE:
        return None
    
    trend, vol_regime, atr_pct = identify_regime(df)
    
    # For LONG calls: Want oversold or uptrend continuation
    rsi = calculate_rsi(df)
    current_rsi = rsi.iloc[-1]
    
    # Skip if not oversold and not in uptrend
    if current_rsi > LONG_RSI_OVERSOLD and trend != "UPTREND":
        return None
    
    atr = calculate_atr(df).iloc[-1]
    
    # For calls: ATM or slightly OTM
    call_strike = get_atm_strike(current_price + (0.5 * atr))
    
    options = get_option_chain(symbol, expiry)
    if not options:
        return None
    
    calls = [opt for opt in options if opt['strike'] == call_strike and opt['instrument_type'] == 'CE']
    
    if not calls:
        return None
    
    ce_symbol = calls[0]['tradingsymbol']
    
    time.sleep(API_DELAY)
    quotes = get_option_quotes([ce_symbol])
    
    if f"NFO:{ce_symbol}" not in quotes:
        return None
    
    ce_ltp = quotes[f"NFO:{ce_symbol}"]["last_price"]
    
    if ce_ltp <= 0:
        return None
    
    premium_pct = (ce_ltp / current_price) * 100
    
    if premium_pct > LONG_MAX_PREMIUM_PCT:
        return None
    
    time.sleep(API_DELAY)
    ce_history = get_historical_option_prices(symbol, call_strike, 'CE', expiry, HISTORICAL_OPTION_DAYS)
    
    analysis = analyze_option_history(ce_history, ce_ltp)
    
    if analysis and analysis['entry_percentile'] > LONG_MAX_ENTRY_PERCENTILE:
        return None
    
    quality, strengths, concerns = evaluate_long_quality(analysis, premium_pct, days_to_expiry)
    
    if quality == "POOR":
        return None
    
    breakeven = call_strike + ce_ltp
    daily_theta = ce_ltp / days_to_expiry
    
    # Target: 1.5-2 ATR move up
    target_price = current_price + (1.5 * atr)
    target_move_pct = ((target_price - current_price) / current_price) * 100
    
    # Potential return if target hit
    if target_price > call_strike:
        target_value = (target_price - call_strike) + (ce_ltp * 0.3)  # Intrinsic + remaining time value
        potential_return = ((target_value - ce_ltp) / ce_ltp) * 100
    else:
        potential_return = 0
    
    base_score = 100 - (analysis['entry_percentile'] if analysis else 50)
    
    # Bonus for oversold
    if current_rsi < 30:
        base_score += 15
    elif current_rsi < 35:
        base_score += 10
    
    # Bonus for uptrend
    if trend == "UPTREND":
        base_score += 10
    
    if analysis:
        if quality == "EXCELLENT":
            base_score += 20
        elif quality == "GOOD":
            base_score += 10
        
        if analysis['iv_trend'] == "FALLING":
            base_score += 10
    
    result = {
        'Symbol': symbol,
        'Strategy': 'LONG_CALL',
        'Expiry': expiry_label,
        'DTE': days_to_expiry,
        'Price': round(current_price, 2),
        'Strike': call_strike,
        'Option': ce_symbol,
        'Premium': round(ce_ltp, 2),
        'Cost_%': round(premium_pct, 2),
        'Daily_Theta': round(daily_theta, 2),
        'Breakeven': round(breakeven, 2),
        'BE_Move_%': round(((breakeven - current_price) / current_price) * 100, 2),
        'Target': round(target_price, 2),
        'Target_Move_%': round(target_move_pct, 2),
        'Potential_Return_%': round(potential_return, 1),
        'RSI': round(current_rsi, 1),
        'Trend': trend,
        'Vol': vol_regime,
        'Quality': quality,
        'Score': round(base_score, 1)
    }
    
    if analysis:
        result.update({
            'Entry_%ile': round(analysis['entry_percentile'], 1),
            'Option_Vol%': round(analysis['option_vol'] * 100, 1),
            'IV': analysis['iv_trend'],
            'Hist_Mean': round(analysis['historical_mean'], 2),
            'Expansion_Potential': round((analysis['historical_max'] / ce_ltp - 1) * 100, 1),
            'Strengths': '; '.join(strengths) if strengths else '-',
            'Concerns': '; '.join(concerns) if concerns else '-'
        })
    
    # Add rationale
    rationale = []
    if current_rsi < 30:
        rationale.append("Deeply oversold")
    elif current_rsi < 35:
        rationale.append("Oversold")
    
    if trend == "UPTREND":
        rationale.append("Uptrend")
    
    if analysis and analysis['entry_percentile'] < 15:
        rationale.append("Very cheap IV")
    
    result['Rationale'] = '; '.join(rationale) if rationale else 'Technical setup'
    
    return result

def scan_long_put(symbol, df, current_price, expiry, expiry_label):
    """
    Scan for LONG PUT opportunities (BUY put for bearish play)
    Look for overbought + resistance + cheap IV
    """
    if expiry is None:
        return None
    
    days_to_expiry = (expiry - datetime.now().date()).days
    
    if days_to_expiry < LONG_MIN_DTE:
        return None
    
    trend, vol_regime, atr_pct = identify_regime(df)
    
    rsi = calculate_rsi(df)
    current_rsi = rsi.iloc[-1]
    
    # For LONG puts: Want overbought or downtrend continuation
    if current_rsi < LONG_RSI_OVERBOUGHT and trend != "DOWNTREND":
        return None
    
    atr = calculate_atr(df).iloc[-1]
    
    # For puts: ATM or slightly OTM
    put_strike = get_atm_strike(current_price - (0.5 * atr))
    
    options = get_option_chain(symbol, expiry)
    if not options:
        return None
    
    puts = [opt for opt in options if opt['strike'] == put_strike and opt['instrument_type'] == 'PE']
    
    if not puts:
        return None
    
    pe_symbol = puts[0]['tradingsymbol']
    
    time.sleep(API_DELAY)
    quotes = get_option_quotes([pe_symbol])
    
    if f"NFO:{pe_symbol}" not in quotes:
        return None
    
    pe_ltp = quotes[f"NFO:{pe_symbol}"]["last_price"]
    
    if pe_ltp <= 0:
        return None
    
    premium_pct = (pe_ltp / current_price) * 100
    
    if premium_pct > LONG_MAX_PREMIUM_PCT:
        return None
    
    time.sleep(API_DELAY)
    pe_history = get_historical_option_prices(symbol, put_strike, 'PE', expiry, HISTORICAL_OPTION_DAYS)
    
    analysis = analyze_option_history(pe_history, pe_ltp)
    
    if analysis and analysis['entry_percentile'] > LONG_MAX_ENTRY_PERCENTILE:
        return None
    
    quality, strengths, concerns = evaluate_long_quality(analysis, premium_pct, days_to_expiry)
    
    if quality == "POOR":
        return None
    
    breakeven = put_strike - pe_ltp
    daily_theta = pe_ltp / days_to_expiry
    
    target_price = current_price - (1.5 * atr)
    target_move_pct = ((target_price - current_price) / current_price) * 100
    
    if target_price < put_strike:
        target_value = (put_strike - target_price) + (pe_ltp * 0.3)
        potential_return = ((target_value - pe_ltp) / pe_ltp) * 100
    else:
        potential_return = 0
    
    base_score = 100 - (analysis['entry_percentile'] if analysis else 50)
    
    if current_rsi > 70:
        base_score += 15
    elif current_rsi > 65:
        base_score += 10
    
    if trend == "DOWNTREND":
        base_score += 10
    
    if analysis:
        if quality == "EXCELLENT":
            base_score += 20
        elif quality == "GOOD":
            base_score += 10
        
        if analysis['iv_trend'] == "FALLING":
            base_score += 10
    
    result = {
        'Symbol': symbol,
        'Strategy': 'LONG_PUT',
        'Expiry': expiry_label,
        'DTE': days_to_expiry,
        'Price': round(current_price, 2),
        'Strike': put_strike,
        'Option': pe_symbol,
        'Premium': round(pe_ltp, 2),
        'Cost_%': round(premium_pct, 2),
        'Daily_Theta': round(daily_theta, 2),
        'Breakeven': round(breakeven, 2),
        'BE_Move_%': round(((breakeven - current_price) / current_price) * 100, 2),
        'Target': round(target_price, 2),
        'Target_Move_%': round(target_move_pct, 2),
        'Potential_Return_%': round(potential_return, 1),
        'RSI': round(current_rsi, 1),
        'Trend': trend,
        'Vol': vol_regime,
        'Quality': quality,
        'Score': round(base_score, 1)
    }
    
    if analysis:
        result.update({
            'Entry_%ile': round(analysis['entry_percentile'], 1),
            'Option_Vol%': round(analysis['option_vol'] * 100, 1),
            'IV': analysis['iv_trend'],
            'Hist_Mean': round(analysis['historical_mean'], 2),
            'Expansion_Potential': round((analysis['historical_max'] / pe_ltp - 1) * 100, 1),
            'Strengths': '; '.join(strengths) if strengths else '-',
            'Concerns': '; '.join(concerns) if concerns else '-'
        })
    
    rationale = []
    if current_rsi > 70:
        rationale.append("Deeply overbought")
    elif current_rsi > 65:
        rationale.append("Overbought")
    
    if trend == "DOWNTREND":
        rationale.append("Downtrend")
    
    if analysis and analysis['entry_percentile'] < 15:
        rationale.append("Very cheap IV")
    
    result['Rationale'] = '; '.join(rationale) if rationale else 'Technical setup'
    
    return result

def run_long_options_scanner():
    """
    Main scanner for LONG (BUY) options opportunities
    Scans for premium BUYING opportunities when IV is low
    """
    
    all_opportunities = {
        'straddles_preferred': [],      # Next month (55 DTE)
        'straddles_alternative': [],    # Current month (27 DTE)
        'strangles_preferred': [],
        'strangles_alternative': [],
        'calls_preferred': [],
        'calls_alternative': [],
        'puts_preferred': [],
        'puts_alternative': []
    }
    
    print("\n" + "=" * 100)
    print("LONG OPTIONS SCANNER - PREMIUM BUYING OPPORTUNITIES")
    print("=" * 100)
    
    if not initialize_instrument_cache():
        print("❌ Failed to initialize instrument cache. Exiting.")
        return
    
    print("\n" + "=" * 100)
    print(f"SCANNING {len(symbols)} SYMBOLS FOR LONG OPPORTUNITIES")
    print("=" * 100)
    print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\nSCANNER CONFIGURATION:")
    print(f"  • Max entry percentile: {LONG_MAX_ENTRY_PERCENTILE}% (only show if premium CHEAP)")
    print(f"  • Min strategy vol: {LONG_MIN_STRATEGY_VOL}% (need movement expected)")
    print(f"  • Max premium cost: {LONG_MAX_PREMIUM_PCT}% of stock price")
    print(f"  • Preferred DTE: {LONG_PREFERRED_DTE_MIN}-{LONG_PREFERRED_DTE_MAX} days (NEXT MONTH) ⭐")
    print(f"  • Alternative DTE: 20-35 days (CURRENT MONTH)")
    print("\nSTRATEGY LOGIC:")
    print("  ✅ OPPOSITE of selling: Buy when IV LOW, sell when IV HIGH")
    print("  ✅ Looking for cheap premiums ready to expand")
    print("  ✅ Prefer next month (more time = lower theta bleed)")
    print("-" * 100)
    
    success_count = 0
    fail_count = 0
    
    for idx, symbol in enumerate(symbols):
        try:
            print(f"[{idx+1}/{len(symbols)}] {symbol}...", end=' ', flush=True)
            
            instrument_token = get_instrument_token(symbol)
            if not instrument_token:
                print("❌ No token")
                fail_count += 1
                continue
            
            time.sleep(API_DELAY)
            df = get_historical_data(instrument_token, LOOKBACK_DAYS)
            
            if df is None or len(df) < MIN_DATA_DAYS:
                print(f"❌ Data: {len(df) if df is not None else 0}d")
                fail_count += 1
                continue
            
            current_price = df['close'].iloc[-1]
            
            # Get BOTH preferred (next month) and alternative (current month) expiries
            preferred_expiry, alternative_expiry = get_expiries_for_long_options(symbol)
            
            if preferred_expiry is None:
                print("❌ No expiry")
                fail_count += 1
                continue
            
            success_count += 1
            found_any = False
            
            # PREFERRED: Next month (55 DTE)
            if preferred_expiry:
                pref_dte = (preferred_expiry - datetime.now().date()).days
                
                straddle_pref = scan_long_straddle(symbol, df, current_price, preferred_expiry, f"NEXT({pref_dte}d)⭐")
                if straddle_pref:
                    all_opportunities['straddles_preferred'].append(straddle_pref)
                    found_any = True
                
                strangle_pref = scan_long_strangle(symbol, df, current_price, preferred_expiry, f"NEXT({pref_dte}d)⭐")
                if strangle_pref:
                    all_opportunities['strangles_preferred'].append(strangle_pref)
                    found_any = True
                
                call_pref = scan_long_call(symbol, df, current_price, preferred_expiry, f"NEXT({pref_dte}d)⭐")
                if call_pref:
                    all_opportunities['calls_preferred'].append(call_pref)
                    found_any = True
                
                put_pref = scan_long_put(symbol, df, current_price, preferred_expiry, f"NEXT({pref_dte}d)⭐")
                if put_pref:
                    all_opportunities['puts_preferred'].append(put_pref)
                    found_any = True
            
            # ALTERNATIVE: Current month (27 DTE)
            if alternative_expiry:
                alt_dte = (alternative_expiry - datetime.now().date()).days
                
                straddle_alt = scan_long_straddle(symbol, df, current_price, alternative_expiry, f"CUR({alt_dte}d)")
                if straddle_alt:
                    all_opportunities['straddles_alternative'].append(straddle_alt)
                    found_any = True
                
                strangle_alt = scan_long_strangle(symbol, df, current_price, alternative_expiry, f"CUR({alt_dte}d)")
                if strangle_alt:
                    all_opportunities['strangles_alternative'].append(strangle_alt)
                    found_any = True
                
                call_alt = scan_long_call(symbol, df, current_price, alternative_expiry, f"CUR({alt_dte}d)")
                if call_alt:
                    all_opportunities['calls_alternative'].append(call_alt)
                    found_any = True
                
                put_alt = scan_long_put(symbol, df, current_price, alternative_expiry, f"CUR({alt_dte}d)")
                if put_alt:
                    all_opportunities['puts_alternative'].append(put_alt)
                    found_any = True
            
            if found_any:
                print("✅", end='', flush=True)
            else:
                print("⚪", end='', flush=True)
            
            print()
            
        except Exception as e:
            print(f"❌ {str(e)[:40]}")
            fail_count += 1
            continue
    
    print("\n" + "=" * 100)
    print(f"SCAN COMPLETE - Success: {success_count}/{len(symbols)}, Failed: {fail_count}")
    print("=" * 100)
    
    # Display and save results
    strategy_groups = [
        ('LONG STRADDLE - NEXT MONTH (RECOMMENDED) ⭐', all_opportunities['straddles_preferred'], 'long_straddle_next_month.csv'),
        ('LONG STRADDLE - CURRENT MONTH (ALTERNATIVE)', all_opportunities['straddles_alternative'], 'long_straddle_current_month.csv'),
        ('LONG STRANGLE - NEXT MONTH (RECOMMENDED) ⭐', all_opportunities['strangles_preferred'], 'long_strangle_next_month.csv'),
        ('LONG STRANGLE - CURRENT MONTH (ALTERNATIVE)', all_opportunities['strangles_alternative'], 'long_strangle_current_month.csv'),
        ('LONG CALL - NEXT MONTH (RECOMMENDED) ⭐', all_opportunities['calls_preferred'], 'long_call_next_month.csv'),
        ('LONG CALL - CURRENT MONTH (ALTERNATIVE)', all_opportunities['calls_alternative'], 'long_call_current_month.csv'),
        ('LONG PUT - NEXT MONTH (RECOMMENDED) ⭐', all_opportunities['puts_preferred'], 'long_put_next_month.csv'),
        ('LONG PUT - CURRENT MONTH (ALTERNATIVE)', all_opportunities['puts_alternative'], 'long_put_current_month.csv'),
    ]
    
    for strategy_name, opportunities, filename in strategy_groups:
        print(f"\n{'='*100}")
        print(f"{strategy_name}: {len(opportunities)} opportunities")
        print(f"{'='*100}")
        
        if opportunities:
            df_result = pd.DataFrame(opportunities)
            df_result = df_result.sort_values('Score', ascending=False)
            
            pd.set_option('display.max_columns', None)
            pd.set_option('display.width', 200)
            pd.set_option('display.max_colwidth', 30)
            
            print(df_result.to_string(index=False))
            
            df_result.to_csv(filename, index=False)
            print(f"\n✅ Saved to {filename}")
            
            if 'Quality' in df_result.columns:
                print(f"\n📊 QUALITY BREAKDOWN:")
                for q, c in df_result['Quality'].value_counts().items():
                    print(f"   {q}: {c}")
            
            if 'DTE' in df_result.columns:
                print(f"\n⏱️  DTE RANGE:")
                print(f"   Min: {df_result['DTE'].min()} days")
                print(f"   Max: {df_result['DTE'].max()} days")
                print(f"   Avg: {df_result['DTE'].mean():.1f} days")
        else:
            print("No opportunities found.")
    
    # Summary
    print(f"\n{'='*100}")
    print("TOP OPPORTUNITIES BY CATEGORY")
    print(f"{'='*100}")
    
    # Combine preferred opportunities
    all_preferred = (
        all_opportunities['straddles_preferred'] +
        all_opportunities['strangles_preferred'] +
        all_opportunities['calls_preferred'] +
        all_opportunities['puts_preferred']
    )
    
    if all_preferred:
        top_preferred = pd.DataFrame(all_preferred).nlargest(5, 'Score')
        print(f"\n🏆 TOP 5 OVERALL (NEXT MONTH - RECOMMENDED):")
        for idx, row in top_preferred.iterrows():
            print(f"  {row['Symbol']}: {row['Strategy']} | Score={row['Score']} | Quality={row['Quality']} | Cost=₹{row.get('Total_Cost', row.get('Premium', 0))}")
    
    print(f"\n{'='*100}")
    print("KEY INSIGHTS")
    print(f"{'='*100}")
    
    total_opps = sum(len(opps) for opps in all_opportunities.values())
    pref_opps = sum(len(all_opportunities[k]) for k in all_opportunities if 'preferred' in k)
    alt_opps = sum(len(all_opportunities[k]) for k in all_opportunities if 'alternative' in k)
    
    print(f"Total Opportunities Found: {total_opps}")
    print(f"  • Next Month (Recommended): {pref_opps}")
    print(f"  • Current Month (Alternative): {alt_opps}")
    
    print(f"\n💡 TRADING GUIDELINES:")
    print(f"  ✅ Prefer NEXT MONTH expiry (lower daily theta, more time)")
    print(f"  ✅ Enter at EXCELLENT or GOOD quality only")
    print(f"  ✅ Target 50-100% return, stop at 40-50% loss")
    print(f"  ✅ Exit 2 weeks before expiry if not profitable")
    print(f"  ✅ Position size: 1-2% per trade, max 10% total")
    
    print(f"\n{'='*100}")
    print(f"Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*100}")

if __name__ == "__main__":
    run_long_options_scanner()