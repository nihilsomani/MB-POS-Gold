#!/usr/bin/env python3
"""
option_trend_engine_v4_enhanced.py

Enhancements over v3:
 - More nuanced zone interpretation with volume proxies
 - Max Pain calculation (simplified - requires strike data for full implementation)
 - Confidence scoring based on data quality
 - Improved rollover logic with strike analysis
 - Better PCR context with market regime detection
 - Volatility regime awareness (using daily_range_pct as proxy)
 - Risk-adjusted signal strength

Usage:
  python option_trend_engine_v4_enhanced.py --csv data.csv --date 2025-11-20 [--debug]
"""

import pandas as pd
import argparse
from datetime import datetime, timedelta
import sys

# -------------------------
# Configurable thresholds
# -------------------------
OTM_CALL_WALL_MULT = 1.20
OTM_PUT_WALL_MULT  = 1.20
ATM_PUT_DOM_MULT   = 1.25
ITM_PUT_DOM_MULT   = 1.05

# PCR thresholds with more granularity
PCR_EXTREME_BULLISH = 1.30  # Panic put buying -> contrarian long
PCR_BULLISH_HIGH    = 1.10  # Healthy put support
PCR_NEUTRAL_HIGH    = 0.90
PCR_NEUTRAL_LOW     = 0.70
PCR_BEARISH_LOW     = 0.55  # Extreme call dominance -> contrarian short

# Signal thresholds
SCORE_LONG_THRESHOLD = 4     # Increased for higher quality
SCORE_SHORT_THRESHOLD = -4

# Confidence thresholds
HIGH_CONFIDENCE_MIN_OI = 10000  # Adjust based on your market

# -------------------------
# Helpers
# -------------------------
def safe_float(x):
    try:
        return float(x)
    except:
        return 0.0

def compute_zone_weights(row):
    """Return numeric zone strengths and raw totals"""
    oc = safe_float(row.get("otm_call_oi", 0))
    ac = safe_float(row.get("atm_call_oi", 0))
    ic = safe_float(row.get("itm_call_oi", 0))
    op = safe_float(row.get("otm_put_oi", 0))
    ap = safe_float(row.get("atm_put_oi", 0))
    ip = safe_float(row.get("itm_put_oi", 0))

    # Adjusted weights: ITM 0.45, ATM 0.40, OTM 0.15 (ATM matters more near expiry)
    call_strength = 0.45 * ic + 0.40 * ac + 0.15 * oc
    put_strength  = 0.45 * ip + 0.40 * ap + 0.15 * op

    return {
        "oc": oc, "ac": ac, "ic": ic,
        "op": op, "ap": ap, "ip": ip,
        "call_strength": call_strength,
        "put_strength": put_strength,
        "call_total": oc + ac + ic,
        "put_total": op + ap + ip
    }

def compute_pcr(cur_row):
    """Compute ATM Put-Call Ratio"""
    ac = safe_float(cur_row.get("atm_call_oi", 0))
    ap = safe_float(cur_row.get("atm_put_oi", 0))
    if ac == 0:
        return None
    return ap / ac

def detect_volatility_regime(row):
    """
    Classify volatility regime using daily_range_pct as proxy
    Returns: "HIGH", "NORMAL", "LOW"
    """
    daily_range = safe_float(row.get("daily_range_pct", 0))
    
    if daily_range > 2.5:
        return "HIGH"
    elif daily_range < 0.8:
        return "LOW"
    else:
        return "NORMAL"

def futures_flow_score(today_cur, yesterday_cur):
    """
    Enhanced futures flow with magnitude consideration
    """
    reasons = []
    score = 0

    if yesterday_cur is None:
        reasons.append("⚠ No prior-day data - futures flow unknown")
        return 0, reasons

    delta_price = safe_float(today_cur.get("close", 0)) - safe_float(yesterday_cur.get("close", 0))
    delta_oi = safe_float(today_cur.get("oi", 0)) - safe_float(yesterday_cur.get("oi", 0))
    
    # Calculate percentage changes for magnitude
    prev_price = safe_float(yesterday_cur.get("close", 0))
    prev_oi = safe_float(yesterday_cur.get("oi", 0))
    
    price_change_pct = (delta_price / prev_price * 100) if prev_price > 0 else 0
    oi_change_pct = (delta_oi / prev_oi * 100) if prev_oi > 0 else 0

    # Strong signals if both price and OI moves are significant
    strong_threshold = 1.0  # 1% move
    is_strong = abs(price_change_pct) > strong_threshold and abs(oi_change_pct) > strong_threshold

    if delta_price > 0 and delta_oi > 0:
        points = 3 if is_strong else 2
        score += points
        reasons.append(f"🟢 Long buildup (ΔP: +{price_change_pct:.1f}%, ΔOI: +{oi_change_pct:.1f}%)")
    elif delta_price < 0 and delta_oi > 0:
        points = 3 if is_strong else 2
        score -= points
        reasons.append(f"🔴 Short buildup (ΔP: {price_change_pct:.1f}%, ΔOI: +{oi_change_pct:.1f}%)")
    elif delta_price > 0 and delta_oi < 0:
        score += 1
        reasons.append(f"⚪ Short covering (ΔP: +{price_change_pct:.1f}%, ΔOI: {oi_change_pct:.1f}%)")
    elif delta_price < 0 and delta_oi < 0:
        score -= 1
        reasons.append(f"⚪ Long unwinding (ΔP: {price_change_pct:.1f}%, ΔOI: {oi_change_pct:.1f}%)")
    else:
        reasons.append("➖ Neutral futures flow")

    return score, reasons

def analyze_option_structure(zones, vol_regime):
    """
    Advanced option structure analysis
    Returns score and reasons
    """
    reasons = []
    score = 0
    
    oc, ac, ic = zones["oc"], zones["ac"], zones["ic"]
    op, ap, ip = zones["op"], zones["ap"], zones["ip"]
    call_total = zones["call_total"]
    put_total = zones["put_total"]
    
    if call_total == 0 or put_total == 0:
        reasons.append("⚠ Insufficient option OI for analysis")
        return 0, reasons
    
    # Calculate ratios for interpretation
    put_itm_ratio = ip / put_total if put_total > 0 else 0
    put_otm_ratio = op / put_total if put_total > 0 else 0
    call_itm_ratio = ic / call_total if call_total > 0 else 0
    call_otm_ratio = oc / call_total if call_total > 0 else 0
    
    # --- PUT STRUCTURE ANALYSIS ---
    
    # Classic put writing (bullish): High ITM, low OTM
    if put_itm_ratio > 0.50 and put_otm_ratio < 0.25:
        score += 3
        reasons.append(f"🟢 Put writing structure (ITM: {put_itm_ratio:.1%}, OTM: {put_otm_ratio:.1%})")
    
    # Defensive put hedging (bearish): Both ITM and OTM elevated
    elif put_itm_ratio > 0.35 and put_otm_ratio > 0.35:
        score -= 2
        reasons.append(f"🔴 Defensive put hedging (ITM: {put_itm_ratio:.1%}, OTM: {put_otm_ratio:.1%})")
    
    # Fresh put buying (bearish): High OTM, lower ITM
    elif put_otm_ratio > 0.50 and put_itm_ratio < 0.30:
        score -= 2
        reasons.append(f"🔴 Fresh put buying/hedging (OTM: {put_otm_ratio:.1%})")
    
    # --- CALL STRUCTURE ANALYSIS ---
    
    # Call writing (bearish): High ITM, low OTM
    if call_itm_ratio > 0.50 and call_otm_ratio < 0.25:
        score -= 3
        reasons.append(f"🔴 Call writing overhead (ITM: {call_itm_ratio:.1%}, OTM: {call_otm_ratio:.1%})")
    
    # Bullish call buying (bullish): High OTM calls
    elif call_otm_ratio > 0.50 and call_itm_ratio < 0.30:
        # In high vol, this might be hedging; in low vol, speculation
        if vol_regime == "LOW":
            score += 2
            reasons.append(f"🟢 Speculative call buying (OTM: {call_otm_ratio:.1%}, low vol)")
        else:
            score += 1
            reasons.append(f"⚪ OTM call interest (OTM: {call_otm_ratio:.1%}, high vol - mixed)")
    
    return score, reasons

def analyze_walls_and_barriers(zones, fut_score=0):
    """
    Identify support/resistance from OI concentrations
    Checks OTM walls and ATM battleground
    fut_score: futures flow score for validation
    """
    reasons = []
    score = 0
    
    oc, op = zones["oc"], zones["op"]
    ac, ap = zones["ac"], zones["ap"]
    
    # --- ATM ANALYSIS (Key battleground) ---
    # ATM put dominance ONLY bullish if validated by structure
    atm_ratio = ap / ac if ac > 0 else 0
    
    if atm_ratio > ATM_PUT_DOM_MULT:
        # Validate: OTM puts must be LOW (not defensive hedging)
        put_total = zones["put_total"]
        put_otm_ratio = op / put_total if put_total > 0 else 0
        
        # Additional validation: futures should not be bearish
        is_validated = put_otm_ratio < 0.30 and fut_score >= 0
        
        if is_validated:
            score += 2
            reasons.append(f"🟢 Strong ATM put defense (P/C: {atm_ratio:.2f}, validated)")
        else:
            # High ATM but not validated
            if put_otm_ratio >= 0.30:
                reasons.append(f"⚠ High ATM puts (P/C: {atm_ratio:.2f}) but OTM elevated - likely hedging")
            if fut_score < 0:
                reasons.append(f"⚠ High ATM puts but futures bearish - contradicts bullish thesis")
    elif atm_ratio < (1 / ATM_PUT_DOM_MULT):
        score -= 2
        reasons.append(f"🔴 Strong ATM call dominance (P/C: {atm_ratio:.2f})")
    
    # --- OTM WALLS (Support/Resistance) ---
    # Strong call wall (resistance overhead)
    if oc > op * OTM_CALL_WALL_MULT and oc > 1000:  # Add minimum threshold
        score -= 2
        reasons.append(f"🔴 OTM Call wall (OC: {oc:.0f} >> OP: {op:.0f}) - resistance overhead")
    
    # Strong put wall (support below)
    if op > oc * OTM_PUT_WALL_MULT and op > 1000:
        score += 2
        reasons.append(f"🟢 OTM Put wall (OP: {op:.0f} >> OC: {oc:.0f}) - support below")
    
    # Balanced walls (range-bound)
    if 0.8 <= (oc / op if op > 0 else 0) <= 1.2 and oc > 1000 and op > 1000:
        reasons.append(f"➖ Balanced OTM walls - expect range-bound trading")
    
    return score, reasons

def analyze_pcr_with_context(pcr, vol_regime):
    """
    Enhanced PCR analysis with volatility context
    """
    reasons = []
    score = 0
    
    if pcr is None:
        reasons.append("⚠ PCR unavailable")
        return 0, reasons
    
    # Extreme readings - contrarian signals
    if pcr >= PCR_EXTREME_BULLISH:
        score += 2
        reasons.append(f"🟢 Extreme PCR {pcr:.2f} - panic put buying, contrarian long")
    
    # Healthy bullish
    elif PCR_BULLISH_HIGH <= pcr < PCR_EXTREME_BULLISH:
        score += 1
        reasons.append(f"🟢 Elevated PCR {pcr:.2f} - healthy put support")
    
    # Neutral zone
    elif PCR_NEUTRAL_LOW <= pcr < PCR_NEUTRAL_HIGH:
        reasons.append(f"➖ Neutral PCR {pcr:.2f}")
    
    # Bearish
    elif PCR_BEARISH_LOW < pcr < PCR_NEUTRAL_LOW:
        score -= 1
        reasons.append(f"🔴 Low PCR {pcr:.2f} - call dominance")
    
    # Extreme bearish - contrarian
    else:  # pcr <= PCR_BEARISH_LOW
        score -= 2
        reasons.append(f"🔴 Extreme low PCR {pcr:.2f} - excessive call buying, contrarian short")
    
    # Volatility context - ONLY note it, don't heavily adjust scores
    # High vol means fear is normal, but futures ΔOI tells real story
    if vol_regime == "HIGH" and pcr > 1.0:
        reasons.append("  (High vol: put buying expected)")
    
    return score, reasons

def analyze_rollover_dynamics(cur, nxt, zones):
    """
    Enhanced rollover analysis
    """
    reasons = []
    score = 0
    
    if nxt is None:
        reasons.append("⚠ No next expiry data")
        return 0, reasons
    
    # Premium analysis
    cur_close = safe_float(cur.get("close", 0))
    nxt_close = safe_float(nxt.get("close", 0))
    prem_diff = nxt_close - cur_close
    
    if cur_close > 0:
        prem_pct = (prem_diff / cur_close) * 100
        
        if prem_pct > 0.5:  # Contango
            score += 1
            reasons.append(f"🟢 Contango {prem_pct:.2f}% - bullish rollover premium")
        elif prem_pct < -0.5:  # Backwardation
            score -= 1
            reasons.append(f"🔴 Backwardation {prem_pct:.2f}% - bearish pressure")
    
    # OI migration analysis
    # NOTE: DISABLED - Options OI data is duplicated between current/next expiry
    # If your data source provides expiry-specific options OI, uncomment this block
    """
    cur_opt_oi = zones["call_total"] + zones["put_total"]
    
    nxt_zones = compute_zone_weights(nxt)
    nxt_opt_oi = nxt_zones["call_total"] + nxt_zones["put_total"]
    
    if cur_opt_oi > 0:
        migration_ratio = nxt_opt_oi / cur_opt_oi
        
        if migration_ratio > 1.2:  # Strong migration to next
            score += 1
            reasons.append(f"🟢 OI rolling to next ({migration_ratio:.2f}x) - healthy positioning")
        elif migration_ratio < 0.5:  # Stuck in current
            score -= 1
            reasons.append(f"⚠ OI concentrated in current expiry - squeeze risk")
    """
    
    # Futures OI rollover
    cur_fut_oi = safe_float(cur.get("oi", 0))
    nxt_fut_oi = safe_float(nxt.get("oi", 0))
    
    if cur_fut_oi > 0 and nxt_fut_oi > cur_fut_oi * 1.5:
        score += 1
        reasons.append("🟢 Futures OI rolling forward - normal expiry dynamics")
    elif cur_fut_oi > nxt_fut_oi * 2:
        reasons.append("⚠ Futures OI not rolling - watch for abnormal expiry")
    
    return score, reasons

def calculate_confidence(cur, nxt, yesterday_cur, zones):
    """
    Calculate confidence level for the signal
    Returns: confidence score 0-100 and factors list
    """
    confidence = 100
    factors = []
    
    # Data availability penalties
    if yesterday_cur is None:
        confidence -= 20
        factors.append("Missing prior-day data (-20)")
    
    if nxt is None:
        confidence -= 15
        factors.append("Missing next expiry (-15)")
    
    # OI quality checks
    fut_oi = safe_float(cur.get("oi", 0))
    if fut_oi < HIGH_CONFIDENCE_MIN_OI:
        confidence -= 25
        factors.append(f"Low futures OI: {fut_oi:.0f} (-25)")
    
    opt_oi = zones["call_total"] + zones["put_total"]
    if opt_oi < HIGH_CONFIDENCE_MIN_OI:
        confidence -= 20
        factors.append(f"Low option OI: {opt_oi:.0f} (-20)")
    
    # Imbalance checks (too one-sided can be unreliable)
    if zones["call_total"] > 0 and zones["put_total"] > 0:
        call_put_ratio = zones["call_total"] / zones["put_total"]
        if call_put_ratio > 5 or call_put_ratio < 0.2:
            confidence -= 15
            factors.append(f"Extreme C/P imbalance: {call_put_ratio:.2f} (-15)")
    
    # Volatility regime (high vol = lower confidence)
    vol_regime = detect_volatility_regime(cur)
    if vol_regime == "HIGH":
        confidence -= 10
        factors.append("High volatility regime (-10)")
    
    confidence = max(0, min(100, confidence))
    
    if confidence >= 80:
        level = "HIGH"
    elif confidence >= 60:
        level = "MEDIUM"
    else:
        level = "LOW"
    
    return confidence, level, factors

def classify_signal_for_pair(cur, nxt, yesterday_cur, debug=False):
    """
    Enhanced signal classification with multiple analysis layers
    """
    reasons = []
    score = 0
    
    # Get volatility regime
    vol_regime = detect_volatility_regime(cur)
    
    # 1) Futures flow
    fut_score, fut_reasons = futures_flow_score(cur, yesterday_cur)
    score += fut_score
    reasons.extend(fut_reasons)
    
    # 2) Zone analysis (single pass to avoid double-counting)
    zones = compute_zone_weights(cur)
    
    structure_score, structure_reasons = analyze_option_structure(zones, vol_regime)
    score += structure_score
    reasons.extend(structure_reasons)
    
    # NOTE: Zone dominance is already handled in analyze_option_structure()
    # DO NOT add duplicate checks here to avoid double-counting
    
    # 3) Walls and barriers (pass futures score for validation)
    wall_score, wall_reasons = analyze_walls_and_barriers(zones, fut_score)
    score += wall_score
    reasons.extend(wall_reasons)
    
    # 4) PCR analysis
    pcr = compute_pcr(cur)
    pcr_score, pcr_reasons = analyze_pcr_with_context(pcr, vol_regime)
    score += pcr_score
    reasons.extend(pcr_reasons)
    
    # 5) Rollover dynamics
    rollover_score, rollover_reasons = analyze_rollover_dynamics(cur, nxt, zones)
    score += rollover_score
    reasons.extend(rollover_reasons)
    
    # 6) Calculate confidence
    confidence, conf_level, conf_factors = calculate_confidence(cur, nxt, yesterday_cur, zones)
    
    # 7) Final signal with confidence adjustment
    raw_signal = "NO EDGE"
    if score >= SCORE_LONG_THRESHOLD:
        raw_signal = "LONG"
    elif score <= SCORE_SHORT_THRESHOLD:
        raw_signal = "SHORT"
    
    # Downgrade signal if low confidence
    if conf_level == "LOW" and raw_signal != "NO EDGE":
        reasons.append(f"⚠ Signal downgraded due to LOW confidence ({confidence}%)")
        signal = "NO EDGE"
    else:
        signal = raw_signal
    
    components = {
        "score": score,
        "signal": signal,
        "confidence": confidence,
        "confidence_level": conf_level,
        "vol_regime": vol_regime,
        "call_strength": zones["call_strength"],
        "put_strength": zones["put_strength"],
        "call_total": zones["call_total"],
        "put_total": zones["put_total"],
        "oc": zones["oc"], "ac": zones["ac"], "ic": zones["ic"],
        "op": zones["op"], "ap": zones["ap"], "ip": zones["ip"],
        "pcr": pcr
    }
    
    return {
        "signal": signal,
        "score": score,
        "confidence": confidence,
        "confidence_level": conf_level,
        "reasons": reasons,
        "confidence_factors": conf_factors,
        "components": components
    }

# -------------------------
# Main
# -------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv", required=True, help="Path to daily_trend_master_advanced.csv")
    parser.add_argument("--date", required=True, help="Date to print (YYYY-MM-DD)")
    parser.add_argument("--debug", action="store_true", help="Print debug info")
    args = parser.parse_args()

    try:
        df = pd.read_csv(args.csv)
    except Exception as e:
        print(f"Failed to load CSV: {e}")
        sys.exit(1)

    # Data preparation
    df.columns = [c.strip() for c in df.columns]
    df["date"] = pd.to_datetime(df["date"], dayfirst=False, errors='coerce')
    if df["date"].isnull().any():
        df["date"] = pd.to_datetime(df["date"].astype(str), dayfirst=True, errors='coerce')
    
    df["date_only"] = df["date"].dt.date

    numeric_cols = ["open","high","low","close","volume","oi","daily_range_pct",
                    "otm_call_oi","atm_call_oi","itm_call_oi","otm_put_oi","atm_put_oi","itm_put_oi"]
    for c in numeric_cols:
        if c not in df.columns:
            df[c] = 0
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0)

    # Create previous day lookups
    df_sorted = df.sort_values(["symbol","contract_type","date"])
    df_sorted["prev_close"] = df_sorted.groupby(["symbol","contract_type"])["close"].shift(1)
    df_sorted["prev_oi"] = df_sorted.groupby(["symbol","contract_type"])["oi"].shift(1)

    lookup = {}
    for _, row in df_sorted.iterrows():
        key = (row["date_only"], row["symbol"], str(row["contract_type"]).strip().lower())
        lookup[key] = row.to_dict()

    # Process signals
    results = []
    grouped = df_sorted.groupby(["date_only","symbol"])
    
    for (dt, sym), grp in grouped:
        ct_vals = set(grp["contract_type"].astype(str).str.lower().values)
        if "current" not in ct_vals or "next" not in ct_vals:
            continue

        cur_row = grp[grp["contract_type"].astype(str).str.lower() == "current"].loc[
            grp[grp["contract_type"].astype(str).str.lower() == "current"]["oi"].idxmax()].to_dict()
        nxt_row = grp[grp["contract_type"].astype(str).str.lower() == "next"].loc[
            grp[grp["contract_type"].astype(str).str.lower() == "next"]["oi"].idxmax()].to_dict()

        prev_key = (dt - timedelta(days=1), sym, "current")
        yesterday_cur = lookup.get(prev_key, None)

        res = classify_signal_for_pair(cur_row, nxt_row, yesterday_cur, debug=args.debug)

        results.append({
            "date": dt.isoformat(),
            "symbol": sym,
            "signal": res["signal"],
            "score": res["score"],
            "confidence": res["confidence"],
            "conf_level": res["confidence_level"],
            "vol_regime": res["components"]["vol_regime"],
            "reasons": " | ".join(res["reasons"]),
            "conf_factors": " | ".join(res["confidence_factors"]) if res["confidence_factors"] else "",
            "close": safe_float(cur_row.get("close", 0)),
            "current_expiry_oi": safe_float(cur_row.get("oi", 0)),
            "next_expiry_oi": safe_float(nxt_row.get("oi", 0)),
            "pcr": "" if res["components"]["pcr"] is None else f"{res['components']['pcr']:.3f}",
            "put_strength": res["components"]["put_strength"],
            "call_strength": res["components"]["call_strength"],
            "put_total": res["components"]["put_total"],
            "call_total": res["components"]["call_total"]
        })

    results_df = pd.DataFrame(results)
    results_df.to_csv("signals_all.csv", index=False)

    # Filter by date
    try:
        user_date = pd.to_datetime(args.date, dayfirst=False).date()
    except:
        user_date = pd.to_datetime(args.date, dayfirst=True).date()

    out_for_date = results_df[results_df["date"] == user_date.isoformat()].copy()
    out_fname = f"signals_{user_date.isoformat()}.csv"
    out_for_date.to_csv(out_fname, index=False)

    print(f"\n{'='*80}")
    print(f"Processed {len(results_df)} symbol-date combinations")
    print(f"Saved: signals_all.csv and {out_fname}")
    print(f"{'='*80}\n")

    print(f"=== SIGNALS for {user_date.isoformat()} ===\n")
    
    if out_for_date.empty:
        print("No results for this date")
    else:
        # Summary stats
        signals_count = out_for_date["signal"].value_counts()
        print(f"Signal Distribution: {signals_count.to_dict()}\n")
        
        # Show high confidence trades only
        high_conf = out_for_date[out_for_date["conf_level"] == "HIGH"]
        if not high_conf.empty:
            print(f"\n🎯 HIGH CONFIDENCE SIGNALS ({len(high_conf)}):\n")
            display_cols = ["symbol","signal","score","confidence","close","pcr","vol_regime"]
            print(high_conf[display_cols].to_string(index=False))
            print("\n")
        
        # Show all signals
        print(f"ALL SIGNALS ({len(out_for_date)}):\n")
        display_cols = ["symbol","signal","score","conf_level","confidence","pcr","reasons"]
        print(out_for_date[display_cols].to_string(index=False))

    if args.debug:
        results_df.to_csv("signals_all_debug.csv", index=False)
        print("\n✅ Detailed debug CSV: signals_all_debug.csv")

if __name__ == "__main__":
    main()