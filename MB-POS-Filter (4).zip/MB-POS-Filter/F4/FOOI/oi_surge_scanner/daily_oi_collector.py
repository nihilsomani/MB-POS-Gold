"""
DAILY OI COLLECTOR
==================

Collects end-of-day OI data for all F&O stocks
Builds historical database for backtesting

Run this DAILY at 3:30 PM to build your database!

Author: Your Trading System
"""

import pandas as pd
from kiteconnect import KiteConnect
from datetime import datetime
import time
import logging
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DailyOICollector:
    """
    Collects daily OI snapshots for backtesting
    """
    
    def __init__(self, api_key: str, access_token: str):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Load instruments
        self.instrument_cache = {}
        self._load_instruments()
    
    def _load_instruments(self):
        """Load NFO instruments"""
        logger.info("Loading instruments...")
        instruments = self.kite.instruments("NFO")
        
        for inst in instruments:
            symbol = inst['tradingsymbol']
            self.instrument_cache[symbol] = {
                'token': inst['instrument_token'],
                'strike': inst.get('strike', 0),
                'expiry': inst.get('expiry'),
                'instrument_type': inst.get('instrument_type', ''),
                'lot_size': inst.get('lot_size', 0),
                'underlying': inst.get('name', '')
            }
        
        logger.info(f"Loaded {len(self.instrument_cache)} instruments")
    
    def collect_eod_oi(self, symbols: list, output_file: str = "data/historical_oi.csv", date: str = None):
        """
        Collect end-of-day OI for all options AND futures
        
        Args:
            symbols: List of underlying symbols
            output_file: Where to save the data
            date: Date to collect for (YYYY-MM-DD format). If None, uses today.
        """
        # Use provided date or default to today
        if date:
            date_today = date
            logger.info(f"Collecting OI for specified date: {date_today}")
        else:
            date_today = datetime.now().strftime('%Y-%m-%d')
            logger.info(f"Collecting OI for today: {date_today}")
        
        logger.info("=" * 80)
        logger.info(f"COLLECTING EOD OI DATA - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info(f"Target Date: {date_today}")
        logger.info("=" * 80)
        
        data = []  # Initialize data list
        
        for symbol in symbols:
            logger.info(f"Processing {symbol}...")
            
            # Get FUTURES for this symbol (current month)
            futures = [
                (sym, info) for sym, info in self.instrument_cache.items()
                if info['underlying'] == symbol and info['instrument_type'] == 'FUT'
            ]
            
            # Collect futures OI
            for fut_symbol, fut_info in futures[:3]:  # Usually 3 expiries
                try:
                    key = f"NFO:{fut_symbol}"
                    quote = self.kite.quote([key])
                    
                    if key in quote:
                        q = quote[key]
                        
                        data.append({
                            'date': date_today,
                            'symbol': fut_symbol,
                            'underlying': symbol,
                            'strike': 0,  # N/A for futures
                            'type': 'FUT',
                            'expiry': fut_info['expiry'],
                            'ltp': q.get('last_price', 0),
                            'oi': q.get('oi', 0),
                            'volume': q.get('volume', 0),
                            'lot_size': fut_info['lot_size']
                        })
                    
                    time.sleep(0.1)
                
                except Exception as e:
                    logger.error(f"Error processing future {fut_symbol}: {e}")
                    continue
            
            # Get OPTIONS for this symbol (current month)
            options = [
                (sym, info) for sym, info in self.instrument_cache.items()
                if info['underlying'] == symbol and info['instrument_type'] in ['CE', 'PE']
            ]
            
            # Get quotes for all options in batches
            batch = []
            for opt_symbol, opt_info in options[:50]:  # Batch size 50
                try:
                    key = f"NFO:{opt_symbol}"
                    batch.append(key)
                    
                    if len(batch) == 50:  # Process batch
                        quotes = self.kite.quote(batch)
                        
                        for k in batch:
                            if k in quotes:
                                q = quotes[k]
                                opt_sym = k.replace("NFO:", "")
                                opt_info = self.instrument_cache[opt_sym]
                                
                                data.append({
                                    'date': date_today,
                                    'symbol': opt_sym,
                                    'underlying': symbol,
                                    'strike': opt_info['strike'],
                                    'type': opt_info['instrument_type'],
                                    'expiry': opt_info['expiry'],
                                    'ltp': q.get('last_price', 0),
                                    'oi': q.get('oi', 0),
                                    'volume': q.get('volume', 0),
                                    'lot_size': opt_info['lot_size']
                                })
                        
                        batch = []
                        time.sleep(0.35)  # Rate limiting
                
                except Exception as e:
                    logger.error(f"Error processing {opt_symbol}: {e}")
                    continue
            
            # Process remaining
            if batch:
                try:
                    quotes = self.kite.quote(batch)
                    for k in batch:
                        if k in quotes:
                            q = quotes[k]
                            opt_sym = k.replace("NFO:", "")
                            opt_info = self.instrument_cache[opt_sym]
                            
                            data.append({
                                'date': date_today,
                                'symbol': opt_sym,
                                'underlying': symbol,
                                'strike': opt_info['strike'],
                                'type': opt_info['instrument_type'],
                                'expiry': opt_info['expiry'],
                                'ltp': q.get('last_price', 0),
                                'oi': q.get('oi', 0),
                                'volume': q.get('volume', 0),
                                'lot_size': opt_info['lot_size']
                            })
                except Exception as e:
                    logger.error(f"Error in final batch: {e}")
        
        # Save to CSV
        if data:
            df = pd.DataFrame(data)
            
            # Create directory if needed
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # Append if file exists, create if not
            if os.path.exists(output_file):
                df.to_csv(output_file, mode='a', header=False, index=False)
                logger.info(f"✅ Appended {len(df)} records to {output_file}")
            else:
                df.to_csv(output_file, index=False)
                logger.info(f"✅ Created {output_file} with {len(df)} records")
            
            # Show summary
            futures_count = len(df[df['type'] == 'FUT'])
            options_count = len(df[df['type'].isin(['CE', 'PE'])])
            
            logger.info(f"Date: {date_today}")
            logger.info(f"Symbols: {len(symbols)}")
            logger.info(f"Futures tracked: {futures_count}")
            logger.info(f"Options tracked: {options_count}")
            logger.info(f"Total OI captured: {df['oi'].sum():,}")
        else:
            logger.warning("No data collected!")


def main():
    """
    Run daily OI collection
    
    Usage:
        # Collect for today (default)
        python daily_oi_collector.py
        
        # Collect for specific date
        python daily_oi_collector.py --date 2024-11-28
        
        # Collect for date range (backfill)
        python daily_oi_collector.py --start-date 2024-11-01 --end-date 2024-11-28
    """
    import argparse
    from datetime import timedelta  # Add this import
    
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Collect EOD OI data')
    parser.add_argument('--date', type=str, help='Specific date (YYYY-MM-DD)')
    parser.add_argument('--start-date', type=str, help='Start date for range (YYYY-MM-DD)')
    parser.add_argument('--end-date', type=str, help='End date for range (YYYY-MM-DD)')
    args = parser.parse_args()
    
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "egXi7wY9yjV71qKsoSEKyv0saJ9mvqMf"
    
    # Universe (load from CSV)
    universe_df = pd.read_csv("data/FNOStock.csv")
    UNIVERSE = universe_df.iloc[:, 0].tolist()
    
    # Initialize collector
    collector = DailyOICollector(API_KEY, ACCESS_TOKEN)
    
    # Determine what to collect
    if args.start_date and args.end_date:
        # Date range mode (backfill)
        logger.info("=" * 80)
        logger.info("BACKFILL MODE - Collecting for date range")
        logger.info("=" * 80)
        
        start = datetime.strptime(args.start_date, '%Y-%m-%d')
        end = datetime.strptime(args.end_date, '%Y-%m-%d')
        
        current = start
        days_collected = 0
        
        while current <= end:
            # Skip weekends
            if current.weekday() < 5:  # Monday=0, Friday=4
                date_str = current.strftime('%Y-%m-%d')
                logger.info(f"Collecting for {date_str}...")
                
                collector.collect_eod_oi(UNIVERSE, date=date_str)
                days_collected += 1
                
                # Sleep between days to avoid rate limits
                time.sleep(2)
            else:
                logger.info(f"Skipping {current.strftime('%Y-%m-%d')} (weekend)")
            
            current += timedelta(days=1)
        
        logger.info("=" * 80)
        logger.info(f"BACKFILL COMPLETE - {days_collected} days collected")
        logger.info("=" * 80)
    
    elif args.date:
        # Single date mode
        logger.info(f"Collecting for specific date: {args.date}")
        collector.collect_eod_oi(UNIVERSE, date=args.date)
    
    else:
        # Default: today
        logger.info("Collecting for today (default)")
        collector.collect_eod_oi(UNIVERSE)
    
    logger.info("=" * 80)
    logger.info("EOD OI COLLECTION COMPLETE!")
    logger.info("=" * 80)


if __name__ == "__main__":
    main()
