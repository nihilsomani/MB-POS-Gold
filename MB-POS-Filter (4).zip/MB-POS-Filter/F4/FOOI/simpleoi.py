import requests
import pandas as pd
import numpy as np
from datetime import datetime
import sys
from pathlib import Path

# Add path for config import
sys.path.insert(0, str(Path(__file__).parent.parent / "MBI"))

try:
    from kiteconnect import KiteConnect
    from config import API_KEY, ACCESS_TOKEN
    HAS_KITE = True
except ImportError:
    HAS_KITE = False
    print("Warning: KiteConnect not available. Will only show NSE bhavcopy OI.")


def get_nse_fut_oi(symbol, expiry, target_date=None):
    """
    Get OI from NSE bhavcopy (official source).
    
    Args:
        symbol: Stock symbol (e.g., "HINDALCO")
        expiry: Expiry date in format "YYYY-MM-DD" (e.g., "2025-11-25")
        target_date: Date to fetch bhavcopy for (default: today)
    """
    if target_date is None:
        target_date = datetime.today()
    else:
        target_date = datetime.strptime(target_date, "%Y-%m-%d")
    
    # Convert expiry to required NSE format (e.g., 25NOV2025)
    expiry_dt = datetime.strptime(expiry, "%Y-%m-%d")
    expiry_str = expiry_dt.strftime("%d%b%Y").upper()

    # Get bhavcopy URL for target_date
    date_str = target_date.strftime("%d%m%Y")
    month_str = target_date.strftime("%b").upper()
    year = target_date.year
    url = f"https://archives.nseindia.com/content/historical/DERIVATIVES/{year}/{month_str}/fo{date_str}bhav.csv.zip"

    print(f"Downloading NSE bhavcopy: {url}")
    try:
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        
        bhav_file = "bhav.zip"
        open(bhav_file, "wb").write(r.content)

        df = pd.read_csv(bhav_file)

        # Filter stock future row
        fut = df[
            (df["INSTRUMENT"] == "FUTSTK") &
            (df["SYMBOL"] == symbol.upper()) &
            (df["EXPIRY_DT"] == expiry_str)
        ]

        if fut.empty:
            print(f"No matching future found in NSE bhavcopy for {symbol} {expiry_str}.")
            return None

        oi = fut.iloc[0]["OPEN_INT"]
        close_price = fut.iloc[0]["CLOSE"]
        print(f"\nNSE Bhavcopy OI for {symbol} {expiry}: {oi:,}")
        print(f"NSE Bhavcopy Close: {close_price}")
        return {'oi': oi, 'close': close_price, 'source': 'NSE Bhavcopy'}
    except Exception as e:
        print(f"Error fetching NSE bhavcopy: {e}")
        return None


def get_kite_options_oi(symbol, expiry, target_date=None):
    """
    Get options OI (call and put) from KiteConnect API for a specific expiry.
    Uses historical_data() API to fetch historical OI for the target_date.
    
    Args:
        symbol: Stock symbol (e.g., "HINDALCO")
        expiry: Expiry date in format "YYYY-MM-DD" (e.g., "2025-11-25")
        target_date: Date to fetch data for (default: today)
    
    Returns:
        dict with 'options_call_oi', 'options_put_oi', 'options_total_oi', 'options_pcr'
    """
    if not HAS_KITE:
        return None
    
    if target_date is None:
        target_date = datetime.today().date()
    else:
        target_date = datetime.strptime(target_date, "%Y-%m-%d").date()
    
    try:
        kite = KiteConnect(api_key=API_KEY)
        kite.set_access_token(ACCESS_TOKEN)
        
        # Get all instruments
        instruments = kite.instruments("NFO")
        
        # Find options for the symbol and expiry
        expiry_dt = datetime.strptime(expiry, "%Y-%m-%d").date()
        options = [
            inst for inst in instruments
            if inst["segment"] == "NFO-OPT" 
            and inst["tradingsymbol"].startswith(symbol.upper())
            and pd.to_datetime(inst["expiry"]).date() == expiry_dt
        ]
        
        if not options:
            print(f"No options found for {symbol} with expiry {expiry}")
            return None
        
        print(f"Found {len(options)} option contracts for {symbol} {expiry}. Fetching historical OI for {target_date}...")
        print(f"This may take a while (fetching {len(options)} contracts)...")
        
        # Fetch historical_data() for each option contract
        from_date_str = target_date.strftime('%Y-%m-%d')
        to_date_str = target_date.strftime('%Y-%m-%d')
        
        total_call_oi = 0.0
        total_put_oi = 0.0
        successful_fetches = 0
        failed_fetches = 0
        
        # Process in batches with delay to respect rate limits
        import time
        for i, opt in enumerate(options):
            token = opt["instrument_token"]
            instrument_type = opt.get('instrument_type', '')
            
            try:
                # Fetch historical data for this option contract
                hist_data = kite.historical_data(
                    token,
                    from_date_str,
                    to_date_str,
                    interval="day",
                    oi=True,
                    continuous=False
                )
                
                if hist_data and len(hist_data) > 0:
                    hist_row = hist_data[0]
                    oi = hist_row.get('oi', 0) or 0
                    
                    if instrument_type == 'CE':
                        total_call_oi += oi
                    elif instrument_type == 'PE':
                        total_put_oi += oi
                    
                    successful_fetches += 1
                else:
                    failed_fetches += 1
                
                # Add delay to respect rate limits (every 10 contracts)
                if (i + 1) % 10 == 0:
                    time.sleep(0.5)  # 500ms delay every 10 contracts
                    if (i + 1) % 50 == 0:
                        print(f"  Progress: {i + 1}/{len(options)} contracts fetched...")
                
            except Exception as e:
                failed_fetches += 1
                if failed_fetches <= 5:  # Only print first 5 errors to avoid spam
                    print(f"  Warning: Failed to fetch OI for {opt.get('tradingsymbol')}: {e}")
                continue
        
        print(f"  Completed: {successful_fetches} successful, {failed_fetches} failed")
        
        if successful_fetches == 0:
            print(f"No historical OI data available for {symbol} {expiry} on {target_date}")
            return None
        
        total_oi = total_call_oi + total_put_oi
        pcr = (total_put_oi / total_call_oi) if total_call_oi > 0 else (float('inf') if total_put_oi > 0 else 1.0)
        
        return {
            'options_call_oi': total_call_oi if total_call_oi > 0 else None,
            'options_put_oi': total_put_oi if total_put_oi > 0 else None,
            'options_total_oi': total_oi if total_oi > 0 else None,
            'options_pcr': float(pcr) if not np.isinf(pcr) else None
        }
        
    except Exception as e:
        print(f"Error fetching options OI: {e}")
        import traceback
        traceback.print_exc()
        return None


def get_kite_oi(symbol, expiry, target_date=None):
    """
    Get OI from KiteConnect API (same logic as scanner).
    Prefers historical_data() OI (EOD settlement) over quote() OI.
    
    Args:
        symbol: Stock symbol (e.g., "HINDALCO")
        expiry: Expiry date in format "YYYY-MM-DD" (e.g., "2025-11-25")
        target_date: Date to fetch data for (default: today)
    """
    if not HAS_KITE:
        return None
    
    if target_date is None:
        target_date = datetime.today().date()
    else:
        target_date = datetime.strptime(target_date, "%Y-%m-%d").date()
    
    try:
        kite = KiteConnect(api_key=API_KEY)
        kite.set_access_token(ACCESS_TOKEN)
        
        # Get futures chain
        instruments = kite.instruments("NFO")
        futures = [
            inst for inst in instruments
            if inst["segment"] == "NFO-FUT" and inst["tradingsymbol"].startswith(symbol.upper())
        ]
        
        if not futures:
            print(f"No futures found for {symbol}")
            return None
        
        # Find matching expiry
        expiry_dt = datetime.strptime(expiry, "%Y-%m-%d").date()
        matching_fut = None
        for fut in futures:
            if pd.to_datetime(fut["expiry"]).date() == expiry_dt:
                matching_fut = fut
                break
        
        if not matching_fut:
            print(f"No future found with expiry {expiry}")
            return None
        
        token = matching_fut["instrument_token"]
        tradingsymbol = matching_fut["tradingsymbol"]
        
        # Method 1: Get quote() API data
        quote_key = f"NFO:{tradingsymbol}"
        quotes = kite.quote([quote_key])
        quote_data = quotes.get(quote_key) if quotes else None
        
        oi_from_quote = None
        price_from_quote = None
        if quote_data:
            oi_from_quote = quote_data.get('oi', 0)
            price_from_quote = quote_data.get('last_price')
        
        # Method 2: Get historical_data() OI (EOD settlement - preferred)
        oi_from_historical = None
        price_from_historical = None
        try:
            from_date_str = target_date.strftime('%Y-%m-%d')
            to_date_str = target_date.strftime('%Y-%m-%d')
            hist_data = kite.historical_data(
                token,
                from_date_str,
                to_date_str,
                interval="day",
                oi=True,
                continuous=False
            )
            if hist_data and len(hist_data) > 0:
                hist_row = hist_data[0]
                oi_from_historical = hist_row.get('oi', 0)
                price_from_historical = hist_row.get('close')
        except Exception as e:
            print(f"Error fetching historical_data: {e}")
        
        # Prefer historical_data() OI (EOD settlement) - same logic as scanner
        if oi_from_historical is not None and oi_from_historical > 0:
            final_oi = oi_from_historical
            final_price = price_from_historical if price_from_historical else price_from_quote
            oi_source = "historical_data (EOD settlement)"
            if oi_from_quote and abs(oi_from_historical - oi_from_quote) > 1000:
                print(f"\nKiteConnect Future OI (preferred): {final_oi:,} ({oi_source})")
                print(f"  Note: quote() OI={oi_from_quote:,} differs - using historical_data like scanner")
            else:
                print(f"\nKiteConnect Future OI: {final_oi:,} ({oi_source})")
        elif oi_from_quote:
            final_oi = oi_from_quote
            final_price = price_from_quote
            oi_source = "quote API (fallback - historical_data missing)"
            print(f"\nKiteConnect Future OI: {final_oi:,} ({oi_source})")
        else:
            print(f"\nKiteConnect: No OI data available")
            return None
        
        print(f"KiteConnect Close: {final_price}")
        return {'oi': final_oi, 'close': final_price, 'source': f'KiteConnect ({oi_source})'}
        
    except Exception as e:
        print(f"Error fetching KiteConnect data: {e}")
        return None


def compare_oi_sources(symbol, expiry, target_date=None, show_options=True):
    """
    Compare OI from NSE bhavcopy vs KiteConnect (scanner logic).
    Also shows options OI (call and put) if show_options=True.
    """
    print("=" * 80)
    print(f"OI COMPARISON: {symbol} - Expiry {expiry}")
    if target_date:
        print(f"Target Date: {target_date}")
    print("=" * 80)
    
    # Get NSE bhavcopy OI
    nse_data = get_nse_fut_oi(symbol, expiry, target_date)
    
    # Get KiteConnect Future OI (scanner logic)
    kite_data = get_kite_oi(symbol, expiry, target_date)
    
    # Get Options OI (call and put)
    options_data = None
    if show_options and HAS_KITE:
        print("\n" + "-" * 80)
        print("FETCHING OPTIONS OI...")
        print("-" * 80)
        options_data = get_kite_options_oi(symbol, expiry, target_date)
    
    # Compare Futures OI
    print("\n" + "=" * 80)
    print("FUTURES OI COMPARISON")
    print("=" * 80)
    
    if nse_data and kite_data:
        oi_diff = abs(nse_data['oi'] - kite_data['oi'])
        oi_diff_pct = (oi_diff / nse_data['oi']) * 100 if nse_data['oi'] > 0 else 0
        
        print(f"NSE Bhavcopy OI:     {nse_data['oi']:,}")
        print(f"KiteConnect OI:      {kite_data['oi']:,}")
        print(f"Difference:          {oi_diff:,} ({oi_diff_pct:.2f}%)")
        
        if oi_diff < 1000:
            print("Status: MATCH (difference < 1000)")
        else:
            print("Status: MISMATCH (difference >= 1000)")
        
        price_diff = abs(nse_data['close'] - kite_data['close']) if nse_data.get('close') and kite_data.get('close') else None
        if price_diff is not None:
            print(f"\nNSE Bhavcopy Close:  {nse_data['close']}")
            print(f"KiteConnect Close:   {kite_data['close']}")
            print(f"Price Difference:     {price_diff:.2f}")
    elif nse_data:
        print(f"NSE Bhavcopy OI:     {nse_data['oi']:,}")
        print("KiteConnect OI:      Not available")
    elif kite_data:
        print("NSE Bhavcopy OI:     Not available")
        print(f"KiteConnect OI:      {kite_data['oi']:,}")
    else:
        print("No data available from either source")
    
    # Show Options OI
    if show_options:
        print("\n" + "=" * 80)
        print("OPTIONS OI (KiteConnect API)")
        print("=" * 80)
        
        if options_data:
            call_oi = options_data.get('options_call_oi', 0) or 0
            put_oi = options_data.get('options_put_oi', 0) or 0
            total_oi = options_data.get('options_total_oi', 0) or 0
            pcr = options_data.get('options_pcr')
            
            print(f"Options Call OI:      {call_oi:,.0f}")
            print(f"Options Put OI:      {put_oi:,.0f}")
            print(f"Options Total OI:    {total_oi:,.0f}")
            if pcr is not None and not np.isinf(pcr):
                print(f"PCR (Put/Call):      {pcr:.4f}")
            else:
                print(f"PCR (Put/Call):      N/A")
        else:
            print("Options OI:           Not available")
    
    print("=" * 80)


# Example usage
if __name__ == "__main__":
    import sys
    
    if len(sys.argv) >= 3:
        symbol = sys.argv[1]
        expiry = sys.argv[2]
        target_date = sys.argv[3] if len(sys.argv) > 3 else None
        compare_oi_sources(symbol, expiry, target_date)
    else:
        # Default: HINDALCO 11/25/2025 for 11/13/2025
        compare_oi_sources("HINDALCO", "2025-11-25", "2025-11-10")
