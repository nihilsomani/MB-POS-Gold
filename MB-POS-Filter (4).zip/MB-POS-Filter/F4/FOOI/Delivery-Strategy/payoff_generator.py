"""
Fully Corrected Payoff Generator
- Adds explicit call_pnl column
- Corrects ROI
- Fixes price stepping
- Adds break-even row
- Clean payoff breakdown
"""

import pandas as pd
import numpy as np
from datetime import datetime
import os


def generate_payoff(spot, strike, premium, lot_size, strategy='50_50'):
    """
    Accurate payoff generator for hedged covered call strategies.
    """

    # === STRATEGY PARAMETERS ==========================================
    if strategy == '50_50':
        total_lots = 2
        hedged_lots = 1
        strategy_name = "50% Hedged"
    elif strategy == '100_hedged':
        total_lots = 1
        hedged_lots = 1
        strategy_name = "100% Hedged"
    else:  # 66_33
        total_lots = 3
        hedged_lots = 2
        strategy_name = "66% Hedged"

    total_shares = total_lots * lot_size
    hedged_shares = hedged_lots * lot_size
    unhedged_shares = total_shares - hedged_shares

    # One-time premium collected
    PREMIUM_COLLECTED = premium * hedged_shares

    # Investments
    GROSS_INVESTMENT = spot * total_shares
    NET_INVESTMENT = GROSS_INVESTMENT - PREMIUM_COLLECTED

    # Break-even (premium reduces cost)
    break_even = round(spot - premium, 2)

    # === PRICE RANGE (TRUE 1% STEPS + forced strike + BE row) =============
    price_range = []

    for pct in range(-15, 21):  # -15% to +20%
        price_range.append(round(spot * (1 + pct/100), 2))

    # Insert break-even if missing
    if break_even not in price_range:
        price_range.append(break_even)

    # Insert strike if missing
    if strike not in price_range:
        price_range.append(strike)

    price_range = sorted(price_range)

    # === CALCULATION LOOP ===============================================
    rows = []
    tol = spot * 0.003  # 0.3% tolerance for tagging ENTRY/STRIKE/BE

    for price in price_range:

        # ----- STOCK P&L -----
        hedged_stock_pnl = (min(price, strike) - spot) * hedged_shares
        unhedged_stock_pnl = (price - spot) * unhedged_shares

        # ----- CALL P&L (explicit call loss) -----
        call_intrinsic = max(0, price - strike)
        call_pnl = -call_intrinsic * hedged_shares     # loss after strike

        # ----- TOTAL P&L -----
        total_pnl = hedged_stock_pnl + unhedged_stock_pnl + call_pnl + PREMIUM_COLLECTED
        roi_pct = round((total_pnl / NET_INVESTMENT) * 100, 2)

        # ----- KEY TAGGING -----
        key = ""
        if abs(price - spot) <= tol:
            key = "ENTRY"
        elif abs(price - strike) <= tol:
            key = "STRIKE"
        elif abs(price - break_even) <= tol:
            key = "BREAKEVEN"

        rows.append({
            "price": price,
            "hedged_stock_pnl": round(hedged_stock_pnl, 2),
            "unhedged_stock_pnl": round(unhedged_stock_pnl, 2),
            "call_pnl": round(call_pnl, 2),              # NEW COLUMN
            "premium_collected": PREMIUM_COLLECTED,      # FIXED value
            "total_pnl": round(total_pnl, 2),
            "roi_pct": roi_pct,
            "key": key
        })

    df = pd.DataFrame(rows)

    # === SUMMARY =========================================================
    max_profit = df["total_pnl"].max()
    min_pnl = df["total_pnl"].min()
    max_roi = df["roi_pct"].max()
    min_roi = df["roi_pct"].min()

    print("\n" + "="*90)
    print(f"PAYOFF SUMMARY — {strategy_name}")
    print("="*90)
    print(f"Spot Price         : ₹{spot}")
    print(f"Strike Price       : ₹{strike}")
    print(f"Break-even Price   : ₹{break_even}")
    print(f"Premium Collected  : ₹{PREMIUM_COLLECTED:,}")
    print(f"Gross Investment   : ₹{GROSS_INVESTMENT:,}")
    print(f"Net Investment     : ₹{NET_INVESTMENT:,}")
    print("-"*90)
    print(f"Max Profit         : ₹{max_profit:,}")
    print(f"Max ROI            : {max_roi}%")
    print(f"Max Loss           : ₹{min_pnl:,}")
    print(f"Worst ROI          : {min_roi}%")
    print("="*90)

    # === SAVE FILE ======================================================
    filename = f"payoff_{strategy}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    df.to_csv(filename, index=False)
    print(f"\nSaved: {os.path.abspath(filename)}")

    return df
if __name__ == "__main__":
    print("\n=== Accurate Covered Call Payoff Generator ===\n")

    spot = float(input("Spot price: "))
    strike = float(input("Strike price: "))
    premium = float(input("Premium per share: "))
    lot_size = int(input("Lot size: "))

    print("\n1 = 50% Hedged\n2 = 100% Hedged\n3 = 66% Hedged\n4 = All\n")
    choice = input("Select strategy: ")

    strategies = {
        "1": ["50_50"],
        "2": ["100_hedged"],
        "3": ["66_33"],
        "4": ["50_50", "100_hedged", "66_33"]
    }.get(choice, ["50_50"])

    for s in strategies:
        print(f"\nGenerating payoff for {s}...")
        generate_payoff(spot, strike, premium, lot_size, s)
