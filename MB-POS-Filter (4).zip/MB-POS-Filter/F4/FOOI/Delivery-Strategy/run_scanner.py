"""
Simple script to run the Covered Call Scanner
Handles Kite Connect authentication and runs scans
"""

from kiteconnect import KiteConnect
from covered_call_scanner import CoveredCallScanner
import webbrowser
from urllib.parse import urlparse, parse_qs
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def get_access_token(api_key: str, api_secret: str) -> str:
    """
    Handle Kite Connect login flow to get access token
    
    Args:
        api_key: Your Kite API key
        api_secret: Your Kite API secret
        
    Returns:
        Access token string
    """
    kite = KiteConnect(api_key=api_key)
    
    # Generate login URL
    login_url = kite.login_url()
    
    print("\n" + "="*80)
    print("KITE CONNECT AUTHENTICATION")
    print("="*80)
    print("\n1. Opening browser for Kite login...")
    print("2. Login with your Kite credentials")
    print("3. After login, you'll be redirected to a URL")
    print("4. Copy the ENTIRE URL from your browser and paste it here\n")
    
    # Open browser
    webbrowser.open(login_url)
    
    # Get redirect URL from user
    redirect_url = input("Paste the redirect URL here: ").strip()
    
    # Extract request token from URL
    parsed = urlparse(redirect_url)
    params = parse_qs(parsed.query)
    
    if 'request_token' not in params:
        raise ValueError("Invalid URL - no request_token found")
    
    request_token = params['request_token'][0]
    
    # Generate access token
    data = kite.generate_session(request_token, api_secret=api_secret)
    access_token = data['access_token']
    
    print(f"\n✅ Authentication successful!")
    print(f"Access Token: {access_token}\n")
    print("💡 TIP: Save this token - it's valid till 6 AM next day")
    print("Add it to your config.py to skip login next time\n")
    
    return access_token


def quick_scan(symbols=None, capital=1000000):
    """
    Quick scan with manual credentials input
    
    Args:
        symbols: List of symbols to scan (None for default list)
        capital: Maximum capital available
    """
    print("\n" + "="*80)
    print("COVERED CALL SCANNER - QUICK START")
    print("="*80)
    
    # Get credentials
    print("\n📋 Enter your Kite Connect credentials")
    print("(Get them from https://kite.trade/ -> API -> Create App)\n")
    
    api_key = input("API Key: ").strip()
    api_secret = input("API Secret: ").strip()
    
    # Try to use saved token, otherwise do full login
    print("\nDo you have a saved access token? (yes/no)")
    has_token = input("Answer: ").strip().lower()
    
    if has_token in ['yes', 'y']:
        access_token = input("Enter your access token: ").strip()
    else:
        access_token = get_access_token(api_key, api_secret)
    
    # Initialize scanner
    print("\n🔍 Initializing scanner...")
    scanner = CoveredCallScanner(api_key, access_token)
    
    # Default stocks if none provided
    if symbols is None:
        symbols = [
            'UNIONBANK', 'BANKBARODA', 'SBIN', 'PNB', 'CANBK',
            'HDFCBANK', 'ICICIBANK', 'AXISBANK',
            'TCS', 'INFY', 'RELIANCE', 'ITC'
        ]
    
    print(f"\n📊 Scanning {len(symbols)} stocks with ₹{capital:,} capital...")
    
    # Run scan
    results = scanner.scan_covered_calls(
        symbols=symbols,
        max_capital=capital,
        min_score=50
    )
    
    if results.empty:
        print("\n❌ No opportunities found matching criteria")
        return
    
    # Display results
    print("\n" + "="*80)
    print("TOP COVERED CALL OPPORTUNITIES")
    print("="*80 + "\n")
    
    # Format output
    for idx, row in results.head(10).iterrows():
        print(f"{row['symbol']:12} | Strike: ₹{row['strike']:7.2f} ({row['otm_pct']:+5.2f}% OTM)")
        print(f"             | Premium: ₹{row['premium']:6.2f} ({row['premium_pct']:5.2f}% yield)")
        print(f"             | Max Profit: {row['max_profit_pct']:5.2f}% | Score: {row['score']:5.1f}/100 [{row['rating']}]")
        print(f"             | Capital: ₹{row['spot_price'] * row['lot_size'] * 2:,.0f} (2 lots)")
        print("-" * 80)
    
    # Get detailed report for best opportunity
    print("\n🎯 Generating detailed report for best opportunity...\n")
    
    best = results.iloc[0]
    report = scanner.generate_report(
        symbol=best['symbol'],
        strike=best['strike'],
        max_capital=capital
    )
    
    if 'error' not in report:
        print_detailed_report(report)
    
    # Save results
    output_file = '/mnt/user-data/outputs/covered_call_results.csv'
    results.to_csv(output_file, index=False)
    print(f"\n💾 Full results saved to: {output_file}")
    
    return results, report


def print_detailed_report(report):
    """Print a formatted detailed report"""
    
    print("="*80)
    print(f"DETAILED ANALYSIS: {report['symbol']}")
    print("="*80)
    
    print(f"\n📈 STOCK DETAILS")
    print(f"   Current Price: ₹{report['spot_price']:.2f}")
    print(f"   Lot Size: {report['lot_size']:,} shares")
    print(f"   Expiry: {report['expiry']} ({report['days_to_expiry']} days)")
    
    a = report['analysis']
    print(f"\n🎯 STRIKE ANALYSIS")
    print(f"   Strike: ₹{a['strike']:.2f} ({a['otm_pct']:+.2f}% from spot)")
    print(f"   Premium: ₹{a['premium']:.2f} ({a['premium_pct']:.2f}% of stock price)")
    print(f"   Total Premium Collected: ₹{a['total_premium']:,.2f}")
    print(f"   ")
    print(f"   Max Profit (if assigned): ₹{a['max_profit']:,.2f} ({a['max_profit_pct']:.2f}%)")
    print(f"   Breakeven: ₹{a['breakeven']:.2f} ({a['breakeven_pct']:.2f}% protection)")
    print(f"   Probability ITM: {a['prob_itm']:.1f}%")
    print(f"   ")
    print(f"   📊 SCORE: {a['score']:.1f}/100 ({a['rating']})")
    
    print(f"\n💰 POSITION SIZING")
    for pos in report['position_sizes']:
        print(f"\n   {pos['strategy']}:")
        print(f"   ├─ Buy: {pos['total_shares']:,} shares (₹{pos['capital_required']:,.0f})")
        print(f"   ├─ Sell: {pos['lots_to_sell']} lot(s) of {a['strike']} CE")
        print(f"   ├─ Hedged: {pos['hedged_shares']:,} | Unhedged: {pos['unhedged_shares']:,}")
        print(f"   └─ {pos['description']}")
    
    print(f"\n📊 PAYOFF SCENARIOS (Conservative Strategy)")
    print(f"{'Price':<10} {'P&L':<15} {'Return %':<12} {'Note'}")
    print("-" * 60)
    
    payoff = report['payoff_table']
    
    # Show key price levels
    key_prices = [
        report['spot_price'] * 0.95,  # -5%
        report['spot_price'] * 0.98,  # -2%
        report['spot_price'],          # Entry
        report['spot_price'] * 1.02,  # +2%
        a['strike'],                   # Strike
        report['spot_price'] * 1.08,  # +8%
    ]
    
    for price in key_prices:
        row = payoff.iloc[(payoff['price'] - price).abs().argsort()[:1]]
        note = ''
        if abs(price - report['spot_price']) < 0.5:
            note = '← ENTRY'
        elif abs(price - a['strike']) < 0.5:
            note = '← STRIKE (capped)'
        
        print(f"₹{row['price'].values[0]:<9.2f} ₹{row['total_pnl'].values[0]:>13,.0f} {row['return_pct'].values[0]:>10.2f}%  {note}")
    
    print("\n" + "="*80)


def analyze_specific_stock(symbol: str, capital: float = 500000):
    """
    Analyze a specific stock in detail
    
    Args:
        symbol: Stock symbol to analyze
        capital: Capital available
    """
    print(f"\n🔍 Analyzing {symbol}...")
    
    # Get credentials (simplified - you can modify this)
    try:
        from config import KITE_API_KEY, KITE_ACCESS_TOKEN
        api_key = KITE_API_KEY
        access_token = KITE_ACCESS_TOKEN
    except ImportError:
        print("No config.py found. Please enter credentials:")
        api_key = input("API Key: ").strip()
        access_token = input("Access Token: ").strip()
    
    scanner = CoveredCallScanner(api_key, access_token)
    
    # Scan just this stock
    results = scanner.scan_covered_calls(
        symbols=[symbol],
        max_capital=capital,
        min_score=0  # Show all strikes
    )
    
    if results.empty:
        print(f"❌ No options data found for {symbol}")
        return
    
    print(f"\n📊 All available strikes for {symbol}:")
    print("="*80)
    
    display_cols = [
        'strike', 'premium', 'premium_pct', 'otm_pct',
        'max_profit_pct', 'prob_itm', 'score', 'rating'
    ]
    
    print(results[display_cols].to_string(index=False))
    
    # Generate detailed report for best strike
    best = results.iloc[0]
    report = scanner.generate_report(symbol, best['strike'], capital)
    
    if 'error' not in report:
        print_detailed_report(report)
    
    return results


if __name__ == "__main__":
    import sys
    
    print("""
    ╔══════════════════════════════════════════════════════════════════════╗
    ║                    COVERED CALL SCANNER                              ║
    ║                  Find Best Premium Opportunities                     ║
    ╚══════════════════════════════════════════════════════════════════════╝
    """)
    
    # Choose mode
    print("Select mode:")
    print("1. Quick Scan (scan multiple stocks)")
    print("2. Analyze specific stock")
    print("3. Exit")
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice == '1':
        # Quick scan mode
        print("\nEnter capital available (or press Enter for ₹10,00,000):")
        capital_input = input("Capital: ").strip()
        capital = int(capital_input) if capital_input else 1000000
        
        results, report = quick_scan(capital=capital)
        
    elif choice == '2':
        # Specific stock analysis
        symbol = input("\nEnter stock symbol (e.g., UNIONBANK): ").strip().upper()
        
        print("Enter capital available (or press Enter for ₹5,00,000):")
        capital_input = input("Capital: ").strip()
        capital = int(capital_input) if capital_input else 500000
        
        results = analyze_specific_stock(symbol, capital)
        
    else:
        print("\n👋 Goodbye!")
        sys.exit(0)
    
    print("\n✅ Scan complete!")
