"""
Configuration file for Covered Call Scanner
Copy this to config.py and fill in your credentials
"""

# Kite Connect API Credentials
# Get these from https://kite.trade/ -> API -> Create App
KITE_API_KEY = "3bi2yh8g830vq3y6"
KITE_API_SECRET = "O8KUzM0GWNp18p8UwmtHIyGRALr7AuXK"

# You'll get this after login flow
# See: https://kite.trade/docs/connect/v3/user/#login-flow
KITE_ACCESS_TOKEN = "O8KUzM0GWNp18p8UwmtHIyGRALr7AuXK"

# Scanner Settings
SCANNER_CONFIG = {
    # Premium targets
    'min_premium_pct': 2.0,      # Minimum 2% premium to consider
    'ideal_premium_pct': 2.5,    # Sweet spot
    'max_premium_pct': 4.0,      # Above this is too risky (too ATM)
    
    # Strike selection
    'min_otm_pct': 2.0,          # Minimum 2% out of money
    'max_otm_pct': 8.0,          # Maximum 8% out of money
    
    # Scoring weights
    'premium_weight': 40,        # 40 points for premium quality
    'otm_weight': 30,            # 30 points for OTM distance
    'probability_weight': 30,    # 30 points for win probability
    
    # Capital management
    'max_capital': 1000000,      # Maximum capital (₹10L default)
    'min_score': 50,             # Minimum score to include in results
    
    # Stocks to scan (None = scan all F&O)
    'target_stocks': [
        # PSU Banks
        'UNIONBANK', 'BANKBARODA', 'SBIN', 'PNB', 'CANBK', 'IOB',
        
        # Private Banks
        'HDFCBANK', 'ICICIBANK', 'AXISBANK', 'KOTAKBANK', 'INDUSINDBK',
        
        # IT
        'TCS', 'INFY', 'WIPRO', 'HCLTECH', 'TECHM',
        
        # Auto
        'TATAMOTORS', 'MARUTI', 'M&M', 'EICHERMOT',
        
        # Others
        'RELIANCE', 'ITC', 'BHARTIARTL', 'SBIN', 'LT', 'TATASTEEL'
    ]
}

# Position Sizing Preferences
POSITION_CONFIG = {
    'preferred_strategy': 'conservative',  # 'conservative', 'balanced', or 'aggressive'
    'max_stocks': 5,                       # Maximum number of stocks in portfolio
    'rebalance_weekly': True,              # Roll positions weekly
}

# Risk Management
RISK_CONFIG = {
    'stop_loss_pct': 5.0,           # Exit if stock drops 5%
    'trailing_stop': True,           # Use trailing stops
    'max_drawdown_pct': 10.0,       # Maximum portfolio drawdown
    'position_size_pct': 20.0,      # Max 20% per position
}

# Notification Settings (optional)
NOTIFICATION_CONFIG = {
    'send_telegram': False,          # Send alerts to Telegram
    'telegram_bot_token': '',
    'telegram_chat_id': '',
    
    'send_email': False,             # Send email alerts
    'email_from': '',
    'email_to': '',
    'smtp_server': 'smtp.gmail.com',
    'smtp_port': 587,
}
