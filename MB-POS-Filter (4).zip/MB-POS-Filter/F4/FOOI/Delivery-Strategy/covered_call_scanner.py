"""
Batch Covered Call Scanner
Reads symbols from data/FNOStock.csv and scans all of them
"""

from kiteconnect import KiteConnect
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import os
import time

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class BatchCoveredCallScanner:
    """Scanner that processes multiple stocks from CSV"""
    
    def __init__(self, api_key: str, access_token: str):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Premium targets for monthly
        self.MIN_PREMIUM_PCT = 3.0   # 3%+ for monthly
        self.IDEAL_PREMIUM_PCT = 5.0
        self.MAX_PREMIUM_PCT = 10.0
        
        # Strike selection
        self.MIN_OTM_PCT = 3.0
        self.MAX_OTM_PCT = 15.0
        
        logger.info("BatchCoveredCallScanner initialized")
    
    def load_stock_list(self, csv_path: str = 'data/FNOStock.csv'):
        """Load stock list from CSV - only needs Symbol column"""
        try:
            if not os.path.exists(csv_path):
                logger.error(f"CSV file not found: {csv_path}")
                return []
            
            df = pd.read_csv(csv_path)
            
            # Extract symbols (handles both 'Symbol' and 'symbol' column names)
            if 'Symbol' in df.columns:
                symbols = df['Symbol'].tolist()
            elif 'symbol' in df.columns:
                symbols = df['symbol'].tolist()
            else:
                logger.error("CSV must have 'Symbol' column")
                return []
            
            # Remove any NaN values
            symbols = [s for s in symbols if pd.notna(s)]
            
            logger.info(f"Loaded {len(symbols)} stocks from {csv_path}")
            return symbols
            
        except Exception as e:
            logger.error(f"Error loading CSV: {e}")
            return []
    
    def get_stock_price(self, symbol: str):
        """Get current stock price"""
        try:
            quote = self.kite.quote(f"NSE:{symbol}")
            return quote[f"NSE:{symbol}"]['last_price']
        except Exception as e:
            logger.debug(f"Error fetching price for {symbol}: {e}")
            return None
    
    def get_lot_size(self, symbol: str):
        """Get lot size from instruments"""
        try:
            instruments = self.kite.instruments("NFO")
            for inst in instruments:
                if symbol in inst['tradingsymbol'] and inst['instrument_type'] == 'CE':
                    return inst['lot_size']
            return None
        except Exception as e:
            logger.debug(f"Error fetching lot size for {symbol}: {e}")
            return None
    
    def get_nearest_expiry(self, symbol: str):
        """Get nearest expiry for a symbol"""
        try:
            instruments = self.kite.instruments("NFO")
            
            expiries = set()
            for inst in instruments:
                if symbol in inst['tradingsymbol'] and inst['instrument_type'] == 'CE':
                    expiries.add(inst['expiry'])
            
            if not expiries:
                return None
            
            expiries = sorted(list(expiries))
            today = datetime.now().date()
            future_expiries = [exp for exp in expiries if exp >= today]
            
            return future_expiries[0] if future_expiries else None
            
        except Exception as e:
            logger.debug(f"Error getting expiry for {symbol}: {e}")
            return None
    
    def get_option_chain(self, symbol: str, expiry):
        """Get option chain"""
        try:
            instruments = self.kite.instruments("NFO")
            
            if isinstance(expiry, datetime):
                expiry_date = expiry.date()
            else:
                expiry_date = expiry
            
            options = [
                inst for inst in instruments
                if symbol in inst['tradingsymbol'] 
                and inst['expiry'] == expiry_date
                and inst['instrument_type'] == 'CE'
            ]
            
            if not options:
                return pd.DataFrame()
            
            # Get quotes in batches
            option_symbols = [f"NFO:{opt['tradingsymbol']}" for opt in options]
            all_quotes = {}
            
            for i in range(0, len(option_symbols), 100):
                batch = option_symbols[i:i+100]
                try:
                    quotes = self.kite.quote(batch)
                    all_quotes.update(quotes)
                    time.sleep(0.1)  # Rate limiting
                except Exception as e:
                    logger.debug(f"Error fetching quotes batch: {e}")
                    continue
            
            # Build chain
            chain_data = []
            for opt in options:
                symbol_key = f"NFO:{opt['tradingsymbol']}"
                if symbol_key in all_quotes:
                    quote = all_quotes[symbol_key]
                    chain_data.append({
                        'strike': opt['strike'],
                        'ltp': quote['last_price'],
                        'oi': quote.get('oi', 0),
                        'volume': quote.get('volume', 0),
                    })
            
            return pd.DataFrame(chain_data)
            
        except Exception as e:
            logger.debug(f"Error getting option chain: {e}")
            return pd.DataFrame()
    
    def find_best_strike(self, symbol: str, spot: float, expiry, lot_size: int, days_to_expiry: int):
        """Find best strike for a symbol"""
        try:
            chain = self.get_option_chain(symbol, expiry)
            if chain.empty:
                return None
            
            # Filter by OTM range
            otm_min = spot * (1 + self.MIN_OTM_PCT / 100)
            otm_max = spot * (1 + self.MAX_OTM_PCT / 100)
            
            valid = chain[
                (chain['strike'] >= otm_min) & 
                (chain['strike'] <= otm_max) &
                (chain['ltp'] > 0)
            ].copy()
            
            if valid.empty:
                # Fallback: get any strike with premium
                valid = chain[chain['ltp'] > 0].copy()
                if valid.empty:
                    return None
            
            # Score each strike
            best_score = -1
            best_strike = None
            
            for _, row in valid.iterrows():
                strike = row['strike']
                premium = row['ltp']
                
                otm_pct = ((strike - spot) / spot) * 100
                premium_pct = (premium / spot) * 100
                
                # Quick scoring
                score = 0
                
                # Premium score (prefer 3-5%)
                if premium_pct >= self.MIN_PREMIUM_PCT:
                    score += 40
                
                # OTM score (prefer 5-8%)
                if 5 <= otm_pct <= 8:
                    score += 30
                elif 3 <= otm_pct <= 10:
                    score += 20
                
                # Probability score
                prob_itm = max(5, min(95, 50 - otm_pct * 3))
                score += max(0, 30 - abs(prob_itm - 20) * 0.5)
                
                if score > best_score:
                    best_score = score
                    best_strike = {
                        'strike': strike,
                        'premium': premium,
                        'otm_pct': round(otm_pct, 2),
                        'premium_pct': round(premium_pct, 2),
                        'score': round(score, 1)
                    }
            
            return best_strike
            
        except Exception as e:
            logger.debug(f"Error finding best strike: {e}")
            return None
    
    def scan_all_stocks(self, csv_path: str = 'data/FNOStock.csv', 
                       max_capital: float = 500000,
                       min_score: float = 50):
        """
        Scan all stocks from CSV file
        CSV only needs 'Symbol' column - everything else fetched from API
        
        Args:
            csv_path: Path to CSV with stock symbols (only 'Symbol' column required)
            max_capital: Maximum capital available (default: ₹5L)
            min_score: Minimum score to include
        
        Returns:
            DataFrame with results
        """
        
        # Load stock list (just symbols)
        symbols = self.load_stock_list(csv_path)
        if not symbols:
            logger.error("No stocks to scan")
            return pd.DataFrame()
        
        logger.info(f"\n{'='*80}")
        logger.info(f"BATCH SCAN: {len(symbols)} stocks")
        logger.info(f"Max Capital: ₹{max_capital:,.0f}")
        logger.info(f"Min Score: {min_score}")
        logger.info(f"Fetching lot sizes and prices from API...")
        logger.info(f"{'='*80}\n")
        
        results = []
        
        for idx, symbol in enumerate(symbols, 1):
            try:
                logger.info(f"[{idx}/{len(symbols)}] Scanning {symbol}...")
                
                # Get spot price
                spot = self.get_stock_price(symbol)
                if spot is None:
                    logger.warning(f"  ❌ Could not fetch price")
                    continue
                
                # Get lot size
                lot_size = self.get_lot_size(symbol)
                if lot_size is None:
                    logger.warning(f"  ❌ Could not fetch lot size")
                    continue
                
                # Check capital
                capital_needed = spot * lot_size
                if capital_needed > max_capital:
                    logger.info(f"  ⚠️  Needs ₹{capital_needed:,.0f} (skipping)")
                    continue
                
                # Get expiry
                expiry = self.get_nearest_expiry(symbol)
                if expiry is None:
                    logger.warning(f"  ❌ No expiry found")
                    continue
                
                days_to_expiry = (expiry - datetime.now().date()).days
                
                # Find best strike
                best = self.find_best_strike(symbol, spot, expiry, lot_size, days_to_expiry)
                if best is None:
                    logger.warning(f"  ❌ No suitable strikes")
                    continue
                
                # Check score threshold
                if best['score'] < min_score:
                    logger.info(f"  ⚠️  Score {best['score']:.1f} below threshold")
                    continue
                
                # Calculate key metrics
                total_premium = best['premium'] * lot_size
                max_profit = (best['strike'] - spot) * lot_size + total_premium
                max_profit_pct = (max_profit / (spot * lot_size)) * 100
                
                result = {
                    'symbol': symbol,
                    'spot': spot,
                    'lot_size': lot_size,
                    'capital_needed': capital_needed,
                    'strike': best['strike'],
                    'premium': best['premium'],
                    'premium_pct': best['premium_pct'],
                    'otm_pct': best['otm_pct'],
                    'total_premium': round(total_premium, 0),
                    'max_profit': round(max_profit, 0),
                    'max_profit_pct': round(max_profit_pct, 2),
                    'days_to_expiry': days_to_expiry,
                    'expiry': expiry.strftime('%Y-%m-%d'),
                    'score': best['score']
                }
                
                results.append(result)
                
                logger.info(f"  ✅ {best['strike']} CE @ ₹{best['premium']:.2f} ({best['premium_pct']:.2f}%) Score: {best['score']:.1f}")
                
                # Rate limiting
                time.sleep(0.2)
                
            except Exception as e:
                logger.error(f"  ❌ Error scanning {symbol}: {e}")
                continue
        
        if not results:
            logger.warning("\n❌ No opportunities found")
            return pd.DataFrame()
        
        # Create DataFrame and sort
        df = pd.DataFrame(results)
        df = df.sort_values('score', ascending=False)
        
        logger.info(f"\n✅ Found {len(df)} opportunities")
        
        return df


def batch_scan(csv_path: str = 'data/FNOStock.csv', 
               capital: float = 500000,
               min_score: float = 50):
    """
    Run batch scan on all stocks in CSV
    CSV only needs 'Symbol' column - everything else auto-fetched
    """
    
    print("""
    ╔══════════════════════════════════════════════════════════════════════╗
    ║              BATCH COVERED CALL SCANNER                              ║
    ║           Scan multiple stocks from CSV file                         ║
    ╚══════════════════════════════════════════════════════════════════════╝
    """)
    
    # Get credentials
    try:
        from config import KITE_API_KEY, KITE_ACCESS_TOKEN
        api_key = KITE_API_KEY
        access_token = KITE_ACCESS_TOKEN
    except ImportError:
        print("\n⚠️  No config.py found. Enter credentials:")
        api_key = input("API Key: ").strip()
        access_token = input("Access Token: ").strip()
    
    # Initialize scanner
    scanner = BatchCoveredCallScanner(api_key, access_token)
    
    # Run batch scan
    results = scanner.scan_all_stocks(
        csv_path=csv_path,
        max_capital=capital,
        min_score=min_score
    )
    
    if results.empty:
        print("\n❌ No opportunities found")
        return
    
    # Display results
    print(f"\n{'='*80}")
    print(f"TOP COVERED CALL OPPORTUNITIES")
    print(f"{'='*80}\n")
    
    # Format display
    for idx, row in results.head(20).iterrows():
        print(f"{row['symbol']:12} @ ₹{row['spot']:7.2f} | Lot: {row['lot_size']:5}")
        print(f"  Strike: ₹{row['strike']:7.2f} ({row['otm_pct']:+5.2f}% OTM)")
        print(f"  Premium: ₹{row['premium']:6.2f} ({row['premium_pct']:5.2f}% yield)")
        print(f"  Max Profit: ₹{row['max_profit']:>9,.0f} ({row['max_profit_pct']:5.2f}%)")
        print(f"  Capital: ₹{row['capital_needed']:>9,.0f} | Score: {row['score']:5.1f}/100")
        print(f"  Expiry: {row['expiry']} ({row['days_to_expiry']} days)")
        print("-" * 80)
    
    # Summary statistics
    print(f"\n{'='*80}")
    print(f"SUMMARY")
    print(f"{'='*80}")
    print(f"Total opportunities: {len(results)}")
    print(f"Average premium: {results['premium_pct'].mean():.2f}%")
    print(f"Average score: {results['score'].mean():.1f}/100")
    print(f"Capital range: ₹{results['capital_needed'].min():,.0f} - ₹{results['capital_needed'].max():,.0f}")
    
    # Sector breakdown (if available in CSV)
    print(f"\nTop 5 by score:")
    for idx, row in results.head(5).iterrows():
        print(f"  {idx+1}. {row['symbol']:12} Score: {row['score']:5.1f} | Premium: {row['premium_pct']:5.2f}%")
    
    # Save results
    output_file = f'covered_call_scan_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    results.to_csv(output_file, index=False)
    print(f"\n💾 Results saved to: {os.path.abspath(output_file)}")
    
    return results


def filter_scan(csv_path: str = 'data/FNOStock.csv',
                capital: float = 500000,
                sector: str = None,
                min_premium_pct: float = 3.0):
    """
    Filtered scan with specific criteria
    Note: Sector filtering only works if CSV has 'Sector' column
    
    Args:
        csv_path: Path to stock CSV (only 'Symbol' required)
        capital: Max capital (default: ₹5L)
        sector: Filter by sector (only if CSV has 'Sector' column)
        min_premium_pct: Minimum premium percentage
    """
    
    print(f"\n🔍 Filtered Scan")
    print(f"   Capital: ₹{capital:,.0f}")
    if sector:
        print(f"   Sector: {sector}")
    print(f"   Min Premium: {min_premium_pct}%\n")
    
    # Load and filter stock list
    stock_df = pd.read_csv(csv_path)
    
    if sector:
        if 'Sector' in stock_df.columns:
            stock_df = stock_df[stock_df['Sector'] == sector]
            print(f"📊 Scanning {len(stock_df)} stocks in {sector} sector...")
        else:
            print(f"⚠️  CSV has no 'Sector' column. Scanning all stocks...")
    
    # Save filtered list temporarily
    temp_csv = 'temp_filtered_stocks.csv'
    
    # Only save Symbol column
    if 'Symbol' in stock_df.columns:
        stock_df[['Symbol']].to_csv(temp_csv, index=False)
    else:
        print("❌ CSV must have 'Symbol' column")
        return pd.DataFrame()
    
    # Run scan
    results = batch_scan(temp_csv, capital, min_score=50)
    
    # Filter by premium
    if results is not None and not results.empty:
        results = results[results['premium_pct'] >= min_premium_pct]
        print(f"\n✅ {len(results)} stocks meet all criteria")
    
    # Cleanup
    if os.path.exists(temp_csv):
        os.remove(temp_csv)
    
    return results


if __name__ == "__main__":
    import sys
    
    # Parse command line arguments
    mode = input("\nSelect mode:\n1. Scan all stocks\n2. Filter by sector\n3. Custom criteria\nChoice (1-3): ").strip()
    
    if mode == '1':
        # Scan all
        capital = input("Enter capital (default ₹5,00,000): ").strip()
        capital = int(capital) if capital else 500000
        
        results = batch_scan(capital=capital, min_score=50)
        
    elif mode == '2':
        # Filter by sector
        print("\n⚠️  Note: Sector filtering requires 'Sector' column in CSV")
        print("Available if you have it, otherwise all stocks will be scanned.\n")
        
        sector_choice = input("Enter sector name (or press Enter to skip): ").strip()
        capital = input("Enter capital (default ₹5,00,000): ").strip()
        capital = int(capital) if capital else 500000
        
        results = filter_scan(sector=sector_choice if sector_choice else None, capital=capital)
        
    elif mode == '3':
        # Custom criteria
        capital = input("Enter capital (default ₹5,00,000): ").strip()
        capital = int(capital) if capital else 500000
        
        min_premium = input("Min premium % (default 3.0): ").strip()
        min_premium = float(min_premium) if min_premium else 3.0
        
        min_score = input("Min score (default 50): ").strip()
        min_score = float(min_score) if min_score else 50
        
        results = batch_scan(capital=capital, min_score=min_score)
        
        if results is not None and not results.empty:
            results = results[results['premium_pct'] >= min_premium]
            print(f"\n✅ {len(results)} stocks meet criteria")
    
    print("\n✅ Scan complete!")