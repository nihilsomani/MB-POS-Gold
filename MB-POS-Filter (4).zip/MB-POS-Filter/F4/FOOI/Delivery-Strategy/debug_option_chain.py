"""
Standalone debug script to check option chain
No imports needed - all code included
"""

from kiteconnect import KiteConnect
import pandas as pd
from datetime import datetime

def debug_option_chain(symbol, api_key, access_token):
    """Show actual option chain to see what premium values exist"""
    
    print(f"""
    ╔══════════════════════════════════════════════════════════════════════╗
    ║              OPTION CHAIN DEBUG - {symbol:<12}                      ║
    ║         See actual premium values from Kite API                      ║
    ╚══════════════════════════════════════════════════════════════════════╝
    """)
    
    kite = KiteConnect(api_key=api_key)
    kite.set_access_token(access_token)
    
    # Get spot price
    try:
        quote = kite.quote(f"NSE:{symbol}")
        spot = quote[f"NSE:{symbol}"]['last_price']
        print(f"\n✅ Spot Price: ₹{spot:.2f}")
    except Exception as e:
        print(f"❌ Error fetching spot price: {e}")
        return None
    
    # Get expiry
    try:
        instruments = kite.instruments("NFO")
        expiries = set()
        for inst in instruments:
            if symbol in inst['tradingsymbol'] and inst['instrument_type'] == 'CE':
                expiries.add(inst['expiry'])
        
        if not expiries:
            print(f"❌ No expiries found for {symbol}")
            return None
        
        expiries = sorted(list(expiries))
        today = datetime.now().date()
        future_expiries = [exp for exp in expiries if exp >= today]
        
        if not future_expiries:
            print(f"❌ No future expiries")
            return None
        
        expiry = future_expiries[0]
        days_to_expiry = (expiry - today).days
        
        print(f"✅ Expiry: {expiry.strftime('%Y-%m-%d')} ({days_to_expiry} days)")
        
    except Exception as e:
        print(f"❌ Error fetching expiry: {e}")
        return None
    
    # Get option chain
    try:
        print(f"\n⏳ Fetching option chain...")
        
        options = [
            inst for inst in instruments
            if symbol in inst['tradingsymbol'] 
            and inst['expiry'] == expiry
            and inst['instrument_type'] == 'CE'
        ]
        
        if not options:
            print(f"❌ No call options found")
            return None
        
        print(f"✅ Found {len(options)} strikes")
        
        # Get quotes in batches
        option_symbols = [f"NFO:{opt['tradingsymbol']}" for opt in options]
        all_quotes = {}
        
        print(f"⏳ Fetching premiums...")
        for i in range(0, len(option_symbols), 100):
            batch = option_symbols[i:i+100]
            quotes = kite.quote(batch)
            all_quotes.update(quotes)
        
        # Build chain data
        chain_data = []
        for opt in options:
            symbol_key = f"NFO:{opt['tradingsymbol']}"
            if symbol_key in all_quotes:
                quote = all_quotes[symbol_key]
                chain_data.append({
                    'strike': opt['strike'],
                    'ltp': quote['last_price'],
                    'oi': quote.get('oi', 0),
                    'volume': quote.get('volume', 0),
                })
        
        df = pd.DataFrame(chain_data)
        
        if df.empty:
            print(f"❌ No option data")
            return None
        
        print(f"✅ Got premium data for {len(df)} strikes")
        
    except Exception as e:
        print(f"❌ Error fetching option chain: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    # Show option chain
    print(f"\n{'='*80}")
    print(f"OPTION CHAIN NEAR SPOT")
    print(f"{'='*80}")
    
    # Filter for strikes near spot (±10%)
    min_strike = spot * 0.90
    max_strike = spot * 1.10
    
    filtered = df[(df['strike'] >= min_strike) & (df['strike'] <= max_strike)].copy()
    
    if filtered.empty:
        print("⚠️  No strikes in ±10% range, showing all:")
        filtered = df.copy()
    
    filtered['otm_pct'] = ((filtered['strike'] - spot) / spot) * 100
    filtered['premium_pct'] = (filtered['ltp'] / spot) * 100
    filtered = filtered.sort_values('strike')
    
    print(f"\n{'Strike':<10} {'Premium':<12} {'Prem %':<10} {'OTM %':<10} {'OI':<12} {'Volume':<10}")
    print("-" * 70)
    
    for _, row in filtered.iterrows():
        # Marker for special prices
        marker = ""
        if abs(row['strike'] - spot) < 50:
            marker = " ← Near spot"
        elif row['ltp'] == 0:
            marker = " ← NO PREMIUM!"
        elif row['otm_pct'] > 3 and row['otm_pct'] < 6 and row['ltp'] > 0:
            marker = " ← Good range"
        
        print(f"₹{row['strike']:<9.2f} ₹{row['ltp']:<11.2f} {row['premium_pct']:<9.2f}% {row['otm_pct']:>8.2f}% {row['oi']:>10,.0f} {row['volume']:>9,.0f}{marker}")
    
    # Statistics
    print(f"\n{'='*80}")
    print("STATISTICS")
    print(f"{'='*80}")
    
    total = len(filtered)
    with_premium = len(filtered[filtered['ltp'] > 0])
    zero_premium = len(filtered[filtered['ltp'] == 0])
    
    print(f"\nStrikes in range: {total}")
    print(f"With premium > 0: {with_premium}")
    print(f"With 0 premium: {zero_premium}")
    
    if with_premium > 0:
        print(f"\n✅ GOOD! {with_premium} strikes have actual premium")
        
        # Recommend strikes
        good_strikes = filtered[filtered['ltp'] > 0].copy()
        
        # Find strikes with good premium (>2% of stock) and reasonable OTM (2-6%)
        recommended = good_strikes[
            (good_strikes['premium_pct'] >= 2.0) & 
            (good_strikes['otm_pct'] >= 2.0) & 
            (good_strikes['otm_pct'] <= 6.0)
        ]
        
        if not recommended.empty:
            print(f"\n🎯 RECOMMENDED STRIKES (2-6% OTM, 2%+ premium):")
            for _, row in recommended.iterrows():
                print(f"   ₹{row['strike']:.2f} → Premium: ₹{row['ltp']:.2f} ({row['premium_pct']:.2f}%, {row['otm_pct']:+.2f}% OTM)")
        else:
            print(f"\n💡 Available strikes with premium:")
            for _, row in good_strikes.head(5).iterrows():
                print(f"   ₹{row['strike']:.2f} → Premium: ₹{row['ltp']:.2f} ({row['premium_pct']:.2f}%, {row['otm_pct']:+.2f}% OTM)")
    else:
        print(f"\n❌ PROBLEM! No strikes have premium > 0")
        print(f"   Possible reasons:")
        print(f"   - Market is closed")
        print(f"   - Stock is very illiquid")
        print(f"   - API issue")
    
    return filtered


if __name__ == "__main__":
    import sys
    
    # Get credentials
    try:
        from config import KITE_API_KEY, KITE_ACCESS_TOKEN
        api_key = KITE_API_KEY
        access_token = KITE_ACCESS_TOKEN
        print("✅ Loaded credentials from config.py")
    except ImportError:
        print("\n⚠️  No config.py found.")
        api_key = input("API Key: ").strip()
        access_token = input("Access Token: ").strip()
    
    # Get symbol
    if len(sys.argv) > 1:
        symbol = sys.argv[1].upper()
    else:
        symbol = input("\nEnter symbol (e.g., DIVISLAB): ").strip().upper()
    
    # Run debug
    chain = debug_option_chain(symbol, api_key, access_token)
    
    if chain is not None and not chain.empty:
        print(f"\n{'='*80}")
        print("NEXT STEPS")
        print(f"{'='*80}")
        
        good_strikes = chain[chain['ltp'] > 0]
        
        if not good_strikes.empty:
            best_strike = good_strikes.iloc[0]['strike']
            print(f"\n✅ Premium data exists!")
            print(f"\nTo generate payoff, run:")
            print(f"  python payoff_generator.py")
            print(f"  Symbol: {symbol}")
            print(f"  Strike: {best_strike:.2f}  ← Use this!")
            
            print(f"\nOr use simple_payoff_generator.py:")
            print(f"  python simple_payoff_generator.py")
            print(f"  Spot: {chain.iloc[0]['strike']:.2f}  (check actual spot)")
            print(f"  Strike: {best_strike:.2f}")
            print(f"  Premium: {good_strikes.iloc[0]['ltp']:.2f}")
        else:
            print(f"\n❌ No tradeable strikes found")
            print(f"   Try a different stock or wait for market to open")
    else:
        print(f"\n❌ Could not fetch option chain")
        print(f"   Check your API credentials and try again")