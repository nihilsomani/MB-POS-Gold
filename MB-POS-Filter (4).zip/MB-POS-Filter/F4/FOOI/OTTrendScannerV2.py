import os
import time
import logging
from datetime import datetime, timedelta, date
from pathlib import Path
from typing import List, Dict, Optional

import numpy as np
import pandas as pd

from OITrendScanner import TrendScanner  # Reuse existing fetch utilities

# Configure separate logger for daily snapshot scanner
# Note: We create a new logger with a file handler, but don't call basicConfig again
# since OITrendScanner already configured the root logger
logger = logging.getLogger("OTTrendScannerV2")
logger.setLevel(logging.INFO)

# Add file handler if not already present
if not any(isinstance(h, logging.FileHandler) and h.baseFilename.endswith("daily_trend_scanner.log") 
          for h in logger.handlers):
    file_handler = logging.FileHandler("daily_trend_scanner.log")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s'))
    logger.addHandler(file_handler)
    
    # Also add stream handler if not present
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(logging.INFO)
        stream_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s'))
        logger.addHandler(stream_handler)

MASTER_DATA_PATH = Path("data/daily_trend_master.csv")
DEFAULT_HISTORY_DAYS = 21   # initial seed window if no master file exists yet (≈15+ trading days)
MAX_DATA_RETENTION_DAYS = 21  # Maximum days of data to retain (older data will be removed)
API_DELAY_SECONDS = 0.5      # delay between API calls to respect rate limits (500ms)

# Minimum start date: Only fetch and retain data from 2025-11-19 onwards
MIN_START_DATE = date(2025, 11, 19)


class DailyMasterStore:
    """Handles persistence of raw day-level snapshots."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> pd.DataFrame:
        if not self.path.exists():
            return pd.DataFrame()
        try:
            df = pd.read_csv(self.path, parse_dates=['date'])
            df['date'] = df['date'].dt.date
            return df
        except Exception as exc:
            logger.error(f"Failed to read master daily file {self.path}: {exc}")
            return pd.DataFrame()

    def append_rows(self, rows: List[Dict]):
        if not rows:
            logger.info("[SAVE] No new daily rows to append.")
            return

        logger.info(f"[SAVE] Preparing to save {len(rows)} rows to master file")
        new_df = pd.DataFrame(rows)
        new_df['date'] = pd.to_datetime(new_df['date']).dt.date
        
        # Log sample of rows being saved
        if len(rows) > 0:
            sample_row = rows[0]
            logger.info(f"[SAVE] Sample row being saved: symbol={sample_row.get('symbol')}, date={sample_row.get('date')}, contract_type={sample_row.get('contract_type')}, close={sample_row.get('close')}, oi={sample_row.get('oi'):,.0f}")
            # Log all unique dates being saved
            dates_in_rows = sorted(set(r.get('date') for r in rows))
            logger.info(f"[SAVE] Dates in rows being saved: {dates_in_rows}")

        if self.path.exists():
            existing_df = self.load()
            existing_count = len(existing_df)
            logger.info(f"[SAVE] Existing file has {existing_count} rows")
            
            # Check for duplicates before combining
            if not existing_df.empty and not new_df.empty:
                existing_dates = set(existing_df['date'].unique())
                new_dates = set(new_df['date'].unique())
                overlap = existing_dates & new_dates
                if overlap:
                    logger.info(f"[SAVE] Date overlap detected: {sorted(overlap)} - these will be overwritten with new data (keep='last')")
                    # Check for exact duplicates (same symbol, contract_type, date) in new_df itself
                    new_df_duplicates = new_df.duplicated(subset=['symbol', 'contract_type', 'date'], keep=False)
                    if new_df_duplicates.any():
                        num_dups_in_new = new_df_duplicates.sum()
                        logger.warning(f"[SAVE] WARNING: Found {num_dups_in_new} duplicate rows within new data itself (before combining with existing)!")
                        dup_samples = new_df[new_df_duplicates].groupby(['symbol', 'contract_type', 'date']).size()
                        logger.warning(f"[SAVE]   Duplicate groups: {dup_samples.to_dict()}")
                    
                    # Check specific symbols/dates that will be overwritten
                    for date_val in overlap:
                        existing_for_date = existing_df[existing_df['date'] == date_val]
                        new_for_date = new_df[new_df['date'] == date_val]
                        logger.info(f"[SAVE]   Date {date_val}: {len(existing_for_date)} existing rows, {len(new_for_date)} new rows")
                        # Log sample of what will be overwritten
                        if not existing_for_date.empty and not new_for_date.empty:
                            sample_existing = existing_for_date.iloc[0]
                            sample_new = new_for_date.iloc[0]
                            if sample_existing['symbol'] == sample_new['symbol'] and sample_existing['contract_type'] == sample_new['contract_type']:
                                logger.info(f"[SAVE]     {sample_existing['symbol']} {sample_existing['contract_type']}: OLD Close={sample_existing.get('close')}, OI={sample_existing.get('oi'):,.0f} -> NEW Close={sample_new.get('close')}, OI={sample_new.get('oi'):,.0f}")
            
            combined = pd.concat([existing_df, new_df], ignore_index=True)
            before_dedup = len(combined)
            
            # Count duplicates by type
            duplicates_with_existing = combined.duplicated(subset=['symbol', 'contract_type', 'date'], keep=False)
            if duplicates_with_existing.any():
                dup_df = combined[duplicates_with_existing]
                # Separate into: duplicates that exist in both existing and new (expected for EOD updates) vs duplicates within new_df itself (unexpected)
                new_symbols_dates = set(zip(new_df['symbol'], new_df['contract_type'], new_df['date']))
                dup_in_new_only = dup_df[dup_df.apply(lambda row: (row['symbol'], row['contract_type'], row['date']) in new_symbols_dates, axis=1)]
                dup_between_existing_new = dup_df[~dup_df.index.isin(dup_in_new_only.index)]
                
                if not dup_in_new_only.empty:
                    logger.warning(f"[SAVE] WARNING: {len(dup_in_new_only)} duplicates found within new data itself (unexpected - should be filtered before saving)")
                if not dup_between_existing_new.empty:
                    logger.info(f"[SAVE] {len(dup_between_existing_new)} duplicates between existing and new data (expected for EOD updates - will keep new data)")
            
            combined.drop_duplicates(subset=['symbol', 'contract_type', 'date'], keep='last', inplace=True)
            after_dedup = len(combined)
            if before_dedup != after_dedup:
                logger.info(f"[SAVE] Deduplication: {before_dedup} rows -> {after_dedup} rows (removed {before_dedup - after_dedup} duplicates)")
                logger.info(f"[SAVE]   This is expected when updating existing dates with new data (EOD updates, quote() API data, etc.)")
        else:
            logger.info(f"[SAVE] Creating new master file (no existing file)")
            combined = new_df.drop_duplicates(subset=['symbol', 'contract_type', 'date'], keep='last')

        # CRITICAL: Remove data older than MAX_DATA_RETENTION_DAYS AND before MIN_START_DATE (2025-11-19)
        # This ensures we only maintain the last 21 days of data AND ignore anything before 11/19
        today = datetime.now().date()
        from datetime import date as date_type
        MIN_START_DATE = date_type(2025, 11, 19)  # Minimum start date: 2025-11-19
        cutoff_date = max(MIN_START_DATE, today - timedelta(days=MAX_DATA_RETENTION_DAYS))
        
        before_cleanup = len(combined)
        combined = combined[combined['date'] >= cutoff_date].copy()
        # Also remove anything before MIN_START_DATE (double check)
        combined = combined[combined['date'] >= MIN_START_DATE].copy()
        after_cleanup = len(combined)
        
        if before_cleanup > after_cleanup:
            removed_count = before_cleanup - after_cleanup
            logger.info(f"[SAVE] Cleaned up {removed_count} rows older than {MAX_DATA_RETENTION_DAYS} days or before {MIN_START_DATE} (cutoff: {cutoff_date}). Kept {after_cleanup} rows from {MIN_START_DATE} onwards (last {MAX_DATA_RETENTION_DAYS} days).")
        
        combined.sort_values(['symbol', 'contract_type', 'date'], inplace=True)
        combined.to_csv(self.path, index=False)
        logger.info(f"[SAVE] Master daily file updated -> {self.path} ({len(combined)} rows, last {MAX_DATA_RETENTION_DAYS} days only).")
        
        # Verify saved data for end_date if it was in the rows
        if rows:
            end_dates_in_rows = set(r.get('date') for r in rows)
            for end_date_val in end_dates_in_rows:
                saved_for_date = combined[combined['date'] == end_date_val]
                if not saved_for_date.empty:
                    sample_saved = saved_for_date.iloc[0]
                    logger.info(f"[SAVE] Verification: Saved data for {end_date_val} - {sample_saved['symbol']} {sample_saved['contract_type']}: Close={sample_saved.get('close')}, OI={sample_saved.get('oi'):,.0f}")


class OTTrendScannerV2:
    """
    Captures raw per-day futures/oi fields to build a longitudinal master sheet.
    First run seeds DEFAULT_HISTORY_DAYS; subsequent runs append only new sessions.
    """

    def __init__(self, api_key: str, access_token: str,
                 symbols_csv: str = "data/FNOStock.csv",
                 master_path: Path = MASTER_DATA_PATH):
        self.base_scanner = TrendScanner(api_key=api_key,
                                         access_token=access_token,
                                         input_csv=symbols_csv,
                                         max_workers=1)  # sequential fetching for clarity
        self.store = DailyMasterStore(master_path)

    def _is_market_open(self) -> bool:
        """Check if market is currently open (9:15 AM - 3:30 PM IST)"""
        now = datetime.now(self.base_scanner.ist_timezone)
        current_time = now.time()
        
        market_open = datetime.strptime('09:15', '%H:%M').time()
        market_close = datetime.strptime('15:30', '%H:%M').time()
        
        is_open = market_open <= current_time <= market_close
        if is_open:
            logger.info(f"Market is currently OPEN (current time: {current_time.strftime('%H:%M:%S')} IST)")
        else:
            logger.info(f"Market is CLOSED (current time: {current_time.strftime('%H:%M:%S')} IST)")
        return is_open

    def _determine_fetch_window(self, existing_df: pd.DataFrame) -> (date, date):
        today = datetime.now(self.base_scanner.ist_timezone).date()
        now = datetime.now(self.base_scanner.ist_timezone)
        current_time = now.time()
        is_market_open = self._is_market_open()
        
        # Check if market hasn't opened yet today (before 9:15 AM)
        market_open_time = datetime.strptime('09:15', '%H:%M').time()
        market_not_opened_yet = current_time < market_open_time
        
        logger.info(f"[FETCH_WINDOW] Starting fetch window determination - Today: {today}, Current time: {current_time.strftime('%H:%M:%S')} IST, Market open: {is_market_open}, Market not opened yet: {market_not_opened_yet}")
        if not existing_df.empty and 'date' in existing_df.columns:
            last_existing = max(existing_df['date'])
            total_rows = len(existing_df)
            logger.info(f"[FETCH_WINDOW] Existing master file: {total_rows} rows, Last date: {last_existing}")
        else:
            logger.info(f"[FETCH_WINDOW] No existing master file or empty")
        
        # If market is open, don't fetch today (will get intraday data, not EOD settlement)
        # Instead, fetch up to yesterday or last available date
        if is_market_open:
            logger.warning("Market is OPEN - skipping today's data to avoid intraday values. Will fetch EOD data after market close.")
            if existing_df.empty or 'date' not in existing_df.columns:
                # First run during market hours - fetch up to yesterday
                start = max(MIN_START_DATE, today - timedelta(days=DEFAULT_HISTORY_DAYS + 1))
                end = today - timedelta(days=1)
                logger.debug(f"First run during market hours: fetching from {start} to {end} (excluding today)")
                return start, end
            else:
                # Incremental update during market hours - fetch up to yesterday
                last_date = max(existing_df['date'])
                yesterday = today - timedelta(days=1)
                if last_date >= yesterday:
                    # Already have yesterday's data - nothing to fetch
                    logger.debug(f"Already have yesterday's data. Skipping today (market open).")
                    return yesterday, yesterday  # Return same date to skip (start > end will be handled)
                else:
                    # Fetch up to yesterday
                    start = last_date
                    end = yesterday
                    logger.debug(f"Incremental update during market hours: fetching from {start} to {end} (excluding today)")
                    return start, end
        
        # Market is closed
        yesterday = today - timedelta(days=1)
        
        # CRITICAL: If market hasn't opened yet today (before 9:15 AM), don't fetch today
        # Instead, only update yesterday's EOD data if it exists
        # Today's data will be available after market opens
        if market_not_opened_yet:
            logger.info(f"Market hasn't opened yet today (current time: {current_time.strftime('%H:%M:%S')} IST < 9:15 AM). Will only update yesterday's EOD data if needed.")
            if existing_df.empty or 'date' not in existing_df.columns:
                # First run before market open - fetch up to yesterday
                start = max(MIN_START_DATE, today - timedelta(days=DEFAULT_HISTORY_DAYS + 1))
                end = yesterday
                logger.debug(f"First run before market open: fetching from {start} to {yesterday} (excluding today)")
                return start, end
            
            last_date = max(existing_df['date'])
            if last_date >= yesterday:
                # Check if yesterday needs EOD update
                yesterday_rows = existing_df[existing_df['date'] == yesterday]
                if not yesterday_rows.empty:
                    logger.info(f"Yesterday's data exists. Will update yesterday ({yesterday}) with EOD settlement data.")
                    return yesterday, yesterday  # Return yesterday to trigger EOD update
                else:
                    logger.debug(f"Yesterday's data doesn't exist. Nothing to fetch before market open.")
                    return yesterday, yesterday  # Return same date to skip
            else:
                # Fetch up to yesterday
                start = last_date
                end = yesterday
                logger.debug(f"Incremental update before market open: fetching from {start} to {yesterday} (excluding today)")
                return start, end
        
        # Market is closed (after market hours) - safe to fetch today (will get EOD data)
        if existing_df.empty or 'date' not in existing_df.columns:
            start = max(MIN_START_DATE, today - timedelta(days=DEFAULT_HISTORY_DAYS))
            logger.debug(f"First run: fetching from {start} to {today} (full history)")
            return start, today

        last_date = max(existing_df['date'])
        if last_date >= today:
            # Data exists for today, but we may need to re-fetch with calculations
            # Check if today's data has NaN calculations - if so, we need to re-fetch with previous day
            today_rows = existing_df[existing_df['date'] == today]
            if not today_rows.empty and 'price_return_pct' in today_rows.columns:
                has_nan_calc = today_rows['price_return_pct'].isna().any()
                if has_nan_calc:
                    logger.debug(f"Today's data has NaN calculations - will re-fetch with previous day for calculations")
                    # Fetch from yesterday to today to enable calculations
                    return today - timedelta(days=1), today
            logger.debug(f"Already up to date: last_date={last_date}, today={today}")
            return today, today
        # For incremental updates, fetch one extra day (yesterday) to enable pct_change/diff calculations
        # This ensures price_return_pct, oi_change, oi_change_pct are calculated correctly for today
        start = last_date  # Include last_date so we can calculate changes for new days
        logger.debug(f"Incremental update: last_date={last_date}, start={start}, end={today}")
        return start, today

    def _build_rows_for_contract(self, symbol: str, contract_label: str,
                                 contract_info: Optional[Dict],
                                 start_date: date, end_date: date) -> List[Dict]:
        if not contract_info:
            return []

        token = contract_info.get('instrument_token')
        expiry = contract_info.get('expiry')
        if token is None or expiry is None:
            return []

        df = self.base_scanner.get_historical_data(
            token,
            start_date,
            end_date,
            interval="day",
            cap_outliers_flag=True,
            contract_type="future"
        )
        time.sleep(API_DELAY_SECONDS)  # Respect API rate limits
        
        # FALLBACK: For the most recent date (end_date), ALWAYS try quote() API to get accurate current/latest data
        # This is especially important when historical_data() has delays, incorrect data, or missing recent dates
        # quote() API is more accurate for current/latest values (like simpleoi.py uses)
        # We use quote() for today or yesterday to ensure we get the most accurate EOD/latest values
        today = datetime.now(self.base_scanner.ist_timezone).date()
        use_quote_for_end_date = (end_date >= today - timedelta(days=1))  # For today or yesterday
        
        if use_quote_for_end_date:
            # Try quote() API to get accurate data for the most recent date
            # This ensures we get accurate EOD/latest values (like simpleoi.py)
            logger.debug(f"{symbol} {contract_label}: Attempting quote() API fallback for {end_date} (end_date >= today-1)")
            try:
                tradingsymbol = contract_info.get('tradingsymbol', '')
                quote_key = f"NFO:{tradingsymbol}" if tradingsymbol else None
                
                # Try multiple methods to get quote data (like simpleoi.py uses token directly)
                quote_data = None
                
                # Method 1: Try with tradingsymbol (NFO:SYMBOL format)
                if tradingsymbol:
                    quote_key = f"NFO:{tradingsymbol}"
                    logger.debug(f"{symbol} {contract_label}: Trying quote() API with key: {quote_key}")
                    quotes = self.base_scanner.kite.quote([quote_key])
                    quote_data = quotes.get(quote_key) if quotes else None
                
                # Method 2: Fallback to token directly (like simpleoi.py does)
                if not quote_data:
                    logger.debug(f"{symbol} {contract_label}: Trying quote() API with token: {token}")
                    quotes = self.base_scanner.kite.quote([token])
                    # Try both string and int key (simpleoi.py uses str(token))
                    quote_data = quotes.get(str(token)) if quotes else None
                    if not quote_data and quotes:
                        quote_data = quotes.get(token) if quotes else None
                
                if not quote_data:
                    logger.warning(f"{symbol} {contract_label}: Quote API returned no data. Available keys: {list(quotes.keys()) if quotes else 'None'}")
                
                if quote_data and 'last_price' in quote_data:
                    logger.debug(f"{symbol} {contract_label}: Got quote data - last_price={quote_data.get('last_price')}, oi={quote_data.get('oi')}")
                    
                    # Determine which price to use for close:
                    # - ALWAYS use last_price (like simpleoi.py does) - it's the most accurate current/EOD price
                    # - ohlc.close might be stale (from previous day) or not updated
                    # - last_price is always the current/latest price, whether market is open or closed
                    last_price = quote_data.get('last_price')
                    ohlc_close = quote_data.get('ohlc', {}).get('close')
                    
                    # Use last_price as primary (matches simpleoi.py behavior)
                    # Only fallback to ohlc.close if last_price is missing
                    if last_price and last_price > 0:
                        close_price = last_price
                        price_source = "last_price (like simpleoi.py)"
                        if ohlc_close and abs(last_price - ohlc_close) > 0.1:
                            logger.debug(f"{symbol} {contract_label}: Using last_price={close_price} (ohlc.close={ohlc_close} differs, using last_price like simpleoi.py)")
                        else:
                            logger.debug(f"{symbol} {contract_label}: Using last_price={close_price} (matches simpleoi.py)")
                    elif ohlc_close:
                        # Fallback to ohlc.close only if last_price is missing
                        close_price = ohlc_close
                        price_source = "ohlc.close (fallback - last_price missing)"
                        logger.warning(f"{symbol} {contract_label}: last_price missing, using ohlc.close={close_price} as fallback")
                    else:
                        # Both missing - this shouldn't happen
                        close_price = None
                        price_source = "None (both missing)"
                        logger.error(f"{symbol} {contract_label}: Both last_price and ohlc.close are missing!")
                    
                    # For OI: Use historical_data() OI if available (more accurate EOD settlement)
                    # quote() API OI might be live/intraday, while historical_data() OI is EOD settlement
                    # This matches NSE bhavcopy better than quote() API OI
                    oi_from_quote = quote_data.get('oi', 0)
                    oi_from_historical = None
                    
                    # Try to get OI from historical_data() if we have it in df
                    if not df.empty:
                        df_dates = df['date'].dt.date.values
                        if end_date in df_dates:
                            hist_row = df[df['date'].dt.date == end_date].iloc[0]
                            oi_from_historical = hist_row.get('oi')
                    
                    # Prefer historical_data() OI for EOD settlement (matches NSE bhavcopy better)
                    # Only use quote() OI if historical_data() OI is missing
                    if oi_from_historical is not None and not pd.isna(oi_from_historical) and oi_from_historical > 0:
                        final_oi = oi_from_historical
                        oi_source = "historical_data (EOD settlement)"
                        if abs(oi_from_historical - oi_from_quote) > 1000:  # Significant difference
                            logger.info(f"{symbol} {contract_label}: Using historical_data() OI={final_oi:,.0f} (quote() OI={oi_from_quote:,.0f} differs - historical_data matches NSE bhavcopy better)")
                        else:
                            logger.debug(f"{symbol} {contract_label}: Using historical_data() OI={final_oi:,.0f} (matches quote() OI={oi_from_quote:,.0f})")
                    else:
                        # Fallback to quote() OI if historical_data() OI not available
                        final_oi = oi_from_quote
                        oi_source = "quote API (fallback - historical_data missing)"
                        logger.debug(f"{symbol} {contract_label}: Using quote() OI={final_oi:,.0f} (historical_data() OI not available)")
                    
                    # Get volume - prefer historical_data() volume (EOD settlement) over quote() volume
                    # quote() API volume might be 0 or missing, while historical_data() has accurate EOD volume
                    volume_from_quote = quote_data.get('volume', 0) or 0
                    volume_from_historical = None
                    
                    if not df.empty:
                        df_dates = df['date'].dt.date.values
                        if end_date in df_dates:
                            hist_row = df[df['date'].dt.date == end_date].iloc[0]
                            volume_from_historical = hist_row.get('volume')
                    
                    # Use historical_data() volume if available and > 0, else use quote() volume
                    if volume_from_historical is not None and not pd.isna(volume_from_historical) and volume_from_historical > 0:
                        final_volume = volume_from_historical
                        volume_source = "historical_data (EOD settlement)"
                    elif volume_from_quote > 0:
                        final_volume = volume_from_quote
                        volume_source = "quote API"
                    else:
                        final_volume = 0
                        volume_source = "None (both missing)"
                        logger.warning(f"{symbol} {contract_label}: Both historical_data() and quote() volume are missing/zero for {end_date}")
                    
                    # Create a row from quote data for end_date
                    quote_row = {
                        'date': pd.to_datetime(end_date),
                        'open': quote_data.get('ohlc', {}).get('open'),
                        'high': quote_data.get('ohlc', {}).get('high'),
                        'low': quote_data.get('ohlc', {}).get('low'),
                        'close': close_price,
                        'volume': final_volume,  # Use historical_data() volume if available, else quote() volume
                        'oi': final_oi,  # Use historical_data() OI if available, else quote() OI
                    }
                    
                    if not df.empty:
                        # ALWAYS replace end_date data with quote data (more accurate for recent dates)
                        # Check if end_date already exists in df - if so, replace it with quote data
                        df_dates = df['date'].dt.date.values
                        if end_date in df_dates:
                            # Replace existing row with quote data (more accurate)
                            old_row = df[df['date'].dt.date == end_date].iloc[0]
                            logger.info(f"{symbol} {contract_label}: [FETCH] Before quote() replacement for {end_date} - Close={old_row.get('close')}, OI={old_row.get('oi'):,.0f}, Volume={old_row.get('volume'):,.0f}")
                            df = df[df['date'].dt.date != end_date]
                            quote_df = pd.DataFrame([quote_row])
                            df = pd.concat([df, quote_df], ignore_index=True)
                            # Verify the replacement worked
                            new_row = df[df['date'].dt.date == end_date]
                            if not new_row.empty:
                                logger.info(f"{symbol} {contract_label}: [FETCH] After quote() replacement for {end_date} - Close={new_row.iloc[0].get('close')}, OI={new_row.iloc[0].get('oi'):,.0f}, Volume={new_row.iloc[0].get('volume'):,.0f}")
                            logger.info(f"{symbol} {contract_label}: [FETCH] Replaced {end_date} data with quote() API - Close={quote_row['close']} ({price_source}), OI={quote_row['oi']:,.0f}, Volume={quote_row['volume']:,.0f} ({volume_source}) (was: Close={old_row.get('close')}, OI={old_row.get('oi'):,.0f}, Volume={old_row.get('volume'):,.0f})")
                        else:
                            # Append quote data
                            quote_df = pd.DataFrame([quote_row])
                            df = pd.concat([df, quote_df], ignore_index=True)
                            logger.info(f"{symbol} {contract_label}: [FETCH] Added {end_date} data from quote() API - Close={quote_row['close']} ({price_source}), OI={quote_row['oi']:,.0f}")
                    else:
                        # Only quote data available
                        df = pd.DataFrame([quote_row])
                        logger.info(f"{symbol} {contract_label}: [FETCH] Using quote() API for {end_date} (historical_data() had no data) - Close={quote_row['close']} ({price_source}), OI={quote_row['oi']:,.0f}")
                    time.sleep(API_DELAY_SECONDS)  # Respect rate limits
            except Exception as e:
                logger.debug(f"{symbol} {contract_label}: Quote API fallback failed: {e}")
        
        if df.empty:
            logger.debug(f"{symbol} {contract_label}: No data returned from API for {start_date} to {end_date}")
            return []

        df = df[df['date'].dt.weekday < 5].copy()
        df.sort_values('date', inplace=True)
        
        # Debug: Verify quote() API data is still in DataFrame after filtering/sorting
        if not df.empty and end_date >= today - timedelta(days=1):
            end_date_rows = df[df['date'].dt.date == end_date]
            if not end_date_rows.empty:
                end_row = end_date_rows.iloc[0]
                logger.debug(f"{symbol} {contract_label}: After filtering/sorting, end_date row - Close={end_row.get('close')}, OI={end_row.get('oi'):,.0f}")
        
        logger.debug(f"{symbol} {contract_label}: Fetched {len(df)} trading days from {df['date'].min().date() if not df.empty else 'N/A'} to {df['date'].max().date() if not df.empty else 'N/A'}")

        df['close'] = pd.to_numeric(df['close'], errors='coerce')
        df['open'] = pd.to_numeric(df['open'], errors='coerce')
        df['high'] = pd.to_numeric(df['high'], errors='coerce')
        df['low'] = pd.to_numeric(df['low'], errors='coerce')
        df['volume'] = pd.to_numeric(df['volume'], errors='coerce')
        df['oi'] = pd.to_numeric(df.get('oi'), errors='coerce')

        df['price_return_pct'] = df['close'].pct_change() * 100
        df['oi_change'] = df['oi'].diff()
        df['oi_change_pct'] = df['oi'].pct_change() * 100
        df['daily_range_pct'] = ((df['high'] - df['low']) / df['close'].replace(0, pd.NA)) * 100
        
        # Debug: Check if calculations worked (should have non-NaN values for rows after first)
        if len(df) > 1:
            calc_check = df.iloc[-1]  # Last row (should be today)
            has_price_return = not pd.isna(calc_check.get('price_return_pct'))
            has_oi_change = not pd.isna(calc_check.get('oi_change'))
            has_oi_change_pct = not pd.isna(calc_check.get('oi_change_pct'))
            if not (has_price_return and has_oi_change and has_oi_change_pct):
                logger.warning(f"{symbol} {contract_label}: Calculations may have failed - price_return_pct={has_price_return}, "
                             f"oi_change={has_oi_change}, oi_change_pct={has_oi_change_pct} for date {calc_check.get('date')}")
            else:
                logger.debug(f"{symbol} {contract_label}: Calculations OK - price_return_pct={calc_check.get('price_return_pct'):.4f}%, "
                           f"oi_change={calc_check.get('oi_change'):.0f}, oi_change_pct={calc_check.get('oi_change_pct'):.4f}%")
        elif len(df) == 1:
            logger.warning(f"{symbol} {contract_label}: Only 1 row fetched - calculations will be NaN (expected for first day)")

        rows = []
        for _, row in df.iterrows():
            row_date = row['date'].date()
            # Log for end_date row to verify quote() API data is preserved
            if row_date == end_date:
                logger.info(f"{symbol} {contract_label}: [PROCESS] Creating row for {row_date} - Close={row.get('close')}, OI={row.get('oi'):,.0f}, Open={row.get('open')}, High={row.get('high')}, Low={row.get('low')}")
            rows.append({
                'date': row_date,
                'symbol': symbol,
                'contract_type': contract_label,
                'expiry': pd.to_datetime(expiry).date(),
                'open': row['open'],
                'high': row['high'],
                'low': row['low'],
                'close': row['close'],
                'volume': row['volume'],
                'oi': row['oi'],
                'price_return_pct': row['price_return_pct'],
                'oi_change': row['oi_change'],
                'oi_change_pct': row['oi_change_pct'],
                'daily_range_pct': row['daily_range_pct'],
                'instrument_token': token
            })
        logger.info(f"{symbol} {contract_label}: [PROCESS] Created {len(rows)} rows from DataFrame (date range: {min(r['date'] for r in rows) if rows else 'N/A'} to {max(r['date'] for r in rows) if rows else 'N/A'})")
        return rows

    def _build_rows_for_spot(self, symbol: str, start_date: date, end_date: date) -> List[Dict]:
        try:
            # NSE instrument cache is already populated by TrendScanner, no API call needed
            nse_row = self.base_scanner.nse_instrument_cache[
                self.base_scanner.nse_instrument_cache['tradingsymbol'] == symbol.upper()
            ]
            if nse_row.empty:
                return []
            token = nse_row['instrument_token'].iloc[0]
        except Exception:
            return []

        df = self.base_scanner.get_historical_data(
            token,
            start_date,
            end_date,
            interval="day",
            cap_outliers_flag=True,
            contract_type="index"  # fetch without OI
        )
        time.sleep(API_DELAY_SECONDS)  # Respect API rate limits
        if df.empty:
            logger.debug(f"{symbol} spot: No data returned from API for {start_date} to {end_date}")
            return []

        df = df[df['date'].dt.weekday < 5].copy()
        df.sort_values('date', inplace=True)
        
        logger.debug(f"{symbol} spot: Fetched {len(df)} trading days from {df['date'].min().date() if not df.empty else 'N/A'} to {df['date'].max().date() if not df.empty else 'N/A'}")

        df['close'] = pd.to_numeric(df.get('close'), errors='coerce')
        df['open'] = pd.to_numeric(df.get('open'), errors='coerce')
        df['high'] = pd.to_numeric(df.get('high'), errors='coerce')
        df['low'] = pd.to_numeric(df.get('low'), errors='coerce')

        df['price_return_pct'] = df['close'].pct_change() * 100
        df['daily_range_pct'] = ((df['high'] - df['low']) / df['close'].replace(0, pd.NA)) * 100
        
        # Debug: Check if calculations worked (spot doesn't have OI, so only check price_return_pct)
        if len(df) > 1:
            calc_check = df.iloc[-1]  # Last row (should be today)
            has_price_return = not pd.isna(calc_check.get('price_return_pct'))
            if not has_price_return:
                logger.warning(f"{symbol} spot: Calculation may have failed - price_return_pct is NaN for date {calc_check.get('date')}")
            else:
                logger.debug(f"{symbol} spot: Calculation OK - price_return_pct={calc_check.get('price_return_pct'):.4f}%")
        elif len(df) == 1:
            logger.warning(f"{symbol} spot: Only 1 row fetched - price_return_pct will be NaN (expected for first day)")

        rows: List[Dict] = []
        for _, row in df.iterrows():
            rows.append({
                'date': row['date'].date(),
                'symbol': symbol,
                'contract_type': 'spot',
                'expiry': None,
                'open': row.get('open'),
                'high': row.get('high'),
                'low': row.get('low'),
                'close': row.get('close'),
                'volume': None,
                'oi': None,
                'price_return_pct': row.get('price_return_pct'),
                'oi_change': None,
                'oi_change_pct': None,
                'daily_range_pct': row.get('daily_range_pct'),
                'instrument_token': token
            })
        return rows

    def _get_options_oi_snapshot(self, symbol: str, target_date: date) -> Dict:
        """
        Fetch options OI snapshot for a given symbol and date.
        Returns aggregated options OI metrics: total call OI, put OI, PCR, etc.
        
        Note: Options OI is live data, so we fetch current snapshot and associate it with target_date.
        For historical dates, this will only work if we're fetching on that date.
        """
        try:
            # Get current month expiry date (approximate - use futures chain to get expiry)
            futures = self.base_scanner.get_futures_chain(symbol)
            current_fut = futures.get('current')
            
            if not current_fut or 'expiry' not in current_fut:
                return {
                    'options_call_oi': None,
                    'options_put_oi': None,
                    'options_total_oi': None,
                    'options_pcr': None,
                    'options_call_oi_change_pct': None,
                    'options_put_oi_change_pct': None,
                }
            
            # Use current month futures expiry as proxy for options expiry
            current_expiry = pd.to_datetime(current_fut['expiry']).date()
            
            # Fetch options chain for current month expiry
            option_chain = self.base_scanner.get_option_chain(symbol, [current_expiry])
            time.sleep(API_DELAY_SECONDS)  # Respect API rate limits
            
            if option_chain.empty or 'oi' not in option_chain.columns:
                return {
                    'options_call_oi': None,
                    'options_put_oi': None,
                    'options_total_oi': None,
                    'options_pcr': None,
                    'options_call_oi_change_pct': None,
                    'options_put_oi_change_pct': None,
                }
            
            # Separate calls and puts
            calls = option_chain[option_chain['instrument_type'] == 'CE'].copy()
            puts = option_chain[option_chain['instrument_type'] == 'PE'].copy()
            
            # Aggregate OI
            total_call_oi = float(calls['oi'].sum(skipna=True)) if not calls.empty else 0.0
            total_put_oi = float(puts['oi'].sum(skipna=True)) if not puts.empty else 0.0
            total_oi = total_call_oi + total_put_oi
            
            # Calculate PCR (Put-Call Ratio)
            pcr = (total_put_oi / total_call_oi) if total_call_oi > 0 else (float('inf') if total_put_oi > 0 else 1.0)
            
            return {
                'options_call_oi': total_call_oi if total_call_oi > 0 else None,
                'options_put_oi': total_put_oi if total_put_oi > 0 else None,
                'options_total_oi': total_oi if total_oi > 0 else None,
                'options_pcr': float(pcr) if not np.isinf(pcr) else None,
                'options_call_oi_change_pct': None,  # Will be calculated from historical data
                'options_put_oi_change_pct': None,  # Will be calculated from historical data
            }
        except Exception as e:
            logger.warning(f"Error fetching options OI for {symbol} on {target_date}: {e}")
            return {
                'options_call_oi': None,
                'options_put_oi': None,
                'options_total_oi': None,
                'options_pcr': None,
                'options_call_oi_change_pct': None,
                'options_put_oi_change_pct': None,
            }

    def capture_daily_snapshots(self):
        logger.info("=" * 80)
        logger.info("[SCANNER] Starting daily snapshot capture")
        logger.info("=" * 80)
        
        existing = self.store.load()
        existing_count = len(existing) if not existing.empty else 0
        logger.info(f"[SCANNER] Loaded existing master file: {existing_count} rows")
        
        today = datetime.now(self.base_scanner.ist_timezone).date()
        now = datetime.now(self.base_scanner.ist_timezone)
        current_time = now.time()
        is_market_closed = not self._is_market_open()
        yesterday = today - timedelta(days=1)
        
        logger.info(f"[SCANNER] Current status - Today: {today}, Time: {current_time.strftime('%H:%M:%S')} IST, Market closed: {is_market_closed}")
        
        # ========================================================================
        # STEP 1: Determine missing data (today/yesterday)
        # ========================================================================
        # (No strike-specific data in base version)
        
        # ========================================================================
        # STEP 2: Determine EOD update requirement
        # ========================================================================
        needs_eod_update = False
        eod_update_date = None
        
        if is_market_closed and not existing.empty and 'date' in existing.columns:
            today_rows_exist = existing[existing['date'] == today]
            yesterday_rows_exist = existing[existing['date'] == yesterday]
            
            logger.info(f"[SCANNER] STEP 2: EOD update check - Today exists: {not today_rows_exist.empty}, Yesterday exists: {not yesterday_rows_exist.empty}")
            
            # Priority 1: ALWAYS update yesterday if it exists (most important - ensures EOD settlement)
            if not yesterday_rows_exist.empty:
                needs_eod_update = True
                eod_update_date = yesterday
                logger.info(f"[SCANNER] STEP 2: Priority 1 - Yesterday ({yesterday}) exists, will update with EOD settlement data")
                # If today also exists, we'll update both (handled in STEP 3)
                if not today_rows_exist.empty:
                    logger.info(f"[SCANNER] STEP 2: Both today and yesterday exist - will update both")
            # Priority 2: Update today if it exists (and yesterday doesn't)
            elif not today_rows_exist.empty:
                needs_eod_update = True
                eod_update_date = today
                logger.info(f"[SCANNER] STEP 2: Priority 2 - Today ({today}) exists, will update with EOD settlement data")
        
        # ========================================================================
        # STEP 3: Build fetch window
        # ========================================================================
        logger.info(f"[SCANNER] STEP 3: Building fetch window...")
        logger.info(f"[SCANNER] STEP 3: Update requirements - needs_eod_update={needs_eod_update}, eod_update_date={eod_update_date}")
        
        # Get base fetch window from _determine_fetch_window
        start_date, end_date = self._determine_fetch_window(existing)
        logger.info(f"[SCANNER] STEP 3: Base fetch window from _determine_fetch_window: start_date={start_date}, end_date={end_date}")
        
        # Override fetch window based on update requirements
        if needs_eod_update:
            # Adjust fetch window for EOD update
            if eod_update_date == yesterday:
                # Update yesterday (and today if it exists)
                today_rows_exist = existing[existing['date'] == today].empty if not existing.empty and 'date' in existing.columns else True
                if not today_rows_exist and not existing[existing['date'] == yesterday].empty:
                    # Both exist - update both
                    start_date = min(start_date, yesterday)
                    end_date = today
                    logger.info(f"[SCANNER] STEP 3: Override - EOD update for both yesterday and today, setting window to ({start_date}, {end_date})")
                else:
                    # Only yesterday exists - update only yesterday
                    start_date = yesterday
                    end_date = yesterday
                    logger.info(f"[SCANNER] STEP 3: Override - EOD update for yesterday only, setting window to ({start_date}, {end_date})")
            elif eod_update_date == today:
                # Update today only
                start_date = today
                end_date = today
                logger.info(f"[SCANNER] STEP 3: Override - EOD update for today only, setting window to ({start_date}, {end_date})")
        
        # Adjust for weekends (no trading on weekends)
        if end_date.weekday() >= 5:  # Saturday=5, Sunday=6
            days_back = end_date.weekday() - 4  # Saturday: 1 day back, Sunday: 2 days back
            old_end_date = end_date
            end_date = end_date - timedelta(days=days_back)
            logger.info(f"[SCANNER] STEP 3: Adjusted end_date from weekend ({old_end_date}) to last trading day: {end_date}")
            if start_date > end_date:
                start_date = end_date
                logger.info(f"[SCANNER] STEP 3: Adjusted start_date to match end_date: {start_date}")
            # Re-check EOD update after weekend adjustment
            if not existing.empty and 'date' in existing.columns:
                adjusted_end_date_rows = existing[existing['date'] == end_date]
                if not adjusted_end_date_rows.empty and not needs_eod_update:
                    needs_eod_update = True
                    eod_update_date = end_date
                    logger.info(f"[SCANNER] STEP 3: After weekend adjustment - end_date {end_date} exists, setting EOD update flag")
        
        if start_date > end_date and not needs_eod_update:
            logger.info("[SCANNER] STEP 3: No fetch needed - master sheet already up to date")
            return
        
        logger.info(f"[SCANNER] STEP 3: Final fetch window: start_date={start_date}, end_date={end_date}")

        # For incremental updates, we need to fetch one extra day (previous day) to enable
        # pct_change() and diff() calculations. But we only want to store new days.
        # Determine the last existing date to know what's "new"
        last_existing_date = max(existing['date']) if not existing.empty and 'date' in existing.columns else None
        
        # Fetch one day before start_date to enable calculations (if doing incremental update)
        # BUT: If start_date is already yesterday (today - 1), don't subtract again
        # This happens when _determine_fetch_window already adjusted for NaN calculations
        # Note: 'today' variable is already defined above
        fetch_start = start_date
        if last_existing_date is not None:
            if start_date < end_date:
                # Incremental update: Check if start_date is already yesterday
                # If start_date == today - 1, it's already set correctly by _determine_fetch_window
                # Only subtract if start_date is further back (e.g., last_date from master file)
                if start_date < today - timedelta(days=1):
                    # start_date is older than yesterday, subtract one more day
                    fetch_start = start_date - timedelta(days=1)
                    logger.debug(f"Fetching extra day for calculations: fetch_start={fetch_start} (one day before start_date={start_date})")
                else:
                    # start_date is already yesterday (today - 1), use it as-is
                    logger.debug(f"Using start_date as fetch_start: {fetch_start} (already includes previous day for calculations)")
            elif start_date == end_date and start_date == today:
                # Re-fetching today: fetch one day before to enable calculations
                fetch_start = start_date - timedelta(days=1)
                logger.debug(f"Re-fetching today with calculations: fetch_start={fetch_start} (one day before start_date={start_date})")
        
        # Determine if we're re-fetching today due to NaN calculations
        is_refetch_today_nan = (start_date == today - timedelta(days=1) and 
                               end_date == today and 
                               last_existing_date is not None and 
                               last_existing_date >= today)
        store_from_date = today if is_refetch_today_nan else start_date
        logger.info(f"Building daily snapshots from {fetch_start} to {end_date} (will store new days from {store_from_date}).")
        if last_existing_date:
            logger.debug(f"Last existing date in master: {last_existing_date}, will filter to keep only dates > {last_existing_date}")
        
        # Ensure NSE instrument cache is populated once at startup (cached, no repeated API calls)
        # This is handled by TrendScanner initialization, but we access it to ensure it's loaded
        _ = self.base_scanner.nse_instrument_cache
        
        symbols = self.base_scanner.read_symbols()
        all_rows: List[Dict] = []

        for symbol in symbols:
            symbol = symbol.strip().upper()
            futures = self.base_scanner.get_futures_chain(symbol)
            time.sleep(API_DELAY_SECONDS)  # Respect API rate limits after futures chain lookup
            
            # Fetch options OI snapshot for today (or most recent date in range)
            # Note: Options OI is live data, so we fetch current snapshot
            today = datetime.now(self.base_scanner.ist_timezone).date()
            target_date = min(today, end_date) if end_date <= today else end_date
            options_snapshot = self._get_options_oi_snapshot(symbol, target_date)
            
            # Calculate options OI change from previous day if available
            if not existing.empty and 'options_call_oi' in existing.columns:
                prev_row = existing[
                    (existing['symbol'] == symbol) & 
                    (existing['date'] < target_date) &
                    (existing['options_call_oi'].notna())
                ].sort_values('date', ascending=False)
                
                if not prev_row.empty:
                    prev_call_oi = prev_row.iloc[0].get('options_call_oi')
                    prev_put_oi = prev_row.iloc[0].get('options_put_oi')
                    curr_call_oi = options_snapshot.get('options_call_oi')
                    curr_put_oi = options_snapshot.get('options_put_oi')
                    
                    if prev_call_oi and curr_call_oi and prev_call_oi > 0:
                        options_snapshot['options_call_oi_change_pct'] = ((curr_call_oi - prev_call_oi) / prev_call_oi) * 100.0
                    if prev_put_oi and curr_put_oi and prev_put_oi > 0:
                        options_snapshot['options_put_oi_change_pct'] = ((curr_put_oi - prev_put_oi) / prev_put_oi) * 100.0
            
            # Fetch with one extra day (previous day) to enable pct_change/diff calculations
            # But we'll filter to only keep new days when appending
            current_rows = self._build_rows_for_contract(symbol, "current",
                                                         futures.get('current'),
                                                         fetch_start, end_date)
            next_rows = self._build_rows_for_contract(symbol, "next",
                                                      futures.get('next'),
                                                      fetch_start, end_date)
            spot_rows = self._build_rows_for_spot(symbol, fetch_start, end_date)
            
            # Filter to only keep new days (dates > last_existing_date) to avoid re-storing existing data
            # EXCEPT: If we're re-fetching today because it has NaN calculations, allow re-storing today
            # EXCEPT: If we're doing an EOD update, keep rows for the EOD update date
            # This ensures we only append new days, but calculations work correctly because
            # we fetched one extra day (previous day) to enable pct_change/diff calculations
            all_symbol_rows = current_rows + next_rows + spot_rows
            rows_before_filter = len(all_symbol_rows)
            logger.info(f"{symbol}: [FILTER] Before filtering: {rows_before_filter} rows (current={len(current_rows)}, next={len(next_rows)}, spot={len(spot_rows)})")
            
            # Check if we're re-fetching today due to NaN calculations
            # This happens when start_date is yesterday (today - 1) and end_date is today
            # AND last_existing_date is today (data exists but has NaN)
            is_refetch_today = (start_date == today - timedelta(days=1) and 
                              end_date == today and 
                              last_existing_date is not None and 
                              last_existing_date >= today)
            
            if last_existing_date is not None:
                # CRITICAL: Check if we're doing an EOD update
                # IMPORTANT: If we're fetching today (end_date == today) and today doesn't exist, 
                # we should keep today's rows, not filter them out as EOD update
                dates_in_rows = set(row.get('date') for row in all_symbol_rows)
                dates_that_exist = set(existing[existing['symbol'] == symbol]['date'].unique()) if not existing.empty else set()
                overlap_dates = dates_in_rows & dates_that_exist
                
                is_eod_update_for_date = False
                eod_target_date = None
                
                # Check if needs_eod_update flag is set (from earlier in the function)
                if needs_eod_update and eod_update_date:
                    eod_target_date = eod_update_date
                    is_eod_update_for_date = True
                    logger.info(f"{symbol}: [FILTER] EOD update flag is set for {eod_update_date}")
                # CRITICAL: If end_date (today) doesn't exist in existing data, we're fetching NEW data
                # Don't treat this as EOD update - keep all rows including today
                elif end_date not in dates_that_exist:
                    # end_date is new data - not an EOD update
                    logger.info(f"{symbol}: [FILTER] end_date ({end_date}) is NEW data (not in existing) - will keep all rows including new date")
                    is_eod_update_for_date = False  # Explicitly set to False
                # Check if we have rows for dates that already exist AND end_date also exists (EOD update)
                elif overlap_dates and end_date in dates_that_exist:
                    # We have overlap AND end_date exists in existing - this is an EOD update
                    eod_target_date = end_date
                    is_eod_update_for_date = True
                    logger.info(f"{symbol}: [FILTER] Detected EOD update - end_date ({end_date}) exists in existing data, will update")
                # Check if end_date matches last_existing_date (we're updating the last date)
                elif end_date == last_existing_date:
                    # end_date matches last_existing_date - this is an EOD update
                    eod_target_date = end_date
                    is_eod_update_for_date = True
                    logger.info(f"{symbol}: [FILTER] Detected EOD update - end_date ({end_date}) matches last_existing_date")
                
                # CRITICAL: Only do EOD update filtering if we're actually doing an EOD update
                # If end_date is new data (doesn't exist), use normal mode to keep all new rows including end_date
                if is_eod_update_for_date:
                    # Re-fetching for EOD update: keep rows for the date being updated
                    if not eod_target_date:
                        eod_target_date = eod_update_date if (needs_eod_update and eod_update_date) else end_date
                    logger.info(f"{symbol}: [FILTER] EOD update mode - filtering to keep only rows for {eod_target_date}")
                    logger.info(f"{symbol}: [FILTER]   needs_eod_update={needs_eod_update}, eod_update_date={eod_update_date}, is_refetch_today={is_refetch_today}")
                    all_symbol_rows = [row for row in all_symbol_rows if row.get('date') == eod_target_date]
                    rows_after_filter = len(all_symbol_rows)
                    logger.info(f"{symbol}: [FILTER] EOD update for {eod_target_date} - keeping {rows_after_filter} rows (filtered from {rows_before_filter})")
                    # Log what rows were kept
                    for row in all_symbol_rows:
                        oi_val = row.get('oi')
                        oi_str = f"{oi_val:,.0f}" if oi_val is not None else "None"
                        logger.info(f"{symbol}: [FILTER]   Kept: {row.get('contract_type')} - Date={row.get('date')}, Close={row.get('close')}, OI={oi_str}")
                elif is_refetch_today:
                    # Re-fetching today: keep today's rows (will overwrite existing NaN data)
                    all_symbol_rows = [row for row in all_symbol_rows if row.get('date') == today]
                    rows_after_filter = len(all_symbol_rows)
                    logger.info(f"{symbol}: [FILTER] Re-fetching today - keeping {rows_after_filter} rows for {today} (will overwrite existing NaN data)")
                else:
                    # Only keep rows for dates after the last existing date (new days only)
                    logger.info(f"{symbol}: [FILTER] Normal mode - filtering to keep only rows with date > {last_existing_date}")
                    logger.info(f"{symbol}: [FILTER]   Rows have dates: {sorted(dates_in_rows)}, existing dates: {sorted(dates_that_exist)}")
                    logger.info(f"{symbol}: [FILTER]   needs_eod_update={needs_eod_update}, eod_update_date={eod_update_date}, is_eod_update_for_date={is_eod_update_for_date}")
                    all_symbol_rows = [row for row in all_symbol_rows if row.get('date') > last_existing_date]
                    rows_after_filter = len(all_symbol_rows)
                    if rows_before_filter > rows_after_filter:
                        logger.info(f"{symbol}: [FILTER] Filtered {rows_before_filter} rows to {rows_after_filter} new rows (removed {rows_before_filter - rows_after_filter} existing rows)")
                    elif rows_after_filter == 0 and rows_before_filter > 0:
                        logger.warning(f"{symbol}: [FILTER] WARNING: All {rows_before_filter} rows filtered out! This might be an EOD update that wasn't detected.")
                        logger.warning(f"{symbol}: [FILTER]   Row dates: {sorted(dates_in_rows)}, last_existing_date: {last_existing_date}, end_date: {end_date}")
                        logger.warning(f"{symbol}: [FILTER]   needs_eod_update={needs_eod_update}, eod_update_date={eod_update_date}, is_refetch_today={is_refetch_today}, is_eod_update_for_date={is_eod_update_for_date}")
                        # Force keep rows for end_date if it exists in existing data (EOD update)
                        if end_date in dates_that_exist:
                            logger.warning(f"{symbol}: [FILTER] FORCING to keep rows for {end_date} (exists in existing data - EOD update)")
                            all_symbol_rows = [row for row in current_rows + next_rows + spot_rows if row.get('date') == end_date]
                            rows_after_filter = len(all_symbol_rows)
                            logger.warning(f"{symbol}: [FILTER] After force-keep: {rows_after_filter} rows")
            else:
                # First run: keep all rows
                logger.info(f"{symbol}: [FILTER] First run - keeping rows with date >= {start_date}")
                all_symbol_rows = [row for row in all_symbol_rows if row.get('date') >= start_date]
                logger.info(f"{symbol}: [FILTER] First run - keeping {len(all_symbol_rows)} rows from {start_date} onwards")
            
            # Debug: Verify calculations are present for new rows
            if all_symbol_rows:
                sample_row = all_symbol_rows[0]
                sample_date = sample_row.get('date')
                has_calc = not pd.isna(sample_row.get('price_return_pct'))
                if not has_calc and sample_date > last_existing_date if last_existing_date else True:
                    logger.warning(f"{symbol}: New row for {sample_date} has NaN price_return_pct - calculation may have failed")
            
            # Add options OI to rows
            # Note: Options OI is live data - we can only fetch current snapshot
            # We store it for today's date, and over time (running daily) we'll build historical data
            for row in all_symbol_rows:
                row_date = row.get('date')
                # Add options data if this row's date matches target_date (today or most recent date in range)
                # This ensures we store options OI for the date we're processing
                if row_date == target_date:
                    row.update(options_snapshot)
                else:
                    # For other dates: check if we have historical options OI data in master file
                    # (This will be populated as we run the scanner daily over time)
                    if not existing.empty and 'options_call_oi' in existing.columns:
                        hist_row = existing[
                            (existing['symbol'] == symbol) &
                            (existing['date'] == row_date) &
                            (existing['options_call_oi'].notna())
                        ]
                        if not hist_row.empty:
                            # Use historical options OI data from master file
                            hist_data = hist_row.iloc[0]
                            row.update({
                                'options_call_oi': hist_data.get('options_call_oi'),
                                'options_put_oi': hist_data.get('options_put_oi'),
                                'options_total_oi': hist_data.get('options_total_oi'),
                                'options_pcr': hist_data.get('options_pcr'),
                                'options_call_oi_change_pct': None,  # Will be calculated in pattern engine
                                'options_put_oi_change_pct': None,  # Will be calculated in pattern engine
                            })
                        else:
                            # No historical data available yet (will populate as we run daily)
                            row.update({
                                'options_call_oi': None,
                                'options_put_oi': None,
                                'options_total_oi': None,
                                'options_pcr': None,
                                'options_call_oi_change_pct': None,
                                'options_put_oi_change_pct': None,
                            })
                    else:
                        # No historical data structure yet
                        row.update({
                            'options_call_oi': None,
                            'options_put_oi': None,
                            'options_total_oi': None,
                            'options_pcr': None,
                            'options_call_oi_change_pct': None,
                            'options_put_oi_change_pct': None,
                        })
            
            all_rows.extend(all_symbol_rows)
            pcr_val = options_snapshot.get('options_pcr')
            pcr_str = f"{pcr_val:.2f}" if pcr_val is not None else "N/A"
            call_chg = options_snapshot.get('options_call_oi_change_pct')
            put_chg = options_snapshot.get('options_put_oi_change_pct')
            call_chg_str = f"{call_chg:+.2f}%" if call_chg is not None else "N/A"
            put_chg_str = f"{put_chg:+.2f}%" if put_chg is not None else "N/A"
            logger.info(f"{symbol}: appended {len(all_symbol_rows)} new daily rows (fetched {len(current_rows) + len(next_rows) + len(spot_rows)} total). "
                       f"Options OI: Call={options_snapshot.get('options_call_oi', 'N/A')} ({call_chg_str}), "
                       f"Put={options_snapshot.get('options_put_oi', 'N/A')} ({put_chg_str}), "
                       f"PCR={pcr_str}")

        # Summary log
        if all_rows:
            dates_in_new_rows = set(row.get('date') for row in all_rows)
            calc_success_count = sum(1 for row in all_rows if not pd.isna(row.get('price_return_pct')))
            calc_fail_count = len(all_rows) - calc_success_count
            logger.info(f"Summary: Appending {len(all_rows)} new rows for dates {min(dates_in_new_rows)} to {max(dates_in_new_rows)}. "
                       f"Calculations: {calc_success_count} successful, {calc_fail_count} failed (NaN)")
            if calc_fail_count > 0:
                logger.warning(f"WARNING: {calc_fail_count} rows have NaN calculations - check if fetch window includes previous day")
        else:
            logger.info("No new rows to append (all data already exists)")

        self.store.append_rows(all_rows)


def main():
    api_key = "3bi2yh8g830vq3y6"
    access_token = "8fKrR1CLiT0D74LhSbLVCFGVWhs9APA4"

    if "YOUR_API_KEY" in api_key or "YOUR_ACCESS_TOKEN" in access_token:
        print("Please set KITE_API_KEY and KITE_ACCESS_TOKEN env vars for OTTrendScannerV2.")
        return

    scanner = OTTrendScannerV2(api_key=api_key, access_token=access_token)
    scanner.capture_daily_snapshots()


if __name__ == "__main__":
    main()

