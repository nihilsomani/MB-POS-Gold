#!/usr/bin/env python3
"""
option_trend_engine_v4_enhanced.py

Enhancements over v3:
 - More nuanced zone interpretation with volume proxies
 - Max Pain calculation (simplified - requires strike data for full implementation)
 - Confidence scoring based on data quality
 - Improved rollover logic with strike analysis
 - Better PCR context with market regime detection
 - Volatility regime awareness (using daily_range_pct as proxy)
 - Risk-adjusted signal strength

Usage:
  python option_trend_engine_v4_enhanced.py --csv data.csv --date 2025-11-20 [--debug]
"""

import pandas as pd
import argparse
from datetime import datetime, timedelta
import sys

# -------------------------
# Configurable thresholds
# -------------------------
OTM_CALL_WALL_MULT = 1.20
OTM_PUT_WALL_MULT  = 1.20
ATM_PUT_DOM_MULT   = 1.25
ITM_PUT_DOM_MULT   = 1.05

# PCR thresholds with more granularity
PCR_EXTREME_BULLISH = 1.30  # Panic put buying -> contrarian long
PCR_BULLISH_HIGH    = 1.10  # Healthy put support
PCR_NEUTRAL_HIGH    = 0.90
PCR_NEUTRAL_LOW     = 0.70
PCR_BEARISH_LOW     = 0.55  # Extreme call dominance -> contrarian short

# Signal thresholds
SCORE_LONG_THRESHOLD = 4     # Increased for higher quality
SCORE_SHORT_THRESHOLD = -4

# Confidence thresholds
HIGH_CONFIDENCE_MIN_OI = 10000  # Adjust based on your market

# -------------------------
# Helpers
# -------------------------
def calculate_signal_persistence(symbol, date, current_score, current_signal, all_results, lookback_days):
    """
    Check if signal has persisted over multiple days
    Awards bonus points for confirmed trends
    
    Returns: (bonus_score, persistence_days, persistence_info)
    """
    if lookback_days < 2:
        return 0, 0, []
    
    persistence_info = []
    same_direction_days = 0
    
    # Look back through previous results
    for i in range(1, lookback_days + 1):
        prev_date = date - timedelta(days=i)
        prev_date_str = prev_date.isoformat()
        
        # Find previous signal for this symbol
        prev_results = [r for r in all_results if r['date'] == prev_date_str and r['symbol'] == symbol]
        
        if not prev_results:
            # No data for this date
            break
        
        prev_result = prev_results[0]
        prev_signal = prev_result['signal']
        prev_score = prev_result['score']
        
        # Check if signals are in same direction
        is_same_direction = False
        
        if current_signal == 'STRANGLE' and prev_signal == 'STRANGLE':
            is_same_direction = True
            persistence_info.append(f"Day-{i}: STRANGLE")
        elif current_signal in ['LONG', 'SHORT'] and current_signal == prev_signal:
            is_same_direction = True
            persistence_info.append(f"Day-{i}: {prev_signal}")
        elif current_signal == 'LONG' and prev_score > 2:
            # Was bullish even if not strong enough for LONG
            is_same_direction = True
            persistence_info.append(f"Day-{i}: Bullish (score {prev_score})")
        elif current_signal == 'SHORT' and prev_score < -2:
            # Was bearish even if not strong enough for SHORT
            is_same_direction = True
            persistence_info.append(f"Day-{i}: Bearish (score {prev_score})")
        
        if is_same_direction:
            same_direction_days += 1
        else:
            # Signal changed direction, stop counting
            persistence_info.append(f"Day-{i}: Different ({prev_signal})")
            break
    
    # Award bonus based on persistence
    if same_direction_days >= 4:
        bonus = 3
        grade = "VERY STRONG"
    elif same_direction_days >= 2:
        bonus = 2
        grade = "CONFIRMED"
    elif same_direction_days >= 1:
        bonus = 1
        grade = "DEVELOPING"
    else:
        bonus = 0
        grade = "NEW"
    
    return bonus, same_direction_days, {
        'grade': grade,
        'days': same_direction_days,
        'history': persistence_info
    }

def safe_float(x):
    try:
        return float(x)
    except:
        return 0.0

def compute_zone_weights(row):
    """Return numeric zone strengths and raw totals"""
    oc = safe_float(row.get("otm_call_oi", 0))
    ac = safe_float(row.get("atm_call_oi", 0))
    ic = safe_float(row.get("itm_call_oi", 0))
    op = safe_float(row.get("otm_put_oi", 0))
    ap = safe_float(row.get("atm_put_oi", 0))
    ip = safe_float(row.get("itm_put_oi", 0))

    # Adjusted weights: ITM 0.45, ATM 0.40, OTM 0.15 (ATM matters more near expiry)
    call_strength = 0.45 * ic + 0.40 * ac + 0.15 * oc
    put_strength  = 0.45 * ip + 0.40 * ap + 0.15 * op

    return {
        "oc": oc, "ac": ac, "ic": ic,
        "op": op, "ap": ap, "ip": ip,
        "call_strength": call_strength,
        "put_strength": put_strength,
        "call_total": oc + ac + ic,
        "put_total": op + ap + ip
    }

def compute_pcr(cur_row):
    """Compute ATM Put-Call Ratio"""
    ac = safe_float(cur_row.get("atm_call_oi", 0))
    ap = safe_float(cur_row.get("atm_put_oi", 0))
    if ac == 0:
        return None
    return ap / ac

def detect_volatility_regime(row):
    """
    Classify volatility regime using daily_range_pct as proxy
    Returns: "HIGH", "NORMAL", "LOW"
    """
    daily_range = safe_float(row.get("daily_range_pct", 0))
    
    if daily_range > 2.5:
        return "HIGH"
    elif daily_range < 0.8:
        return "LOW"
    else:
        return "NORMAL"

def futures_flow_score(today_cur, yesterday_cur):
    """
    Enhanced futures flow with magnitude consideration
    """
    reasons = []
    score = 0

    if yesterday_cur is None:
        reasons.append("⚠ No prior-day data - futures flow unknown")
        return 0, reasons

    delta_price = safe_float(today_cur.get("close", 0)) - safe_float(yesterday_cur.get("close", 0))
    delta_oi = safe_float(today_cur.get("oi", 0)) - safe_float(yesterday_cur.get("oi", 0))
    
    # Calculate percentage changes for magnitude
    prev_price = safe_float(yesterday_cur.get("close", 0))
    prev_oi = safe_float(yesterday_cur.get("oi", 0))
    
    price_change_pct = (delta_price / prev_price * 100) if prev_price > 0 else 0
    oi_change_pct = (delta_oi / prev_oi * 100) if prev_oi > 0 else 0

    # Strong signals if both price and OI moves are significant
    strong_threshold = 1.0  # 1% move
    is_strong = abs(price_change_pct) > strong_threshold and abs(oi_change_pct) > strong_threshold

    if delta_price > 0 and delta_oi > 0:
        points = 3 if is_strong else 2
        score += points
        reasons.append(f"🟢 Long buildup (ΔP: +{price_change_pct:.1f}%, ΔOI: +{oi_change_pct:.1f}%)")
    elif delta_price < 0 and delta_oi > 0:
        points = 3 if is_strong else 2
        score -= points
        reasons.append(f"🔴 Short buildup (ΔP: {price_change_pct:.1f}%, ΔOI: +{oi_change_pct:.1f}%)")
    elif delta_price > 0 and delta_oi < 0:
        score += 1
        reasons.append(f"⚪ Short covering (ΔP: +{price_change_pct:.1f}%, ΔOI: {oi_change_pct:.1f}%)")
    elif delta_price < 0 and delta_oi < 0:
        score -= 1
        reasons.append(f"⚪ Long unwinding (ΔP: {price_change_pct:.1f}%, ΔOI: {oi_change_pct:.1f}%)")
    else:
        reasons.append("➖ Neutral futures flow")

    return score, reasons

def analyze_option_structure(zones, vol_regime):
    """
    Advanced option structure analysis
    Returns score and reasons
    """
    reasons = []
    score = 0
    
    oc, ac, ic = zones["oc"], zones["ac"], zones["ic"]
    op, ap, ip = zones["op"], zones["ap"], zones["ip"]
    call_total = zones["call_total"]
    put_total = zones["put_total"]
    
    if call_total == 0 or put_total == 0:
        reasons.append("⚠ Insufficient option OI for analysis")
        return 0, reasons
    
    # Calculate ratios for interpretation
    put_itm_ratio = ip / put_total if put_total > 0 else 0
    put_otm_ratio = op / put_total if put_total > 0 else 0
    call_itm_ratio = ic / call_total if call_total > 0 else 0
    call_otm_ratio = oc / call_total if call_total > 0 else 0
    
    # --- PUT STRUCTURE ANALYSIS ---
    
    # Classic put writing (bullish): High ITM, low OTM
    if put_itm_ratio > 0.50 and put_otm_ratio < 0.25:
        score += 3
        reasons.append(f"🟢 Put writing structure (ITM: {put_itm_ratio:.1%}, OTM: {put_otm_ratio:.1%})")
    
    # Defensive put hedging (bearish): Both ITM and OTM elevated
    elif put_itm_ratio > 0.35 and put_otm_ratio > 0.35:
        score -= 2
        reasons.append(f"🔴 Defensive put hedging (ITM: {put_itm_ratio:.1%}, OTM: {put_otm_ratio:.1%})")
    
    # Fresh put buying (bearish): High OTM, lower ITM
    elif put_otm_ratio > 0.50 and put_itm_ratio < 0.30:
        score -= 2
        reasons.append(f"🔴 Fresh put buying/hedging (OTM: {put_otm_ratio:.1%})")
    
    # --- CALL STRUCTURE ANALYSIS ---
    
    # Call writing (bearish): High ITM, low OTM
    if call_itm_ratio > 0.50 and call_otm_ratio < 0.25:
        score -= 3
        reasons.append(f"🔴 Call writing overhead (ITM: {call_itm_ratio:.1%}, OTM: {call_otm_ratio:.1%})")
    
    # Bullish call buying (bullish): High OTM calls
    elif call_otm_ratio > 0.50 and call_itm_ratio < 0.30:
        # In high vol, this might be hedging; in low vol, speculation
        if vol_regime == "LOW":
            score += 2
            reasons.append(f"🟢 Speculative call buying (OTM: {call_otm_ratio:.1%}, low vol)")
        else:
            score += 1
            reasons.append(f"⚪ OTM call interest (OTM: {call_otm_ratio:.1%}, high vol - mixed)")
    
    return score, reasons

def analyze_walls_and_barriers(zones, fut_score=0):
    """
    Identify support/resistance from OI concentrations
    Checks OTM walls and ATM battleground
    fut_score: futures flow score for validation
    """
    reasons = []
    score = 0
    
    oc, op = zones["oc"], zones["op"]
    ac, ap = zones["ac"], zones["ap"]
    
    # --- ATM ANALYSIS (Key battleground) ---
    # ATM put dominance ONLY bullish if validated by structure
    atm_ratio = ap / ac if ac > 0 else 0
    
    if atm_ratio > ATM_PUT_DOM_MULT:
        # Validate: OTM puts must be LOW (not defensive hedging)
        put_total = zones["put_total"]
        put_otm_ratio = op / put_total if put_total > 0 else 0
        
        # Additional validation: futures should not be bearish
        is_validated = put_otm_ratio < 0.30 and fut_score >= 0
        
        if is_validated:
            score += 2
            reasons.append(f"🟢 Strong ATM put defense (P/C: {atm_ratio:.2f}, validated)")
        else:
            # High ATM but not validated
            if put_otm_ratio >= 0.30:
                reasons.append(f"⚠ High ATM puts (P/C: {atm_ratio:.2f}) but OTM elevated - likely hedging")
            if fut_score < 0:
                reasons.append(f"⚠ High ATM puts but futures bearish - contradicts bullish thesis")
    elif atm_ratio < (1 / ATM_PUT_DOM_MULT):
        score -= 2
        reasons.append(f"🔴 Strong ATM call dominance (P/C: {atm_ratio:.2f})")
    
    # --- OTM WALLS (Support/Resistance) ---
    # Strong call wall (resistance overhead)
    if oc > op * OTM_CALL_WALL_MULT and oc > 1000:  # Add minimum threshold
        score -= 2
        reasons.append(f"🔴 OTM Call wall (OC: {oc:.0f} >> OP: {op:.0f}) - resistance overhead")
    
    # Strong put wall (support below)
    if op > oc * OTM_PUT_WALL_MULT and op > 1000:
        score += 2
        reasons.append(f"🟢 OTM Put wall (OP: {op:.0f} >> OC: {oc:.0f}) - support below")
    
    # Balanced walls (range-bound)
    if 0.8 <= (oc / op if op > 0 else 0) <= 1.2 and oc > 1000 and op > 1000:
        reasons.append(f"➖ Balanced OTM walls - expect range-bound trading")
    
    return score, reasons

def analyze_pcr_with_context(pcr, vol_regime):
    """
    Enhanced PCR analysis with volatility context
    """
    reasons = []
    score = 0
    
    if pcr is None:
        reasons.append("⚠ PCR unavailable")
        return 0, reasons
    
    # Validate PCR is in reasonable range
    if pcr < 0.1 or pcr > 5.0:
        reasons.append(f"⚠ Invalid PCR value: {pcr:.2f}")
        return 0, reasons
    
    # Extreme readings - contrarian signals
    if pcr >= PCR_EXTREME_BULLISH:
        score += 2
        reasons.append(f"🟢 Extreme PCR {pcr:.2f} - panic put buying, contrarian long")
    
    # Healthy bullish
    elif PCR_BULLISH_HIGH <= pcr < PCR_EXTREME_BULLISH:
        score += 1
        reasons.append(f"🟢 Elevated PCR {pcr:.2f} - healthy put support")
    
    # Neutral zone
    elif PCR_NEUTRAL_LOW <= pcr < PCR_NEUTRAL_HIGH:
        reasons.append(f"➖ Neutral PCR {pcr:.2f}")
    
    # Bearish
    elif PCR_BEARISH_LOW < pcr < PCR_NEUTRAL_LOW:
        score -= 1
        reasons.append(f"🔴 Low PCR {pcr:.2f} - call dominance")
    
    # Extreme bearish - contrarian
    else:  # pcr <= PCR_BEARISH_LOW
        score -= 2
        reasons.append(f"🔴 Extreme low PCR {pcr:.2f} - excessive call buying, contrarian short")
    
    # Volatility context - ONLY note it, don't heavily adjust scores
    # High vol means fear is normal, but futures ΔOI tells real story
    if vol_regime == "HIGH" and pcr > 1.0:
        reasons.append("  (High vol: put buying expected)")
    
    return score, reasons

def analyze_rollover_dynamics(cur, nxt, zones):
    """
    Enhanced rollover analysis
    """
    reasons = []
    score = 0
    
    if nxt is None:
        reasons.append("⚠ No next expiry data")
        return 0, reasons
    
    # Premium analysis
    cur_close = safe_float(cur.get("close", 0))
    nxt_close = safe_float(nxt.get("close", 0))
    prem_diff = nxt_close - cur_close
    
    if cur_close > 0:
        prem_pct = (prem_diff / cur_close) * 100
        
        if prem_pct > 0.5:  # Contango
            score += 1
            reasons.append(f"🟢 Contango {prem_pct:.2f}% - bullish rollover premium")
        elif prem_pct < -0.5:  # Backwardation
            score -= 1
            reasons.append(f"🔴 Backwardation {prem_pct:.2f}% - bearish pressure")
    
    # OI migration analysis
    cur_opt_oi = zones["call_total"] + zones["put_total"]
    
    nxt_zones = compute_zone_weights(nxt)
    nxt_opt_oi = nxt_zones["call_total"] + nxt_zones["put_total"]
    
    if cur_opt_oi > 0:
        migration_ratio = nxt_opt_oi / cur_opt_oi
        
        if migration_ratio > 1.2:  # Strong migration to next
            score += 1
            reasons.append(f"🟢 OI rolling to next ({migration_ratio:.2f}x) - healthy positioning")
        elif migration_ratio < 0.5:  # Stuck in current
            score -= 1
            reasons.append(f"⚠ OI concentrated in current expiry - squeeze risk")
    
    # Futures OI rollover
    cur_fut_oi = safe_float(cur.get("oi", 0))
    nxt_fut_oi = safe_float(nxt.get("oi", 0))
    
    if cur_fut_oi > 0 and nxt_fut_oi > cur_fut_oi * 1.5:
        score += 1
        reasons.append("🟢 Futures OI rolling forward - normal expiry dynamics")
    elif cur_fut_oi > nxt_fut_oi * 2:
        reasons.append("⚠ Futures OI not rolling - watch for abnormal expiry")
    
    return score, reasons

def calculate_confidence(cur, nxt, yesterday_cur, zones):
    """
    Calculate confidence level for the signal
    Returns: confidence score 0-100 and factors list
    """
    confidence = 100
    factors = []
    
    # Data availability penalties
    if yesterday_cur is None:
        confidence -= 20
        factors.append("Missing prior-day data (-20)")
    
    if nxt is None:
        confidence -= 15
        factors.append("Missing next expiry (-15)")
    
    # OI quality checks
    fut_oi = safe_float(cur.get("oi", 0))
    if fut_oi < HIGH_CONFIDENCE_MIN_OI:
        confidence -= 25
        factors.append(f"Low futures OI: {fut_oi:.0f} (-25)")
    
    opt_oi = zones["call_total"] + zones["put_total"]
    if opt_oi < HIGH_CONFIDENCE_MIN_OI:
        confidence -= 20
        factors.append(f"Low option OI: {opt_oi:.0f} (-20)")
    
    # Imbalance checks (too one-sided can be unreliable)
    if zones["call_total"] > 0 and zones["put_total"] > 0:
        call_put_ratio = zones["call_total"] / zones["put_total"]
        if call_put_ratio > 5 or call_put_ratio < 0.2:
            confidence -= 15
            factors.append(f"Extreme C/P imbalance: {call_put_ratio:.2f} (-15)")
    
    # Volatility regime (high vol = lower confidence)
    vol_regime = detect_volatility_regime(cur)
    if vol_regime == "HIGH":
        confidence -= 10
        factors.append("High volatility regime (-10)")
    
    confidence = max(0, min(100, confidence))
    
    if confidence >= 80:
        level = "HIGH"
    elif confidence >= 60:
        level = "MEDIUM"
    else:
        level = "LOW"
    
    return confidence, level, factors

def detect_short_strangle_opportunity(cur, nxt, yesterday_cur, zones, pcr, vol_regime, fut_score):
    """
    Detect conditions favorable for short strangle (sell OTM call + sell OTM put)
    
    Ideal conditions:
    1. Low/normal volatility (not expecting big moves)
    2. Sideways/neutral futures flow
    3. Balanced OTM walls (support below, resistance above)
    4. Price in middle of range
    5. PCR near neutral (0.8-1.2)
    6. No strong directional signals
    
    Returns: (is_strangle, score, reasons, suggested_range)
    """
    reasons = []
    score = 0
    is_strangle = False
    
    # Get current price and range info
    current_price = safe_float(cur.get("close", 0))
    daily_range_pct = safe_float(cur.get("daily_range_pct", 0))
    
    if current_price == 0:
        return False, 0, ["No price data"], None
    
    # 1. Volatility regime check (prefer LOW or NORMAL)
    if vol_regime == "HIGH":
        reasons.append("❌ High volatility - risky for strangle")
        return False, 0, reasons, None
    elif vol_regime == "LOW":
        score += 2
        reasons.append("✅ Low volatility regime - ideal for strangle")
    else:  # NORMAL
        score += 1
        reasons.append("✅ Normal volatility - acceptable for strangle")
    
    # 2. Futures flow should be neutral/sideways (not strong directional)
    if abs(fut_score) >= 2:
        reasons.append(f"❌ Strong directional flow (score: {fut_score}) - avoid strangle")
        return False, 0, reasons, None
    elif fut_score == 0:
        score += 2
        reasons.append("✅ Neutral futures flow - perfect for strangle")
    else:  # abs(fut_score) == 1
        score += 1
        reasons.append("✅ Weak directional bias - acceptable for strangle")
    
    # 3. Check for balanced OTM walls (need both support and resistance)
    oc, op = zones["oc"], zones["op"]
    
    # Both OTM walls should exist and be significant
    # Use dynamic threshold based on total OI
    total_oi = zones["call_total"] + zones["put_total"]
    min_wall_oi = max(1000, total_oi * 0.15)  # At least 15% of total OI or 1000
    
    if oc < min_wall_oi or op < min_wall_oi:
        reasons.append("❌ Insufficient OTM walls - no clear range boundaries")
        return False, 0, reasons, None
    
    # Calculate wall balance
    wall_ratio = oc / op if op > 0 else 0
    
    if 0.7 <= wall_ratio <= 1.4:
        # Balanced walls - good for strangle
        score += 3
        reasons.append(f"✅ Balanced OTM walls (call/put: {wall_ratio:.2f}) - clear range")
    elif 0.5 <= wall_ratio <= 2.0:
        # Somewhat balanced
        score += 1
        reasons.append(f"⚠ Moderately balanced walls ({wall_ratio:.2f}) - acceptable")
    else:
        # Too imbalanced
        reasons.append(f"❌ Imbalanced walls ({wall_ratio:.2f}) - directional bias")
        return False, 0, reasons, None
    
    # 4. PCR should be near neutral (not extreme fear or greed)
    if pcr is None:
        reasons.append("⚠ No PCR data")
    elif 0.8 <= pcr <= 1.2:
        score += 2
        reasons.append(f"✅ Neutral PCR ({pcr:.2f}) - balanced sentiment")
    elif 0.6 <= pcr <= 1.5:
        score += 1
        reasons.append(f"⚠ Moderate PCR ({pcr:.2f}) - slight bias but acceptable")
    else:
        reasons.append(f"❌ Extreme PCR ({pcr:.2f}) - strong directional bias")
        return False, 0, reasons, None
    
    # 5. Recent price action should be range-bound (not trending)
    if yesterday_cur is not None:
        prev_close = safe_float(yesterday_cur.get("close", 0))
        if prev_close > 0:
            price_change_pct = ((current_price - prev_close) / prev_close) * 100
            
            if abs(price_change_pct) < 1.0:
                score += 2
                reasons.append(f"✅ Consolidating (Δ{price_change_pct:+.1f}%) - range-bound")
            elif abs(price_change_pct) < 2.0:
                score += 1
                reasons.append(f"⚠ Moderate move (Δ{price_change_pct:+.1f}%) - acceptable")
            else:
                reasons.append(f"❌ Large move (Δ{price_change_pct:+.1f}%) - trending market")
                return False, 0, reasons, None
    
    # 6. Daily range should be moderate (not explosive)
    if daily_range_pct > 3.0:
        reasons.append(f"❌ Wide daily range ({daily_range_pct:.1f}%) - too volatile")
        return False, 0, reasons, None
    elif daily_range_pct < 1.5:
        score += 1
        reasons.append(f"✅ Tight range ({daily_range_pct:.1f}%) - low volatility")
    
    # 7. Check option structure is not too directional
    call_total = zones["call_total"]
    put_total = zones["put_total"]
    
    if call_total > 0 and put_total > 0:
        opt_ratio = call_total / put_total
        
        if 0.7 <= opt_ratio <= 1.4:
            score += 1
            reasons.append(f"✅ Balanced option interest ({opt_ratio:.2f})")
        else:
            reasons.append(f"⚠ Skewed option interest ({opt_ratio:.2f})")
    
    # 8. Time to expiry consideration (prefer not too close)
    # This would require expiry date parsing - simplified here
    # Ideally: 7-21 days is sweet spot for strangle
    
    # Final decision
    STRANGLE_THRESHOLD = 8  # Need strong conviction for premium selling
    
    if score >= STRANGLE_THRESHOLD:
        is_strangle = True
        
        # Calculate suggested strike range based on OTM walls
        # Estimate: sell call ~2-3% OTM, sell put ~2-3% OTM
        suggested_call_strike = current_price * 1.025
        suggested_put_strike = current_price * 0.975
        
        suggested_range = {
            "current_price": current_price,
            "sell_call_near": suggested_call_strike,
            "sell_put_near": suggested_put_strike,
            "range_width_pct": 5.0,
            "otm_call_oi": oc,
            "otm_put_oi": op
        }
        
        reasons.append(f"🎯 SHORT STRANGLE opportunity (score: {score})")
        reasons.append(f"   Suggested: Sell {suggested_call_strike:.0f}C / {suggested_put_strike:.0f}P")
    else:
        suggested_range = None
        reasons.append(f"❌ Insufficient score ({score}/{STRANGLE_THRESHOLD}) for strangle")
    
    return is_strangle, score, reasons, suggested_range

def classify_signal_for_pair(cur, nxt, yesterday_cur, debug=False):
    """
    Enhanced signal classification with multiple analysis layers
    """
    reasons = []
    score = 0
    
    # Get volatility regime
    vol_regime = detect_volatility_regime(cur)
    
    # 1) Futures flow
    fut_score, fut_reasons = futures_flow_score(cur, yesterday_cur)
    score += fut_score
    reasons.extend(fut_reasons)
    
    # 2) Zone analysis (single pass to avoid double-counting)
    zones = compute_zone_weights(cur)
    
    structure_score, structure_reasons = analyze_option_structure(zones, vol_regime)
    score += structure_score
    reasons.extend(structure_reasons)
    
    # NOTE: Zone dominance is already handled in analyze_option_structure()
    # DO NOT add duplicate checks here to avoid double-counting
    
    # 3) Walls and barriers (pass futures score for validation)
    wall_score, wall_reasons = analyze_walls_and_barriers(zones, fut_score)
    score += wall_score
    reasons.extend(wall_reasons)
    
    # 4) PCR analysis
    pcr = compute_pcr(cur)
    pcr_score, pcr_reasons = analyze_pcr_with_context(pcr, vol_regime)
    score += pcr_score
    reasons.extend(pcr_reasons)
    
    # 5) Rollover dynamics
    rollover_score, rollover_reasons = analyze_rollover_dynamics(cur, nxt, zones)
    score += rollover_score
    reasons.extend(rollover_reasons)
    
    # 6) Calculate confidence
    confidence, conf_level, conf_factors = calculate_confidence(cur, nxt, yesterday_cur, zones)
    
    # 7) Check for short strangle opportunity
    is_strangle, strangle_score, strangle_reasons, strangle_range = detect_short_strangle_opportunity(
        cur, nxt, yesterday_cur, zones, pcr, vol_regime, fut_score
    )
    
    # 8) Final signal with confidence adjustment
    raw_signal = "NO EDGE"
    if score >= SCORE_LONG_THRESHOLD:
        raw_signal = "LONG"
    elif score <= SCORE_SHORT_THRESHOLD:
        raw_signal = "SHORT"
    
    # Override with STRANGLE if conditions are met
    if is_strangle and raw_signal == "NO EDGE":
        signal = "STRANGLE"
        # Add strangle reasons to main reasons
        reasons.extend(strangle_reasons)
    elif is_strangle and abs(score) < 6:
        # Even with weak directional signal, strangle might be better
        signal = "STRANGLE"
        reasons.append(f"⚠ Directional signal weak (score: {score}), STRANGLE preferred")
        reasons.extend(strangle_reasons)
    else:
        # Use directional signal
        # Downgrade signal if low confidence
        if conf_level == "LOW" and raw_signal != "NO EDGE":
            reasons.append(f"⚠ Signal downgraded due to LOW confidence ({confidence}%)")
            signal = "NO EDGE"
        else:
            signal = raw_signal
    
    components = {
        "score": score,
        "signal": signal,
        "confidence": confidence,
        "confidence_level": conf_level,
        "vol_regime": vol_regime,
        "call_strength": zones["call_strength"],
        "put_strength": zones["put_strength"],
        "call_total": zones["call_total"],
        "put_total": zones["put_total"],
        "oc": zones["oc"], "ac": zones["ac"], "ic": zones["ic"],
        "op": zones["op"], "ap": zones["ap"], "ip": zones["ip"],
        "pcr": pcr,
        "is_strangle": is_strangle,
        "strangle_score": strangle_score if is_strangle else None,
        "strangle_range": strangle_range
    }
    
    return {
        "signal": signal,
        "score": score,
        "confidence": confidence,
        "confidence_level": conf_level,
        "reasons": reasons,
        "confidence_factors": conf_factors,
        "components": components
    }

# -------------------------
# Main
# -------------------------
def main():
    parser = argparse.ArgumentParser(description='Options signal engine with one-day or multi-day analysis')
    parser.add_argument("--csv", required=True, help="Path to daily_trend_master_advanced.csv")
    parser.add_argument("--date", required=True, help="Date to print (YYYY-MM-DD)")
    parser.add_argument("--mode", choices=['oneday', 'multiday'], default='multiday',
                       help="Analysis mode: 'oneday' for quick signals, 'multiday' for confirmed trends (default: multiday)")
    parser.add_argument("--lookback", type=int, default=3, 
                       help="Days to look back for multi-day analysis (default: 3, range: 2-7)")
    parser.add_argument("--debug", action="store_true", help="Print debug info")
    args = parser.parse_args()
    
    # Validate lookback
    if args.lookback < 2 or args.lookback > 7:
        print("Warning: lookback should be 2-7 days. Using default of 3.")
        args.lookback = 3

    try:
        df = pd.read_csv(args.csv)
    except Exception as e:
        print(f"Failed to load CSV: {e}")
        sys.exit(1)

    # Data preparation
    df.columns = [c.strip() for c in df.columns]
    df["date"] = pd.to_datetime(df["date"], dayfirst=False, errors='coerce')
    if df["date"].isnull().any():
        df["date"] = pd.to_datetime(df["date"].astype(str), dayfirst=True, errors='coerce')
    
    df["date_only"] = df["date"].dt.date

    numeric_cols = ["open","high","low","close","volume","oi","daily_range_pct",
                    "otm_call_oi","atm_call_oi","itm_call_oi","otm_put_oi","atm_put_oi","itm_put_oi"]
    for c in numeric_cols:
        if c not in df.columns:
            df[c] = 0
        df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0)

    # Create previous day lookups
    df_sorted = df.sort_values(["symbol","contract_type","date"])
    df_sorted["prev_close"] = df_sorted.groupby(["symbol","contract_type"])["close"].shift(1)
    df_sorted["prev_oi"] = df_sorted.groupby(["symbol","contract_type"])["oi"].shift(1)

    lookup = {}
    for _, row in df_sorted.iterrows():
        key = (row["date_only"], row["symbol"], str(row["contract_type"]).strip().lower())
        lookup[key] = row.to_dict()

    # Process signals
    results = []
    grouped = df_sorted.groupby(["date_only","symbol"])
    
    for (dt, sym), grp in grouped:
        ct_vals = set(grp["contract_type"].astype(str).str.lower().values)
        if "current" not in ct_vals or "next" not in ct_vals:
            continue

        cur_row = grp[grp["contract_type"].astype(str).str.lower() == "current"].loc[
            grp[grp["contract_type"].astype(str).str.lower() == "current"]["oi"].idxmax()].to_dict()
        nxt_row = grp[grp["contract_type"].astype(str).str.lower() == "next"].loc[
            grp[grp["contract_type"].astype(str).str.lower() == "next"]["oi"].idxmax()].to_dict()

        prev_key = (dt - timedelta(days=1), sym, "current")
        yesterday_cur = lookup.get(prev_key, None)

        res = classify_signal_for_pair(cur_row, nxt_row, yesterday_cur, debug=args.debug)

        results.append({
            "date": dt.isoformat(),
            "symbol": sym,
            "signal": res["signal"],
            "score": res["score"],
            "confidence": res["confidence"],
            "conf_level": res["confidence_level"],
            "vol_regime": res["components"]["vol_regime"],
            "is_strangle": res["components"]["is_strangle"],
            "strangle_score": res["components"]["strangle_score"] if res["components"]["is_strangle"] else "",
            "strangle_call_strike": res["components"]["strangle_range"]["sell_call_near"] if res["components"]["strangle_range"] else "",
            "strangle_put_strike": res["components"]["strangle_range"]["sell_put_near"] if res["components"]["strangle_range"] else "",
            "reasons": " | ".join(res["reasons"]),
            "conf_factors": " | ".join(res["confidence_factors"]) if res["confidence_factors"] else "",
            "close": safe_float(cur_row.get("close", 0)),
            "current_expiry_oi": safe_float(cur_row.get("oi", 0)),
            "next_expiry_oi": safe_float(nxt_row.get("oi", 0)),
            "pcr": "" if res["components"]["pcr"] is None else f"{res['components']['pcr']:.3f}",
            "put_strength": res["components"]["put_strength"],
            "call_strength": res["components"]["call_strength"],
            "put_total": res["components"]["put_total"],
            "call_total": res["components"]["call_total"]
        })

    results_df = pd.DataFrame(results)
    
    # Apply multi-day analysis if requested
    if args.mode == 'multiday' and len(results_df) > 0:
        print(f"\n🔄 Applying {args.lookback}-day persistence analysis...")
        
        enhanced_results = []
        for idx, row in results_df.iterrows():
            row_date = pd.to_datetime(row['date']).date()
            
            # Calculate persistence
            persistence_bonus, persist_days, persist_info = calculate_signal_persistence(
                row['symbol'],
                row_date,
                row['score'],
                row['signal'],
                results,
                args.lookback
            )
            
            # Apply bonus to score (only for directional signals)
            enhanced_score = row['score']
            enhanced_signal = row['signal']
            
            if row['signal'] in ['LONG', 'SHORT']:
                # Apply bonus correctly based on signal direction
                if row['signal'] == 'LONG':
                    enhanced_score = row['score'] + persistence_bonus  # More positive = stronger
                else:  # SHORT
                    enhanced_score = row['score'] - persistence_bonus  # More negative = stronger
                
                # Re-check if signal strength changed
                if row['signal'] == 'LONG' and enhanced_score < SCORE_LONG_THRESHOLD:
                    enhanced_signal = 'NO EDGE'
                elif row['signal'] == 'SHORT' and enhanced_score > SCORE_SHORT_THRESHOLD:
                    enhanced_signal = 'NO EDGE'
                    
            # For strangles, bonus improves confidence but doesn't change score
            strangle_bonus = 0
            if row['signal'] == 'STRANGLE' and persist_days >= 2:
                strangle_bonus = persist_days  # More days = more confidence
            
            enhanced_results.append({
                **row.to_dict(),
                'original_score': row['score'],
                'enhanced_score': enhanced_score,
                'original_signal': row['signal'],
                'enhanced_signal': enhanced_signal,
                'persistence_bonus': persistence_bonus,
                'persistence_days': persist_days,
                'persistence_grade': persist_info['grade'],
                'persistence_history': ' | '.join(persist_info['history']) if persist_info['history'] else '',
                'strangle_persistence_days': strangle_bonus if row['signal'] == 'STRANGLE' else ''
            })
        
        results_df = pd.DataFrame(enhanced_results)
        
        # Use enhanced signals for display
        results_df['signal'] = results_df['enhanced_signal']
        results_df['score'] = results_df['enhanced_score']
    else:
        # One-day mode - add placeholder columns
        results_df['original_score'] = results_df['score']
        results_df['enhanced_score'] = results_df['score']
        results_df['original_signal'] = results_df['signal']
        results_df['enhanced_signal'] = results_df['signal']
        results_df['persistence_bonus'] = 0
        results_df['persistence_days'] = 0
        results_df['persistence_grade'] = 'NEW'
        results_df['persistence_history'] = ''
        results_df['strangle_persistence_days'] = ''
    
    # Save all results
    results_df.to_csv("signals_all.csv", index=False)

    # Filter by date
    try:
        user_date = pd.to_datetime(args.date, dayfirst=False).date()
    except:
        user_date = pd.to_datetime(args.date, dayfirst=True).date()

    out_for_date = results_df[results_df["date"] == user_date.isoformat()].copy()
    out_fname = f"signals_{user_date.isoformat()}.csv"
    out_for_date.to_csv(out_fname, index=False)

    print(f"\n{'='*80}")
    print(f"Mode: {args.mode.upper()}" + (f" (Lookback: {args.lookback} days)" if args.mode == 'multiday' else ""))
    print(f"Processed {len(results_df)} symbol-date combinations")
    print(f"Saved: signals_all.csv and {out_fname}")
    print(f"{'='*80}\n")

    print(f"=== SIGNALS for {user_date.isoformat()} ===\n")
    
    if out_for_date.empty:
        print("No results for this date")
    else:
        # Summary stats
        signals_count = out_for_date["enhanced_signal" if args.mode == 'multiday' else "signal"].value_counts()
        print(f"Signal Distribution: {signals_count.to_dict()}")
        
        if args.mode == 'multiday':
            # Show persistence stats
            confirmed_signals = out_for_date[out_for_date['persistence_days'] >= 2]
            if len(confirmed_signals) > 0:
                print(f"Confirmed Signals (2+ days): {len(confirmed_signals)}")
            strong_signals = out_for_date[out_for_date['persistence_days'] >= 4]
            if len(strong_signals) > 0:
                print(f"Strong Trends (4+ days): {len(strong_signals)}")
        print()
        
        # Show high confidence or confirmed trades only
        if args.mode == 'multiday':
            priority = out_for_date[
                ((out_for_date["conf_level"] == "HIGH") & (out_for_date['persistence_days'] >= 2)) |
                (out_for_date['persistence_days'] >= 3)
            ]
        else:
            priority = out_for_date[out_for_date["conf_level"] == "HIGH"]
        
        if not priority.empty:
            print(f"\n🎯 {'CONFIRMED' if args.mode == 'multiday' else 'HIGH CONFIDENCE'} SIGNALS ({len(priority)}):\n")
            display_cols = ["symbol","enhanced_signal" if args.mode == 'multiday' else "signal","enhanced_score" if args.mode == 'multiday' else "score","confidence","persistence_grade" if args.mode == 'multiday' else "conf_level","close","pcr"]
            if args.mode == 'multiday':
                display_cols.insert(4, "persistence_days")
            print(priority[display_cols].to_string(index=False))
            print("\n")
        
        # Show all signals
        print(f"ALL SIGNALS ({len(out_for_date)}):\n")
        if args.mode == 'multiday':
            display_cols = ["symbol","enhanced_signal","enhanced_score","original_score","persistence_grade","persistence_days","conf_level","pcr","reasons"]
        else:
            display_cols = ["symbol","signal","score","conf_level","confidence","pcr","reasons"]
        print(out_for_date[display_cols].to_string(index=False))

    if args.debug:
        results_df.to_csv("signals_all_debug.csv", index=False)
        print("\n✅ Detailed debug CSV: signals_all_debug.csv")

if __name__ == "__main__":
    main()