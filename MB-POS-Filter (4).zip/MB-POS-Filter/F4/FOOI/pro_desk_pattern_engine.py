"""
Pro Desk Pattern Engine
-----------------------

Futures‑first analytics on the daily master sheet (OTTrendScannerV2) to produce:
  • Option‑selling (non‑directional) candidates in genuine compression regimes
  • Directional (trend / coil‑ignition) opportunities with strict microstructure gates

Required inputs (from data/daily_trend_master.csv):
  - date, symbol, contract_type ∈ {current,next,spot}, expiry (for futures legs)
  - OHLC: high, low, close ; volume
  - OI series (futures): oi, oi_change_pct
  - daily_range_pct, price_return_pct (or we compute derivatives)

Core outputs per leg:
  - core_label: TREND_LONG / TREND_SHORT / NEUTRAL (price–OI microstructure only)
  - label (regime): COMPRESSION_MODE / EXPANSION_MODE / TRANSITION_MODE
  - sellability_score (0..1), sell_recommendation ∈ {SAFE, MODERATE, CAUTION, AVOID}
  - directional_recommendation ∈ {OK, NEUTRAL, AVOID}
  - veto flags: distribution_veto, bearish_slide_veto, shock_memory_strong
  - context flags: coiling_flag, expansion_bias, expansion_flag, days_to_expiry, liquidity_tier
  - policy_brief: compact summary (Core|Dir|Sell|Liq|InstBias|ExpRisk|Coil|Shock)

Key rules (short):
  • Futures‑first: only current futures can authorize a sell; spot is context only.
  • Hard SELL vetoes (ANY → AVOID): Distribution / Bearish‑slide / ATR120≥0.90 / Shock‑memory‑strong.
  • Sellability (DTE‑aware): 0.50·(1−ATR120%) + 0.25·stability + 0.25·(1−vol_extreme).
  • SELL candidate requires core_label==NEUTRAL, current leg, compression regime, no veto/ExpRisk, Liq A/B, 7–21 DTE.
  • Directional requires core TREND (alignment, displacement, OI confirm, Liq≠C), then passes tradability (ATR60, ExpRisk).
"""

from __future__ import annotations

import argparse
from pathlib import Path
import os
import sys
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

# Master file is stored at project root (e.g. C:/.../finance_ai_ws/data/daily_trend_master.csv).
# Use a path relative to this script's location so it works regardless of CWD.
MASTER_PATH = (Path(__file__).resolve().parents[3] / "data" / "daily_trend_master.csv")
DEFAULT_LOOKBACK = 5
MIN_ROWS_REQUIRED = 5  # need at least this many daily snapshots per symbol
MIN_TREND_DISPLACEMENT_MULT = 2.0  # price slope * lookback must exceed avg_range * multiplier
MICRO_RANGE_THRESHOLD = 1.2  # daily range % considered truly micro; cap alignment below this
ROLL_OVER_THRESHOLD = 1.5  # next/current OI growth ratio to call rollover-driven
INV_ROTATION_ALIGNMENT_MAX = 0.5
INV_ROTATION_RANGE_MAX = 4.5
INV_ROTATION_RANGE_MIN = 2.0
MIN_OI_GROWTH_FOR_ROTATION = 0.5
MIN_ATR_HISTORY_60 = 20   # minimum bars for meaningful 60-bar ATR percentile (relaxed for newer contracts)
MIN_ATR_HISTORY_120 = 40  # minimum bars for meaningful 120-bar ATR percentile (relaxed for newer contracts)


def _straddle_quality_score(
    oi_cv: float,
    avg_range: float,
    realized_vol: float,
    rollover_pct: float,
    alignment: float,
) -> float:
    """
    0–100 score for straddle (short-vol) sellability.

    This intentionally uses a simple, piecewise structure:
      1) OI stability (30 pts) via coefficient of variation
      2) Range quality (25 pts) around an ideal 2.5–4.5% band
      3) Realized volatility (20 pts), preferring low realized vol
      4) Rollover participation (15 pts) as a proxy for healthy rotation
      5) Lack of directional bias (10 pts) via low |alignment|
    """
    score = 0.0
    pts_oi = pts_range = pts_rv = pts_roll = pts_align = 0.0

    oi_cv = float(oi_cv if oi_cv is not None else 0.0)
    avg_range = float(avg_range if avg_range is not None else 0.0)
    realized_vol = float(realized_vol if realized_vol is not None else 0.0)
    rollover_pct = float(rollover_pct if rollover_pct is not None else 0.0)
    alignment = float(alignment if alignment is not None else 0.0)

    # 1. OI Stability (30 points)
    if oi_cv > 0:
        if oi_cv < 0.02:
            pts_oi = 30
        elif oi_cv < 0.03:
            pts_oi = 25
        elif oi_cv < 0.05:
            pts_oi = 15
        else:
            pts_oi = 5
        score += pts_oi

    # 2. Range Quality (25 points)
    if 2.5 < avg_range < 4.5:
        pts_range = 25
    elif 2.0 < avg_range < 5.0:
        pts_range = 20
    elif avg_range < 2.0:
        # Too tight – compression can be dangerous for naked straddles
        pts_range = 5
    score += pts_range

    # 3. Volatility (20 points) – use realized vol in % terms
    if realized_vol < 12:
        pts_rv = 20
    elif realized_vol < 16:
        pts_rv = 15
    elif realized_vol < 20:
        pts_rv = 10
    score += pts_rv

    # 4. Rollover (15 points) – proxy via OI growth / participation
    if rollover_pct > 6:
        pts_roll = 15
    elif rollover_pct > 4:
        pts_roll = 12
    elif rollover_pct > 2:
        pts_roll = 8
    score += pts_roll

    # 5. No Directional Bias (10 points)
    if abs(alignment) < 0.3:
        pts_align = 10
    elif abs(alignment) < 0.5:
        pts_align = 6
    score += pts_align

    return float(score)


def _short_straddle_score(row: pd.Series) -> float:
    """
    0–100 "intelligent" short-straddle score combining:
      - Realized compression (range, stability)
      - IV context from options_screener (ATMIV, IVPercentile, ATMIVChange)
      - Flow context (FutureOIPercentChange, VolumeMultiple)
      - Surface context (PCR) and simple event veto
    """
    score = 0.0

    # IV context
    ivp = float(row.get("IVPercentile") or 0.0)
    ivchg = float(row.get("ATMIVChange") or 0.0)

    # Prefer low-mid IV percentile: cheap-ish vs own history but not absolute floor
    if 10 <= ivp <= 50:
        score += 25
    elif 50 < ivp <= 70:
        score += 15

    # IV change: avoid fresh spikes, reward stable/falling IV
    if ivchg < -2:
        score += 10
    elif -2 <= ivchg <= 2:
        score += 5

    # Realized compression: range + stability from engine
    rng = float(row.get("avg_daily_range_pct") or 0.0)
    stab = float(row.get("volatility_stability") or 0.0)
    if stab > 0.7 and rng <= 1.5:
        score += 25
    elif stab > 0.6 and rng <= 2.0:
        score += 15

    # Flow: futures OI & volume
    fou = float(row.get("FutureOIPercentChange") or 0.0)
    vm = float(row.get("VolumeMultiple") or 1.0)
    if abs(fou) < 5 and vm < 2:
        score += 15
    elif abs(fou) < 10:
        score += 8

    # Options surface: balanced PCR (prefer options OI PCR from master file, fallback to screener)
    options_pcr = row.get("options_pcr")
    screener_pcr = float(row.get("PCR") or 1.0)
    pcr = float(options_pcr) if options_pcr is not None else screener_pcr
    
    if 0.8 <= pcr <= 1.2:
        score += 10
    elif 0.7 <= pcr <= 1.3:
        score += 6
    elif pcr > 1.5 or pcr < 0.6:
        score -= 5  # Extreme PCR = directional bias (bad for straddles)
    
    # Max Pain Distance (timing signal for straddles)
    max_pain_dist = row.get("distance_from_maxpain")
    if max_pain_dist is not None:
        if abs(max_pain_dist) < 1.5:
            score += 5  # Near max pain = good for straddles
        elif abs(max_pain_dist) > 3.0:
            score -= 3  # Far from max pain = mean reversion risk
    
    # Calendar Spread (rollover activity indicator) - Optimized: increased points
    calendar_spread_pct = row.get("calendar_spread_pct")
    if calendar_spread_pct is not None:
        if 0.3 <= calendar_spread_pct <= 1.0:
            score += 5  # Healthy rollover activity (increased from +3)
        elif 0.1 <= calendar_spread_pct < 0.3:
            score += 2  # Moderate rollover activity

    # Options OI flow: stable options OI is good for straddles (writers active)
    options_call_oi_chg = row.get("options_call_oi_change_pct")
    options_put_oi_chg = row.get("options_put_oi_change_pct")
    
    if options_call_oi_chg is not None and options_put_oi_chg is not None:
        # Both call and put OI stable or building slightly = writers active
        if abs(options_call_oi_chg) < 5 and abs(options_put_oi_chg) < 5:
            score += 8  # Stable options OI = good for straddles
        elif abs(options_call_oi_chg) < 10 and abs(options_put_oi_chg) < 10:
            score += 4
        # Large options OI changes = directional flow (bad for straddles)
        elif abs(options_call_oi_chg) > 20 or abs(options_put_oi_chg) > 20:
            score -= 5

    # Futures vs Options OI divergence check
    # If futures OI is building but options OI is flat/declining = hedging (good for straddles)
    fou = float(row.get("FutureOIPercentChange") or 0.0)
    options_total_chg = row.get("options_total_oi_change_pct")
    if options_total_chg is not None:
        options_total_chg = float(options_total_chg)
        # Divergence: futures building but options stable = hedging activity
        if abs(fou) > 5 and abs(options_total_chg) < 5:
            score += 3  # Hedging activity = good for straddles

    # Simple event veto: penalize obvious binary events
    event = str(row.get("Event") or "").lower()
    if any(k in event for k in ("result", "earnings", "policy", "budget", "agm")):
        score -= 30

    # DTE penalty for short straddles
    # For short straddles, DTE is critical:
    # - Too close to expiry (<7 days) = high gamma risk, low liquidity, unpredictable moves
    # - Too far from expiry (>21 days) = less theta decay benefit, more time for adverse moves
    # - Sweet spot: 7-21 DTE (optimal theta decay with manageable risk)
    dte = row.get("days_to_expiry")
    if dte is not None:
        if dte < 7:
            # Too close to expiry - high gamma risk, low liquidity
            score = score * 0.5  # Heavy penalty (reduce score by 50%)
        elif dte > 21:
            # Too far from expiry - less theta benefit, more time for adverse moves
            score = score * 0.7  # Moderate penalty (reduce score by 30%)
        elif 7 <= dte <= 21:
            # Sweet spot for short straddles - no penalty
            pass

    return float(np.clip(score, 0.0, 100.0))


def _directional_trade_score(row: pd.Series) -> float:
    """
    0–100 score for directional trade (call/put buy) suitability for 1-5 day holding.
    
    Combines:
      - Momentum & trend strength (30 pts): alignment, displacement, OI z-score, price slope
      - Entry timing (25 pts): RSI zone, ATR percentile, recent momentum (weighted heavily for 1-5 day trades), momentum acceleration, exhaustion risk
      - IV context for buying options (20 pts): IV percentile, IV change
      - Liquidity & flow (15 pts): tier, volume, OI growth
      - Risk management (10 pts): vetoes, ATR extremes, PCR extremes
    
    Note: Recent momentum is heavily weighted (up to 8 pts) as it's critical for short-term trades.
    Momentum acceleration (recent move >1.5x average) adds bonus points.
    """
    score = 0.0
    
    # Extract core metrics
    core = str(row.get("core_label") or "")
    align = float(row.get("alignment_ratio") or 0.0)
    price_disp = float(row.get("price_displacement") or 0.0)
    avg_range = float(row.get("avg_daily_range_pct") or 0.0)
    oi_z = float(row.get("oi_zscore") or 0.0)
    price_slope = float(row.get("price_slope") or 0.0)
    oi_slope_pct = float(row.get("oi_slope_pct") or 0.0)
    last_price_ret = float(row.get("last_price_return_pct") or 0.0)
    avg_price_ret = float(row.get("avg_price_return_pct") or 0.0)  # Average return over lookback
    
    rsi2 = row.get("rsi2")
    rsi3 = row.get("rsi3")
    atr60 = row.get("atr14_percentile60")
    atr120 = row.get("atr14_percentile120")
    
    ivp = float(row.get("IVPercentile") or 0.0)
    ivchg = float(row.get("ATMIVChange") or 0.0)
    
    tier = str(row.get("liquidity_tier") or "C")
    vm = float(row.get("VolumeMultiple") or 1.0)
    oi_growth = float(row.get("oi_growth_pct") or 0.0)
    screener_pcr = float(row.get("PCR") or 1.0)
    options_pcr = row.get("options_pcr")  # Prefer options OI PCR from master file
    pcr = float(options_pcr) if options_pcr is not None else screener_pcr
    
    # Options OI metrics
    options_call_oi_chg = row.get("options_call_oi_change_pct")
    options_put_oi_chg = row.get("options_put_oi_change_pct")
    options_call_oi_chg = float(options_call_oi_chg) if options_call_oi_chg is not None else None
    options_put_oi_chg = float(options_put_oi_chg) if options_put_oi_chg is not None else None
    
    # New metrics from clause-pro-desk enhancements
    oi_velocity = row.get("oi_velocity_current")
    oi_acceleration = row.get("oi_acceleration")
    volume_oi_div = row.get("volume_oi_divergence")
    basis_momentum = row.get("basis_momentum")
    pcr_zscore = row.get("pcr_zscore")
    net_oi_flow = row.get("net_oi_flow")
    flow_sentiment = str(row.get("flow_sentiment") or "")
    
    # Hard vetoes: if any of these, score is 0
    contract_type = str(row.get("contract_type") or "")
    
    if (bool(row.get("distribution_veto")) or 
        bool(row.get("bearish_slide_veto")) or 
        bool(row.get("shock_memory_strong")) or
        (atr120 is not None and atr120 >= 0.90) or
        tier == "C"):
        return 0.0
    
    # 1. MOMENTUM & TREND STRENGTH (30 points)
    # Core trend present
    if core in ("TREND_LONG", "TREND_SHORT"):
        score += 15
    # Alignment strength
    # For LONG: high alignment is good (price and OI move together)
    # For SHORT: lower alignment is expected (price down, OI up in short buildup)
    if core == "TREND_LONG":
        if align >= 0.75:
            score += 8
        elif align >= 0.65:
            score += 5
    elif core == "TREND_SHORT":
        # For short buildup, alignment is lower but still meaningful
        if align >= 0.50:
            score += 6  # Good for short buildup
        elif align >= 0.40:
            score += 4
        # Note: OI slope check removed - redundant with OI growth checks below
    # OI Velocity check (1st derivative - day-over-day rate of change)
    if oi_velocity is not None:
        if core == "TREND_LONG" and oi_velocity > 2.0:
            score += 2  # Strong day-over-day OI accumulation
        elif core == "TREND_SHORT" and oi_velocity > 2.0:
            score += 2  # Strong day-over-day OI buildup (shorts)
        elif oi_velocity < -2.0:
            score -= 1  # OI unwinding (momentum fading)
    # OI Acceleration bonus (early signal detection)
    if oi_acceleration is not None:
        if core == "TREND_LONG" and oi_acceleration > 0.5:
            score += 3  # Accelerating accumulation
        elif core == "TREND_SHORT" and oi_acceleration > 0.5:
            score += 3  # Accelerating distribution
        elif oi_acceleration < -0.5:
            score -= 2  # Momentum fading
    # Displacement vs range (meaningful move)
    if avg_range > 0:
        disp_mult = price_disp / avg_range if avg_range > 0 else 0
        if disp_mult >= 3.0:
            score += 7
        elif disp_mult >= 2.0:
            score += 4
    # OI conviction (z-score) - for short buildup, OI z should be positive
    if core == "TREND_SHORT" and oi_z > 0.5:
        # OI above average (short buildup)
        if oi_z >= 1.5:
            score += 5
        elif oi_z >= 1.0:
            score += 3
    elif core == "TREND_LONG":
        # For long buildup, OI z should also be positive
        if abs(oi_z) >= 1.5:
            score += 5
        elif abs(oi_z) >= 1.0:
            score += 3
    
    # Breakout detection: coil about to spring
    label = str(row.get('label') or "")
    if label == "WATCH_BREAKOUT" and (atr60 or 0) >= 0.60:
        score += 8  # Coil about to spring - high probability breakout setup
    
    # 2. ENTRY TIMING (25 points)
    # RSI zone: direction-specific preferences
    rsi_val = rsi2 if rsi2 is not None else (rsi3 if rsi3 is not None else 50.0)
    if core == "TREND_LONG":
        # For CALL buys: prefer RSI 20-80 (momentum building, not exhausted)
        if 20 <= rsi_val <= 80:
            score += 8
        elif 10 <= rsi_val < 20 or 80 < rsi_val <= 90:
            score += 4
    elif core == "TREND_SHORT":
        # For PUT buys: prefer RSI 50-90 (bearish momentum, overbought = good entry for puts)
        if 50 <= rsi_val <= 90:
            score += 8
        elif 40 <= rsi_val < 50 or 90 < rsi_val <= 95:
            score += 5
        elif 20 <= rsi_val < 40:
            score += 3  # Still acceptable
    else:
        # Neutral: general 20-80 zone
        if 20 <= rsi_val <= 80:
            score += 8
        elif 10 <= rsi_val < 20 or 80 < rsi_val <= 90:
            score += 4
    # ATR percentile: for 1-5 day trades, prefer more active markets (higher volatility)
    if atr60 is not None:
        if 0.60 <= atr60 <= 0.80:
            score += 10  # Rising volatility, not exhausted - sweet spot for short-term trades
        elif 0.45 <= atr60 < 0.60:
            score += 7   # Building momentum
        elif 0.80 < atr60 <= 0.90:
            score += 4   # High but tradable
        elif atr60 >= 0.90:
            score -= 5   # Exhaustion risk - too high, likely to reverse
        else:  # atr60 < 0.45
            score += 2   # Low vol (harder to profit in 1-5 days)
    # Recent momentum confirmation (critical for 1-5 day trades)
    # For short-term trades, recent momentum is more important than overall trend
    if core == "TREND_LONG":
        if last_price_ret > 1.5:
            score += 8  # Strong recent bullish momentum
        elif last_price_ret > 0.8:
            score += 6  # Good recent bullish momentum
        elif last_price_ret > 0.3:
            score += 4  # Moderate recent bullish momentum
        elif last_price_ret > 0:
            score += 2  # Weak but positive
        elif last_price_ret < -1.0:
            score -= 5  # Strong contradictory move (bearish)
        elif last_price_ret < -0.5:
            score -= 3  # Moderate contradictory move
        elif last_price_ret < 0:
            score -= 1  # Minor pullback
    elif core == "TREND_SHORT":
        if last_price_ret < -1.5:
            score += 8  # Strong recent bearish momentum
        elif last_price_ret < -0.8:
            score += 6  # Good recent bearish momentum
        elif last_price_ret < -0.3:
            score += 4  # Moderate recent bearish momentum
        elif last_price_ret < 0:
            score += 2  # Weak but negative
        elif last_price_ret > 1.0:
            score -= 5  # Strong contradictory move (bullish)
        elif last_price_ret > 0.5:
            score -= 3  # Moderate contradictory move
        elif last_price_ret > 0:
            score -= 1  # Minor bounce
    # Momentum acceleration bonus: if recent momentum is stronger than average
    # This indicates the move is accelerating, which is great for 1-5 day trades
    if core == "TREND_LONG" and avg_price_ret > 0:
        momentum_accel = last_price_ret / avg_price_ret if avg_price_ret > 0 else 0
        if momentum_accel > 1.5:  # Recent move is 1.5x stronger than average
            score += 3  # Momentum accelerating
        elif momentum_accel > 1.2:
            score += 2
    elif core == "TREND_SHORT" and avg_price_ret < 0:
        momentum_accel = abs(last_price_ret / avg_price_ret) if avg_price_ret < 0 else 0
        if momentum_accel > 1.5:  # Recent move is 1.5x stronger than average
            score += 3  # Momentum accelerating
        elif momentum_accel > 1.2:
            score += 2
    
    # Exhaustion check: if ATR120 very high, reduce timing score
    if atr120 is not None and atr120 >= 0.85:
        score -= 3
    
    # 3. IV CONTEXT FOR BUYING OPTIONS (20 points) - REVISED
    # Lower IV = cheaper options (better for buying)
    # But very low IV (<20%) might mean market doesn't expect a move (no IV expansion potential)
    # Sweet spot: 20-40% (cheap but market still has some expectation of movement)
    # Rising IV = market pricing in move (can be good signal)
    if 20 <= ivp < 40:
        score += 12  # Sweet spot: cheap options with reasonable move expectation
    elif 10 <= ivp < 20:
        score += 8   # Very cheap but market might not expect move (lower IV expansion potential)
    elif ivp < 10:
        score += 5   # Extremely low IV - might be "dead" market, but cheap entry
    elif 40 <= ivp <= 60:
        score += 8   # Reasonable IV, still acceptable for buying
    elif 60 < ivp <= 80:
        score += 4   # Getting expensive
    else:  # ivp > 80
        score -= 5   # Very expensive, move might be priced in
    
    # IV change: slightly rising IV is actually a good signal for buying
    if -2 <= ivchg <= 5:
        score += 8   # Stable to rising (market sensing move)
    elif 5 < ivchg <= 10:
        score += 4   # Rising but not spike
    elif ivchg > 10:
        score -= 8   # Spiking (expensive, late entry)
    elif ivchg < -5:
        score -= 5   # Collapsing (market thinks move is over)
    
    # 4. LIQUIDITY & FLOW (15 points)
    # Liquidity tier
    if tier == "A":
        score += 8
    elif tier == "B":
        score += 5
    # Volume multiple (showing interest)
    if vm >= 2.0:
        score += 4
    elif vm >= 1.5:
        score += 2
    # OI growth confirming direction
    # For LONG: OI rising (longs building)
    # For SHORT: OI rising (shorts building) - this is the key signal!
    if core == "TREND_LONG" and oi_growth > 0:
        score += 3
    elif core == "TREND_SHORT" and oi_growth > 0:  # FIXED: short buildup has OI rising
        score += 4  # Slightly higher weight for short buildup confirmation
    # Strong OI moves
    if core == "TREND_LONG" and oi_growth > 5:
        score += 2
    elif core == "TREND_SHORT" and oi_growth > 5:
        score += 3  # Strong short buildup is very bearish (good for PUT trades)
    
    # Volume-OI Divergence (strong conviction signal)
    if volume_oi_div is not None:
        if abs(volume_oi_div) > 50:
            score += 4  # Strong divergence = high conviction
        elif abs(volume_oi_div) > 30:
            score += 2
        elif abs(volume_oi_div) < 10:
            score -= 1  # Low divergence = weak signal
    
    # Basis Momentum (futures vs spot sentiment) - Optimized: lower threshold, higher points
    if basis_momentum is not None:
        if core == "TREND_LONG" and basis_momentum > 3:  # Lowered from 5 to 3
            score += 5  # Basis expanding = bullish (increased from +3)
        elif core == "TREND_LONG" and basis_momentum > 1:
            score += 2  # Moderate basis expansion
        elif core == "TREND_SHORT" and basis_momentum < -3:  # Lowered from -5 to -3
            score += 5  # Basis contracting = bearish (increased from +3)
        elif core == "TREND_SHORT" and basis_momentum < -1:
            score += 2  # Moderate basis contraction
    
    # PCR Z-Score (extreme detection)
    if pcr_zscore is not None:
        if core == "TREND_LONG" and pcr_zscore < -1.5:
            score += 4  # Oversold squeeze
        elif core == "TREND_SHORT" and pcr_zscore > 1.5:
            score += 4  # Overbought squeeze
    
    # Note: Net OI Flow check removed - redundant with individual options OI checks below
    
    # 5. RISK MANAGEMENT (10 points)
    # PCR interpretation is direction-specific:
    # - For CALL buys (LONG): Low PCR (<0.7) = puts being bought = bearish risk
    # - For PUT buys (SHORT): High PCR (>1.5) = puts being bought = bearish confirmation (good for PUT trades)!
    if core == "TREND_LONG":
        # For CALL buys: balanced PCR is best, avoid low PCR (put buying)
        if 0.8 <= pcr <= 1.3:
            score += 5  # Balanced
        elif 0.7 <= pcr < 0.8 or 1.3 < pcr <= 1.5:
            score += 3
        elif pcr < 0.7:
            score -= 3  # Low PCR = put buying = bearish risk for calls
    elif core == "TREND_SHORT":
        # For PUT buys: high PCR is actually good (puts being bought = bearish confirmation)
        if 1.2 <= pcr <= 2.0:
            score += 6  # High PCR = put buying = good for PUT trades
        elif 0.9 <= pcr < 1.2:
            score += 4
        elif pcr < 0.7:
            score -= 2  # Very low PCR = call buying = bearish risk for puts
    else:
        # Neutral: balanced is best
        if 0.8 <= pcr <= 1.3:
            score += 5
        elif 0.7 <= pcr < 0.8 or 1.3 < pcr <= 1.5:
            score += 3
    
    # Futures vs Options OI divergence analysis
    # Both building together = strong directional conviction
    # Divergence = hedging/rollover (weaker signal)
    if options_call_oi_chg is not None:
        if core == "TREND_LONG":
            # For LONG: Both futures OI and call OI building = strong bullish
            if oi_growth > 5 and options_call_oi_chg > 5:
                score += 5  # Strong alignment = both building
            elif oi_growth > 5 and options_call_oi_chg < -5:
                score -= 3  # Divergence = hedging (weaker signal)
        elif core == "TREND_SHORT":
            # For SHORT: Futures OI building (shorts) + Put OI building = strong bearish
            if options_put_oi_chg is not None:
                if oi_growth > 5 and options_put_oi_chg > 5:
                    score += 5  # Strong alignment = both building
                elif oi_growth > 5 and options_put_oi_chg < -5:
                    score -= 3  # Divergence = hedging (weaker signal)
    # Shock memory soft (minor penalty)
    if bool(row.get("shock_memory_soft")):
        score -= 2
    # Expansion bias (might mean move is late)
    if bool(row.get("expansion_bias")):
        score -= 2
    
    return float(np.clip(score, 0.0, 100.0))


def _generate_entry_exit_levels(row: pd.Series) -> Dict:
    """Generate entry, exit, and risk parameters for directional trades."""
    current_price = float(row.get('close') or 0)
    core = str(row.get('core_label') or '')
    
    if current_price == 0:
        return {}
    
    if core == 'TREND_LONG':
        entry = current_price
        stop_loss = current_price * 0.98  # 2% stop
        target1 = current_price * 1.02   # 2% target
        target2 = current_price * 1.035  # 3.5% target
        target3 = current_price * 1.05   # 5% target
        risk_reward = (target2 - entry) / (entry - stop_loss) if (entry - stop_loss) > 0 else 0.0
    elif core == 'TREND_SHORT':
        entry = current_price
        stop_loss = current_price * 1.02  # 2% stop
        target1 = current_price * 0.98    # 2% target
        target2 = current_price * 0.965   # 3.5% target
        target3 = current_price * 0.95    # 5% target
        risk_reward = (entry - target2) / (stop_loss - entry) if (stop_loss - entry) > 0 else 0.0
    else:
        return {}
    
    return {
        'entry_level': round(entry, 2),
        'stop_loss': round(stop_loss, 2),
        'target1': round(target1, 2),
        'target2': round(target2, 2),
        'target3': round(target3, 2),
        'risk_reward': round(risk_reward, 2)
    }


def _calculate_risk_metrics(row: pd.Series) -> Dict:
    """Calculate risk metrics for position sizing and management."""
    current_price = float(row.get('close') or 0)
    ivp = float(row.get('IVPercentile') or 0)
    daily_range = float(row.get('avg_daily_range_pct') or 0)
    
    if current_price == 0:
        return {}
    
    # Value at Risk (simplified)
    var_1day = current_price * 0.02  # 2% VaR
    var_5day = current_price * 0.045  # 4.5% VaR
    
    # Position sizing based on IV regime
    if ivp > 75:
        position_size_multiplier = 0.6  # Reduce size (high IV = high risk)
        recommended_position_size = "REDUCED (50-70% of normal)"
    elif ivp < 25:
        position_size_multiplier = 1.25  # Increase size (low IV = lower risk)
        recommended_position_size = "INCREASED (120-130% of normal)"
    else:
        position_size_multiplier = 1.0  # Normal size
        recommended_position_size = "NORMAL (100%)"
    
    # Risk score (0-100)
    risk_score = 50  # Base score
    if ivp > 80:
        risk_score += 20
    if daily_range > 3.0:
        risk_score += 10
    
    risk_score = min(100, risk_score)
    risk_level = "HIGH" if risk_score > 70 else "MODERATE" if risk_score > 40 else "LOW"
    
    return {
        'var_1day': round(var_1day, 2),
        'var_5day': round(var_5day, 2),
        'position_size_multiplier': round(position_size_multiplier, 2),
        'recommended_position_size': recommended_position_size,
        'risk_score': round(risk_score, 0),
        'risk_level': risk_level
    }


def _calc_slope(series: pd.Series) -> float:
    series = series.dropna()
    if len(series) < 2:
        return 0.0
    x = np.arange(len(series))
    y = series.values
    slope, _ = np.polyfit(x, y, 1)
    return float(slope)


def _alignment_ratio(price_pct: pd.Series, oi_pct: pd.Series) -> float:
    mask = (~price_pct.isna()) & (~oi_pct.isna())
    if not mask.any():
        return 0.0
    price_vals = pd.to_numeric(price_pct[mask], errors="coerce")
    oi_vals = pd.to_numeric(oi_pct[mask], errors="coerce")
    valid_mask = (~price_vals.isna()) & (~oi_vals.isna())
    if not valid_mask.any():
        return 0.0
    price_vals = price_vals[valid_mask]
    oi_vals = oi_vals[valid_mask]
    aligned = np.sign(price_vals) == np.sign(oi_vals)
    return float(aligned.mean())


def _volatility_stability(daily_range_pct: pd.Series) -> float:
    vals = daily_range_pct.dropna()
    if len(vals) < MIN_ROWS_REQUIRED:
        return 0.0
    std = vals.std()
    if std == 0 or np.isnan(std):
        return 1.0
    # map lower std to higher stability (0..1)
    stability = 1 / (1 + std)
    return float(np.clip(stability, 0.0, 1.0))


def _recent_direction(price_pct: pd.Series) -> float:
    vals = price_pct.dropna()
    if len(vals) == 0:
        return 0.0
    return vals.iloc[-1]


def _rsi(close: pd.Series, period: int) -> pd.Series:
    close = close.astype(float)
    delta = close.diff()
    gain = (delta.where(delta > 0, 0.0)).rolling(window=period, min_periods=period).mean()
    loss = (-delta.where(delta < 0, 0.0)).rolling(window=period, min_periods=period).mean()
    rs = gain / loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi


def _atr(high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> pd.Series:
    high = high.astype(float)
    low = low.astype(float)
    close = close.astype(float)
    prev_close = close.shift(1)
    tr = pd.concat([
        (high - low).abs(),
        (high - prev_close).abs(),
        (low - prev_close).abs()
    ], axis=1).max(axis=1)
    atr = tr.rolling(window=period, min_periods=period).mean()
    return atr


def _get_atr_series(symbol: str, contract: str, grp_sorted: pd.DataFrame, df: pd.DataFrame) -> Tuple[pd.Series, bool]:
    """
    Calculate ATR, falling back to spot if futures history is insufficient.
    
    Returns:
        (atr14_series, used_spot_fallback)
    """
    # For spot contracts, no fallback needed (already using spot)
    if contract == 'spot':
        atr14_series = _atr(grp_sorted['high'], grp_sorted['low'], grp_sorted['close'], period=14)
        return atr14_series, False
    
    # Try futures contract first
    atr14_series = _atr(grp_sorted['high'], grp_sorted['low'], grp_sorted['close'], period=14)
    
    # If futures history insufficient, use spot
    if len(atr14_series.dropna()) < MIN_ATR_HISTORY_120:
        spot_data = df[
            (df['symbol'] == symbol) &
            (df['contract_type'] == 'spot')
        ].sort_values('date')
        
        if len(spot_data) >= MIN_ATR_HISTORY_120:
            spot_atr = _atr(spot_data['high'], spot_data['low'], spot_data['close'], period=14)
            return spot_atr, True
    
    return atr14_series, False


def _compression_quality(window: pd.DataFrame) -> str | None:
    """Classify compression quality over last ~10 bars.
    Returns one of: 'COMPRESSION_SAFE', 'COMPRESSION_DANGEROUS', 'COMPRESSION_UNKNOWN', or None.
    """
    try:
        if window is None or len(window) < 10:
            return None
        # Use last 10, split 5/5
        recent = window.tail(5)
        earlier = window.tail(10).head(5)
        if 'daily_range_pct' not in window.columns:
            return None
        recent_range = float(pd.to_numeric(recent['daily_range_pct'], errors='coerce').dropna().mean()) if not recent.empty else np.nan
        earlier_range = float(pd.to_numeric(earlier['daily_range_pct'], errors='coerce').dropna().mean()) if not earlier.empty else np.nan
        rcr = (recent_range / earlier_range) if (earlier_range and not np.isnan(earlier_range) and earlier_range > 0) else 1.0
        # Volume trend (futures-first relevance; still compute if present)
        vol_declining = False
        if 'volume' in window.columns:
            recent_vol = float(pd.to_numeric(recent['volume'], errors='coerce').dropna().mean()) if not recent.empty else np.nan
            earlier_vol = float(pd.to_numeric(earlier['volume'], errors='coerce').dropna().mean()) if not earlier.empty else np.nan
            if earlier_vol and not np.isnan(earlier_vol) and earlier_vol > 0:
                vol_declining = (recent_vol / earlier_vol) < 0.8 if (recent_vol and not np.isnan(recent_vol)) else False
        # Post-event context: any notable spike in last 10 bars
        post_event = False
        try:
            last10 = window.tail(10)
            if 'daily_range_pct' in last10.columns:
                post_event = float(pd.to_numeric(last10['daily_range_pct'], errors='coerce').abs().max()) > 3.0
        except Exception:
            post_event = False
        # Decision
        if (rcr < 0.7) or (vol_declining and post_event):
            return 'COMPRESSION_DANGEROUS'
        if (0.8 <= rcr <= 1.2) and (not post_event):
            return 'COMPRESSION_SAFE'
        return 'COMPRESSION_UNKNOWN'
    except Exception:
        return None


def _categorize(row: Dict[str, float]) -> Tuple[str, str]:
    """
    Return (label, note)
    """
    slope_price = row['price_slope']
    slope_oi = row['oi_slope']
    align = row['alignment_ratio']
    vol_stab = row['vol_stability']
    avg_range = row['avg_daily_range']
    last_move = row['last_price_return']
    price_displacement = row['price_displacement']
    oi_growth_pct = row['oi_growth_pct']

    # Reject micro-range alignment
    if avg_range < MICRO_RANGE_THRESHOLD:
        effective_align = min(align, 0.4)
    else:
        effective_align = align

    # Trend Long bias
    if (
        slope_price > 0
        and slope_oi > 0
        and effective_align >= 0.65
        and price_displacement >= avg_range * MIN_TREND_DISPLACEMENT_MULT
    ):
        if last_move > 0:
            return "TREND_LONG", "Price+OI rising with consistent alignment"
        return "TREND_LONG", "Structure bullish; latest move paused"

    # Trend Short bias
    # For bearish trends, we want OI rising (short buildup), not falling
    # Price down + OI up = shorts building (strong bearish signal)
    # Note: For short buildup, price and OI move in opposite directions,
    # so alignment will be lower. We relax alignment requirement for SHORT.
    if (
        slope_price < 0
        and slope_oi > 0  # OI rising (short buildup)
        and effective_align >= 0.50  # Relaxed from 0.65 (price/OI move opposite in short buildup)
        and price_displacement >= avg_range * MIN_TREND_DISPLACEMENT_MULT
    ):
        if last_move < 0:
            return "TREND_SHORT", "Price falling with OI rising (short buildup)"
        return "TREND_SHORT", "Structure bearish; short buildup in progress"

    # Inventory rotation / option selling
    if (
        vol_stab > 0.6
        and (INV_ROTATION_RANGE_MIN <= avg_range <= INV_ROTATION_RANGE_MAX)
        and effective_align < INV_ROTATION_ALIGNMENT_MAX
        and price_displacement < avg_range * MIN_TREND_DISPLACEMENT_MULT * 0.75
        and abs(oi_growth_pct) >= MIN_OI_GROWTH_FOR_ROTATION
    ):
        return "INVENTORY_ROTATION", "OI rotating inside tight range - favor option selling"

    # Neutral short premium candidate (compression lane: < INV_ROTATION_RANGE_MIN)
    if vol_stab > 0.6 and avg_range < INV_ROTATION_RANGE_MIN and effective_align < INV_ROTATION_ALIGNMENT_MAX:
        return "NEUTRAL_SELL", "Low volatility and weak directional alignment"

    # Watch for breakout: tight range but alignment increasing
    if avg_range < 1.5 and (slope_price ** 2 + slope_oi ** 2) < 0.05 and 0.4 <= effective_align <= 0.6:
        return "WATCH_BREAKOUT", "Tightening range; alignment improving"

    # Range chop: volatility creeping up without clear direction
    if avg_range >= 2.5 and align < 0.4:
        return "CHOPPY", "Elevated daily range without structural bias"

    return "UNCLASSIFIED", "No dominant pattern detected"


def analyze_master(master_path: Path, lookback: int) -> pd.DataFrame:
    if not master_path.exists():
        raise FileNotFoundError(f"Master file not found: {master_path}")

    df = pd.read_csv(master_path, parse_dates=['date', 'expiry'])
    if df.empty:
        raise ValueError("Master file is empty.")

    df['date'] = df['date'].dt.date
    df.sort_values(['symbol', 'contract_type', 'date'], inplace=True)

    summaries: List[Dict] = []

    for (symbol, contract), grp in df.groupby(['symbol', 'contract_type']):
        window = grp.tail(lookback).copy()
        if len(window) < MIN_ROWS_REQUIRED:
            continue

        # Data validation: check for critical missing fields
        try:
            required_fields = ['close', 'high', 'low', 'daily_range_pct']
            missing = [f for f in required_fields if f not in window.columns or window[f].isna().all()]
            if missing:
                print(f"WARNING: {symbol} [{contract}] missing required fields: {missing}", file=sys.stderr)
        except Exception as e:
            print(f"ERROR: Data validation failed for {symbol} [{contract}]: {e}", file=sys.stderr)

        # Days-to-expiry (for futures legs)
        dte = None
        if contract != 'spot' and 'expiry' in window.columns and window['expiry'].notna().any():
            try:
                last_day = pd.to_datetime(window['date'].iloc[-1])
                last_exp = pd.to_datetime(window['expiry'].dropna().iloc[-1])
                dte = max(0, (last_exp.date() - last_day.date()).days)
            except Exception:
                dte = None

        # Timing indicators computed on full group history
        grp_sorted = grp.sort_values('date').copy()
        rsi2_series = _rsi(grp_sorted['close'], 2)
        rsi3_series = _rsi(grp_sorted['close'], 3)
        # Hybrid ATR: use spot fallback if futures history insufficient
        atr14_series, used_spot_atr = _get_atr_series(symbol, contract, grp_sorted, df)

        # Basis Analysis (Futures vs Spot) - sentiment indicator
        current_basis = None
        basis_percentage = None
        basis_momentum = None
        if contract != 'spot':
            spot_data = df[(df['symbol'] == symbol) & (df['contract_type'] == 'spot')].sort_values('date')
            if not spot_data.empty and len(window) > 0:
                current_future = float(window['close'].iloc[-1])
                current_spot = float(spot_data['close'].iloc[-1]) if len(spot_data) > 0 else None
                if current_spot and current_spot > 0:
                    current_basis = current_future - current_spot
                    basis_percentage = (current_basis / current_spot) * 100.0
                    # Basis momentum (if we have history)
                    if len(window) >= 2 and len(spot_data) >= 2:
                        prev_future = float(window['close'].iloc[-2])
                        prev_spot = float(spot_data['close'].iloc[-2])
                        prev_basis = prev_future - prev_spot
                        basis_momentum = current_basis - prev_basis

        # Calendar Spread Analysis (Next month vs Current month)
        calendar_spread = None
        calendar_spread_pct = None
        if contract == 'current':
            next_data = df[(df['symbol'] == symbol) & (df['contract_type'] == 'next')].sort_values('date')
            if not next_data.empty and len(window) > 0:
                current_price = float(window['close'].iloc[-1])
                next_price = float(next_data['close'].iloc[-1]) if len(next_data) > 0 else None
                if next_price and current_price > 0:
                    calendar_spread = next_price - current_price
                    calendar_spread_pct = (calendar_spread / current_price) * 100.0

        # Shock Memory (strong/soft) – detect recent abnormal spikes during compression (futures-first)
        shock_memory_strong = False
        shock_memory_soft = False
        if contract != 'spot':
            try:
                last5 = window.tail(min(5, len(window))).copy()
                max_range5 = (last5['daily_range_pct'].abs().max()
                              if 'daily_range_pct' in last5.columns else np.nan)
                oi_abs = last5['oi_change_pct'].abs().dropna() if 'oi_change_pct' in last5.columns else pd.Series(dtype=float)
                oi_spike_max = oi_abs.max() if not oi_abs.empty else np.nan
                overall_comp = (window['daily_range_pct'].dropna().mean() < 0.9) if 'daily_range_pct' in window.columns else False
                if overall_comp and not np.isnan(max_range5):
                    if (max_range5 >= 2.5) and (not np.isnan(oi_spike_max) and oi_spike_max >= 50):
                        shock_memory_strong = True
                    elif (2.0 <= max_range5 < 2.5) or (not np.isnan(oi_spike_max) and 30 <= oi_spike_max < 50):
                        shock_memory_soft = True
            except Exception:
                shock_memory_strong = False
                shock_memory_soft = False

        # OI z-score vs own history (future legs only)
        oi_zscore = None
        try:
            if 'oi' in grp_sorted.columns and grp_sorted['oi'].notna().any() and contract != 'spot':
                oi_hist = pd.to_numeric(grp_sorted['oi'], errors='coerce').dropna()
                if len(oi_hist) >= 10:
                    mu = oi_hist.mean()
                    sd = oi_hist.std(ddof=0) or 1.0
                    oi_zscore = float((oi_hist.iloc[-1] - mu) / sd)
        except Exception:
            oi_zscore = None
        # Percentiles for both 60 and 120 bar windows
        # Use adaptive windows: if we have less than 60/120 bars, use whatever history is available
        # (as long as it meets minimum threshold) to compute percentiles.
        atr_all = atr14_series.dropna()
        atr_current = atr_all.iloc[-1] if not atr_all.empty else np.nan
        atr_percentile_60 = np.nan
        atr_percentile_120 = np.nan
        
        # For 60-day window: use up to 60 bars, or all available if less
        if len(atr_all) >= MIN_ATR_HISTORY_60 and not np.isnan(atr_current):
            atr_window_60 = atr_all.tail(min(60, len(atr_all)))
            rank60 = (atr_window_60 <= atr_current).sum()
            atr_percentile_60 = rank60 / len(atr_window_60)
        
        # For 120-day window: use up to 120 bars, or all available if less
        if len(atr_all) >= MIN_ATR_HISTORY_120 and not np.isnan(atr_current):
            atr_window_120 = atr_all.tail(min(120, len(atr_all)))
            rank120 = (atr_window_120 <= atr_current).sum()
            atr_percentile_120 = rank120 / len(atr_window_120)

        # Additional regime context
        days_in_atr10 = None
        vol_extreme_distance = None
        if len(atr_all) >= MIN_ATR_HISTORY_120:
            try:
                atr_window_120 = atr_all.tail(min(120, len(atr_all)))
                thr10 = np.nanpercentile(atr_window_120.values, 10)
                days_in_atr10 = int((atr14_series.tail(60) <= thr10).sum())
            except Exception:
                days_in_atr10 = None
        if not np.isnan(atr_percentile_120):
            vol_extreme_distance = float(np.clip(abs(atr_percentile_120 - 0.5) * 2.0, 0.0, 1.0))

        price_slope = _calc_slope(window['close'])
        oi_slope = _calc_slope(window['oi'])
        alignment = _alignment_ratio(window['price_return_pct'], window['oi_change_pct'])
        vol_stability = _volatility_stability(window['daily_range_pct'])

        avg_range = window['daily_range_pct'].dropna().mean()
        # Liquidity (window-level): average oi/volume for futures legs
        avg_win_oi = window['oi'].dropna().mean() if 'oi' in window.columns else np.nan
        avg_win_vol = window['volume'].dropna().mean() if 'volume' in window.columns else np.nan
        avg_price_ret = window['price_return_pct'].dropna().mean()
        avg_oi_pct = window['oi_change_pct'].dropna().mean()
        last_price_ret = _recent_direction(window['price_return_pct'])
        # Net price displacement over window (%), compare to avg daily range
        try:
            start_px = float(window['close'].iloc[0])
            end_px = float(window['close'].iloc[-1])
            price_displacement = abs((end_px - start_px) / start_px * 100.0)
        except Exception:
            price_displacement = None
        oi_start = window['oi'].dropna().iloc[0] if window['oi'].dropna().any() else np.nan
        oi_end = window['oi'].dropna().iloc[-1] if window['oi'].dropna().any() else np.nan
        oi_growth_pct = 0.0
        if not np.isnan(oi_start) and oi_start != 0 and not np.isnan(oi_end):
            oi_growth_pct = ((oi_end - oi_start) / oi_start) * 100.0
        # Normalize OI slope by average OI in window (percent per bar)
        oi_slope_pct = 0.0
        if avg_win_oi and not np.isnan(avg_win_oi) and avg_win_oi > 0:
            oi_slope_pct = (oi_slope / avg_win_oi) * 100.0

        # OI Velocity & Acceleration (1st and 2nd derivatives for early signal detection)
        oi_velocity_current = None
        oi_acceleration = None
        if len(window) >= 2 and 'oi' in window.columns and contract != 'spot':
            oi_vals = window['oi'].dropna()
            if len(oi_vals) >= 2:
                oi_vals_array = oi_vals.values
                # OI Velocity: day-over-day rate of change (%)
                oi_velocity = np.diff(oi_vals_array) / oi_vals_array[:-1] * 100.0
                if len(oi_velocity) > 0:
                    oi_velocity_current = float(oi_velocity[-1])
                    # OI Acceleration: change in velocity (2nd derivative)
                    if len(oi_velocity) > 1:
                        oi_acceleration = float(oi_velocity[-1] - oi_velocity[-2])

        # Volume-OI Divergence (strong conviction signal)
        volume_oi_divergence = None
        if 'volume' in window.columns and len(window) >= 2 and contract != 'spot':
            current_vol = window['volume'].iloc[-1]
            prev_vol = window['volume'].iloc[-2]
            if prev_vol > 0 and not np.isnan(current_vol) and not np.isnan(prev_vol):
                volume_change_pct = ((current_vol - prev_vol) / prev_vol) * 100.0
                volume_oi_divergence = volume_change_pct - oi_growth_pct

        # Options OI metrics (calculated from window data, similar to futures OI)
        options_call_oi_start = None
        options_call_oi_end = None
        options_call_oi_change_pct = None
        options_put_oi_start = None
        options_put_oi_end = None
        options_put_oi_change_pct = None
        options_total_oi_start = None
        options_total_oi_end = None
        options_total_oi_change_pct = None
        options_pcr = None
        options_call_oi_slope = None
        options_put_oi_slope = None
        
        if 'options_call_oi' in window.columns and window['options_call_oi'].notna().any():
            options_call_oi_series = window['options_call_oi'].dropna()
            if len(options_call_oi_series) > 0:
                options_call_oi_start = float(options_call_oi_series.iloc[0])
                options_call_oi_end = float(options_call_oi_series.iloc[-1])
                if options_call_oi_start and options_call_oi_start > 0 and options_call_oi_end:
                    options_call_oi_change_pct = ((options_call_oi_end - options_call_oi_start) / options_call_oi_start) * 100.0
                # Calculate options call OI slope
                if len(options_call_oi_series) > 1:
                    options_call_oi_slope = _calc_slope(options_call_oi_series)
        
        if 'options_put_oi' in window.columns and window['options_put_oi'].notna().any():
            options_put_oi_series = window['options_put_oi'].dropna()
            if len(options_put_oi_series) > 0:
                options_put_oi_start = float(options_put_oi_series.iloc[0])
                options_put_oi_end = float(options_put_oi_series.iloc[-1])
                if options_put_oi_start and options_put_oi_start > 0 and options_put_oi_end:
                    options_put_oi_change_pct = ((options_put_oi_end - options_put_oi_start) / options_put_oi_start) * 100.0
                # Calculate options put OI slope
                if len(options_put_oi_series) > 1:
                    options_put_oi_slope = _calc_slope(options_put_oi_series)
        
        # Options total OI and PCR
        if options_call_oi_end is not None and options_put_oi_end is not None:
            options_total_oi_end = options_call_oi_end + options_put_oi_end
            if options_call_oi_end > 0:
                options_pcr = options_put_oi_end / options_call_oi_end
        elif 'options_pcr' in window.columns and window['options_pcr'].notna().any():
            # Fallback: use PCR from master file if available
            options_pcr = float(window['options_pcr'].dropna().iloc[-1])
        
        if options_call_oi_start is not None and options_put_oi_start is not None:
            options_total_oi_start = options_call_oi_start + options_put_oi_start
            if options_total_oi_start and options_total_oi_start > 0 and options_total_oi_end:
                options_total_oi_change_pct = ((options_total_oi_end - options_total_oi_start) / options_total_oi_start) * 100.0

        # PCR Momentum & Z-Score (extreme detection)
        pcr_momentum = None
        pcr_zscore = None
        if 'options_pcr' in window.columns and window['options_pcr'].notna().any():
            pcr_series = window['options_pcr'].dropna()
            if len(pcr_series) >= 2:
                current_pcr = float(pcr_series.iloc[-1])
                prev_pcr = float(pcr_series.iloc[-2])
                if prev_pcr > 0:
                    pcr_momentum = ((current_pcr - prev_pcr) / prev_pcr) * 100.0
            if len(pcr_series) >= 3:
                pcr_mean = float(pcr_series.mean())
                pcr_std = float(pcr_series.std()) if len(pcr_series) > 1 else 1.0
                if pcr_std > 0:
                    current_pcr = float(pcr_series.iloc[-1])
                    pcr_zscore = (current_pcr - pcr_mean) / pcr_std

        # Net OI Flow & Flow Sentiment (call OI change - put OI change)
        net_oi_flow = None
        flow_sentiment = None
        if len(window) >= 2:
            if 'options_call_oi' in window.columns and 'options_put_oi' in window.columns:
                prev_call_oi = window['options_call_oi'].iloc[-2] if len(window) >= 2 else None
                prev_put_oi = window['options_put_oi'].iloc[-2] if len(window) >= 2 else None
                curr_call_oi = options_call_oi_end
                curr_put_oi = options_put_oi_end
                
                if (prev_call_oi is not None and not np.isnan(prev_call_oi) and
                    prev_put_oi is not None and not np.isnan(prev_put_oi) and
                    curr_call_oi is not None and curr_put_oi is not None):
                    call_change = curr_call_oi - prev_call_oi
                    put_change = curr_put_oi - prev_put_oi
                    net_oi_flow = call_change - put_change
                    flow_sentiment = "BULLISH" if net_oi_flow > 0 else "BEARISH" if net_oi_flow < 0 else "NEUTRAL"

        # OI Skew (alternative to PCR, more intuitive)
        oi_skew = None
        if options_call_oi_end is not None and options_put_oi_end is not None:
            total_oi = options_call_oi_end + options_put_oi_end
            if total_oi > 0:
                oi_skew = ((options_call_oi_end - options_put_oi_end) / total_oi) * 100.0

        label, note = _categorize({
            'price_slope': price_slope,
            'oi_slope': oi_slope,
            'alignment_ratio': alignment,
            'vol_stability': vol_stability,
            'avg_daily_range': avg_range or 0.0,
            'last_price_return': last_price_ret or 0.0,
            'lookback_days': len(window),
            'price_displacement': price_displacement,
            'oi_growth_pct': oi_growth_pct,
        })

        # Core microstructure label (hierarchy Layer 1): price + OI only
        core_label = "NEUTRAL"
        if alignment is not None and price_displacement is not None:
            displacement_ok = price_displacement >= (avg_range or 0) * MIN_TREND_DISPLACEMENT_MULT
            # OI z-score: for directional trends, we want OI growing (above average) in both cases
            # Bullish: Price up + OI up (longs building) → positive z-score
            # Bearish: Price down + OI up (shorts building) → positive z-score
            oi_z_ok = abs(oi_zscore or 0) > 0.5  # OI significantly above average (either direction)
            if displacement_ok and alignment >= 0.65 and oi_z_ok and price_slope > 0 and oi_slope_pct > 0:
                core_label = "TREND_LONG"
            elif displacement_ok and alignment >= 0.50 and oi_z_ok and price_slope < 0 and oi_slope_pct > 0:
                # Note: oi_slope_pct > 0 for SHORT (OI rising = short buildup)
                # Alignment relaxed to 0.50 because price/OI move opposite in short buildup
                core_label = "TREND_SHORT"

        # Regime / expansion flags (local) for final label
        low_vol = (not np.isnan(atr_percentile_120) and atr_percentile_120 <= 0.60) or ((avg_range or 0) <= 1.8 and (vol_stability or 0) > 0.60)
        flat_oi = (abs(oi_growth_pct or 0) < 1.0) and (abs(oi_zscore or 0) < 0.5)
        # Expansion candidate logic:
        #   1) Clear core trend, OR
        #   2) ATR120 very high vs history, OR
        #   3) High ATR60 + high alignment + meaningful price displacement.
        # The displacement gate (>= 2x average daily range) prevents stable,
        # rotation-style compression names from being misclassified as expansion
        # purely on noise in alignment and short-term ATR.
        exp_candidate = (
            (core_label in ("TREND_LONG", "TREND_SHORT"))
            or (not np.isnan(atr_percentile_120) and atr_percentile_120 >= 0.75)
            or (
                ((atr_percentile_60 or 0) >= 0.70)
                and ((alignment or 0) >= 0.65)
                and (
                    price_displacement is not None
                    and (avg_range or 0) > 0
                    and price_displacement >= (avg_range or 0) * 2.0
                )
            )
        )
        # Coiling/expansion bias
        coiling_flag = bool(((avg_range or 0) < 1.2) and ((vol_stability or 0) > 0.7) and ((alignment or 0) >= 0.65))
        expansion_bias = bool(coiling_flag and (((atr_percentile_60 or 0) >= 0.70) or ((days_in_atr10 or 0) >= 30)))
        # Compression quality classification
        compression_quality = None
        if low_vol and (alignment or 0) <= 0.60 and flat_oi:
            compression_quality = _compression_quality(window)
        # Final regime label (Layer-3): compress / transition / expansion
        if low_vol and (alignment or 0) <= 0.60 and flat_oi:
            final_label = "COMPRESSION_MODE"
        elif exp_candidate:
            final_label = "EXPANSION_MODE"
        else:
            final_label = "TRANSITION_MODE"

        # Enforce hierarchy: core_label (price+OI) is preserved separately; final label is regime interpretation
        label = final_label

        # Seller distribution veto: rising OI with falling price over lookback (futures legs only)
        distribution_veto = False
        if contract != 'spot':
            try:
                if (price_displacement is not None and price_displacement <= -1.0) and \
                   ((oi_growth_pct or 0) > 0) and ((oi_zscore or 0) >= 0.7):
                    distribution_veto = True
                    label = "TRANSITION_MODE"
                    note = (note or "")
                    note = (str(note) + " | Distribution: rising OI with falling price (sell veto)").strip()
            except Exception:
                distribution_veto = False

        # Bearish slide veto: controlled down channel with elevated range and OI support (futures legs only)
        bearish_slide_veto = False
        if contract != 'spot':
            try:
                if (price_displacement is not None and price_displacement <= -2.0) and \
                   (price_slope < 0) and ((avg_range or 0) >= 1.0) and \
                   (((oi_growth_pct or 0) > 0) or ((oi_zscore or 0) >= 0.7)):
                    bearish_slide_veto = True
                    label = "EXPANSION_MODE"
                    note = (note or "")
                    note = (str(note) + " | Bearish slide: down channel with OI support (sell veto)").strip()
            except Exception:
                bearish_slide_veto = False

        # Annotate if ATR was computed from spot fallback
        if used_spot_atr:
            note = (note or "")
            note = (str(note) + " | ATR from spot fallback").strip()

        # Inputs for simpler 0–100 straddle-quality score
        # OI coefficient of variation over the analysis window
        oi_vals = window['oi'].dropna() if 'oi' in window.columns else pd.Series(dtype=float)
        oi_mean = float(oi_vals.mean()) if not oi_vals.empty else np.nan
        oi_std = float(oi_vals.std(ddof=0)) if not oi_vals.empty else np.nan
        oi_cv = (oi_std / oi_mean) if (oi_mean and not np.isnan(oi_mean) and oi_mean != 0) else np.nan

        # Realized volatility (annualised) from price returns if present; else fall back to daily_range_pct
        if 'price_return_pct' in window.columns and window['price_return_pct'].notna().any():
            ret_vals = pd.to_numeric(window['price_return_pct'], errors='coerce').dropna()
            rv = float(ret_vals.std(ddof=0)) * np.sqrt(252) if len(ret_vals) > 1 else 0.0
        else:
            # Approximate using daily_range_pct band as a rough proxy
            rng_vals = pd.to_numeric(window['daily_range_pct'], errors='coerce').dropna() if 'daily_range_pct' in window.columns else pd.Series(dtype=float)
            rv = float(rng_vals.std(ddof=0)) * np.sqrt(252) if len(rng_vals) > 1 else 0.0

        # Rollover participation proxy – use absolute OI growth percentage over the window
        rollover_pct = abs(oi_growth_pct or 0.0)

        score = _straddle_quality_score(
            oi_cv=oi_cv,
            avg_range=avg_range or 0.0,
            realized_vol=rv,
            rollover_pct=rollover_pct,
            alignment=alignment or 0.0,
        )

        summaries.append({
            'symbol': symbol,
            'contract_type': contract,
            'label': label,
            'core_label': core_label,
            'score': round(score, 2),
            'price_slope': round(price_slope, 4),
            'oi_slope': round(oi_slope, 4),
            'oi_slope_pct': round(oi_slope_pct, 4),
            'oi_velocity_current': round(oi_velocity_current, 4) if oi_velocity_current is not None else None,
            'oi_acceleration': round(oi_acceleration, 4) if oi_acceleration is not None else None,
            'volume_oi_divergence': round(volume_oi_divergence, 2) if volume_oi_divergence is not None else None,
            'alignment_ratio': round(alignment, 2),
            'volatility_stability': round(vol_stability, 2),
            'avg_daily_range_pct': round(avg_range or 0.0, 2),
            'avg_price_return_pct': round(avg_price_ret or 0.0, 2),
            'avg_oi_change_pct': round(avg_oi_pct or 0.0, 2),
            'last_price_return_pct': round(last_price_ret or 0.0, 2),
            'lookback_days': len(window),
            'price_displacement': round(price_displacement, 3),
            'oi_growth_pct': round(oi_growth_pct, 2),
            'oi_zscore': round(oi_zscore, 2) if oi_zscore is not None else None,
            'current_basis': round(current_basis, 2) if current_basis is not None else None,
            'basis_percentage': round(basis_percentage, 3) if basis_percentage is not None else None,
            'basis_momentum': round(basis_momentum, 2) if basis_momentum is not None else None,
            'calendar_spread': round(calendar_spread, 2) if calendar_spread is not None else None,
            'calendar_spread_pct': round(calendar_spread_pct, 3) if calendar_spread_pct is not None else None,
            'avg_window_oi': round(avg_win_oi, 0) if not np.isnan(avg_win_oi) else None,
            'avg_window_volume': round(avg_win_vol, 0) if not np.isnan(avg_win_vol) else None,
            'note': note,
            'last_date': window['date'].iloc[-1],
            'days_to_expiry': (int(dte) if dte is not None else None),
            'distribution_veto': distribution_veto,
            'bearish_slide_veto': bearish_slide_veto,
            'shock_memory_strong': shock_memory_strong,
            'shock_memory_soft': shock_memory_soft,
            'coiling_flag': coiling_flag,
            'expansion_bias': expansion_bias,
            'compression_quality': compression_quality,
            'days_in_atr10': days_in_atr10,
            'vol_extreme_distance': vol_extreme_distance,
            'rsi2': round(rsi2_series.iloc[-1], 2) if not rsi2_series.dropna().empty else None,
            'rsi3': round(rsi3_series.iloc[-1], 2) if not rsi3_series.dropna().empty else None,
            # Options OI metrics
            'options_call_oi': round(options_call_oi_end, 0) if options_call_oi_end is not None else None,
            'options_put_oi': round(options_put_oi_end, 0) if options_put_oi_end is not None else None,
            'options_total_oi': round(options_total_oi_end, 0) if options_total_oi_end is not None else None,
            'options_pcr': round(options_pcr, 3) if options_pcr is not None else None,
            'pcr_momentum': round(pcr_momentum, 2) if pcr_momentum is not None else None,
            'pcr_zscore': round(pcr_zscore, 2) if pcr_zscore is not None else None,
            'options_call_oi_change_pct': round(options_call_oi_change_pct, 2) if options_call_oi_change_pct is not None else None,
            'options_put_oi_change_pct': round(options_put_oi_change_pct, 2) if options_put_oi_change_pct is not None else None,
            'options_total_oi_change_pct': round(options_total_oi_change_pct, 2) if options_total_oi_change_pct is not None else None,
            'options_call_oi_slope': round(options_call_oi_slope, 2) if options_call_oi_slope is not None else None,
            'options_put_oi_slope': round(options_put_oi_slope, 2) if options_put_oi_slope is not None else None,
            'net_oi_flow': round(net_oi_flow, 0) if net_oi_flow is not None else None,
            'flow_sentiment': flow_sentiment,
            'oi_skew': round(oi_skew, 2) if oi_skew is not None else None,
            'atr14': round(atr_current, 4) if not np.isnan(atr_current) else None,
            'atr14_percentile60': round(atr_percentile_60, 3) if not np.isnan(atr_percentile_60) else None,
            'atr14_percentile120': round(atr_percentile_120, 3) if not np.isnan(atr_percentile_120) else None,
            'close': current_price,  # Add close price for entry/exit calculations
        })

    report_df = pd.DataFrame(summaries)
    if report_df.empty:
        return report_df

    # Attach derivative/IV context from latest options screener snapshot, if available.
    try:
        data_root = Path(__file__).resolve().parents[3] / "data"
        screener_files = sorted(data_root.glob("options_screener_*.csv"))
        if screener_files:
            latest = screener_files[-1]
            ctx = pd.read_csv(latest)
            # Expect at least: Instrument, ATMIV, ATMIVChange, IVPercentile, Event,
            # VolumeMultiple, FutureOIPercentChange, PCR, MaxPain, FuturePrice, etc.
            # Join on symbol (Instrument) only; context is per underlying.
            report_df = report_df.merge(
                ctx,
                how="left",
                left_on="symbol",
                right_on="Instrument",
                suffixes=("", "_ctx"),
            )
    except Exception as e:
        # If anything goes wrong, proceed without derivative context.
        print(f"WARNING: Failed to load options screener context: {e}", file=sys.stderr)

    # Calculate Max Pain Distance (after screener merge)
    if 'MaxPain' in report_df.columns and 'close' in report_df.columns:
        def _calc_max_pain_distance(row):
            max_pain = row.get('MaxPain')
            current_price = row.get('close')
            if max_pain and current_price and not pd.isna(max_pain) and not pd.isna(current_price) and max_pain > 0:
                return ((current_price - max_pain) / max_pain) * 100.0
            return None
        report_df['distance_from_maxpain'] = report_df.apply(_calc_max_pain_distance, axis=1)
    else:
        report_df['distance_from_maxpain'] = None

    # Timing signal: RSI(2) or RSI(3) < 10 and ATR at multi-month lows (<=10th pct) on stable low-range names
    def _timing_sig(row):
        rsi2 = row.get('rsi2')
        rsi3 = row.get('rsi3')
        atrp = row.get('atr14_percentile120')
        low_vol = (row.get('avg_daily_range_pct') is not None and row.get('avg_daily_range_pct') < 2.2 and
                   row.get('volatility_stability') is not None and row.get('volatility_stability') > 0.6)
        cond_rsi = (rsi2 is not None and rsi2 < 10) or (rsi3 is not None and rsi3 < 10)
        cond_atr = (atrp is not None and atrp <= 0.10)
        return "RSI_ATR_EXPANSION" if (low_vol and cond_rsi and cond_atr) else None

    report_df['timing_signal'] = report_df.apply(_timing_sig, axis=1)
    mask = report_df['timing_signal'].notna()
    report_df.loc[mask, 'note'] = report_df.loc[mask, 'note'].astype(str) + " | RSI(2/3)<10 & ATR low"

    # Annotate compression quality in notes for compression rows
    comp_mask = (report_df['label'] == 'COMPRESSION_MODE') & report_df['compression_quality'].notna()
    report_df.loc[comp_mask & (report_df['compression_quality'] == 'COMPRESSION_SAFE'), 'note'] = report_df.loc[comp_mask & (report_df['compression_quality'] == 'COMPRESSION_SAFE'), 'note'].astype(str) + " | Compression SAFE"
    report_df.loc[comp_mask & (report_df['compression_quality'] == 'COMPRESSION_DANGEROUS'), 'note'] = report_df.loc[comp_mask & (report_df['compression_quality'] == 'COMPRESSION_DANGEROUS'), 'note'].astype(str) + " | Compression DANGEROUS"

    # Liquidity tiers across symbols using within-report percentiles
    def _percentile(series: pd.Series, val):
        s = pd.to_numeric(series, errors='coerce').dropna()
        if len(s) == 0 or val is None or np.isnan(val):
            return np.nan
        return float((s <= val).sum() / len(s))

    liquidity_tiers = []
    inst_bias_flags = []
    for idx, row in report_df.iterrows():
        oi_p = _percentile(report_df['avg_window_oi'], row.get('avg_window_oi'))
        vol_p = _percentile(report_df['avg_window_volume'], row.get('avg_window_volume'))
        # Tiering: A if both >=0.7, B if both >=0.4, else C (spot rows have None -> C)
        if np.isnan(oi_p) or np.isnan(vol_p):
            tier = "C"
        elif oi_p >= 0.7 and vol_p >= 0.7:
            tier = "A"
        elif oi_p >= 0.4 and vol_p >= 0.4:
            tier = "B"
        else:
            tier = "C"
        liquidity_tiers.append(tier)
        # Institutional bias proxy: good alignment, stable vol, tight range, positive OI growth & z, and tier A/B
        align_ok = (row.get('alignment_ratio') or 0) >= 0.65
        stab_ok = (row.get('volatility_stability') or 0) > 0.6
        range_ok = (row.get('avg_daily_range_pct') or 99) < 2.0
        oi_sig = ((row.get('oi_growth_pct') or 0) > 0) and ((row.get('oi_zscore') or 0) > 0.5)
        inst_bias_flags.append(bool((tier in ("A", "B")) and align_ok and stab_ok and range_ok and oi_sig))

    report_df['liquidity_tier'] = liquidity_tiers
    report_df['institutional_bias'] = inst_bias_flags

    # Note hints for liquidity & institutional bias
    report_df.loc[report_df['liquidity_tier'] == 'A', 'note'] = report_df.loc[report_df['liquidity_tier'] == 'A', 'note'].astype(str) + " | Liquidity A"
    report_df.loc[report_df['liquidity_tier'] == 'B', 'note'] = report_df.loc[report_df['liquidity_tier'] == 'B', 'note'].astype(str) + " | Liquidity B"
    report_df.loc[report_df['institutional_bias'] == True, 'note'] = report_df.loc[report_df['institutional_bias'] == True, 'note'].astype(str) + " | Institutional bias"

    # SELL safety tiers and directional suppression
    def _sell_tier(row):
        atr120 = row.get('atr14_percentile120')
        stab = row.get('volatility_stability')
        ctype = row.get('contract_type')
        dte = row.get('days_to_expiry')
        if atr120 is None or stab is None:
            return None
        # DTE-adjusted thresholds (tighter near expiry)
        safe_cut = 0.40
        moderate_cut = 0.75
        if isinstance(dte, (int, float)) and dte is not None:
            if dte <= 5:
                safe_cut = 0.30
                moderate_cut = 0.60
            elif dte <= 10:
                safe_cut = 0.40
                moderate_cut = 0.70
            else:
                safe_cut = 0.45
                moderate_cut = 0.75
        if ctype in ('current', 'next'):
            if atr120 < safe_cut and stab > 0.65: return "SELL_SAFE"
            if atr120 < moderate_cut and stab > 0.60: return "SELL_MODERATE"
            if 0.75 <= atr120 <= 0.90: return "SELL_CAUTION"
            return None
        # spot informational
        if atr120 < 0.40 and stab > 0.65: return "SELL_SAFE"
        if atr120 < 0.75 and stab > 0.60: return "SELL_MODERATE"
        if 0.75 <= atr120 <= 0.90: return "SELL_CAUTION"
        return None

    report_df['sell_tier'] = report_df.apply(_sell_tier, axis=1)

    # Expansion risk annotation (no promotion): flag high ATR120
    report_df['expansion_flag'] = (report_df['atr14_percentile120'].fillna(0) >= 0.75)
    mask_risk = report_df['expansion_flag']
    report_df.loc[mask_risk, 'note'] = report_df.loc[mask_risk, 'note'].astype(str) + " | ATR120 high (>=0.75) - expansion risk"

    # Suppress directional if low ATR60 and weak alignment
    mask_dir_suppress = (
        report_df['label'].isin(['TREND_LONG', 'TREND_SHORT'])
        & (report_df['atr14_percentile60'].fillna(1) < 0.40)
        & (report_df['alignment_ratio'].fillna(0) < 0.70)
    )
    report_df.loc[mask_dir_suppress, 'label'] = 'NEUTRAL_SELL'
    report_df.loc[mask_dir_suppress, 'note'] = report_df.loc[mask_dir_suppress, 'note'].astype(str) + " | Directional suppressed (ATR60 low & weak alignment)"

    # Append sell tier hints
    tier_notes = {
        "SELL_SAFE": "SELL safe (ATR120<0.40, stability>0.65)",
        "SELL_MODERATE": "SELL moderate (ATR120<0.75, stability ok)",
        "SELL_CAUTION": "SELL with caution (ATR120 0.75-0.90)",
    }
    report_df['note'] = report_df.apply(
        lambda r: (str(r['note']) + " | " + tier_notes.get(r['sell_tier'], "")).rstrip(" | ")
        if r.get('sell_tier') else r['note'],
        axis=1
    )

    # High-level recommendations (legacy - kept for backward compatibility)
    def _dir_reco(row):
        atr60 = row.get('atr14_percentile60')
        align = row.get('alignment_ratio') or 0.0
        atr120 = row.get('atr14_percentile120') or 0.0
        tier = row.get('liquidity_tier')
        core = (row.get('core_label') or "")
        if atr60 is None:
            return None
        # Consolidation regime: reduce alignment gate for expansion candidates
        is_consol = (
            (row.get('avg_daily_range_pct') or 0) < 2.0 and (row.get('volatility_stability') or 0) > 0.6
        ) or (atr120 <= 0.60)
        # Hard vetoes
        if (atr60 < 0.40) or (tier == 'C') or (atr120 >= 0.90):
            return "AVOID"
        # Core trend present: alignment matters less, but require tradability
        if core in ("TREND_LONG", "TREND_SHORT"):
            return "OK"
        # No core trend: in consolidation, allow expansion 'OK' on ATR60 alone
        if is_consol and atr60 >= 0.70 and atr120 < 0.90:
            return "OK"
        # Otherwise require stronger alignment
        if atr60 >= 0.70 and align >= 0.70 and atr120 < 0.90:
            return "OK"
        return "NEUTRAL"
    
    # Assign legacy directional_recommendation for backward compatibility
    report_df['directional_recommendation'] = report_df.apply(_dir_reco, axis=1)

    # Sellability score (futures-first): 0.50 stability, 0.25 tight range, 0.25 low ATR120 distance from median
    def _sellability_score(row):
        stab = row.get('volatility_stability') or 0.0            # higher is better (0..1)
        rng = row.get('avg_daily_range_pct') or 0.0              # lower is better
        atr120 = row.get('atr14_percentile120')                  # lower is better
        vext = row.get('vol_extreme_distance')
        # Normalize range to [0..1] on a 0..3% band; clamp
        rng_norm = min(1.0, max(0.0, rng / 3.0))
        atr_comp = 0.0 if (atr120 is None) else (1.0 - min(1.0, max(0.0, atr120)))
        vext_comp = 0.0 if (vext is None or np.isnan(vext)) else (1.0 - float(vext))
        score = 0.50 * stab + 0.25 * (1.0 - rng_norm) + 0.25 * max(atr_comp, vext_comp)
        return round(score, 3)

    report_df['sellability_score'] = report_df.apply(_sellability_score, axis=1)

    # Intelligent short-straddle score (0–100) combining engine stats + options_screener context
    report_df['short_straddle_score'] = report_df.apply(_short_straddle_score, axis=1)

    # Directional trade score (0–100) for 1-5 day call/put buys
    report_df['directional_trade_score'] = report_df.apply(_directional_trade_score, axis=1)

    # Generate entry/exit levels for directional trades
    entry_exit_data = report_df.apply(_generate_entry_exit_levels, axis=1)
    for col in ['entry_level', 'stop_loss', 'target1', 'target2', 'target3', 'risk_reward']:
        report_df[col] = entry_exit_data.apply(lambda x: x.get(col) if isinstance(x, dict) else None)

    # Calculate risk metrics
    risk_data = report_df.apply(_calculate_risk_metrics, axis=1)
    for col in ['var_1day', 'var_5day', 'position_size_multiplier', 'recommended_position_size', 'risk_score', 'risk_level']:
        report_df[col] = risk_data.apply(lambda x: x.get(col) if isinstance(x, dict) else None)

    # Directional trade recommendation based on score
    def _directional_trade_reco(row):
        score = float(row.get('directional_trade_score') or 0.0)
        core = str(row.get('core_label') or "")
        
        # Must have a core trend for directional trades
        if core not in ("TREND_LONG", "TREND_SHORT"):
            return "NEUTRAL"
        
        # Score-based thresholds
        if score >= 75:
            return "STRONG_BUY"
        elif score >= 60:
            return "BUY"
        elif score >= 40:
            return "CAUTION"
        elif score > 0:
            return "AVOID"
        else:
            return "AVOID"  # Hard vetoes triggered
    
    report_df['directional_trade_recommendation'] = report_df.apply(_directional_trade_reco, axis=1)
    
    # Directional candidate flag: strong buy or buy with good conditions
    report_df['directional_candidate'] = report_df.apply(
        lambda r: bool(
            (r.get('directional_trade_recommendation') in ('STRONG_BUY', 'BUY'))
            and (r.get('core_label') in ('TREND_LONG', 'TREND_SHORT'))
            and (r.get('liquidity_tier') in ('A', 'B'))
            and (not bool(r.get('distribution_veto')))
            and (not bool(r.get('bearish_slide_veto')))
            and (not bool(r.get('shock_memory_strong')))
        ),
        axis=1
    )

    def _sell_reco(row):
        # Distribution or bearish-slide veto overrides everything
        if bool(row.get('distribution_veto')) or bool(row.get('bearish_slide_veto')):
            return "AVOID"
        # Hard veto on extreme expansion risk
        if (row.get('atr14_percentile120') or 0) >= 0.90:
            return "AVOID"
        # Futures-first compression gating
        if row.get('contract_type') != 'current':
            return "AVOID"
        label = row.get('label')
        # Allow certain rollover-neutral structures that are effectively
        # tight, low-vol coils to be treated like compression for selling.
        low_range = (row.get('avg_daily_range_pct') or 99) <= 1.5
        stab_ok = (row.get('volatility_stability') or 0) > 0.7
        no_exp = not bool(row.get('expansion_flag'))
        rollover_friendly = (label == 'ROLLOVER_NEUTRAL') and low_range and stab_ok and no_exp
        if not (label == 'COMPRESSION_MODE' or rollover_friendly):
            return "CAUTION"
        score = row.get('sellability_score') or 0.0
        dte = row.get('days_to_expiry')
        # Tighten thresholds as expiry approaches
        adj = 0.0
        if isinstance(dte, (int, float)) and dte is not None:
            if dte <= 5:
                adj = 0.05
            elif dte <= 10:
                adj = 0.02
        # Base tier
        if score >= (0.70 + adj):
            tier = "SAFE"
        elif score >= (0.55 + adj):
            tier = "MODERATE"
        elif score >= (0.40 + adj):
            tier = "CAUTION"
        else:
            tier = "AVOID"
        # Shock memory veto/downgrade
        if bool(row.get('shock_memory_strong')):
            tier = "AVOID"
        elif bool(row.get('shock_memory_soft')):
            if tier == "SAFE": tier = "MODERATE"
            elif tier == "MODERATE": tier = "CAUTION"
        # Compression quality cap
        if row.get('label') == 'COMPRESSION_MODE' and row.get('compression_quality') == 'COMPRESSION_DANGEROUS':
            if tier in ("SAFE", "MODERATE"): tier = "CAUTION"
        # Expansion bias cap
        if bool(row.get('expansion_bias')) and tier in ("SAFE", "MODERATE"):
            tier = "CAUTION"
        # Illiquidity cap
        if (row.get('liquidity_tier') == 'C') or ((row.get('avg_window_oi') or 0) < 1000):
            if tier in ("SAFE", "MODERATE"): tier = "CAUTION"
        return tier

    report_df['sell_recommendation'] = report_df.apply(_sell_reco, axis=1)
    # Final short-straddle candidate gate: use the intelligent score plus hard vetoes.
    report_df['sell_candidate'] = report_df.apply(
        lambda r: bool(
            (r.get('contract_type') == 'current')
            and ((r.get('short_straddle_score') or 0.0) >= 70.0)
            and (r.get('core_label') == 'NEUTRAL')
            and (not bool(r.get('distribution_veto')))
            and (not bool(r.get('bearish_slide_veto')))
            and (not bool(r.get('expansion_flag')))
            and (r.get('liquidity_tier') in ('A', 'B'))
            and ((r.get('days_to_expiry') or 0) >= 7)
            and ((r.get('days_to_expiry') or 0) <= 21)
        ),
        axis=1
    )

    # Policy brief summary
    def _brief(row):
        parts = []
        core = row.get('core_label') or row.get('label') or "NA"
        parts.append(str(core))
        # Directional trade recommendation (new, for 1-5 day call/put buys)
        dtr = row.get('directional_trade_recommendation')
        if dtr and dtr != 'NEUTRAL':
            parts.append(f"DirTrade:{dtr}")
        # Legacy directional recommendation (if still used)
        dr = row.get('directional_recommendation')
        if dr and not dtr:
            parts.append(f"Dir:{dr}")
        sr = row.get('sell_recommendation')
        if sr:
            parts.append(f"Sell:{sr}")
        lt = row.get('liquidity_tier')
        if lt:
            parts.append(f"Liq{lt}")
        if bool(row.get('institutional_bias')):
            parts.append("InstBias")
        if bool(row.get('expansion_flag')):
            parts.append("ExpRisk")
        cq = row.get('compression_quality')
        if cq == 'COMPRESSION_SAFE':
            parts.append('CompSafe')
        elif cq == 'COMPRESSION_DANGEROUS':
            parts.append('CompRisk')
        if bool(row.get('coiling_flag')):
            parts.append("Coil")
        if bool(row.get('shock_memory_strong')):
            parts.append("Shock")
        if row.get('contract_type') == 'current':
            parts.append("FutFirst")
        return " | ".join(parts)

    report_df['policy_brief'] = report_df.apply(_brief, axis=1)

    # Comprehensive summary note with justification and recommendation
    def _generate_summary_note(row):
        """Generate detailed summary note with justification, recommendation, and key data."""
        parts = []
        
        symbol = row.get('symbol', 'N/A')
        contract = row.get('contract_type', 'N/A')
        core = row.get('core_label', 'NEUTRAL')
        label = row.get('label', 'UNKNOWN')
        
        # 1. PRIMARY RECOMMENDATION
        sell_reco = row.get('sell_recommendation')
        dir_reco = row.get('directional_trade_recommendation')
        sell_candidate = bool(row.get('sell_candidate'))
        dir_candidate = bool(row.get('directional_candidate'))
        
        if sell_candidate and sell_reco in ('SAFE', 'MODERATE'):
            parts.append(f"✅ SELL STRADDLE ({sell_reco}): Short-straddle candidate")
        elif dir_candidate and dir_reco in ('STRONG_BUY', 'BUY'):
            direction = "CALL" if core == 'TREND_LONG' else "PUT"
            parts.append(f"✅ BUY {direction} ({dir_reco}): Directional trade opportunity")
        elif sell_reco == 'AVOID' or (dir_reco == 'AVOID' and not dir_candidate):
            parts.append(f"❌ AVOID: High risk or poor setup")
        elif sell_reco in ('CAUTION', 'MODERATE') or dir_reco in ('CAUTION', 'NEUTRAL'):
            parts.append(f"⚠️ CAUTION: Monitor conditions before entry")
        else:
            parts.append(f"➡️ NEUTRAL: No clear opportunity")
        
        # 2. KEY METRICS SUMMARY
        metrics = []
        
        # Regime
        if label == 'COMPRESSION_MODE':
            metrics.append(f"Compression regime")
        elif label == 'EXPANSION_MODE':
            metrics.append(f"Expansion regime")
        elif label == 'TRANSITION_MODE':
            metrics.append(f"Transition regime")
        
        # Core trend
        if core == 'TREND_LONG':
            metrics.append(f"Bullish trend")
        elif core == 'TREND_SHORT':
            metrics.append(f"Bearish trend")
        else:
            metrics.append(f"Neutral structure")
        
        # Alignment
        align = row.get('alignment_ratio')
        if align is not None:
            if align >= 0.65:
                metrics.append(f"Strong alignment ({align:.2f})")
            elif align >= 0.50:
                metrics.append(f"Moderate alignment ({align:.2f})")
            else:
                metrics.append(f"Low alignment ({align:.2f})")
        
        # Volatility
        atr120 = row.get('atr14_percentile120')
        if atr120 is not None:
            if atr120 < 0.40:
                metrics.append(f"Low vol (ATR120: {atr120:.1%})")
            elif atr120 >= 0.75:
                metrics.append(f"High vol (ATR120: {atr120:.1%})")
            else:
                metrics.append(f"Moderate vol (ATR120: {atr120:.1%})")
        
        # Range
        avg_range = row.get('avg_daily_range_pct')
        if avg_range is not None:
            if avg_range < 1.5:
                metrics.append(f"Tight range ({avg_range:.2f}%)")
            elif avg_range > 3.0:
                metrics.append(f"Wide range ({avg_range:.2f}%)")
            else:
                metrics.append(f"Normal range ({avg_range:.2f}%)")
        
        if metrics:
            parts.append(" | ".join(metrics))
        
        # 3. OI ANALYSIS
        oi_parts = []
        
        # Futures OI
        oi_growth = row.get('oi_growth_pct')
        oi_z = row.get('oi_zscore')
        if oi_growth is not None:
            if abs(oi_growth) > 5:
                oi_parts.append(f"Futures OI: {oi_growth:+.1f}%")
            elif abs(oi_growth) > 2:
                oi_parts.append(f"Futures OI: {oi_growth:+.1f}% (moderate)")
        
        if oi_z is not None and abs(oi_z) > 0.5:
            oi_parts.append(f"OI z-score: {oi_z:.2f}")
        
        # Options OI
        options_call_chg = row.get('options_call_oi_change_pct')
        options_put_chg = row.get('options_put_oi_change_pct')
        options_pcr = row.get('options_pcr')
        
        if options_call_chg is not None and options_put_chg is not None:
            if abs(options_call_chg) > 5 or abs(options_put_chg) > 5:
                oi_parts.append(f"Options OI: Call {options_call_chg:+.1f}%, Put {options_put_chg:+.1f}%")
        
        if options_pcr is not None:
            if options_pcr > 1.3:
                oi_parts.append(f"PCR: {options_pcr:.2f} (put-heavy)")
            elif options_pcr < 0.7:
                oi_parts.append(f"PCR: {options_pcr:.2f} (call-heavy)")
            else:
                oi_parts.append(f"PCR: {options_pcr:.2f} (balanced)")
        
        # Futures vs Options divergence
        if oi_growth is not None and options_call_chg is not None:
            if abs(oi_growth) > 5 and abs(options_call_chg) < 5:
                oi_parts.append("Futures↑/Options→ (hedging)")
            elif oi_growth > 5 and options_call_chg > 5:
                oi_parts.append("Both↑ (strong conviction)")
        
        if oi_parts:
            parts.append("OI: " + " | ".join(oi_parts))
        
        # 4. SCORES & CONFIDENCE
        score_parts = []
        
        sell_score = row.get('short_straddle_score')
        dir_score = row.get('directional_trade_score')
        sellability = row.get('sellability_score')
        
        if sell_candidate and sell_score is not None:
            score_parts.append(f"Straddle Score: {sell_score:.0f}/100")
        if dir_candidate and dir_score is not None:
            score_parts.append(f"Directional Score: {dir_score:.0f}/100")
        if sellability is not None and sell_reco in ('SAFE', 'MODERATE'):
            score_parts.append(f"Sellability: {sellability:.2f}")
        
        if score_parts:
            parts.append(" | ".join(score_parts))
        
        # 5. RISK FACTORS
        risk_parts = []
        
        if bool(row.get('distribution_veto')):
            risk_parts.append("⚠️ Distribution risk")
        if bool(row.get('bearish_slide_veto')):
            risk_parts.append("⚠️ Bearish slide")
        if bool(row.get('shock_memory_strong')):
            risk_parts.append("⚠️ Recent volatility shock")
        if bool(row.get('expansion_flag')):
            risk_parts.append("⚠️ Expansion risk")
        if row.get('compression_quality') == 'COMPRESSION_DANGEROUS':
            risk_parts.append("⚠️ Dangerous compression")
        
        dte = row.get('days_to_expiry')
        if dte is not None:
            if dte < 7:
                risk_parts.append(f"⚠️ Low DTE ({dte}d)")
            elif dte > 21:
                risk_parts.append(f"⚠️ High DTE ({dte}d)")
        
        tier = row.get('liquidity_tier')
        if tier == 'C':
            risk_parts.append("⚠️ Low liquidity")
        
        if risk_parts:
            parts.append("Risks: " + " | ".join(risk_parts))
        
        # 6. OPPORTUNITIES / STRENGTHS
        opp_parts = []
        
        if bool(row.get('institutional_bias')):
            opp_parts.append("✅ Institutional flow")
        if row.get('compression_quality') == 'COMPRESSION_SAFE':
            opp_parts.append("✅ Safe compression")
        if bool(row.get('coiling_flag')):
            opp_parts.append("✅ Coiling pattern")
        if tier == 'A':
            opp_parts.append("✅ High liquidity")
        
        ivp = row.get('IVPercentile')
        if ivp is not None:
            if ivp < 40:
                opp_parts.append(f"✅ Low IV ({ivp:.0f}%)")
            elif ivp > 70:
                opp_parts.append(f"⚠️ High IV ({ivp:.0f}%)")
        
        if opp_parts:
            parts.append(" | ".join(opp_parts))
        
        # 7. TIMING SIGNAL
        timing = row.get('timing_signal')
        if timing:
            parts.append(f"⏰ Timing: {timing}")
        
        # Combine all parts
        summary = " | ".join(parts)
        return summary
    
    report_df['summary_note'] = report_df.apply(_generate_summary_note, axis=1)

    # Rollover overrides per symbol
    for symbol, grp in report_df.groupby('symbol'):
        curr = grp[grp['contract_type'] == 'current']
        nxt = grp[grp['contract_type'] == 'next']
        if curr.empty or nxt.empty:
            continue
        curr_idx = curr.index[0]
        nxt_idx = nxt.index[0]
        curr_row = report_df.loc[curr_idx]
        next_row = report_df.loc[nxt_idx]
        curr_disp = curr_row['price_displacement']
        next_disp = next_row['price_displacement']
        curr_range = curr_row['avg_daily_range_pct']
        next_range = next_row['avg_daily_range_pct']
        curr_growth = abs(curr_row['oi_growth_pct'])
        next_growth = abs(next_row['oi_growth_pct'])
        curr_oi_avg = float(curr_row.get('avg_window_oi') or 0.0)
        next_oi_avg = float(next_row.get('avg_window_oi') or 0.0)
        # Absolute rollover size (as fraction of current)
        rollover_ratio = (next_oi_avg / curr_oi_avg) if curr_oi_avg > 0 else 0.0
        # Relative growth multiple
        rollover_growth_mult = (next_growth / max(curr_growth, 0.01)) if next_growth is not None else 0.0

        strong_rollover = (
            (rollover_ratio >= 0.04) and  # at least 4% of current OI showing in next
            (rollover_growth_mult >= ROLL_OVER_THRESHOLD)
        )
        if strong_rollover and (
            curr_disp < curr_range * MIN_TREND_DISPLACEMENT_MULT and
            next_disp < next_range * MIN_TREND_DISPLACEMENT_MULT
        ):
            report_df.loc[[curr_idx, nxt_idx], 'label'] = "ROLLOVER_NEUTRAL"
            report_df.loc[[curr_idx, nxt_idx], 'note'] = (
                f"Next-month OI rollover (size {rollover_ratio:.2%}, x{rollover_growth_mult:.1f} growth) with flat price -> rollover rotation"
            )

    return report_df


def main():
    parser = argparse.ArgumentParser(description="Pro Desk Pattern Engine")
    parser.add_argument("--lookback", type=int, default=DEFAULT_LOOKBACK,
                        help="Number of most recent trading days per symbol")
    parser.add_argument("--output", type=str, default="data/pro_desk_pattern_report.csv",
                        help="Path to save the ranked pattern report")
    parser.add_argument("--top", type=int, default=10,
                        help="Number of top entries per label to print")
    args = parser.parse_args()

    report_df = analyze_master(MASTER_PATH, args.lookback)
    if report_df.empty:
        print("No symbols met the minimum data requirement.")
        return

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    report_df.sort_values('score', ascending=False).to_csv(output_path, index=False)
    print(f"Report saved to {output_path} ({len(report_df)} rows).")

    sections = [
        ("COMPRESSION_MODE", "Compression Mode (Best for Selling)"),
        ("EXPANSION_MODE", "Expansion Candidate (Avoid selling / Consider buying)"),
        ("TRANSITION_MODE", "Transition Mode (Avoid)"),
    ]
    for key, title in sections:
        subset = report_df[report_df['label'] == key].sort_values('score', ascending=False)
        if subset.empty:
            continue
        print(f"\n=== {title} (Top {min(args.top, len(subset))}) ===")
        for _, row in subset.head(args.top).iterrows():
            print(
                f"{row['symbol']} [{row['contract_type']}] "
                f"score={row['score']} core={row.get('core_label','')} "
                f"Dir:{row.get('directional_recommendation','')} "
                f"Sell:{row.get('sell_recommendation','')} "
                f"Stab={row.get('volatility_stability','')} "
                f"Range%={row.get('avg_daily_range_pct','')} "
                f"ATR60%={row.get('atr14_percentile60','')} "
                f"OI%={row.get('avg_oi_change_pct','')} ZOI={row.get('oi_zscore','')} "
                f"| {row['note']}"
            )
            # Print summary note if available
            if 'summary_note' in row and pd.notna(row.get('summary_note')):
                print(f"  📋 Summary: {row['summary_note']}")

    # Dedicated Top SELL candidates (current futures only, SAFE/MOD, no veto, no ExpRisk)
    sell_subset = report_df[(report_df['contract_type'] == 'current') &
                            (report_df['sell_candidate'] == True) &
                            (~report_df['expansion_flag']) &
                            (~report_df['distribution_veto']) &
                            (~report_df['bearish_slide_veto'])]
    if not sell_subset.empty:
        sell_subset = sell_subset.sort_values(['sellability_score', 'volatility_stability', 'avg_daily_range_pct'], ascending=[False, False, True])
        print(f"\n=== Top SELL candidates (current futs, SAFE/MOD, 7–21 DTE) (Top {min(args.top, len(sell_subset))}) ===")
        for _, row in sell_subset.head(args.top).iterrows():
            print(
                f"{row['symbol']} [DTE={row.get('days_to_expiry','?')}] "
                f"SellScore={row.get('sellability_score','')} Tier={row.get('sell_recommendation','')} "
                f"Stab={row.get('volatility_stability','')} Range%={row.get('avg_daily_range_pct','')} "
                f"ATR120%={row.get('atr14_percentile120','')} | {row.get('policy_brief','')}"
            )
            # Print summary note if available
            if 'summary_note' in row and pd.notna(row.get('summary_note')):
                print(f"  📋 Summary: {row['summary_note']}")

    # Dedicated Top DIRECTIONAL candidates (1-5 day call/put buys)
    dir_subset = report_df[(report_df['directional_candidate'] == True) &
                           (report_df['contract_type'] == 'current')]
    if not dir_subset.empty:
        dir_subset = dir_subset.sort_values(['directional_trade_score', 'alignment_ratio', 'oi_zscore'], ascending=[False, False, False])
        print(f"\n=== Top DIRECTIONAL candidates (1-5 day call/put buys) (Top {min(args.top, len(dir_subset))}) ===")
        for _, row in dir_subset.head(args.top).iterrows():
            direction = "CALL" if row.get('core_label') == 'TREND_LONG' else "PUT"
            print(
                f"{row['symbol']} [{direction}] "
                f"DirScore={row.get('directional_trade_score','')} Reco={row.get('directional_trade_recommendation','')} "
                f"Core={row.get('core_label','')} Align={row.get('alignment_ratio','')} "
                f"ATR60%={row.get('atr14_percentile60','')} OIZ={row.get('oi_zscore','')} "
                f"IV%={row.get('IVPercentile','')} | {row.get('policy_brief','')}"
            )
            # Print summary note if available
            if 'summary_note' in row and pd.notna(row.get('summary_note')):
                print(f"  📋 Summary: {row['summary_note']}")


if __name__ == "__main__":
    main()

