# Quick Start Guide

## 🚀 Complete Workflow: Scrape + Merge Sector Data

Follow these steps to enrich your stock list with sector hierarchy and market cap data.

---

## Step 1: Scrape Data from Screener.in

```bash
cd C:\nihil\finance_ai_ws\MB-POS-Filter\F4\helper
python sector-marketcap-scraper.py
```

**What happens:**
- Reads symbols from `../../../data/Nifty50stocks.csv`
- Scrapes sector + market cap from screener.in
- Saves to `output/sector_marketcap_YYYYMMDD_HHMMSS.csv`
- Takes ~2-3 minutes for 50 stocks

**Output example:**
```
output/sector_marketcap_20251022_143015.csv
```

---

## Step 2: Rename Output (Optional)

```bash
cd output
copy sector_marketcap_20251022_143015.csv sector_marketcap_latest.csv
```

**Why:** Makes it easier for `sector-copy.py` to find the latest file.

---

## Step 3: Merge with Your Stock List

**Edit `sector-copy.py` first:**
```python
# Update these paths:
STOCK_LIST_FILE = "../../../data/Nifty50stocks.csv"           # Your stock list
SCRAPED_DATA_FILE = "./output/sector_marketcap_latest.csv"    # Scraped data
OUTPUT_FILE = "./output/enriched_stocks.csv"                   # Final output
```

**Run merger:**
```bash
python sector-copy.py
```

**What happens:**
- Merges your stock list with scraped data
- Matches by Symbol column
- Saves to `output/enriched_stocks.csv`

---

## Result

You now have an enriched stock list with:
✅ All original columns from your stock list  
✅ Market_Cap_Crores  
✅ Sector_Level_1 (broad sector)  
✅ Sector_Level_2 (industry)  
✅ Sector_Level_3 (sub-industry)  
✅ Sector_Level_4 (specific category)  
✅ Scraping status and timestamp  

---

## Example Output

**Before (Nifty50stocks.csv):**
```csv
Symbol
RELIANCE
TCS
HDFCBANK
```

**After (enriched_stocks.csv):**
```csv
Symbol,Market_Cap_Crores,Sector_Level_1,Sector_Level_2,Sector_Level_3,Sector_Level_4,Status,Scraped_At
RELIANCE,1532000.45,Materials,Oil & Gas,Refineries,Petroleum Products,Success,2025-10-22 14:30:15
TCS,1287000.00,Information Technology,Software,IT Services,Software Products,Success,2025-10-22 14:30:18
HDFCBANK,985000.23,Financials,Banks,Private Banks,Large Private Banks,Success,2025-10-22 14:30:21
```

---

## Common Use Cases

### Use Case 1: Filter by Sector
```python
import pandas as pd

df = pd.read_csv("output/enriched_stocks.csv")

# Get only IT stocks
it_stocks = df[df['Sector_Level_1'] == 'Information Technology']
print(it_stocks)
```

### Use Case 2: Filter by Market Cap
```python
import pandas as pd

df = pd.read_csv("output/enriched_stocks.csv")

# Get large cap stocks (>50,000 Cr)
large_cap = df[df['Market_Cap_Crores'] > 50000]
print(large_cap)
```

### Use Case 3: Sector Distribution
```python
import pandas as pd

df = pd.read_csv("output/enriched_stocks.csv")

# Count stocks by sector
sector_dist = df['Sector_Level_1'].value_counts()
print(sector_dist)
```

---

## Troubleshooting

### Issue: "Input file not found"
**Solution:** 
```bash
# Check if file exists
dir ..\..\..\data\Nifty50stocks.csv

# If not, update INPUT_CSV in sector-marketcap-scraper.py
```

### Issue: "Scraped data file not found" (in sector-copy.py)
**Solution:**
```bash
# List available files
dir output

# Update SCRAPED_DATA_FILE to match actual filename
```

### Issue: No matches in merge
**Solution:** Check symbol format (uppercase, no spaces, NSE symbols)

---

## Tips

💡 **Run during off-peak hours** for better scraping success  
💡 **Keep timestamped outputs** for historical tracking  
💡 **Test with 5-10 stocks first** before running full list  
💡 **Check log file** if many failures occur  
💡 **Update data monthly** to keep market caps current  

---

## Next Steps

After enrichment, you can:
1. Use enriched data in your trading strategies
2. Filter stocks by sector for sector rotation
3. Create market cap-based portfolios
4. Analyze sector-wise performance
5. Feed into your backtesting frameworks

---

**Happy Trading! 📊🚀**

