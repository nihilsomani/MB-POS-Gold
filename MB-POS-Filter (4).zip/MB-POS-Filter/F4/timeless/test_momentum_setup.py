"""
Setup Validation Script for Momentum Breakout Scanner
======================================================

Run this script to validate your setup before running the main scanner.

Usage:
    python test_momentum_setup.py
"""

import sys
import os
from pathlib import Path

def test_imports():
    """Test if all required packages are installed"""
    print("\n" + "="*60)
    print("TESTING PACKAGE IMPORTS")
    print("="*60)
    
    required_packages = {
        'pandas': 'pandas',
        'numpy': 'numpy',
        'kiteconnect': 'kiteconnect',
        'pandas_ta': 'pandas_ta',
        'openpyxl': 'openpyxl',
    }
    
    missing = []
    
    for name, import_name in required_packages.items():
        try:
            __import__(import_name)
            print(f"✓ {name:20s} - OK")
        except ImportError:
            print(f"✗ {name:20s} - MISSING")
            missing.append(name)
    
    if missing:
        print(f"\n❌ Missing packages: {', '.join(missing)}")
        print(f"   Install with: pip install {' '.join(missing)}")
        return False
    else:
        print("\n✅ All required packages installed!")
        return True

def test_universe_file():
    """Test if universe CSV file exists"""
    print("\n" + "="*60)
    print("TESTING UNIVERSE FILE")
    print("="*60)
    
    # Check relative to script location
    script_dir = Path(__file__).parent
    universe_path = script_dir / ".." / "data" / "MCAP7000.csv"
    
    print(f"Looking for: {universe_path.resolve()}")
    
    if universe_path.exists():
        try:
            import pandas as pd
            df = pd.read_csv(universe_path)
            
            if 'Symbol' in df.columns:
                num_symbols = len(df['Symbol'].unique())
                print(f"✓ Universe file found")
                print(f"  - Path: {universe_path.resolve()}")
                print(f"  - Symbols: {num_symbols}")
                print(f"  - First 5: {df['Symbol'].head().tolist()}")
                return True
            else:
                print(f"✗ Universe file found but missing 'Symbol' column")
                print(f"  - Columns found: {df.columns.tolist()}")
                return False
        except Exception as e:
            print(f"✗ Error reading universe file: {e}")
            return False
    else:
        print(f"✗ Universe file not found")
        print(f"  - Expected location: {universe_path.resolve()}")
        print(f"  - Please create this file with a 'Symbol' column")
        return False

def test_api_credentials():
    """Test if API credentials are configured"""
    print("\n" + "="*60)
    print("TESTING API CREDENTIALS")
    print("="*60)
    
    try:
        from momentum_breakout_scanner import API_KEY, ACCESS_TOKEN
        
        # Check if they're still default/placeholder values
        default_key = "3bi2yh8g830vq3y6"
        default_token = "u7rj2D6CmkVVmahVO5ywn8p8GfRD1ZGX"
        
        if API_KEY and ACCESS_TOKEN:
            if API_KEY == default_key or ACCESS_TOKEN == default_token:
                print("⚠️  Using default credentials (may not work)")
                print("   Please update API_KEY and ACCESS_TOKEN in momentum_breakout_scanner.py")
                return "warning"
            else:
                print("✓ API credentials configured")
                print(f"  - API Key: {API_KEY[:10]}...")
                print(f"  - Access Token: {ACCESS_TOKEN[:10]}...")
                return True
        else:
            print("✗ API credentials not set")
            return False
            
    except ImportError as e:
        print(f"✗ Cannot import scanner module: {e}")
        return False

def test_kite_connection():
    """Test if Kite API connection works"""
    print("\n" + "="*60)
    print("TESTING KITE CONNECTION (OPTIONAL)")
    print("="*60)
    print("Attempting to connect to Kite API...")
    
    try:
        from momentum_breakout_scanner import API_KEY, ACCESS_TOKEN
        from kiteconnect import KiteConnect
        
        kite = KiteConnect(api_key=API_KEY)
        kite.set_access_token(ACCESS_TOKEN)
        
        # Try to fetch profile (lightweight API call)
        profile = kite.profile()
        
        print(f"✓ Kite connection successful!")
        print(f"  - User ID: {profile.get('user_id', 'N/A')}")
        print(f"  - User Name: {profile.get('user_name', 'N/A')}")
        print(f"  - Email: {profile.get('email', 'N/A')}")
        return True
        
    except Exception as e:
        print(f"✗ Kite connection failed: {e}")
        print(f"  - This is optional for testing, but required for actual scanning")
        print(f"  - Check your API credentials and access token validity")
        return False

def test_cache_directory():
    """Test if cache directory can be created"""
    print("\n" + "="*60)
    print("TESTING CACHE DIRECTORY")
    print("="*60)
    
    try:
        cache_dir = Path("MB_Breakout_Cache")
        cache_dir.mkdir(exist_ok=True)
        
        historical_dir = cache_dir / "historical"
        historical_dir.mkdir(exist_ok=True)
        
        # Test write permissions
        test_file = cache_dir / "test.txt"
        test_file.write_text("test")
        test_file.unlink()
        
        print(f"✓ Cache directory setup successful")
        print(f"  - Location: {cache_dir.resolve()}")
        return True
        
    except Exception as e:
        print(f"✗ Cache directory setup failed: {e}")
        return False

def test_scanner_module():
    """Test if scanner module can be imported"""
    print("\n" + "="*60)
    print("TESTING SCANNER MODULE")
    print("="*60)
    
    try:
        import momentum_breakout_scanner
        
        print("✓ Scanner module imported successfully")
        print(f"  - Config object: {hasattr(momentum_breakout_scanner, 'config')}")
        print(f"  - Main function: {hasattr(momentum_breakout_scanner, 'run_momentum_breakout_scanner')}")
        
        # Print configuration
        config = momentum_breakout_scanner.config
        print(f"\nCurrent Scanner Configuration:")
        print(f"  - Near high threshold: {config.near_high_threshold*100:.0f}%")
        print(f"  - Weekly gain required: {config.weekly_gain_threshold*100:.0f}%")
        print(f"  - Min turnover: ₹{config.min_avg_turnover/1e7:.0f} Cr")
        print(f"  - ATR range: {config.min_atr_percent:.1f}% - {config.max_atr_percent:.1f}%")
        
        return True
        
    except Exception as e:
        print(f"✗ Scanner module import failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all validation tests"""
    
    print("\n" + "#"*60)
    print("# MOMENTUM BREAKOUT SCANNER - SETUP VALIDATION")
    print("#"*60)
    
    results = {
        'imports': test_imports(),
        'universe': test_universe_file(),
        'api_creds': test_api_credentials(),
        'cache': test_cache_directory(),
        'scanner': test_scanner_module(),
        'kite': test_kite_connection(),
    }
    
    print("\n" + "="*60)
    print("VALIDATION SUMMARY")
    print("="*60)
    
    # Count results
    passed = sum(1 for v in results.values() if v is True)
    warnings = sum(1 for v in results.values() if v == "warning")
    failed = sum(1 for v in results.values() if v is False)
    
    print(f"\n✅ Passed:   {passed}/6")
    if warnings:
        print(f"⚠️  Warnings: {warnings}/6")
    print(f"❌ Failed:   {failed}/6")
    
    print("\nTest Results:")
    for name, result in results.items():
        if result is True:
            status = "✅ PASS"
        elif result == "warning":
            status = "⚠️  WARN"
        else:
            status = "❌ FAIL"
        print(f"  {status} - {name.upper()}")
    
    print("\n" + "="*60)
    
    if failed == 0:
        print("\n🎉 Setup validation complete! You're ready to run the scanner.")
        print("\nNext steps:")
        print("  1. Review/update API credentials if needed")
        print("  2. Run: python run_momentum_breakout.py --preset default")
        print("  3. Check QUICKSTART_MOMENTUM.md for usage guide")
        print("\n" + "="*60)
        return 0
    else:
        print("\n⚠️  Some tests failed. Please fix the issues above before running the scanner.")
        print("\nCommon fixes:")
        print("  - Missing packages: pip install -r requirements_momentum_scanner.txt")
        print("  - Universe file: Create ../data/MCAP7000.csv with Symbol column")
        print("  - API credentials: Update momentum_breakout_scanner.py lines 28-29")
        print("\n" + "="*60)
        return 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

