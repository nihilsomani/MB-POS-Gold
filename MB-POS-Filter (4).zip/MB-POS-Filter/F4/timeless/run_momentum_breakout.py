"""
Quick Runner for Momentum Breakout Scanner
==========================================

Simple script to run the momentum breakout scanner with different presets.

Usage:
    python run_momentum_breakout.py --preset conservative
    python run_momentum_breakout.py --preset aggressive
    python run_momentum_breakout.py --preset default
"""

import sys
import argparse
from datetime import datetime
from momentum_breakout_scanner import (
    run_momentum_breakout_scanner,
    config,
    logger
)


def apply_preset(preset_name: str):
    """Apply scanning preset configuration"""
    
    if preset_name == "conservative":
        logger.info("📊 Applying CONSERVATIVE preset")
        config.near_high_threshold = 0.98  # Within 2% of high
        config.weekly_gain_threshold = 0.15  # 15% weekly gain
        config.min_avg_turnover = 10e7  # ₹10 crore
        config.min_atr_percent = 3.0
        config.max_atr_percent = 10.0
        
    elif preset_name == "aggressive":
        logger.info("🚀 Applying AGGRESSIVE preset")
        config.near_high_threshold = 0.90  # Within 10% of high
        config.weekly_gain_threshold = 0.07  # 7% weekly gain
        config.min_avg_turnover = 2e7  # ₹2 crore
        config.min_atr_percent = 1.5
        config.max_atr_percent = 20.0
        
    elif preset_name == "momentum":
        logger.info("💪 Applying MOMENTUM preset (high weekly gains)")
        config.near_high_threshold = 0.95  # Within 5% of high
        config.weekly_gain_threshold = 0.20  # 20% weekly gain (strong)
        config.min_avg_turnover = 5e7  # ₹5 crore
        config.min_atr_percent = 2.0
        config.max_atr_percent = 15.0
        
    elif preset_name == "liquid":
        logger.info("💰 Applying LIQUID preset (high turnover stocks)")
        config.near_high_threshold = 0.95  # Within 5% of high
        config.weekly_gain_threshold = 0.10  # 10% weekly gain
        config.min_avg_turnover = 50e7  # ₹50 crore (very liquid)
        config.min_atr_percent = 2.0
        config.max_atr_percent = 15.0
        
    elif preset_name == "default":
        logger.info("⚙️  Using DEFAULT preset")
        # Default values already set in config
        pass
    
    else:
        logger.error(f"Unknown preset: {preset_name}")
        logger.info("Available presets: conservative, aggressive, momentum, liquid, default")
        sys.exit(1)
    
    # Print active configuration
    logger.info("-" * 60)
    logger.info("Active Scanner Configuration:")
    logger.info(f"  • Near High Threshold: {config.near_high_threshold*100:.0f}% (within {(1-config.near_high_threshold)*100:.0f}% of 3M high)")
    logger.info(f"  • Weekly Gain Required: {config.weekly_gain_threshold*100:.0f}%")
    logger.info(f"  • Min Avg Turnover: ₹{config.min_avg_turnover/1e7:.0f} Cr")
    logger.info(f"  • ATR % Range: {config.min_atr_percent:.1f}% - {config.max_atr_percent:.1f}%")
    logger.info("-" * 60)


def main():
    """Main runner function"""
    
    parser = argparse.ArgumentParser(
        description='Run Momentum Breakout Scanner with presets',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Presets:
  default       - Standard Weinstein/Pryzby settings (5% from high, 10% weekly)
  conservative  - High quality only (2% from high, 15% weekly, ₹10cr turnover)
  aggressive    - More signals (10% from high, 7% weekly, ₹2cr turnover)
  momentum      - Strong momentum focus (5% from high, 20% weekly)
  liquid        - Large-cap focus (5% from high, 10% weekly, ₹50cr turnover)

Examples:
  python run_momentum_breakout.py --preset default
  python run_momentum_breakout.py --preset conservative
  python run_momentum_breakout.py --preset aggressive
        """
    )
    
    parser.add_argument(
        '--preset',
        type=str,
        default='default',
        choices=['default', 'conservative', 'aggressive', 'momentum', 'liquid'],
        help='Scanner preset configuration'
    )
    
    args = parser.parse_args()
    
    # Print header
    print("\n" + "=" * 80)
    print(" MOMENTUM BREAKOUT SCANNER")
    print(" Stan Weinstein / Shake Pryzby Methodology")
    print("=" * 80)
    print(f" Run Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f" Preset: {args.preset.upper()}")
    print("=" * 80 + "\n")
    
    # Apply preset
    apply_preset(args.preset)
    
    # Run scanner
    try:
        run_momentum_breakout_scanner()
    except KeyboardInterrupt:
        logger.warning("\n⚠️  Scanner interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"\n❌ Scanner failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

