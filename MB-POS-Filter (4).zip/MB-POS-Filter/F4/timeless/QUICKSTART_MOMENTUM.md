# Quick Start Guide - Momentum Breakout Scanner

## 🚀 Get Started in 5 Minutes

### Step 1: Install Dependencies

```bash
cd C:\nihil\finance_ai_ws\MB-POS-Filter\F4\timeless
pip install -r requirements_momentum_scanner.txt
```

### Step 2: Configure API Credentials

Edit `momentum_breakout_scanner.py`:

```python
# Line 28-29
API_KEY = "your_kite_api_key"
ACCESS_TOKEN = "your_access_token"
```

Or set environment variables (recommended):
```bash
set KITE_API_KEY=your_api_key
set KITE_ACCESS_TOKEN=your_access_token
```

### Step 3: Prepare Universe File

Ensure you have a CSV file with stocks to scan:
- Default location: `MB-POS-Filter/F4/data/MCAP7000.csv`
- Must contain a column named `Symbol`
- Example:
  ```
  Symbol
  RELIANCE
  TCS
  INFY
  HDFC
  ...
  ```

### Step 4: Run the Scanner

#### Option A: Use Presets (Recommended)

```bash
# Default settings (balanced)
python run_momentum_breakout.py --preset default

# Conservative (high quality only)
python run_momentum_breakout.py --preset conservative

# Aggressive (more signals)
python run_momentum_breakout.py --preset aggressive

# Momentum focus (strong weekly gains)
python run_momentum_breakout.py --preset momentum

# Large-cap focus (high liquidity)
python run_momentum_breakout.py --preset liquid
```

#### Option B: Run Directly

```bash
python momentum_breakout_scanner.py
```

### Step 5: Check Results

Output files will be created in the same directory:
- `momentum_breakout_signals_YYYYMMDD_HHMMSS.xlsx`

Excel file contains all signals sorted by score:
- 🟢 Green rows: Score ≥75 (exceptional)
- 🟡 Yellow rows: Score 60-74 (good)
- ⚪ White rows: Score <60 (marginal)

## 📊 Understanding the Output

### Excel Columns Explained

| Column | What It Means | Look For |
|--------|---------------|----------|
| **Score** | Overall quality (0-100) | ≥75 = best |
| **Weekly Gain %** | Past week return | ≥15% = strong momentum |
| **Dist from High %** | How far from 3M high | ≤2% = very close to breakout |
| **Avg Turnover (Cr)** | Daily liquidity | ≥10cr = very liquid |
| **ATR %** | Volatility level | 3-8% = ideal |
| **Volume Ratio** | Volume vs average | ≥2x = strong confirmation |
| **Above 50MA** | Intermediate trend | ✓ = bullish |
| **Above 200MA** | Long-term trend | ✓ = strong trend |
| **RS Rating** | Strength vs market | ≥60 = outperformer |

### Reading a Signal

**Strong Signal Example:**
```
Symbol: RELIANCE
Score: 87.3
Weekly Gain %: 12.5%
Dist from High %: 1.2%
ATR %: 4.5%
Volume Ratio: 2.1x
Above 50MA: ✓
Above 200MA: ✓
RS Rating: 78
```

✅ **Interpretation:**
- Very high score (87.3) - exceptional setup
- Strong momentum (12.5% weekly)
- Very close to breakout (1.2% from high)
- Healthy volatility (4.5%)
- Volume surge (2.1x average)
- Trending on all timeframes
- Outperforming market (RS 78)

➡️ **Action:** High-priority trade candidate

---

**Weak Signal Example:**
```
Symbol: EXAMPLE
Score: 58.2
Weekly Gain %: 10.1%
Dist from High %: 4.8%
ATR %: 11.2%
Volume Ratio: 0.9x
Above 50MA: ✗
Above 200MA: ✗
RS Rating: 42
```

⚠️ **Interpretation:**
- Low score (58.2) - marginal
- Barely meets weekly threshold
- Still 4.8% from high
- High volatility (11.2%)
- No volume confirmation
- Below moving averages
- Underperforming market

➡️ **Action:** Pass or very small position

## 🎯 Quick Trading Guide

### 1. Prioritize by Score

- **Score 80-100**: Top priority, larger position size
- **Score 70-79**: Good setups, normal position size
- **Score 60-69**: Watchlist, small position
- **Score <60**: Generally avoid

### 2. Entry Timing

**Don't buy immediately on signal!**

Wait for:
- Volume confirmation on breakout day
- Price holding above breakout level
- No major resistance immediately overhead

**Entry approaches:**
1. **Aggressive**: Buy at market on signal day
2. **Conservative**: Wait for pullback to breakout level
3. **Confirmation**: Wait for close above 3M high with volume

### 3. Stop Loss

**Initial Stop:**
- Place 1.5-2× ATR below entry
- Or below most recent swing low
- Never more than 8-10% from entry

**Example:**
```
Entry: ₹1000
ATR: ₹30
Stop: ₹1000 - (2 × ₹30) = ₹940 (6% risk)
```

### 4. Position Sizing

**Formula:**
```
Position Size = (Account Risk ₹) / (Entry - Stop)
```

**Example:**
```
Account: ₹10,00,000
Risk per trade: 1% = ₹10,000
Entry: ₹1000
Stop: ₹940
Risk per share: ₹60

Position Size = ₹10,000 / ₹60 = 166 shares
```

### 5. Take Profit

**Short-term traders:**
- Target: +15-25% (1.5-2.5R)
- Time: 1-4 weeks

**Swing traders:**
- Target: +50-100% (5-10R)
- Time: 1-3 months
- Trail stop with 50MA

**Position traders:**
- No fixed target
- Trail with 50MA or 20MA
- Exit when trend breaks

## ⚙️ Preset Comparison

| Preset | Signals | Quality | Use Case |
|--------|---------|---------|----------|
| **Conservative** | Few | Very High | Capital preservation, high win rate |
| **Default** | Moderate | High | Balanced approach (recommended) |
| **Momentum** | Moderate | High | Catch explosive moves |
| **Aggressive** | Many | Mixed | Active traders, more opportunities |
| **Liquid** | Few | Very High | Large accounts, easy execution |

### When to Use Each Preset

**Conservative:**
- Bear market or choppy conditions
- New to momentum trading
- Want high win rate over quantity

**Default:**
- Most market conditions
- Following Weinstein methodology closely
- Balanced risk/reward

**Momentum:**
- Bull market
- Want to catch parabolic moves
- Can handle higher volatility

**Aggressive:**
- Very active trading style
- Can monitor many positions
- Experienced with breakouts

**Liquid:**
- Trading large capital
- Need guaranteed execution
- Focus on blue chips

## 🔧 Common Issues

### Issue: No signals found

**Solutions:**
1. Try aggressive preset: `--preset aggressive`
2. Check market conditions (scanner works best in bull markets)
3. Verify universe file has valid symbols
4. Check if it's a holiday/weekend

### Issue: Too many signals

**Solutions:**
1. Use conservative preset: `--preset conservative`
2. Filter by score: Only trade signals ≥75
3. Use RS Rating filter: Only trade RS ≥60

### Issue: Scanner is slow

**First run:** 15-30 minutes (fetching data) - normal
**Subsequent runs:** Should be faster (uses cache)

**To speed up:**
1. Reduce universe size (fewer stocks)
2. Cache is working (check `MB_Breakout_Cache/` folder)
3. Check internet connection

### Issue: API rate limit errors

**Solution:**
1. Increase delay: `config.api_delay_seconds = 0.5`
2. Run during off-peak hours
3. Check Kite API limits for your plan

## 📈 Advanced Tips

### 1. Combine with Sector Analysis

- If multiple signals from same sector → sector momentum
- Stronger signals when sector is trending

### 2. Market Regime Filter

- Scanner works best when NIFTY 50 is above 200MA
- In bear markets, raise quality bar (Score ≥80)

### 3. Re-scan Frequency

- Daily: For active traders
- Weekly: For swing traders
- After market rallies: Often find fresh breakouts

### 4. Watchlist Management

- Create watchlist from Score ≥70 signals
- Monitor for entry opportunities
- Track which setups work best for your style

### 5. Keep a Trading Journal

Track:
- Which scores work best for you
- Which presets generate better trades
- Win rate by RS Rating ranges
- Common failure patterns

## 📚 Next Steps

1. **Read full documentation**: `MOMENTUM_BREAKOUT_README.md`
2. **Study examples**: Check previous signal files
3. **Paper trade**: Test strategy before real money
4. **Backtest**: Use `timeless_market_backtester.py` as template
5. **Customize**: Adjust filters for your trading style

## 🆘 Support

For questions or issues:
1. Check `MOMENTUM_BREAKOUT_README.md` for detailed documentation
2. Review other scanners in `F4/scan/` folder for examples
3. Check Kite Connect documentation for API issues

---

**Remember:** This scanner finds opportunities. Successful trading requires:
- ✅ Proper risk management
- ✅ Entry/exit discipline
- ✅ Position sizing
- ✅ Market awareness
- ✅ Emotional control

**Good luck and happy trading! 🚀**

