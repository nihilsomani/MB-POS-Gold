"""
Quick cache inspector - shows what data is actually cached
"""

import os
import pickle
import pandas as pd
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
HISTORICAL_CACHE_DIR = os.path.join(SCRIPT_DIR, "MB_Breakout_Cache", "historical")

def inspect_cache():
    """Inspect cached data files"""
    
    if not os.path.exists(HISTORICAL_CACHE_DIR):
        print(f"❌ Cache directory not found: {HISTORICAL_CACHE_DIR}")
        return
    
    cache_files = [f for f in os.listdir(HISTORICAL_CACHE_DIR) if f.endswith('.pkl')]
    
    print(f"\n{'='*80}")
    print(f"CACHE INSPECTION")
    print(f"{'='*80}\n")
    print(f"Cache directory: {HISTORICAL_CACHE_DIR}")
    print(f"Total cached files: {len(cache_files)}\n")
    
    if not cache_files:
        print("❌ No cached files found!")
        print("\nThis is likely because:")
        print("  1. First run - data hasn't been cached yet")
        print("  2. Cache was cleared")
        print("\nRun the scanner first to populate cache.")
        return
    
    # Sample first 10 files
    print("Sampling first 10 cached files:\n")
    print(f"{'Symbol':<15} {'Days':>6} {'From':>12} {'To':>12} {'Status'}")
    print("-" * 70)
    
    valid_count = 0
    insufficient_count = 0
    error_count = 0
    
    for i, cache_file in enumerate(cache_files[:10]):
        try:
            # Parse symbol from filename
            symbol = cache_file.split('_')[0]
            
            # Load cache file
            filepath = os.path.join(HISTORICAL_CACHE_DIR, cache_file)
            with open(filepath, 'rb') as f:
                data = pickle.load(f)
            
            if not data:
                print(f"{symbol:<15} {'EMPTY':>6} {'N/A':>12} {'N/A':>12} ❌ No data")
                error_count += 1
                continue
            
            # Convert to dataframe
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            
            days = len(df)
            from_date = df['date'].min().strftime('%Y-%m-%d')
            to_date = df['date'].max().strftime('%Y-%m-%d')
            
            if days >= 80:
                status = "✓ OK"
                valid_count += 1
            else:
                status = f"⚠️  Short ({days} < 80)"
                insufficient_count += 1
            
            print(f"{symbol:<15} {days:>6} {from_date:>12} {to_date:>12} {status}")
            
        except Exception as e:
            print(f"{symbol:<15} {'ERROR':>6} {'N/A':>12} {'N/A':>12} ❌ {str(e)[:20]}")
            error_count += 1
    
    print("\n" + "="*70)
    print(f"Summary (first 10 files):")
    print(f"  Valid (≥80 days): {valid_count}")
    print(f"  Insufficient data: {insufficient_count}")
    print(f"  Errors: {error_count}")
    print("="*70)
    
    # Overall stats
    print(f"\n📊 Overall Cache Stats:")
    print(f"  Total files: {len(cache_files)}")
    print(f"  Estimated valid: ~{len(cache_files) * valid_count // 10 if len(cache_files) >= 10 else 'Unknown'}")
    
    if insufficient_count > 5:
        print(f"\n⚠️  WARNING: Many files have insufficient data!")
        print(f"   This may be because:")
        print(f"   1. Stocks are newly listed")
        print(f"   2. Data fetch range was too short")
        print(f"   3. API returned incomplete data")
        print(f"\n   Consider:")
        print(f"   - Clearing cache: rmdir /s MB_Breakout_Cache")
        print(f"   - Re-running scanner to fetch fresh data")

if __name__ == "__main__":
    inspect_cache()

