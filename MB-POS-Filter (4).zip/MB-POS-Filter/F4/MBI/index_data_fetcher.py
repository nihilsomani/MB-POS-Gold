"""
Index Data Fetcher with Caching
================================
Fetches Nifty 500 index data and calculates trends using vectorization.

Features:
- Disk caching for index data
- Vectorized trend calculations
- Fast lookups for daily analysis
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, Optional
import logging
import os
import pickle

logger = logging.getLogger(__name__)


class IndexDataFetcher:
    """
    Fetches and caches Nifty 500 index data.
    Uses vectorization for fast trend calculations.
    """
    
    def __init__(
        self,
        kite,
        cache_dir: str = "MBI_EM_Cache",
        index_symbol: str = "NIFTY 500"
    ):
        self.kite = kite
        self.cache_dir = cache_dir
        self.index_symbol = index_symbol
        self.cache_file = os.path.join(cache_dir, "nifty500_index.pkl")
        
        # Ensure cache directory exists
        os.makedirs(cache_dir, exist_ok=True)
        
        logger.info(f"IndexDataFetcher initialized for {index_symbol}")
    
    def fetch_index_data(
        self,
        start_date: datetime,
        end_date: datetime,
        force_refresh: bool = False
    ) -> pd.DataFrame:
        """
        Fetch index data with caching.
        
        Args:
            start_date: Start date for data
            end_date: End date for data
            force_refresh: Skip cache and fetch fresh
        
        Returns:
            DataFrame with index OHLC data and calculated trends
        """
        # Check cache first (unless force_refresh)
        if not force_refresh and os.path.exists(self.cache_file):
            cached_data = self._load_from_cache()
            if cached_data is not None:
                # Check if cache covers required date range
                cache_start = cached_data.index.min()
                cache_end = cached_data.index.max()
                
                if cache_start <= start_date and cache_end >= end_date:
                    logger.info(f"Using cached index data ({len(cached_data)} days)")
                    # Filter to requested range
                    mask = (cached_data.index >= start_date) & (cached_data.index <= end_date)
                    return cached_data[mask].copy()
                else:
                    logger.info("Cache doesn't cover full range, fetching fresh data")
        
        # Fetch from API
        logger.info(f"Fetching {self.index_symbol} data from API...")
        df = self._fetch_from_api(start_date, end_date)
        
        if df is not None and len(df) > 0:
            # Calculate trends using vectorization
            df = self._calculate_trends_vectorized(df)
            
            # Save to cache
            self._save_to_cache(df)
            
            logger.info(f"Fetched and cached {len(df)} days of index data")
            return df
        else:
            logger.error("Failed to fetch index data")
            return pd.DataFrame()
    
    def _fetch_from_api(
        self,
        start_date: datetime,
        end_date: datetime
    ) -> Optional[pd.DataFrame]:
        """Fetch index data from Kite API"""
        try:
            # Try INDICES exchange first (proper index data)
            nifty500_token = None
            nifty500_symbol = None
            
            # Try INDICES exchange
            try:
                instruments = self.kite.instruments("INDICES")
                for inst in instruments:
                    if 'NIFTY 500' in inst['tradingsymbol'] or 'NIFTY500' in inst['tradingsymbol']:
                        nifty500_token = inst['instrument_token']
                        nifty500_symbol = inst['tradingsymbol']
                        logger.info(f"Found in INDICES: {nifty500_symbol} (Token: {nifty500_token})")
                        break
            except:
                logger.debug("INDICES exchange not available, trying NSE...")
            
            # If not found, try NSE exchange
            if not nifty500_token:
                instruments = self.kite.instruments("NSE")
                for inst in instruments:
                    if inst['tradingsymbol'] == 'NIFTY 500':
                        nifty500_token = inst['instrument_token']
                        nifty500_symbol = inst['tradingsymbol']
                        logger.info(f"Found in NSE: {nifty500_symbol} (Token: {nifty500_token})")
                        break
            
            if not nifty500_token:
                logger.error("Nifty 500 index not found in INDICES or NSE exchange")
                return None
            
            # Fetch historical data
            # Add buffer for trend calculations
            fetch_start = start_date - timedelta(days=30)
            
            data = self.kite.historical_data(
                instrument_token=nifty500_token,
                from_date=fetch_start,
                to_date=end_date + timedelta(days=1),
                interval="day"
            )
            
            if not data:
                logger.error("No data returned from API")
                return None
            
            # Convert to DataFrame
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
            df.set_index('date', inplace=True)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching index data from API: {e}")
            return None
    
    def _calculate_trends_vectorized(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate index trends using vectorization.
        Much faster than row-by-row calculations.
        """
        # Calculate SMAs (vectorized)
        df['sma_5'] = df['close'].rolling(window=5, min_periods=1).mean()
        df['sma_10'] = df['close'].rolling(window=10, min_periods=1).mean()
        df['sma_20'] = df['close'].rolling(window=20, min_periods=1).mean()
        
        # Calculate price changes (vectorized)
        df['pct_change_1d'] = df['close'].pct_change() * 100
        df['pct_change_5d'] = df['close'].pct_change(periods=5) * 100
        df['pct_change_10d'] = df['close'].pct_change(periods=10) * 100
        
        # Determine trend (vectorized boolean operations)
        # Rising: Close > SMA5 and SMA5 > SMA10
        df['is_rising'] = (df['close'] > df['sma_5']) & (df['sma_5'] > df['sma_10'])
        
        # Falling: Close < SMA5 and SMA5 < SMA10
        df['is_falling'] = (df['close'] < df['sma_5']) & (df['sma_5'] < df['sma_10'])
        
        # Flat: Neither rising nor falling
        df['is_flat'] = ~df['is_rising'] & ~df['is_falling']
        
        # String trend (for readability)
        df['trend'] = 'flat'
        df.loc[df['is_rising'], 'trend'] = 'rising'
        df.loc[df['is_falling'], 'trend'] = 'falling'
        
        # Calculate trend strength (vectorized)
        # Strength = Distance from SMA as % of price
        df['trend_strength'] = ((df['close'] - df['sma_10']) / df['close'] * 100).abs()
        
        return df
    
    def _load_from_cache(self) -> Optional[pd.DataFrame]:
        """Load index data from cache file"""
        try:
            with open(self.cache_file, 'rb') as f:
                df = pickle.load(f)
            logger.debug(f"Loaded {len(df)} days from cache")
            return df
        except Exception as e:
            logger.warning(f"Failed to load cache: {e}")
            return None
    
    def _save_to_cache(self, df: pd.DataFrame):
        """Save index data to cache file"""
        try:
            with open(self.cache_file, 'wb') as f:
                pickle.dump(df, f)
            logger.debug(f"Saved {len(df)} days to cache")
        except Exception as e:
            logger.warning(f"Failed to save cache: {e}")
    
    def get_trend_for_date(
        self,
        df: pd.DataFrame,
        date: datetime
    ) -> Dict[str, any]:
        """
        Get index trend data for a specific date.
        Optimized for fast lookups during daily loop.
        
        Returns dict with:
        - close: Closing price
        - trend: 'rising', 'falling', or 'flat'
        - pct_change_1d: 1-day % change
        - pct_change_5d: 5-day % change
        - trend_strength: Strength of trend
        """
        try:
            if date not in df.index:
                return {
                    'close': None,
                    'trend': 'unknown',
                    'pct_change_1d': 0,
                    'pct_change_5d': 0,
                    'trend_strength': 0,
                    'is_rising': False,
                    'is_falling': False
                }
            
            row = df.loc[date]
            
            return {
                'close': row['close'],
                'trend': row['trend'],
                'pct_change_1d': row['pct_change_1d'],
                'pct_change_5d': row['pct_change_5d'],
                'trend_strength': row['trend_strength'],
                'is_rising': row['is_rising'],
                'is_falling': row['is_falling']
            }
            
        except Exception as e:
            logger.error(f"Error getting trend for {date}: {e}")
            return {
                'close': None,
                'trend': 'unknown',
                'pct_change_1d': 0,
                'pct_change_5d': 0,
                'trend_strength': 0,
                'is_rising': False,
                'is_falling': False
            }


# =============================================================================
# Utility Functions
# =============================================================================

def classify_market_type(em_score: float, em_trend: str, index_trend: str) -> str:
    """
    Classify market type based on EM and Index.
    
    Returns:
        - "Broad Rally" (High EM + Rising Index) = BEST
        - "Narrow Rally" (Low EM + Rising Index) = FRAGILE
        - "Divergence Rally" (High EM + Falling Index) = CAUTION
        - "Broad Decline" (Low EM + Falling Index) = AVOID
        - "Recovery" (Mid EM + Rising Index) = EMERGING
    """
    # Classify EM level
    em_high = em_score >= 40
    em_mid = 18 <= em_score < 40
    em_low = em_score < 18
    
    # Market type matrix
    if em_high and index_trend == 'rising':
        return "Broad Rally"  # BEST - All sizes participating
    elif em_mid and index_trend == 'rising':
        return "Recovery"  # GOOD - Breadth improving
    elif em_low and index_trend == 'rising':
        return "Narrow Rally"  # FRAGILE - Only large caps
    elif em_high and index_trend == 'falling':
        return "Divergence"  # CAUTION - Breadth without leadership
    elif em_low and index_trend == 'falling':
        return "Broad Decline"  # AVOID - Everything weak
    else:  # Flat index
        return "Consolidation"


# =============================================================================
# Testing
# =============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    
    print("\n" + "="*80)
    print("INDEX DATA FETCHER TEST")
    print("="*80 + "\n")
    
    # Test vectorized calculations
    test_data = pd.DataFrame({
        'close': [100, 102, 104, 103, 105, 107, 106, 108, 110, 109]
    })
    
    print("Test Data (10 days):")
    print(test_data['close'].values)
    
    # Mock object to test calculations
    fetcher = IndexDataFetcher(kite=None)
    result = fetcher._calculate_trends_vectorized(test_data)
    
    print("\nCalculated Trends:")
    print(result[['close', 'sma_5', 'trend', 'pct_change_1d']].tail())
    
    print("\nMarket Type Classification Test:")
    test_cases = [
        (65, 'rising', 'rising', "Should be: Broad Rally"),
        (30, 'rising', 'rising', "Should be: Recovery"),
        (15, 'rising', 'rising', "Should be: Narrow Rally"),
        (65, 'rising', 'falling', "Should be: Divergence"),
        (15, 'declining', 'falling', "Should be: Broad Decline"),
    ]
    
    for em, em_trend, idx_trend, expected in test_cases:
        result = classify_market_type(em, em_trend, idx_trend)
        print(f"EM={em}%, EM trend={em_trend}, Index={idx_trend}")
        print(f"  Result: {result} ({expected})")
        print()

