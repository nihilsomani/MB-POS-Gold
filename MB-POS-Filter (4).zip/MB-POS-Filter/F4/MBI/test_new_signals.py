"""
Test New V3.4 Signals on Historical Crash Cases
"""

from timeframe_analyzer import analyze_timeframes

print("\n" + "="*80)
print("TESTING V3.4 SIGNALS ON HISTORICAL CRASHES")
print("="*80 + "\n")

test_cases = [
    {
        "name": "Jun 26, 2024 (Day before crash)",
        "em_score": 64.9,
        "em_trend": "declining",
        "em_chng_5d": 30.13,
        "market_type": "Broad Rally",
        "index_trend": "rising",
        "index_chng_5d": 3.31,
        "divergence_warning": False,
        "regime": "Extreme Bullish",
        "expected": "Should NOT be BUY - EM declining from peak"
    },
    {
        "name": "Dec 6, 2024 (Peak, day before decline)",
        "em_score": 69.5,
        "em_trend": "rising",
        "em_chng_5d": 25.0,
        "market_type": "Broad Rally",
        "index_trend": "rising",
        "index_chng_5d": 2.76,
        "divergence_warning": False,
        "regime": "Extreme Bullish",
        "expected": "Can be BUY/HOLD - EM still rising"
    },
    {
        "name": "Dec 9, 2024 (EM 62%, declining from 69.5%)",
        "em_score": 62.0,
        "em_trend": "declining",
        "em_chng_5d": -5.79,
        "market_type": "Broad Rally",
        "index_trend": "rising",
        "index_chng_5d": 2.0,
        "divergence_warning": False,
        "regime": "Extreme Bullish",
        "expected": "Should be HOLD or cautious - not extreme"
    },
    {
        "name": "Oct 20, 2024 (Perfect setup - actually worked!)",
        "em_score": 61.8,
        "em_trend": "rising",
        "em_chng_5d": 21.76,
        "market_type": "Broad Rally",
        "index_trend": "rising",
        "index_chng_5d": 1.81,
        "divergence_warning": False,
        "regime": "Extreme Bullish",
        "expected": "Should be BUY (HIGH) - this was a good signal"
    }
]

for i, case in enumerate(test_cases, 1):
    print(f"{i}. {case['name']}")
    print(f"   Expected: {case['expected']}")
    print()
    
    result = analyze_timeframes(
        em_score=case['em_score'],
        em_trend=case['em_trend'],
        em_chng_5d=case['em_chng_5d'],
        market_type=case['market_type'],
        index_trend=case['index_trend'],
        index_chng_5d=case['index_chng_5d'],
        divergence_warning=case['divergence_warning'],
        regime=case['regime']
    )
    
    print(f"   V3.4 Signals:")
    print(f"     2-5d:   {result['short']}")
    print(f"     5-10d:  {result['medium']}")
    print(f"     10-21d: {result['long']}")  
    print(f"     21+d:   {result['very_long']}")
    print()
    print(f"   10-21d Reason: {result['long'].reason}")
    print()
    print("-" * 80)
    print()

print("="*80)
print("ANALYSIS")
print("="*80)
print()
print("Check if V3.4 signals match expectations above.")
print("Key test: Jun 26 should NOT be BUY (HIGH) anymore!")
print()

