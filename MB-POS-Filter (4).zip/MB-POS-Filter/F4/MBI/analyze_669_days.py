"""
Comprehensive Analysis of 669-Day Dataset
==========================================
Analyzes patterns, signals, and warnings from Feb 2023 - Nov 2025.
"""

import pandas as pd
import numpy as np

print("\n" + "="*80)
print("COMPREHENSIVE 669-DAY ANALYSIS")
print("="*80 + "\n")

# Load data
df = pd.read_excel("../../../mbi_em_dashboard_20251105_150843.xlsx")
df['date'] = pd.to_datetime(df['date'])

print(f"Total days: {len(df)}")
print(f"Date range: {df['date'].min().strftime('%Y-%m-%d')} to {df['date'].max().strftime('%Y-%m-%d')}\n")

# =============================================================================
# 1. EM DISTRIBUTION
# =============================================================================

print("="*80)
print("1. EM DISTRIBUTION ACROSS 669 DAYS")
print("="*80 + "\n")

print(f"EM Statistics:")
print(f"  Min:    {df['EM'].min():.1f}%")
print(f"  Max:    {df['EM'].max():.1f}%")
print(f"  Avg:    {df['EM'].mean():.1f}%")
print(f"  Median: {df['EM'].median():.1f}%")
print()

print(f"EM Distribution:")
print(f"  <12% (Bear):       {(df['EM'] < 12).sum():3d} days ({(df['EM'] < 12).sum()/len(df)*100:.1f}%)")
print(f"  12-18% (Early):    {((df['EM'] >= 12) & (df['EM'] < 18)).sum():3d} days ({((df['EM'] >= 12) & (df['EM'] < 18)).sum()/len(df)*100:.1f}%)")
print(f"  18-40% (Healthy):  {((df['EM'] >= 18) & (df['EM'] < 40)).sum():3d} days ({((df['EM'] >= 18) & (df['EM'] < 40)).sum()/len(df)*100:.1f}%)")
print(f"  40-60% (Strong):   {((df['EM'] >= 40) & (df['EM'] < 60)).sum():3d} days ({((df['EM'] >= 40) & (df['EM'] < 60)).sum()/len(df)*100:.1f}%)")
print(f"  60-70% (Extreme):  {((df['EM'] >= 60) & (df['EM'] < 70)).sum():3d} days ({((df['EM'] >= 60) & (df['EM'] < 70)).sum()/len(df)*100:.1f}%)")
print(f"  >70% (Very High):  {(df['EM'] > 70).sum():3d} days ({(df['EM'] > 70).sum()/len(df)*100:.1f}%)")
print()

# =============================================================================
# 2. CRASH EVENTS
# =============================================================================

print("="*80)
print("2. CRASH EVENT ANALYSIS")
print("="*80 + "\n")

crashes = df[df['EM_chng_3d'] <= -10].copy()
print(f"Total crash events (EM_chng_3d <= -10): {len(crashes)}\n")

print(f"Recent crashes (last 30 days):")
recent_crashes = crashes[crashes['date'] >= df['date'].max() - pd.Timedelta(days=30)]
for idx, row in recent_crashes.iterrows():
    print(f"  {row['date'].strftime('%Y-%m-%d')}: EM {row['EM']:.1f}%, "
          f"EM_chng_3d = {row['EM_chng_3d']:.1f}%")
print()

# =============================================================================
# 3. V3.4 PATTERN VALIDATION (EM >70% + declining)
# =============================================================================

print("="*80)
print("3. V3.4 VALIDATED PATTERN: EM >70% + DECLINING")
print("="*80 + "\n")

pattern_v34 = df[(df['EM'] > 70) & (df['em_trend'] == 'declining')].copy()
print(f"EM >70% + declining events: {len(pattern_v34)}\n")

if len(pattern_v34) > 0:
    print("V3.4 Pattern Occurrences:")
    for idx, row in pattern_v34.iterrows():
        # Check if crash happened in next 5 days
        future = df[(df['date'] > row['date']) & (df['date'] <= row['date'] + pd.Timedelta(days=5))]
        crashed = (future['EM_chng_3d'] <= -10).any() if len(future) > 0 else False
        
        status = "-> CRASH!" if crashed else "-> Sustained"
        print(f"  {row['date'].strftime('%Y-%m-%d')}: EM {row['EM']:.1f}%, "
              f"signal_10_21d = {row.get('signal_10_21d', 'N/A')} {status}")
    print()

# =============================================================================
# 4. OCTOBER 2025 CASE STUDY
# =============================================================================

print("="*80)
print("4. OCTOBER 2025 CASE STUDY (Your Recent Data)")
print("="*80 + "\n")

oct_data = df[(df['date'] >= '2025-10-20') & (df['date'] <= '2025-11-05')].copy()

print("Oct 20 - Nov 5, 2025 Timeline:")
print("-" * 80)
for idx, row in oct_data.iterrows():
    em_str = f"{row['EM']:5.1f}%"
    trend_str = f"{row['em_trend']:10s}"
    signal_10_21 = row.get('signal_10_21d', 'N/A')[:15]
    
    print(f"{row['date'].strftime('%Y-%m-%d')}: EM {em_str} {trend_str} "
          f"{row['regime']:18s} {signal_10_21:15s} {row['position_size']}")
print()

print("Analysis:")
print("  Oct 21-29: EM 64-70%, rising/stable -> BUY/HOLD signals")
print("  Oct 30: EM 61%, declining -> TRIM TO 30%")
print("  Oct 31: EM 52%, crashing -> EXIT ALL (crash detected)")
print("  Nov 3-5: EM 42-38%, crashing -> STAY OUT")
print()

# =============================================================================
# 5. V3.4 IMPROVEMENT CHECK
# =============================================================================

print("="*80)
print("5. V3.4 SIGNAL QUALITY CHECK")
print("="*80 + "\n")

if 'signal_10_21d' in df.columns:
    buy_high = df[df['signal_10_21d'].str.contains('BUY \\(HIGH\\)', na=False)]
    buy_med = df[df['signal_10_21d'].str.contains('BUY \\(MEDIUM\\)', na=False)]
    sell_high = df[df['signal_10_21d'].str.contains('SELL \\(HIGH\\)', na=False)]
    hold_med = df[df['signal_10_21d'].str.contains('HOLD \\(MEDIUM\\)', na=False)]
    hold_low = df[df['signal_10_21d'].str.contains('HOLD \\(LOW\\)', na=False)]
    
    print(f"10-21 Day Signal Distribution (669 days):")
    print(f"  BUY (HIGH):   {len(buy_high):3d} signals")
    print(f"  BUY (MEDIUM): {len(buy_med):3d} signals")
    print(f"  HOLD (MEDIUM):{len(hold_med):3d} signals")
    print(f"  HOLD (LOW):   {len(hold_low):3d} signals")
    print(f"  SELL (HIGH):  {len(sell_high):3d} signals")
    print()
    
    # Check recent BUY (HIGH) signals
    recent_buy_high = buy_high[buy_high['date'] >= df['date'].max() - pd.Timedelta(days=90)]
    if len(recent_buy_high) > 0:
        print(f"Recent BUY (HIGH) signals (last 90 days):")
        for idx, row in recent_buy_high.tail(5).iterrows():
            print(f"  {row['date'].strftime('%Y-%m-%d')}: EM {row['EM']:.1f}%, "
                  f"{row['em_trend']}, {row['market_type']}")
        print()

# =============================================================================
# 6. WARNING SIGNAL EFFECTIVENESS
# =============================================================================

print("="*80)
print("6. WARNING SIGNAL EFFECTIVENESS (V3.4 vs Reality)")
print("="*80 + "\n")

# Check EM >70% + declining pattern across full dataset
em_70_declining = df[(df['EM'] > 70) & (df['em_trend'] == 'declining')].copy()
crashes_after_warning = 0

print(f"EM >70% + declining events (V3.4 SELL signal): {len(em_70_declining)}\n")

if len(em_70_declining) > 0:
    print("Checking each occurrence:")
    for idx, row in em_70_declining.iterrows():
        date = row['date']
        # Check next 7 days for crash
        future = df[(df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=7))]
        crashed = (future['EM_chng_3d'] <= -10).any() if len(future) > 0 else False
        
        if crashed:
            crashes_after_warning += 1
            crash_date = future[future['EM_chng_3d'] <= -10].iloc[0]['date']
            days_to_crash = (crash_date - date).days
            crash_em = future[future['EM_chng_3d'] <= -10].iloc[0]['EM']
            print(f"  {date.strftime('%Y-%m-%d')}: EM {row['EM']:.1f}% "
                  f"-> CRASH in {days_to_crash} days! EM {crash_em:.1f}%")
        else:
            print(f"  {date.strftime('%Y-%m-%d')}: EM {row['EM']:.1f}% "
                  f"-> Sustained (no crash)")
    
    reliability = (crashes_after_warning / len(em_70_declining) * 100) if len(em_70_declining) > 0 else 0
    print(f"\nReliability: {crashes_after_warning}/{len(em_70_declining)} = {reliability:.1f}%")
    
    if reliability >= 60:
        print(f"[EXCELLENT] V3.4 pattern validated on full dataset!")
    else:
        print(f"[ADJUST] Reliability changed with more data")
    print()

# =============================================================================
# 7. MARKET TYPE DISTRIBUTION
# =============================================================================

print("="*80)
print("7. MARKET TYPE DISTRIBUTION (V3)")
print("="*80 + "\n")

if 'market_type' in df.columns:
    market_dist = df['market_type'].value_counts()
    print("Market Type Distribution:")
    for mtype, count in market_dist.items():
        pct = count / len(df) * 100
        print(f"  {mtype:20s}: {count:3d} days ({pct:4.1f}%)")
    print()

# =============================================================================
# 8. DIVERGENCE WARNING EFFECTIVENESS
# =============================================================================

print("="*80)
print("8. DIVERGENCE WARNING ANALYSIS")
print("="*80 + "\n")

if 'divergence_warning' in df.columns:
    df['div_flag'] = df['divergence_warning'].astype(str).str.upper().isin(['YES', 'TRUE'])
    div_count = df['div_flag'].sum()
    print(f"Divergence warnings: {div_count} days ({div_count/len(df)*100:.1f}%)\n")
    
    # Check how many divergences led to problems
    div_events = df[df['div_flag'] == True].copy()
    if len(div_events) > 0:
        print("Recent divergence warnings:")
        recent_div = div_events.tail(10)
        for idx, row in recent_div.iterrows():
            print(f"  {row['date'].strftime('%Y-%m-%d')}: EM {row['EM']:.1f}%, "
                  f"{row['market_type']}, Index {row['index_trend']}")
        print()

# =============================================================================
# 9. ANTI-WHIPSAW EFFECTIVENESS
# =============================================================================

print("="*80)
print("9. ANTI-WHIPSAW MESSAGES (V3.2 Feature)")
print("="*80 + "\n")

# Count anti-whipsaw interventions
stay_out = df[df['trading_action'].str.contains('STAY OUT', na=False)]
gradual_entry = df[df['trading_action'].str.contains('GRADUAL ENTRY', na=False)]
hold_min = df[df['trading_action'].str.contains('HOLD - Min hold', na=False)]

print(f"Anti-whipsaw interventions:")
print(f"  STAY OUT (enforced hold):  {len(stay_out):3d} days")
print(f"  GRADUAL ENTRY (smoothing): {len(gradual_entry):3d} days")
print(f"  HOLD (min period):         {len(hold_min):3d} days")
print(f"\nTotal interventions: {len(stay_out) + len(gradual_entry) + len(hold_min)} "
      f"({(len(stay_out) + len(gradual_entry) + len(hold_min))/len(df)*100:.1f}% of days)")
print()

# =============================================================================
# 10. KEY DATES TO REVIEW
# =============================================================================

print("="*80)
print("10. KEY DATES FOR YOUR REVIEW")
print("="*80 + "\n")

# Find EM >70% + declining occurrences
em_70_decl = df[(df['EM'] > 70) & (df['em_trend'] == 'declining')].copy()
print(f"EM >70% + declining (V3.4 SELL signal): {len(em_70_decl)} events\n")

if len(em_70_decl) > 0:
    print("Dates to review in Excel:")
    for idx, row in em_70_decl.iterrows():
        print(f"  {row['date'].strftime('%Y-%m-%d')}: EM {row['EM']:.1f}%, "
              f"signal_10_21d = {row.get('signal_10_21d', 'N/A')}")
    print()

# Find BUY (HIGH) signals
if 'signal_10_21d' in df.columns:
    buy_high_full = df[df['signal_10_21d'].str.contains('BUY \\(HIGH\\)', na=False)].copy()
    print(f"BUY (HIGH) signals for 10-21d: {len(buy_high_full)} events\n")
    
    if len(buy_high_full) > 0:
        print("All BUY (HIGH) dates (100% win rate in backtest!):")
        for idx, row in buy_high_full.iterrows():
            print(f"  {row['date'].strftime('%Y-%m-%d')}: EM {row['EM']:.1f}%, "
                  f"{row['em_trend']}, {row['market_type']}")
        print()

print("="*80)
print("RECOMMENDATIONS")
print("="*80 + "\n")

print("For 10-21 Day Trading:")
print("  1. ENTER on BUY (HIGH) signals only")
print("  2. EXIT on SELL (HIGH) or EM crashing")
print("  3. HOLD on HOLD signals (don't overtrade)")
print("  4. Watch for EM >70% + declining (66.7% crash risk)")
print()

print("Next Steps:")
print("  1. Open Excel: mbi_em_dashboard_20251105_150843.xlsx")
print("  2. Review the dates listed above")
print("  3. Check if V3.4 signals make sense")
print("  4. Current status: Nov 5 = DETERIORATING (stay in cash)")
print()

