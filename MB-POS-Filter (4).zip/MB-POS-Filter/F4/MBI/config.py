"""
MBI EM System Configuration
============================
Central configuration file for all MBI EM modules.

UPDATE YOUR CREDENTIALS HERE (one place only!)
"""

import os  # For path handling

# =============================================================================
# KITECONNECT API CREDENTIALS
# =============================================================================

# IMPORTANT: Update these with your valid credentials
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "ag9KpKehMcYZILhTs8STLPKcf9dAQxyT"  # Generate fresh token daily!

# =============================================================================
# DATA CONFIGURATION
# =============================================================================

# Paths - Use absolute paths to work from any location
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(_SCRIPT_DIR)))

# Stock Universe
UNIVERSE_CSV = os.path.join(_WORKSPACE_ROOT, "data", "nifty500.csv")

# Cache Directory  
CACHE_DIR = os.path.join(_SCRIPT_DIR, "MBI_EM_Cache")

# Date Ranges for Daily Analysis
ANALYSIS_DAYS = 400      # Days to analyze in daily run (if using relative dates)
LOOKBACK_DAYS = 370     # Historical data needed for indicators

# Optional: Specific date range override (leave None to use ANALYSIS_DAYS)
ANALYSIS_START_DATE = None  # e.g., "2025-10-21" or None for auto
ANALYSIS_END_DATE = None    # e.g., "2025-11-03" or None for today

# API Configuration
API_DELAY = 0.3         # Seconds between API calls

# =============================================================================
# EM SYSTEM PARAMETERS
# =============================================================================

# Pocket Pivot Detection
PPD_THRESHOLD = 4.5           # Minimum % gain
VOLUME_MULTIPLIER = 1.5       # vs 50-day average
VOLUME_PERCENTILE = 75        # Top 25th percentile

# Follow-Through Tracking
FT_LOOKBACK = 5               # Days to check follow-through
FT_SUCCESS_DAYS = 3           # Days above PPD high required
FT_GAIN_TARGET = 3.0          # % gain target
FT_TREND_DAYS = 5             # Days above 20 EMA

# EM Calculation
EM_LOOKBACK = 10              # Days lookback window
EM_MIN_SAMPLE = 5             # Minimum PPDs required

# Regime Thresholds (REVISED Nov 4, 2025 - Trend-Based!)
# KEY INSIGHT: Trend matters MORE than absolute level!
REGIME_BEAR = 12              # Bear Control (< 12% EM)
REGIME_REPAIR = 15            # Repair Zone (12-15% EM)
REGIME_EARLY = 18             # Early Momentum (15-18% EM)
REGIME_HEALTHY = 40           # Healthy Bullish (18-40% EM)
REGIME_STRONG = 60            # Strong Bullish (40-60% EM) - BEST zone if stable/rising!
REGIME_EXTREME = 75           # Extreme Bullish (> 60% EM) - Still good if stable!

# EM Trend Detection (CRITICAL!)
EM_CRASH_THRESHOLD_3D = -12   # EM drop > 12pts in 3 days = Crash signal (index-confirmed!)
EM_CRASH_THRESHOLD_5D = -15   # EM drop > 15pts in 5 days = EXIT ALL  
EM_DECLINING_THRESHOLD = -3   # EM change < -3pts = weakening
EM_RISING_THRESHOLD = +3      # EM change > +3pts = strengthening

# Index neutral crash handling (tunable)
NEUTRAL_CRASH_THRESHOLD = -1.0  # If index 5d change <= this while trend flat, treat as crash confirmation

# =============================================================================
# EUPHORIA DETECTION SETTINGS
# =============================================================================

EUPHORIA_EM_THRESHOLD = 75            # EM dangerously high
EUPHORIA_EM_PLATEAU_DAYS = 3          # Days EM stays > threshold without rising
EUPHORIA_EM_SPIKE = 20                # 1-day EM spike signalling blow-off

EUPHORIA_BREADTH_DIVERGENCE_DAYS = 3  # Consecutive 4.5R declines vs rising index
EUPHORIA_RATIO_PEAK = 400             # 4.5R considered euphoric

EUPHORIA_52WH_THRESHOLD = 30          # Extreme number of 52-week highs
EUPHORIA_52WH_DECLINE_THRESHOLD = 0.5 # Collapse vs recent high

EUPHORIA_SMA_OVEREXTENSION = 85       # % above SMAs indicating overbought

# REVISED Trading Logic (V3.5 - Index-Confirmed Crash Detection, Nov 2025):
# KEY INSIGHT: EM crash + Index strong = Narrow rally (reduce to 50%, don't exit)
#              EM crash + Index weak = Real crash (exit all)
# ✅ EM >60% + RISING + INDEX RISING = 120% AGGRESSIVE (Nov 14-29: +3-6% returns!)
# ⚠️ EM >60% + RISING + INDEX FALLING = 50% CAUTIOUS (Oct 1-8: Divergence, -3% loss avoided!)
# 🚨 EM crash + Index falling = EXIT ALL (Real crash - both breadth and index weak)
# 🟡 EM crash + Index rising = REDUCE to 50% (Narrow rally - large caps leading, small caps weak)
# ❌ V1: "EM > 35% = euphoria = trim" (WRONG - missed rallies!)
# ✅ V2: "EM declining fast = exit" (GOOD - catches crashes but too sensitive!)
# ✅ V3: "EM + Index confirmation = best signal" (BEST - reduces false positives!)
# ✅ V3.5: "Index-confirmed crash detection" (INTELLIGENT - Sep 12 false alarm fixed!)

# =============================================================================
# BACKTEST CONFIGURATION
# =============================================================================

# Default Backtest Periods
DEFAULT_BACKTEST_START = "2023-01-01"
DEFAULT_BACKTEST_END = "2025-10-31"

# Forward Return Periods
FORWARD_PERIODS = [5, 10, 20]  # Days

# Output
OUTPUT_DIR = "MBI_EM_Backtest_Results"

# =============================================================================
# NOTES
# =============================================================================

# Access Token:
#   - Generate fresh token daily from Kite login
#   - Tokens expire at 6 AM IST daily
#   - Update ACCESS_TOKEN above when expired

# Universe CSV:
#   - Must have a 'Symbol' column
#   - Recommended: Nifty 500 or higher for good sample size
#   - Minimum: 50 stocks for meaningful EM calculation

# Performance:
#   - First run: 30-90 minutes (fetches data)
#   - Subsequent runs: 5-30 minutes (uses cache)
#   - Cache persists until manually deleted

# =============================================================================
# ANTI-WHIPSAW SETTINGS (V3.1 Enhancement)
# =============================================================================

# Regime Change Hysteresis (prevents flip-flopping)
REGIME_CHANGE_BUFFER = 3.0  # EM must cross threshold by this amount to change regime
# Example: If in "Healthy" (EM >= 18), need to drop to <15 to exit (not just <18)

# Position Change Smoothing (prevents 0% -> 144% jumps)
MAX_POSITION_CHANGE_PER_DAY = 0.50  # Maximum 50% position change per day
# Example: Can't go 100% -> 0% in one day (will go 100% -> 50% -> 0% over 2 days)
ENABLE_POSITION_SMOOTHING = True  # Set to False to disable

# Minimum Hold Period (prevents rapid entry/exit)
MIN_HOLD_DAYS_BULLISH = 2  # Minimum days to hold a bullish position
MIN_HOLD_DAYS_BEARISH = 3  # Minimum days to stay out after crash exit

# Exit Confirmation (requires sustained weakness)
REQUIRE_EXIT_CONFIRMATION = True  # Need 2 consecutive days of weakness to exit
CRASH_EXIT_THRESHOLD = -12  # Immediate exit if EM drops >12% in 3 days (override all)

