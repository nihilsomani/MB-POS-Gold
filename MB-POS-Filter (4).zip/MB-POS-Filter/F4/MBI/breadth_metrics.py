"""
Breadth Metrics Calculator
===========================
Calculates traditional market breadth indicators to complement EM.

Metrics:
- 4.5R: Ratio of extreme up movers to down movers
- SMA Breadth: % of stocks above 20/50-day moving averages
- 52-Week Extremes: Count of new highs vs lows
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from datetime import datetime
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


@dataclass
class BreadthMetrics:
    """Container for daily breadth metrics"""
    date: datetime
    
    # 4.5% movers
    up_4_5_count: int
    down_4_5_count: int
    ratio_4_5: float  # (up / down) * 100
    
    # SMA breadth (as percentages)
    sma_20_breadth: float
    sma_50_breadth: float
    
    # 52-week extremes
    high_52w_count: int
    low_52w_count: int
    
    # Total stocks processed
    total_stocks: int
    
    def __str__(self):
        return (f"{self.date.strftime('%Y-%m-%d')}: "
                f"4.5R={self.ratio_4_5:.0f} | "
                f"20SMA={self.sma_20_breadth:.0f}% | "
                f"50SMA={self.sma_50_breadth:.0f}% | "
                f"52WH/L={self.high_52w_count}/{self.low_52w_count}")


class BreadthMetricsCalculator:
    """
    Calculates market breadth metrics for a given date.
    
    Configuration:
    - extreme_threshold: % change threshold for 4.5% movers (default: 4.5)
    - sma_periods: Periods for SMA calculations (default: [20, 50])
    """
    
    def __init__(
        self,
        extreme_threshold: float = 4.5,
        sma_periods: List[int] = None
    ):
        self.extreme_threshold = extreme_threshold
        self.sma_periods = sma_periods or [20, 50]
        
        logger.info(f"BreadthMetricsCalculator initialized: threshold={extreme_threshold}%")
    
    def calculate_sma(self, series: pd.Series, period: int) -> pd.Series:
        """Calculate simple moving average"""
        return series.rolling(window=period, min_periods=period).mean()
    
    def calculate_metrics_for_date(
        self,
        stock_data: Dict[str, pd.DataFrame],
        target_date: datetime
    ) -> BreadthMetrics:
        """
        Calculate all breadth metrics for a specific date.
        
        Args:
            stock_data: Dict mapping symbol -> DataFrame with OHLCV data
            target_date: Date to calculate metrics for
        
        Returns:
            BreadthMetrics object with all calculated values
        """
        target_date = pd.to_datetime(target_date).tz_localize(None)
        
        # Initialize counters
        up_4_5_count = 0
        down_4_5_count = 0
        above_20_sma_count = 0
        above_50_sma_count = 0
        high_52w_count = 0
        low_52w_count = 0
        total_stocks = 0
        
        # Process each stock
        for symbol, df in stock_data.items():
            if df.empty:
                continue
            
            # Get data up to target date
            df_upto = df[df.index <= target_date]
            if df_upto.empty:
                continue
            
            # Get data for the specific target date
            df_today = df_upto[df_upto.index == target_date]
            if df_today.empty:
                continue  # Stock didn't trade on this date
            
            total_stocks += 1
            row = df_today.iloc[0]
            
            # --- 4.5% Movers ---
            if pd.notna(row['open']) and pd.notna(row['close']) and row['open'] != 0:
                pct_change = ((row['close'] - row['open']) / row['open']) * 100
                if pct_change >= self.extreme_threshold:
                    up_4_5_count += 1
                elif pct_change <= -self.extreme_threshold:
                    down_4_5_count += 1
            
            # --- SMA Breadth ---
            # Calculate SMAs using data up to target date
            if 20 in self.sma_periods and len(df_upto) >= 20:
                sma_20 = self.calculate_sma(df_upto['close'], 20).iloc[-1]
                if pd.notna(sma_20) and pd.notna(row['close']) and row['close'] > sma_20:
                    above_20_sma_count += 1
            
            if 50 in self.sma_periods and len(df_upto) >= 50:
                sma_50 = self.calculate_sma(df_upto['close'], 50).iloc[-1]
                if pd.notna(sma_50) and pd.notna(row['close']) and row['close'] > sma_50:
                    above_50_sma_count += 1
            
            # --- 52-Week High/Low ---
            # Look back 365 days from target date
            lookback_52w = df_upto.tail(365)
            if len(lookback_52w) > 0:
                high_52w = lookback_52w['high'].max()
                low_52w = lookback_52w['low'].min()
                
                if pd.notna(high_52w) and pd.notna(row['high']) and row['high'] >= high_52w:
                    high_52w_count += 1
                if pd.notna(low_52w) and pd.notna(row['low']) and row['low'] <= low_52w:
                    low_52w_count += 1
        
        # Calculate derived metrics
        if down_4_5_count > 0:
            ratio_4_5 = (up_4_5_count / down_4_5_count) * 100
        else:
            ratio_4_5 = 9999 if up_4_5_count > 0 else 100  # Extreme value when no down movers
        
        sma_20_breadth = (above_20_sma_count / total_stocks) * 100 if total_stocks > 0 else 0
        sma_50_breadth = (above_50_sma_count / total_stocks) * 100 if total_stocks > 0 else 0
        
        metrics = BreadthMetrics(
            date=target_date,
            up_4_5_count=up_4_5_count,
            down_4_5_count=down_4_5_count,
            ratio_4_5=ratio_4_5,
            sma_20_breadth=sma_20_breadth,
            sma_50_breadth=sma_50_breadth,
            high_52w_count=high_52w_count,
            low_52w_count=low_52w_count,
            total_stocks=total_stocks
        )
        
        logger.info(f"Breadth metrics for {target_date.strftime('%Y-%m-%d')}: {metrics}")
        
        return metrics
    
    def calculate_metrics_series(
        self,
        stock_data: Dict[str, pd.DataFrame],
        date_range: List[datetime]
    ) -> pd.DataFrame:
        """
        Calculate breadth metrics for a range of dates.
        
        Args:
            stock_data: Dict mapping symbol -> DataFrame with OHLCV data
            date_range: List of dates to calculate metrics for
        
        Returns:
            DataFrame with breadth metrics for each date
        """
        results = []
        
        for date in date_range:
            metrics = self.calculate_metrics_for_date(stock_data, date)
            
            results.append({
                'date': metrics.date,
                '4.5r': metrics.ratio_4_5,
                'up_4.5_count': metrics.up_4_5_count,
                'down_4.5_count': metrics.down_4_5_count,
                '20sma': metrics.sma_20_breadth,
                '50sma': metrics.sma_50_breadth,
                '52WH': metrics.high_52w_count,
                '52WL': metrics.low_52w_count,
                'total_stocks': metrics.total_stocks
            })
        
        df = pd.DataFrame(results)
        
        # Calculate day-to-day changes
        df['4.5r_chng'] = df['4.5r'].diff()
        df['20sma_chng'] = df['20sma'].diff()
        df['50sma_chng'] = df['50sma'].diff()
        
        return df
    
    def get_market_character(self, metrics: BreadthMetrics) -> str:
        """
        Determine market character from breadth metrics.
        
        Returns:
            String describing market character (bullish, bearish, neutral)
        """
        # Score based on multiple factors
        score = 0
        
        # 4.5R ratio
        if metrics.ratio_4_5 > 400:
            score += 2  # Very bullish
        elif metrics.ratio_4_5 > 200:
            score += 1  # Bullish
        elif metrics.ratio_4_5 < 50:
            score -= 2  # Very bearish
        elif metrics.ratio_4_5 < 100:
            score -= 1  # Bearish
        
        # SMA breadth
        if metrics.sma_20_breadth > 70:
            score += 1
        elif metrics.sma_20_breadth < 30:
            score -= 1
        
        if metrics.sma_50_breadth > 70:
            score += 1
        elif metrics.sma_50_breadth < 30:
            score -= 1
        
        # 52-week extremes
        if metrics.high_52w_count > metrics.low_52w_count * 2:
            score += 1
        elif metrics.low_52w_count > metrics.high_52w_count * 2:
            score -= 1
        
        # Classify
        if score >= 3:
            return "Strong Bullish"
        elif score >= 1:
            return "Bullish"
        elif score <= -3:
            return "Strong Bearish"
        elif score <= -1:
            return "Bearish"
        else:
            return "Neutral"


# ==============================================================================
# Testing / Example Usage
# ==============================================================================

if __name__ == "__main__":
    # Configure logging for testing
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Create sample stock data
    dates = pd.date_range('2024-01-01', periods=100, freq='D')
    
    sample_stocks = {}
    for i in range(10):
        symbol = f"STOCK{i}"
        df = pd.DataFrame({
            'open': 100 + np.random.randn(100).cumsum(),
            'high': 105 + np.random.randn(100).cumsum(),
            'low': 95 + np.random.randn(100).cumsum(),
            'close': 100 + np.random.randn(100).cumsum(),
            'volume': np.random.randint(1000000, 5000000, 100)
        }, index=dates)
        
        # Some stocks with strong up days
        if i < 3:
            df.loc[dates[50], 'close'] = df.loc[dates[50], 'open'] * 1.05  # +5%
        # Some with down days
        elif i < 5:
            df.loc[dates[50], 'close'] = df.loc[dates[50], 'open'] * 0.95  # -5%
        
        sample_stocks[symbol] = df
    
    print(f"\n{'='*80}")
    print(f"BREADTH METRICS CALCULATOR TEST")
    print(f"{'='*80}\n")
    
    # Test calculator
    calculator = BreadthMetricsCalculator()
    
    # Calculate for a specific date
    test_date = dates[50]
    metrics = calculator.calculate_metrics_for_date(sample_stocks, test_date)
    
    print(f"Metrics for {test_date.strftime('%Y-%m-%d')}:")
    print(f"  4.5% Up/Down: {metrics.up_4_5_count}/{metrics.down_4_5_count}")
    print(f"  4.5R Ratio: {metrics.ratio_4_5:.0f}")
    print(f"  20 SMA Breadth: {metrics.sma_20_breadth:.1f}%")
    print(f"  50 SMA Breadth: {metrics.sma_50_breadth:.1f}%")
    print(f"  52W High/Low: {metrics.high_52w_count}/{metrics.low_52w_count}")
    print(f"  Total Stocks: {metrics.total_stocks}")
    
    character = calculator.get_market_character(metrics)
    print(f"\n  Market Character: {character}")
    
    # Calculate series
    date_range = dates[45:55].tolist()
    metrics_series = calculator.calculate_metrics_series(sample_stocks, date_range)
    
    print(f"\nMetrics Series:")
    print(metrics_series[['date', '4.5r', '20sma', '50sma']].to_string(index=False))

