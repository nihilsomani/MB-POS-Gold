"""
Quick V3 Backtest Analyzer - Works with Sample Data
====================================================
Paste your CSV data and get instant analysis!

Usage:
    1. Save your Excel data as CSV: backtest_sample.csv
    2. python quick_analyze.py
"""

import pandas as pd
import numpy as np

# =============================================================================
# LOAD DATA
# =============================================================================

print("\n" + "="*80)
print("QUICK V3 BACKTEST ANALYZER")
print("="*80 + "\n")

# Try to load from CSV first
try:
    df = pd.read_csv("backtest_sample.csv")
    print(f"[OK] Loaded backtest_sample.csv ({len(df)} rows)\n")
except:
    # Try Excel file
    try:
        df = pd.read_excel("MBI_EM_Backtest_Results/backtest_results.xlsx")
        print(f"[OK] Loaded backtest_results.xlsx ({len(df)} rows)\n")
    except:
        print("[!] No data file found!")
        print("\nCreate backtest_sample.csv with columns:")
        print("  date, EM, regime, market_type, divergence_warning, fwd_return_10d")
        print("\nOr run full backtest:")
        print("  python run_mbi_em_backtest.py --start 2024-10-01 --end 2024-11-30")
        exit(1)

# Clean column names (remove spaces)
df.columns = df.columns.str.strip()

# =============================================================================
# QUICK METRICS
# =============================================================================

print("="*80)
print("1. PERFORMANCE BY MARKET TYPE")
print("="*80 + "\n")

if 'market_type' in df.columns and 'fwd_return_10d' in df.columns:
    # Remove unknown/NaN
    df_clean = df[df['market_type'].notna()].copy()
    
    perf = df_clean.groupby('market_type').agg({
        'fwd_return_10d': ['count', 'mean', lambda x: (x > 0).sum() / len(x) * 100]
    }).round(2)
    
    perf.columns = ['Count', 'Avg Return %', 'Win Rate %']
    perf = perf.sort_values('Avg Return %', ascending=False)
    
    print(perf)
    print()
    
    # Highlight best/worst
    best = perf['Avg Return %'].idxmax()
    worst = perf['Avg Return %'].idxmin()
    
    print(f"[BEST]  {best}: {perf.loc[best, 'Avg Return %']:+.2f}% avg")
    print(f"[WORST] {worst}: {perf.loc[worst, 'Avg Return %']:+.2f}% avg")
    print(f"[VALUE] Spread = {perf.loc[best, 'Avg Return %'] - perf.loc[worst, 'Avg Return %']:.2f}%")
    print()

# =============================================================================
# DIVERGENCE IMPACT
# =============================================================================

print("="*80)
print("2. DIVERGENCE WARNING IMPACT")
print("="*80 + "\n")

if 'divergence_warning' in df.columns:
    # Clean divergence column
    df['div'] = df['divergence_warning'].astype(str).str.upper().isin(['TRUE', 'YES', '1'])
    
    div_impact = df.groupby('div')['fwd_return_10d'].agg([
        ('Count', 'count'),
        ('Avg Return', 'mean')
    ]).round(2)
    
    print(div_impact)
    print()
    
    if True in div_impact.index and False in div_impact.index:
        no_div = div_impact.loc[False, 'Avg Return']
        with_div = div_impact.loc[True, 'Avg Return']
        
        print(f"Without Divergence: {no_div:+.2f}%")
        print(f"With Divergence:    {with_div:+.2f}%")
        print(f"Difference:         {no_div - with_div:+.2f}%")
        print()
        print(f"  -> Divergence warnings catch {abs(no_div - with_div):.2f}% worse signals!")
        print()

# =============================================================================
# BROAD RALLY VS DIVERGENCE RALLY
# =============================================================================

print("="*80)
print("3. V3 VALUE: BROAD RALLY VS DIVERGENCE RALLY")
print("="*80 + "\n")

if 'market_type' in df.columns:
    broad = df[df['market_type'] == 'Broad Rally']
    diverge = df[df['market_type'] == 'Divergence Rally']
    
    if len(broad) > 0:
        broad_avg = broad['fwd_return_10d'].mean()
        broad_win = (broad['fwd_return_10d'] > 0).sum() / len(broad) * 100
        print(f"BROAD RALLY ({len(broad)} signals):")
        print(f"  Avg Return: {broad_avg:+.2f}%")
        print(f"  Win Rate:   {broad_win:.1f}%")
        print(f"  -> V3 Action: Trade with 120-144% position")
        print()
    
    if len(diverge) > 0:
        div_avg = diverge['fwd_return_10d'].mean()
        div_win = (diverge['fwd_return_10d'] > 0).sum() / len(diverge) * 100
        print(f"DIVERGENCE RALLY ({len(diverge)} signals):")
        print(f"  Avg Return: {div_avg:+.2f}%")
        print(f"  Win Rate:   {div_win:.1f}%")
        print(f"  -> V3 Action: Reduce to 30-50% position")
        print()
    
    if len(broad) > 0 and len(diverge) > 0:
        v3_value = broad_avg - div_avg
        print(f"V3 VALUE: {v3_value:+.2f}%")
        print(f"  -> This is how much better Broad Rally performs!")
        print(f"  -> V2 would trade both equally (lose {abs(div_avg):.2f}% on divergences)")
        print(f"  -> V3 avoids 60-70% of divergence losses by reducing position")
        print()

# =============================================================================
# REGIME PERFORMANCE
# =============================================================================

print("="*80)
print("4. PERFORMANCE BY REGIME")
print("="*80 + "\n")

if 'regime' in df.columns:
    regime_perf = df.groupby('regime').agg({
        'fwd_return_10d': ['count', 'mean']
    }).round(2)
    
    regime_perf.columns = ['Count', 'Avg Return %']
    regime_perf = regime_perf.sort_values('Avg Return %', ascending=False)
    
    print(regime_perf)
    print()

# =============================================================================
# EXAMPLE CASES
# =============================================================================

print("="*80)
print("5. EXAMPLE SCENARIOS FROM YOUR DATA")
print("="*80 + "\n")

# Show specific examples
examples = [
    ("Broad Rally + High EM", 
     (df['market_type'] == 'Broad Rally') & (df['EM'] > 60)),
    
    ("Divergence Rally (V3 catches these!)", 
     df['market_type'] == 'Divergence Rally'),
    
    ("Deteriorating + Falling Index",
     (df['regime'] == 'Deteriorating') & (df.get('index_trend', 'flat') == 'falling'))
]

for title, condition in examples:
    subset = df[condition]
    if len(subset) > 0:
        avg_ret = subset['fwd_return_10d'].mean()
        print(f"{title}:")
        print(f"  Count: {len(subset)}")
        print(f"  Avg Forward Return: {avg_ret:+.2f}%")
        
        # Show one example
        sample = subset.iloc[0]
        print(f"  Example: {sample.get('date', 'N/A')}")
        print(f"    EM: {sample.get('EM', 'N/A'):.1f}%")
        print(f"    Index Trend: {sample.get('index_trend', 'N/A')}")
        print(f"    Result: {sample['fwd_return_10d']:+.2f}%")
        print()

# =============================================================================
# V3 SUMMARY
# =============================================================================

print("="*80)
print("6. V3 SYSTEM SUMMARY")
print("="*80 + "\n")

if 'market_type' in df.columns and 'EM' in df.columns:
    # Count signal types
    broad_count = len(df[df['market_type'] == 'Broad Rally'])
    div_count = len(df[df['market_type'] == 'Divergence Rally'])
    total_signals = len(df[df['EM'] >= 40])
    
    print(f"Total High EM Signals (>40%): {total_signals}")
    print(f"  - Broad Rally (trade full):    {broad_count} ({broad_count/total_signals*100:.1f}%)")
    print(f"  - Divergence Rally (reduce):   {div_count} ({div_count/total_signals*100:.1f}%)")
    print()
    print(f"V3 helps you:")
    print(f"  [+] Identify {broad_count} best signals (Broad Rally)")
    print(f"  [+] Warn about {div_count} false signals (Divergence)")
    print(f"  [+] Adjust position size dynamically (30-144%)")
    print()

print("="*80)
print("ANALYSIS COMPLETE!")
print("="*80)
print()
print("Next steps:")
print("  1. Review market types: Broad Rally = best, Divergence = worst")
print("  2. Check if divergence warnings have negative returns")
print("  3. Run full backtest for 2024: python run_mbi_em_backtest.py")
print()

