"""
MBI EM (Equity Momentum) Backtester V2
=======================================
Validates the MBI EM system's predictive power and optimal thresholds.

Tests:
1. Forward returns by EM regime
2. Regime transition accuracy
3. False positive/negative rates
4. Optimal EM threshold tuning
5. Trade simulation using EM signals

Strategy (V2 - Trend-Based):
- Use EM as market timing filter
- Enter trades when EM >= Early Momentum threshold (18%)
- Stay invested through Healthy (18-40%), Strong (40-60%), Extreme (>60%) zones
- Exit when EM drops below Repair zone (<15%)
- V2 uses dashboard with trend-based classifier for regime detection

NOTE: Dashboard now uses TrendBasedRegimeClassifier (V2) which incorporates
      EM trend analysis (rising/stable/declining/crashing) and crash detection.

Author: MBI EM System
Date: November 2025
Updated: V2 Integration - November 4, 2025
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import logging
import os
import json
import matplotlib.pyplot as plt
import seaborn as sns

# Import our MBI modules
from mbi_em_dashboard import MBIEMDashboard

# =============================================================================
# LOGGING SETUP
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('mbi_em_backtest.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# =============================================================================
# CONFIGURATION
# =============================================================================

# API Configuration
# Import from config.py (UPDATE CREDENTIALS THERE!)
try:
    from config import API_KEY, ACCESS_TOKEN, UNIVERSE_CSV as DEFAULT_UNIVERSE
except ImportError:
    # Fallback to defaults
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "7uCdOd1Je1xRzfajiTYrlts6bgH4CV46"
    DEFAULT_UNIVERSE = "data/nifty500.csv"
    logger.warning("config.py not found. Using default credentials.")

# Backtest Configuration - Use config.py dates if available
try:
    from config import DEFAULT_BACKTEST_START, DEFAULT_BACKTEST_END
    DEFAULT_START_DATE = DEFAULT_BACKTEST_START
    DEFAULT_END_DATE = DEFAULT_BACKTEST_END
except:
    DEFAULT_START_DATE = "2022-01-01"
    DEFAULT_END_DATE = "2025-11-03"

UNIVERSE_CSV = DEFAULT_UNIVERSE

# EM Thresholds - Import from config.py (V2 - Trend-Based)
try:
    from config import (
        REGIME_BEAR, REGIME_REPAIR, REGIME_EARLY, REGIME_HEALTHY,
        REGIME_STRONG, REGIME_EXTREME,
        EM_CRASH_THRESHOLD_3D, EM_CRASH_THRESHOLD_5D,
        EM_DECLINING_THRESHOLD, EM_RISING_THRESHOLD
    )
    DEFAULT_THRESHOLDS = {
        'bear_control': REGIME_BEAR,
        'repair_zone': REGIME_REPAIR,
        'early_momentum': REGIME_EARLY,
        'healthy_bullish': REGIME_HEALTHY,
        'strong_bullish': REGIME_STRONG,         # NEW V2
        'extreme_bullish': REGIME_EXTREME,       # NEW V2
        'crash_3d': EM_CRASH_THRESHOLD_3D,       # NEW V2
        'crash_5d': EM_CRASH_THRESHOLD_5D,       # NEW V2
        'declining': EM_DECLINING_THRESHOLD,     # NEW V2
        'rising': EM_RISING_THRESHOLD,           # NEW V2
    }
    logger.info(f"Loaded V2 thresholds from config.py: Healthy={REGIME_HEALTHY}, Strong={REGIME_STRONG}, Extreme={REGIME_EXTREME}")
except ImportError:
    # Fallback defaults (V2 thresholds)
    DEFAULT_THRESHOLDS = {
        'bear_control': 12,
        'repair_zone': 15,
        'early_momentum': 18,
        'healthy_bullish': 40,      # V2: Raised from 35
        'strong_bullish': 60,       # NEW V2
        'extreme_bullish': 75,      # NEW V2
        'crash_3d': -10,            # NEW V2
        'crash_5d': -15,            # NEW V2
        'declining': -3,            # NEW V2
        'rising': 3,                # NEW V2
    }
    logger.warning("config.py not found. Using V2 default thresholds.")

# Forward Return Analysis
FORWARD_PERIODS = [5, 10, 20]  # Days to look forward

# Output Directory
OUTPUT_DIR = "MBI_EM_Backtest_Results"
os.makedirs(OUTPUT_DIR, exist_ok=True)


# =============================================================================
# BACKTEST ENGINE
# =============================================================================

class MBIEMBacktester:
    """
    Backtest the MBI EM system to validate predictive power.
    """
    
    def __init__(
        self,
        api_key: str,
        access_token: str,
        universe_csv: str = UNIVERSE_CSV,
        thresholds: Dict = None
    ):
        self.api_key = api_key
        self.access_token = access_token
        self.universe_csv = universe_csv
        self.thresholds = thresholds or DEFAULT_THRESHOLDS
        
        # Initialize dashboard
        self.dashboard = MBIEMDashboard(
            api_key=api_key,
            access_token=access_token,
            universe_csv=universe_csv,
            analysis_days=365*2,  # 2 years for backtest
            lookback_days=370
        )
        
        logger.info("MBI EM Backtester initialized")
    
    def run_backtest(
        self,
        start_date: datetime,
        end_date: datetime,
        index_symbol: str = 'NIFTY 50'
    ) -> Dict:
        """
        Run complete backtest and validation.
        
        Args:
            start_date: Start date for backtest
            end_date: End date for backtest
            index_symbol: Index to use for forward returns
        
        Returns:
            Dict with backtest results and metrics
        """
        logger.info(f"\n{'='*80}")
        logger.info(f"STARTING MBI EM BACKTEST")
        logger.info(f"{'='*80}")
        logger.info(f"Period: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
        logger.info(f"Universe: {self.universe_csv}")
        logger.info(f"Thresholds: {self.thresholds}")
        
        # Step 1: Calculate EM for entire period
        logger.info("\n--- Step 1: Calculating EM for backtest period ---")
        mbi_results = self.dashboard.run_analysis(
            start_date=start_date,
            end_date=end_date
        )
        
        if mbi_results.empty:
            logger.error("No MBI results generated. Check data availability.")
            return {}
        
        logger.info(f"Calculated EM for {len(mbi_results)} trading days")
        
        # Step 2: Get index data for forward returns
        logger.info("\n--- Step 2: Fetching index data for forward returns ---")
        index_data = self._get_index_data(index_symbol, start_date, end_date)
        
        if index_data is None or index_data.empty:
            logger.warning("Index data not available. Skipping forward return analysis.")
            index_data = None
        
        # Step 3: Calculate forward returns
        logger.info("\n--- Step 3: Calculating forward returns by regime ---")
        forward_returns = self._calculate_forward_returns(mbi_results, index_data)
        
        # Step 4: Calculate regime statistics
        logger.info("\n--- Step 4: Analyzing regime performance ---")
        regime_stats = self._analyze_regime_performance(mbi_results, forward_returns)
        
        # Step 5: Calculate false signal rates
        logger.info("\n--- Step 5: Calculating false signal rates ---")
        signal_quality = self._analyze_signal_quality(mbi_results, forward_returns)
        
        # Step 6: Test threshold sensitivity
        logger.info("\n--- Step 6: Testing threshold sensitivity ---")
        threshold_analysis = self._test_threshold_sensitivity(mbi_results, forward_returns)
        
        # Step 7: Simulate trading strategy
        logger.info("\n--- Step 7: Simulating trading strategy ---")
        trading_results = self._simulate_trading(mbi_results, forward_returns)
        
        # Compile results
        results = {
            'mbi_results': mbi_results,
            'forward_returns': forward_returns,
            'regime_stats': regime_stats,
            'signal_quality': signal_quality,
            'threshold_analysis': threshold_analysis,
            'trading_results': trading_results,
            'backtest_period': {
                'start': start_date,
                'end': end_date,
                'days': len(mbi_results)
            }
        }
        
        # Step 8: Generate reports
        logger.info("\n--- Step 8: Generating reports ---")
        self._generate_report(results)
        self._generate_plots(results)
        
        logger.info(f"\n{'='*80}")
        logger.info("BACKTEST COMPLETE")
        logger.info(f"{'='*80}\n")
        
        return results
    
    def _get_index_data(
        self,
        index_symbol: str,
        start_date: datetime,
        end_date: datetime
    ) -> Optional[pd.DataFrame]:
        """Fetch index data for forward return calculation"""
        try:
            # Try to get from Kite
            from kiteconnect import KiteConnect
            kite = KiteConnect(api_key=self.api_key)
            kite.set_access_token(self.access_token)
            
            # Get Nifty 50 instrument token
            instruments = kite.instruments(exchange="NSE")
            nifty_token = None
            for inst in instruments:
                if inst['tradingsymbol'] == 'NIFTY 50':
                    nifty_token = inst['instrument_token']
                    break
            
            if not nifty_token:
                logger.warning("Nifty 50 not found in instruments")
                return None
            
            # Fetch historical data
            data = kite.historical_data(
                instrument_token=nifty_token,
                from_date=start_date,
                to_date=end_date + timedelta(days=30),  # Extra buffer for forward returns
                interval="day"
            )
            
            if not data:
                return None
            
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
            df.set_index('date', inplace=True)
            
            logger.info(f"Fetched {len(df)} days of index data")
            return df
            
        except Exception as e:
            logger.error(f"Error fetching index data: {e}")
            return None
    
    def _calculate_forward_returns(
        self,
        mbi_results: pd.DataFrame,
        index_data: Optional[pd.DataFrame]
    ) -> pd.DataFrame:
        """Calculate forward returns for each date"""
        results = mbi_results.copy()
        
        if index_data is None:
            logger.warning("No index data available for forward returns")
            return results
        
        for period in FORWARD_PERIODS:
            col_name = f'fwd_return_{period}d'
            results[col_name] = np.nan
            
            for idx, row in results.iterrows():
                current_date = pd.to_datetime(row['date'])
                
                # Get future date
                future_dates = index_data[index_data.index > current_date].head(period)
                
                if len(future_dates) >= period:
                    current_close = index_data.loc[
                        index_data.index <= current_date, 'close'
                    ].iloc[-1]
                    future_close = future_dates['close'].iloc[-1]
                    
                    fwd_return = ((future_close - current_close) / current_close) * 100
                    results.at[idx, col_name] = fwd_return
        
        return results
    
    def _analyze_regime_performance(
        self,
        mbi_results: pd.DataFrame,
        forward_returns: pd.DataFrame
    ) -> Dict:
        """Analyze performance by regime"""
        stats = {}
        
        for regime in forward_returns['regime'].unique():
            regime_data = forward_returns[forward_returns['regime'] == regime]
            
            regime_stats = {
                'count': len(regime_data),
                'avg_em': regime_data['EM'].mean(),
                'em_std': regime_data['EM'].std(),
            }
            
            # Forward returns stats
            for period in FORWARD_PERIODS:
                col = f'fwd_return_{period}d'
                if col in regime_data.columns:
                    valid_returns = regime_data[col].dropna()
                    if len(valid_returns) > 0:
                        regime_stats[f'avg_return_{period}d'] = valid_returns.mean()
                        regime_stats[f'positive_pct_{period}d'] = (valid_returns > 0).mean() * 100
                        regime_stats[f'median_return_{period}d'] = valid_returns.median()
            
            stats[regime] = regime_stats
        
        return stats
    
    def _analyze_signal_quality(
        self,
        mbi_results: pd.DataFrame,
        forward_returns: pd.DataFrame
    ) -> Dict:
        """Calculate false positive and false negative rates"""
        results = {}
        
        for period in FORWARD_PERIODS:
            col = f'fwd_return_{period}d'
            if col not in forward_returns.columns:
                continue
            
            valid_data = forward_returns.dropna(subset=[col])
            
            # Bullish signals (EM > Early threshold) - V2: uses config threshold
            early_threshold = self.thresholds.get('early_momentum', 18)
            bullish_signals = valid_data[valid_data['EM'] > early_threshold]
            if len(bullish_signals) > 0:
                false_positives = (bullish_signals[col] < 0).sum()
                fp_rate = false_positives / len(bullish_signals)
                avg_return = bullish_signals[col].mean()
            else:
                fp_rate = 0
                avg_return = 0
            
            # Bearish signals (EM < 12)
            bearish_signals = valid_data[valid_data['EM'] < 12]
            if len(bearish_signals) > 0:
                false_negatives = (bearish_signals[col] > 0).sum()
                fn_rate = false_negatives / len(bearish_signals)
                avg_return_bear = bearish_signals[col].mean()
            else:
                fn_rate = 0
                avg_return_bear = 0
            
            # Overall accuracy
            bullish_correct = len(bullish_signals[bullish_signals[col] > 0])
            bearish_correct = len(bearish_signals[bearish_signals[col] < 0])
            total_signals = len(bullish_signals) + len(bearish_signals)
            
            accuracy = (bullish_correct + bearish_correct) / total_signals if total_signals > 0 else 0
            
            results[f'{period}d'] = {
                'false_positive_rate': fp_rate,
                'false_negative_rate': fn_rate,
                'accuracy': accuracy,
                'bullish_signals': len(bullish_signals),
                'bearish_signals': len(bearish_signals),
                'avg_return_bullish': avg_return,
                'avg_return_bearish': avg_return_bear
            }
        
        return results
    
    def _test_threshold_sensitivity(
        self,
        mbi_results: pd.DataFrame,
        forward_returns: pd.DataFrame
    ) -> Dict:
        """Test different EM thresholds to find optimal values"""
        results = {}
        
        # Test bear control threshold (8-16)
        bear_thresholds = range(8, 17, 2)
        results['bear_control'] = self._test_single_threshold(
            forward_returns, 'bear', bear_thresholds, operator='<'
        )
        
        # Test healthy bullish threshold (16-28)
        healthy_thresholds = range(16, 29, 2)
        results['healthy_bullish'] = self._test_single_threshold(
            forward_returns, 'healthy', healthy_thresholds, operator='>'
        )
        
        return results
    
    def _test_single_threshold(
        self,
        data: pd.DataFrame,
        threshold_type: str,
        threshold_values: range,
        operator: str = '>'
    ) -> List[Dict]:
        """Test a range of threshold values"""
        results = []
        
        col = 'fwd_return_10d'  # Use 10-day forward return
        if col not in data.columns:
            return results
        
        valid_data = data.dropna(subset=[col])
        
        for threshold in threshold_values:
            if operator == '>':
                signals = valid_data[valid_data['EM'] > threshold]
                expected_positive = True
            else:
                signals = valid_data[valid_data['EM'] < threshold]
                expected_positive = False
            
            if len(signals) > 0:
                avg_return = signals[col].mean()
                positive_rate = (signals[col] > 0).mean()
                accuracy = positive_rate if expected_positive else (1 - positive_rate)
                
                results.append({
                    'threshold': threshold,
                    'signal_count': len(signals),
                    'avg_return': avg_return,
                    'positive_rate': positive_rate,
                    'accuracy': accuracy
                })
        
        return results
    
    def _simulate_trading(
        self,
        mbi_results: pd.DataFrame,
        forward_returns: pd.DataFrame
    ) -> Dict:
        """Simulate simple trading strategy using EM signals"""
        INITIAL_CAPITAL = 1000000
        
        capital = INITIAL_CAPITAL
        position = 0  # 0 = cash, 1 = invested
        trades = []
        equity_curve = [INITIAL_CAPITAL]
        
        col = 'fwd_return_10d'
        if col not in forward_returns.columns:
            return {}
        
        for idx, row in forward_returns.iterrows():
            em = row['EM']
            fwd_return = row[col]
            
            if pd.isna(fwd_return):
                equity_curve.append(equity_curve[-1])
                continue
            
            # Trading logic (V2: Uses config thresholds)
            early_threshold = self.thresholds.get('early_momentum', 18)
            healthy_threshold = self.thresholds.get('healthy_bullish', 40)
            strong_threshold = self.thresholds.get('strong_bullish', 60)
            
            if position == 0:
                # Not invested - check for entry signal
                # V2: Enter at Early threshold, stay through Healthy/Strong zones
                if em >= early_threshold:  # Entry: EM >= 18%
                    position = 1
                    entry_price = capital
                    trades.append({
                        'date': row['date'],
                        'action': 'BUY',
                        'em': em,
                        'capital': capital
                    })
            else:
                # Invested - check for exit signal
                # V2: Exit if below Repair zone
                if em < self.thresholds.get('repair_zone', 15):  # Exit: EM < 15%
                    position = 0
                    # Realize return
                    capital = capital * (1 + fwd_return/100)
                    trades.append({
                        'date': row['date'],
                        'action': 'SELL',
                        'em': em,
                        'return': fwd_return,
                        'capital': capital
                    })
                else:
                    # Still invested, unrealized gain
                    capital = capital * (1 + fwd_return/100)
            
            equity_curve.append(capital)
        
        # Calculate metrics
        total_return = ((capital - INITIAL_CAPITAL) / INITIAL_CAPITAL) * 100
        num_trades = len([t for t in trades if t['action'] == 'BUY'])
        
        winning_trades = [t for t in trades if t['action'] == 'SELL' and t.get('return', 0) > 0]
        win_rate = len(winning_trades) / num_trades * 100 if num_trades > 0 else 0
        
        return {
            'initial_capital': INITIAL_CAPITAL,
            'final_capital': capital,
            'total_return': total_return,
            'num_trades': num_trades,
            'win_rate': win_rate,
            'trades': trades,
            'equity_curve': equity_curve
        }
    
    def _generate_report(self, results: Dict):
        """Generate text report"""
        report_file = os.path.join(OUTPUT_DIR, 'backtest_report.txt')
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("MBI EM BACKTEST REPORT\n")
            f.write("="*80 + "\n\n")
            
            # Backtest period
            f.write(f"Period: {results['backtest_period']['start'].strftime('%Y-%m-%d')} ")
            f.write(f"to {results['backtest_period']['end'].strftime('%Y-%m-%d')}\n")
            f.write(f"Trading Days: {results['backtest_period']['days']}\n\n")
            
            # Regime performance
            f.write("-"*80 + "\n")
            f.write("REGIME PERFORMANCE\n")
            f.write("-"*80 + "\n")
            for regime, stats in results['regime_stats'].items():
                f.write(f"\n{regime}:\n")
                f.write(f"  Days: {stats['count']}\n")
                f.write(f"  Avg EM: {stats['avg_em']:.2f}%\n")
                if 'avg_return_10d' in stats:
                    f.write(f"  Avg 10d Return: {stats['avg_return_10d']:.2f}%\n")
                    f.write(f"  Positive Rate: {stats['positive_pct_10d']:.1f}%\n")
            
            # Signal quality
            f.write("\n" + "-"*80 + "\n")
            f.write("SIGNAL QUALITY\n")
            f.write("-"*80 + "\n")
            for period, metrics in results['signal_quality'].items():
                f.write(f"\n{period} Forward Return:\n")
                f.write(f"  False Positive Rate: {metrics['false_positive_rate']:.1%}\n")
                f.write(f"  False Negative Rate: {metrics['false_negative_rate']:.1%}\n")
                f.write(f"  Accuracy: {metrics['accuracy']:.1%}\n")
                f.write(f"  Bullish Signals: {metrics['bullish_signals']}\n")
                f.write(f"  Bearish Signals: {metrics['bearish_signals']}\n")
            
            # Trading results
            if results['trading_results']:
                f.write("\n" + "-"*80 + "\n")
                f.write("TRADING SIMULATION\n")
                f.write("-"*80 + "\n")
                tr = results['trading_results']
                f.write(f"Initial Capital: Rs.{tr['initial_capital']:,.0f}\n")
                f.write(f"Final Capital: Rs.{tr['final_capital']:,.0f}\n")
                f.write(f"Total Return: {tr['total_return']:.2f}%\n")
                f.write(f"Number of Trades: {tr['num_trades']}\n")
                f.write(f"Win Rate: {tr['win_rate']:.1f}%\n")
        
        logger.info(f"Report saved to {report_file}")
    
    def _generate_plots(self, results: Dict):
        """Generate visualization plots"""
        # Plot 1: EM over time with regime colors
        self._plot_em_timeline(results)
        
        # Plot 2: Forward returns by regime
        self._plot_returns_by_regime(results)
        
        # Plot 3: Threshold sensitivity
        self._plot_threshold_sensitivity(results)
        
        # Plot 4: Equity curve
        if results['trading_results']:
            self._plot_equity_curve(results)
    
    def _plot_em_timeline(self, results: Dict):
        """Plot EM over time with regime colors"""
        df = results['mbi_results']
        
        fig, ax = plt.subplots(figsize=(15, 6))
        
        # Color map for regimes
        regime_colors = {
            'Bear Control': 'red',
            'Repair Zone': 'orange',
            'Early Momentum': 'yellow',
            'Healthy Bullish': 'green',
            'Euphoria': 'blue'
        }
        
        for regime, color in regime_colors.items():
            regime_data = df[df['regime'] == regime]
            if not regime_data.empty:
                ax.scatter(regime_data['date'], regime_data['EM'], 
                          c=color, label=regime, alpha=0.6, s=20)
        
        # Add threshold lines (V2 thresholds)
        ax.axhline(y=self.thresholds.get('bear_control', 12), color='red', linestyle='--', alpha=0.5, label='Bear Control')
        ax.axhline(y=self.thresholds.get('early_momentum', 18), color='yellow', linestyle='--', alpha=0.5, label='Early Momentum')
        ax.axhline(y=self.thresholds.get('healthy_bullish', 40), color='green', linestyle='--', alpha=0.5, label='Healthy')
        ax.axhline(y=self.thresholds.get('strong_bullish', 60), color='darkgreen', linestyle='--', alpha=0.5, label='Strong')
        ax.axhline(y=self.thresholds.get('extreme_bullish', 75), color='blue', linestyle='--', alpha=0.5, label='Extreme')
        
        ax.set_xlabel('Date')
        ax.set_ylabel('EM (%)')
        ax.set_title('Equity Momentum (EM) Timeline')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, 'em_timeline.png'), dpi=150)
        plt.close()
        
        logger.info("Saved: em_timeline.png")
    
    def _plot_returns_by_regime(self, results: Dict):
        """Box plot of forward returns by regime"""
        df = results['forward_returns']
        
        if 'fwd_return_10d' not in df.columns:
            return
        
        fig, ax = plt.subplots(figsize=(12, 6))
        
        data_to_plot = []
        labels = []
        for regime in df['regime'].unique():
            regime_returns = df[df['regime'] == regime]['fwd_return_10d'].dropna()
            if len(regime_returns) > 0:
                data_to_plot.append(regime_returns)
                labels.append(regime)
        
        ax.boxplot(data_to_plot, labels=labels)
        ax.set_ylabel('10-Day Forward Return (%)')
        ax.set_title('Forward Returns by Regime')
        ax.axhline(y=0, color='black', linestyle='--', alpha=0.5)
        ax.grid(True, alpha=0.3)
        plt.xticks(rotation=45, ha='right')
        
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, 'returns_by_regime.png'), dpi=150)
        plt.close()
        
        logger.info("Saved: returns_by_regime.png")
    
    def _plot_threshold_sensitivity(self, results: Dict):
        """Plot threshold sensitivity analysis"""
        threshold_data = results['threshold_analysis']
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle('Threshold Sensitivity Analysis', fontsize=16)
        
        # Bear Control threshold
        if 'bear_control' in threshold_data and threshold_data['bear_control']:
            bear_df = pd.DataFrame(threshold_data['bear_control'])
            
            axes[0, 0].plot(bear_df['threshold'], bear_df['avg_return'], marker='o')
            axes[0, 0].set_title('Bear Control: Avg Return vs Threshold')
            axes[0, 0].set_xlabel('EM Threshold')
            axes[0, 0].set_ylabel('Avg 10d Return (%)')
            axes[0, 0].grid(True)
            axes[0, 0].axvline(x=12, color='red', linestyle='--', label='Default (12)')
            axes[0, 0].legend()
            
            axes[0, 1].plot(bear_df['threshold'], bear_df['accuracy'], marker='o', color='green')
            axes[0, 1].set_title('Bear Control: Accuracy vs Threshold')
            axes[0, 1].set_xlabel('EM Threshold')
            axes[0, 1].set_ylabel('Accuracy')
            axes[0, 1].grid(True)
            axes[0, 1].axvline(x=12, color='red', linestyle='--', label='Default (12)')
            axes[0, 1].legend()
        
        # Healthy Bullish threshold
        if 'healthy_bullish' in threshold_data and threshold_data['healthy_bullish']:
            healthy_df = pd.DataFrame(threshold_data['healthy_bullish'])
            
            axes[1, 0].plot(healthy_df['threshold'], healthy_df['avg_return'], marker='o')
            axes[1, 0].set_title('Healthy Bullish: Avg Return vs Threshold')
            axes[1, 0].set_xlabel('EM Threshold')
            axes[1, 0].set_ylabel('Avg 10d Return (%)')
            axes[1, 0].grid(True)
            default_threshold = self.thresholds.get('early_momentum', 18)
            axes[1, 0].axvline(x=default_threshold, color='green', linestyle='--', label=f'Config ({default_threshold})')
            axes[1, 0].legend()
            
            axes[1, 1].plot(healthy_df['threshold'], healthy_df['signal_count'], marker='o', color='orange')
            axes[1, 1].set_title('Healthy Bullish: Signal Count vs Threshold')
            axes[1, 1].set_xlabel('EM Threshold')
            axes[1, 1].set_ylabel('Number of Signals')
            axes[1, 1].grid(True)
            axes[1, 1].axvline(x=default_threshold, color='green', linestyle='--', label=f'Config ({default_threshold})')
            axes[1, 1].legend()
        
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, 'threshold_sensitivity.png'), dpi=150)
        plt.close()
        
        logger.info("Saved: threshold_sensitivity.png")
    
    def _plot_equity_curve(self, results: Dict):
        """Plot simulated trading equity curve"""
        tr = results['trading_results']
        
        fig, ax = plt.subplots(figsize=(15, 6))
        
        equity = tr['equity_curve']
        ax.plot(equity, linewidth=2)
        ax.set_xlabel('Day')
        ax.set_ylabel('Equity (Rs.)')
        ax.set_title(f"Equity Curve - Total Return: {tr['total_return']:.2f}%")
        ax.grid(True, alpha=0.3)
        ax.axhline(y=tr['initial_capital'], color='gray', linestyle='--', alpha=0.5, label='Initial')
        ax.legend()
        
        # Mark trades
        for trade in tr['trades']:
            if trade['action'] == 'BUY':
                idx = next(i for i, d in enumerate(results['mbi_results']['date']) 
                          if d == trade['date'])
                ax.axvline(x=idx, color='green', alpha=0.3, linewidth=0.5)
            elif trade['action'] == 'SELL':
                idx = next(i for i, d in enumerate(results['mbi_results']['date']) 
                          if d == trade['date'])
                ax.axvline(x=idx, color='red', alpha=0.3, linewidth=0.5)
        
        plt.tight_layout()
        plt.savefig(os.path.join(OUTPUT_DIR, 'equity_curve.png'), dpi=150)
        plt.close()
        
        logger.info("Saved: equity_curve.png")
    
    def export_to_excel(self, results: Dict) -> str:
        """
        Export backtest results to Excel for easy analysis.
        
        Returns path to generated Excel file.
        """
        try:
            import openpyxl
            from openpyxl.styles import PatternFill, Font, Alignment
            
            logger.info("Generating Excel export...")
            
            # Validate inputs
            if 'mbi_results' not in results or 'forward_returns' not in results:
                logger.error("Missing required data for Excel export")
                return None
            
            # Prepare data
            mbi_df = results['mbi_results'].copy()
            fwd_df = results['forward_returns'].copy()
            
            # Check if required columns exist
            required_cols = ['date', 'EM', 'regime', '4.5r', '20sma', '50sma', '52WH', '52WL']
            missing_cols = [col for col in required_cols if col not in mbi_df.columns]
            if missing_cols:
                logger.warning(f"Missing columns: {missing_cols}. Using available columns only.")
            
            # Merge forward returns
            if 'fwd_return_10d' in fwd_df.columns:
                merged_df = mbi_df.merge(fwd_df[['date', 'fwd_return_10d']], on='date', how='left')
            else:
                merged_df = mbi_df.copy()
                merged_df['fwd_return_10d'] = None
            
            # Format date
            merged_df['date'] = pd.to_datetime(merged_df['date']).dt.strftime('%Y-%m-%d')
            
            # Select and order columns (V3.3: Add all new columns)
            available_cols = merged_df.columns.tolist()
            
            # Build column list dynamically
            columns = ['date']
            
            # Index data (V3)
            for col in ['index_close', 'index_trend', 'index_chng_5d']:
                if col in available_cols:
                    columns.append(col)
            
            # Breadth metrics
            for col in ['4.5r', '4.5r_chng', '20sma', '20sma_chng', '50sma', '50sma_chng', '52WH', '52WL']:
                if col in available_cols:
                    columns.append(col)
            
            # EM metrics (V3.2)
            for col in ['EM', 'EM_chng', 'EM_chng_3d', 'EM_chng_5d', 'em_trend']:
                if col in available_cols:
                    columns.append(col)
            
            # Market classification (V3)
            for col in ['market_type', 'divergence_warning', 'position_size', 'regime', 'trading_action']:
                if col in available_cols:
                    columns.append(col)
            
            # Multi-timeframe signals (V3.3)
            for col in ['signal_2_5d', 'reason_2_5d', 'signal_5_10d', 'reason_5_10d',
                       'signal_10_21d', 'reason_10_21d', 'signal_21plus', 'reason_21plus']:
                if col in available_cols:
                    columns.append(col)
            
            # Forward return
            if 'fwd_return_10d' in available_cols:
                columns.append('fwd_return_10d')
            
            # Filter to only columns that exist
            columns = [col for col in columns if col in available_cols]
            
            display_df = merged_df[columns].copy()
            
            # Round numeric columns safely
            numeric_round_1 = ['EM', '4.5r', '20sma', '50sma', 'index_close']
            for col in numeric_round_1:
                if col in display_df.columns and pd.api.types.is_numeric_dtype(display_df[col]):
                    display_df[col] = display_df[col].round(1)
            
            numeric_round_2 = ['fwd_return_10d', 'index_chng_5d', 'EM_chng', 'EM_chng_3d', 'EM_chng_5d',
                              '4.5r_chng', '20sma_chng', '50sma_chng']
            for col in numeric_round_2:
                if col in display_df.columns and pd.api.types.is_numeric_dtype(display_df[col]):
                    display_df[col] = display_df[col].round(2)
            
            # Format position_size as percentage
            if 'position_size' in display_df.columns and pd.api.types.is_numeric_dtype(display_df['position_size']):
                display_df['position_size'] = (display_df['position_size'] * 100).round(0).astype(str) + '%'
            
            # Format divergence_warning as Yes/No
            if 'divergence_warning' in display_df.columns:
                display_df['divergence_warning'] = display_df['divergence_warning'].map({True: 'YES', False: 'No'})
            
            # Save to Excel
            output_file = os.path.join(OUTPUT_DIR, 'backtest_results.xlsx')
            display_df.to_excel(output_file, index=False, engine='openpyxl')
            
            # Apply formatting
            wb = openpyxl.load_workbook(output_file)
            ws = wb.active
            
            # Header formatting
            header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True)
            
            for cell in ws[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", vertical="center")
            
            # Color code EM values
            green_fill = PatternFill(start_color="00FF00", end_color="00FF00", fill_type="solid")
            yellow_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
            red_fill = PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid")
            white_font = Font(color="FFFFFF", bold=True)
            
            # Format data cells dynamically based on column headers
            header_row = [cell.value for cell in ws[1]]
            
            # Find column indices dynamically
            em_col = header_row.index('EM') + 1 if 'EM' in header_row else None
            regime_col = header_row.index('regime') + 1 if 'regime' in header_row else None
            fwd_col = header_row.index('fwd_return_10d') + 1 if 'fwd_return_10d' in header_row else None
            
            for row in range(2, ws.max_row + 1):
                # Color EM cells
                if em_col:
                    em_cell = ws.cell(row=row, column=em_col)
                    em_value = em_cell.value
                    
                    if em_value is not None and isinstance(em_value, (int, float)):
                        if em_value < 12:
                            em_cell.fill = red_fill
                            em_cell.font = white_font
                        elif em_value < 18:
                            em_cell.fill = yellow_fill
                        elif em_value >= self.thresholds.get('healthy_bullish', 40):
                            em_cell.fill = green_fill
                
                # Color regime cells
                if regime_col:
                    regime_cell = ws.cell(row=row, column=regime_col)
                    regime_value = regime_cell.value
                    
                    if regime_value:
                        if "Bear" in str(regime_value):
                            regime_cell.fill = red_fill
                            regime_cell.font = white_font
                        elif "Healthy" in str(regime_value) or "Bullish" in str(regime_value):
                            regime_cell.fill = green_fill
                        elif "Early" in str(regime_value):
                            regime_cell.fill = yellow_fill
                
                # Color forward returns
                if fwd_col:
                    fwd_cell = ws.cell(row=row, column=fwd_col)
                    fwd_value = fwd_cell.value
                    
                    if fwd_value is not None and isinstance(fwd_value, (int, float)):
                        if fwd_value > 0:
                            fwd_cell.fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
                        elif fwd_value < 0:
                            fwd_cell.fill = PatternFill(start_color="FFB6C1", end_color="FFB6C1", fill_type="solid")
            
            # Adjust column widths
            ws.column_dimensions['A'].width = 12  # Date
            ws.column_dimensions['B'].width = 10  # EM
            ws.column_dimensions['C'].width = 20  # Regime
            ws.column_dimensions['D'].width = 18  # Fwd Return
            ws.column_dimensions['E'].width = 8   # 4.5R
            ws.column_dimensions['F'].width = 10  # 20SMA
            ws.column_dimensions['G'].width = 10  # 50SMA
            ws.column_dimensions['H'].width = 8   # 52WH
            ws.column_dimensions['I'].width = 8   # 52WL
        
            # Save formatted workbook
            wb.save(output_file)
            
            logger.info(f"Excel export saved to: {output_file}")
            return output_file
            
        except Exception as e:
            logger.error(f"Failed to export to Excel: {e}")
            logger.exception("Excel export error details:")
            return None


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Run backtest with command line arguments"""
    import argparse
    
    parser = argparse.ArgumentParser(description='MBI EM System Backtester')
    parser.add_argument('--start-date', type=str, default=DEFAULT_START_DATE,
                       help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end-date', type=str, default=DEFAULT_END_DATE,
                       help='End date (YYYY-MM-DD)')
    parser.add_argument('--universe', type=str, default=UNIVERSE_CSV,
                       help='Path to universe CSV')
    
    args = parser.parse_args()
    
    # Parse dates
    start_date = datetime.strptime(args.start_date, '%Y-%m-%d')
    end_date = datetime.strptime(args.end_date, '%Y-%m-%d')
    
    # Initialize backtester
    backtester = MBIEMBacktester(
        api_key=API_KEY,
        access_token=ACCESS_TOKEN,
        universe_csv=args.universe
    )
    
    # Run backtest
    results = backtester.run_backtest(start_date, end_date)
    
    # Export to Excel
    print("\n📊 Generating Excel export...")
    excel_file = backtester.export_to_excel(results)
    if excel_file:
        print(f"   Excel saved: {excel_file}")
    else:
        print("   Warning: Excel export failed (see logs)")
    
    # Print summary
    print("\n" + "="*80)
    print("BACKTEST SUMMARY")
    print("="*80)
    
    if results.get('signal_quality'):
        sq = results['signal_quality'].get('10d', {})
        print(f"\nSignal Quality (10-day forward):")
        print(f"  Accuracy: {sq.get('accuracy', 0):.1%}")
        print(f"  False Positive Rate: {sq.get('false_positive_rate', 0):.1%}")
        print(f"  False Negative Rate: {sq.get('false_negative_rate', 0):.1%}")
    
    if results.get('trading_results'):
        tr = results['trading_results']
        print(f"\nTrading Simulation:")
        print(f"  Total Return: {tr.get('total_return', 0):.2f}%")
        print(f"  Win Rate: {tr.get('win_rate', 0):.1f}%")
        print(f"  Number of Trades: {tr.get('num_trades', 0)}")
    
    print(f"\n✅ Results saved to: {OUTPUT_DIR}/")
    print("="*80 + "\n")


if __name__ == "__main__":
    main()

