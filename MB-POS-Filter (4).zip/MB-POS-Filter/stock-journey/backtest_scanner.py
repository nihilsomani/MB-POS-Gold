"""
Backtest Scanner for Weekly→Daily Strategy
A comprehensive backtesting engine that simulates the scanner's signals historically
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional, Any
import logging
from dataclasses import dataclass, asdict
from pathlib import Path
import json

from weekly_daily_scanner import WeeklyDailyScanner
from config import ScannerConfig

logging.basicConfig(
    level=logging.INFO,  # Normal logging
    format='%(levelname)s:%(name)s:%(message)s'
)
logger = logging.getLogger(__name__)


@dataclass
class Trade:
    """Represents a single trade"""
    symbol: str
    entry_date: str
    entry_price: float
    stop_price: float
    target_price: float
    position_size: int
    position_value: float
    risk_amount: float
    
    # Signal info
    signal_date: str
    confidence_score: float
    stage: str
    
    # Exit info (filled when trade closes)
    exit_date: Optional[str] = None
    exit_price: Optional[float] = None
    exit_reason: Optional[str] = None
    pnl: Optional[float] = None
    pnl_pct: Optional[float] = None
    return_r: Optional[float] = None  # Return in R multiples
    days_held: Optional[int] = None
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    def close_trade(self, exit_date: str, exit_price: float, exit_reason: str):
        """Close the trade and calculate P&L"""
        self.exit_date = exit_date
        self.exit_price = exit_price
        self.exit_reason = exit_reason
        
        # Calculate P&L
        self.pnl = (exit_price - self.entry_price) * self.position_size
        self.pnl_pct = ((exit_price - self.entry_price) / self.entry_price) * 100
        
        # Calculate R-multiple (how many times risk was gained/lost)
        risk_per_share = self.entry_price - self.stop_price
        if risk_per_share > 0:
            self.return_r = (exit_price - self.entry_price) / risk_per_share
        else:
            self.return_r = 0
        
        # Days held
        entry_dt = pd.to_datetime(self.entry_date)
        exit_dt = pd.to_datetime(self.exit_date)
        self.days_held = (exit_dt - entry_dt).days


@dataclass
class BacktestConfig:
    """Backtest configuration"""
    start_date: str = "2024-01-01"
    end_date: str = "2024-12-31"
    initial_capital: float = 2000000
    max_positions: int = 10
    min_confidence: float = 0.55  # Only trade MODERATE or better
    risk_per_trade: float = 0.01  # 1% risk per trade
    use_daily_confirmation: bool = True
    max_days_to_confirm: int = 5  # Max days to wait for confirmation
    trailing_stop_atr_mult: float = 2.0  # Optional trailing stop
    max_hold_days: int = 60  # Max days to hold a trade


class BacktestEngine:
    """Main backtesting engine"""
    
    def __init__(self, config: BacktestConfig = None, scanner_config: ScannerConfig = None):
        self.config = config or BacktestConfig()
        self.scanner_config = scanner_config or ScannerConfig()
        self.scanner = WeeklyDailyScanner(self.scanner_config)
        
        # State tracking
        self.capital = self.config.initial_capital
        self.equity_curve = []
        self.open_positions: Dict[str, Trade] = {}
        self.closed_trades: List[Trade] = []
        self.pending_signals: List[Dict] = []
        
        # Performance tracking
        self.daily_returns = []
        self.equity_history = []
        
        # Statistics
        self.total_signals_generated = 0
        self.total_signals_confirmed = 0
        self.total_signals_expired = 0
        
    def run_backtest(self, symbols: List[str]) -> Dict[str, Any]:
        """
        Run the backtest across historical data
        
        Strategy:
        1. Walk forward week by week
        2. Run scanner at each week end
        3. Wait for daily confirmation
        4. Enter trades with position sizing
        5. Manage stops and targets
        6. Track performance
        """
        logger.info(f"Starting backtest from {self.config.start_date} to {self.config.end_date}")
        logger.info(f"Universe: {len(symbols)} symbols")
        logger.info(f"Initial capital: ₹{self.capital:,.0f}")
        
        # Fetch all historical data once with extended lookback
        # We need data FROM (start_date - buffer) TO end_date for backtesting
        start_date = pd.to_datetime(self.config.start_date)
        end_date = pd.to_datetime(self.config.end_date)
        
        # Extend lookback to get data before backtest start (for indicators)
        # Need at least 50 weeks (350 days) + buffer for MA calculations
        data_start = start_date - pd.Timedelta(days=400)  # ~14 months before for 50-week MA
        data_end = end_date
        
        logger.info(f"Fetching historical data from {data_start.date()} to {data_end.date()}...")
        logger.info(f"(Backtest period: {start_date.date()} to {end_date.date()})")
        
        # Calculate days needed
        days_needed = (data_end - data_start).days + 50  # Add buffer
        
        # Fetch data with custom date range
        all_data = self.scanner.data_fetcher.batch_fetch_data(
            symbols, 
            to_date=data_end.strftime('%Y-%m-%d'),
            lookback_days=days_needed
        )
        
        # Validate fetched data and ensure all data is timezone-naive
        valid_symbols = 0
        data_stats = []
        for symbol, df in all_data.items():
            if df is not None and not df.empty:
                # Ensure timezone-naive index
                if df.index.tz is not None:
                    df.index = df.index.tz_localize(None)
                    all_data[symbol] = df  # Update in place
                
                valid_symbols += 1
                data_stats.append({
                    'symbol': symbol,
                    'rows': len(df),
                    'start': df.index[0] if len(df) > 0 else None,
                    'end': df.index[-1] if len(df) > 0 else None
                })
        
        logger.info(f"✅ Data fetched: {valid_symbols}/{len(symbols)} symbols have data")
        if data_stats:
            avg_rows = np.mean([s['rows'] for s in data_stats])
            min_rows = min([s['rows'] for s in data_stats])
            max_rows = max([s['rows'] for s in data_stats])
            logger.info(f"   Data range: {min_rows}-{max_rows} rows (avg: {avg_rows:.0f})")
            
            # Find earliest and latest dates across all data
            earliest_start = min([s['start'] for s in data_stats])
            latest_end = max([s['end'] for s in data_stats])
            logger.info(f"   Date coverage: {earliest_start.date()} to {latest_end.date()}")
            
            # Calculate recommended backtest start (100 days after earliest data)
            recommended_start = earliest_start + pd.Timedelta(days=150)  # ~100 trading days
            logger.info(f"   ⚠️  Recommended backtest start: {recommended_start.date()} (allows 100+ bars)")
            
            # Show a few examples
            sample = sorted(data_stats, key=lambda x: x['rows'], reverse=True)[:3]
            for s in sample:
                logger.info(f"   Example: {s['symbol']} has {s['rows']} rows from {s['start'].date()} to {s['end'].date()}")
        
        # Fetch benchmark data for the scanner
        logger.info("Fetching benchmark data...")
        self.scanner.benchmark_data = self.scanner.data_fetcher.get_benchmark_data()
        
        # Ensure benchmark data is timezone-naive
        if self.scanner.benchmark_data is not None and not self.scanner.benchmark_data.empty:
            if self.scanner.benchmark_data.index.tz is not None:
                self.scanner.benchmark_data.index = self.scanner.benchmark_data.index.tz_localize(None)
        
        if self.scanner.benchmark_data is not None and not self.scanner.benchmark_data.empty:
            logger.info(f"✅ Benchmark data: {len(self.scanner.benchmark_data)} rows")
        else:
            logger.warning("⚠️  Benchmark data is empty or None!")
        
        # Prepare Nifty 50 data for market regime filter
        logger.info("Preparing Nifty 50 for market regime filter...")
        nifty_data = self.scanner.benchmark_data.copy()
        nifty_data['ma_50'] = nifty_data['close'].rolling(window=50).mean()
        logger.info(f"Nifty 50 MA50 calculated: {len(nifty_data)} rows")
        
        # Get date range
        start_date = pd.to_datetime(self.config.start_date)
        end_date = pd.to_datetime(self.config.end_date)
        
        # Create weekly periods
        current_date = start_date
        week_num = 0
        
        total_weeks = int((end_date - start_date).days / 7)
        logger.info(f"\n{'='*60}")
        logger.info(f"STARTING WEEK-BY-WEEK BACKTEST")
        logger.info(f"Total weeks to process: ~{total_weeks}")
        logger.info(f"{'='*60}\n")
        
        while current_date <= end_date:
            week_num += 1
            week_end = current_date + timedelta(days=6)
            
            if week_num % 10 == 0:
                logger.info(f"Processing week {week_num}: {current_date.date()}")
            
            # Step 1: Check open positions for exits
            self._check_exits(current_date, week_end, all_data)
            
            # Step 2: Check pending signals for confirmation
            self._check_confirmations(current_date, week_end, all_data)
            
            # Step 3: Run scanner for new signals (once per week)
            if len(self.open_positions) < self.config.max_positions:
                if week_num % 10 == 0:
                    logger.info(f"Running weekly scan for {len(symbols)} symbols on {week_end.date()}")
                
                new_signals = self._run_weekly_scan(week_end, symbols, all_data)
                
                if new_signals:
                    # POSITION ENTRY THROTTLE: Max 5 new positions per week to prevent cluster disasters
                    MAX_NEW_POSITIONS_PER_WEEK = 5
                    available_slots = self.config.max_positions - len(self.open_positions)
                    slots_this_week = min(MAX_NEW_POSITIONS_PER_WEEK, available_slots)
                    
                    # Sort by confidence and take top N
                    new_signals.sort(key=lambda x: x['confidence_score'], reverse=True)
                    signals_to_add = new_signals[:slots_this_week]
                    signals_skipped = len(new_signals) - len(signals_to_add)
                    
                    self.pending_signals.extend(signals_to_add)
                    
                    if week_num % 10 == 0:
                        logger.info(f"Added {len(signals_to_add)} signals (skipped {signals_skipped} to limit cluster risk)")
                elif week_num % 10 == 0:
                    logger.debug(f"No signals generated on {week_end.date()}")
            
            # Step 4: Track equity
            self._update_equity(current_date, all_data)
            
            # Move to next week
            current_date = week_end + timedelta(days=1)
        
        # Close any remaining open positions
        self._close_all_positions(end_date, all_data, "Backtest ended")
        
        # Log comprehensive statistics
        logger.info(f"\n{'='*60}")
        logger.info(f"BACKTEST COMPLETED - FINAL STATISTICS")
        logger.info(f"{'='*60}")
        logger.info(f"\n📊 Signal Flow:")
        logger.info(f"   Total signals generated: {self.total_signals_generated}")
        logger.info(f"   ├─ Confirmed & entered: {self.total_signals_confirmed}")
        logger.info(f"   ├─ Expired (no confirmation): {self.total_signals_expired}")
        logger.info(f"   └─ Pending: {len(self.pending_signals)}")
        logger.info(f"\n💼 Trade Statistics:")
        logger.info(f"   Total trades closed: {len(self.closed_trades)}")
        
        if self.closed_trades:
            winning = sum(1 for t in self.closed_trades if t.pnl > 0)
            losing = sum(1 for t in self.closed_trades if t.pnl <= 0)
            logger.info(f"   ├─ Winners: {winning}")
            logger.info(f"   └─ Losers: {losing}")
            
            # Show sample trades
            logger.info(f"\n   Sample trades:")
            for i, trade in enumerate(self.closed_trades[:5]):
                logger.info(f"      {i+1}. {trade.symbol}: ₹{trade.pnl:,.0f} ({trade.pnl_pct:.1f}%) - {trade.exit_reason}")
        
        logger.info(f"\n{'='*60}\n")
        
        # Calculate performance metrics
        results = self._calculate_performance()
        
        # Save results
        self._save_results(results)
        
        logger.info("Backtest completed!")
        return results
    
    def _run_weekly_scan(self, scan_date: pd.Timestamp, symbols: List[str], 
                        all_data: Dict) -> List[Dict]:
        """Run scanner on historical data up to scan_date"""
        signals = []
        processed_count = 0
        signal_count = 0
        confidence_scores = []  # Track all confidence scores
        skipped_no_data = 0
        skipped_insufficient_data = 0
        error_count = 0
        
        for symbol in symbols:
            # Skip if already in position
            if symbol in self.open_positions:
                continue
            
            if symbol not in all_data or all_data[symbol].empty:
                skipped_no_data += 1
                continue
            
            # Get data up to scan_date
            hist_data = all_data[symbol][all_data[symbol].index <= scan_date].copy()
            
            if len(hist_data) < 100:  # Need minimum data
                skipped_insufficient_data += 1
                continue
            
            try:
                # Process symbol (same as scanner does)
                result = self.scanner._process_symbol(symbol, hist_data, self.capital)
                processed_count += 1
                
                if result is None:
                    if processed_count <= 3:  # Log first few None results
                        logger.debug(f"  {symbol}: _process_symbol returned None")
                    continue
                
                # Extract signal info
                scoring = result.get('scoring_analysis', {}) or {}
                confidence = scoring.get('overall_confidence', 0)
                stage_analysis = result.get('stage_analysis', {}) or {}
                stage = stage_analysis.get('latest_stage', 'UNKNOWN')
                trade_setup = result.get('trade_setup', {}) or {}
                
                # Track confidence scores
                if confidence > 0:
                    confidence_scores.append(confidence)
                    # Log high confidence stocks
                    if confidence >= 0.70:
                        logger.info(f"  🌟 {symbol}: High confidence {confidence:.3f} ({stage})")
                
                # Check if signal meets criteria
                if confidence >= self.config.min_confidence:
                    signal_count += 1
                    # Good signal - add to pending
                    entry_info = trade_setup.get('entry', {}) or {}
                    stop_info = trade_setup.get('stop', {}) or {}
                    target_info = trade_setup.get('target', {}) or {}
                    position_info = trade_setup.get('position', {}) or {}
                    
                    signal = {
                        'symbol': symbol,
                        'signal_date': scan_date.strftime('%Y-%m-%d'),
                        'confidence_score': confidence,
                        'stage': stage,
                        'entry_price': entry_info.get('entry_price', 0),
                        'stop_price': stop_info.get('stop_price', 0),
                        'target_price': target_info.get('target_price', 0),
                        'position_size': position_info.get('position_size_shares', 0),
                        'risk_amount': position_info.get('risk_amount', 0),
                    }
                    
                    # Validate signal with detailed logging
                    validation_failed = []
                    if signal['entry_price'] <= 0:
                        validation_failed.append(f"entry={signal['entry_price']}")
                    if signal['stop_price'] <= 0:
                        validation_failed.append(f"stop={signal['stop_price']}")
                    if signal['position_size'] <= 0:
                        validation_failed.append(f"size={signal['position_size']}")
                    
                    if not validation_failed:
                        signals.append(signal)
                        logger.info(f"  ✅ SIGNAL: {symbol} conf={confidence:.3f} entry=₹{signal['entry_price']:.0f}")
                    else:
                        # LOG ALL VALIDATION FAILURES (not just first 5)
                        logger.warning(f"  ❌ {symbol}: Signal validation failed - {', '.join(validation_failed)}")
                        logger.debug(f"      trade_setup keys: {list(trade_setup.keys())}")
                        logger.debug(f"      entry_info: {entry_info}")
                        logger.debug(f"      stop_info: {stop_info}")
                        logger.debug(f"      target_info: {target_info}")
                        logger.debug(f"      position_info: {position_info}")
                        
            except Exception as e:
                error_count += 1
                if error_count <= 3:  # Log first few errors
                    logger.warning(f"Error scanning {symbol}: {e}")
                continue
        
        # Update statistics
        self.total_signals_generated += len(signals)
        
        # Summary logging
        total_attempted = len(symbols)
        logger.info(f"\n📊 Scan Summary for {scan_date.date()}:")
        logger.info(f"   Total symbols: {total_attempted}")
        logger.info(f"   ├─ No data: {skipped_no_data}")
        logger.info(f"   ├─ Insufficient data (<100 bars): {skipped_insufficient_data}")
        logger.info(f"   ├─ Processed successfully: {processed_count}")
        logger.info(f"   └─ Errors: {error_count}")
        
        # Confidence distribution
        if processed_count > 0 and confidence_scores:
            max_conf = max(confidence_scores)
            avg_conf = np.mean(confidence_scores)
            median_conf = np.median(confidence_scores)
            
            # Confidence buckets
            very_high = sum(1 for c in confidence_scores if c >= 0.75)
            high = sum(1 for c in confidence_scores if 0.60 <= c < 0.75)
            moderate = sum(1 for c in confidence_scores if 0.45 <= c < 0.60)
            low = sum(1 for c in confidence_scores if c < 0.45)
            
            logger.info(f"\n   📈 Confidence Distribution:")
            logger.info(f"      Avg: {avg_conf:.3f} | Median: {median_conf:.3f} | Max: {max_conf:.3f}")
            logger.info(f"      ├─ Very High (≥0.75): {very_high}")
            logger.info(f"      ├─ High (0.60-0.75): {high}")
            logger.info(f"      ├─ Moderate (0.45-0.60): {moderate}")
            logger.info(f"      └─ Low (<0.45): {low}")
            logger.info(f"\n   🎯 Above threshold ({self.config.min_confidence}): {signal_count} candidates")
            logger.info(f"   ✅ Valid signals generated: {len(signals)}")
            
            if signal_count > 0 and len(signals) == 0:
                logger.warning(f"   ⚠️  {signal_count} candidates but 0 valid signals - check trade setup validation!")
        elif processed_count > 0:
            logger.warning(f"   ⚠️  Processed {processed_count} symbols but NO confidence scores > 0!")
        else:
            logger.warning(f"   ⚠️  No symbols were successfully processed!")
        
        if signals:
            # Sort by confidence and take top opportunities
            signals.sort(key=lambda x: x['confidence_score'], reverse=True)
            logger.info(f"✅ Generated {len(signals)} valid signals on {scan_date.date()} (Top: {signals[0]['symbol']} @ {signals[0]['confidence_score']:.2f})")
        
        return signals
    
    def _check_confirmations(self, start_date: pd.Timestamp, end_date: pd.Timestamp,
                            all_data: Dict):
        """Check pending signals for daily confirmation and enter trades"""
        confirmed_indices = []
        
        for idx, signal in enumerate(self.pending_signals):
            symbol = signal['symbol']
            signal_date = pd.to_datetime(signal['signal_date'])
            
            # Check if signal is too old
            days_waiting = (end_date - signal_date).days
            if days_waiting > self.config.max_days_to_confirm:
                confirmed_indices.append(idx)  # Remove expired signal
                self.total_signals_expired += 1
                continue
            
            # Skip if no data
            if symbol not in all_data:
                continue
            
            # Get daily data after signal
            daily_data = all_data[symbol]
            after_signal = daily_data[daily_data.index > signal_date]
            this_week = after_signal[after_signal.index <= end_date]
            
            if this_week.empty:
                continue
            
            # Check for confirmation (price above entry with volume)
            entry_price = signal['entry_price']
            
            for date, row in this_week.iterrows():
                # Confirmation: high >= entry_price with decent volume
                if row['high'] >= entry_price:
                    # Enter trade
                    actual_entry = max(entry_price, row['open'])  # Realistic entry
                    
                    # Check if we have capital
                    position_value = actual_entry * signal['position_size']
                    if position_value > self.capital * 0.15:  # Max 15% per position
                        signal['position_size'] = int((self.capital * 0.15) / actual_entry)
                        position_value = actual_entry * signal['position_size']
                    
                    if position_value > self.capital * 0.9:  # Keep some cash
                        continue
                    
                    # Create trade
                    trade = Trade(
                        symbol=symbol,
                        entry_date=date.strftime('%Y-%m-%d'),
                        entry_price=actual_entry,
                        stop_price=signal['stop_price'],
                        target_price=signal['target_price'],
                        position_size=signal['position_size'],
                        position_value=position_value,
                        risk_amount=signal['risk_amount'],
                        signal_date=signal['signal_date'],
                        confidence_score=signal['confidence_score'],
                        stage=signal['stage']
                    )
                    
                    # Add to open positions
                    self.open_positions[symbol] = trade
                    self.capital -= position_value
                    self.total_signals_confirmed += 1
                    
                    logger.info(f"ENTRY: {symbol} @ Rs.{actual_entry:.2f} on {date.date()} "
                              f"(Conf: {signal['confidence_score']:.2f}, Stage: {signal['stage']}, "
                              f"Stop: Rs.{trade.stop_price:.2f}, Target: Rs.{trade.target_price:.2f})")
                    
                    confirmed_indices.append(idx)
                    break
        
        # Remove confirmed/expired signals
        for idx in sorted(confirmed_indices, reverse=True):
            self.pending_signals.pop(idx)
    
    def _check_exits(self, start_date: pd.Timestamp, end_date: pd.Timestamp, 
                    all_data: Dict):
        """Check open positions for stop/target hits with FIXED 10% STOP LOSS"""
        symbols_to_close = []
        
        for symbol, trade in self.open_positions.items():
            if symbol not in all_data:
                continue
            
            # Get daily data for this period
            daily_data = all_data[symbol]
            entry_date = pd.to_datetime(trade.entry_date)
            period_data = daily_data[(daily_data.index > entry_date) & 
                                    (daily_data.index <= end_date)]
            
            if period_data.empty:
                continue
            
            # FIXED 10% STOP LOSS from entry price
            stop_loss_price = trade.entry_price * 0.90  # 10% below entry
            
            # Check each day for exits
            for date, row in period_data.iterrows():
                exit_price = None
                exit_reason = None
                
                # Check 10% stop loss hit
                if row['low'] <= stop_loss_price:
                    exit_price = stop_loss_price
                    exit_reason = "Stop Loss (10%)"
                
                # Check target hit
                elif row['high'] >= trade.target_price:
                    exit_price = trade.target_price
                    exit_reason = "Target Hit"
                
                # Check max hold period
                elif (date - entry_date).days >= self.config.max_hold_days:
                    exit_price = row['close']
                    exit_reason = "Max Hold Period"
                
                # Exit if triggered
                if exit_price:
                    trade.close_trade(date.strftime('%Y-%m-%d'), exit_price, exit_reason)
                    self.closed_trades.append(trade)
                    self.capital += exit_price * trade.position_size
                    symbols_to_close.append(symbol)
                    
                    profit_emoji = "WIN" if trade.pnl > 0 else "LOSS"
                    logger.info(f"{profit_emoji}: {symbol} @ Rs.{exit_price:.2f} on {date.date()} "
                              f"- {exit_reason} - P&L: Rs.{trade.pnl:,.0f} ({trade.pnl_pct:.1f}%) "
                              f"[{trade.return_r:.2f}R in {trade.days_held} days]")
                    break
        
        # Remove closed positions
        for symbol in symbols_to_close:
            del self.open_positions[symbol]
    
    def _close_all_positions(self, close_date: pd.Timestamp, all_data: Dict, reason: str):
        """Close all remaining open positions"""
        for symbol, trade in list(self.open_positions.items()):
            if symbol in all_data:
                # Get last available price
                daily_data = all_data[symbol]
                available_data = daily_data[daily_data.index <= close_date]
                if not available_data.empty:
                    last_price = available_data.iloc[-1]['close']
                    last_date = available_data.index[-1]
                    
                    trade.close_trade(last_date.strftime('%Y-%m-%d'), last_price, reason)
                    self.closed_trades.append(trade)
                    self.capital += last_price * trade.position_size
        
        self.open_positions.clear()
    
    def _update_equity(self, date: pd.Timestamp, all_data: Dict):
        """Update equity curve"""
        # Calculate total equity (cash + open positions)
        total_equity = self.capital
        
        for symbol, trade in self.open_positions.items():
            if symbol in all_data:
                daily_data = all_data[symbol]
                current_data = daily_data[daily_data.index <= date]
                if not current_data.empty:
                    current_price = current_data.iloc[-1]['close']
                    total_equity += current_price * trade.position_size
        
        self.equity_history.append({
            'date': date.strftime('%Y-%m-%d'),
            'equity': total_equity,
            'cash': self.capital,
            'open_positions': len(self.open_positions)
        })
    
    def _calculate_performance(self) -> Dict[str, Any]:
        """Calculate comprehensive performance metrics"""
        if not self.closed_trades:
            logger.warning("No trades executed in backtest")
            # Return basic structure even with no trades
            return {
                'backtest_config': asdict(self.config),
                'summary': {
                    'initial_capital': self.config.initial_capital,
                    'final_equity': self.capital,
                    'total_return': 0,
                    'total_return_pct': 0,
                    'max_drawdown_pct': 0,
                },
                'trade_stats': {
                    'total_trades': 0,
                    'winning_trades': 0,
                    'losing_trades': 0,
                    'win_rate_pct': 0,
                    'avg_win': 0,
                    'avg_loss': 0,
                    'win_loss_ratio': 0,
                    'avg_r_multiple': 0,
                    'expectancy': 0,
                    'avg_days_held': 0,
                },
                'risk_metrics': {
                    'sharpe_ratio': 0,
                    'max_drawdown_pct': 0,
                },
                'trades': [],
                'equity_curve': []
            }
        
        # Convert to DataFrame
        trades_df = pd.DataFrame([t.to_dict() for t in self.closed_trades])
        equity_df = pd.DataFrame(self.equity_history)
        
        # Basic stats
        total_trades = len(trades_df)
        winning_trades = trades_df[trades_df['pnl'] > 0]
        losing_trades = trades_df[trades_df['pnl'] <= 0]
        
        win_rate = len(winning_trades) / total_trades * 100 if total_trades > 0 else 0
        
        # P&L stats
        total_pnl = trades_df['pnl'].sum()
        avg_win = winning_trades['pnl'].mean() if len(winning_trades) > 0 else 0
        avg_loss = losing_trades['pnl'].mean() if len(losing_trades) > 0 else 0
        
        # Returns
        final_equity = equity_df['equity'].iloc[-1]
        total_return_pct = ((final_equity - self.config.initial_capital) / 
                           self.config.initial_capital * 100)
        
        # Risk-adjusted metrics
        avg_r_multiple = trades_df['return_r'].mean()
        
        # Calculate Sharpe (simplified - using trade returns)
        trade_returns = trades_df['pnl_pct'].values
        if len(trade_returns) > 1:
            sharpe_ratio = (trade_returns.mean() / trade_returns.std()) * np.sqrt(52)  # Annualized
        else:
            sharpe_ratio = 0
        
        # Max drawdown
        equity_curve = equity_df['equity'].values
        running_max = np.maximum.accumulate(equity_curve)
        drawdown = (equity_curve - running_max) / running_max * 100
        max_drawdown = drawdown.min()
        
        # Time stats
        avg_days_held = trades_df['days_held'].mean()
        
        # Win/Loss ratio
        win_loss_ratio = abs(avg_win / avg_loss) if avg_loss != 0 else 0
        
        # Expectancy
        expectancy = (win_rate/100 * avg_win) + ((100-win_rate)/100 * avg_loss)
        
        results = {
            'backtest_config': asdict(self.config),
            'summary': {
                'initial_capital': self.config.initial_capital,
                'final_equity': final_equity,
                'total_return': total_pnl,
                'total_return_pct': total_return_pct,
                'max_drawdown_pct': max_drawdown,
            },
            'trade_stats': {
                'total_trades': total_trades,
                'winning_trades': len(winning_trades),
                'losing_trades': len(losing_trades),
                'win_rate_pct': win_rate,
                'avg_win': avg_win,
                'avg_loss': avg_loss,
                'win_loss_ratio': win_loss_ratio,
                'avg_r_multiple': avg_r_multiple,
                'expectancy': expectancy,
                'avg_days_held': avg_days_held,
            },
            'risk_metrics': {
                'sharpe_ratio': sharpe_ratio,
                'max_drawdown_pct': max_drawdown,
            },
            'trades': trades_df.to_dict('records'),
            'equity_curve': equity_df.to_dict('records')
        }
        
        return results
    
    def _save_results(self, results: Dict):
        """Save backtest results"""
        output_dir = Path("output/backtests")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Save summary
        summary_file = output_dir / f"backtest_summary_{timestamp}.json"
        summary = {
            'backtest_config': results['backtest_config'],
            'summary': results['summary'],
            'trade_stats': results['trade_stats'],
            'risk_metrics': results['risk_metrics']
        }
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)
        
        logger.info(f"Summary saved to {summary_file}")
        
        # Save trades
        if results.get('trades'):
            trades_df = pd.DataFrame(results['trades'])
            trades_file = output_dir / f"backtest_trades_{timestamp}.csv"
            trades_df.to_csv(trades_file, index=False)
            logger.info(f"Trades saved to {trades_file}")
        
        # Save equity curve
        if results.get('equity_curve'):
            equity_df = pd.DataFrame(results['equity_curve'])
            equity_file = output_dir / f"backtest_equity_{timestamp}.csv"
            equity_df.to_csv(equity_file, index=False)
            logger.info(f"Equity curve saved to {equity_file}")
        
        self._print_summary(results)
    
    def _print_summary(self, results: Dict):
        """Print backtest summary"""
        print("\n" + "="*60)
        print("BACKTEST SUMMARY")
        print("="*60)
        
        summary = results['summary']
        stats = results['trade_stats']
        risk = results['risk_metrics']
        
        print(f"\nPERFORMANCE")
        print(f"   Initial Capital:     Rs.{summary['initial_capital']:,.0f}")
        print(f"   Final Equity:        Rs.{summary['final_equity']:,.0f}")
        print(f"   Total Return:        Rs.{summary['total_return']:,.0f} ({summary['total_return_pct']:.2f}%)")
        print(f"   Max Drawdown:        {summary['max_drawdown_pct']:.2f}%")
        
        print(f"\nTRADE STATISTICS")
        print(f"   Total Trades:        {stats['total_trades']}")
        print(f"   Winning Trades:      {stats['winning_trades']}")
        print(f"   Losing Trades:       {stats['losing_trades']}")
        print(f"   Win Rate:            {stats['win_rate_pct']:.1f}%")
        print(f"   Avg Win:             Rs.{stats['avg_win']:,.0f}")
        print(f"   Avg Loss:            Rs.{stats['avg_loss']:,.0f}")
        print(f"   Win/Loss Ratio:      {stats['win_loss_ratio']:.2f}")
        print(f"   Avg R-Multiple:      {stats['avg_r_multiple']:.2f}R")
        print(f"   Expectancy:          Rs.{stats['expectancy']:,.0f}")
        print(f"   Avg Days Held:       {stats['avg_days_held']:.1f}")
        
        print(f"\nRISK METRICS")
        print(f"   Sharpe Ratio:        {risk['sharpe_ratio']:.2f}")
        print(f"   Max Drawdown:        {risk['max_drawdown_pct']:.2f}%")
        
        print("\n" + "="*60 + "\n")


def main():
    """Run backtest"""
    print("Weekly->Daily Scanner - Backtest Engine")
    print("="*60)
    
    # Configure backtest
    # NOTE: Start date should be ~6 months after data begins to ensure 100+ bars available
    backtest_config = BacktestConfig(
        start_date="2023-01-01",  # Full bull market + correction cycle
        end_date="2024-10-25",
        initial_capital=2000000,
        max_positions=10,
        min_confidence=0.50,  # Lower threshold for more signals (MODERATE+)
        risk_per_trade=0.01,
        use_daily_confirmation=True,
        max_days_to_confirm=10,  # Give more time for confirmation
        max_hold_days=90  # Longer hold period
    )
    
    print(f"\nBacktest Configuration:")
    print(f"   Period: {backtest_config.start_date} to {backtest_config.end_date}")
    print(f"   Capital: Rs.{backtest_config.initial_capital:,.0f}")
    print(f"   Min Confidence: {backtest_config.min_confidence}")
    print(f"   Max Positions: {backtest_config.max_positions}")
    print(f"   Max Hold Days: {backtest_config.max_hold_days}\n")
    
    # Read symbols
    symbols_file = "data/Nifty-500-stocks.csv"
    try:
        symbols_df = pd.read_csv(symbols_file)
        # Use all symbols for comprehensive backtest
        symbols = symbols_df['Symbol'].tolist()
        print(f"Loaded {len(symbols)} symbols from {symbols_file}")
    except Exception as e:
        print(f"Error reading symbols: {e}")
        return
    
    # Run backtest
    engine = BacktestEngine(backtest_config)
    results = engine.run_backtest(symbols)


if __name__ == "__main__":
    main()

