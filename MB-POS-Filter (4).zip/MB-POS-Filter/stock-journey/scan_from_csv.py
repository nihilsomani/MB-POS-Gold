"""
Scan from CSV File
Flexible script to scan symbols from MCAP-great2500.csv with customizable parameters
"""

from weekly_daily_scanner import WeeklyDailyScanner
import pandas as pd
import logging
import argparse
import sys

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def load_symbols_from_csv(csv_file, max_symbols=None, start_index=0):
    """Load symbols from CSV file with optional limits"""
    try:
        symbols_df = pd.read_csv(csv_file)
        symbols = symbols_df['Symbol'].tolist()
        
        # Apply limits if specified
        if max_symbols:
            symbols = symbols[start_index:start_index + max_symbols]
        
        print(f"✅ Loaded {len(symbols)} symbols from {csv_file}")
        if max_symbols:
            print(f"   (Symbols {start_index+1} to {start_index + len(symbols)} from total {len(symbols_df)} symbols)")
        
        return symbols
        
    except Exception as e:
        print(f"❌ Error reading symbols from {csv_file}: {e}")
        return None

def main():
    """Main function with command line arguments"""
    parser = argparse.ArgumentParser(description='Scan symbols from CSV file')
    parser.add_argument('--csv', default='data/MCAP-great2500.csv', 
                       help='Path to CSV file with symbols (default: data/MCAP-great2500.csv)')
    parser.add_argument('--max-symbols', type=int, default=50,
                       help='Maximum number of symbols to scan (default: 50)')
    parser.add_argument('--start-index', type=int, default=0,
                       help='Starting index in the CSV (default: 0)')
    parser.add_argument('--capital', type=float, default=100000,
                       help='Account capital for position sizing (default: 100000)')
    parser.add_argument('--quick', action='store_true',
                       help='Run quick scan instead of full scan')
    parser.add_argument('--min-confidence', type=float, default=0.5,
                       help='Minimum confidence score for quick scan (default: 0.5)')
    
    args = parser.parse_args()
    
    print("🚀 Weekly→Daily Scanner - CSV Symbol Scan")
    print("=" * 60)
    
    # Load symbols from CSV
    symbols = load_symbols_from_csv(args.csv, args.max_symbols, args.start_index)
    if not symbols:
        print("❌ Failed to load symbols. Exiting.")
        return
    
    # Initialize scanner
    print("\n📊 Initializing scanner...")
    scanner = WeeklyDailyScanner()
    
    # Validate configuration
    validation = scanner.validate_configuration()
    if not validation['valid']:
        print(f"❌ Configuration issues: {validation['issues']}")
        return
    
    print("✅ Scanner initialized successfully!")
    
    print(f"\n🔍 Scanning {len(symbols)} symbols...")
    print(f"💰 Account Capital: ₹{args.capital:,}")
    
    if args.quick:
        # Run quick scan
        print("\n⚡ Running quick scan...")
        results = scanner.run_quick_scan(symbols, min_confidence=args.min_confidence)
        
        if not results.empty:
            print(f"\n✅ Quick scan completed! Found {len(results)} candidates")
            print("\n📈 Quick Scan Results:")
            print(results[['symbol', 'stage', 'confidence_score', 'confidence_level']].to_string(index=False))
            
            # Show top candidates
            top_candidates = results.head(5)
            print(f"\n🏆 Top 5 Candidates:")
            for _, row in top_candidates.iterrows():
                print(f"   {row['symbol']}: {row['stage']} (Score: {row['confidence_score']:.3f})")
        else:
            print("❌ No candidates found in quick scan")
    
    else:
        # Run full scan
        print("\n⚡ Running full detailed scan...")
        print("This may take several minutes...")
        
        results = scanner.run_full_scan(symbols, account_capital=args.capital)
        
        if results['success']:
            print(f"\n✅ Scan completed successfully!")
            print(f"📊 Processed {results['processed_symbols']} out of {results['total_symbols']} symbols")
            
            # Get the output dataframe
            output_df = results['output_dataframe']
            
            if not output_df.empty:
                print(f"\n📈 Found {len(output_df)} candidates with data")
                
                # Show summary by stage
                stage_summary = output_df['label'].value_counts()
                print(f"\n📊 Stage Breakdown:")
                for stage, count in stage_summary.items():
                    print(f"   {stage}: {count} symbols")
                
                # Show confidence levels
                confidence_summary = output_df['confidence_level'].value_counts()
                print(f"\n🎯 Confidence Levels:")
                for level, count in confidence_summary.items():
                    print(f"   {level}: {count} symbols")
                
                # Show top candidates
                print(f"\n🏆 Top 10 Candidates:")
                top_candidates = output_df.head(10)
                display_cols = ['symbol', 'label', 'confidence_score', 'confidence_level', 'recommendation']
                print(top_candidates[display_cols].to_string(index=False))
                
                # Show confirmed breakouts
                confirmed = output_df[output_df['daily_confirmed'] == True]
                if not confirmed.empty:
                    print(f"\n✅ Confirmed Breakouts ({len(confirmed)}):")
                    print(confirmed[['symbol', 'confidence_score', 'entry_suggested', 'stop_suggested', 'target_suggested']].to_string(index=False))
                
                # Export results
                output_file = scanner.export_results()
                print(f"\n💾 Results exported to: {output_file}")
                
                # Show scan summary
                scan_summary = results['scan_summary']
                print(f"\n⏱️ Scan Summary:")
                print(f"   Duration: {scan_summary['scan_timing']['duration_minutes']:.1f} minutes")
                print(f"   Data Quality: {scan_summary['data_quality']['data_completeness']*100:.1f}%")
                
            else:
                print("❌ No data returned from scan")
        
        else:
            print(f"❌ Scan failed: {results['error']}")
    
    print(f"\n🎉 Scan completed!")

if __name__ == "__main__":
    main()
