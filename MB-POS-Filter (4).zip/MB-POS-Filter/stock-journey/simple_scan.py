"""
Simple Scanner for 1000+ Symbols
Uses NSE instrument cache and 1-second delay between calls - no rocket science!
"""

from weekly_daily_scanner import WeeklyDailyScanner
import pandas as pd
import logging
import time
from datetime import datetime

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    """Simple scan for all symbols in CSV"""
    print("🚀 Simple Scanner for 1000+ Symbols")
    print("=" * 50)
    print("Using NSE instrument cache + 0.35-second delay between calls")
    print("=" * 50)
    
    # Load all symbols from CSV
    symbols_file = "data/MCAP-great2500.csv"
    try:
        symbols_df = pd.read_csv(symbols_file)
        symbols = symbols_df['Symbol'].tolist()
        print(f"✅ Loaded {len(symbols)} symbols from {symbols_file}")
        print(f"⏱️  Estimated time: {len(symbols) * 0.35:.0f} seconds ({len(symbols) * 0.35 / 60:.1f} minutes)")
    except Exception as e:
        print(f"❌ Error reading symbols: {e}")
        return
    
    # Initialize scanner
    print("\n📊 Initializing scanner...")
    scanner = WeeklyDailyScanner()
    
    # Validate configuration
    validation = scanner.validate_configuration()
    if not validation['valid']:
        print(f"❌ Configuration issues: {validation['issues']}")
        return
    
    print("✅ Scanner initialized successfully!")
    
    # Start timing
    start_time = time.time()
    
    # Run full scan
    print(f"\n⚡ Starting scan for {len(symbols)} symbols...")
    print("Progress will be shown every 50 symbols...")
    
    results = scanner.run_full_scan(symbols, account_capital=100000)
    
    # Calculate actual time
    end_time = time.time()
    actual_duration = (end_time - start_time) / 60
    
    if results['success']:
        print(f"\n✅ Scan completed successfully!")
        print(f"📊 Processed {results['processed_symbols']} out of {results['total_symbols']} symbols")
        print(f"⏱️  Actual duration: {actual_duration:.1f} minutes")
        
        # Get the output dataframe
        output_df = results['output_dataframe']
        
        if not output_df.empty:
            print(f"\n📈 Found {len(output_df)} candidates with data")
            
            # Show summary by stage
            stage_summary = output_df['label'].value_counts()
            print(f"\n📊 Stage Breakdown:")
            for stage, count in stage_summary.items():
                print(f"   {stage}: {count} symbols")
            
            # Show confidence levels
            confidence_summary = output_df['confidence_level'].value_counts()
            print(f"\n🎯 Confidence Levels:")
            for level, count in confidence_summary.items():
                print(f"   {level}: {count} symbols")
            
            # Show top candidates
            print(f"\n🏆 Top 20 Candidates:")
            top_candidates = output_df.head(20)
            display_cols = ['symbol', 'label', 'confidence_score', 'confidence_level', 'recommendation']
            print(top_candidates[display_cols].to_string(index=False))
            
            # Show confirmed breakouts
            confirmed = output_df[output_df['daily_confirmed'] == True]
            if not confirmed.empty:
                print(f"\n✅ Confirmed Breakouts ({len(confirmed)}):")
                print(confirmed[['symbol', 'confidence_score', 'entry_suggested', 'stop_suggested', 'target_suggested']].to_string(index=False))
            
            # Export results
            output_file = scanner.export_results()
            print(f"\n💾 Results exported to: {output_file}")
            
        else:
            print("❌ No data returned from scan")
    
    else:
        print(f"❌ Scan failed: {results['error']}")
    
    print(f"\n🎉 Simple scan completed!")

if __name__ == "__main__":
    main()
