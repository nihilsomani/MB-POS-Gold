"""
Large Scale Scanner
Optimized for scanning 1000+ symbols with proper rate limiting and progress tracking
"""

from weekly_daily_scanner import WeeklyDailyScanner
import pandas as pd
import logging
import time
from datetime import datetime
import argparse

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def estimate_scan_time(num_symbols, batch_size=20):
    """Estimate scan time based on symbol count"""
    # Each symbol takes ~0.4 seconds due to rate limiting
    # Plus 2 seconds delay between batches
    symbols_per_batch = batch_size
    num_batches = (num_symbols + symbols_per_batch - 1) // symbols_per_batch
    
    time_per_symbol = 0.4  # seconds
    time_per_batch_delay = 2  # seconds
    
    total_time = (num_symbols * time_per_symbol) + ((num_batches - 1) * time_per_batch_delay)
    return total_time / 60  # return in minutes

def main():
    """Main function for large scale scanning"""
    parser = argparse.ArgumentParser(description='Large Scale Scanner for 1000+ symbols')
    parser.add_argument('--csv', default='data/MCAP-great2500.csv', 
                       help='Path to CSV file with symbols')
    parser.add_argument('--max-symbols', type=int, default=None,
                       help='Maximum number of symbols to scan (default: all)')
    parser.add_argument('--start-index', type=int, default=0,
                       help='Starting index in the CSV (default: 0)')
    parser.add_argument('--capital', type=float, default=100000,
                       help='Account capital for position sizing')
    parser.add_argument('--batch-size', type=int, default=20,
                       help='Batch size for processing (default: 20)')
    parser.add_argument('--quick', action='store_true',
                       help='Run quick scan instead of full scan')
    parser.add_argument('--min-confidence', type=float, default=0.5,
                       help='Minimum confidence score for quick scan')
    
    args = parser.parse_args()
    
    print("🚀 Large Scale Weekly→Daily Scanner")
    print("=" * 60)
    
    # Load symbols from CSV
    try:
        symbols_df = pd.read_csv(args.csv)
        all_symbols = symbols_df['Symbol'].tolist()
        
        # Apply limits
        if args.max_symbols:
            symbols = all_symbols[args.start_index:args.start_index + args.max_symbols]
        else:
            symbols = all_symbols[args.start_index:]
        
        print(f"✅ Loaded {len(symbols)} symbols from {args.csv}")
        print(f"   (Symbols {args.start_index+1} to {args.start_index + len(symbols)} from total {len(all_symbols)} symbols)")
        
        # Estimate time
        estimated_time = estimate_scan_time(len(symbols), args.batch_size)
        print(f"⏱️  Estimated scan time: {estimated_time:.1f} minutes")
        
    except Exception as e:
        print(f"❌ Error reading symbols from {args.csv}: {e}")
        return
    
    # Initialize scanner
    print("\n📊 Initializing scanner...")
    scanner = WeeklyDailyScanner()
    
    # Validate configuration
    validation = scanner.validate_configuration()
    if not validation['valid']:
        print(f"❌ Configuration issues: {validation['issues']}")
        return
    
    print("✅ Scanner initialized successfully!")
    
    # Start timing
    start_time = time.time()
    
    if args.quick:
        # Run quick scan
        print(f"\n⚡ Running quick scan for {len(symbols)} symbols...")
        print("This will take several minutes due to rate limiting...")
        
        results = scanner.run_quick_scan(symbols, min_confidence=args.min_confidence)
        
        if not results.empty:
            print(f"\n✅ Quick scan completed! Found {len(results)} candidates")
            print("\n📈 Quick Scan Results:")
            print(results[['symbol', 'stage', 'confidence_score', 'confidence_level']].to_string(index=False))
            
            # Show top candidates
            top_candidates = results.head(10)
            print(f"\n🏆 Top 10 Candidates:")
            for _, row in top_candidates.iterrows():
                print(f"   {row['symbol']}: {row['stage']} (Score: {row['confidence_score']:.3f})")
        else:
            print("❌ No candidates found in quick scan")
    
    else:
        # Run full scan
        print(f"\n⚡ Running full detailed scan for {len(symbols)} symbols...")
        print("This will take a significant amount of time due to rate limiting...")
        print("Progress will be shown in the logs...")
        
        results = scanner.run_full_scan(symbols, account_capital=args.capital)
        
        if results['success']:
            print(f"\n✅ Scan completed successfully!")
            print(f"📊 Processed {results['processed_symbols']} out of {results['total_symbols']} symbols")
            
            # Get the output dataframe
            output_df = results['output_dataframe']
            
            if not output_df.empty:
                print(f"\n📈 Found {len(output_df)} candidates with data")
                
                # Show summary by stage
                stage_summary = output_df['label'].value_counts()
                print(f"\n📊 Stage Breakdown:")
                for stage, count in stage_summary.items():
                    print(f"   {stage}: {count} symbols")
                
                # Show confidence levels
                confidence_summary = output_df['confidence_level'].value_counts()
                print(f"\n🎯 Confidence Levels:")
                for level, count in confidence_summary.items():
                    print(f"   {level}: {count} symbols")
                
                # Show top candidates
                print(f"\n🏆 Top 20 Candidates:")
                top_candidates = output_df.head(20)
                display_cols = ['symbol', 'label', 'confidence_score', 'confidence_level', 'recommendation']
                print(top_candidates[display_cols].to_string(index=False))
                
                # Show confirmed breakouts
                confirmed = output_df[output_df['daily_confirmed'] == True]
                if not confirmed.empty:
                    print(f"\n✅ Confirmed Breakouts ({len(confirmed)}):")
                    print(confirmed[['symbol', 'confidence_score', 'entry_suggested', 'stop_suggested', 'target_suggested']].to_string(index=False))
                
                # Export results
                output_file = scanner.export_results()
                print(f"\n💾 Results exported to: {output_file}")
                
                # Show scan summary
                scan_summary = results['scan_summary']
                print(f"\n⏱️ Scan Summary:")
                print(f"   Duration: {scan_summary['scan_timing']['duration_minutes']:.1f} minutes")
                print(f"   Data Quality: {scan_summary['data_quality']['data_completeness']*100:.1f}%")
                
            else:
                print("❌ No data returned from scan")
        
        else:
            print(f"❌ Scan failed: {results['error']}")
    
    # Final timing
    end_time = time.time()
    actual_duration = (end_time - start_time) / 60
    print(f"\n⏱️  Actual scan duration: {actual_duration:.1f} minutes")
    print(f"🎉 Large scale scan completed!")

if __name__ == "__main__":
    main()
