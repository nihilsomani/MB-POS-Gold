"""
CSV Output Generator
Creates comprehensive CSV output with all required fields and analysis
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Any
import logging
from datetime import datetime
from pathlib import Path

from config import config, STAGE_LABELS

logger = logging.getLogger(__name__)

class CSVOutputGenerator:
    """Generates comprehensive CSV output for scanner results"""
    
    def __init__(self, config_obj=None):
        self.config = config_obj or config
    
    def create_scanner_output(self, scanner_results: Dict[str, Dict[str, Any]]) -> pd.DataFrame:
        """
        Create comprehensive scanner output CSV
        
        Required columns:
        - symbol, last_week_end, label, confidence_score
        - weekly OHLCV data
        - technical indicators (MA, ATR, range metrics)
        - volume and RS metrics
        - breakout levels and entry/stop/target
        - position sizing and notes
        """
        if not scanner_results:
            return pd.DataFrame()
        
        output_rows = []
        
        for symbol, data in scanner_results.items():
            try:
                row = self._create_symbol_row(symbol, data)
                if row:
                    output_rows.append(row)
            except Exception as e:
                logger.error(f"Error processing {symbol}: {e}")
                continue
        
        if not output_rows:
            logger.warning("No valid data to output")
            return pd.DataFrame()
        
        df = pd.DataFrame(output_rows)
        
        # FILTER: Only show tradeable stages (UPTREND_CONT and BASE_BREAKOUT)
        # Other stages (downtrends, consolidations) are not actionable
        if 'label' in df.columns:
            tradeable_stages = ['UPTREND_CONT', 'BASE_BREAKOUT']
            before_filter = len(df)
            df = df[df['label'].isin(tradeable_stages)]
            after_filter = len(df)
            
            if before_filter > after_filter:
                logger.info(f"Filtered to tradeable stages: {after_filter}/{before_filter} stocks (removed {before_filter - after_filter} non-tradeable)")
        
        # Sort by confidence score descending
        if 'confidence_score' in df.columns:
            df = df.sort_values('confidence_score', ascending=False)
        
        return df
    
    def _create_symbol_row(self, symbol: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create a single row for a symbol"""
        try:
            # Extract weekly data
            weekly_data = data.get('weekly_data', pd.DataFrame())
            if weekly_data.empty:
                return None
            
            latest_weekly = weekly_data.iloc[-1]
            
            # Safety check - ensure latest_weekly is not None
            if latest_weekly is None:
                logger.warning(f"No weekly data for {symbol}")
                return None
            
            # Extract daily data
            daily_data = data.get('daily_data', pd.DataFrame())
            
            # Extract analysis results with safe defaults
            stage_analysis = data.get('stage_analysis', {}) or {}
            scoring_analysis = data.get('scoring_analysis', {}) or {}
            confirmation_analysis = data.get('confirmation_analysis', {}) or {}
            trade_setup = data.get('trade_setup', {}) or {}
            
            # Basic symbol info
            row = {
                'symbol': symbol,
                'last_week_end': latest_weekly.name.strftime('%Y-%m-%d') if hasattr(latest_weekly.name, 'strftime') else str(latest_weekly.name),
                'label': stage_analysis.get('latest_stage', 'UNKNOWN'),
                'stage_label': STAGE_LABELS.get(stage_analysis.get('latest_stage', 'UNKNOWN'), 'Unknown'),
                'confidence_score': scoring_analysis.get('overall_confidence', 0.0),
                'confidence_level': scoring_analysis.get('confidence_level', 'IGNORE')
            }
            
            # Weekly OHLCV data
            row.update({
                'weekly_close': latest_weekly.get('close', 0.0),
                'weekly_open': latest_weekly.get('open', 0.0),
                'weekly_high': latest_weekly.get('high', 0.0),
                'weekly_low': latest_weekly.get('low', 0.0),
                'weekly_volume': latest_weekly.get('volume', 0),
                'weekly_vwap': latest_weekly.get('vwap_week', 0.0)
            })
            
            # Technical indicators
            row.update({
                f'ma_short_{self.config.MA_SHORT_WEEKS}w': latest_weekly.get(f'ma_short_{self.config.MA_SHORT_WEEKS}w', 0.0),
                f'ma_long_{self.config.MA_LONG_WEEKS}w': latest_weekly.get(f'ma_long_{self.config.MA_LONG_WEEKS}w', 0.0),
                f'ma_trend_{self.config.MA_TREND_WEEKS}w': latest_weekly.get(f'ma_trend_{self.config.MA_TREND_WEEKS}w', 0.0),
                'ma_slope': latest_weekly.get('ma_slope', 0.0),
                f'atr_{self.config.ATR_WEEKS}w': latest_weekly.get(f'atr_{self.config.ATR_WEEKS}w', 0.0)
            })
            
            # Range metrics
            row.update({
                f'range_high_{self.config.RANGE_WEEKS}w': latest_weekly.get(f'range_high_{self.config.RANGE_WEEKS}w', 0.0),
                f'range_low_{self.config.RANGE_WEEKS}w': latest_weekly.get(f'range_low_{self.config.RANGE_WEEKS}w', 0.0),
                f'range_pct_{self.config.RANGE_WEEKS}w': latest_weekly.get(f'range_pct_{self.config.RANGE_WEEKS}w', 0.0),
                'atr_shrink': latest_weekly.get('atr_shrink', False)
            })
            
            # Volume metrics
            row.update({
                f'vol_ma_{self.config.VOL_MA_WEEKS}w': latest_weekly.get(f'vol_ma_{self.config.VOL_MA_WEEKS}w', 0.0),
                'vol_spike_latest': latest_weekly.get('vol_spike', 0.0),
                'vol_z': latest_weekly.get('vol_z', 0.0)
            })
            
            # Relative strength
            row.update({
                f'rs_{self.config.RS_WEEKS}w': latest_weekly.get(f'rs_{self.config.RS_WEEKS}w', 1.0),
                f'rs_z_{self.config.RS_WEEKS}w': latest_weekly.get(f'rs_z_{self.config.RS_WEEKS}w', 0.0)
            })
            
            # Pattern recognition
            row.update({
                'hhhl_pattern': latest_weekly.get('hhhl_pattern', False),
                'higher_highs': latest_weekly.get('higher_highs', False),
                'higher_lows': latest_weekly.get('higher_lows', False)
            })
            
            # Breakout levels
            row.update({
                'breakout_level': latest_weekly.get('breakout_level', 0.0),
                'breakout_signal': latest_weekly.get('breakout_signal', False),
                'breakout_strength': latest_weekly.get('breakout_strength', 0.0)
            })
            
            # Signal scores (protect against None)
            signal_scores = scoring_analysis.get('signal_scores') or {}
            row.update({
                'trend_strength_score': signal_scores.get('trend_strength', 0.0),
                'range_breakout_score': signal_scores.get('range_breakout', 0.0),
                'volume_confirmation_score': signal_scores.get('volume_confirmation', 0.0),
                'relative_strength_score': signal_scores.get('relative_strength', 0.0),
                'atr_volatility_score': signal_scores.get('atr_volatility', 0.0),
                'hhhl_pattern_score': signal_scores.get('hhhl_pattern', 0.0)
            })
            
            # Daily confirmation with safe defaults (protect against None values)
            confirmation = confirmation_analysis.get('confirmation') or {} if confirmation_analysis else {}
            failure = confirmation_analysis.get('failure') or {} if confirmation_analysis else {}
            
            row.update({
                'daily_confirmed': confirmation.get('confirmed', False),
                'confirmation_date': confirmation.get('confirmation_date', ''),
                'confirmation_price': confirmation.get('confirmation_price', 0.0),
                'confirmation_volume': confirmation.get('confirmation_volume', 0),
                'daily_vol_spike': confirmation.get('daily_vol_spike', 0.0),
                'breakout_failed': failure.get('failed', False),
                'failure_date': failure.get('failure_date', ''),
                'failure_reason': failure.get('failure_reason', ''),
                'confirmation_status': confirmation_analysis.get('status', 'PENDING'),
                'recommendation': confirmation_analysis.get('recommendation', 'WATCH')
            })
            
            # Trade setup (ensure all values are dicts, not None)
            trade_summary = trade_setup.get('trade_summary') or {}
            entry_info = trade_setup.get('entry') or {}
            stop_info = trade_setup.get('stop') or {}
            target_info = trade_setup.get('target') or {}
            position_info = trade_setup.get('position') or {}
            
            row.update({
                'entry_suggested': entry_info.get('entry_price', 0.0),
                'entry_type': entry_info.get('entry_type', ''),
                'stop_suggested': stop_info.get('stop_price', 0.0),
                'stop_method': stop_info.get('stop_method', ''),
                'stop_distance_pct': stop_info.get('stop_distance_pct', 0.0),
                'target_suggested': target_info.get('target_price', 0.0),
                'target_method': target_info.get('target_method', ''),
                'target_distance_pct': target_info.get('target_distance_pct', 0.0),
                'position_size_shares': position_info.get('position_size_shares', 0),
                'position_value': position_info.get('position_value', 0.0),
                'position_value_pct': position_info.get('position_value_pct', 0.0),
                'risk_amount': position_info.get('risk_amount', 0.0),
                'risk_pct': position_info.get('risk_pct', 0.0),
                'risk_reward_ratio': trade_summary.get('risk_reward_ratio', 0.0),
                'potential_reward': trade_summary.get('potential_reward', 0.0)
            })
            
            # Analysis notes
            notes = self._generate_analysis_notes(symbol, data)
            row['notes'] = notes
            
            return row
            
        except Exception as e:
            import traceback
            logger.error(f"Error creating row for {symbol}: {e}")
            logger.debug(f"Traceback: {traceback.format_exc()}")
            return None
    
    def _generate_analysis_notes(self, symbol: str, data: Dict[str, Any]) -> str:
        """Generate analysis notes explaining why a symbol was flagged"""
        notes = []
        
        # Stage analysis (protect against None)
        stage_analysis = data.get('stage_analysis') or {}
        latest_stage = stage_analysis.get('latest_stage', 'UNKNOWN')
        
        if latest_stage == 'BASE_BREAKOUT':
            notes.append("Weekly breakout from consolidation base")
        elif latest_stage == 'UPTREND_CONT':
            notes.append("Uptrend continuation pattern")
        elif latest_stage == 'BASE_CONSOLIDATION':
            notes.append("Base consolidation - watch for breakout")
        elif latest_stage == 'FAILED_BREAKOUT':
            notes.append("Previous breakout failed")
        
        # Scoring analysis (protect against None)
        scoring_analysis = data.get('scoring_analysis') or {}
        confidence_level = scoring_analysis.get('confidence_level', 'IGNORE')
        
        if confidence_level == 'STRONG':
            notes.append("Strong confidence score - high probability setup")
        elif confidence_level == 'MODERATE':
            notes.append("Moderate confidence - good setup with some risk")
        elif confidence_level == 'WATCHLIST':
            notes.append("Watchlist candidate - monitor for improvement")
        
        # Confirmation analysis (protect against None values)
        confirmation_analysis = data.get('confirmation_analysis') or {}
        confirmation = confirmation_analysis.get('confirmation') or {}
        failure = confirmation_analysis.get('failure') or {}
        
        if confirmation.get('confirmed', False):
            notes.append("Daily confirmation received")
        elif failure.get('failed', False):
            notes.append(f"Breakout failed: {failure.get('failure_reason', 'Unknown reason')}")
        else:
            notes.append("Pending daily confirmation")
        
        # Trade setup validation (protect against None)
        trade_setup = data.get('trade_setup') or {}
        validation = data.get('trade_validation') or {}
        trade_summary = trade_setup.get('trade_summary') or {}
        
        if validation.get('valid', True):
            risk_reward = trade_summary.get('risk_reward_ratio', 0)
            if risk_reward >= 2.0:
                notes.append(f"Excellent risk-reward ratio: {risk_reward:.1f}:1")
            elif risk_reward >= 1.5:
                notes.append(f"Good risk-reward ratio: {risk_reward:.1f}:1")
            else:
                notes.append(f"Poor risk-reward ratio: {risk_reward:.1f}:1")
        else:
            issues = validation.get('issues', [])
            if issues:
                notes.append(f"Trade setup issues: {', '.join(issues)}")
        
        return "; ".join(notes) if notes else "No specific notes"
    
    def save_scanner_output(self, df: pd.DataFrame, 
                           filepath: str = None,
                           include_metadata: bool = True) -> str:
        """Save scanner output to CSV with optional metadata"""
        if df.empty:
            logger.warning("No data to save")
            return ""
        
        if filepath is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filepath = f"{self.config.OUTPUT_DIR}/scanner_results_{timestamp}.csv"
        
        # Ensure output directory exists
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        
        # Save main data
        df.to_csv(filepath, index=False)
        
        # Add metadata if requested
        if include_metadata:
            metadata_file = filepath.replace('.csv', '_metadata.txt')
            self._save_metadata(metadata_file, df)
        
        logger.info(f"Scanner output saved to {filepath}")
        return filepath
    
    def _save_metadata(self, filepath: str, df: pd.DataFrame):
        """Save metadata about the scanner run"""
        metadata = {
            'scan_date': datetime.now().isoformat(),
            'total_symbols': len(df),
            'stages_found': df['label'].value_counts().to_dict(),
            'confidence_levels': df['confidence_level'].value_counts().to_dict(),
            'confirmed_breakouts': df['daily_confirmed'].sum(),
            'failed_breakouts': df['breakout_failed'].sum(),
            'avg_confidence_score': df['confidence_score'].mean(),
            'config_used': {
                'ma_short_weeks': self.config.MA_SHORT_WEEKS,
                'ma_long_weeks': self.config.MA_LONG_WEEKS,
                'range_weeks': self.config.RANGE_WEEKS,
                'atr_weeks': self.config.ATR_WEEKS,
                'vol_ma_weeks': self.config.VOL_MA_WEEKS,
                'rs_weeks': self.config.RS_WEEKS,
                'range_pct_threshold': self.config.RANGE_PCT_THRESHOLD,
                'weekly_vol_spike': self.config.WEEKLY_VOL_SPIKE,
                'breakout_buffer': self.config.BREAKOUT_BUFFER,
                'risk_percent': self.config.RISK_PERCENT,
                'max_position_percent': self.config.MAX_POSITION_PERCENT
            }
        }
        
        with open(filepath, 'w') as f:
            f.write("Scanner Run Metadata\n")
            f.write("=" * 50 + "\n\n")
            
            for key, value in metadata.items():
                if isinstance(value, dict):
                    f.write(f"{key}:\n")
                    for sub_key, sub_value in value.items():
                        f.write(f"  {sub_key}: {sub_value}\n")
                else:
                    f.write(f"{key}: {value}\n")
    
    def create_summary_report(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Create a summary report of scanner results"""
        if df.empty:
            return {}
        
        summary = {
            'overview': {
                'total_symbols_scanned': len(df),
                'scan_date': datetime.now().isoformat(),
                'avg_confidence_score': df['confidence_score'].mean(),
                'median_confidence_score': df['confidence_score'].median()
            },
            'stage_breakdown': df['label'].value_counts().to_dict(),
            'confidence_breakdown': df['confidence_level'].value_counts().to_dict(),
            'confirmation_status': {
                'confirmed': df['daily_confirmed'].sum(),
                'failed': df['breakout_failed'].sum(),
                'pending': len(df) - df['daily_confirmed'].sum() - df['breakout_failed'].sum()
            },
            'top_candidates': df.head(10)[['symbol', 'label', 'confidence_score', 'recommendation']].to_dict('records'),
            'risk_analysis': {
                'avg_risk_reward_ratio': df['risk_reward_ratio'].mean(),
                'high_risk_reward': (df['risk_reward_ratio'] >= 2.0).sum(),
                'avg_position_size': df['position_size_shares'].mean(),
                'avg_risk_pct': df['risk_pct'].mean()
            }
        }
        
        return summary
    
    def filter_by_criteria(self, df: pd.DataFrame, 
                          min_confidence: float = None,
                          stages: List[str] = None,
                          confirmed_only: bool = False,
                          min_risk_reward: float = None) -> pd.DataFrame:
        """Filter results by various criteria"""
        filtered_df = df.copy()
        
        if min_confidence is not None:
            filtered_df = filtered_df[filtered_df['confidence_score'] >= min_confidence]
        
        if stages is not None:
            filtered_df = filtered_df[filtered_df['label'].isin(stages)]
        
        if confirmed_only:
            filtered_df = filtered_df[filtered_df['daily_confirmed'] == True]
        
        if min_risk_reward is not None:
            filtered_df = filtered_df[filtered_df['risk_reward_ratio'] >= min_risk_reward]
        
        return filtered_df
