import pandas as pd
import numpy as np

# --- Helper functions ---

def safe_eval_list(x):
    """Convert string representation of list to Python list safely."""
    if isinstance(x, str):
        try:
            # replace nan string with np.nan
            x = x.replace('nan', 'np.nan')
            return eval(x)
        except:
            return []
    elif isinstance(x, list) or isinstance(x, np.ndarray):
        return x
    else:
        return []

def classify_stock(row):
    # Extract main metrics
    rs_ratio = row.get('RS_Ratio', 0)
    rs_mom = row.get('RS_Momentum', 0)
    mom_diff = row.get('RS_Momentum - RS_Ratio', 0)
    distance = row.get('Distance_from_Center', 0)
    tail_angle = row.get('Tail_Angle', 0)
    velocity = row.get('Velocity_Factor', 0)
    quadrant = str(row.get('Quadrant', '')).strip()
    move_dir = str(row.get('Movement_Direction', '')).strip()

    tail_rs = safe_eval_list(row.get('Tail_RS', []))
    tail_mom = safe_eval_list(row.get('Tail_Momentum', []))

    # --- Compute tail rotation ---
    tail_rs_change = tail_rs[-1] - tail_rs[0] if len(tail_rs) > 1 else 0
    tail_mom_change = tail_mom[-1] - tail_mom[0] if len(tail_mom) > 1 else 0

    # --- Initial classification ---
    classification = "Balanced/Safe"
    comment = "Stock is in balanced range; momentum and RS are aligned moderately."

    # Momentum Burst
    if mom_diff > 20 and tail_mom_change > 0 and tail_rs_change > 0:
        classification = "Momentum Burst"
        comment = ("Momentum outpacing RS strongly with sharp rotation (burst setup). "
                   "Recent tail shows improving RS & Momentum → positive rotation.")
    # Overextended
    elif rs_ratio > 100 and tail_mom_change < 0 and tail_rs_change < 0:
        classification = "Overextended"
        comment = ("RS is high but tail shows fading momentum & RS; stock may be overextended. "
                   "Consider waiting for rotation or pullback.")
    # Quadrant / Movement nuance
    if quadrant.lower() in ['weakening', 'lagging'] or move_dir.lower() in ['away from leading']:
        classification = "Overextended" if classification != "Momentum Burst" else classification
        comment += " Quadrant/Movement indicates caution; rotation may reverse."

    # Adjust for very low RS but strong momentum
    if rs_ratio < 70 and mom_diff > 25:
        classification = "Momentum Burst"
        comment += " Strong momentum despite low RS; potential early breakout opportunity."

    return classification, comment

def compute_rank_score(row):
    # Higher RS, Momentum, Opportunity_Score, Tail velocity → higher rank
    score = 0
    score += min(max(row.get('RS_Ratio', 0), 0), 200) * 0.4
    score += min(max(row.get('RS_Momentum', 0), 0), 200) * 0.3
    score += min(max(row.get('RS_Momentum - RS_Ratio', 0), 0), 100) * 0.2
    score += min(max(row.get('Velocity_Factor', 0), 0), 100) * 0.1
    return round(score, 2)

# --- Main script ---

# Load data
input_file = "RRG_Combined_Analysis_20250925_125735.csv"  # replace with your file path
df = pd.read_csv(input_file)

# Apply classification
df[['Classification', 'Comment']] = df.apply(lambda row: pd.Series(classify_stock(row)), axis=1)

# Compute rank score
df['Rank_Score'] = df.apply(compute_rank_score, axis=1)

# Add recommendation based on classification
def recommendation_from_class(row):
    cls = row['Classification']
    if cls == 'Momentum Burst':
        return "STRONG BUY"
    elif cls == 'Overextended':
        return "CAUTION - Consider waiting"
    else:
        return "Balanced / HOLD"
    
df['Recommendation'] = df.apply(recommendation_from_class, axis=1)

# Sort by rank score
df.sort_values('Rank_Score', ascending=False, inplace=True)

# Export report
output_file = "Scan_Insight_25Sep2025.csv"
df.to_csv(output_file, index=False)

print(f"Report generated: {output_file}")
