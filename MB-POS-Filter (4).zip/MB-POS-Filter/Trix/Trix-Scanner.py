"""
TRIX Zero-Line Crossover Scanner for Kite Connect
Flexible configuration via config.json for all parameters
Supports multiple timeframes: daily, weekly, monthly
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import time
from datetime import datetime, timedelta
import logging
import json
import os
import argparse
from typing import Dict, List, Tuple, Optional

# Configure logging with UTF-8 support
import sys

# Create handlers with UTF-8 encoding
script_dir = os.path.dirname(os.path.abspath(__file__))
log_file = os.path.join(script_dir, 'trix_scanner.log')
file_handler = logging.FileHandler(log_file, encoding='utf-8')
console_handler = logging.StreamHandler(sys.stdout)

# Set formatter
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
console_handler.setFormatter(formatter)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    handlers=[file_handler, console_handler]
)
logger = logging.getLogger(__name__)


class Config:
    """Configuration manager with validation"""
    
    DEFAULT_CONFIG = {
        "kite_credentials": {
            "api_key": "your_api_key_here",
            "access_token": "your_access_token_here"
        },
        "trix_parameters": {
            "length": 14,
            "signal_type": "SMA",  # SMA or EMA
            "signal_length": 9,
            "multiplier": 1
        },
        "scanning_parameters": {
            "timeframe": "day",  # day, week, month, 5minute, 15minute, hour
            "lookback_days": 60,  # Data to fetch
            "zero_tolerance_percent": 4.0,  # Range around zero (±4%)
            "min_volume_ratio": 0.5,  # Minimum volume ratio to consider
            "min_histogram_for_strong": 0.01  # Minimum histogram for strong signal
        },
        "scoring_weights": {
            "crossover": 30,
            "near_zero": 25,
            "positive_histogram": 15,
            "positive_slope": 10,
            "volume_boost": 10,
            "momentum_bonus": 10
        },
        "filters": {
            "only_crossovers": False,  # Only show crossover signals
            "only_near_zero": False,  # Only show near-zero opportunities
            "min_opportunity_score": 0,  # Minimum score to include
            "max_results": None  # Limit number of results (None = all)
        },
        "files": {
            "input_csv": "input.csv",
            "output_csv": "trix_scan_results_{timestamp}.csv",
            "cache_file": "nse_instruments_cache.json",
            "cache_duration_hours": 24
        },
        "rate_limiting": {
            "max_calls_per_second": 3,
            "delay_between_symbols": 0.1
        }
    }
    
    def __init__(self, config_file: str = "config.json"):
        # If config_file is just a filename (no path), look in script directory
        if not os.path.dirname(config_file) and config_file == "config.json":
            script_dir = os.path.dirname(os.path.abspath(__file__))
            self.config_file = os.path.join(script_dir, config_file)
        else:
            self.config_file = config_file
        self.config = self._load_config()
    
    def _load_config(self) -> dict:
        """Load config from file or create default"""
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    user_config = json.load(f)
                logger.info(f"Loaded configuration from {self.config_file}")
                # Merge with defaults (user config overrides)
                return self._deep_merge(self.DEFAULT_CONFIG.copy(), user_config)
            except Exception as e:
                logger.warning(f"Error loading config: {e}. Using defaults.")
                return self.DEFAULT_CONFIG.copy()
        else:
            # Create default config file
            self._save_config(self.DEFAULT_CONFIG)
            logger.info(f"Created default config: {self.config_file}")
            return self.DEFAULT_CONFIG.copy()
    
    def _deep_merge(self, base: dict, overlay: dict) -> dict:
        """Deep merge two dictionaries"""
        for key, value in overlay.items():
            if key in base and isinstance(base[key], dict) and isinstance(value, dict):
                base[key] = self._deep_merge(base[key], value)
            else:
                base[key] = value
        return base
    
    def _save_config(self, config: dict):
        """Save config to file"""
        with open(self.config_file, 'w') as f:
            json.dump(config, f, indent=4)
    
    def get(self, *keys):
        """Get nested config value"""
        value = self.config
        for key in keys:
            value = value.get(key)
            if value is None:
                return None
        return value
    
    def validate(self) -> bool:
        """Validate configuration"""
        # Check credentials
        api_key = self.get('kite_credentials', 'api_key')
        access_token = self.get('kite_credentials', 'access_token')
        
        if api_key == "your_api_key_here" or not api_key:
            logger.error("[ERROR] API key not configured in config.json")
            return False
        
        if access_token == "your_access_token_here" or not access_token:
            logger.error("[ERROR] Access token not configured in config.json")
            return False
        
        # Validate timeframe
        valid_timeframes = ['minute', '3minute', '5minute', '10minute', '15minute', 
                           '30minute', 'hour', 'day', 'week', 'month']
        timeframe = self.get('scanning_parameters', 'timeframe')
        if timeframe not in valid_timeframes:
            logger.error(f"[ERROR] Invalid timeframe: {timeframe}. Valid: {valid_timeframes}")
            return False
        
        # Validate signal type
        signal_type = self.get('trix_parameters', 'signal_type')
        if signal_type not in ['SMA', 'EMA']:
            logger.error(f"[ERROR] Invalid signal_type: {signal_type}. Use 'SMA' or 'EMA'")
            return False
        
        logger.info("[OK] Configuration validated successfully")
        return True


class RateLimiter:
    """Rate limiter for Kite Connect API"""
    
    def __init__(self, max_calls: int = 3, time_window: float = 1.0):
        self.max_calls = max_calls
        self.time_window = time_window
        self.calls = []
    
    def wait_if_needed(self):
        """Wait if rate limit would be exceeded"""
        now = time.time()
        # Remove calls outside time window
        self.calls = [call_time for call_time in self.calls if now - call_time < self.time_window]
        
        if len(self.calls) >= self.max_calls:
            sleep_time = self.time_window - (now - self.calls[0]) + 0.1
            if sleep_time > 0:
                logger.debug(f"Rate limit: sleeping {sleep_time:.2f}s")
                time.sleep(sleep_time)
                self.calls = []
        
        self.calls.append(time.time())


class InstrumentCache:
    """Cache NSE instruments to avoid repeated API calls"""
    
    def __init__(self, kite: KiteConnect, cache_file: str, cache_duration_hours: int = 24):
        self.kite = kite
        self.cache_file = cache_file
        self.cache_duration = timedelta(hours=cache_duration_hours)
        self.instruments = {}
        self.cache_time = None
        self._load_or_refresh()
    
    def _load_or_refresh(self):
        """Load from cache or refresh from API"""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    cache_data = json.load(f)
                    self.cache_time = datetime.fromisoformat(cache_data['timestamp'])
                    
                    if datetime.now() - self.cache_time < self.cache_duration:
                        self.instruments = cache_data['instruments']
                        logger.info(f"[OK] Loaded {len(self.instruments)} instruments from cache")
                        return
            except Exception as e:
                logger.warning(f"Cache load failed: {e}")
        
        self._refresh_from_api()
    
    def _refresh_from_api(self):
        """Fetch instruments from Kite API"""
        logger.info("Fetching instruments from Kite API...")
        try:
            instruments_list = self.kite.instruments("NSE")
            self.instruments = {
                inst['tradingsymbol']: {
                    'instrument_token': inst['instrument_token'],
                    'exchange_token': inst['exchange_token'],
                    'name': inst['name'],
                    'lot_size': inst['lot_size']
                }
                for inst in instruments_list
            }
            
            # Save to cache
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'instruments': self.instruments
            }
            with open(self.cache_file, 'w') as f:
                json.dump(cache_data, f)
            
            self.cache_time = datetime.now()
            logger.info(f"✅ Cached {len(self.instruments)} instruments")
        except Exception as e:
            logger.error(f"Failed to fetch instruments: {e}")
            raise
    
    def get_token(self, symbol: str) -> Optional[int]:
        """Get instrument token for a symbol"""
        return self.instruments.get(symbol, {}).get('instrument_token')
    
    def get_info(self, symbol: str) -> Optional[Dict]:
        """Get full instrument info"""
        return self.instruments.get(symbol)


class TRIXCalculator:
    """Calculate TRIX indicator with flexible parameters"""
    
    @staticmethod
    def ema(data: pd.Series, period: int) -> pd.Series:
        """Calculate Exponential Moving Average"""
        return data.ewm(span=period, adjust=False).mean()
    
    @staticmethod
    def sma(data: pd.Series, period: int) -> pd.Series:
        """Calculate Simple Moving Average"""
        return data.rolling(window=period).mean()
    
    @staticmethod
    def calculate_trix(df: pd.DataFrame, length: int = 14, signal_type: str = "SMA",
                       signal_length: int = 9, multiplier: float = 1) -> pd.DataFrame:
        """
        Calculate TRIX and Signal line with configurable parameters
        
        Args:
            df: DataFrame with 'close' column
            length: TRIX EMA period
            signal_type: 'SMA' or 'EMA' for signal line
            signal_length: Signal line period
            multiplier: TRIX multiplier for scaling
        
        Returns:
            DataFrame with TRIX, Signal, and Histogram
        """
        # Triple EMA smoothing
        ema1 = TRIXCalculator.ema(df['close'], length)
        ema2 = TRIXCalculator.ema(ema1, length)
        ema3 = TRIXCalculator.ema(ema2, length)
        
        # Rate of Change (1-period) * multiplier
        trix = ((ema3 - ema3.shift(1)) / ema3.shift(1)) * 100 * multiplier
        
        # Signal line (SMA or EMA of TRIX)
        if signal_type.upper() == "EMA":
            signal = TRIXCalculator.ema(trix, signal_length)
        else:  # SMA
            signal = TRIXCalculator.sma(trix, signal_length)
        
        # Histogram
        histogram = trix - signal
        
        df['trix'] = trix
        df['signal'] = signal
        df['histogram'] = histogram
        
        return df


class TRIXScanner:
    """Main scanner class with flexible configuration"""
    
    def __init__(self, config: Config):
        self.config = config
        
        # Initialize Kite
        api_key = config.get('kite_credentials', 'api_key')
        access_token = config.get('kite_credentials', 'access_token')
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Initialize rate limiter
        max_calls = config.get('rate_limiting', 'max_calls_per_second')
        self.rate_limiter = RateLimiter(max_calls=max_calls)
        
        # Initialize instrument cache
        cache_file = config.get('files', 'cache_file')
        # Make cache file path relative to script directory if it's just a filename
        if not os.path.isabs(cache_file) and not cache_file.startswith('../'):
            script_dir = os.path.dirname(os.path.abspath(__file__))
            cache_file = os.path.join(script_dir, cache_file)
        cache_duration = config.get('files', 'cache_duration_hours')
        self.instrument_cache = InstrumentCache(self.kite, cache_file, cache_duration)
        
    def fetch_historical_data(self, instrument_token: int) -> Optional[pd.DataFrame]:
        """Fetch historical data and resample to required timeframe"""
        try:
            self.rate_limiter.wait_if_needed()
            
            timeframe = self.config.get('scanning_parameters', 'timeframe')
            lookback_days = self.config.get('scanning_parameters', 'lookback_days')
            
            # Always fetch daily data from Kite API
            to_date = datetime.now()
            
            # Adjust lookback period for weekly/monthly timeframes
            if timeframe == 'week':
                # For weekly, need ~5x more daily data (5 trading days per week)
                adjusted_lookback = max(lookback_days * 5, 365)  # At least 1 year for weekly
            elif timeframe == 'month':
                # For monthly, need much more daily data (20 trading days per month)
                adjusted_lookback = max(lookback_days * 20, 1095)  # At least 3 years for monthly
            else:
                adjusted_lookback = lookback_days
            
            from_date = to_date - timedelta(days=adjusted_lookback)
            
            # Determine what interval to fetch from Kite API
            if timeframe in ['minute', '3minute', '5minute', '10minute', '15minute', '30minute', 'hour']:
                # Kite supports these intraday timeframes directly
                api_interval = timeframe
            else:
                # For daily/weekly/monthly, fetch daily data and resample
                api_interval = 'day'
            
            # Fetch data from Kite API
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=api_interval
            )
            
            if not data:
                logger.info(f"No {api_interval} data returned from API for token {instrument_token}")
                return None
            
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df = df.sort_values('date').reset_index(drop=True)
            
            logger.info(f"Fetched {len(df)} {api_interval} data points for token {instrument_token}")
            
            # Resample to required timeframe if needed
            if timeframe in ['week', 'month']:
                df = self._resample_data(df, timeframe)
                logger.info(f"Resampled to {timeframe}: {len(df)} data points")
            
            return df
        
        except Exception as e:
            logger.error(f"Error fetching data for token {instrument_token}: {e}")
            return None
    
    def _resample_data(self, df: pd.DataFrame, target_timeframe: str) -> pd.DataFrame:
        """
        Resample daily data to weekly/monthly candles
        
        Args:
            df: DataFrame with daily OHLCV data
            target_timeframe: Target timeframe ('week', 'month')
        
        Returns:
            Resampled DataFrame
        """
        try:
            # Set date as index for resampling
            df_indexed = df.set_index('date')
            
            if target_timeframe == 'week':
                # Weekly resampling (Monday to Friday)
                resampled = df_indexed.resample('W-FRI').agg({
                    'open': 'first',    # First open of the week
                    'high': 'max',      # Highest high of the week
                    'low': 'min',       # Lowest low of the week
                    'close': 'last',    # Last close of the week
                    'volume': 'sum'     # Total volume of the week
                }).dropna()
                
            elif target_timeframe == 'month':
                # Monthly resampling (end of month)
                resampled = df_indexed.resample('ME').agg({
                    'open': 'first',    # First open of the month
                    'high': 'max',      # Highest high of the month
                    'low': 'min',       # Lowest low of the month
                    'close': 'last',    # Last close of the month
                    'volume': 'sum'     # Total volume of the month
                }).dropna()
                
            else:
                # For other timeframes, return original data
                logger.warning(f"Unsupported timeframe for resampling: {target_timeframe}")
                return df
            
            # Reset index to get date column back
            resampled = resampled.reset_index()
            
            # Ensure proper column order
            columns = ['date', 'open', 'high', 'low', 'close', 'volume']
            resampled = resampled[columns]
            
            logger.debug(f"Resampled from {len(df)} daily to {len(resampled)} {target_timeframe} candles")
            return resampled
            
        except Exception as e:
            logger.error(f"Error resampling data to {target_timeframe}: {e}")
            return df  # Return original data if resampling fails
    
    def analyze_symbol(self, symbol: str) -> Optional[Dict]:
        """
        Analyze a single symbol with all configurable parameters
        
        Args:
            symbol: Trading symbol
        
        Returns:
            Dictionary with analysis results or None
        """
        logger.info(f"Analyzing {symbol}...")
        
        # Get instrument token
        inst_token = self.instrument_cache.get_token(symbol)
        if not inst_token:
            logger.warning(f"Symbol {symbol} not found in NSE")
            return None
        
        # Fetch historical data
        df = self.fetch_historical_data(inst_token)
        if df is None:
            logger.warning(f"No data returned for {symbol}")
            return None
        # Determine minimum data points based on timeframe and TRIX length
        trix_length = self.config.get('trix_parameters', 'length')
        timeframe = self.config.get('scanning_parameters', 'timeframe')
        
        # Adjust minimum requirements based on timeframe
        if timeframe == 'month':
            # For monthly, need fewer points since each point represents a month
            min_required = max(trix_length + 10, 20)
        elif timeframe == 'week':
            # For weekly, moderate requirements
            min_required = max(trix_length + 15, 25)
        else:
            # For daily/intraday, need more points for TRIX calculation (3x smoothing + buffer)
            min_required = max(trix_length * 3 + 20, 30)
        
        if len(df) < min_required:
            logger.warning(f"Insufficient data for {symbol}: {len(df)} {timeframe} data points (need {min_required}+)")
            return None
        
        # Get TRIX parameters
        signal_type = self.config.get('trix_parameters', 'signal_type')
        signal_length = self.config.get('trix_parameters', 'signal_length')
        multiplier = self.config.get('trix_parameters', 'multiplier')
        
        # Calculate TRIX
        df = TRIXCalculator.calculate_trix(df, trix_length, signal_type, signal_length, multiplier)
        
        # Drop NaN values
        df = df.dropna()
        if len(df) < 10:
            return None
        
        # Get latest values
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        
        trix_current = latest['trix']
        signal_current = latest['signal']
        trix_prev = prev['trix']
        signal_prev = prev['signal']
        
        # Check for crossover (TRIX crosses above Signal)
        crossover = (trix_prev <= signal_prev) and (trix_current > signal_current)
        
        # Check for crossunder (TRIX crosses below Signal)
        crossunder = (trix_prev >= signal_prev) and (trix_current < signal_current)
        
        # Get scanning parameters
        zero_tolerance = self.config.get('scanning_parameters', 'zero_tolerance_percent')
        min_volume_ratio = self.config.get('scanning_parameters', 'min_volume_ratio')
        
        # Check if TRIX is near zero
        near_zero = abs(trix_current) <= zero_tolerance
        
        # Calculate additional metrics
        histogram = latest['histogram']
        trix_slope = trix_current - trix_prev
        distance_from_zero = trix_current
        
        # Calculate momentum strength (histogram momentum)
        hist_values = df['histogram'].tail(5).values
        hist_momentum = "Accelerating" if all(hist_values[i] < hist_values[i+1] for i in range(len(hist_values)-1)) else \
                       "Decelerating" if all(hist_values[i] > hist_values[i+1] for i in range(len(hist_values)-1)) else \
                       "Mixed"
        
        # Price info
        current_price = latest['close']
        price_change_5d = ((current_price - df.iloc[-6]['close']) / df.iloc[-6]['close'] * 100) if len(df) >= 6 else 0
        
        # Volume analysis (if available)
        avg_volume = df['volume'].tail(20).mean() if 'volume' in df else 0
        current_volume = latest.get('volume', 0)
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 0
        
        # Apply minimum volume filter
        if volume_ratio < min_volume_ratio:
            logger.debug(f"{symbol}: Volume too low ({volume_ratio:.2f}x)")
            return None
        
        # Calculate signal strength and opportunity score
        signal_strength = self._calculate_signal_strength(crossover, near_zero, histogram, trix_slope)
        opportunity_score = self._calculate_opportunity_score(
            crossover, near_zero, histogram, trix_slope, volume_ratio
        )
        
        # Apply filters
        filters = self.config.get('filters')
        if filters.get('only_crossovers') and not crossover:
            return None
        if filters.get('only_near_zero') and not near_zero:
            return None
        if opportunity_score < filters.get('min_opportunity_score', 0):
            return None
        
        # Generate trading note
        note = self._generate_note(
            crossover=crossover,
            crossunder=crossunder,
            near_zero=near_zero,
            trix_current=trix_current,
            signal_current=signal_current,
            histogram=histogram,
            hist_momentum=hist_momentum,
            trix_slope=trix_slope,
            volume_ratio=volume_ratio
        )
        
        # Get timeframe for context
        timeframe = self.config.get('scanning_parameters', 'timeframe')
        
        return {
            'symbol': symbol,
            'date': latest['date'].strftime('%Y-%m-%d %H:%M:%S'),
            'timeframe': timeframe,
            'close_price': round(current_price, 2),
            'trix': round(trix_current, 4),
            'signal': round(signal_current, 4),
            'histogram': round(histogram, 4),
            'trix_slope': round(trix_slope, 4),
            'distance_from_zero': round(distance_from_zero, 4),
            'crossover_detected': crossover,
            'crossunder_detected': crossunder,
            'near_zero_line': near_zero,
            'signal_strength': signal_strength,
            'histogram_momentum': hist_momentum,
            'price_change_5d_pct': round(price_change_5d, 2),
            'volume_ratio': round(volume_ratio, 2),
            'avg_volume_20d': int(avg_volume),
            'current_volume': int(current_volume),
            'opportunity_score': opportunity_score,
            'trix_length': trix_length,
            'signal_type': signal_type,
            'signal_length': signal_length,
            'note': note
        }
    
    def _calculate_signal_strength(self, crossover: bool, near_zero: bool, 
                                   histogram: float, trix_slope: float) -> str:
        """Calculate signal strength based on configuration"""
        min_hist = self.config.get('scanning_parameters', 'min_histogram_for_strong')
        
        if not crossover:
            return "No Signal"
        
        if near_zero and histogram > min_hist and trix_slope > 0:
            return "Strong"
        elif near_zero and histogram > 0:
            return "Moderate"
        elif crossover:
            return "Weak"
        return "No Signal"
    
    def _calculate_opportunity_score(self, crossover: bool, near_zero: bool,
                                     histogram: float, trix_slope: float, 
                                     volume_ratio: float) -> int:
        """Calculate opportunity score using configured weights"""
        weights = self.config.get('scoring_weights')
        score = 0
        
        if crossover:
            score += weights['crossover']
        if near_zero:
            score += weights['near_zero']
        if histogram > 0:
            score += weights['positive_histogram']
        if trix_slope > 0:
            score += weights['positive_slope']
        if volume_ratio > 1.2:
            score += weights['volume_boost']
        
        min_hist = self.config.get('scanning_parameters', 'min_histogram_for_strong')
        if histogram > min_hist and trix_slope > 0.01:
            score += weights['momentum_bonus']
        
        return min(score, 100)
    
    def _generate_note(self, crossover: bool, crossunder: bool, near_zero: bool, 
                       trix_current: float, signal_current: float, histogram: float, 
                       hist_momentum: str, trix_slope: float, volume_ratio: float) -> str:
        """Generate meaningful trading note"""
        notes = []
        
        timeframe = self.config.get('scanning_parameters', 'timeframe')
        tf_label = timeframe.upper() if timeframe in ['day', 'week', 'month'] else timeframe
        
        if crossover and near_zero:
            notes.append(f"[PRIME] PRIME OPPORTUNITY ({tf_label}): Bullish crossover near zero - potential trend reversal")
        elif crossover:
            notes.append(f"[BULL] Bullish crossover detected on {tf_label} timeframe")
        elif crossunder:
            notes.append(f"[BEAR] Bearish crossunder on {tf_label} - consider exit/short")
        
        if near_zero and not crossover:
            notes.append(f"[WARN] TRIX near zero on {tf_label} - monitor for crossover signal")
        
        if histogram > 0:
            notes.append(f"[UP] Positive histogram ({histogram:.4f}) - bullish momentum")
        else:
            notes.append(f"[DOWN] Negative histogram ({histogram:.4f}) - bearish pressure")
        
        if hist_momentum == "Accelerating":
            notes.append("[ACCEL] Momentum accelerating - strong trend potential")
        elif hist_momentum == "Decelerating":
            notes.append("[DECEL] Momentum decelerating - watch for reversal")
        
        if trix_slope > 0.02:
            notes.append("[STRONG] Strong upward TRIX slope")
        elif trix_slope < -0.02:
            notes.append("[DOWN] Negative TRIX slope")
        
        if volume_ratio > 1.5:
            notes.append(f"[VOL] High volume ({volume_ratio:.1f}x avg) - strong conviction")
        elif volume_ratio < 0.7:
            notes.append(f"[LOW_VOL] Low volume ({volume_ratio:.1f}x avg) - weak participation")
        
        if abs(trix_current) < 1.0:
            notes.append("[ZERO] Very close to zero - high probability reversal zone")
        
        return " | ".join(notes) if notes else "No significant signals detected"
    
    def scan_symbols(self, symbols: List[str] = None) -> pd.DataFrame:
        """
        Scan multiple symbols
        
        Args:
            symbols: List of symbols (if None, reads from config input file)
        
        Returns:
            DataFrame with results
        """
        if symbols is None:
            # Read from input file
            input_csv = self.config.get('files', 'input_csv')
            
            # If input_csv is a relative path, make it relative to script directory
            if not os.path.isabs(input_csv):
                script_dir = os.path.dirname(os.path.abspath(__file__))
                input_csv = os.path.normpath(os.path.join(script_dir, input_csv))
            
            logger.info(f"Reading symbols from {input_csv}")
            
            if not os.path.exists(input_csv):
                logger.error(f"Input file {input_csv} not found")
                # Create sample - ensure directory exists first
                os.makedirs(os.path.dirname(input_csv), exist_ok=True)
                sample_df = pd.DataFrame({
                    'symbol': ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK', 
                              'SBIN', 'BHARTIARTL', 'LT', 'WIPRO', 'MARUTI']
                })
                sample_df.to_csv(input_csv, index=False)
                logger.info(f"Created sample {input_csv}")
                symbols = sample_df['symbol'].tolist()
            else:
                try:
                    input_df = pd.read_csv(input_csv)
                    # Check for symbol column (case-insensitive)
                    symbol_col = None
                    for col in input_df.columns:
                        if col.lower() == 'symbol':
                            symbol_col = col
                            break
                    
                    if symbol_col is None:
                        raise ValueError("Input CSV must have 'symbol' column (case-insensitive)")
                    symbols = input_df[symbol_col].unique().tolist()
                except Exception as e:
                    logger.error(f"Error reading input CSV: {e}")
                    return pd.DataFrame()
        
        logger.info(f"[SCAN] Scanning {len(symbols)} symbols on {self.config.get('scanning_parameters', 'timeframe')} timeframe...")
        
        results = []
        delay = self.config.get('rate_limiting', 'delay_between_symbols')
        
        for i, symbol in enumerate(symbols, 1):
            logger.info(f"Progress: {i}/{len(symbols)} - {symbol}")
            
            result = self.analyze_symbol(symbol)
            if result:
                results.append(result)
            
            time.sleep(delay)
        
        # Create results DataFrame
        if results:
            results_df = pd.DataFrame(results)
            
            # Sort by opportunity score (descending)
            results_df = results_df.sort_values('opportunity_score', ascending=False)
            
            # Apply max results filter
            max_results = self.config.get('filters', 'max_results')
            if max_results:
                results_df = results_df.head(max_results)
            
            return results_df
        else:
            logger.warning("No results found")
            return pd.DataFrame()
    
    def save_results(self, results_df: pd.DataFrame):
        """Save results to CSV with timestamp"""
        if results_df.empty:
            logger.warning("No results to save")
            return
        
        output_template = self.config.get('files', 'output_csv')
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_csv = output_template.replace('{timestamp}', timestamp)
        
        # Make output file path relative to script directory if it's just a filename
        if not os.path.isabs(output_csv) and not output_csv.startswith('../'):
            script_dir = os.path.dirname(os.path.abspath(__file__))
            output_csv = os.path.join(script_dir, output_csv)
        
        results_df.to_csv(output_csv, index=False)
        logger.info(f"[OK] Results saved to {output_csv}")
        
        # Print summary
        self._print_summary(results_df)
        
        return output_csv
    
    def _print_summary(self, results_df: pd.DataFrame):
        """Print scan summary"""
        print("\n" + "="*100)
        print(f"SCAN SUMMARY - {self.config.get('scanning_parameters', 'timeframe').upper()} TIMEFRAME")
        print("="*100)
        print(f"Total opportunities: {len(results_df)}")
        print(f"Strong signals: {len(results_df[results_df['signal_strength'] == 'Strong'])}")
        print(f"Crossovers detected: {results_df['crossover_detected'].sum()}")
        print(f"Near zero line: {results_df['near_zero_line'].sum()}")
        print(f"Average opportunity score: {results_df['opportunity_score'].mean():.1f}")
        
        print("\n" + "-"*100)
        print("TOP 5 OPPORTUNITIES")
        print("-"*100)
        
        top_5 = results_df.head(5)
        for idx, row in top_5.iterrows():
            print(f"\n{idx+1}. {row['symbol']} - Score: {row['opportunity_score']} | Strength: {row['signal_strength']}")
            print(f"   Price: ₹{row['close_price']} | TRIX: {row['trix']:.4f} | Signal: {row['signal']:.4f}")
            print(f"   Volume: {row['volume_ratio']:.2f}x | Histogram: {row['histogram']:.4f}")
            print(f"   [NOTE] {row['note']}")
        
        print("\n" + "="*100 + "\n")


def main():
    """Main execution function"""
    
    parser = argparse.ArgumentParser(description='TRIX Scanner with flexible configuration')
    parser.add_argument('-c', '--config', default='config.json', help='Config file path')
    parser.add_argument('-t', '--timeframe', help='Override timeframe (day/week/month/hour/etc)')
    parser.add_argument('-l', '--length', type=int, help='Override TRIX length')
    parser.add_argument('--signal-type', choices=['SMA', 'EMA'], help='Override signal type')
    parser.add_argument('--signal-length', type=int, help='Override signal length')
    parser.add_argument('--crossovers-only', action='store_true', help='Only show crossovers')
    parser.add_argument('--near-zero-only', action='store_true', help='Only show near-zero opportunities')
    parser.add_argument('--min-score', type=int, help='Minimum opportunity score')
    
    args = parser.parse_args()
    
    # Load configuration
    config = Config(args.config)
    
    # Apply command line overrides
    if args.timeframe:
        config.config['scanning_parameters']['timeframe'] = args.timeframe
    if args.length:
        config.config['trix_parameters']['length'] = args.length
    if args.signal_type:
        config.config['trix_parameters']['signal_type'] = args.signal_type
    if args.signal_length:
        config.config['trix_parameters']['signal_length'] = args.signal_length
    if args.crossovers_only:
        config.config['filters']['only_crossovers'] = True
    if args.near_zero_only:
        config.config['filters']['only_near_zero'] = True
    if args.min_score:
        config.config['filters']['min_opportunity_score'] = args.min_score
    
    # Validate configuration
    if not config.validate():
        logger.error("Configuration validation failed. Please check config.json")
        return
    
    # Display configuration
    print("\n" + "="*100)
    print("TRIX SCANNER CONFIGURATION")
    print("="*100)
    print(f"Timeframe: {config.get('scanning_parameters', 'timeframe')}")
    print(f"TRIX Length: {config.get('trix_parameters', 'length')}")
    print(f"Signal Type: {config.get('trix_parameters', 'signal_type')}")
    print(f"Signal Length: {config.get('trix_parameters', 'signal_length')}")
    print(f"Zero Tolerance: ±{config.get('scanning_parameters', 'zero_tolerance_percent')}%")
    print(f"Lookback Days: {config.get('scanning_parameters', 'lookback_days')}")
    print("="*100 + "\n")
    
    try:
        scanner = TRIXScanner(config)
        results_df = scanner.scan_symbols()
        
        if not results_df.empty:
            scanner.save_results(results_df)
        else:
            logger.warning("No opportunities found matching your criteria")
    
    except KeyboardInterrupt:
        logger.info("\n[WARN] Scan interrupted by user")
    except Exception as e:
        logger.error(f"Scanner failed: {e}", exc_info=True)


if __name__ == "__main__":
    main()