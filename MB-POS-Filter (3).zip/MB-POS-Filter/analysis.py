"""
FNO Short-Straddle Scanner

Reads two CSV snapshots per symbol (futures/OI sheet and greeks/options sheet),
merges them by column names (not column order), scores each symbol for a
monthly ATM short-straddle (or defined-risk variant) and writes a ranked CSV.

Features:
- Robust column-name based loading (case-insensitive, common synonyms supported)
- Flexible merge logic: prefers (symbol + expiry) keys, falls back to (symbol + analysis_end_date), then symbol latest
- Scoring based on IV (net_vega), net_theta, writer strength, PCR, roll cost, term structure and OI zscore
- Missing-column tolerant: uses what is available, logs what's missing
- Configurable weights and thresholds
- Produces `ranked_output.csv` and prints top-N candidates

Usage:
    python fno_short_straddle_scanner.py --fut file_fut.csv --greeks file_greeks.csv --out ranked_output.csv

"""

import argparse
import pandas as pd
import numpy as np
import logging
from typing import Tuple, List, Dict

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
logger = logging.getLogger(__name__)

# --------------------------- Utilities ---------------------------------

# Mapping of common synonyms to canonical column names used by the scanner
CANONICAL_MAP = {
    # basic identifiers
    'timestamp': 'timestamp',
    'time': 'timestamp',
    'ts': 'timestamp',
    'symbol': 'symbol',
    'underlying': 'symbol',
    'expiry': 'expiry',
    'exp': 'expiry',
    'spot': 'spot',
    'spot_price': 'spot',

    # futures / oi sheet
    'current_month_fut': 'current_month_fut',
    'current_fut_price': 'current_fut_price',
    'current_oi_change_percent': 'current_oi_change_percent',
    'current_price_change_percent': 'current_price_change_percent',
    'current_oi_zscore': 'current_oi_zscore',
    'current_price_zscore': 'current_price_zscore',
    'days_to_current_expiry': 'days_to_current_expiry',
    'roll_cost_percent_of_spot': 'roll_cost_percent_of_spot',
    'roll_cost_points': 'roll_cost_points',
    'rollover_percent': 'rollover_percent',
    'rollover_quality_index': 'rollover_quality_index',
    'term_structure_slope_percent': 'term_structure_slope_percent',
    'price_oi_ratio_primary': 'price_oi_ratio_primary',
    'writer_dominant_side': 'writer_dominant_side',
    'writer_call_writer_strength_percent': 'writer_call_writer_strength_percent',
    'writer_put_writer_strength_percent': 'writer_put_writer_strength_percent',
    'writer_max_call_oi_strike': 'writer_max_call_oi_strike',
    'writer_max_put_oi_strike': 'writer_max_put_oi_strike',
    'writer_pcr_oi': 'writer_pcr_oi',
    'pcr_oi': 'writer_pcr_oi',
    'analysis_end_date': 'analysis_end_date',
    'analysis_start_date': 'analysis_start_date',
    'analysis_trading_days': 'analysis_trading_days',
    'sentiment_current': 'sentiment_current',
    'sentiment_next': 'sentiment_next',

    # greeks/options sheet
    'dte_days': 'dte_days',
    'dynamic_delta_target': 'dynamic_delta_target',
    'ce_delta': 'ce_delta',
    'pe_delta': 'pe_delta',
    'total_credit': 'total_credit',
    'net_theta': 'net_theta',
    'net_theta_per_day': 'net_theta_per_day',
    'net_theta_per_trading_day': 'net_theta_per_trading_day',
    'net_vega': 'net_vega',
    'net_vega_abs': 'net_vega_abs',
    'net_vega_pct': 'net_vega_pct',
}

# Default scoring weights. User can modify.
DEFAULT_WEIGHTS = {
    'theta': 0.25,            # prefer high short-theta
    'vega': 0.20,             # prefer opportunities where short vega benefits
    'writer_strength': 0.15,  # call-writer dominance if seeking upside cap
    'pcr': 0.10,              # lower PCR (call-dominant) preferred for upside cap
    'oi_zscore': 0.10,        # stable or neutral oi zscore preferred
    'roll_cost': 0.10,        # lower roll cost preferred
    'term_slope': 0.10,       # mild contango preferred
}

# Safe defaults when columns missing
SAFE_DEFAULTS = {
    'net_theta': 0.0,
    'net_vega': 0.0,
    'writer_call_writer_strength_percent': 0.0,
    'writer_pcr_oi': 1.0,
    'current_oi_zscore': 0.0,
    'roll_cost_percent_of_spot': 100.0,
    'term_structure_slope_percent': 0.0,
}

# --------------------------- Core functions ----------------------------

def canonicalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Rename dataframe columns to canonical names (lowercase) when mapping exists."""
    new_cols = {}
    for c in df.columns:
        key = c.strip().lower()
        if key in CANONICAL_MAP:
            new_cols[c] = CANONICAL_MAP[key]
        else:
            # If not mapped, leave as lowercased original
            new_cols[c] = key
    df = df.rename(columns=new_cols)
    return df


def try_parse_dates(df: pd.DataFrame, colnames: List[str]) -> pd.DataFrame:
    for c in colnames:
        if c in df.columns:
            try:
                df[c] = pd.to_datetime(df[c], errors='coerce')
            except Exception:
                df[c] = df[c]
    return df


def load_csv_flexible(path: str) -> pd.DataFrame:
    """Load CSV with flexible parsing and canonicalize column names."""
    logger.info(f"Loading {path}")
    df = pd.read_csv(path, dtype=str)
    df = canonicalize_columns(df)
    # try convert numeric columns where sensible
    for col in df.columns:
        if col in ('timestamp', 'analysis_end_date', 'analysis_start_date', 'expiry'):
            continue
        # attempt numeric coercion
        df[col] = pd.to_numeric(df[col], errors='ignore')
    df = try_parse_dates(df, ['timestamp', 'analysis_end_date', 'analysis_start_date', 'expiry'])
    return df


def pick_latest_per_symbol(df: pd.DataFrame, time_col_candidates: List[str]=None) -> pd.DataFrame:
    """If multiple rows per symbol, pick the latest according to available time columns."""
    if 'symbol' not in df.columns:
        return df
    time_cols = [c for c in ['analysis_end_date', 'timestamp'] if c in df.columns]
    if not time_cols:
        # no time info, return as-is
        return df
    # create composite latest_time
    df['_latest_time'] = pd.NaT
    for c in time_cols:
        df['_latest_time'] = df['_latest_time'].fillna(df[c])
    # sort and take last per symbol
    df_sorted = df.sort_values('_latest_time').groupby('symbol', as_index=False).last()
    df_sorted = df_sorted.drop(columns=['_latest_time'])
    return df_sorted


def smart_merge(fut: pd.DataFrame, greeks: pd.DataFrame) -> pd.DataFrame:
    """Merge using best available keys: (symbol + expiry) -> (symbol + analysis_end_date) -> symbol.
    The function returns a merged dataframe with suffixes.
    """
    left = fut.copy()
    right = greeks.copy()

    # attempt keys by canonical names
    key_options = []
    if 'symbol' in left.columns and 'symbol' in right.columns:
        # expiry names can differ; try a few common ones
        if 'expiry' in left.columns and 'expiry' in right.columns:
            key_options.append(['symbol', 'expiry'])
        if 'analysis_end_date' in left.columns and 'analysis_end_date' in right.columns:
            key_options.append(['symbol', 'analysis_end_date'])
        # fallback to symbol only
        key_options.append(['symbol'])

    for keys in key_options:
        try:
            merged = pd.merge(left, right, on=keys, how='outer', suffixes=('_fut', '_greeks'))
            # check how many rows have non-null values from both
            both_count = merged.dropna(subset=['symbol']).shape[0]
            if both_count > 0:
                logger.info(f"Merged using keys: {keys}")
                return merged
        except Exception as e:
            logger.debug(f"merge failed on {keys}: {e}")

    # final fallback: cartesian-like merge on symbol by taking latest per symbol on each
    left_latest = pick_latest_per_symbol(left)
    right_latest = pick_latest_per_symbol(right)
    merged = pd.merge(left_latest, right_latest, on='symbol', how='outer', suffixes=('_fut', '_greeks'))
    logger.info("Merged by symbol latest fallback")
    return merged


def safe_get(row: pd.Series, col: str):
    if col in row and pd.notna(row[col]):
        return row[col]
    return SAFE_DEFAULTS.get(col, np.nan)


def compute_scores(df: pd.DataFrame, weights: Dict[str, float]) -> pd.DataFrame:
    """Compute a composite score for short-straddle suitability.

    Each sub-score is normalized to 0..1 then combined by weights.
    Higher score = better candidate.
    """
    df = df.copy()

    # Ensure numeric columns exist, fill with safe defaults
    df['net_theta'] = pd.to_numeric(df.get('net_theta'), errors='coerce').fillna(SAFE_DEFAULTS['net_theta'])
    df['net_vega'] = pd.to_numeric(df.get('net_vega'), errors='coerce').fillna(SAFE_DEFAULTS['net_vega'])
    df['writer_call_writer_strength_percent'] = pd.to_numeric(df.get('writer_call_writer_strength_percent'), errors='coerce').fillna(SAFE_DEFAULTS['writer_call_writer_strength_percent'])
    df['writer_pcr_oi'] = pd.to_numeric(df.get('writer_pcr_oi'), errors='coerce').fillna(SAFE_DEFAULTS['writer_pcr_oi'])
    df['current_oi_zscore'] = pd.to_numeric(df.get('current_oi_zscore'), errors='coerce').fillna(SAFE_DEFAULTS['current_oi_zscore'])
    df['roll_cost_percent_of_spot'] = pd.to_numeric(df.get('roll_cost_percent_of_spot'), errors='coerce').fillna(SAFE_DEFAULTS['roll_cost_percent_of_spot'])
    df['term_structure_slope_percent'] = pd.to_numeric(df.get('term_structure_slope_percent'), errors='coerce').fillna(SAFE_DEFAULTS['term_structure_slope_percent'])

    # Sub-scores
    # theta_score: higher positive net_theta (meaning short theta) is better
    # Note: In your greeks snapshot net_theta may be negative for long options; our SAFE_DEFAULT assumes already-signed for short position
    # We'll take sign: prefer positive net_theta
    df['theta_score'] = df['net_theta'].clip(lower= -999)
    # normalize  between 0 and 1 using quantiles to be robust
    if df['theta_score'].nunique() > 1:
        q_low = df['theta_score'].quantile(0.05)
        q_high = df['theta_score'].quantile(0.95)
        df['theta_score_norm'] = ((df['theta_score'] - q_low) / (q_high - q_low)).clip(0,1)
    else:
        df['theta_score_norm'] = 0.5

    # vega_score: prefer opportunities where short vega magnitude is meaningful (abs(net_vega) larger)
    df['vega_score'] = df['net_vega'].abs()
    if df['vega_score'].nunique() > 1:
        q_low = df['vega_score'].quantile(0.05)
        q_high = df['vega_score'].quantile(0.95)
        df['vega_score_norm'] = ((df['vega_score'] - q_low) / (q_high - q_low)).clip(0,1)
    else:
        df['vega_score_norm'] = 0.5

    # writer strength: prefer strong call-writer dominance (if bullish-cap preferred); scale 0..1 from 0..100
    df['writer_strength_norm'] = (df['writer_call_writer_strength_percent'] / 100.0).clip(0,1)

    # PCR: prefer lower PCR (call-dominant). transform so lower -> higher score
    df['pcr'] = df['writer_pcr_oi'].replace(0, np.nan).fillna(1.0)
    df['pcr_norm'] = (1.0 - (df['pcr'] / df['pcr'].max())).clip(0,1) if df['pcr'].max() != 0 else 0.5

    # OI zscore: mild positive or near-zero is fine. we'll penalize extremes
    z = df['current_oi_zscore'].fillna(0)
    # convert to score where -2..2 => 1 (best), larger magnitude reduces score
    df['oi_zscore_norm'] = (1 - (z.abs() / max(1, z.abs().max()))).clip(0,1)

    # roll cost: prefer lower roll cost
    rc = df['roll_cost_percent_of_spot'].fillna(999)
    df['roll_cost_norm'] = (1 - (rc / max(1, rc.max()))).clip(0,1)

    # term slope: prefer slight contango (positive small). We'll map -5..+5 -> 0..1
    ts = df['term_structure_slope_percent'].fillna(0)
    df['term_slope_norm'] = ((ts + 5) / 10).clip(0,1)

    # composite
    df['composite_score'] = (
        weights['theta'] * df['theta_score_norm'] +
        weights['vega'] * df['vega_score_norm'] +
        weights['writer_strength'] * df['writer_strength_norm'] +
        weights['pcr'] * df['pcr_norm'] +
        weights['oi_zscore'] * df['oi_zscore_norm'] +
        weights['roll_cost'] * df['roll_cost_norm'] +
        weights['term_slope'] * df['term_slope_norm']
    )

    # convenience columns: expected_move (from vega if available)
    # approximate expected move (1 std) from net_vega: expected_move_pct = net_vega / 100 (this is heuristic)
    df['expected_move_pct'] = (df['net_vega'].abs() / 100.0).fillna(0)
    df['expected_move_points'] = df['expected_move_pct'] * df['spot'].astype(float).replace({np.nan:0})

    # clean up and return
    return df


def rank_and_output(merged: pd.DataFrame, out_path: str, top_n: int=20) -> pd.DataFrame:
    ranked = merged.sort_values('composite_score', ascending=False).reset_index(drop=True)
    ranked.index += 1
    # write CSV
    ranked.to_csv(out_path, index_label='rank')
    logger.info(f"Wrote ranked output to {out_path}")
    return ranked.head(top_n)


# --------------------------- CLI Entrypoint ----------------------------

def build_arg_parser():
    p = argparse.ArgumentParser(description='FNO Short-Straddle Scanner')
    p.add_argument('--fut', required=True, help='CSV path for futures/OI sheet')
    p.add_argument('--greeks', required=True, help='CSV path for greeks/options sheet')
    p.add_argument('--out', default='ranked_output.csv', help='Output ranked CSV path')
    p.add_argument('--top', type=int, default=20, help='How many top rows to print')
    return p


def main(argv=None):
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    fut = load_csv_flexible(args.fut)
    greeks = load_csv_flexible(args.greeks)

    merged = smart_merge(fut, greeks)

    # ensure spot numeric
    if 'spot' in merged.columns:
        merged['spot'] = pd.to_numeric(merged['spot'], errors='coerce').fillna(0.0)
    else:
        merged['spot'] = 0.0

    # compute scores
    scored = compute_scores(merged, DEFAULT_WEIGHTS)

    # output top N
    top_df = rank_and_output(scored, args.out, top_n=args.top)

    # print a compact view for the user
    display_cols = ['symbol', 'expiry', 'spot', 'total_credit', 'net_theta', 'net_vega', 'writer_call_writer_strength_percent', 'writer_pcr_oi', 'roll_cost_percent_of_spot', 'composite_score']
    available = [c for c in display_cols if c in top_df.columns]
    logger.info('Top candidates:')
    print(top_df[available].to_string(index=True))


if __name__ == '__main__':
    main()
