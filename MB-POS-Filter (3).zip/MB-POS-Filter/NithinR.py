from kiteconnect import KiteConnect
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import json
import os
import time
from typing import Dict, Optional, Tuple
import requests

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Kite Connect API credentials
API_KEY = "3bi2yh8g830vq3y6"  # Replace with your API key
ACCESS_TOKEN = "GwgL1EBcfdAS2YyJrESWbSNbBbUeNNi7"  # Replace with your access token

# Initialize Kite Connect
kite = KiteConnect(api_key=API_KEY)
kite.set_access_token(ACCESS_TOKEN)

# Input and output files
INPUT_CSV = "../data/MCAP-great2500.csv"
OUTPUT_CSV = "stock_analysis_results_NithinR.csv"
CACHE_FILE = "instrument_cache.json"
INSTRUMENTS_CACHE = "nse_instruments.json"

# Define the time period (34 days)
end_date = datetime.now()
start_date = end_date - timedelta(days=34)

# Criteria thresholds (adjust as needed)
MIN_AVG_VOLUME = 1_000  # Minimum average daily volume for liquidity
MAX_RANGE_PERCENT = 3  # Max (high-low)/close % for narrow range days
MIN_UP_DAYS_PERCENT = 65  # Minimum % of up days for strong buying force
MAX_DOWN_DAY_PERCENT = -4  # Max allowable single-day drop
MAX_PRICE_STD = 0.025  # Max standard deviation of close prices (as % of mean)
MAX_SLOPE = 0.025  # Max slope of linear regression (for consolidation)
RECENT_DAYS = 13  # Days to check for rejection
MAX_REJECTION_DROP = -3  # Max drop % for rejection candlestick

# Rate limit constants
HISTORICAL_RATE_LIMIT = 3  # 3 historical data requests per second
LTP_RATE_LIMIT = 10  # 10 LTP requests per second
DELAY = 1.0 / HISTORICAL_RATE_LIMIT  # Delay per historical request
MAX_RETRIES = 3  # Max retries for API calls
RETRY_DELAY = 1.0  # Delay between retries (seconds)

def load_instrument_cache() -> Dict[str, int]:
    """Load instrument token cache from JSON file."""
    if os.path.exists(CACHE_FILE):
        with open(CACHE_FILE, "r") as f:
            return json.load(f)
    return {}

def save_instrument_cache(cache: Dict[str, int]):
    """Save instrument token cache to JSON file."""
    with open(CACHE_FILE, "w") as f:
        json.dump(cache, f, indent=4)

def load_nse_instruments() -> Dict[str, Dict]:
    """Load or fetch NSE instruments list."""
    # Try to load from CSV format first (more reliable)
    csv_file = "../nse_instruments_2025-07-17.csv"
    if os.path.exists(csv_file):
        try:
            df = pd.read_csv(csv_file)
            # Filter for equity instruments only
            eq_df = df[df['instrument_type'] == 'EQ']
            instrument_dict = {}
            for _, row in eq_df.iterrows():
                instrument_dict[row['tradingsymbol']] = {
                    'instrument_token': row['instrument_token'],
                    'tradingsymbol': row['tradingsymbol'],
                    'name': row['name'],
                    'segment': row['segment'],
                    'exchange': row['exchange']
                }
            logging.info(f"Loaded {len(instrument_dict)} NSE equity instruments from CSV")
            return instrument_dict
        except Exception as e:
            logging.error(f"Error loading NSE instruments from CSV: {e}")
    
    # Fallback to JSON cache
    if os.path.exists(INSTRUMENTS_CACHE):
        try:
            with open(INSTRUMENTS_CACHE, "r") as f:
                return json.load(f)
        except Exception as e:
            logging.error(f"Error loading NSE instruments from JSON cache: {e}")
    
    # Last resort: fetch from API
    try:
        instruments = kite.instruments(exchange="NSE")
        instrument_dict = {i["tradingsymbol"]: i for i in instruments if i["segment"] == "NSE-EQ"}
        with open(INSTRUMENTS_CACHE, "w") as f:
            json.dump(instrument_dict, f, indent=4)
        logging.info(f"Fetched {len(instrument_dict)} NSE equity instruments from API")
        return instrument_dict
    except Exception as e:
        logging.error(f"Error fetching NSE instruments: {e}")
        return {}

def fetch_instrument_tokens(symbols: list, cache: Dict[str, int], nse_instruments: Dict[str, Dict]) -> Dict[str, int]:
    """Fetch instrument tokens for symbols, using cache and NSE instruments list."""
    missing_symbols = [s for s in symbols if s not in cache]
    invalid_symbols = [s for s in missing_symbols if s not in nse_instruments]
    if invalid_symbols:
        logging.warning(f"Invalid or non-NSE symbols ({len(invalid_symbols)}): {invalid_symbols[:10]}{'...' if len(invalid_symbols) > 10 else ''}")
        # Log detailed info for first few invalid symbols
        for symbol in invalid_symbols[:5]:
            logging.warning(f"  {symbol}: Not found in NSE instruments")

    valid_missing = [s for s in missing_symbols if s in nse_instruments]
    if not valid_missing:
        return cache

    # Batch LTP requests to respect rate limit (10 requests per second)
    new_tokens = {}
    for i in range(0, len(valid_missing), LTP_RATE_LIMIT):
        batch = valid_missing[i:i + LTP_RATE_LIMIT]
        for attempt in range(MAX_RETRIES):
            try:
                ltp_data = kite.ltp([f"NSE:{s}" for s in batch])
                for symbol in batch:
                    new_tokens[symbol] = ltp_data[f"NSE:{symbol}"]["instrument_token"]
                break
            except Exception as e:
                logging.error(f"Attempt {attempt + 1} failed for LTP batch {batch}: {e}")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY)
                else:
                    logging.error(f"Max retries reached for LTP batch {batch}")
        time.sleep(0.1)  # Small delay to avoid hitting LTP rate limit
    
    cache.update(new_tokens)
    save_instrument_cache(cache)
    return cache

def fetch_historical_data(symbol: str, instrument_token: int, start_date: datetime, end_date: datetime) -> Optional[pd.DataFrame]:
    """Fetch daily historical data for a given stock with retry logic."""
    for attempt in range(MAX_RETRIES):
        try:
            data = kite.historical_data(
                instrument_token=instrument_token,
                from_date=start_date.strftime("%Y-%m-%d"),
                to_date=end_date.strftime("%Y-%m-%d"),
                interval="day",
                continuous=False
            )
            df = pd.DataFrame(data)
            if df.empty:
                logging.warning(f"No historical data for {symbol}")
                return None
            if len(df) < 21:
                logging.warning(f"Only {len(df)} days of data for {symbol}, need 55")
                return None
            df["date"] = pd.to_datetime(df["date"])
            df.set_index("date", inplace=True)
            return df
        except requests.exceptions.RequestException as e:
            logging.error(f"Attempt {attempt + 1} failed for {symbol}: {e}")
            if attempt < MAX_RETRIES - 1:
                time.sleep(RETRY_DELAY)
        except Exception as e:
            logging.error(f"Unexpected error for {symbol}: {e}")
            break
    logging.error(f"Max retries reached for {symbol}")
    return None

def analyze_stock(df: pd.DataFrame, symbol: str) -> Tuple[bool, str, Dict]:
    """Analyze stock data based on the specified criteria and return metrics."""
    metrics = {
        "symbol": symbol,
        "meets_criteria": False, # Will be updated based on all checks
        "up_days_percent": np.nan,
        "avg_daily_return": np.nan,
        "narrow_range_percent": np.nan,
        "avg_volume": np.nan,
        "recent_volume": np.nan,
        "price_std": np.nan,
        "slope_normalized": np.nan,
        "min_daily_return": np.nan,
        "has_rejection": False, # Will be updated if rejection is found
        "reason": "" # Will be built from individual criteria status
    }
    criteria_status_list = []
    overall_meets_criteria = True

    if df is None or len(df) < 21: # Original check: 34 days required out of 55
        metrics["reason"] = "Insufficient data"
        return False, metrics["reason"], metrics

    # Prepare data
    df.loc[:, "daily_return"] = df["close"].pct_change() * 100
    df.loc[:, "up_day"] = df["close"] > df["open"]
    df.loc[:, "range"] = (df["high"] - df["low"]) / df["close"] * 100
    
    # --- Criterion 1: Strong Buying Force ---
    metrics["up_days_percent"] = df["up_day"].mean() * 100
    metrics["avg_daily_return"] = df["daily_return"].mean()
    passed_buying_force = (metrics["up_days_percent"] >= MIN_UP_DAYS_PERCENT and 
                           metrics["avg_daily_return"] > 0)
    overall_meets_criteria &= passed_buying_force
    status_msg = (f"Buying Force: {'Pass' if passed_buying_force else 'Fail'} "
                  f"(UpDays: {metrics['up_days_percent']:.1f}% [Min: {MIN_UP_DAYS_PERCENT}%], "
                  f"AvgReturn: {metrics['avg_daily_return']:.2f}% [Min: >0])")
    criteria_status_list.append(status_msg)

    # --- Criterion 2: Narrow Range Days ---
    metrics["narrow_range_percent"] = (df["range"] < MAX_RANGE_PERCENT).mean() * 100
    # Original logic: fail if narrow_range_percent < 50
    passed_narrow_range = (metrics["narrow_range_percent"] >= 50)
    overall_meets_criteria &= passed_narrow_range
    status_msg = (f"Narrow Range Days: {'Pass' if passed_narrow_range else 'Fail'} "
                  f"({metrics['narrow_range_percent']:.1f}% of days <{MAX_RANGE_PERCENT}% range [Min: 50%])")
    criteria_status_list.append(status_msg)

    # --- Criterion 3: Volume Contracted & 4. Liquid Script (related by avg_volume) ---
    metrics["avg_volume"] = df["volume"].mean()
    metrics["recent_volume"] = df["volume"][-10:].mean() # Last 10 days average volume

    # Criterion 3: Volume Contracted
    # Original logic: fail if recent_volume > avg_volume
    if pd.notna(metrics["recent_volume"]) and pd.notna(metrics["avg_volume"]) and metrics["avg_volume"] > 0:
         # Ensure avg_volume is not zero to avoid division by zero or misleading comparison if both are zero
        passed_volume_contracted = (metrics["recent_volume"] <= metrics["avg_volume"])
    elif pd.notna(metrics["recent_volume"]) and pd.notna(metrics["avg_volume"]) and metrics["recent_volume"] == 0 and metrics["avg_volume"] == 0:
        passed_volume_contracted = True # If both are zero, considered contracted
    else: # Handles NaN or avg_volume being zero when recent_volume is not.
        passed_volume_contracted = False
        
    overall_meets_criteria &= passed_volume_contracted
    status_msg = (f"Volume Contracted: {'Pass' if passed_volume_contracted else 'Fail'} "
                  f"(RecentVol: {metrics['recent_volume']:.0f}, AvgVol: {metrics['avg_volume']:.0f} [Recent <= Avg])")
    criteria_status_list.append(status_msg)

    # Criterion 4: Liquid Script
    passed_liquid_script = (pd.notna(metrics["avg_volume"]) and metrics["avg_volume"] >= MIN_AVG_VOLUME)
    overall_meets_criteria &= passed_liquid_script
    status_msg = (f"Liquidity: {'Pass' if passed_liquid_script else 'Fail'} "
                  f"(AvgVol: {metrics['avg_volume']:.0f} [Min: {MIN_AVG_VOLUME}])")
    criteria_status_list.append(status_msg)

    # --- Criterion 5: Linear Consolidation ---
    close_prices = df["close"]
    if len(close_prices) > 1 and close_prices.mean() != 0: # Ensure there's data and mean is not zero for normalization
        metrics["price_std"] = close_prices.std() / close_prices.mean()
        x = np.arange(len(close_prices))
        slope, _ = np.polyfit(x, close_prices, 1)
        metrics["slope_normalized"] = slope / close_prices.mean()
        
        passed_linear_consolidation = (metrics["price_std"] <= MAX_PRICE_STD and 
                                       abs(metrics["slope_normalized"]) <= MAX_SLOPE)
    else: # Not enough data for std/slope or mean is zero
        metrics["price_std"] = np.nan
        metrics["slope_normalized"] = np.nan
        passed_linear_consolidation = False # Cannot assess consolidation

    overall_meets_criteria &= passed_linear_consolidation
    status_msg = (f"Linear Consolidation: {'Pass' if passed_linear_consolidation else 'Fail'} "
                  f"(PriceStd: {metrics['price_std']:.4f} [Max: {MAX_PRICE_STD}], "
                  f"NormSlope: {metrics['slope_normalized']:.4f} [MaxAbs: {MAX_SLOPE}])")
    criteria_status_list.append(status_msg)

    # --- Criterion 6: No Big Down Day ---
    metrics["min_daily_return"] = df["daily_return"].min() # Excludes first NaN
    # Original logic: fail if min_daily_return < MAX_DOWN_DAY_PERCENT
    if pd.notna(metrics["min_daily_return"]):
        passed_no_big_down_day = (metrics["min_daily_return"] >= MAX_DOWN_DAY_PERCENT)
    else: # If all daily returns are NaN (e.g. only 1 data point for close prices)
        passed_no_big_down_day = True # Or False, depending on desired strictness. Assume True if no returns.
        
    overall_meets_criteria &= passed_no_big_down_day
    status_msg = (f"No Big Down Day: {'Pass' if passed_no_big_down_day else 'Fail'} "
                  f"(MinReturn: {metrics['min_daily_return']:.2f}% [MinAllowed: {MAX_DOWN_DAY_PERCENT}%])")
    criteria_status_list.append(status_msg)

    # --- Criterion 7: No Recent Rejection ---
    rejection_found_flag = False
    rejection_detail_msg = ""
    if len(df) >= RECENT_DAYS and pd.notna(metrics["avg_volume"]) and metrics["avg_volume"] > 0 :
        recent_df = df[-RECENT_DAYS:].copy() # Use .copy() to avoid SettingWithCopyWarning
        # Ensure 'open' is not zero before division
        recent_df.loc[:, "body"] = np.where(recent_df["open"] != 0, 
                                            (recent_df["close"] - recent_df["open"]) / recent_df["open"] * 100, 
                                            0) # Avoid division by zero
        
        for idx, row in recent_df.iterrows():
            if (pd.notna(row["body"]) and row["body"] < MAX_REJECTION_DROP and 
                pd.notna(row["volume"]) and row["volume"] > metrics["avg_volume"]): # avg_volume check from original
                rejection_found_flag = True
                rejection_detail_msg = f" on {idx.date()}"
                break
    metrics["has_rejection"] = rejection_found_flag
    passed_no_recent_rejection = not rejection_found_flag
    overall_meets_criteria &= passed_no_recent_rejection
    status_msg = (f"No Recent Rejection: {'Pass' if passed_no_recent_rejection else 'Fail'}{rejection_detail_msg} "
                  f"[Cond: Body < {MAX_REJECTION_DROP}% & Vol > AvgVol in last {RECENT_DAYS} days]")
    criteria_status_list.append(status_msg)

    # Finalizing
    metrics["meets_criteria"] = overall_meets_criteria
    metrics["reason"] = "; ".join(criteria_status_list)
    
    return metrics["meets_criteria"], metrics["reason"], metrics

def main():
    # Read input CSV
    try:
        input_df = pd.read_csv(INPUT_CSV)
        if "Symbol" not in input_df.columns:
            logging.error("Input CSV must contain a 'Symbol' column")
            return
        symbols = input_df["Symbol"].dropna().astype(str).tolist()
        if not symbols:
            logging.error("No valid symbols found in input CSV")
            return
    except Exception as e:
        logging.error(f"Error reading input CSV ({INPUT_CSV}): {e}")
        return

    # Load NSE instruments for validation
    nse_instruments = load_nse_instruments()

    # Load instrument token cache
    cache = load_instrument_cache()
    cache = fetch_instrument_tokens(symbols, cache, nse_instruments)

    results = []
    request_count = 0

    for symbol in symbols:
        logging.info(f"Analyzing {symbol}...")
        if symbol not in nse_instruments:
            logging.error(f"Invalid NSE symbol: {symbol}")
            results.append({
                "symbol": symbol,
                "meets_criteria": False,
                "reason": "Invalid NSE symbol",
                "up_days_percent": np.nan,
                "avg_daily_return": np.nan,
                "narrow_range_percent": np.nan,
                "avg_volume": np.nan,
                "recent_volume": np.nan,
                "price_std": np.nan,
                "slope_normalized": np.nan,
                "min_daily_return": np.nan,
                "has_rejection": False
            })
            continue

        instrument_token = cache.get(symbol)
        if not instrument_token:
            logging.error(f"No instrument token for {symbol}")
            results.append({
                "symbol": symbol,
                "meets_criteria": False,
                "reason": "No instrument token",
                "up_days_percent": np.nan,
                "avg_daily_return": np.nan,
                "narrow_range_percent": np.nan,
                "avg_volume": np.nan,
                "recent_volume": np.nan,
                "price_std": np.nan,
                "slope_normalized": np.nan,
                "min_daily_return": np.nan,
                "has_rejection": False
            })
            continue

        df = fetch_historical_data(symbol, instrument_token, start_date, end_date)
        meets_criteria, reason, metrics = analyze_stock(df, symbol)
        results.append(metrics)

        # Respect historical data rate limit (3 requests per second)
        request_count += 1
        if request_count % HISTORICAL_RATE_LIMIT == 0:
            time.sleep(DELAY)

    # Define data types for CSV
    dtype = {
        "symbol": str,
        "meets_criteria": bool,
        "up_days_percent": float,
        "avg_daily_return": float,
        "narrow_range_percent": float,
        "avg_volume": float,  # Stored as float to handle NaN, but represents int
        "recent_volume": float,  # Stored as float to handle NaN, but represents int
        "price_std": float,
        "slope_normalized": float,
        "min_daily_return": float,
        "has_rejection": bool,
        "reason": str
    }

    # Create DataFrame and save to CSV
    results_df = pd.DataFrame(results)
    results_df = results_df.astype({k: v for k, v in dtype.items() if k in results_df.columns})
    results_df.to_csv(OUTPUT_CSV, index=False, float_format="%.4f")

    # Print summary
    valid_count = sum(1 for r in results if r['reason'] != "Invalid NSE symbol" and r['reason'] != "No instrument token")
    invalid_count = len(results) - valid_count
    
    print(f"\nSymbol Validation Summary:")
    print(f"Total symbols processed: {len(results)}")
    print(f"Valid symbols: {valid_count}")
    print(f"Invalid symbols: {invalid_count}")
    print(f"Success rate: {valid_count/len(results)*100:.1f}%")
    
    print("\nAnalysis Results:")
    for result in results:
        status = "✓" if result['meets_criteria'] else "✗"
        print(f"{status} {result['symbol']}: {result['reason']}")

if __name__ == "__main__":
    main()