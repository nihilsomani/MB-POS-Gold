import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import matplotlib.pyplot as plt
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import warnings
import time
import json
import os
from typing import Dict, List, Optional, Tuple
warnings.filterwarnings('ignore')

class RRGScanner:
    def __init__(self, api_key, access_token, cache_dir='cache', 
                 weeks_back=21, momentum_period=5, tail_length=10, scoring_weights=None):
        """
        Initialize RRG Scanner with Kite Connect
        
        Args:
            api_key: Your Kite Connect API key
            access_token: Your Kite Connect access token
            cache_dir: Directory to store cached data
            weeks_back: Number of weeks for historical data (default: 21)
            momentum_period: Period for momentum calculation (default: 5)
            tail_length: Number of data points for tail visualization (default: 10)
            scoring_weights: Custom scoring weights dict
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Cache management
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        self.instruments_cache_file = os.path.join(cache_dir, 'nse_instruments.json')
        self.cache_expiry_hours = 24  # Cache expires after 24 hours
        
        # Rate limiting
        self.api_call_delay = 0.1  # 100ms delay between API calls
        self.max_retries = 3
        self.retry_delay = 5  # 5 seconds delay on retry
        
        # RRG Parameters
        self.weeks_back = weeks_back
        self.momentum_period = momentum_period
        self.tail_length = tail_length
        
        # Default scoring weights
        self.scoring_weights = scoring_weights or {
            'quadrant_scores': {
                'Leading': 90,
                'Improving': 70,
                'Weakening': 40,
                'Lagging': 20
            },
            'rs_ratio_multiplier': 0.4,
            'momentum_multiplier': 0.4,
            'distance_multiplier': 0.2,
            'movement_bonuses': {
                'toward_leading': 30,
                'toward_improving': 20,
                'toward_lagging_penalty': -15
            },
            'velocity_max_bonus': 25
        }
        
        # NSE sector indices mapping
        self.sector_indices = {
            'NIFTY AUTO': 'NIFTY AUTO',
            'NIFTY BANK': 'NIFTY BANK', 
            'NIFTY ENERGY': 'NIFTY ENERGY',
            'NIFTY FMCG': 'NIFTY FMCG',
            'NIFTY HEALTHCARE': 'NIFTY HEALTHCARE',
            'NIFTY IT': 'NIFTY IT',
            'NIFTY MEDIA': 'NIFTY MEDIA',
            'NIFTY METAL': 'NIFTY METAL',
            'NIFTY PHARMA': 'NIFTY PHARMA',
            'NIFTY PSU BANK': 'NIFTY PSU BANK',
            'NIFTY REALTY': 'NIFTY REALTY',
            'NIFTY PRIVATE BANK': 'NIFTY PRIVATE BANK'
        }
        
        self.benchmark = 'NIFTY 50'
        
        # Load instruments cache
        self.instruments_cache = self._load_instruments_cache()
    
    def _load_instruments_cache(self) -> Dict:
        """Load instruments from cache if valid, otherwise return empty dict"""
        try:
            if os.path.exists(self.instruments_cache_file):
                with open(self.instruments_cache_file, 'r') as f:
                    cache_data = json.load(f)
                
                # Check if cache is still valid
                cache_time = datetime.fromisoformat(cache_data.get('timestamp', '2000-01-01'))
                if (datetime.now() - cache_time).total_seconds() < self.cache_expiry_hours * 3600:
                    print(f"📁 Loaded {len(cache_data.get('instruments', []))} instruments from cache")
                    return cache_data.get('instruments', [])
                else:
                    print("🕐 Instruments cache expired, will refresh")
        except Exception as e:
            print(f"⚠️ Error loading cache: {e}")
        
        return []
    
    def _save_instruments_cache(self, instruments: List[Dict]):
        """Save instruments to cache"""
        try:
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'instruments': instruments
            }
            with open(self.instruments_cache_file, 'w') as f:
                json.dump(cache_data, f, indent=2)
            print(f"💾 Cached {len(instruments)} instruments")
        except Exception as e:
            print(f"⚠️ Error saving cache: {e}")
    
    def _rate_limit_delay(self):
        """Add delay between API calls to respect rate limits"""
        time.sleep(self.api_call_delay)
    
    def _api_call_with_retry(self, func, *args, **kwargs):
        """Make API call with retry logic and rate limiting"""
        for attempt in range(self.max_retries):
            try:
                self._rate_limit_delay()
                return func(*args, **kwargs)
            except Exception as e:
                if "Too many requests" in str(e) or "rate limit" in str(e).lower():
                    if attempt < self.max_retries - 1:
                        print(f"⏳ Rate limit hit, waiting {self.retry_delay}s before retry {attempt + 1}/{self.max_retries}")
                        time.sleep(self.retry_delay * (attempt + 1))  # Exponential backoff
                        continue
                raise e
        return None
        
    def get_historical_data(self, instrument_token, from_date, to_date, interval='week'):
        """
        Fetch historical data from Kite Connect with rate limiting
        
        Args:
            instrument_token: NSE instrument token
            from_date: Start date
            to_date: End date  
            interval: Data interval (day, week, month)
        
        Returns:
            DataFrame with OHLCV data
        """
        try:
            data = self._api_call_with_retry(
                self.kite.historical_data,
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            if data is None:
                return pd.DataFrame()
                
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date'])
                df.set_index('date', inplace=True)
            return df
        except Exception as e:
            print(f"Error fetching data for {instrument_token}: {e}")
            return pd.DataFrame()
    
    def get_instrument_token(self, tradingsymbol):
        """
        Get instrument token for a trading symbol using cache
        """
        try:
            # First check cache
            if self.instruments_cache:
                instrument = next((item for item in self.instruments_cache 
                                 if item['tradingsymbol'] == tradingsymbol), None)
                if instrument:
                    return instrument['instrument_token']
            
            # If not in cache, fetch from API and update cache
            print(f"🔄 Fetching instruments from API (not in cache)")
            instruments = self._api_call_with_retry(self.kite.instruments, "NSE")
            
            if instruments:
                # Update cache
                self._save_instruments_cache(instruments)
                self.instruments_cache = instruments
                
                # Find the instrument
                instrument = next((item for item in instruments 
                                 if item['tradingsymbol'] == tradingsymbol), None)
                return instrument['instrument_token'] if instrument else None
            
            return None
        except Exception as e:
            print(f"Error getting instrument token for {tradingsymbol}: {e}")
            return None
    
    def calculate_relative_strength(self, sector_data, benchmark_data):
        """
        Calculate relative strength ratio
        
        Args:
            sector_data: DataFrame with sector price data
            benchmark_data: DataFrame with benchmark price data
            
        Returns:
            Series with RS ratio
        """
        # Ensure both datasets have same index
        common_dates = sector_data.index.intersection(benchmark_data.index)
        sector_aligned = sector_data.loc[common_dates, 'close']
        benchmark_aligned = benchmark_data.loc[common_dates, 'close']
        
        # Calculate RS ratio (normalize to 100)
        rs_ratio = (sector_aligned / benchmark_aligned) * 100
        rs_ratio = rs_ratio / rs_ratio.iloc[0] * 100  # Normalize to start at 100
        
        return rs_ratio
    
    def calculate_rs_momentum(self, rs_ratio, period=10):
        """
        Calculate RS momentum (rate of change of RS)
        
        Args:
            rs_ratio: Series with RS ratio values
            period: Period for momentum calculation
            
        Returns:
            Series with RS momentum
        """
        rs_momentum = rs_ratio.pct_change(period) * 100 + 100
        return rs_momentum
    
    def get_quadrant(self, rs_ratio, rs_momentum, benchmark_rs=100, benchmark_momentum=100):
        """
        Determine which quadrant a security is in
        
        Returns:
            String indicating quadrant: 'Leading', 'Weakening', 'Lagging', 'Improving'
        """
        if rs_ratio >= benchmark_rs and rs_momentum >= benchmark_momentum:
            return 'Leading'
        elif rs_ratio < benchmark_rs and rs_momentum >= benchmark_momentum:
            return 'Weakening'
        elif rs_ratio < benchmark_rs and rs_momentum < benchmark_momentum:
            return 'Lagging'
        else:  # rs_ratio >= benchmark_rs and rs_momentum < benchmark_momentum
            return 'Improving'
    
    def calculate_rrg_data(self, weeks_back=None, momentum_period=None):
        """
        Calculate RRG data for all sectors
        
        Args:
            weeks_back: Number of weeks of historical data (uses instance default if None)
            momentum_period: Period for momentum calculation (uses instance default if None)
            
        Returns:
            DataFrame with RRG coordinates for each sector
        """
        # Use instance parameters if not provided
        weeks_back = weeks_back or self.weeks_back
        momentum_period = momentum_period or self.momentum_period
        
        end_date = datetime.now()
        start_date = end_date - timedelta(weeks=weeks_back)
        
        # Get benchmark data
        benchmark_token = self.get_instrument_token(self.benchmark)
        if not benchmark_token:
            raise ValueError(f"Could not find instrument token for {self.benchmark}")
            
        benchmark_data = self.get_historical_data(
            benchmark_token, start_date, end_date, 'week'
        )
        
        if benchmark_data.empty:
            raise ValueError("Could not fetch benchmark data")
        
        results = []
        
        for sector_name, sector_symbol in self.sector_indices.items():
            try:
                sector_token = self.get_instrument_token(sector_symbol)
                if not sector_token:
                    print(f"Skipping {sector_name}: No instrument token found")
                    continue
                    
                sector_data = self.get_historical_data(
                    sector_token, start_date, end_date, 'week'
                )
                
                if sector_data.empty:
                    print(f"Skipping {sector_name}: No data available")
                    continue
                
                # Calculate RS ratio and momentum
                rs_ratio = self.calculate_relative_strength(sector_data, benchmark_data)
                rs_momentum = self.calculate_rs_momentum(rs_ratio, momentum_period)
                
                # Get latest values
                current_rs = rs_ratio.iloc[-1] if not rs_ratio.empty else 100
                current_momentum = rs_momentum.iloc[-1] if not rs_momentum.empty else 100
                
                # Determine quadrant
                quadrant = self.get_quadrant(current_rs, current_momentum)
                
                # Calculate tail data (configurable length for visualization)
                tail_length = min(self.tail_length, len(rs_ratio))
                tail_rs = rs_ratio.iloc[-tail_length:].tolist()
                tail_momentum = rs_momentum.iloc[-tail_length:].tolist()
                
                results.append({
                    'Sector': sector_name,
                    'Symbol': sector_symbol,
                    'RS_Ratio': current_rs,
                    'RS_Momentum': current_momentum,
                    'Quadrant': quadrant,
                    'Tail_RS': tail_rs,
                    'Tail_Momentum': tail_momentum,
                    'Distance_from_Center': np.sqrt((current_rs - 100)**2 + (current_momentum - 100)**2)
                })
                
                print(f"✓ Processed {sector_name}: {quadrant}")
                
            except Exception as e:
                print(f"✗ Error processing {sector_name}: {e}")
                continue
        
        return pd.DataFrame(results)
    
    def scan_sectors(self):
        """
        Main scanning function - returns RRG analysis
        
        Returns:
            Dictionary with categorized sectors
        """
        print("🔍 Starting RRG Sector Scan...")
        print("=" * 50)
        
        try:
            rrg_data = self.calculate_rrg_data()
            
            if rrg_data.empty:
                return {"error": "No data could be processed"}
            
            # Categorize sectors by quadrant
            leading = rrg_data[rrg_data['Quadrant'] == 'Leading'].sort_values('Distance_from_Center', ascending=False)
            weakening = rrg_data[rrg_data['Quadrant'] == 'Weakening'].sort_values('RS_Ratio', ascending=False)
            lagging = rrg_data[rrg_data['Quadrant'] == 'Lagging'].sort_values('Distance_from_Center')
            improving = rrg_data[rrg_data['Quadrant'] == 'Improving'].sort_values('RS_Momentum', ascending=False)
            
            # Print results
            print("\n📈 LEADING QUADRANT (Buy Focus):")
            print("-" * 40)
            for _, row in leading.iterrows():
                print(f"  • {row['Sector']:<20} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
            
            print("\n📉 WEAKENING QUADRANT (Monitor/Correction):")
            print("-" * 40)
            for _, row in weakening.iterrows():
                print(f"  • {row['Sector']:<20} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
            
            print("\n🔻 LAGGING QUADRANT (Avoid/Value Play):")
            print("-" * 40)
            for _, row in lagging.iterrows():
                print(f"  • {row['Sector']:<20} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
            
            print("\n📊 IMPROVING QUADRANT (Early Entry):")
            print("-" * 40)
            for _, row in improving.iterrows():
                print(f"  • {row['Sector']:<20} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
            
            return {
                'data': rrg_data,
                'leading': leading,
                'weakening': weakening, 
                'lagging': lagging,
                'improving': improving,
                'summary': self._generate_summary(rrg_data)
            }
            
        except Exception as e:
            print(f"❌ Error in sector scan: {e}")
            return {"error": str(e)}
    
    def _generate_summary(self, rrg_data):
        """Generate trading summary and recommendations"""
        leading_count = len(rrg_data[rrg_data['Quadrant'] == 'Leading'])
        improving_count = len(rrg_data[rrg_data['Quadrant'] == 'Improving'])
        total_strong = leading_count + improving_count
        
        market_strength = "Strong" if total_strong >= 6 else "Moderate" if total_strong >= 3 else "Weak"
        
        return {
            'market_strength': market_strength,
            'leading_sectors': leading_count,
            'improving_sectors': improving_count,
            'total_opportunity': total_strong,
            'recommendation': self._get_recommendation(market_strength, total_strong)
        }
    
    def _get_recommendation(self, strength, total_strong):
        """Generate trading recommendation based on sector analysis"""
        if strength == "Strong":
            return f"🟢 Market shows broad strength with {total_strong} sectors in buy zones. Focus on leading sectors for momentum plays."
        elif strength == "Moderate":
            return f"🟡 Selective opportunity with {total_strong} strong sectors. Stock selection becomes crucial."
        else:
            return f"🔴 Limited sector strength detected. Consider defensive positioning or wait for better setup."
    
    def create_visual_plot(self, rrg_data):
        """
        Create interactive RRG plot using Plotly
        
        Args:
            rrg_data: DataFrame with RRG analysis results
        """
        if rrg_data.empty:
            print("No data to plot")
            return
        
        # Color mapping for quadrants
        color_map = {
            'Leading': '#00FF00',      # Green
            'Weakening': '#FFA500',    # Orange  
            'Lagging': '#FF0000',      # Red
            'Improving': '#0000FF'     # Blue
        }
        
        fig = go.Figure()
        
        # Add quadrant backgrounds
        fig.add_shape(type="rect", x0=100, y0=100, x1=120, y1=120,
                     fillcolor="rgba(0,255,0,0.1)", line=dict(width=0))
        fig.add_shape(type="rect", x0=80, y0=100, x1=100, y1=120,
                     fillcolor="rgba(255,165,0,0.1)", line=dict(width=0))
        fig.add_shape(type="rect", x0=80, y0=80, x1=100, y1=100,
                     fillcolor="rgba(255,0,0,0.1)", line=dict(width=0))
        fig.add_shape(type="rect", x0=100, y0=80, x1=120, y1=100,
                     fillcolor="rgba(0,0,255,0.1)", line=dict(width=0))
        
        # Plot each sector
        for _, row in rrg_data.iterrows():
            # Plot tail (historical path)
            if len(row['Tail_RS']) > 1:
                fig.add_trace(go.Scatter(
                    x=row['Tail_RS'],
                    y=row['Tail_Momentum'],
                    mode='lines',
                    line=dict(color=color_map[row['Quadrant']], width=2),
                    showlegend=False,
                    opacity=0.6
                ))
            
            # Plot current position
            fig.add_trace(go.Scatter(
                x=[row['RS_Ratio']],
                y=[row['RS_Momentum']],
                mode='markers+text',
                marker=dict(
                    color=color_map[row['Quadrant']],
                    size=12,
                    line=dict(color='black', width=2)
                ),
                text=[row['Sector']],
                textposition="top center",
                name=row['Quadrant'],
                showlegend=True if row['Sector'] == rrg_data['Sector'].iloc[0] else False
            ))
        
        # Add center lines
        fig.add_hline(y=100, line_dash="dash", line_color="gray")
        fig.add_vline(x=100, line_dash="dash", line_color="gray")
        
        # Add quadrant labels
        fig.add_annotation(x=110, y=110, text="LEADING", showarrow=False, font=dict(size=16, color="green"))
        fig.add_annotation(x=90, y=110, text="WEAKENING", showarrow=False, font=dict(size=16, color="orange"))
        fig.add_annotation(x=90, y=90, text="LAGGING", showarrow=False, font=dict(size=16, color="red"))
        fig.add_annotation(x=110, y=90, text="IMPROVING", showarrow=False, font=dict(size=16, color="blue"))
        
        fig.update_layout(
            title="Relative Rotation Graph - NSE Sectors vs Nifty 50",
            xaxis_title="Relative Strength",
            yaxis_title="RS Momentum",
            width=1000,
            height=800,
            template="plotly_white"
        )
        
        fig.show()
        return fig

# Example usage and custom scanner functions
class AdvancedRRGScanner(RRGScanner):
    """
    Extended RRG Scanner with additional features
    """
    
    def scan_custom_stocks(self, stock_list, benchmark='NIFTY 50'):
        """
        Scan custom list of stocks instead of sectors
        
        Args:
            stock_list: List of stock symbols to analyze
            benchmark: Benchmark index (default: NIFTY 50)
        
        Returns:
            RRG analysis for the stock list
        """
        print(f"🔍 Scanning {len(stock_list)} custom stocks vs {benchmark}...")
        
        # Similar implementation as calculate_rrg_data but for individual stocks
        end_date = datetime.now()
        start_date = end_date - timedelta(weeks=21)
        
        # Get benchmark data
        benchmark_token = self.get_instrument_token(benchmark)
        benchmark_data = self.get_historical_data(
            benchmark_token, start_date, end_date, 'week'
        )
        
        results = []
        for stock in stock_list:
            try:
                stock_token = self.get_instrument_token(stock)
                if not stock_token:
                    print(f"Skipping {stock}: No instrument token found")
                    continue
                    
                stock_data = self.get_historical_data(
                    stock_token, start_date, end_date, 'week'
                )
                
                if stock_data.empty:
                    print(f"Skipping {stock}: No data available")
                    continue
                
                rs_ratio = self.calculate_relative_strength(stock_data, benchmark_data)
                rs_momentum = self.calculate_rs_momentum(rs_ratio)
                
                current_rs = rs_ratio.iloc[-1]
                current_momentum = rs_momentum.iloc[-1]
                quadrant = self.get_quadrant(current_rs, current_momentum)
                
                # Calculate tail data for visualization
                tail_length = min(self.tail_length, len(rs_ratio))
                tail_rs = rs_ratio.iloc[-tail_length:].tolist()
                tail_momentum = rs_momentum.iloc[-tail_length:].tolist()
                
                results.append({
                    'Stock': stock,
                    'RS_Ratio': current_rs,
                    'RS_Momentum': current_momentum,
                    'Quadrant': quadrant,
                    'Tail_RS': tail_rs,
                    'Tail_Momentum': tail_momentum,
                    'Distance_from_Center': np.sqrt((current_rs - 100)**2 + (current_momentum - 100)**2)
                })
                
                print(f"✓ Processed {stock}: {quadrant}")
                
            except Exception as e:
                print(f"✗ Error processing {stock}: {e}")
                continue
        
        return pd.DataFrame(results)
    
    def scan_stocks_from_csv(self, csv_file_path, symbol_column='Symbol', benchmark='NIFTY 50'):
        """
        Scan stocks from a CSV file
        
        Args:
            csv_file_path: Path to CSV file containing stock symbols
            symbol_column: Name of the column containing stock symbols (default: 'Symbol')
            benchmark: Benchmark index (default: NIFTY 50)
        
        Returns:
            RRG analysis for the stocks in the CSV file
        """
        try:
            # Read CSV file
            df = pd.read_csv(csv_file_path)
            
            if symbol_column not in df.columns:
                print(f"❌ Column '{symbol_column}' not found in CSV file")
                print(f"Available columns: {list(df.columns)}")
                return pd.DataFrame()
            
            # Extract stock symbols
            stock_list = df[symbol_column].dropna().unique().tolist()
            
            print(f"📁 Loaded {len(stock_list)} stocks from {csv_file_path}")
            print(f"Stocks: {', '.join(stock_list[:10])}{'...' if len(stock_list) > 10 else ''}")
            
            # Perform RRG analysis
            results = self.scan_custom_stocks(stock_list, benchmark)
            
            if not results.empty:
                # Print results by quadrant
                self._print_stock_results(results)
                
                # Generate summary
                summary = self._generate_stock_summary(results)
                print(f"\n💡 {summary}")
            
            return results
            
        except FileNotFoundError:
            print(f"❌ CSV file not found: {csv_file_path}")
            return pd.DataFrame()
        except Exception as e:
            print(f"❌ Error reading CSV file: {e}")
            return pd.DataFrame()
    
    def _print_stock_results(self, results):
        """Print stock analysis results by quadrant"""
        leading = results[results['Quadrant'] == 'Leading'].sort_values('Distance_from_Center', ascending=False)
        weakening = results[results['Quadrant'] == 'Weakening'].sort_values('RS_Ratio', ascending=False)
        lagging = results[results['Quadrant'] == 'Lagging'].sort_values('Distance_from_Center')
        improving = results[results['Quadrant'] == 'Improving'].sort_values('RS_Momentum', ascending=False)
        
        print("\n📈 LEADING QUADRANT (Buy Focus):")
        print("-" * 40)
        for _, row in leading.iterrows():
            print(f"  • {row['Stock']:<15} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
        
        print("\n📉 WEAKENING QUADRANT (Monitor/Correction):")
        print("-" * 40)
        for _, row in weakening.iterrows():
            print(f"  • {row['Stock']:<15} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
        
        print("\n🔻 LAGGING QUADRANT (Avoid/Value Play):")
        print("-" * 40)
        for _, row in lagging.iterrows():
            print(f"  • {row['Stock']:<15} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
        
        print("\n📊 IMPROVING QUADRANT (Early Entry):")
        print("-" * 40)
        for _, row in improving.iterrows():
            print(f"  • {row['Stock']:<15} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
    
    def _generate_stock_summary(self, results):
        """Generate summary for stock analysis"""
        leading_count = len(results[results['Quadrant'] == 'Leading'])
        improving_count = len(results[results['Quadrant'] == 'Improving'])
        total_strong = leading_count + improving_count
        
        if total_strong >= len(results) * 0.6:
            return f"🟢 Strong stock selection with {total_strong}/{len(results)} stocks in buy zones"
        elif total_strong >= len(results) * 0.3:
            return f"🟡 Moderate opportunity with {total_strong}/{len(results)} strong stocks"
        else:
            return f"🔴 Limited strength with only {total_strong}/{len(results)} strong stocks"
    
    def get_top_opportunities(self, results, top_n=10):
        """
        Get top N opportunities based on intelligent scoring with tail angle and velocity
        
        Args:
            results: DataFrame with RRG analysis results
            top_n: Number of top opportunities to return
            
        Returns:
            DataFrame with top opportunities including tail analysis
        """
        if results.empty:
            return pd.DataFrame()
        
        # Add comprehensive opportunity scores with tail angle and velocity
        results = self._add_opportunity_scores(results)
        
        # Sort by opportunity score and return top N
        top_opportunities = results.nlargest(top_n, 'Opportunity_Score')
        
        # Select relevant columns for display
        display_columns = ['Stock', 'RS_Ratio', 'RS_Momentum', 'Quadrant', 
                          'Distance_from_Center', 'Tail_Angle', 'Velocity_Factor', 
                          'Movement_Direction', 'Opportunity_Score']
        
        # Only include columns that exist in the dataframe
        available_columns = [col for col in display_columns if col in top_opportunities.columns]
        
        return top_opportunities[available_columns]
    
    def export_results_to_csv(self, results, filename=None):
        """
        Export detailed results to CSV with proper formatting
        
        Args:
            results: DataFrame with RRG analysis results
            filename: Output filename (auto-generated if None)
        """
        if results.empty:
            print("❌ No results to export")
            return None
        
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"rrg_analysis_{timestamp}.csv"
        
        try:
            # Prepare data for export
            export_data = results.copy()
            
            # Round numerical columns
            numeric_columns = ['RS_Ratio', 'RS_Momentum', 'Distance_from_Center']
            for col in numeric_columns:
                if col in export_data.columns:
                    export_data[col] = export_data[col].round(2)
            
            # Add opportunity score if not present
            if 'Opportunity_Score' not in export_data.columns:
                export_data = self._add_opportunity_scores(export_data)
            
            # Sort by opportunity score
            if 'Opportunity_Score' in export_data.columns:
                export_data = export_data.sort_values('Opportunity_Score', ascending=False)
            
            # Export to CSV
            export_data.to_csv(filename, index=False)
            print(f"💾 Results exported to: {filename}")
            print(f"📊 Exported {len(export_data)} stocks with detailed analysis")
            
            return filename
            
        except Exception as e:
            print(f"❌ Error exporting to CSV: {e}")
            return None
    
    def _calculate_tail_angle_and_velocity(self, results):
        """
        Calculate tail angle and velocity factor for each stock
        
        Args:
            results: DataFrame with RRG analysis results
            
        Returns:
            DataFrame with added Tail_Angle and Velocity_Factor columns
        """
        results = results.copy()
        results['Tail_Angle'] = 0.0
        results['Velocity_Factor'] = 0.0
        results['Movement_Direction'] = 'Unknown'
        
        for idx, row in results.iterrows():
            try:
                tail_rs = row.get('Tail_RS', [])
                tail_momentum = row.get('Tail_Momentum', [])
                
                if len(tail_rs) >= 3 and len(tail_momentum) >= 3:
                    # Calculate deltas for last 3 points
                    delta_rs = tail_rs[-1] - tail_rs[-3]  # Last point - 3rd last point
                    delta_momentum = tail_momentum[-1] - tail_momentum[-3]
                    
                    # Calculate angle using atan2 (returns angle in radians)
                    import math
                    angle_radians = math.atan2(delta_momentum, delta_rs)
                    angle_degrees = math.degrees(angle_radians)
                    
                    # Normalize angle to 0-360 degrees
                    if angle_degrees < 0:
                        angle_degrees += 360
                    
                    results.at[idx, 'Tail_Angle'] = angle_degrees
                    
                    # Calculate velocity (magnitude of movement)
                    velocity = math.sqrt(delta_rs**2 + delta_momentum**2)
                    results.at[idx, 'Velocity_Factor'] = velocity
                    
                    # Determine movement direction
                    if 0 <= angle_degrees <= 90:
                        results.at[idx, 'Movement_Direction'] = 'Toward Leading'
                    elif 90 < angle_degrees <= 180:
                        results.at[idx, 'Movement_Direction'] = 'Toward Weakening'
                    elif 180 < angle_degrees <= 270:
                        results.at[idx, 'Movement_Direction'] = 'Toward Lagging'
                    else:  # 270 < angle_degrees <= 360
                        results.at[idx, 'Movement_Direction'] = 'Toward Improving'
                        
            except Exception as e:
                # If calculation fails, keep default values
                continue
                
        return results
    
    def _add_opportunity_scores(self, results):
        """Add opportunity scores to results with tail angle and velocity factors"""
        results = results.copy()
        
        # First calculate tail angle and velocity
        results = self._calculate_tail_angle_and_velocity(results)
        
        results['Opportunity_Score'] = 0.0
        
        # Get scoring weights
        weights = self.scoring_weights
        
        # Base quadrant scores (configurable)
        quadrant_scores = weights['quadrant_scores']
        for quadrant, score in quadrant_scores.items():
            mask = results['Quadrant'] == quadrant
            results.loc[mask, 'Opportunity_Score'] += score
        
        # RS ratio bonus (configurable multiplier)
        results['Opportunity_Score'] += results['RS_Ratio'] * weights['rs_ratio_multiplier']
        
        # Momentum bonus (configurable multiplier)
        results['Opportunity_Score'] += results['RS_Momentum'] * weights['momentum_multiplier']
        
        # Distance from center bonus (configurable multiplier)
        results['Opportunity_Score'] += results['Distance_from_Center'] * weights['distance_multiplier']
        
        # Movement bonuses (configurable)
        movement_bonuses = weights['movement_bonuses']
        
        # Movement toward Leading quadrant
        toward_leading_mask = results['Movement_Direction'] == 'Toward Leading'
        results.loc[toward_leading_mask, 'Opportunity_Score'] += movement_bonuses['toward_leading']
        
        # Movement toward Improving quadrant
        toward_improving_mask = results['Movement_Direction'] == 'Toward Improving'
        results.loc[toward_improving_mask, 'Opportunity_Score'] += movement_bonuses['toward_improving']
        
        # VELOCITY FACTOR BONUS - Higher velocity = stronger momentum
        # Normalize velocity and add as bonus (configurable max)
        max_velocity = results['Velocity_Factor'].max()
        if max_velocity > 0:
            velocity_bonus = (results['Velocity_Factor'] / max_velocity) * weights['velocity_max_bonus']
            results['Opportunity_Score'] += velocity_bonus
        
        # PENALTY for moving away from Leading quadrant
        away_from_leading_mask = results['Movement_Direction'] == 'Toward Lagging'
        results.loc[away_from_leading_mask, 'Opportunity_Score'] += movement_bonuses['toward_lagging_penalty']
        
        # Ensure no negative scores
        results['Opportunity_Score'] = results['Opportunity_Score'].clip(lower=0)
        
        return results
    
    def get_sector_stocks(self, sector_name):
        """
        Get list of stocks belonging to a specific sector
        This would need to be implemented based on your data source
        """
        # Placeholder - in practice, you'd maintain a mapping of stocks to sectors
        sector_stocks = {
            'NIFTY IT': ['TCS', 'INFY', 'HCLTECH', 'WIPRO', 'TECHM'],
            'NIFTY BANK': ['HDFCBANK', 'ICICIBANK', 'AXISBANK', 'KOTAKBANK', 'SBIN'],
            'NIFTY PHARMA': ['SUNPHARMA', 'DRREDDY', 'CIPLA', 'DIVISLAB', 'LUPIN'],
            # Add more sectors as needed
        }
        
        return sector_stocks.get(sector_name, [])
    
    def dual_timeframe_analysis(self):
        """
        Analyze RRG on both weekly and monthly timeframes for confirmation
        """
        print("🔍 Running Dual Timeframe RRG Analysis...")
        
        weekly_data = self.calculate_rrg_data(weeks_back=21, momentum_period=5)
        # For monthly, you'd modify the interval parameter in get_historical_data
        
        # Compare weekly vs monthly signals
        analysis = {}
        for _, weekly_row in weekly_data.iterrows():
            sector = weekly_row['Sector']
            weekly_quad = weekly_row['Quadrant']
            
            # Monthly analysis would be similar
            analysis[sector] = {
                'weekly': weekly_quad,
                'monthly': 'Leading',  # Placeholder
                'confluence': weekly_quad == 'Leading'  # Simplified
            }
        
        return analysis

# Usage example
def main():
    """
    Example of how to use the RRG Scanner
    """
    # Initialize scanner (you need to provide your Kite Connect credentials)
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "TYwf95Z3yAqnA1aNcmfZkQ8x8MgjGylv"
    
    try:
        scanner = RRGScanner(API_KEY, ACCESS_TOKEN)
        
        # Run sector analysis
        results = scanner.scan_sectors()
        
        if 'error' not in results:
            print("\n" + "="*60)
            print("📊 SCAN COMPLETE - SUMMARY")
            print("="*60)
            print(f"Market Strength: {results['summary']['market_strength']}")
            print(f"Leading Sectors: {results['summary']['leading_sectors']}")
            print(f"Improving Sectors: {results['summary']['improving_sectors']}")
            print(f"\n💡 {results['summary']['recommendation']}")
            
            # Create visualization
            #scanner.create_visual_plot(results['data'])
            
            # Advanced features
            advanced_scanner = AdvancedRRGScanner(API_KEY, ACCESS_TOKEN,weeks_back=26, momentum_period=5, tail_length=13)
            
            # Example 1: Scan specific stocks (hardcoded list)
            it_stocks = ['TCS', 'INFY', 'HCLTECH', 'WIPRO']
            print("\n🎯 IT Sector Stock Analysis (Hardcoded):")
            stock_analysis = advanced_scanner.scan_custom_stocks(it_stocks)
            
            # Example 2: Scan stocks from CSV file
            print("\n" + "="*60)
            print("📁 CSV FILE ANALYSIS")
            print("="*60)
            
            # Try to scan from CSV file (create sample if doesn't exist)
            csv_file = "data\\MCAP-great2500.csv"
            try:
                # Check if CSV exists, if not create a sample
                import os
                if not os.path.exists(csv_file):
                    print(f"📝 Creating sample CSV file: {csv_file}")
                    sample_data = {
                        'Symbol': ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR', 
                                 'ITC', 'SBIN', 'BHARTIARTL', 'KOTAKBANK', 'LT'],
                        'Company': ['Reliance Industries', 'Tata Consultancy Services', 'HDFC Bank', 
                                   'Infosys', 'Hindustan Unilever', 'ITC Limited', 'State Bank of India',
                                   'Bharti Airtel', 'Kotak Mahindra Bank', 'Larsen & Toubro'],
                        'Sector': ['Energy', 'IT', 'Banking', 'IT', 'FMCG', 'FMCG', 'Banking', 
                                  'Telecom', 'Banking', 'Infrastructure']
                    }
                    sample_df = pd.DataFrame(sample_data)
                    sample_df.to_csv(csv_file, index=False)
                    print(f"✅ Sample CSV created with {len(sample_df)} stocks")
                
                # Scan stocks from CSV
                csv_results = advanced_scanner.scan_stocks_from_csv(csv_file, symbol_column='Symbol')
                
                if not csv_results.empty:
                    # Get top 10 opportunities
                    print(f"\n🏆 TOP 10 OPPORTUNITIES:")
                    print("=" * 60)
                    top_10 = advanced_scanner.get_top_opportunities(csv_results, top_n=10)
                    for i, (_, row) in enumerate(top_10.iterrows(), 1):
                        # Format tail angle and velocity info
                        tail_info = ""
                        if 'Tail_Angle' in row and 'Velocity_Factor' in row:
                            tail_info = f" | Angle: {row['Tail_Angle']:.1f}° | Vel: {row['Velocity_Factor']:.2f}"
                        
                        movement_info = ""
                        if 'Movement_Direction' in row:
                            movement_info = f" | {row['Movement_Direction']}"
                        
                        print(f"{i:2d}. {row['Stock']:<15} | Score: {row['Opportunity_Score']:.1f} | "
                              f"RS: {row['RS_Ratio']:.2f} | Mom: {row['RS_Momentum']:.2f} | {row['Quadrant']}{tail_info}{movement_info}")
                    
                    # Export detailed results to CSV
                    csv_filename = advanced_scanner.export_results_to_csv(csv_results, "detailed_rrg_analysis.csv")
                    
                    # Create visualization
                    print(f"\n📊 Creating RRG visualization...")
                    advanced_scanner.create_visual_plot(csv_results)
                
            except Exception as e:
                print(f"❌ Error with CSV analysis: {e}")
            
    except Exception as e:
        print(f"❌ Scanner initialization failed: {e}")
        print("Please check your API credentials and connection")

if __name__ == "__main__":
    # Uncomment to run
    main()
    print("RRG Scanner loaded successfully!")
    print("Initialize with: scanner = RRGScanner(api_key, access_token)")
    print("Run scan with: results = scanner.scan_sectors()")