"""
Comprehensive Insight Scanner
Analyzes OITrendScanner.py output and generates enriched insights with:
- Short Straddle suitability scores and rankings
- Directional trade opportunities
- Risk classifications
- Actionable recommendations

Input: trend_results_adaptive_v10_nuance_*.csv (from OITrendScanner.py)
Output: comprehensive_insights_*.csv with all analysis
"""

import pandas as pd
import numpy as np
from datetime import datetime
import logging
import os
import sys

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("comprehensive_insight_scanner.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("ComprehensiveInsightScanner")

class ComprehensiveInsightScanner:
    """
    Post-processes OITrendScanner output to generate actionable insights
    Enhanced with IV percentile, event risk, and IV spike detection
    """
    
    def __init__(self, input_csv_path, options_screener_csv=None, greeks_csv=None):
        self.input_csv_path = input_csv_path
        self.options_screener_csv = options_screener_csv
        self.greeks_csv = greeks_csv
        self.df = None
        self.iv_data = None
        self.greeks_data = None
        self.output_timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # IV and Event Risk thresholds
        self.IV_PERCENTILE_MIN = 40  # Minimum IV percentile for selling premium
        self.IV_SPIKE_THRESHOLD = 2.0  # Absolute IV change threshold for spike
        self.EVENT_RISK_DAYS = 7  # Block straddles within X days of events
        self.IV_PERCENTILE_IDEAL = 60  # Ideal IV percentile (above this = bonus)
        
        # Greeks risk thresholds
        self.MAX_GAMMA_RISK = 0.10  # Maximum gamma at ATM (risk of rapid delta change)
        self.MIN_THETA_PER_DAY = 0.50  # Minimum theta decay per day (Rs per lot)
        self.MAX_VEGA_EXPOSURE = 200  # Maximum vega exposure (Rs per 1% IV change)
        
        # Greeks data adjustment (strangle vs straddle)
        # Greeks CSV uses ~15% delta strangle, but we trade ATM straddles
        # ATM options have higher theta decay (1.5-2x more than 15% delta OTM)
        self.THETA_ATM_ADJUSTMENT_FACTOR = 1.7  # Scale strangle theta to ATM equivalent
        
        # Long-term straddle holding (3-5 weeks) thresholds
        self.MIN_ENTRY_DTE = 10  # Minimum DTE for entry (10+ days to avoid final week gamma explosion)
        self.MIN_THETA_30_DAY = 15.0  # Minimum total theta expected over 30 days (Rs per lot)
        
    def load_data(self):
        """Load the OITrendScanner CSV output"""
        try:
            self.df = pd.read_csv(self.input_csv_path)
            logger.info(f"Loaded {len(self.df)} records from {self.input_csv_path}")
            logger.info(f"Columns: {len(self.df.columns)}")
            return True
        except FileNotFoundError:
            logger.error(f"Input file not found: {self.input_csv_path}")
            return False
        except Exception as e:
            logger.error(f"Error loading data: {e}")
            return False
    
    def load_iv_data(self):
        """Load and merge IV percentile and event risk data from options screener"""
        if not self.options_screener_csv:
            # Try to auto-detect latest options screener file
            import glob
            screener_files = glob.glob("options_screener_*.csv")
            if screener_files:
                self.options_screener_csv = max(screener_files, key=os.path.getmtime)
                logger.info(f"Auto-detected options screener file: {self.options_screener_csv}")
            else:
                logger.warning("No options screener CSV provided or found. IV/Event analysis will be skipped.")
                return False
        
        try:
            self.iv_data = pd.read_csv(self.options_screener_csv)
            logger.info(f"Loaded IV data for {len(self.iv_data)} instruments from {self.options_screener_csv}")
            
            # Rename Instrument to symbol for merging
            self.iv_data.rename(columns={'Instrument': 'symbol'}, inplace=True)
            
            # Select relevant columns
            iv_cols = ['symbol', 'ATMIV', 'ATMIVChange', 'IVPercentile', 'Event']
            self.iv_data = self.iv_data[iv_cols]
            
            # Convert Event column: '-' to None, dates to datetime
            self.iv_data['Event'] = self.iv_data['Event'].replace('-', None)
            self.iv_data['Event'] = pd.to_datetime(self.iv_data['Event'], errors='coerce')
            
            # Merge with main dataframe
            self.df = self.df.merge(self.iv_data, on='symbol', how='left')
            
            matched = self.df['ATMIV'].notna().sum()
            logger.info(f"IV data matched for {matched}/{len(self.df)} stocks")
            
            return True
            
        except FileNotFoundError:
            logger.warning(f"Options screener file not found: {self.options_screener_csv}")
            return False
        except Exception as e:
            logger.error(f"Error loading IV data: {e}")
            return False
    
    def load_greeks_data(self):
        """Load and merge Greeks data (theta, gamma, vega) from delta_strangle_scanner output"""
        if not self.greeks_csv:
            # Try to auto-detect latest Greeks file
            import glob
            greeks_files = glob.glob("kite_equal_delta_strangles_*.csv")
            greeks_files += glob.glob("MB-POS-Filter/F4/FOOI/kite_equal_delta_strangles_*.csv")
            if greeks_files:
                self.greeks_csv = max(greeks_files, key=os.path.getmtime)
                logger.info(f"Auto-detected Greeks file: {self.greeks_csv}")
            else:
                logger.warning("No Greeks CSV provided or found. Greeks analysis will be skipped.")
                return False
        
        try:
            self.greeks_data = pd.read_csv(self.greeks_csv)
            logger.info(f"Loaded Greeks data for {len(self.greeks_data)} instruments from {self.greeks_csv}")
            
            # Greeks CSV has columns like: symbol, ce_theta, pe_theta, net_theta_per_day, 
            # ce_gamma, pe_gamma, net_vega, etc.
            # For straddles, we need ATM strikes (delta ~0.5 for both calls and puts)
            # But the CSV may have strangle data, so we'll take the closest to ATM for each symbol
            
            # Aggregate to symbol level - take average or sum of CE and PE Greeks
            greeks_cols = {
                'net_theta_per_day': 'theta_per_day',
                'net_theta_per_trading_day': 'theta_per_trading_day',
                'net_vega': 'vega',
                'total_credit': 'straddle_credit',
                'be_upper': 'breakeven_upper',
                'be_lower': 'breakeven_lower',
                'min_be_distance_pct': 'min_be_distance_pct',
                'rom_pct': 'return_on_margin_pct'
            }
            
            # Group by symbol and take the first (most recent) or average
            if 'symbol' in self.greeks_data.columns:
                # Aggregate Greeks by symbol (average for multiple entries)
                numeric_cols = [col for col in self.greeks_data.columns 
                               if self.greeks_data[col].dtype in ['float64', 'int64']]
                
                greeks_summary = self.greeks_data.groupby('symbol')[numeric_cols].first().reset_index()
                
                # Select and rename key columns for merging
                greeks_for_merge = greeks_summary[['symbol'] + [col for col in greeks_cols.keys() if col in greeks_summary.columns]].copy()
                greeks_for_merge.rename(columns=greeks_cols, inplace=True)
                
                # Calculate combined gamma (CE + PE for ATM straddle)
                if 'ce_gamma' in greeks_summary.columns and 'pe_gamma' in greeks_summary.columns:
                    greeks_for_merge['gamma_atm'] = (
                        greeks_summary['ce_gamma'].fillna(0) + greeks_summary['pe_gamma'].fillna(0)
                    )
                
                # Merge with main dataframe
                self.df = self.df.merge(greeks_for_merge, on='symbol', how='left')
                
                matched = self.df['theta_per_day'].notna().sum()
                logger.info(f"Greeks data matched for {matched}/{len(self.df)} stocks")
                
                return True
            else:
                logger.warning("Greeks CSV missing 'symbol' column")
                return False
            
        except FileNotFoundError:
            logger.warning(f"Greeks file not found: {self.greeks_csv}")
            return False
        except Exception as e:
            logger.error(f"Error loading Greeks data: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False
    
    def load_expert_results(self, greeks_straddle_csv=None, greeks_directional_csv=None, claude_straddle_csv=None):
        """Merge specialist scanner outputs for context (no additional filtering)."""
        import glob
        
        try:
            if greeks_straddle_csv is None:
                straddle_files = glob.glob("greeks_straddles_*.csv")
                if straddle_files:
                    greeks_straddle_csv = max(straddle_files, key=os.path.getmtime)
            if greeks_directional_csv is None:
                directional_files = glob.glob("greeks_directional_*.csv")
                if directional_files:
                    greeks_directional_csv = max(directional_files, key=os.path.getmtime)
            if claude_straddle_csv is None:
                claude_candidates = glob.glob("fno_straddle_results*.csv") + glob.glob("claude_oi_results_*.csv")
                if claude_candidates:
                    claude_straddle_csv = max(claude_candidates, key=os.path.getmtime)
            
            if greeks_straddle_csv and os.path.exists(greeks_straddle_csv):
                try:
                    g_straddle = pd.read_csv(greeks_straddle_csv)
                    merge_cols = {'score': 'greeks_straddle_score', 'action': 'greeks_straddle_action', 'position_size': 'greeks_straddle_position'}
                    g_straddle = g_straddle.rename(columns=merge_cols)
                    self.df = self.df.merge(g_straddle[['symbol'] + [c for c in merge_cols.values() if c in g_straddle.columns]], on='symbol', how='left')
                    logger.info(f"Merged Greeks straddle expert results from {greeks_straddle_csv}")
                except Exception as e:
                    logger.warning(f"Failed to merge greeks straddle results: {e}")
            
            if greeks_directional_csv and os.path.exists(greeks_directional_csv):
                try:
                    g_dir = pd.read_csv(greeks_directional_csv)
                    dir_cols = {'score': 'greeks_directional_score', 'action': 'greeks_directional_action', 'instrument': 'greeks_directional_instrument'}
                    g_dir = g_dir.rename(columns=dir_cols)
                    keep_cols = ['symbol'] + [c for c in dir_cols.values() if c in g_dir.columns]
                    self.df = self.df.merge(g_dir[keep_cols], on='symbol', how='left')
                    logger.info(f"Merged Greeks directional expert results from {greeks_directional_csv}")
                except Exception as e:
                    logger.warning(f"Failed to merge greeks directional results: {e}")
            
            if claude_straddle_csv and os.path.exists(claude_straddle_csv):
                try:
                    claude_df = pd.read_csv(claude_straddle_csv)
                    rename_map = {}
                    if 'straddle_score' in claude_df.columns:
                        rename_map['straddle_score'] = 'claude_straddle_score'
                    if 'action' in claude_df.columns:
                        rename_map['action'] = 'claude_straddle_action'
                    if 'confidence' in claude_df.columns:
                        rename_map['confidence'] = 'claude_straddle_confidence'
                    claude_df = claude_df.rename(columns=rename_map)
                    keep = ['symbol'] + [v for v in rename_map.values()]
                    self.df = self.df.merge(claude_df[keep], on='symbol', how='left')
                    logger.info(f"Merged Claude straddle results from {claude_straddle_csv}")
                except Exception as e:
                    logger.warning(f"Failed to merge Claude results: {e}")
            
            return True
        except Exception as e:
            logger.warning(f"Expert result merge skipped: {e}")
            return False
    
    def analyze_iv_and_event_risks(self):
        """Analyze IV percentile, IV spikes, and event risks"""
        logger.info("Analyzing IV percentile and event risks...")
        
        # Initialize IV/Event risk columns
        self.df['iv_percentile_rank'] = None
        self.df['iv_current'] = None
        self.df['iv_change'] = None
        self.df['iv_suitable_for_selling'] = True
        self.df['iv_risk_level'] = 'Unknown'
        self.df['iv_risk_reason'] = ''
        self.df['event_date'] = None
        self.df['days_to_event'] = None
        self.df['event_risk_level'] = 'None'
        self.df['event_risk_blocked'] = False
        self.df['iv_spike_detected'] = False
        
        # If no IV data, return
        if 'IVPercentile' not in self.df.columns:
            logger.warning("IV data not available. Skipping IV/Event risk analysis.")
            return
        
        for idx, row in self.df.iterrows():
            # IV Percentile Analysis
            if pd.notna(row['IVPercentile']):
                iv_pct = row['IVPercentile']
                self.df.at[idx, 'iv_percentile_rank'] = iv_pct
                self.df.at[idx, 'iv_current'] = row.get('ATMIV')
                self.df.at[idx, 'iv_change'] = row.get('ATMIVChange')
                
                # IV Percentile Risk Classification
                if iv_pct < 30:
                    self.df.at[idx, 'iv_suitable_for_selling'] = False
                    self.df.at[idx, 'iv_risk_level'] = 'Very High'
                    self.df.at[idx, 'iv_risk_reason'] = f'CRITICAL: IV at {iv_pct}th percentile (< 30%) - Premium too cheap'
                elif iv_pct < self.IV_PERCENTILE_MIN:
                    self.df.at[idx, 'iv_suitable_for_selling'] = False
                    self.df.at[idx, 'iv_risk_level'] = 'High'
                    self.df.at[idx, 'iv_risk_reason'] = f'LOW IV: {iv_pct}th percentile (< 40%) - Poor risk/reward'
                elif iv_pct < 50:
                    self.df.at[idx, 'iv_risk_level'] = 'Medium'
                    self.df.at[idx, 'iv_risk_reason'] = f'Below-average IV: {iv_pct}th percentile - Acceptable but not ideal'
                elif iv_pct < self.IV_PERCENTILE_IDEAL:
                    self.df.at[idx, 'iv_risk_level'] = 'Low'
                    self.df.at[idx, 'iv_risk_reason'] = f'Average IV: {iv_pct}th percentile - Good for selling'
                else:
                    self.df.at[idx, 'iv_risk_level'] = 'Very Low'
                    self.df.at[idx, 'iv_risk_reason'] = f'HIGH IV: {iv_pct}th percentile (>= 60%) - Excellent for selling'
                
                # IV Spike Detection
                if pd.notna(row.get('ATMIVChange')):
                    iv_change = row['ATMIVChange']
                    if abs(iv_change) >= self.IV_SPIKE_THRESHOLD:
                        self.df.at[idx, 'iv_spike_detected'] = True
                        spike_type = 'UP' if iv_change > 0 else 'DOWN'
                        self.df.at[idx, 'iv_risk_reason'] += f' | IV SPIKE {spike_type}: {iv_change:+.1f} points'
                        if iv_change > 0:  # IV spiking up
                            self.df.at[idx, 'iv_suitable_for_selling'] = False
                            if self.df.at[idx, 'iv_risk_level'] in ['Low', 'Very Low']:
                                self.df.at[idx, 'iv_risk_level'] = 'High'
            
            # Event Risk Analysis
            if pd.notna(row.get('Event')):
                event_date = row['Event']
                if isinstance(event_date, str):
                    try:
                        event_date = pd.to_datetime(event_date)
                    except:
                        event_date = None
                
                if event_date and isinstance(event_date, pd.Timestamp):
                    self.df.at[idx, 'event_date'] = event_date.strftime('%Y-%m-%d')
                    
                    # Calculate days to event
                    today = pd.Timestamp.now().normalize()
                    days_to_event = (event_date - today).days
                    self.df.at[idx, 'days_to_event'] = days_to_event
                    
                    # Event risk classification
                    if days_to_event < 0:
                        self.df.at[idx, 'event_risk_level'] = 'Past Event'
                    elif days_to_event <= 3:
                        self.df.at[idx, 'event_risk_level'] = 'CRITICAL - Event Imminent'
                        self.df.at[idx, 'event_risk_blocked'] = True
                    elif days_to_event <= self.EVENT_RISK_DAYS:
                        self.df.at[idx, 'event_risk_level'] = f'HIGH - Event in {days_to_event} days'
                        self.df.at[idx, 'event_risk_blocked'] = True
                    elif days_to_event <= 14:
                        self.df.at[idx, 'event_risk_level'] = f'MEDIUM - Event in {days_to_event} days'
                    else:
                        self.df.at[idx, 'event_risk_level'] = f'Low - Event in {days_to_event} days'
        
        # Log summary
        unsuitable_iv = (~self.df['iv_suitable_for_selling']).sum()
        blocked_events = self.df['event_risk_blocked'].sum()
        iv_spikes = self.df['iv_spike_detected'].sum()
        
        logger.info(f"IV Risk Summary: {unsuitable_iv} stocks with unsuitable IV for selling")
        logger.info(f"Event Risk Summary: {blocked_events} stocks blocked by event risk")
        logger.info(f"IV Spike Summary: {iv_spikes} stocks with IV spikes detected")
    
    def analyze_greeks_risks(self):
        """Analyze Greeks-based risks (theta decay, gamma risk, vega exposure)"""
        logger.info("Analyzing Greeks risks...")
        logger.info(f"Theta adjustment factor: {self.THETA_ATM_ADJUSTMENT_FACTOR}x (strangle → ATM straddle)")
        
        # Initialize Greeks risk columns
        self.df['greeks_gamma_risk'] = 'Low'
        self.df['greeks_theta_quality'] = 'Good'
        self.df['greeks_vega_exposure'] = 'Low'
        self.df['greeks_suitable_for_straddle'] = True
        self.df['greeks_risk_reason'] = ''
        
        # Check if Greeks columns exist
        if 'theta_per_day' not in self.df.columns:
            logger.warning("Greeks data not available for risk analysis")
            return
        
        for idx, row in self.df.iterrows():
            reasons = []
            gamma_risk = 'Low'
            theta_quality = 'Good'
            vega_exposure = 'Low'
            suitable = True
            
            # 1. THETA ANALYSIS (Time Decay)
            # Note: Greeks CSV contains strangle data (~15% delta), but we trade ATM straddles
            # ATM options have higher theta decay, so we apply adjustment factor
            theta_per_day_raw = row.get('theta_per_day')
            if pd.notna(theta_per_day_raw):
                # Adjust strangle theta to ATM equivalent
                theta_per_day = theta_per_day_raw * self.THETA_ATM_ADJUSTMENT_FACTOR
                
                if theta_per_day < self.MIN_THETA_PER_DAY:
                    theta_quality = 'Poor'
                    reasons.append(f'Low theta decay: Rs {theta_per_day_raw:.2f}/day (ATM equiv: ~Rs {theta_per_day:.2f})')
                    suitable = False
                elif theta_per_day < 1.7:  # Adjusted from 1.0 for ATM
                    theta_quality = 'Moderate'
                    reasons.append(f'Moderate theta: Rs {theta_per_day_raw:.2f}/day (ATM equiv: ~Rs {theta_per_day:.2f})')
                else:
                    theta_quality = 'Excellent'
                    reasons.append(f'Good theta: Rs {theta_per_day_raw:.2f}/day (ATM equiv: ~Rs {theta_per_day:.2f})')
            else:
                theta_per_day = None
            
            # Calculate DTE once for all Greeks analysis
            days_to_expiry = row.get('trade_option_expiry')
            dte = None
            if pd.notna(days_to_expiry) and isinstance(days_to_expiry, str):
                try:
                    from datetime import datetime
                    expiry = datetime.strptime(days_to_expiry, '%Y-%m-%d')
                    dte = (expiry - datetime.now()).days
                except:
                    pass
            
            # 2. GAMMA ANALYSIS (Rate of Delta Change - Risk Increases Near Expiry)
            # Gamma = rate of change of delta. High gamma means delta changes rapidly with price moves.
            # Factors affecting gamma: DTE (primary), strike proximity to spot, IV
            # Gamma increases as: DTE decreases, strike approaches ATM, IV decreases
            gamma_atm = row.get('gamma_atm')
            
            if pd.notna(gamma_atm):
                # Gamma threshold adjustment: Stricter near expiry, lenient far out
                # At 0-7 DTE: gamma > 0.08 is dangerous (gamma explosion zone)
                # At 8-21 DTE: gamma > 0.10 is risky
                # At 22+ DTE: gamma > 0.12 is acceptable (more room for time decay)
                
                effective_gamma_threshold = self.MAX_GAMMA_RISK  # Default: 0.10
                
                if dte is not None:
                    if dte <= 7:
                        effective_gamma_threshold = 0.08  # Stricter near expiry
                    elif dte <= 21:
                        effective_gamma_threshold = 0.09
                    # else: 0.10 (default)
                
                if gamma_atm > effective_gamma_threshold:
                    gamma_risk = 'Very High'
                    reasons.append(f'HIGH GAMMA: {gamma_atm:.3f} (rapid delta changes - unstable position)')
                    suitable = False
                elif gamma_atm > 0.06:
                    gamma_risk = 'High'
                    reasons.append(f'Elevated gamma: {gamma_atm:.3f} (delta changes quickly)')
                elif gamma_atm > 0.03:
                    gamma_risk = 'Medium'
                    reasons.append(f'Moderate gamma: {gamma_atm:.3f}')
                # Low gamma = good (stable delta, predictable position)
            
            # 3. VEGA ANALYSIS (IV Sensitivity)
            vega = row.get('vega')
            if pd.notna(vega):
                vega_abs = abs(vega)
                if vega_abs > self.MAX_VEGA_EXPOSURE:
                    vega_exposure = 'Very High'
                    reasons.append(f'HIGH VEGA: Rs {vega_abs:.0f} per 1% IV change')
                    if vega_abs > 300:
                        suitable = False  # Only block extreme vega
                elif vega_abs > 150:
                    vega_exposure = 'High'
                    reasons.append(f'Elevated vega: Rs {vega_abs:.0f}/1% IV')
                elif vega_abs > 100:
                    vega_exposure = 'Medium'
                    reasons.append(f'Moderate vega: Rs {vega_abs:.0f}/1% IV')
                # Low vega = good (less sensitive to IV changes)
            
            # 4. LONG-TERM HOLDING ANALYSIS (3-5 weeks)
            # For your strategy: Entry in last week of prev expiry / 1st week of current month
            # Hold until last week (3-5 weeks = 21-35 days)
            # (DTE already calculated above)
            
            if dte is not None:
                # Check if entry DTE is suitable (avoid final week gamma explosion)
                if dte < self.MIN_ENTRY_DTE:
                    reasons.append(f'INSUFFICIENT DTE: {dte} days (need {self.MIN_ENTRY_DTE}+ days to avoid final week gamma risk)')
                    suitable = False
                elif dte >= 10:
                    # Calculate expected theta accumulation over holding period
                    if pd.notna(theta_per_day):
                        # Estimate theta over 30 days (assuming theta decay curve)
                        # Early days have more theta, later days have less
                        # Rough estimate: 70% of daily theta * 30 days
                        estimated_30d_theta = theta_per_day * 30 * 0.7
                        if estimated_30d_theta >= self.MIN_THETA_30_DAY:
                            reasons.append(f'Good long-term theta: ~Rs {estimated_30d_theta:.0f} over 30 days')
                        else:
                            reasons.append(f'Low theta accumulation: ~Rs {estimated_30d_theta:.0f} over 30 days')
                    
                    # Warn about gamma increase as position ages
                    if pd.notna(gamma_atm):
                        if gamma_atm > 0.04:  # Even moderate gamma can become dangerous
                            reasons.append(f'Watch gamma progression: Will increase as DTE → 7 days')
                    
                    # Vega warning for long holds
                    if pd.notna(vega):
                        if abs(vega) > 120:
                            reasons.append(f'Vega exposure: Rs {abs(vega):.0f}/1% IV (monitor IV changes over 3-5 weeks)')
            
            # 5. BREAKEVEN DISTANCE (from Greeks calculation)
            min_be_dist = row.get('min_be_distance_pct')
            if pd.notna(min_be_dist):
                if min_be_dist < 2.0:
                    reasons.append(f'Narrow breakeven: {min_be_dist:.1f}% (tight profit zone)')
                elif min_be_dist > 8.0:
                    # Large BE = good (wide profit zone)
                    reasons.append(f'Wide breakeven: {min_be_dist:.1f}% (comfortable profit zone)')
            
            # Set final values
            self.df.at[idx, 'greeks_gamma_risk'] = gamma_risk
            self.df.at[idx, 'greeks_theta_quality'] = theta_quality
            self.df.at[idx, 'greeks_vega_exposure'] = vega_exposure
            self.df.at[idx, 'greeks_suitable_for_straddle'] = suitable
            self.df.at[idx, 'greeks_risk_reason'] = ' | '.join(reasons) if reasons else 'Greeks metrics acceptable'
        
        # Log summary
        unsuitable_greeks = (~self.df['greeks_suitable_for_straddle']).sum()
        high_gamma = (self.df['greeks_gamma_risk'].isin(['High', 'Very High'])).sum()
        poor_theta = (self.df['greeks_theta_quality'] == 'Poor').sum()
        high_vega = (self.df['greeks_vega_exposure'].isin(['High', 'Very High'])).sum()
        
        logger.info(f"Greeks Risk Summary: {unsuitable_greeks} stocks unsuitable due to Greeks")
        logger.info(f"Gamma Risk: {high_gamma} stocks with high/very high gamma")
        logger.info(f"Theta Quality: {poor_theta} stocks with poor theta decay")
        logger.info(f"Vega Exposure: {high_vega} stocks with high/very high vega")
    
    def analyze_oi_spatial_patterns(self):
        """Analyze OI spatial distribution for skew, concentration, and spread detection"""
        logger.info("Analyzing OI spatial patterns (skew, concentration, spreads)...")
        
        # Initialize OI spatial columns
        self.df['oi_skew_type'] = 'Balanced'
        self.df['oi_directional_bias'] = 'Neutral'
        self.df['oi_spread_detected'] = False
        self.df['oi_spatial_suitable_for_straddle'] = True
        self.df['oi_spatial_risk_level'] = 'Low'
        self.df['oi_spatial_risk_reason'] = ''
        
        # Required columns from Phase 1
        required_cols = [
            'spot_price', 'writer_max_call_oi_strike', 'writer_max_put_oi_strike',
            'writer_call_oi_concentration_pct', 'writer_put_oi_concentration_pct',
            'writer_second_call_oi_ratio', 'writer_second_put_oi_ratio'
        ]
        
        missing_cols = [col for col in required_cols if col not in self.df.columns]
        if missing_cols:
            logger.warning(f"Missing OI spatial columns: {missing_cols}. Skipping OI spatial analysis.")
            return
        
        for idx, row in self.df.iterrows():
            spot = row.get('spot_price')
            max_call_strike = row.get('writer_max_call_oi_strike')
            max_put_strike = row.get('writer_max_put_oi_strike')
            call_conc = row.get('writer_call_oi_concentration_pct', 0)
            put_conc = row.get('writer_put_oi_concentration_pct', 0)
            second_call_ratio = row.get('writer_second_call_oi_ratio', 0)
            second_put_ratio = row.get('writer_second_put_oi_ratio', 0)
            
            # Skip if key data is missing
            if pd.isna(spot) or pd.isna(max_call_strike) or pd.isna(max_put_strike):
                continue
            
            reasons = []
            risk_level = 'Low'
            suitable = True
            skew_type = 'Balanced'
            directional_bias = 'Neutral'
            spread_detected = False
            
            # 1. SKEW DETECTION: Check if max OI strikes suggest directional positioning
            # Bullish skew: Max put OI is ABOVE spot (protective puts/synthetic longs)
            # Bearish skew: Max call OI is BELOW spot (covered calls/synthetic shorts)
            
            if max_put_strike > spot:
                skew_type = 'Bullish_Inversion'
                directional_bias = 'Bullish'
                
                # High concentration = strong directional bias
                if put_conc > 40:
                    suitable = False
                    risk_level = 'Very High'
                    reasons.append(f'BULLISH SKEW: Max Put OI at {int(max_put_strike)} > Spot {spot:.0f} ({put_conc:.1f}% concentration)')
                elif put_conc > 30:
                    risk_level = 'High'
                    reasons.append(f'Moderate bullish skew: Max Put OI above spot ({put_conc:.1f}% concentration)')
                else:
                    risk_level = 'Medium'
                    reasons.append(f'Weak bullish skew: Max Put OI above spot but low concentration ({put_conc:.1f}%)')
            
            elif max_call_strike < spot:
                skew_type = 'Bearish_Inversion'
                directional_bias = 'Bearish'
                
                if call_conc > 40:
                    suitable = False
                    risk_level = 'Very High'
                    reasons.append(f'BEARISH SKEW: Max Call OI at {int(max_call_strike)} < Spot {spot:.0f} ({call_conc:.1f}% concentration)')
                elif call_conc > 30:
                    risk_level = 'High'
                    reasons.append(f'Moderate bearish skew: Max Call OI below spot ({call_conc:.1f}% concentration)')
                else:
                    risk_level = 'Medium'
                    reasons.append(f'Weak bearish skew: Max Call OI below spot but low concentration ({call_conc:.1f}%)')
            
            # 2. CONCENTRATION ANALYSIS (for normal skew): High concentration = directional bet
            else:
                if call_conc > 50 or put_conc > 50:
                    suitable = False
                    risk_level = 'Very High'
                    side = 'Call' if call_conc > put_conc else 'Put'
                    conc_val = max(call_conc, put_conc)
                    directional_bias = 'Bearish' if call_conc > put_conc else 'Bullish'
                    reasons.append(f'EXTREME {side.upper()} CONCENTRATION: {conc_val:.1f}% - Strong directional positioning')
                
                elif call_conc > 40 or put_conc > 40:
                    risk_level = 'High'
                    side = 'Call' if call_conc > put_conc else 'Put'
                    conc_val = max(call_conc, put_conc)
                    directional_bias = 'Bearish' if call_conc > put_conc else 'Bullish'
                    reasons.append(f'High {side} concentration: {conc_val:.1f}% - Moderate directional bias')
            
            # 3. SPREAD DETECTION: High second OI ratio suggests spread activity
            if second_call_ratio > 0.6 or second_put_ratio > 0.6:
                spread_detected = True
                if risk_level in ['Low', 'Medium']:  # Don't override high-risk classifications
                    risk_level = 'Medium'
                    reasons.append(f'SPREAD DETECTED: 2nd OI ratio high (C:{second_call_ratio:.2f}, P:{second_put_ratio:.2f}) - May be hedge activity')
            
            # 4. IDEAL SCENARIO: Balanced, low concentration
            if call_conc < 25 and put_conc < 25 and skew_type == 'Balanced':
                risk_level = 'Very Low'
                reasons.append(f'IDEAL OI DISTRIBUTION: Balanced & dispersed (C:{call_conc:.1f}%, P:{put_conc:.1f}%)')
            
            # Set final values
            self.df.at[idx, 'oi_skew_type'] = skew_type
            self.df.at[idx, 'oi_directional_bias'] = directional_bias
            self.df.at[idx, 'oi_spread_detected'] = spread_detected
            self.df.at[idx, 'oi_spatial_suitable_for_straddle'] = suitable
            self.df.at[idx, 'oi_spatial_risk_level'] = risk_level
            self.df.at[idx, 'oi_spatial_risk_reason'] = ' | '.join(reasons) if reasons else 'Balanced OI distribution'
        
        # Log summary
        unsuitable_oi = (~self.df['oi_spatial_suitable_for_straddle']).sum()
        bullish_skew = (self.df['oi_skew_type'] == 'Bullish_Inversion').sum()
        bearish_skew = (self.df['oi_skew_type'] == 'Bearish_Inversion').sum()
        spreads = self.df['oi_spread_detected'].sum()
        
        logger.info(f"OI Spatial Summary: {unsuitable_oi} stocks unsuitable due to OI skew/concentration")
        logger.info(f"Skew Detection: {bullish_skew} bullish, {bearish_skew} bearish inversions")
        logger.info(f"Spread Detection: {spreads} stocks with potential spread activity")
    
    def _normalize_zscore(self, series, reverse=False):
        """
        Normalize a series to z-scores (mean=0, std=1)
        
        Args:
            series: pandas Series to normalize
            reverse: If True, multiply by -1 (for lower-is-better metrics)
        
        Returns:
            Normalized Series
        """
        if series.empty or len(series) == 0:
            return series
        
        # Only normalize non-zero values (suitable candidates)
        mask = series != 0
        if mask.sum() < 2:  # Need at least 2 values to normalize
            return pd.Series([0.0] * len(series), index=series.index)
        
        mean_val = series[mask].mean()
        std_val = series[mask].std()
        
        if std_val == 0 or pd.isna(std_val):
            # No variance - return zeros or fixed value
            return pd.Series([0.0] * len(series), index=series.index)
        
        normalized = (series - mean_val) / std_val
        if reverse:
            normalized = normalized * -1
        
        return normalized
    
    def _get_expiry_phase(self, dte):
        """
        Determine expiry phase based on days to expiry
        
        Args:
            dte: Days to expiry (int or None)
        
        Returns:
            tuple: (phase_name, rollover_threshold_low, rollover_threshold_high)
                - phase_name: 'Early' (DTE > 20), 'Mid' (DTE 14-20), 'Late' (DTE 7-14), 'Final' (DTE < 7)
                - rollover_threshold_low: Minimum acceptable rollover % for this phase
                - rollover_threshold_high: Good rollover % for this phase
        """
        if dte is None or pd.isna(dte):
            # Default to Mid cycle if unknown
            return ('Mid', 30.0, 60.0)
        
        dte = int(dte)
        
        if dte > 20:
            # Early expiry: Rollover % will be artificially low (0-30% typical)
            # Focus on next_oi_change_percent instead
            return ('Early', 5.0, 30.0)
        elif dte > 14:
            # Mid expiry: Rollover % building (30-60% typical)
            return ('Mid', 30.0, 60.0)
        elif dte > 7:
            # Late expiry: High rollover expected (60-75% typical)
            return ('Late', 60.0, 75.0)
        else:
            # Final week: Very high rollover expected (75-90%+ typical)
            return ('Final', 75.0, 90.0)
    
    def calculate_straddle_metrics(self):
        """Calculate short straddle suitability metrics"""
        logger.info("Calculating short straddle metrics...")
        
        # Initialize columns
        self.df['straddle_suitable'] = False
        self.df['straddle_score'] = 0.0
        self.df['straddle_score_raw'] = 0.0  # NEW: Raw interpretable score
        self.df['straddle_score_normalized'] = 0.0  # NEW: Z-score normalized for ranking
        self.df['straddle_rank'] = 0
        self.df['straddle_tier'] = 'Not Suitable'
        self.df['straddle_risk_level'] = 'N/A'
        self.df['straddle_risk_factors'] = ''
        self.df['straddle_strengths'] = ''
        self.df['straddle_expected_range_lower'] = None
        self.df['straddle_expected_range_upper'] = None
        self.df['straddle_breakeven_lower'] = None
        self.df['straddle_breakeven_upper'] = None
        self.df['straddle_deployment_timing'] = 'N/A'
        self.df['straddle_failed_filters'] = ''  # NEW: Track which filters failed
        
        # Calculate average price momentum using REALIZED VOLATILITY (not directional change)
        # Prefer realized vol metrics if available, fallback to directional change
        if 'current_avg_abs_daily_move_pct' in self.df.columns and 'next_avg_abs_daily_move_pct' in self.df.columns:
            # Use realized volatility (avg absolute daily move)
            current_vol = self.df['current_avg_abs_daily_move_pct'].fillna(0)
            next_vol = self.df['next_avg_abs_daily_move_pct'].fillna(0)
            
            # Average the two (prefer next month if both available, current if next is missing)
            self.df['avg_price_momentum'] = pd.Series([
                next_vol.iloc[i] if pd.notna(next_vol.iloc[i]) and next_vol.iloc[i] > 0 
                else current_vol.iloc[i] if pd.notna(current_vol.iloc[i]) and current_vol.iloc[i] > 0
                else (current_vol.iloc[i] + next_vol.iloc[i]) / 2 if (pd.notna(current_vol.iloc[i]) and pd.notna(next_vol.iloc[i])) 
                else 0
                for i in range(len(self.df))
            ], index=self.df.index)
            
            logger.info("Using realized volatility (avg abs daily move) for price momentum")
        else:
            # Fallback: Use directional price change (old method)
            self.df['avg_price_momentum'] = (
                self.df['current_price_change_percent'].abs() + 
                self.df['next_price_change_percent'].abs()
            ) / 2
            logger.warning("Realized volatility columns not found - using directional price change (less accurate for straddles)")
        
        # Filter for straddle candidates (with IV, Event, and OI Spatial blocks)
        # Tier 1: Strict criteria for best quality
        tier1_mask = (
            (self.df['combined_sentiment'] == 'Neutral') &
            (self.df['confidence_percent'] >= 35) &
            (self.df['confidence_percent'] <= 50) &
            (self.df['writer_pcr_oi'] >= 0.70) &  # Relaxed from 0.75 (accommodate slight call writer bias)
            (self.df['writer_pcr_oi'] <= 1.30) &  # Relaxed from 1.25 (accommodate slight put writer bias)
            (self.df['avg_price_momentum'] <= 3.0) &
            (self.df['rollover_quality_index'] >= 6.5) &
            (self.df['oi_spatial_suitable_for_straddle'] == True)  # Phase 2: OI spatial check
        )
        
        # Tier 2 Borderline: RQI 5.5-6.5 with excellent supporting factors
        # For early rollover scenarios where next month already has OI
        # OR early expiry where rollover % is artificially low
        
        # Calculate DTE and expiry phase for each row
        self.df['expiry_phase'] = 'Unknown'
        self.df['dte_calculated'] = None
        for idx, row in self.df.iterrows():
            if pd.notna(row.get('trade_option_expiry')):
                try:
                    expiry_date = datetime.strptime(str(row['trade_option_expiry']), '%Y-%m-%d')
                    dte = (expiry_date - datetime.now()).days
                    self.df.at[idx, 'dte_calculated'] = dte
                    phase, _, _ = self._get_expiry_phase(dte)
                    self.df.at[idx, 'expiry_phase'] = phase
                except:
                    pass
        
        # Early expiry: Lower rollover threshold, focus on next_oi_change
        early_expiry_mask = self.df['expiry_phase'] == 'Early'
        normal_expiry_mask = ~early_expiry_mask
        
        # Standard borderline (Mid/Late/Final expiry) - requires 70% rollover
        tier2_borderline_normal = (
            (self.df['combined_sentiment'] == 'Neutral') &
            (self.df['confidence_percent'] >= 35) &
            (self.df['confidence_percent'] <= 50) &
            (self.df['writer_pcr_oi'] >= 0.70) &  # Relaxed from 0.75
            (self.df['writer_pcr_oi'] <= 1.30) &  # Relaxed from 1.25
            (self.df['avg_price_momentum'] <= 3.0) &
            (self.df['rollover_quality_index'] >= 5.5) &
            (self.df['rollover_quality_index'] < 6.5) &
            (self.df['rollover_percent'] >= 70.0) &  # Strong rollover % (supporting factor)
            (self.df['oi_spatial_suitable_for_straddle'] == True) &
            normal_expiry_mask
        )
        
        # Early expiry borderline: Relaxed rollover threshold, use next_oi_change instead
        if 'next_oi_change_percent' in self.df.columns:
            next_oi_series = self.df['next_oi_change_percent'].fillna(0)
        else:
            next_oi_series = pd.Series([0] * len(self.df), index=self.df.index)
        
        tier2_borderline_early = (
            (self.df['combined_sentiment'] == 'Neutral') &
            (self.df['confidence_percent'] >= 35) &
            (self.df['confidence_percent'] <= 50) &
            (self.df['writer_pcr_oi'] >= 0.70) &  # Relaxed from 0.75
            (self.df['writer_pcr_oi'] <= 1.30) &  # Relaxed from 1.25
            (self.df['avg_price_momentum'] <= 3.0) &
            (self.df['rollover_quality_index'] >= 5.5) &
            (self.df['rollover_quality_index'] < 6.5) &
            (
                (self.df['rollover_percent'] >= 15.0) |  # Relaxed: 15%+ acceptable in early expiry
                (next_oi_series >= 20.0)  # OR strong next OI buildup
            ) &
            (self.df['oi_spatial_suitable_for_straddle'] == True) &
            early_expiry_mask
        )
        
        tier2_borderline_mask = tier2_borderline_normal | tier2_borderline_early
        
        # Combine masks
        straddle_mask = tier1_mask | tier2_borderline_mask
        
        self.df.loc[straddle_mask, 'straddle_suitable'] = True
        
        # NEW: Track failed filters for each stock
        for idx, row in self.df.iterrows():
            failed_filters = []
            
            # Check each filter individually
            if row['combined_sentiment'] != 'Neutral':
                failed_filters.append(f"Sentiment: {row['combined_sentiment']} (need Neutral)")
            
            if not (35 <= row['confidence_percent'] <= 50):
                failed_filters.append(f"Confidence: {row['confidence_percent']:.1f}% (need 35-50%)")
            
            if not (0.70 <= row['writer_pcr_oi'] <= 1.30):
                failed_filters.append(f"PCR: {row['writer_pcr_oi']:.2f} (need 0.70-1.30)")
            
            if row['avg_price_momentum'] > 3.0:
                failed_filters.append(f"Price Momentum: {row['avg_price_momentum']:.2f}% (need <= 3.0%)")
            
            if row['rollover_quality_index'] < 6.5:
                # Check if borderline (RQI 5.5-6.5 with supporting factors)
                if row['rollover_quality_index'] < 5.5:
                    failed_filters.append(f"RQI: {row['rollover_quality_index']:.1f} (need >= 6.5, or 5.5-6.5 with strong rollover)")
                elif row['rollover_quality_index'] < 6.5:
                    # Check if it would pass borderline criteria
                    phase = row.get('expiry_phase', 'Unknown')
                    rollover_pct = row.get('rollover_percent', 0)
                    next_oi_chg = row.get('next_oi_change_percent', 0)
                    
                    if phase == 'Early':
                        if rollover_pct < 15.0 and next_oi_chg < 20.0:
                            failed_filters.append(f"RQI: {row['rollover_quality_index']:.1f} (need >= 6.5, or 5.5-6.5 with rollover >= 15% or next OI >= 20%)")
                    else:
                        if rollover_pct < 70.0:
                            failed_filters.append(f"RQI: {row['rollover_quality_index']:.1f} (need >= 6.5, or 5.5-6.5 with rollover >= 70%)")
            
            if 'oi_spatial_suitable_for_straddle' in self.df.columns:
                if row.get('oi_spatial_suitable_for_straddle') != True:
                    oi_risk = row.get('oi_spatial_risk_level', 'Unknown')
                    failed_filters.append(f"OI Spatial: {oi_risk} risk (need suitable)")
            
            if 'greeks_suitable_for_straddle' in self.df.columns:
                if row.get('greeks_suitable_for_straddle') != True:
                    greeks_reason = row.get('greeks_risk_reason', 'Greeks not suitable')
                    failed_filters.append(f"Greeks: {greeks_reason}")
            
            if 'iv_suitable_for_selling' in self.df.columns:
                if row.get('iv_suitable_for_selling') != True:
                    iv_pct = row.get('iv_percentile_rank', '?')
                    failed_filters.append(f"IV: {iv_pct}th percentile (pref >= 55th)")
            
            if 'event_risk_blocked' in self.df.columns:
                if row.get('event_risk_blocked') == True:
                    event_date = row.get('event_date', 'Unknown')
                    days_to_event = row.get('days_to_event', '?')
                    failed_filters.append(f"Event Risk: Event on {event_date} ({days_to_event} days away)")
            
            # Store failed filters
            if failed_filters:
                self.df.at[idx, 'straddle_failed_filters'] = ' | '.join(failed_filters)
            else:
                # If no failed filters but still not suitable, mark as passed all filters
                if not row['straddle_suitable']:
                    self.df.at[idx, 'straddle_failed_filters'] = 'Passed all filters but not in Tier 1/2'
        
        # Mark borderline cases for special handling
        self.df['straddle_borderline'] = False
        borderline_candidates = tier2_borderline_mask & straddle_mask
        self.df.loc[borderline_candidates, 'straddle_borderline'] = True
        
        # Calculate composite straddle score (0-100) - RAW SCORE (interpretable)
        price_stability = 100 - (self.df['avg_price_momentum'] * 10)
        pcr_balance = 100 - (abs(self.df['writer_pcr_oi'] - 1.0) * 100)
        low_conviction = 100 - self.df['confidence_percent']
        quality_score = self.df['rollover_quality_index'] * 10
        
        self.df['straddle_score_raw'] = (
            price_stability * 0.35 +
            pcr_balance * 0.25 +
            low_conviction * 0.20 +
            quality_score * 0.20
        )
        
        # Apply borderline penalty: Reduce score by 5 points for RQI 5.5-6.5 cases
        # This ensures they rank lower than Tier 1 but are still included
        self.df.loc[self.df['straddle_borderline'] == True, 'straddle_score_raw'] = (
            self.df.loc[self.df['straddle_borderline'] == True, 'straddle_score_raw'] - 5.0
        )
        
        # Only score suitable candidates
        self.df.loc[~straddle_mask, 'straddle_score_raw'] = 0.0
        
        # HYBRID: Calculate normalized scores for stable ranking (when >= 5 candidates)
        suitable_df = self.df[self.df['straddle_suitable']].copy()
        if len(suitable_df) >= 5:
            # Normalize individual features first, then combine
            price_momentum_norm = self._normalize_zscore(suitable_df['avg_price_momentum'], reverse=True)
            pcr_imbalance_norm = self._normalize_zscore(abs(suitable_df['writer_pcr_oi'] - 1.0), reverse=True)
            confidence_norm = self._normalize_zscore(suitable_df['confidence_percent'], reverse=True)
            rqi_norm = self._normalize_zscore(suitable_df['rollover_quality_index'], reverse=False)
            
            # Combine normalized features with same weights
            normalized_score = (
                price_momentum_norm * 0.35 +
                pcr_imbalance_norm * 0.25 +
                confidence_norm * 0.20 +
                rqi_norm * 0.20
            )
            
            # Apply borderline penalty to normalized score
            borderline_mask = suitable_df['straddle_borderline'] == True
            if borderline_mask.any():
                # Penalty as z-score (roughly -0.5 standard deviations)
                normalized_score[borderline_mask] = normalized_score[borderline_mask] - 0.5
            
            # Store normalized scores back to main dataframe
            for orig_idx in suitable_df.index:
                # Find the position in normalized_score
                if orig_idx in normalized_score.index:
                    self.df.at[orig_idx, 'straddle_score_normalized'] = normalized_score.at[orig_idx]
                else:
                    # Fallback: match by position
                    pos = list(suitable_df.index).index(orig_idx)
                    if pos < len(normalized_score):
                        self.df.at[orig_idx, 'straddle_score_normalized'] = normalized_score.iloc[pos]
            
            # Use normalized score for ranking (but preserve raw for display)
            self.df['straddle_score'] = self.df['straddle_score_normalized']
            logger.info(f"Using normalized scoring for {len(suitable_df)} straddle candidates")
        else:
            # < 5 candidates: Use raw scores (better interpretability with small samples)
            self.df['straddle_score'] = self.df['straddle_score_raw']
            self.df.loc[~straddle_mask, 'straddle_score_normalized'] = 0.0
            logger.info(f"Using raw scoring for {len(suitable_df)} straddle candidates (sample too small for normalization)")
        
        # Rank straddle candidates (using hybrid score)
        if len(suitable_df) > 0:
            suitable_df = self.df[self.df['straddle_suitable']].copy()
            suitable_df = suitable_df.sort_values('straddle_score', ascending=False).reset_index(drop=False)
            for rank_idx, orig_idx in enumerate(suitable_df['index'], 1):
                self.df.at[orig_idx, 'straddle_rank'] = rank_idx
            
            # Assign tiers based on rank and borderline status
            for idx, row in self.df[self.df['straddle_suitable']].iterrows():
                rank = row['straddle_rank']
                is_borderline = row.get('straddle_borderline', False)
                
                if is_borderline:
                    # Borderline cases: RQI 5.5-6.5 with good supporting factors
                    if rank <= 10:
                        self.df.at[idx, 'straddle_tier'] = 'Tier 2 Borderline (RQI 5.5-6.5)'
                    else:
                        self.df.at[idx, 'straddle_tier'] = 'Tier 3 Borderline (RQI 5.5-6.5)'
                else:
                    # Standard tier assignment
                    if rank <= 5:
                        self.df.at[idx, 'straddle_tier'] = 'Tier 1 (Best)'
                    elif rank <= 10:
                        self.df.at[idx, 'straddle_tier'] = 'Tier 2 (Good)'
                    elif rank <= 20:
                        self.df.at[idx, 'straddle_tier'] = 'Tier 3 (Acceptable)'
                    else:
                        self.df.at[idx, 'straddle_tier'] = 'Tier 4 (Lower Priority)'
        
        # Calculate risk levels and factors
        for idx, row in self.df[self.df['straddle_suitable']].iterrows():
            risk_factors = []
            strengths = []
            is_borderline = row.get('straddle_borderline', False)
            
            # Borderline cases start with Medium risk (RQI 5.5-6.5)
            if is_borderline:
                risk_level = 'Medium'
                risk_factors.append(f"Borderline RQI: {row['rollover_quality_index']:.1f} (5.5-6.5) - Early rollover scenario")
                # Add note about supporting factors
                if row['rollover_percent'] >= 75:
                    strengths.append(f"High Rollover ({row['rollover_percent']:.1f}%) - Offsets low RQI")
            else:
                risk_level = 'Low'
            
            # ====== NEW: IV and Event Risk Analysis ======
            # IV Percentile Risk
            if pd.notna(row.get('iv_percentile_rank')):
                iv_pct = row['iv_percentile_rank']
                if iv_pct >= self.IV_PERCENTILE_IDEAL:
                    strengths.append(f"High IV Percentile ({iv_pct}th) - Great for selling")
                elif iv_pct >= 50:
                    strengths.append(f"Good IV Percentile ({iv_pct}th)")
                # Note: Low IV already blocked from straddle_suitable
            
            # IV Spike Warning
            if row.get('iv_spike_detected', False):
                risk_factors.append(f"IV Spike Detected ({row.get('iv_change', 0):+.1f})")
                if risk_level == 'Low':
                    risk_level = 'Medium-High'
            
            # Event Risk (shouldn't appear if blocked, but check anyway)
            if row.get('event_risk_blocked', False):
                risk_factors.append(f"EVENT RISK: {row.get('event_risk_level', 'Unknown')}")
                risk_level = 'Very High'
            elif pd.notna(row.get('days_to_event')) and row['days_to_event'] <= 14:
                risk_factors.append(f"Event in {int(row['days_to_event'])} days")
                if risk_level == 'Low':
                    risk_level = 'Medium'
            
            # ====== Phase 2: OI Spatial Risk Analysis ======
            if row.get('oi_skew_type', 'Balanced') == 'Bullish_Inversion':
                oi_risk = row.get('oi_spatial_risk_level', 'Low')
                if oi_risk in ['Very High', 'High']:
                    risk_factors.append(f"BULLISH OI SKEW: {row.get('oi_spatial_risk_reason', 'Unknown')}")
                    if oi_risk == 'Very High':
                        risk_level = 'High'
                    elif risk_level == 'Low':
                        risk_level = 'Medium-High'
                else:
                    risk_factors.append(f"Weak bullish skew detected")
                    if risk_level == 'Low':
                        risk_level = 'Medium'
            
            elif row.get('oi_skew_type', 'Balanced') == 'Bearish_Inversion':
                oi_risk = row.get('oi_spatial_risk_level', 'Low')
                if oi_risk in ['Very High', 'High']:
                    risk_factors.append(f"BEARISH OI SKEW: {row.get('oi_spatial_risk_reason', 'Unknown')}")
                    if oi_risk == 'Very High':
                        risk_level = 'High'
                    elif risk_level == 'Low':
                        risk_level = 'Medium-High'
                else:
                    risk_factors.append(f"Weak bearish skew detected")
                    if risk_level == 'Low':
                        risk_level = 'Medium'
            
            elif row.get('oi_spatial_risk_level', 'Low') == 'Very Low':
                strengths.append(f"IDEAL OI Distribution - Balanced & dispersed")
            
            # Spread Detection
            if row.get('oi_spread_detected', False):
                risk_factors.append(f"Spread activity detected - May indicate hedging")
                if risk_level == 'Low':
                    risk_level = 'Medium'
            # ====== END Phase 2 ======
            
            # Analyze rollover risk (DTE-aware thresholds)
            # Calculate DTE from trade_option_expiry
            dte = None
            if pd.notna(row.get('trade_option_expiry')):
                try:
                    expiry_date = datetime.strptime(str(row['trade_option_expiry']), '%Y-%m-%d')
                    dte = (expiry_date - datetime.now()).days
                except:
                    pass
            
            phase, rollover_low, rollover_high = self._get_expiry_phase(dte)
            rollover_pct = row['rollover_percent']
            
            if phase == 'Early':
                # Early expiry: Rollover % artificially low, focus on next_oi_change
                next_oi_chg = row.get('next_oi_change_percent', 0)
                if rollover_pct < rollover_low and next_oi_chg < 15:
                    risk_factors.append(f"Early Expiry: Low Rollover ({rollover_pct:.1f}%) + Weak Next OI ({next_oi_chg:.1f}%)")
                    if risk_level == 'Low':
                        risk_level = 'Medium'
                elif rollover_pct >= rollover_high:
                    strengths.append(f"Early Expiry: Good Rollover ({rollover_pct:.1f}%) - Institutions Positioning Early")
                elif next_oi_chg >= 20:
                    strengths.append(f"Early Expiry: Strong Next OI Buildup ({next_oi_chg:.1f}%) - Rollover Building")
            elif phase == 'Mid':
                # Mid expiry: Moderate rollover expected
                if rollover_pct < rollover_low:
                    risk_factors.append(f"Mid Expiry: Low Rollover ({rollover_pct:.1f}% < {rollover_low:.0f}%)")
                    if risk_level == 'Low':
                        risk_level = 'Medium-High'
                elif rollover_pct < rollover_high:
                    risk_factors.append(f"Mid Expiry: Moderate Rollover ({rollover_pct:.1f}%)")
                    if risk_level == 'Low':
                        risk_level = 'Medium'
                else:
                    strengths.append(f"Good Rollover ({rollover_pct:.1f}%)")
            elif phase == 'Late':
                # Late expiry: High rollover critical
                if rollover_pct < rollover_low:
                    risk_factors.append(f"Late Expiry: Low Rollover ({rollover_pct:.1f}% < {rollover_low:.0f}%) - Critical Risk")
                    risk_level = 'High'
                elif rollover_pct < rollover_high:
                    risk_factors.append(f"Late Expiry: Moderate Rollover ({rollover_pct:.1f}%) - Should Be Higher")
                    if risk_level == 'Low':
                        risk_level = 'Medium-High'
                else:
                    strengths.append(f"Excellent Rollover ({rollover_pct:.1f}%) - Institutions Rolling")
            else:  # Final week
                # Final week: Very high rollover expected
                if rollover_pct < rollover_low:
                    risk_factors.append(f"Final Week: VERY LOW Rollover ({rollover_pct:.1f}% < {rollover_low:.0f}%) - MAJOR RISK")
                    risk_level = 'Very High'
                elif rollover_pct < rollover_high:
                    risk_factors.append(f"Final Week: Low Rollover ({rollover_pct:.1f}%) - Should Be 75%+")
                    risk_level = 'High'
                else:
                    strengths.append(f"Excellent Final Week Rollover ({rollover_pct:.1f}%) - Heavy Institutional Activity")
            
            # Analyze PCR
            if 0.95 <= row['writer_pcr_oi'] <= 1.05:
                strengths.append(f"Perfect PCR ({row['writer_pcr_oi']:.2f})")
            elif 0.85 <= row['writer_pcr_oi'] <= 1.15:
                strengths.append(f"Good PCR Balance ({row['writer_pcr_oi']:.2f})")
            else:
                risk_factors.append(f"PCR Imbalance ({row['writer_pcr_oi']:.2f})")
                if risk_level == 'Low':
                    risk_level = 'Medium'
            
            # Analyze volatility
            if row['avg_price_momentum'] < 0.5:
                strengths.append(f"Ultra-Low Vol ({row['avg_price_momentum']:.2f}%)")
            elif row['avg_price_momentum'] < 1.0:
                strengths.append(f"Low Vol ({row['avg_price_momentum']:.2f}%)")
            elif row['avg_price_momentum'] > 2.0:
                risk_factors.append(f"High Vol ({row['avg_price_momentum']:.2f}%)")
                if risk_level in ['Low', 'Medium']:
                    risk_level = 'Medium-High'
            
            # Check for historical max excursion (breakeven breach risk)
            max_excursion = row.get('current_max_excursion_pct')
            if pd.notna(max_excursion) and max_excursion > 8.0:
                risk_factors.append(f"Recent Large Move: {max_excursion:.1f}% max excursion in last 7 days")
                if risk_level == 'Low':
                    risk_level = 'Medium'
            
            # Analyze RQI (with early expiry override)
            phase = row.get('expiry_phase', 'Unknown')
            rqi = row['rollover_quality_index']
            
            if rqi >= 9.0:
                strengths.append(f"Excellent RQI ({rqi:.1f})")
            elif rqi >= 7.5:
                strengths.append(f"Good RQI ({rqi:.1f})")
            elif rqi >= 4.5 and phase == 'Early':
                # EARLY EXPIRY RQI OVERRIDE: Allow RQI 4.5-6.5 if strong next OI buildup
                next_oi_chg = row.get('next_oi_change_percent', 0)
                if next_oi_chg >= 20:
                    strengths.append(f"Early Expiry RQI Override: {rqi:.1f} (Low but Next OI +{next_oi_chg:.1f}% = positioning building)")
                    risk_factors.append(f"Watch for price confirmation (RQI {rqi:.1f} below 6.5)")
                else:
                    risk_factors.append(f"Low RQI: {rqi:.1f} (early expiry but weak OI buildup)")
            else:
                # Normal RQI assessment
                risk_factors.append(f"Moderate RQI ({rqi:.1f})")
            
            # Analyze confidence (low is good for straddles)
            if row['confidence_percent'] < 42:
                strengths.append(f"Very Low Conviction ({row['confidence_percent']:.1f}%)")
            elif row['confidence_percent'] < 46:
                strengths.append(f"Low Conviction ({row['confidence_percent']:.1f}%)")
            elif row['confidence_percent'] > 48:
                risk_factors.append(f"Higher Conviction ({row['confidence_percent']:.1f}%)")
            
            # Analyze OI levels (liquidity)
            if pd.notna(row['current_fut_oi']) and row['current_fut_oi'] < 500000:
                risk_factors.append(f"Lower Liquidity (OI: {int(row['current_fut_oi']):,})")
            elif pd.notna(row['current_fut_oi']) and row['current_fut_oi'] > 10000000:
                strengths.append(f"High Liquidity (OI: {int(row['current_fut_oi']/1000000):.1f}M)")
            
            self.df.at[idx, 'straddle_risk_level'] = risk_level
            self.df.at[idx, 'straddle_risk_factors'] = ' | '.join(risk_factors) if risk_factors else 'None'
            self.df.at[idx, 'straddle_strengths'] = ' | '.join(strengths) if strengths else 'Standard'
            
            # Calculate expected range (writer strikes)
            if pd.notna(row['writer_max_put_oi_strike']) and pd.notna(row['writer_max_call_oi_strike']):
                self.df.at[idx, 'straddle_expected_range_lower'] = row['writer_max_put_oi_strike']
                self.df.at[idx, 'straddle_expected_range_upper'] = row['writer_max_call_oi_strike']
            
            # Estimate breakeven (ATM ± estimated premium of ~5% of spot)
            if pd.notna(row['atm_strike']) and pd.notna(row['spot_price']):
                est_premium = row['spot_price'] * 0.05  # Rough estimate: 5% of spot
                self.df.at[idx, 'straddle_breakeven_lower'] = row['atm_strike'] - est_premium
                self.df.at[idx, 'straddle_breakeven_upper'] = row['atm_strike'] + est_premium
            
            # Deployment timing recommendation
            if is_borderline:
                # Borderline cases need extra caution
                self.df.at[idx, 'straddle_deployment_timing'] = 'Deploy Thu/Fri (Borderline RQI - Monitor First)'
            elif risk_level == 'Low':
                self.df.at[idx, 'straddle_deployment_timing'] = 'Deploy Immediately (Tue/Wed)'
            elif risk_level == 'Medium':
                self.df.at[idx, 'straddle_deployment_timing'] = 'Deploy Wed/Thu (Post-Expiry Clear)'
            elif risk_level == 'Medium-High':
                self.df.at[idx, 'straddle_deployment_timing'] = 'Deploy Thu/Fri (Monitor First)'
            else:
                self.df.at[idx, 'straddle_deployment_timing'] = 'Wait & Monitor (High Risk)'
        
        straddle_count = self.df['straddle_suitable'].sum()
        early_count = ((self.df['expiry_phase'] == 'Early') & self.df['straddle_suitable']).sum()
        logger.info(f"Found {straddle_count} straddle candidates ({early_count} in Early Expiry phase)")
    
    def calculate_hedge_recommendations(self):
        """
        Calculate hedge recommendations for 0.2 delta strangles based on gap risk.
        
        For 0.2 delta strangle (5-6% OTM each side):
        - Built-in protection: 5-6% moves are within short strikes
        - Hedge needed: Only when max_excursion suggests gaps beyond short strikes
        - Wing placement: 2x the strangle distance (10-12% OTM)
        """
        logger.info("Calculating hedge recommendations for strangles...")
        
        # Initialize hedge columns
        self.df['gap_risk_level'] = 'Low'
        self.df['hedge_recommended'] = 'No'
        self.df['hedge_strategy'] = 'Naked Strangle - No hedge needed'
        self.df['hedge_call_wing_strike'] = None
        self.df['hedge_put_wing_strike'] = None
        self.df['hedge_wing_distance_pct'] = None
        self.df['estimated_hedge_cost_pct'] = None
        self.df['hedged_max_loss_estimate'] = None
        self.df['hedge_reason'] = ''
        
        # Only analyze straddle-suitable candidates
        for idx, row in self.df[self.df['straddle_suitable']].iterrows():
            max_excursion = row.get('current_max_excursion_pct', 0)
            atm_strike = row.get('atm_strike')
            spot_price = row.get('spot_price')
            straddle_credit = row.get('straddle_credit', spot_price * 0.05 if pd.notna(spot_price) else 50)
            
            if pd.isna(max_excursion) or pd.isna(atm_strike) or pd.isna(spot_price):
                continue
            
            # 0.2 delta strangle has strikes ~5-6% OTM
            # Short strikes provide built-in protection up to ~5-6% moves
            strangle_protection_pct = 5.0  # 0.2 delta is ~5% OTM
            
            # Determine gap risk level and hedge need
            if max_excursion > 12:
                gap_risk = 'Very High'
                hedge_needed = 'MANDATORY'
                wing_distance = max(max_excursion + 2, 13)  # Just beyond max move
                hedge_reason = f'Extreme gap risk: {max_excursion:.1f}% max move (well beyond strangle protection)'
                
            elif max_excursion > 8:
                gap_risk = 'High'
                hedge_needed = 'RECOMMENDED'
                wing_distance = max(max_excursion + 1.5, 10)  # Buffer beyond max
                hedge_reason = f'High gap risk: {max_excursion:.1f}% max move (exceeds strangle strikes)'
                
            elif max_excursion > 6:
                gap_risk = 'Medium'
                hedge_needed = 'OPTIONAL'
                wing_distance = 9  # Standard protection
                hedge_reason = f'Moderate gap risk: {max_excursion:.1f}% max move (near strangle limit)'
                
            else:
                gap_risk = 'Low'
                hedge_needed = 'NO'
                wing_distance = 12  # Wide, cheap insurance if desired
                hedge_reason = f'Low gap risk: {max_excursion:.1f}% max move (within strangle protection)'
            
            # Calculate wing strikes
            call_wing = round(atm_strike * (1 + wing_distance/100), 0)
            put_wing = round(atm_strike * (1 - wing_distance/100), 0)
            
            # Estimate hedge cost (rough approximation)
            # For 10% OTM options: typically 8-12% of half-credit each
            # For 12% OTM options: typically 5-8% of half-credit each
            if wing_distance <= 8:
                cost_per_wing_pct = 12  # 12% of half-credit for tight wings
            elif wing_distance <= 10:
                cost_per_wing_pct = 10  # 10% of half-credit
            elif wing_distance <= 12:
                cost_per_wing_pct = 7   # 7% of half-credit for wide wings
            else:
                cost_per_wing_pct = 5   # 5% of half-credit for very wide wings
            
            total_hedge_cost_pct = cost_per_wing_pct * 2  # Both wings
            
            # Estimate max loss for Iron Condor
            # Max loss = (distance to wing) - net credit
            # Net credit = straddle_credit * (1 - hedge_cost_pct/100)
            net_credit = straddle_credit * (1 - total_hedge_cost_pct/100)
            wing_distance_points = atm_strike * (wing_distance/100)
            hedged_max_loss = max(0, wing_distance_points - net_credit)
            
            # Store results
            self.df.at[idx, 'gap_risk_level'] = gap_risk
            self.df.at[idx, 'hedge_recommended'] = hedge_needed
            
            if hedge_needed in ['MANDATORY', 'RECOMMENDED']:
                self.df.at[idx, 'hedge_strategy'] = f'{wing_distance:.0f}% Iron Condor (wings at ±{wing_distance:.0f}%)'
            elif hedge_needed == 'OPTIONAL':
                self.df.at[idx, 'hedge_strategy'] = f'Optional: {wing_distance:.0f}% wings for peace of mind'
            else:
                self.df.at[idx, 'hedge_strategy'] = 'Naked Strangle - No hedge needed'
            
            self.df.at[idx, 'hedge_call_wing_strike'] = call_wing
            self.df.at[idx, 'hedge_put_wing_strike'] = put_wing
            self.df.at[idx, 'hedge_wing_distance_pct'] = wing_distance
            self.df.at[idx, 'estimated_hedge_cost_pct'] = total_hedge_cost_pct
            self.df.at[idx, 'hedged_max_loss_estimate'] = round(hedged_max_loss, 2)
            self.df.at[idx, 'hedge_reason'] = hedge_reason
        
        # Log summary
        hedge_mandatory = (self.df['hedge_recommended'] == 'MANDATORY').sum()
        hedge_recommended = (self.df['hedge_recommended'] == 'RECOMMENDED').sum()
        hedge_optional = (self.df['hedge_recommended'] == 'OPTIONAL').sum()
        no_hedge = (self.df['hedge_recommended'] == 'NO').sum()
        
        logger.info(f"Hedge Summary: {hedge_mandatory} mandatory, {hedge_recommended} recommended, {hedge_optional} optional, {no_hedge} no hedge needed")
    
    def calculate_directional_metrics(self):
        """Calculate directional trade metrics and opportunities"""
        logger.info("Calculating directional trade metrics...")
        
        # Initialize columns
        self.df['directional_suitable'] = False
        self.df['directional_score'] = 0.0
        self.df['directional_score_raw'] = 0.0  # NEW: Raw interpretable score
        self.df['directional_score_normalized'] = 0.0  # NEW: Z-score normalized for ranking
        self.df['directional_rank'] = 0
        self.df['directional_strength'] = 'Weak'
        self.df['directional_conviction_gap'] = 0.0
        self.df['directional_risk_factors'] = ''
        self.df['directional_strengths'] = ''
        self.df['directional_entry_timing'] = 'N/A'
        self.df['directional_target_1'] = None
        self.df['directional_target_2'] = None
        self.df['directional_stop_loss'] = None
        self.df['directional_failed_filters'] = ''  # NEW: Track which filters failed
        
        # Filter for directional candidates (Bullish or Bearish)
        # ===== STABILITY FILTER FOR 3-5 WEEK HOLDS =====
        # Problem: Daily signal volatility causes whipsaws for long-term positions
        # Solution: Require consistent signals with supporting momentum indicators
        # 
        # Criteria:
        # 1. Confidence >= 50% (high conviction), OR
        # 2. Confidence >= 45% + RQI >= 7.0 + (Strong OI momentum OR Next month buildup > 50%)
        # 
        # This filters out weak/volatile signals that flip between days
        
        directional_mask = (
            self.df['combined_sentiment'].isin(['Bullish', 'Bearish']) &
            (self.df['confidence_percent'] >= 45)  # Base threshold
        )
        
        # ENHANCED STABILITY FILTER FOR LONG-TERM HOLDS
        # Require confidence >= 50% OR strong supporting indicators for 3-5 week trades
        
        # EARLY EXPIRY RQI OVERRIDE for directional trades
        # Allow RQI 5.5-7.0 if in early expiry phase with strong next OI buildup
        early_expiry_mask = self.df.get('expiry_phase', pd.Series(['Unknown'] * len(self.df))) == 'Early'
        
        early_expiry_rqi_relaxed = (
            early_expiry_mask &
            (self.df['rollover_quality_index'] >= 5.5) &
            (self.df['rollover_quality_index'] < 7.0) &
            (self.df.get('next_oi_change_percent', pd.Series([0] * len(self.df))) >= 50)  # Strong buildup
        )
        
        stability_mask = (
            (self.df['confidence_percent'] >= 50) |  # Higher confidence = stable
            (
                (self.df['confidence_percent'] >= 45) &
                (
                    (self.df['rollover_quality_index'] >= 7.0) |  # Normal RQI threshold
                    early_expiry_rqi_relaxed  # OR early expiry override (RQI 5.5-7.0 + strong OI)
                ) &
                (
                    (self.df['current_oi_change_percent'] > 10) |  # Strong OI momentum
                    (self.df['next_oi_change_percent'] > 50)  # Strong next month buildup
                )
            )
        )
        
        # Combine both filters - need directional signal AND stability
        final_directional_mask = directional_mask & stability_mask
        
        logger.info(f"Directional candidates: {directional_mask.sum()} basic, {final_directional_mask.sum()} stable (3-5 week hold filter applied)")
        
        self.df.loc[final_directional_mask, 'directional_suitable'] = True
        
        # NEW: Track failed filters for directional trades
        for idx, row in self.df.iterrows():
            failed_filters = []
            
            # Check sentiment filter
            if row['combined_sentiment'] not in ['Bullish', 'Bearish']:
                failed_filters.append(f"Sentiment: {row['combined_sentiment']} (need Bullish or Bearish)")
            
            # Check confidence filter
            if row['confidence_percent'] < 45:
                failed_filters.append(f"Confidence: {row['confidence_percent']:.1f}% (need >= 45%)")
            
            # Check stability filter (confidence >= 50 OR strong supporting factors)
            if row['confidence_percent'] < 50:
                # Need strong supporting factors
                rqi = row['rollover_quality_index']
                next_oi_chg = row.get('next_oi_change_percent', 0)
                current_oi_chg = row.get('current_oi_change_percent', 0)
                phase = row.get('expiry_phase', 'Unknown')
                
                stability_passed = False
                
                # Check early expiry override
                if phase == 'Early' and 5.5 <= rqi < 7.0 and next_oi_chg >= 50:
                    stability_passed = True
                # Check normal RQI threshold
                elif rqi >= 7.0:
                    # Check OI momentum
                    if current_oi_chg > 10 or next_oi_chg > 50:
                        stability_passed = True
                
                if not stability_passed:
                    failed_filters.append(f"Stability: Confidence {row['confidence_percent']:.1f}% < 50% AND (RQI {rqi:.1f} < 7.0 OR weak OI momentum)")
            
            # Store failed filters
            if failed_filters:
                self.df.at[idx, 'directional_failed_filters'] = ' | '.join(failed_filters)
            else:
                # If no failed filters but still not suitable, mark as passed all filters
                if not row['directional_suitable']:
                    self.df.at[idx, 'directional_failed_filters'] = 'Passed all filters but not in final selection'
        
        # Calculate confidence gap to threshold
        self.df['directional_conviction_gap'] = 55.0 - self.df['confidence_percent']
        self.df.loc[self.df['confidence_percent'] >= 55, 'directional_conviction_gap'] = 0.0
        
        # Calculate directional score (0-100) - Only for stable signals
        for idx, row in self.df[final_directional_mask].iterrows():
            score = 0.0
            
            # Confidence (30% weight) - Reduced weight since we have stability filter
            score += (row['confidence_percent'] / 100) * 30
            
            # STABILITY BONUS (15% weight) - NEW for 3-5 week holds
            stability_bonus = 0
            if row['confidence_percent'] >= 55:
                stability_bonus = 15  # High confidence = very stable
            elif row['confidence_percent'] >= 50:
                stability_bonus = 10  # Medium-high confidence = stable
            elif row['rollover_quality_index'] >= 8.0:
                stability_bonus = 5   # Excellent rollover = supporting stability
            score += stability_bonus
            
            # RQI (20% weight)
            score += (row['rollover_quality_index'] / 10) * 20
            
            # Rollover (15% weight)
            score += min(row['rollover_percent'] / 100, 1.0) * 15
            
            # PCR alignment (10% weight)
            if row['combined_sentiment'] == 'Bullish':
                # Higher PCR is better for bullish
                pcr_score = min(row['writer_pcr_oi'] / 1.5, 1.0) * 10
            else:  # Bearish
                # Lower PCR is better for bearish
                pcr_score = min((2.0 - row['writer_pcr_oi']) / 2.0, 1.0) * 10
            score += pcr_score
            
            # MOMENTUM BONUS (10% weight) - Strong OI buildup = sustained move
            momentum_bonus = 0
            next_oi_chg = row.get('next_oi_change_percent', 0)
            if next_oi_chg > 100:
                momentum_bonus = 10  # Exceptional buildup
            elif next_oi_chg > 50:
                momentum_bonus = 7   # Strong buildup
            elif next_oi_chg > 20:
                momentum_bonus = 3   # Moderate buildup
            score += momentum_bonus
            
            # Term structure (10% weight)
            if pd.notna(row['term_structure_slope_percent']):
                if row['combined_sentiment'] == 'Bullish' and row['term_structure_slope_percent'] > 0.25:
                    score += 10
                elif row['combined_sentiment'] == 'Bearish' and row['term_structure_slope_percent'] < 0:
                    score += 10
                elif row['term_structure_slope_percent'] > 0:
                    score += 5
            
            self.df.at[idx, 'directional_score_raw'] = round(score, 1)
        
        # Zero out scores for non-suitable candidates
        self.df.loc[~final_directional_mask, 'directional_score_raw'] = 0.0
        
        # HYBRID: Calculate normalized scores for stable ranking (when >= 5 candidates)
        suitable_directional = self.df[self.df['directional_suitable']].copy()
        if len(suitable_directional) >= 5:
            # Normalize individual features first, then combine
            # Note: Some features are categorical (sentiment), handle separately
            confidence_norm = self._normalize_zscore(suitable_directional['confidence_percent'], reverse=False)
            rqi_norm = self._normalize_zscore(suitable_directional['rollover_quality_index'], reverse=False)
            rollover_norm = self._normalize_zscore(suitable_directional['rollover_percent'], reverse=False)
            next_oi_norm = self._normalize_zscore(suitable_directional.get('next_oi_change_percent', 0), reverse=False)
            
            # PCR alignment (sentiment-specific, normalize separately per sentiment)
            pcr_norm = pd.Series(0.0, index=suitable_directional.index)
            for sentiment in ['Bullish', 'Bearish']:
                sentiment_mask = suitable_directional['combined_sentiment'] == sentiment
                if sentiment_mask.sum() >= 2:
                    if sentiment == 'Bullish':
                        # Higher PCR better
                        pcr_values = suitable_directional.loc[sentiment_mask, 'writer_pcr_oi']
                        pcr_norm.loc[sentiment_mask] = self._normalize_zscore(pcr_values, reverse=False)
                    else:  # Bearish
                        # Lower PCR better (reverse)
                        pcr_values = suitable_directional.loc[sentiment_mask, 'writer_pcr_oi']
                        pcr_norm.loc[sentiment_mask] = self._normalize_zscore(pcr_values, reverse=True)
            
            # Stability bonus normalization (15% weight)
            stability_bonus_vals = pd.Series([
                15.0 if conf >= 55 else (10.0 if conf >= 50 else (5.0 if rqi >= 8.0 else 0))
                for conf, rqi in zip(suitable_directional['confidence_percent'], suitable_directional['rollover_quality_index'])
            ], index=suitable_directional.index)
            stability_norm = self._normalize_zscore(stability_bonus_vals, reverse=False)
            
            # Combine normalized features (matching raw score weights)
            normalized_score = pd.Series(index=suitable_directional.index)
            for idx in suitable_directional.index:
                norm_val = (
                    confidence_norm[idx] * 0.30 +
                    stability_norm[idx] * 0.15 +
                    rqi_norm[idx] * 0.20 +
                    rollover_norm[idx] * 0.15 +
                    pcr_norm[idx] * 0.10 +
                    next_oi_norm[idx] * 0.10
                )
                normalized_score.at[idx] = norm_val
            
            # Store normalized scores back to main dataframe
            for orig_idx in suitable_directional.index:
                if orig_idx in normalized_score.index:
                    self.df.at[orig_idx, 'directional_score_normalized'] = normalized_score.at[orig_idx]
                else:
                    pos = list(suitable_directional.index).index(orig_idx)
                    if pos < len(normalized_score):
                        self.df.at[orig_idx, 'directional_score_normalized'] = normalized_score.iloc[pos] if hasattr(normalized_score, 'iloc') else normalized_score[pos]
            
            # Use normalized score for ranking
            self.df['directional_score'] = self.df['directional_score_normalized']
            logger.info(f"Using normalized scoring for {len(suitable_directional)} directional candidates")
        else:
            # < 5 candidates: Use raw scores
            self.df['directional_score'] = self.df['directional_score_raw']
            self.df.loc[~final_directional_mask, 'directional_score_normalized'] = 0.0
            logger.info(f"Using raw scoring for {len(suitable_directional)} directional candidates (sample too small for normalization)")
        
        # Rank directional candidates (using hybrid score)
        if len(suitable_directional) > 0:
            suitable_directional = self.df[self.df['directional_suitable']].copy()
            suitable_directional = suitable_directional.sort_values('directional_score', ascending=False).reset_index(drop=False)
            for rank_idx, orig_idx in enumerate(suitable_directional['index'], 1):
                self.df.at[orig_idx, 'directional_rank'] = rank_idx
            
            # Re-analyze for entry timing and targets (only for ranked candidates)
            for idx, row in self.df[self.df['directional_suitable']].iterrows():
                score = row['directional_score']
                
                # Strength classification
                if score >= 75:
                    strength = 'Very Strong'
                elif score >= 65:
                    strength = 'Strong'
                elif score >= 55:
                    strength = 'Moderate'
                else:
                    strength = 'Weak'
                self.df.at[idx, 'directional_strength'] = strength
                
                # Analyze risk factors and strengths
                risk_factors = []
                strengths = []
                
                # COUNTER-TREND RISK DETECTION (using historical max moves)
                # Flag if recent price action contradicts directional signal
                sentiment = row['combined_sentiment']
                max_upswing = row.get('current_max_upswing_pct')
                max_drawdown = row.get('current_max_drawdown_pct')
                
                if sentiment == 'Bullish' and pd.notna(max_drawdown) and max_drawdown < -8.0:
                    # Bullish signal after sharp drop = potential dead-cat bounce
                    risk_factors.append(f"Counter-Trend Risk: Recent sharp drop {max_drawdown:.1f}% in last 7 days (bounce vs trend?)")
                elif sentiment == 'Bearish' and pd.notna(max_upswing) and max_upswing > 8.0:
                    # Bearish signal after sharp rally = potential pullback, not reversal
                    risk_factors.append(f"Counter-Trend Risk: Recent sharp rally +{max_upswing:.1f}% in last 7 days (pullback vs reversal?)")
                
                # Flag if max excursion is high (volatile recent behavior)
                max_excursion = row.get('current_max_excursion_pct')
                if pd.notna(max_excursion) and max_excursion > 10.0:
                    risk_factors.append(f"High Recent Volatility: {max_excursion:.1f}% max excursion (increased risk)")
                elif pd.notna(max_excursion) and max_excursion < 3.0:
                    strengths.append(f"Low Recent Volatility: {max_excursion:.1f}% max excursion (stable trend)")
                
                # Rollover analysis
                if row['rollover_percent'] < 70:
                    risk_factors.append(f"Rollover {row['rollover_percent']:.1f}% < 70%")
                else:
                    strengths.append(f"Good Rollover {row['rollover_percent']:.1f}%")
                
                # RQI analysis (with early expiry context)
                phase = row.get('expiry_phase', 'Unknown')
                rqi = row['rollover_quality_index']
                next_oi_chg = row.get('next_oi_change_percent', 0)
                
                if rqi < 6.5:
                    # Check if early expiry override applies
                    if phase == 'Early' and rqi >= 5.5 and next_oi_chg >= 50:
                        strengths.append(f"Early Expiry RQI: {rqi:.1f} (Acceptable with Next OI +{next_oi_chg:.1f}%)")
                        risk_factors.append(f"Monitor for price confirmation (RQI {rqi:.1f} below 6.5)")
                    else:
                        risk_factors.append(f"Low RQI {rqi:.1f}")
                elif rqi >= 9.0:
                    strengths.append(f"Excellent RQI {rqi:.1f}")
                else:
                    strengths.append(f"Good RQI {rqi:.1f}")
                
                # Term structure analysis
                if pd.notna(row['term_structure_slope_percent']):
                    if row['term_structure_slope_percent'] <= 0.25:
                        risk_factors.append(f"Weak Contango {row['term_structure_slope_percent']:.2f}%")
                    else:
                        strengths.append(f"Healthy Contango {row['term_structure_slope_percent']:.2f}%")
                
                # PCR analysis
                if row['combined_sentiment'] == 'Bullish':
                    if row['writer_pcr_oi'] < 0.7:
                        risk_factors.append(f"Call Writer Resistance (PCR {row['writer_pcr_oi']:.2f})")
                    elif row['writer_pcr_oi'] > 1.0:
                        strengths.append(f"Put Writer Support (PCR {row['writer_pcr_oi']:.2f})")
                else:  # Bearish
                    if row['writer_pcr_oi'] > 1.3:
                        risk_factors.append(f"Put Writer Support (PCR {row['writer_pcr_oi']:.2f})")
                    elif row['writer_pcr_oi'] < 0.8:
                        strengths.append(f"Call Writer Resistance (PCR {row['writer_pcr_oi']:.2f})")
                
                # Confidence gap
                if row['directional_conviction_gap'] > 10:
                    risk_factors.append(f"Confidence {row['confidence_percent']:.1f}% (Need 55%+)")
                elif row['directional_conviction_gap'] <= 0:
                    strengths.append(f"Confidence {row['confidence_percent']:.1f}% Above Threshold")
                
                # Momentum consistency
                if ((row['sentiment_current'] == row['sentiment_next']) or 
                   (row['sentiment_current'] in ['Long Buildup', 'Short Covering'] and 
                    row['sentiment_next'] == 'Long Buildup' and row['combined_sentiment'] == 'Bullish')):
                    strengths.append('Consistent Momentum')
                else:
                    risk_factors.append('Mixed Signals Between Months')
                
                self.df.at[idx, 'directional_risk_factors'] = ' | '.join(risk_factors) if risk_factors else 'None'
                self.df.at[idx, 'directional_strengths'] = ' | '.join(strengths) if strengths else 'None'
                
                # Entry timing recommendation
                if row['directional_conviction_gap'] <= 0 and row['rollover_percent'] >= 70:
                    self.df.at[idx, 'directional_entry_timing'] = 'Ready Now (Post-Expiry)'
                elif row['directional_conviction_gap'] <= 5:
                    self.df.at[idx, 'directional_entry_timing'] = 'Watch for Tue/Wed Confirmation'
                elif row['directional_conviction_gap'] <= 10:
                    self.df.at[idx, 'directional_entry_timing'] = 'Monitor - May Signal Post-Expiry'
            else:
                self.df.at[idx, 'directional_entry_timing'] = 'Wait for Stronger Setup'
            
            # Calculate targets and stops (simple percentage-based)
            if pd.notna(row['spot_price']):
                if row['combined_sentiment'] == 'Bullish':
                    self.df.at[idx, 'directional_target_1'] = round(row['spot_price'] * 1.05, 2)
                    self.df.at[idx, 'directional_target_2'] = round(row['spot_price'] * 1.08, 2)
                    self.df.at[idx, 'directional_stop_loss'] = round(row['spot_price'] * 0.975, 2)
                else:  # Bearish
                    self.df.at[idx, 'directional_target_1'] = round(row['spot_price'] * 0.95, 2)
                    self.df.at[idx, 'directional_target_2'] = round(row['spot_price'] * 0.92, 2)
                    self.df.at[idx, 'directional_stop_loss'] = round(row['spot_price'] * 1.025, 2)
        
        # Rank directional candidates
        dir_suitable = self.df[self.df['directional_suitable']].copy()
        if len(dir_suitable) > 0:
            dir_suitable = dir_suitable.sort_values('directional_score', ascending=False)
            dir_suitable['directional_rank'] = range(1, len(dir_suitable) + 1)
            self.df.update(dir_suitable[['directional_rank']])
        
        logger.info(f"Found {self.df['directional_suitable'].sum()} directional candidates")
    
    def classify_market_condition(self):
        """Classify overall market condition"""
        logger.info("Classifying market condition...")
        
        total_stocks = len(self.df)
        neutral_pct = (self.df['combined_sentiment'] == 'Neutral').sum() / total_stocks * 100
        avg_confidence = self.df['confidence_percent'].mean()
        avg_rollover = self.df['rollover_percent'].mean()
        avg_pcr = self.df['writer_pcr_oi'].mean()
        low_rollover_pct = (self.df['rollover_percent'] < 70).sum() / total_stocks * 100
        
        # Create market summary
        self.market_summary = {
            'total_stocks': total_stocks,
            'neutral_sentiment_pct': round(neutral_pct, 1),
            'avg_confidence': round(avg_confidence, 1),
            'avg_rollover': round(avg_rollover, 1),
            'avg_pcr': round(avg_pcr, 2),
            'low_rollover_pct': round(low_rollover_pct, 1),
            'straddle_opportunities': self.df['straddle_suitable'].sum(),
            'directional_opportunities': self.df['directional_suitable'].sum(),
            'tradeable_signals': (self.df['action'].str.contains('BUY', na=False)).sum()
        }
        
        # Determine market phase
        if neutral_pct > 90 and avg_rollover < 70:
            self.market_phase = 'Expiry Week Distortion'
        elif neutral_pct > 70:
            self.market_phase = 'Rangebound/Consolidation'
        elif avg_confidence > 55:
            self.market_phase = 'Trending with Conviction'
        else:
            self.market_phase = 'Low Conviction Mixed'
        
        self.df['market_phase'] = self.market_phase
        
        logger.info(f"Market Phase: {self.market_phase}")
        logger.info(f"Market Summary: {self.market_summary}")
    
    def add_actionable_recommendations(self):
        """Add specific actionable recommendations"""
        logger.info("Generating actionable recommendations...")
        
        self.df['primary_recommendation'] = 'Hold/Monitor'
        self.df['recommendation_reason'] = ''
        self.df['trade_setup'] = ''
        
        for idx, row in self.df.iterrows():
            # Check if tradeable BUY signal
            if pd.notna(row['action']) and 'BUY' in str(row['action']):
                self.df.at[idx, 'primary_recommendation'] = 'DIRECTIONAL TRADE'
                self.df.at[idx, 'recommendation_reason'] = f"Scanner generated BUY signal with {row['confidence_percent']:.1f}% confidence"
                if pd.notna(row['selected_option_symbol']):
                    self.df.at[idx, 'trade_setup'] = f"{row['action']} | Strike: {row['selected_option_strike']} | Premium: {row['selected_option_premium']}"
                else:
                    self.df.at[idx, 'trade_setup'] = row['action']
            
            # Check for top-tier straddle
            elif row['straddle_tier'] in ['Tier 1 (Best)', 'Tier 2 (Good)']:
                self.df.at[idx, 'primary_recommendation'] = 'SHORT STRADDLE'
                self.df.at[idx, 'recommendation_reason'] = f"{row['straddle_tier']} - Score {row['straddle_score']:.1f}, {row['straddle_risk_level']} Risk"
                if pd.notna(row['atm_strike']):
                    self.df.at[idx, 'trade_setup'] = f"Sell {row['atm_strike']} CE + {row['atm_strike']} PE (Nov exp) | Range: {row['straddle_expected_range_lower']}-{row['straddle_expected_range_upper']}"
            
            # Check for high-potential directional (needs confirmation)
            elif row['directional_suitable'] and row['confidence_percent'] > 50:
                self.df.at[idx, 'primary_recommendation'] = 'WATCH - Near Signal'
                self.df.at[idx, 'recommendation_reason'] = f"{row['combined_sentiment']} with {row['confidence_percent']:.1f}% confidence (needs +{row['directional_conviction_gap']:.1f}%)"
                self.df.at[idx, 'trade_setup'] = f"Monitor post-expiry for BUY {row['combined_sentiment'].upper()} signal"
            
            # Check for lower-tier straddle
            elif row['straddle_suitable']:
                self.df.at[idx, 'primary_recommendation'] = 'STRADDLE (Lower Tier)'
                self.df.at[idx, 'recommendation_reason'] = f"{row['straddle_tier']} - Score {row['straddle_score']:.1f}, {row['straddle_risk_level']} Risk"
                if pd.notna(row['atm_strike']):
                    self.df.at[idx, 'trade_setup'] = f"Sell {row['atm_strike']} CE + {row['atm_strike']} PE (Consider if Tier 1/2 full)"
            
            # Default monitoring
            else:
                reasons = []
                if row['combined_sentiment'] == 'Neutral' and row['confidence_percent'] < 35:
                    reasons.append('Very low conviction')
                elif row['combined_sentiment'] == 'Neutral':
                    reasons.append(f"Neutral with {row['confidence_percent']:.1f}% confidence")
                
                if row['rollover_percent'] < 60:
                    reasons.append(f"Low rollover {row['rollover_percent']:.1f}%")
                
                if row['writer_pcr_oi'] < 0.65 or row['writer_pcr_oi'] > 1.4:
                    reasons.append(f"Extreme PCR {row['writer_pcr_oi']:.2f}")
                
                self.df.at[idx, 'recommendation_reason'] = ' | '.join(reasons) if reasons else 'No clear setup'
    
    def add_risk_classifications(self):
        """Add comprehensive risk classifications"""
        logger.info("Adding risk classifications...")
        
        self.df['overall_risk_rating'] = 'Medium'
        self.df['liquidity_risk'] = 'Low'
        self.df['rollover_risk'] = 'Low'
        self.df['writer_resistance_risk'] = 'Low'
        self.df['volatility_risk'] = 'Low'
        
        for idx, row in self.df.iterrows():
            # Liquidity risk
            if pd.notna(row['current_fut_oi']):
                if row['current_fut_oi'] < 500000:
                    self.df.at[idx, 'liquidity_risk'] = 'High'
                elif row['current_fut_oi'] < 2000000:
                    self.df.at[idx, 'liquidity_risk'] = 'Medium'
                else:
                    self.df.at[idx, 'liquidity_risk'] = 'Low'
            
            # Rollover risk (DTE-aware thresholds)
            dte = row.get('dte_calculated')
            if dte is None and pd.notna(row.get('trade_option_expiry')):
                try:
                    expiry_date = datetime.strptime(str(row['trade_option_expiry']), '%Y-%m-%d')
                    dte = (expiry_date - datetime.now()).days
                except:
                    dte = None
            
            phase, rollover_low, rollover_high = self._get_expiry_phase(dte)
            rollover_pct = row['rollover_percent']
            
            if phase == 'Early':
                # Early expiry: Very lenient thresholds
                if rollover_pct >= rollover_high:
                    self.df.at[idx, 'rollover_risk'] = 'Low'
                elif rollover_pct >= rollover_low:
                    self.df.at[idx, 'rollover_risk'] = 'Medium'
                else:
                    # Check next_oi_change as alternative signal
                    next_oi_chg = row.get('next_oi_change_percent', 0)
                    if next_oi_chg >= 20:
                        self.df.at[idx, 'rollover_risk'] = 'Medium'  # Offset by strong OI buildup
                    else:
                        self.df.at[idx, 'rollover_risk'] = 'High'
            elif phase == 'Mid':
                # Mid expiry: Moderate thresholds
                if rollover_pct >= rollover_high:
                    self.df.at[idx, 'rollover_risk'] = 'Low'
                elif rollover_pct >= rollover_low:
                    self.df.at[idx, 'rollover_risk'] = 'Medium'
                elif rollover_pct >= 20:
                    self.df.at[idx, 'rollover_risk'] = 'High'
                else:
                    self.df.at[idx, 'rollover_risk'] = 'Very High'
            elif phase == 'Late':
                # Late expiry: Higher thresholds (critical period)
                if rollover_pct >= rollover_high:
                    self.df.at[idx, 'rollover_risk'] = 'Low'
                elif rollover_pct >= rollover_low:
                    self.df.at[idx, 'rollover_risk'] = 'Medium'
                elif rollover_pct >= 50:
                    self.df.at[idx, 'rollover_risk'] = 'High'
                else:
                    self.df.at[idx, 'rollover_risk'] = 'Very High'
            else:  # Final week
                # Final week: Very high thresholds (most critical)
                if rollover_pct >= rollover_high:
                    self.df.at[idx, 'rollover_risk'] = 'Low'
                elif rollover_pct >= rollover_low:
                    self.df.at[idx, 'rollover_risk'] = 'Medium'
                elif rollover_pct >= 60:
                    self.df.at[idx, 'rollover_risk'] = 'High'
                else:
                    self.df.at[idx, 'rollover_risk'] = 'Very High'
            
            # Writer resistance risk
            if row['writer_call_writer_strength_percent'] > 65:
                self.df.at[idx, 'writer_resistance_risk'] = 'Very High (Call Resistance)'
            elif row['writer_call_writer_strength_percent'] > 60:
                self.df.at[idx, 'writer_resistance_risk'] = 'High (Call Resistance)'
            elif row['writer_put_writer_strength_percent'] > 65:
                self.df.at[idx, 'writer_resistance_risk'] = 'Very High (Put Resistance)'
            elif row['writer_put_writer_strength_percent'] > 60:
                self.df.at[idx, 'writer_resistance_risk'] = 'High (Put Resistance)'
            elif 0.85 <= row['writer_pcr_oi'] <= 1.15:
                self.df.at[idx, 'writer_resistance_risk'] = 'Low (Balanced)'
            else:
                self.df.at[idx, 'writer_resistance_risk'] = 'Medium'
            
            # Volatility risk
            if row['avg_price_momentum'] < 0.5:
                self.df.at[idx, 'volatility_risk'] = 'Very Low'
            elif row['avg_price_momentum'] < 1.5:
                self.df.at[idx, 'volatility_risk'] = 'Low'
            elif row['avg_price_momentum'] < 3.0:
                self.df.at[idx, 'volatility_risk'] = 'Medium'
            else:
                self.df.at[idx, 'volatility_risk'] = 'High'
            
            # Overall risk rating
            risk_scores = {
                'Very High': 4, 'High': 3, 'Medium': 2, 'Low': 1, 'Very Low': 0.5,
                'Very High (Call Resistance)': 4, 'High (Call Resistance)': 3,
                'Very High (Put Resistance)': 4, 'High (Put Resistance)': 3,
                'Low (Balanced)': 1
            }
            
            total_risk = (
                risk_scores.get(self.df.at[idx, 'liquidity_risk'], 2) +
                risk_scores.get(self.df.at[idx, 'rollover_risk'], 2) +
                risk_scores.get(self.df.at[idx, 'writer_resistance_risk'], 2) +
                risk_scores.get(self.df.at[idx, 'volatility_risk'], 2)
            ) / 4
            
            if total_risk >= 3.5:
                self.df.at[idx, 'overall_risk_rating'] = 'Very High'
            elif total_risk >= 2.5:
                self.df.at[idx, 'overall_risk_rating'] = 'High'
            elif total_risk >= 1.5:
                self.df.at[idx, 'overall_risk_rating'] = 'Medium'
            else:
                self.df.at[idx, 'overall_risk_rating'] = 'Low'
    
    def generate_summary_stats(self):
        """Generate summary statistics for the report"""
        logger.info("Generating summary statistics...")
        
        summary = {
            'analysis_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'input_file': self.input_csv_path,
            'total_stocks_analyzed': len(self.df),
            'market_phase': self.market_phase,
            **self.market_summary,
            
            # Straddle summary
            'straddle_tier1_count': (self.df['straddle_tier'] == 'Tier 1 (Best)').sum(),
            'straddle_tier2_count': (self.df['straddle_tier'] == 'Tier 2 (Good)').sum(),
            'straddle_tier2_borderline_count': (self.df['straddle_tier'] == 'Tier 2 Borderline (RQI 5.5-6.5)').sum(),
            'straddle_tier3_count': (self.df['straddle_tier'] == 'Tier 3 (Acceptable)').sum(),
            'straddle_tier3_borderline_count': (self.df['straddle_tier'] == 'Tier 3 Borderline (RQI 5.5-6.5)').sum(),
            'straddle_low_risk_count': (self.df['straddle_risk_level'] == 'Low').sum(),
            'straddle_medium_risk_count': (self.df['straddle_risk_level'] == 'Medium').sum(),
            'straddle_high_risk_count': (self.df['straddle_risk_level'].isin(['Medium-High', 'High'])).sum(),
            
            # Directional summary
            'directional_very_strong': (self.df['directional_strength'] == 'Very Strong').sum(),
            'directional_strong': (self.df['directional_strength'] == 'Strong').sum(),
            'directional_moderate': (self.df['directional_strength'] == 'Moderate').sum(),
            'directional_ready_now': (self.df['directional_entry_timing'] == 'Ready Now (Post-Expiry)').sum(),
            'directional_watch': (self.df['directional_entry_timing'].str.contains('Watch|Monitor', na=False)).sum(),
            
            # Risk summary
            'high_rollover_risk': (self.df['rollover_risk'].isin(['High', 'Very High'])).sum(),
            'extreme_writer_resistance': (self.df['writer_resistance_risk'].str.contains('Very High', na=False)).sum(),
            'high_volatility_stocks': (self.df['volatility_risk'] == 'High').sum()
        }
        
        # Add IV and Event Risk Summary (conditional - only if IV data loaded)
        if 'iv_percentile_rank' in self.df.columns:
            summary.update({
                'stocks_with_iv_data': self.df['iv_percentile_rank'].notna().sum(),
                'unsuitable_iv_for_selling': (~self.df['iv_suitable_for_selling']).sum() if 'iv_suitable_for_selling' in self.df.columns else 0,
                'low_iv_stocks': ((self.df['iv_percentile_rank'] < 40) & self.df['iv_percentile_rank'].notna()).sum(),
                'high_iv_stocks': ((self.df['iv_percentile_rank'] >= 60) & self.df['iv_percentile_rank'].notna()).sum(),
                'iv_spikes_detected': self.df['iv_spike_detected'].sum() if 'iv_spike_detected' in self.df.columns else 0,
                'event_risk_blocked_stocks': self.df['event_risk_blocked'].sum() if 'event_risk_blocked' in self.df.columns else 0,
                'stocks_with_upcoming_events': self.df['event_date'].notna().sum() if 'event_date' in self.df.columns else 0,
                'avg_iv_percentile': self.df['iv_percentile_rank'].mean() if self.df['iv_percentile_rank'].notna().any() else None
            })
        
        # Add OI Spatial Summary (Phase 2)
        if 'oi_skew_type' in self.df.columns:
            summary.update({
                'oi_unsuitable_for_straddle': (~self.df['oi_spatial_suitable_for_straddle']).sum(),
                'bullish_inversions': (self.df['oi_skew_type'] == 'Bullish_Inversion').sum(),
                'bearish_inversions': (self.df['oi_skew_type'] == 'Bearish_Inversion').sum(),
                'spread_activity_detected': self.df['oi_spread_detected'].sum()
            })
        
        # Add Realized Volatility Summary
        if 'current_avg_abs_daily_move_pct' in self.df.columns:
            summary.update({
                'avg_realized_vol_daily': self.df['current_avg_abs_daily_move_pct'].mean() if self.df['current_avg_abs_daily_move_pct'].notna().any() else None,
                'stocks_high_volatility_gt_3pct': (self.df['current_avg_abs_daily_move_pct'] > 3.0).sum() if 'current_avg_abs_daily_move_pct' in self.df.columns else 0,
                'stocks_low_volatility_lt_1pct': (self.df['current_avg_abs_daily_move_pct'] < 1.0).sum() if 'current_avg_abs_daily_move_pct' in self.df.columns else 0
            })
        
        self.summary_stats = summary
        return summary
    
    def save_comprehensive_output(self):
        """Save enriched CSV with all insights"""
        output_file = f"comprehensive_insights_{self.output_timestamp}.csv"
        
        try:
            # Reorder columns for better readability
            priority_cols = [
                'symbol', 'primary_recommendation', 'recommendation_reason', 'trade_setup',
                'spot_price', 'combined_sentiment', 'confidence_percent', 'action',
                
                # IV and Event Risk columns (critical for straddles)
                'iv_percentile_rank', 'iv_current', 'iv_change', 'iv_suitable_for_selling',
                'iv_risk_level', 'iv_risk_reason', 'iv_spike_detected',
                'event_date', 'days_to_event', 'event_risk_level', 'event_risk_blocked',
                
                # Phase 2: OI Spatial Analysis (skew, concentration, spreads)
                'oi_skew_type', 'oi_directional_bias', 'oi_spatial_suitable_for_straddle',
                'oi_spatial_risk_level', 'oi_spatial_risk_reason', 'oi_spread_detected',
                'writer_call_oi_concentration_pct', 'writer_put_oi_concentration_pct',
                'writer_max_call_oi_value', 'writer_max_put_oi_value',
                'writer_second_call_strike', 'writer_second_call_oi_ratio',
                'writer_second_put_strike', 'writer_second_put_oi_ratio',
                
                # Greeks Analysis (theta, gamma, vega)
                'theta_per_day', 'theta_per_trading_day', 'gamma_atm', 'vega',
                'straddle_credit', 'breakeven_upper', 'breakeven_lower', 'min_be_distance_pct',
                'greeks_gamma_risk', 'greeks_theta_quality', 'greeks_vega_exposure',
                'greeks_suitable_for_straddle', 'greeks_risk_reason',
                
                # Straddle metrics
                'straddle_suitable', 'straddle_tier', 'straddle_rank', 
                'straddle_score', 'straddle_score_raw', 'straddle_score_normalized',
                'straddle_risk_level', 'straddle_strengths', 'straddle_risk_factors',
                'straddle_deployment_timing',
                'atm_strike', 'straddle_expected_range_lower', 'straddle_expected_range_upper',
                'straddle_breakeven_lower', 'straddle_breakeven_upper',
                
                # Directional metrics
                'directional_suitable', 'directional_strength', 'directional_rank', 
                'directional_score', 'directional_score_raw', 'directional_score_normalized',
                'directional_conviction_gap', 'directional_strengths', 'directional_risk_factors',
                'directional_entry_timing', 'directional_target_1', 'directional_target_2', 'directional_stop_loss',
                
                # Risk classifications
                'overall_risk_rating', 'liquidity_risk', 'rollover_risk', 'writer_resistance_risk', 'volatility_risk',
                
                # Key metrics
                'avg_price_momentum', 'writer_pcr_oi', 'rollover_quality_index', 'rollover_percent',
                'current_fut_oi', 'next_fut_oi', 'current_fut_avg_volume', 'next_fut_avg_volume',
                
                # Realized Volatility Metrics (straddle risk assessment)
                'current_realized_vol_daily_pct', 'current_avg_abs_daily_move_pct', 'current_avg_daily_range_pct',
                'current_max_single_day_move_pct', 'current_realized_vol_annualized',
                'current_max_upswing_pct', 'current_max_drawdown_pct', 'current_max_excursion_pct',
                'next_realized_vol_daily_pct', 'next_avg_abs_daily_move_pct', 'next_avg_daily_range_pct',
                'next_max_single_day_move_pct', 'next_realized_vol_annualized',
                'next_max_upswing_pct', 'next_max_drawdown_pct', 'next_max_excursion_pct',
                
                # Expiry phase detection (DTE-aware analysis)
                'expiry_phase', 'dte_calculated', 'days_to_current_expiry'
            ]
            
            # Get remaining columns
            remaining_cols = [col for col in self.df.columns if col not in priority_cols]
            final_cols = priority_cols + remaining_cols
            
            # Reorder
            df_output = self.df[[col for col in final_cols if col in self.df.columns]]
            
            # Save
            df_output.to_csv(output_file, index=False, float_format='%.2f')
            logger.info(f"Comprehensive insights saved to {output_file}")
            
            return output_file
        
        except Exception as e:
            logger.error(f"Error saving comprehensive output: {e}")
            return None
    
    def save_summary_report(self):
        """Save summary report as separate CSV"""
        summary_file = f"market_summary_{self.output_timestamp}.csv"
        
        try:
            summary_df = pd.DataFrame([self.summary_stats])
            summary_df.to_csv(summary_file, index=False)
            logger.info(f"Market summary saved to {summary_file}")
            
            # Also create top opportunities files
            self.save_top_opportunities()
            
            return summary_file
        except Exception as e:
            logger.error(f"Error saving summary: {e}")
            return None
    
    def save_top_opportunities(self):
        """Save separate files for top straddle and directional opportunities"""
        
        # Top 10 Straddles
        try:
            straddle_top = self.df[self.df['straddle_suitable']].nlargest(10, 'straddle_score')
            if len(straddle_top) > 0:
                straddle_file = f"top_straddles_{self.output_timestamp}.csv"
                straddle_cols = [
                    'symbol', 'straddle_rank', 'straddle_score', 'straddle_score_raw', 'straddle_score_normalized',
                    'straddle_tier', 'straddle_risk_level', 'straddle_borderline',  # NEW: Borderline flag
                    'spot_price', 'atm_strike', 'writer_pcr_oi', 'rollover_quality_index', 'rollover_percent',
                    'avg_price_momentum', 'confidence_percent',
                    # IV and Event columns
                    'iv_percentile_rank', 'iv_current', 'iv_change', 'iv_risk_level', 'iv_risk_reason',
                    'event_date', 'days_to_event', 'event_risk_level',
                    # Phase 2: OI Spatial columns
                    'oi_skew_type', 'oi_directional_bias', 'oi_spatial_risk_level',
                    'writer_call_oi_concentration_pct', 'writer_put_oi_concentration_pct',
                    'writer_max_call_oi_value', 'writer_max_put_oi_value',
                    # Greeks columns (theta, gamma, vega, breakeven)
                    'theta_per_day', 'gamma_atm', 'vega', 'greeks_theta_quality', 'greeks_gamma_risk',
                    'greeks_vega_exposure', 'greeks_suitable_for_straddle', 'greeks_risk_reason',
                    'breakeven_upper', 'breakeven_lower', 'min_be_distance_pct',
                    # NEW: Hedge recommendations for gap risk protection
                    'gap_risk_level', 'hedge_recommended', 'hedge_strategy',
                    'hedge_call_wing_strike', 'hedge_put_wing_strike', 'hedge_wing_distance_pct',
                    'estimated_hedge_cost_pct', 'hedged_max_loss_estimate', 'hedge_reason',
                    #
                    'straddle_strengths', 'straddle_risk_factors', 'straddle_deployment_timing',
                    'straddle_expected_range_lower', 'straddle_expected_range_upper',
                    'trade_setup', 'current_fut_oi', 'next_fut_oi'
                ]
                straddle_top[[col for col in straddle_cols if col in straddle_top.columns]].to_csv(straddle_file, index=False, float_format='%.2f')
                logger.info(f"Top straddles saved to {straddle_file}")
        except Exception as e:
            logger.error(f"Error saving top straddles: {e}")
        
        # Top Directional
        try:
            directional_top = self.df[self.df['directional_suitable']].nlargest(10, 'directional_score')
            if len(directional_top) > 0:
                directional_file = f"top_directional_{self.output_timestamp}.csv"
                directional_cols = [
                    'symbol', 'directional_rank', 'directional_score', 'directional_score_raw', 'directional_score_normalized',
                    'directional_strength', 'combined_sentiment', 'confidence_percent', 'directional_conviction_gap',
                    'spot_price', 'action', 'writer_pcr_oi', 'rollover_quality_index', 'rollover_percent',
                    'directional_strengths', 'directional_risk_factors', 'directional_entry_timing',
                    'directional_target_1', 'directional_target_2', 'directional_stop_loss',
                    'selected_option_symbol', 'selected_option_strike', 'selected_option_premium',
                    'selected_option_oi', 'selected_option_volume', 'trade_setup'
                ]
                directional_top[[col for col in directional_cols if col in directional_top.columns]].to_csv(directional_file, index=False, float_format='%.2f')
                logger.info(f"Top directional trades saved to {directional_file}")
        except Exception as e:
            logger.error(f"Error saving top directional: {e}")
    
    def print_summary(self):
        """Print summary to console"""
        print("\n" + "="*100)
        print("COMPREHENSIVE MARKET INSIGHT SCANNER - SUMMARY")
        print("="*100)
        
        print(f"\n{'='*100}")
        print(f"Market Phase: {self.market_phase}")
        print(f"Total Stocks Analyzed: {self.market_summary['total_stocks']}")
        print(f"{'='*100}")
        
        print(f"\nSENTIMENT DISTRIBUTION:")
        print(f"  Neutral: {self.market_summary['neutral_sentiment_pct']:.1f}%")
        print(f"  Average Confidence: {self.market_summary['avg_confidence']:.1f}%")
        print(f"  Average Rollover: {self.market_summary['avg_rollover']:.1f}%")
        print(f"  Average PCR: {self.market_summary['avg_pcr']:.2f}")
        
        print(f"\nOPPORTUNITIES:")
        print(f"  Tradeable Signals (BUY): {self.market_summary['tradeable_signals']}")
        print(f"  Short Straddle Candidates: {self.market_summary['straddle_opportunities']}")
        print(f"    - Tier 1 (Best): {self.summary_stats['straddle_tier1_count']}")
        print(f"    - Tier 2 (Good): {self.summary_stats['straddle_tier2_count']}")
        print(f"    - Tier 3 (Acceptable): {self.summary_stats['straddle_tier3_count']}")
        print(f"  Directional Candidates: {self.market_summary['directional_opportunities']}")
        print(f"    - Very Strong/Strong: {self.summary_stats['directional_very_strong'] + self.summary_stats['directional_strong']}")
        print(f"    - Ready Now: {self.summary_stats['directional_ready_now']}")
        print(f"    - Watch List: {self.summary_stats['directional_watch']}")
        
        print(f"\nRISK ASSESSMENT:")
        print(f"  Stocks with High Rollover Risk: {self.summary_stats['high_rollover_risk']} ({self.market_summary['low_rollover_pct']:.1f}%)")
        print(f"  Stocks with Extreme Writer Resistance: {self.summary_stats['extreme_writer_resistance']}")
        print(f"  High Volatility Stocks: {self.summary_stats['high_volatility_stocks']}")
        
        # NEW: IV and Event Risk Stats
        if self.summary_stats.get('stocks_with_iv_data', 0) > 0:
            print(f"\nIV & EVENT RISK ASSESSMENT:")
            print(f"  Stocks with IV Data: {self.summary_stats['stocks_with_iv_data']}/{self.market_summary['total_stocks']}")
            print(f"  Unsuitable IV for Selling: {self.summary_stats['unsuitable_iv_for_selling']}")
            print(f"  Low IV Stocks (< 40th percentile): {self.summary_stats['low_iv_stocks']}")
            print(f"  High IV Stocks (>= 60th percentile): {self.summary_stats['high_iv_stocks']}")
            print(f"  IV Spikes Detected: {self.summary_stats['iv_spikes_detected']}")
            print(f"  Event Risk Blocked: {self.summary_stats['event_risk_blocked_stocks']}")
            print(f"  Upcoming Events: {self.summary_stats['stocks_with_upcoming_events']}")
            if self.summary_stats.get('avg_iv_percentile'):
                print(f"  Average IV Percentile: {self.summary_stats['avg_iv_percentile']:.1f}th")
        else:
            print(f"\n[WARNING] No IV/Event data available - analysis incomplete")
            print(f"  Provide options_screener CSV for full risk assessment")
        
        # Print top 5 recommendations
        print(f"\n{'='*100}")
        print("TOP 5 RECOMMENDATIONS:")
        print(f"{'='*100}")
        
        top_recs = self.df[self.df['primary_recommendation'].isin(['DIRECTIONAL TRADE', 'SHORT STRADDLE', 'WATCH - Near Signal'])].head(10)
        for idx, (i, row) in enumerate(top_recs.iterrows(), 1):
            print(f"\n{idx}. {row['symbol']} - {row['primary_recommendation']}")
            print(f"   {row['recommendation_reason']}")
            if pd.notna(row['trade_setup']) and row['trade_setup']:
                print(f"   Setup: {row['trade_setup']}")
        
        print(f"\n{'='*100}\n")
    
    def run_comprehensive_analysis(self):
        """Run complete analysis pipeline"""
        logger.info("="*80)
        logger.info("Starting Comprehensive Insight Scanner")
        logger.info("="*80)
        
        # Load data
        if not self.load_data():
            logger.error("Failed to load data. Exiting.")
            return False
        
        # Load IV and event data (optional but recommended)
        iv_loaded = self.load_iv_data()
        if iv_loaded:
            logger.info("IV and event data loaded successfully")
        else:
            logger.warning("Proceeding without IV/Event data - analysis will be limited")
        
        # Load Greeks data (optional but recommended)
        greeks_loaded = self.load_greeks_data()
        if greeks_loaded:
            logger.info("Greeks data loaded successfully")
        else:
            logger.warning("Proceeding without Greeks data - risk analysis will be limited")
        
        # Merge expert-level scores for context
        experts_loaded = self.load_expert_results()
        if experts_loaded:
            logger.info("Expert results merged for contextual reporting")
        else:
            logger.warning("Specialist score merge skipped - reports will omit expert columns")
        
        # Run analysis steps (order matters!)
        if iv_loaded:
            self.analyze_iv_and_event_risks()  # Must run before straddle metrics
        
        if greeks_loaded:
            self.analyze_greeks_risks()  # Analyze Greeks-based risks
        
        self.analyze_oi_spatial_patterns()  # Phase 2: OI spatial analysis
        
        self.calculate_straddle_metrics()
        self.calculate_hedge_recommendations()  # NEW: Gap risk and hedge suggestions for 0.2 delta strangles
        self.calculate_directional_metrics()
        self.add_risk_classifications()
        self.add_actionable_recommendations()
        self.classify_market_condition()
        
        # Generate summary
        self.generate_summary_stats()
        
        # Save outputs
        comprehensive_file = self.save_comprehensive_output()
        summary_file = self.save_summary_report()
        
        # Print summary
        self.print_summary()
        
        logger.info("="*80)
        logger.info("Comprehensive Analysis Complete")
        logger.info(f"Main Output: {comprehensive_file}")
        logger.info(f"Summary: {summary_file}")
        logger.info("="*80)
        
        return True


def main():
    """Main execution function"""
    print("\n" + "="*100)
    print("COMPREHENSIVE INSIGHT SCANNER v2.0")
    print("Analyzes OITrendScanner output with IV percentile and event risk detection")
    print("="*100 + "\n")
    
    # Check for input file
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
    else:
        # Auto-detect latest trend results file
        import glob
        trend_files = glob.glob("trend_results_adaptive_v10_nuance_*.csv")
        if trend_files:
            input_file = max(trend_files, key=os.path.getmtime)
            logger.info(f"Auto-detected latest trend results file: {input_file}")
        else:
            logger.error("No trend_results CSV file found in current directory")
            logger.error("Usage: python ComprehensiveInsightScanner.py <trend_results.csv> [options_screener.csv]")
            logger.error("   Or: Place trend_results_adaptive_v10_nuance_*.csv in same directory")
            return
    
    if not os.path.exists(input_file):
        logger.error(f"Input file not found: {input_file}")
        return
    
    # Check for options screener file (for IV and event data)
    options_screener_file = None
    if len(sys.argv) > 2:
        options_screener_file = sys.argv[2]
    else:
        # Auto-detect latest options screener file
        import glob
        screener_files = glob.glob("options_screener_*.csv")
        if screener_files:
            options_screener_file = max(screener_files, key=os.path.getmtime)
            logger.info(f"Auto-detected options screener file: {options_screener_file}")
        else:
            logger.warning("No options_screener CSV found. IV/Event analysis will be skipped.")
            logger.warning("For full analysis, provide: options_screener_YYYY-MM-DD-HH-MM-SS.csv")
    
    # Run scanner
    scanner = ComprehensiveInsightScanner(input_file, options_screener_file)
    success = scanner.run_comprehensive_analysis()
    
    if success:
        print("\n[SUCCESS] Analysis complete! Check the output files:")
        print(f"   - comprehensive_insights_{scanner.output_timestamp}.csv (Full analysis)")
        print(f"   - top_straddles_{scanner.output_timestamp}.csv (Top 10 straddle opportunities)")
        print(f"   - top_directional_{scanner.output_timestamp}.csv (Top 10 directional trades)")
        print(f"   - market_summary_{scanner.output_timestamp}.csv (Market overview)")
        print(f"   - comprehensive_insight_scanner.log (Detailed log)")
    else:
        print("\n[FAILED] Analysis failed. Check comprehensive_insight_scanner.log for details")


if __name__ == "__main__":
    main()

