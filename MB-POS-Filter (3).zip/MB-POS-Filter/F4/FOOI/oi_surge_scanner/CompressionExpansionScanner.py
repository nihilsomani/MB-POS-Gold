import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
import time

# ============================================================================
# NON-FNO COMPRESSION-EXPANSION SCANNER WITH CPR
# Philosophy: Price + Volume + EMAs + AVWAP + CPR = Institutional Behavior
# ============================================================================

class CompressionExpansionScanner:
    def __init__(self, api_key, access_token):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
    def get_historical_data(self, symbol, from_date, to_date, interval):
        """Fetch historical data from Zerodha"""
        try:
            data = self.kite.historical_data(
                instrument_token=symbol,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            df = pd.DataFrame(data)
            return df
        except Exception as e:
            print(f"Error fetching data for {symbol}: {e}")
            return None
    
    def calculate_ema(self, df, period):
        """Calculate EMA"""
        return df['close'].ewm(span=period, adjust=False).mean()
    
    def calculate_vwap(self, df):
        """Calculate standard VWAP"""
        df['vwap'] = (df['volume'] * (df['high'] + df['low'] + df['close']) / 3).cumsum() / df['volume'].cumsum()
        return df['vwap']
    
    def calculate_anchored_vwap(self, df, anchor_index):
        """Calculate AVWAP from a specific anchor point"""
        subset = df.iloc[anchor_index:].copy()
        typical_price = (subset['high'] + subset['low'] + subset['close']) / 3
        vwap = (typical_price * subset['volume']).cumsum() / subset['volume'].cumsum()
        return vwap
    
    def calculate_cpr(self, df):
        """
        Calculate Central Pivot Range (CPR)
        
        Pivot = (High + Low + Close) / 3
        BC (Bottom Central) = (High + Low) / 2
        TC (Top Central) = (Pivot - BC) + Pivot
        
        CPR Width = TC - BC
        Narrow CPR = consolidation/compression (potential breakout)
        Wide CPR = volatility/distribution
        """
        # Use previous day's data to calculate today's CPR
        df['pivot'] = (df['high'].shift(1) + df['low'].shift(1) + df['close'].shift(1)) / 3
        df['bc'] = (df['high'].shift(1) + df['low'].shift(1)) / 2
        df['tc'] = (df['pivot'] - df['bc']) + df['pivot']
        
        # CPR width (absolute and as % of pivot)
        df['cpr_width'] = df['tc'] - df['bc']
        df['cpr_width_pct'] = (df['cpr_width'] / df['pivot']) * 100
        
        # R1, R2, R3 and S1, S2, S3 (Classic Pivot Points)
        df['r1'] = 2 * df['pivot'] - df['low'].shift(1)
        df['r2'] = df['pivot'] + (df['high'].shift(1) - df['low'].shift(1))
        df['r3'] = df['r1'] + (df['high'].shift(1) - df['low'].shift(1))
        
        df['s1'] = 2 * df['pivot'] - df['high'].shift(1)
        df['s2'] = df['pivot'] - (df['high'].shift(1) - df['low'].shift(1))
        df['s3'] = df['s1'] - (df['high'].shift(1) - df['low'].shift(1))
        
        return df
    
    def classify_cpr(self, cpr_width_pct, lookback_avg_width_pct):
        """
        Classify CPR as Virgin/Narrow/Wide
        
        Virgin CPR: Extremely narrow (< 0.3% of pivot) - highest probability setup
        Narrow CPR: < 50% of average width - consolidation/compression
        Normal CPR: 50-150% of average width
        Wide CPR: > 150% of average width - volatility/avoid
        """
        if cpr_width_pct < 0.3:
            return "VIRGIN_CPR"
        elif cpr_width_pct < (lookback_avg_width_pct * 0.5):
            return "NARROW_CPR"
        elif cpr_width_pct < (lookback_avg_width_pct * 1.5):
            return "NORMAL_CPR"
        else:
            return "WIDE_CPR"
    
    def check_cpr_position(self, df):
        """
        Check price position relative to CPR:
        - Above TC = Bullish
        - Between TC and BC = Inside CPR (consolidation)
        - Below BC = Bearish
        """
        current_price = df['close'].iloc[-1]
        tc = df['tc'].iloc[-1]
        bc = df['bc'].iloc[-1]
        
        if current_price > tc:
            return "ABOVE_CPR"
        elif current_price < bc:
            return "BELOW_CPR"
        else:
            return "INSIDE_CPR"
    
    def find_pivot_points(self, df, window=20):
        """Find swing highs and lows for AVWAP anchoring"""
        df['pivot_high'] = df['high'][(df['high'].shift(1) < df['high']) & (df['high'].shift(-1) < df['high'])]
        df['pivot_low'] = df['low'][(df['low'].shift(1) > df['low']) & (df['low'].shift(-1) > df['low'])]
        
        # Get most recent significant pivot
        recent_high_idx = df['pivot_high'].last_valid_index()
        recent_low_idx = df['pivot_low'].last_valid_index()
        
        return recent_high_idx, recent_low_idx
    
    def calculate_atr(self, df, period=14):
        """Calculate Average True Range"""
        high_low = df['high'] - df['low']
        high_close = abs(df['high'] - df['close'].shift())
        low_close = abs(df['low'] - df['close'].shift())
        
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        atr = tr.rolling(window=period).mean()
        return atr
    
    def analyze_volume_character(self, df, lookback=5):
        """
        Analyze volume behavior:
        - Accumulation: Price up + Volume up
        - Distribution: Price up + Volume down
        - Healthy pullback: Price down + Volume down
        - Panic selling: Price down + Volume up
        """
        recent = df.tail(lookback)
        
        avg_volume = recent['volume'].mean()
        current_volume = df.iloc[-1]['volume']
        
        price_change = df.iloc[-1]['close'] - df.iloc[-lookback]['close']
        volume_change = current_volume - avg_volume
        
        if price_change > 0 and volume_change > 0:
            return "ACCUMULATION"
        elif price_change > 0 and volume_change < 0:
            return "DISTRIBUTION"
        elif price_change < 0 and volume_change < 0:
            return "HEALTHY_PULLBACK"
        elif price_change < 0 and volume_change > 0:
            return "SELLING_PRESSURE"
        else:
            return "NEUTRAL"
    
    def check_compression(self, df, lookback=5):
        """
        Check for compression:
        - Declining ATR (volatility contraction)
        - Narrowing candle ranges
        - Declining volume
        - Narrow CPR (added)
        """
        atr = self.calculate_atr(df)
        recent_atr = atr.tail(lookback)
        
        # Check if ATR is declining
        atr_declining = recent_atr.is_monotonic_decreasing or (recent_atr.iloc[-1] < recent_atr.iloc[0])
        
        # Check if candle ranges are narrowing
        candle_range = df['high'] - df['low']
        recent_ranges = candle_range.tail(lookback)
        ranges_narrowing = recent_ranges.iloc[-1] < recent_ranges.mean()
        
        # Check if volume is declining
        recent_volume = df['volume'].tail(lookback)
        volume_declining = recent_volume.iloc[-1] < recent_volume.mean()
        
        # Check CPR - narrow CPR adds to compression signal
        current_cpr_width = df['cpr_width_pct'].iloc[-1]
        avg_cpr_width = df['cpr_width_pct'].tail(20).mean()
        cpr_narrow = current_cpr_width < (avg_cpr_width * 0.5)
        
        compression_score = sum([atr_declining, ranges_narrowing, volume_declining, cpr_narrow])
        
        return compression_score >= 3  # At least 3 out of 4 conditions
    
    def check_ema_alignment(self, df):
        """
        Check EMA stacking:
        Bullish: 9 > 21 > 50
        Bearish: 9 < 21 < 50
        """
        ema9 = df['ema_9'].iloc[-1]
        ema21 = df['ema_21'].iloc[-1]
        ema50 = df['ema_50'].iloc[-1]
        
        if ema9 > ema21 > ema50:
            return "BULLISH_STACK"
        elif ema9 < ema21 < ema50:
            return "BEARISH_STACK"
        else:
            return "MIXED"
    
    def check_avwap_position(self, df):
        """Check if price is above or below AVWAP (bullish/bearish)"""
        current_price = df['close'].iloc[-1]
        current_avwap = df['avwap'].iloc[-1]
        
        if current_price > current_avwap:
            return "ABOVE_AVWAP"
        else:
            return "BELOW_AVWAP"
    
    def check_weekly_structure(self, weekly_df):
        """
        Check weekly timeframe for trend confirmation:
        - Above 21/50 EMA
        - Higher highs, higher lows
        """
        if len(weekly_df) < 50:
            return "INSUFFICIENT_DATA"
        
        weekly_df['ema_21'] = self.calculate_ema(weekly_df, 21)
        weekly_df['ema_50'] = self.calculate_ema(weekly_df, 50)
        
        current_price = weekly_df['close'].iloc[-1]
        ema21 = weekly_df['ema_21'].iloc[-1]
        ema50 = weekly_df['ema_50'].iloc[-1]
        
        # Check if above EMAs
        above_ema21 = current_price > ema21
        above_ema50 = current_price > ema50
        
        # Check for higher highs and higher lows (last 4 weeks)
        recent_highs = weekly_df['high'].tail(4)
        recent_lows = weekly_df['low'].tail(4)
        
        higher_highs = recent_highs.iloc[-1] > recent_highs.iloc[0]
        higher_lows = recent_lows.iloc[-1] > recent_lows.iloc[0]
        
        if above_ema21 and above_ema50 and higher_highs and higher_lows:
            return "STRONG_UPTREND"
        elif above_ema21 and above_ema50:
            return "UPTREND"
        elif not above_ema21 and not above_ema50:
            return "DOWNTREND"
        else:
            return "CONSOLIDATION"
    
    def calculate_confidence_score(self, daily_df, weekly_df):
        """
        Calculate overall confidence score based on multiple factors:
        - Weekly structure (25%)
        - EMA alignment (20%)
        - Compression (20%)
        - CPR classification (20%) - NEW
        - AVWAP position (10%)
        - Volume character (5%)
        """
        score = 0
        factors = {}
        
        # Weekly structure (25 points)
        weekly_structure = self.check_weekly_structure(weekly_df)
        if weekly_structure == "STRONG_UPTREND":
            score += 25
            factors['weekly'] = 'Strong Uptrend'
        elif weekly_structure == "UPTREND":
            score += 18
            factors['weekly'] = 'Uptrend'
        elif weekly_structure == "CONSOLIDATION":
            score += 10
            factors['weekly'] = 'Consolidation'
        else:
            factors['weekly'] = weekly_structure
        
        # EMA alignment (20 points)
        ema_alignment = self.check_ema_alignment(daily_df)
        if ema_alignment == "BULLISH_STACK":
            score += 20
            factors['ema_stack'] = 'Bullish (9>21>50)'
        elif ema_alignment == "BEARISH_STACK":
            score += 5
            factors['ema_stack'] = 'Bearish (9<21<50)'
        else:
            factors['ema_stack'] = 'Mixed'
        
        # Compression (20 points)
        is_compressed = self.check_compression(daily_df)
        if is_compressed:
            score += 20
            factors['compression'] = 'Yes (Vol+ATR+CPR)'
        else:
            factors['compression'] = 'No'
        
        # CPR Classification (20 points) - NEW
        current_cpr_width = daily_df['cpr_width_pct'].iloc[-1]
        avg_cpr_width = daily_df['cpr_width_pct'].tail(20).mean()
        cpr_type = self.classify_cpr(current_cpr_width, avg_cpr_width)
        
        if cpr_type == "VIRGIN_CPR":
            score += 20
            factors['cpr'] = f'Virgin ({current_cpr_width:.2f}%)'
        elif cpr_type == "NARROW_CPR":
            score += 15
            factors['cpr'] = f'Narrow ({current_cpr_width:.2f}%)'
        elif cpr_type == "NORMAL_CPR":
            score += 8
            factors['cpr'] = f'Normal ({current_cpr_width:.2f}%)'
        else:
            score += 0
            factors['cpr'] = f'Wide ({current_cpr_width:.2f}%)'
        
        # AVWAP position (10 points)
        avwap_pos = self.check_avwap_position(daily_df)
        if avwap_pos == "ABOVE_AVWAP":
            score += 10
            factors['avwap'] = 'Above AVWAP'
        else:
            factors['avwap'] = 'Below AVWAP'
        
        # Volume character (5 points)
        vol_char = self.analyze_volume_character(daily_df)
        if vol_char == "ACCUMULATION":
            score += 5
            factors['volume'] = 'Accumulation'
        elif vol_char == "HEALTHY_PULLBACK":
            score += 3
            factors['volume'] = 'Healthy Pullback'
        else:
            factors['volume'] = vol_char
        
        # CPR Position bonus (additional context)
        cpr_position = self.check_cpr_position(daily_df)
        factors['cpr_position'] = cpr_position
        
        return score, factors
    
    def scan_stock(self, instrument_token, symbol_name):
        """Scan a single stock for compression-expansion setup"""
        
        # Date ranges
        to_date = datetime.now()
        daily_from = to_date - timedelta(days=120)  # ~4 months
        weekly_from = to_date - timedelta(days=365)  # ~1 year
        
        # Fetch daily data
        daily_df = self.get_historical_data(instrument_token, daily_from, to_date, "day")
        if daily_df is None or len(daily_df) < 50:
            return None
        
        # Fetch weekly data
        weekly_df = self.get_historical_data(instrument_token, weekly_from, to_date, "week")
        if weekly_df is None or len(weekly_df) < 50:
            return None
        
        # Calculate EMAs
        daily_df['ema_9'] = self.calculate_ema(daily_df, 9)
        daily_df['ema_21'] = self.calculate_ema(daily_df, 21)
        daily_df['ema_50'] = self.calculate_ema(daily_df, 50)
        
        # Calculate CPR
        daily_df = self.calculate_cpr(daily_df)
        
        # Calculate AVWAP from most recent pivot
        pivot_high_idx, pivot_low_idx = self.find_pivot_points(daily_df)
        
        # Use most recent pivot (high or low) as anchor
        if pivot_high_idx is not None and pivot_low_idx is not None:
            anchor_idx = max(pivot_high_idx, pivot_low_idx)
        elif pivot_high_idx is not None:
            anchor_idx = pivot_high_idx
        elif pivot_low_idx is not None:
            anchor_idx = pivot_low_idx
        else:
            anchor_idx = 0  # Use start of data if no pivots found
        
        avwap = self.calculate_anchored_vwap(daily_df, anchor_idx)
        daily_df.loc[avwap.index, 'avwap'] = avwap
        daily_df['avwap'].fillna(method='ffill', inplace=True)
        
        # Calculate confidence score
        confidence_score, factors = self.calculate_confidence_score(daily_df, weekly_df)
        
        # Current values
        current_price = daily_df['close'].iloc[-1]
        ema9 = daily_df['ema_9'].iloc[-1]
        ema21 = daily_df['ema_21'].iloc[-1]
        ema50 = daily_df['ema_50'].iloc[-1]
        current_avwap = daily_df['avwap'].iloc[-1]
        atr = self.calculate_atr(daily_df).iloc[-1]
        
        # CPR values
        pivot = daily_df['pivot'].iloc[-1]
        tc = daily_df['tc'].iloc[-1]
        bc = daily_df['bc'].iloc[-1]
        cpr_width = daily_df['cpr_width'].iloc[-1]
        cpr_width_pct = daily_df['cpr_width_pct'].iloc[-1]
        
        # Distance from EMAs and CPR (%)
        dist_from_9ema = ((current_price - ema9) / ema9) * 100
        dist_from_21ema = ((current_price - ema21) / ema21) * 100
        dist_from_avwap = ((current_price - current_avwap) / current_avwap) * 100
        dist_from_pivot = ((current_price - pivot) / pivot) * 100
        
        result = {
            'symbol': symbol_name,
            'ltp': round(current_price, 2),
            'confidence_score': confidence_score,
            'weekly_structure': factors['weekly'],
            'ema_stack': factors['ema_stack'],
            'compression': factors['compression'],
            'cpr_type': factors['cpr'],
            'cpr_position': factors['cpr_position'],
            'avwap_position': factors['avwap'],
            'volume_character': factors['volume'],
            'ema_9': round(ema9, 2),
            'ema_21': round(ema21, 2),
            'ema_50': round(ema50, 2),
            'avwap': round(current_avwap, 2),
            'pivot': round(pivot, 2),
            'tc': round(tc, 2),
            'bc': round(bc, 2),
            'cpr_width': round(cpr_width, 2),
            'cpr_width_%': round(cpr_width_pct, 2),
            'dist_9ema_%': round(dist_from_9ema, 2),
            'dist_21ema_%': round(dist_from_21ema, 2),
            'dist_avwap_%': round(dist_from_avwap, 2),
            'dist_pivot_%': round(dist_from_pivot, 2),
            'atr': round(atr, 2)
        }
        
        return result
    
    def run_scan(self, instrument_list, min_confidence=60):
        """
        Run scanner on list of instruments
        instrument_list: List of tuples [(instrument_token, symbol_name), ...]
        min_confidence: Minimum confidence score to filter (0-100)
        """
        results = []
        
        print(f"Scanning {len(instrument_list)} stocks...")
        print("=" * 80)
        
        for idx, (token, symbol) in enumerate(instrument_list, 1):
            print(f"[{idx}/{len(instrument_list)}] Scanning {symbol}...", end=' ')
            
            try:
                result = self.scan_stock(token, symbol)
                
                if result and result['confidence_score'] >= min_confidence:
                    results.append(result)
                    print(f"✓ Score: {result['confidence_score']} | CPR: {result['cpr_type']}")
                else:
                    print("✗ Below threshold")
                
                time.sleep(0.3)  # Rate limiting
                
            except Exception as e:
                print(f"✗ Error: {e}")
                continue
        
        # Sort by confidence score
        results.sort(key=lambda x: x['confidence_score'], reverse=True)
        
        return results
    
    def display_results(self, results):
        """Display scan results in readable format"""
        if not results:
            print("\nNo stocks found matching criteria.")
            return
        
        print("\n" + "=" * 80)
        print(f"COMPRESSION-EXPANSION SCANNER RESULTS ({len(results)} stocks)")
        print("=" * 80)
        
        for idx, stock in enumerate(results, 1):
            print(f"\n{idx}. {stock['symbol']} | LTP: ₹{stock['ltp']} | Confidence: {stock['confidence_score']}/100")
            print("-" * 80)
            print(f"Weekly Structure: {stock['weekly_structure']}")
            print(f"EMA Stack: {stock['ema_stack']}")
            print(f"Compression: {stock['compression']}")
            print(f"CPR: {stock['cpr_type']} | Position: {stock['cpr_position']}")
            print(f"AVWAP: {stock['avwap_position']}")
            print(f"Volume: {stock['volume_character']}")
            print(f"\nCPR Levels:")
            print(f"  TC (Top):    ₹{stock['tc']}")
            print(f"  Pivot:       ₹{stock['pivot']} ({stock['dist_pivot_%']:+.2f}%)")
            print(f"  BC (Bottom): ₹{stock['bc']}")
            print(f"  CPR Width:   ₹{stock['cpr_width']} ({stock['cpr_width_%']:.2f}%)")
            print(f"\nEMA & AVWAP Levels:")
            print(f"  9 EMA:  ₹{stock['ema_9']} ({stock['dist_9ema_%']:+.2f}%)")
            print(f"  21 EMA: ₹{stock['ema_21']} ({stock['dist_21ema_%']:+.2f}%)")
            print(f"  50 EMA: ₹{stock['ema_50']}")
            print(f"  AVWAP:  ₹{stock['avwap']} ({stock['dist_avwap_%']:+.2f}%)")
            print(f"  ATR:    ₹{stock['atr']}")


# ============================================================================
# USAGE WITH INPUT.CSV
# ============================================================================

if __name__ == "__main__":
    
    # Your Zerodha credentials
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "1KYtPvWRd0I92BORjCWSJROzXWTIsEnT"
    
    # Initialize scanner
    scanner = CompressionExpansionScanner(API_KEY, ACCESS_TOKEN)
    
    # Read symbols from input.csv
    # Expected CSV format:
    # instrument_token,symbol
    # 738561,ZOMATO
    # 7707649,PAYTM
    
    try:
        input_df = pd.read_csv('data/sector_marketcap_great8000.csv')
        print(f"Loaded {len(input_df)} symbols from input.csv")
        
        # Create list of tuples
        stock_list = list(zip(input_df['instrument_token'], input_df['symbol']))
        
    except FileNotFoundError:
        print("Error: input.csv not found!")
        print("Please create input.csv with columns: instrument_token,symbol")
        exit(1)
    except KeyError:
        print("Error: input.csv must have columns 'instrument_token' and 'symbol'")
        exit(1)
    
    # Run scan with minimum 65% confidence
    results = scanner.run_scan(stock_list, min_confidence=65)
    
    # Display results
    scanner.display_results(results)
    
    # Export to CSV
    if results:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")
        df_results = pd.DataFrame(results)
        df_results.to_csv(f'compression_scan_{timestamp}.csv', index=False)
        print(f"\n✓ Results exported to compression_scan_{timestamp}.csv")