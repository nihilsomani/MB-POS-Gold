"""
OI SURGE SCANNER - Early Detection System
==========================================

Detects explosive OI buildup in first 1-2 hours of trading
Catches institutional positioning BEFORE retail crowd

Features:
- Gold Master: Tracks previous day closing OI
- Live Monitoring: Scans every 15 min (9:30-11:00 AM)
- Historical Database: Stores all snapshots
- Smart Alerts: 30%+ OI surge + Premium expansion
- All Phases: 1, 2, 3 implemented

Author: Your Trading System
Date: 2024-11-29
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import time
import logging
import os
from typing import Dict, List, Optional, Tuple
import csv

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class OISurgeConfig:
    """Configuration for OI Surge Scanner"""
    
    # Alert Thresholds
    MIN_OI_SURGE_PCT = 30      # 30%+ OI increase triggers alert
    STRONG_SURGE_PCT = 50      # 50%+ = strong signal
    EXPLOSIVE_SURGE_PCT = 100  # 100%+ = explosive (rare)
    
    # Premium Thresholds
    MIN_PREMIUM_VS_VWAP = 3    # 3%+ above VWAP
    STRONG_PREMIUM_VS_VWAP = 5 # 5%+ = strong
    
    # Timing
    SCAN_START_TIME = (9, 30)  # 9:30 AM
    SCAN_END_TIME = (11, 0)    # 11:00 AM
    SCAN_INTERVAL_MIN = 15     # Every 15 minutes
    
    # Master Update
    MASTER_UPDATE_TIME = (15, 30)  # 3:30 PM daily
    
    # File Paths
    MASTER_FILE = "MB-POS-Filter/F4/FOOI/oi_surge_scanner/oi_master.csv"
    HISTORY_FILE = "MB-POS-Filter/F4/FOOI/oi_surge_scanner/oi_history.csv"
    ALERTS_DIR = "MB-POS-Filter/F4/FOOI/oi_surge_scanner/alerts"
    # Option Selection
    ATM_RANGE_PCT = 10  # ±10% from spot for option strikes


class OISurgeScanner:
    """
    OI Surge Detection Scanner
    
    Monitors option OI in real-time and alerts on institutional positioning
    """
    
    def __init__(self, api_key: str, access_token: str):
        """Initialize scanner"""
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Load instrument cache
        self.instrument_cache = {}
        self._load_instruments()
        
        # Load gold master
        self.oi_master = self._load_oi_master()
        
        # Track alerts to avoid duplicates
        self.alerted_today = set()
        
        logger.info("OISurgeScanner initialized successfully")
    
    def _load_instruments(self):
        """Load and cache NFO instruments"""
        logger.info("Loading NFO instruments...")
        instruments = self.kite.instruments("NFO")
        
        for inst in instruments:
            symbol = inst['tradingsymbol']
            self.instrument_cache[symbol] = {
                'token': inst['instrument_token'],
                'exchange': inst['exchange'],
                'strike': inst.get('strike', 0),
                'expiry': inst.get('expiry'),
                'instrument_type': inst.get('instrument_type', '')
            }
        
        logger.info(f"Loaded {len(self.instrument_cache)} NFO instruments")
    
    def _load_oi_master(self) -> pd.DataFrame:
        """
        Load gold master file (previous day closing OI)
        
        Returns:
            DataFrame with columns: symbol, token, closing_oi, last_updated
        """
        if os.path.exists(OISurgeConfig.MASTER_FILE):
            df = pd.read_csv(OISurgeConfig.MASTER_FILE)
            logger.info(f"Loaded OI master with {len(df)} entries")
            return df
        else:
            logger.warning("OI master file not found, creating new")
            return pd.DataFrame(columns=['symbol', 'token', 'closing_oi', 'last_updated'])
    
    def update_oi_master(self, symbols: List[str]):
        """
        Update gold master with today's closing OI
        Run this at 3:30 PM daily
        
        Args:
            symbols: List of underlying symbols to track
        """
        logger.info("=" * 80)
        logger.info("UPDATING OI MASTER (Gold Master)")
        logger.info("=" * 80)
        
        master_data = []
        
        for symbol in symbols:
            logger.info(f"Processing {symbol}...")
            
            # Get ATM options
            options = self._get_atm_options(symbol)
            
            if not options:
                continue
            
            # Get current OI for all options
            for opt in options:
                try:
                    key = f"NFO:{opt['symbol']}"
                    quote = self.kite.quote([key])
                    
                    if key in quote:
                        current_oi = quote[key].get('oi', 0)
                        
                        master_data.append({
                            'symbol': opt['symbol'],
                            'token': opt['token'],
                            'closing_oi': current_oi,
                            'last_updated': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                        })
                    
                    time.sleep(0.1)  # Rate limiting
                
                except Exception as e:
                    logger.error(f"Error fetching OI for {opt['symbol']}: {e}")
                    continue
        
        # Save to master file
        if master_data:
            df = pd.DataFrame(master_data)
            os.makedirs(os.path.dirname(OISurgeConfig.MASTER_FILE), exist_ok=True)
            df.to_csv(OISurgeConfig.MASTER_FILE, index=False)
            logger.info(f"✅ OI Master updated with {len(df)} entries")
            logger.info(f"Saved to: {OISurgeConfig.MASTER_FILE}")
        else:
            logger.warning("No data to update master")
    
    def _get_atm_options(self, symbol: str) -> List[Dict]:
        """
        Get ATM options (±10% from spot)
        
        Returns:
            List of option dicts with symbol, token, strike, type
        """
        try:
            # Get spot price
            spot_key = f"NSE:{symbol}"
            quote = self.kite.quote([spot_key])
            spot_price = quote[spot_key]['last_price']
            
            # Calculate ATM range
            lower_strike = spot_price * (1 - OISurgeConfig.ATM_RANGE_PCT / 100)
            upper_strike = spot_price * (1 + OISurgeConfig.ATM_RANGE_PCT / 100)
            
            # Find current month expiry options
            options = []
            for sym, data in self.instrument_cache.items():
                if symbol not in sym:
                    continue
                
                if data['instrument_type'] not in ['CE', 'PE']:
                    continue
                
                strike = data.get('strike', 0)
                if lower_strike <= strike <= upper_strike:
                    options.append({
                        'symbol': sym,
                        'token': data['token'],
                        'strike': strike,
                        'type': data['instrument_type'],
                        'expiry': data.get('expiry')
                    })
            
            # Filter to nearest expiry only
            if options:
                nearest_expiry = min(opt['expiry'] for opt in options if opt['expiry'])
                options = [opt for opt in options if opt['expiry'] == nearest_expiry]
            
            logger.debug(f"{symbol}: Found {len(options)} ATM options")
            return options
        
        except Exception as e:
            logger.error(f"Error getting ATM options for {symbol}: {e}")
            return []
    
    def _calculate_oi_surge(self, symbol: str, current_oi: int) -> float:
        """
        Calculate OI surge % vs gold master
        
        Args:
            symbol: Option symbol
            current_oi: Current OI value
        
        Returns:
            OI surge percentage (can be negative)
        """
        # Look up previous OI in master
        master_row = self.oi_master[self.oi_master['symbol'] == symbol]
        
        if master_row.empty:
            logger.debug(f"{symbol}: Not in master (new option?)")
            return 0.0
        
        previous_oi = master_row.iloc[0]['closing_oi']
        
        if previous_oi == 0:
            return 0.0
        
        surge_pct = ((current_oi - previous_oi) / previous_oi) * 100
        return surge_pct
    
    def _calculate_premium_vs_vwap(self, symbol: str, token: int) -> float:
        """
        Calculate premium vs VWAP from market open
        
        Args:
            symbol: Option symbol
            token: Instrument token
        
        Returns:
            Premium vs VWAP percentage
        """
        try:
            # Get today's data from market open
            now = datetime.now()
            market_open = now.replace(hour=9, minute=15, second=0, microsecond=0)
            
            # Fetch 5-min data
            from_date = market_open
            to_date = now
            
            df = pd.DataFrame(
                self.kite.historical_data(
                    token, from_date, to_date, '5minute'
                )
            )
            
            if df.empty or len(df) < 3:
                logger.debug(f"{symbol}: Insufficient data for VWAP")
                return 0.0
            
            # Calculate VWAP
            df['vwap'] = (df['close'] * df['volume']).cumsum() / df['volume'].cumsum()
            
            # Get current premium
            key = f"NFO:{symbol}"
            quote = self.kite.quote([key])
            current_premium = quote[key]['last_price']
            
            vwap = df['vwap'].iloc[-1]
            
            if vwap == 0:
                return 0.0
            
            premium_vs_vwap = ((current_premium - vwap) / vwap) * 100
            
            return premium_vs_vwap
        
        except Exception as e:
            logger.debug(f"{symbol}: Error calculating VWAP: {e}")
            return 0.0
    
    def scan_for_oi_surges(self, symbols: List[str]) -> List[Dict]:
        """
        Scan for OI surges across all symbols
        
        Checks both:
        1. Individual strike surges (concentrated positioning)
        2. Aggregated call/put surges (broad positioning)
        
        Args:
            symbols: List of underlying symbols to scan
        
        Returns:
            List of alert dicts
        """
        logger.info("=" * 80)
        logger.info(f"OI SURGE SCAN - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("=" * 80)
        
        alerts = []
        
        for symbol in symbols:
            logger.info(f"Scanning {symbol}...")
            
            # Get ATM options
            options = self._get_atm_options(symbol)
            
            # Track aggregated OI for calls and puts separately
            call_data = {'current': 0, 'previous': 0, 'strikes': []}
            put_data = {'current': 0, 'previous': 0, 'strikes': []}
            
            # PART 1: Individual strike analysis
            for opt in options:
                try:
                    # Get current OI
                    key = f"NFO:{opt['symbol']}"
                    quote = self.kite.quote([key])
                    
                    if key not in quote:
                        continue
                    
                    current_oi = quote[key].get('oi', 0)
                    current_price = quote[key].get('last_price', 0)
                    
                    # Get previous OI from master
                    master_row = self.oi_master[self.oi_master['symbol'] == opt['symbol']]
                    previous_oi = master_row.iloc[0]['closing_oi'] if not master_row.empty else 0
                    
                    # Aggregate for call/put analysis
                    if opt['type'] == 'CE':
                        call_data['current'] += current_oi
                        call_data['previous'] += previous_oi
                        call_data['strikes'].append(opt['strike'])
                    else:  # PE
                        put_data['current'] += current_oi
                        put_data['previous'] += previous_oi
                        put_data['strikes'].append(opt['strike'])
                    
                    # Calculate individual strike OI surge
                    oi_surge_pct = self._calculate_oi_surge(opt['symbol'], current_oi)
                    
                    # Check if individual strike surge meets threshold
                    if oi_surge_pct >= OISurgeConfig.MIN_OI_SURGE_PCT:
                        
                        # Calculate premium vs VWAP
                        premium_vs_vwap = self._calculate_premium_vs_vwap(
                            opt['symbol'], opt['token']
                        )
                        
                        # Check if premium also expanding
                        if premium_vs_vwap >= OISurgeConfig.MIN_PREMIUM_VS_VWAP:
                            
                            # Generate alert
                            alert_key = f"{opt['symbol']}_{datetime.now().strftime('%Y%m%d')}"
                            
                            if alert_key not in self.alerted_today:
                                
                                alert = {
                                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                    'alert_type': 'INDIVIDUAL_STRIKE',
                                    'symbol': opt['symbol'],
                                    'underlying': symbol,
                                    'strike': opt['strike'],
                                    'type': opt['type'],
                                    'current_oi': current_oi,
                                    'previous_oi': previous_oi,
                                    'oi_surge_pct': oi_surge_pct,
                                    'current_price': current_price,
                                    'premium_vs_vwap': premium_vs_vwap,
                                    'signal_strength': self._classify_signal(oi_surge_pct, premium_vs_vwap)
                                }
                                
                                alerts.append(alert)
                                self.alerted_today.add(alert_key)
                                
                                # Log alert
                                self._log_alert(alert)
                    
                    time.sleep(0.1)  # Rate limiting
                
                except Exception as e:
                    logger.error(f"Error processing {opt['symbol']}: {e}")
                    continue
            
            # PART 2: Aggregated call/put analysis
            call_surge = self._analyze_aggregated_oi(symbol, call_data, 'CALL')
            put_surge = self._analyze_aggregated_oi(symbol, put_data, 'PUT')
            
            if call_surge:
                alerts.append(call_surge)
                self._log_alert(call_surge)
            
            if put_surge:
                alerts.append(put_surge)
                self._log_alert(put_surge)
        
        logger.info(f"Scan complete - {len(alerts)} new alerts generated")
        return alerts
    
    def _analyze_aggregated_oi(self, symbol: str, data: Dict, option_type: str) -> Optional[Dict]:
        """
        Analyze aggregated OI across all strikes
        
        Args:
            symbol: Underlying symbol
            data: Dict with current, previous OI totals and strikes
            option_type: 'CALL' or 'PUT'
        
        Returns:
            Alert dict if surge detected, None otherwise
        """
        if data['previous'] == 0:
            return None
        
        # Calculate aggregated surge
        agg_surge_pct = ((data['current'] - data['previous']) / data['previous']) * 100
        
        # Check threshold (use same as individual)
        if agg_surge_pct >= OISurgeConfig.MIN_OI_SURGE_PCT:
            
            # Check if already alerted for this aggregated pattern
            alert_key = f"{symbol}_{option_type}_AGG_{datetime.now().strftime('%Y%m%d')}"
            
            if alert_key in self.alerted_today:
                return None
            
            # Generate aggregated alert
            alert = {
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'alert_type': 'AGGREGATED',
                'symbol': f"{symbol}_ALL_{option_type}S",
                'underlying': symbol,
                'strike': 'MULTIPLE',
                'type': option_type,
                'current_oi': data['current'],
                'previous_oi': data['previous'],
                'oi_surge_pct': agg_surge_pct,
                'current_price': 0,  # N/A for aggregated
                'premium_vs_vwap': 0,  # N/A for aggregated
                'signal_strength': 'STRONG' if agg_surge_pct >= 50 else 'MODERATE',
                'strikes_involved': len(data['strikes']),
                'strike_range': f"{min(data['strikes'])}-{max(data['strikes'])}" if data['strikes'] else ''
            }
            
            self.alerted_today.add(alert_key)
            return alert
        
        return None
    
    def _classify_signal(self, oi_surge: float, premium_surge: float) -> str:
        """
        Classify signal strength
        
        Returns:
            'EXPLOSIVE', 'STRONG', or 'MODERATE'
        """
        if oi_surge >= OISurgeConfig.EXPLOSIVE_SURGE_PCT or premium_surge >= 10:
            return 'EXPLOSIVE'
        elif oi_surge >= OISurgeConfig.STRONG_SURGE_PCT or premium_surge >= OISurgeConfig.STRONG_PREMIUM_VS_VWAP:
            return 'STRONG'
        else:
            return 'MODERATE'
    
    def _log_alert(self, alert: Dict):
        """Log alert to console and file"""
        
        strength_emoji = {
            'EXPLOSIVE': '🚨🚨🚨',
            'STRONG': '⭐⭐',
            'MODERATE': '⚠️'
        }
        
        emoji = strength_emoji.get(alert['signal_strength'], '📊')
        
        logger.info("")
        
        # Different logging for aggregated vs individual alerts
        if alert.get('alert_type') == 'AGGREGATED':
            logger.info(f"{emoji} {alert['signal_strength']} AGGREGATED {alert['type']} OI SURGE!")
            logger.info(f"Underlying: {alert['underlying']}")
            logger.info(f"Pattern: Broad {alert['type'].lower()} buying across {alert['strikes_involved']} strikes")
            logger.info(f"Strike Range: {alert['strike_range']}")
            logger.info(f"Total OI: {alert['current_oi']:,} (was {alert['previous_oi']:,})")
            logger.info(f"Aggregated Surge: +{alert['oi_surge_pct']:.1f}%")
            logger.info(f"Interpretation: Institutional {alert['type'].lower()} positioning - NOT focused on single strike")
        else:
            logger.info(f"{emoji} {alert['signal_strength']} INDIVIDUAL STRIKE OI SURGE!")
            logger.info(f"Symbol: {alert['symbol']}")
            logger.info(f"Strike: {alert['strike']} {alert['type']}")
            logger.info(f"OI Surge: +{alert['oi_surge_pct']:.1f}%")
            logger.info(f"Premium: Rs.{alert['current_price']:.2f} (+{alert['premium_vs_vwap']:.1f}% vs VWAP)")
            logger.info(f"Current OI: {alert['current_oi']:,} (was {alert.get('previous_oi', 0):,})")
            logger.info(f"Interpretation: Concentrated positioning at {alert['strike']} strike")
        
        logger.info("")
        
        # Save to daily alerts file
        self._save_alert_to_file(alert)
    
    def _save_alert_to_file(self, alert: Dict):
        """Save alert to daily CSV file"""
        
        # Create alerts directory
        os.makedirs(OISurgeConfig.ALERTS_DIR, exist_ok=True)
        
        # Daily file
        today = datetime.now().strftime('%Y-%m-%d')
        filename = f"{OISurgeConfig.ALERTS_DIR}/oi_alerts_{today}.csv"
        
        # Check if file exists
        file_exists = os.path.exists(filename)
        
        # Write alert
        with open(filename, 'a', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=alert.keys())
            
            if not file_exists:
                writer.writeheader()
            
            writer.writerow(alert)
    
    def save_snapshot(self, symbols: List[str]):
        """
        Save current OI snapshot to history file
        For backtesting and pattern analysis
        
        Args:
            symbols: List of underlying symbols
        """
        logger.info("Saving OI snapshot to history...")
        
        snapshot_data = []
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        for symbol in symbols:
            options = self._get_atm_options(symbol)
            
            for opt in options:
                try:
                    key = f"NFO:{opt['symbol']}"
                    quote = self.kite.quote([key])
                    
                    if key in quote:
                        snapshot_data.append({
                            'timestamp': timestamp,
                            'symbol': opt['symbol'],
                            'strike': opt['strike'],
                            'type': opt['type'],
                            'oi': quote[key].get('oi', 0),
                            'price': quote[key].get('last_price', 0),
                            'volume': quote[key].get('volume', 0)
                        })
                    
                    time.sleep(0.1)
                
                except Exception as e:
                    logger.error(f"Error in snapshot for {opt['symbol']}: {e}")
                    continue
        
        # Append to history file
        if snapshot_data:
            df = pd.DataFrame(snapshot_data)
            
            os.makedirs(os.path.dirname(OISurgeConfig.HISTORY_FILE), exist_ok=True)
            
            if os.path.exists(OISurgeConfig.HISTORY_FILE):
                df.to_csv(OISurgeConfig.HISTORY_FILE, mode='a', header=False, index=False)
            else:
                df.to_csv(OISurgeConfig.HISTORY_FILE, index=False)
            
            logger.info(f"✅ Snapshot saved ({len(df)} entries)")


def load_universe(csv_path: str = "data/FNOStock.csv") -> List[str]:
    """
    Load stock universe from CSV file
    
    Args:
        csv_path: Path to CSV with stock symbols
    
    Returns:
        List of symbols
    """
    try:
        df = pd.read_csv(csv_path)
        # Assume first column contains symbols
        symbols = df.iloc[:, 0].tolist()
        logger.info(f"Loaded {len(symbols)} symbols from {csv_path}")
        return symbols
    except Exception as e:
        logger.error(f"Error loading universe from {csv_path}: {e}")
        logger.info("Using default universe instead")
        # Fallback to default
        return [
            'NIFTY', 'BANKNIFTY', 'FINNIFTY',
            'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK',
            'SBIN', 'BHARTIARTL', 'ITC', 'KOTAKBANK', 'LT',
            'AXISBANK', 'SUNPHARMA', 'TITAN', 'ADANIENT', 'IOC',
            'TATAMOTORS', 'MARUTI', 'WIPRO', 'ONGC', 'BAJFINANCE'
        ]


def main():
    """
    Main execution flow
    
    Usage:
        python oi_surge_scanner.py
    
    Modes:
        1. Morning scans (9:30-11:00 AM): Detect OI surges
        2. EOD update (3:30 PM): Update gold master
    """
    
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "1KYtPvWRd0I92BORjCWSJROzXWTIsEnT"
    
    # Load universe from CSV (same file as other scanners)
    UNIVERSE = load_universe("data/FNOStock.csv")
    
    # Initialize scanner
    scanner = OISurgeScanner(API_KEY, ACCESS_TOKEN)
    
    logger.info("=" * 80)
    logger.info("OI SURGE SCANNER - Early Detection System")
    logger.info("=" * 80)
    logger.info(f"Tracking {len(UNIVERSE)} symbols")
    logger.info(f"Scan window: 9:30 AM - 11:00 AM (every 15 min)")
    logger.info(f"Alert threshold: {OISurgeConfig.MIN_OI_SURGE_PCT}%+ OI surge")
    logger.info("=" * 80)
    
    # Check current time
    now = datetime.now()
    current_time = (now.hour, now.minute)
    
    # Mode 1: Morning scans
    if OISurgeConfig.SCAN_START_TIME <= current_time <= OISurgeConfig.SCAN_END_TIME:
        logger.info("MODE: Morning OI Surge Detection")
        logger.info("")
        
        while True:
            # Scan for surges
            alerts = scanner.scan_for_oi_surges(UNIVERSE)
            
            # Save snapshot
            scanner.save_snapshot(UNIVERSE)
            
            # Display alerts
            if alerts:
                logger.info(f"🎯 {len(alerts)} ALERT(S) GENERATED!")
                for alert in alerts:
                    logger.info(f"  → {alert['symbol']}: {alert['signal_strength']}")
            
            # Check if still in scan window
            now = datetime.now()
            current_time = (now.hour, now.minute)
            
            if current_time > OISurgeConfig.SCAN_END_TIME:
                logger.info("Scan window ended. Stopping.")
                break
            
            # Wait for next scan
            logger.info(f"Next scan in {OISurgeConfig.SCAN_INTERVAL_MIN} minutes...")
            time.sleep(OISurgeConfig.SCAN_INTERVAL_MIN * 60)
    
    # Mode 2: EOD master update
    elif current_time >= OISurgeConfig.MASTER_UPDATE_TIME:
        logger.info("MODE: End-of-Day Master Update")
        logger.info("")
        
        scanner.update_oi_master(UNIVERSE)
        logger.info("Gold master updated successfully!")
    
    else:
        logger.info("Outside scan window")
        logger.info(f"Morning scans: {OISurgeConfig.SCAN_START_TIME} - {OISurgeConfig.SCAN_END_TIME}")
        logger.info(f"Master update: {OISurgeConfig.MASTER_UPDATE_TIME}")
        logger.info(f"Current time: {current_time}")


if __name__ == "__main__":
    main()
