"""
Straddle Scanner - Refactored Version
Identifies potential straddle buying opportunities based on multiple intraday signals
"""

import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from collections import defaultdict
import pandas as pd
from kiteconnect import KiteConnect

# ==================== CONFIGURATION ====================

class Config:
    """Centralized configuration"""
    # API Credentials
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "JNFX5feH5J9ksNWohYE0BLuDSyicnb1W"
    
    # File paths
    UNIVERSE_CSV = "data/FNOStock.csv"
    OUTPUT_DIR = "scan_outputs"
    
    # Trading thresholds - OPTIMIZED FOR REAL SIGNALS
    THRESH_STRADDLE_VWAP_PCT = 0.04      # 4% - Straddle above its VWAP (more lenient)
    THRESH_SPOT_MOVE_PCT = 0.003         # 0.3% - Spot move in 15 minutes (lower barrier)
    MAX_SPOT_MOVE_PCT = 0.025            # 2.5% - Reject if move too big (too late)
    THRESH_STRADDLE_MOVE_PCT = 0.06      # 6% - Straddle move in 30 minutes (more achievable)
    THRESH_CALL_OI_BUILD_PCT = 0.02      # 2% - Call OI increase (easier to meet)
    
    # Straddle premium limits
    MIN_STRADDLE_VWAP_PCT = 0.02         # 2% - Minimum premium inflation (lower floor)
    MAX_STRADDLE_VWAP_PCT = 0.15         # 15% - Maximum (avoid overpriced)
    
    # Multi-timeframe analysis (CRITICAL - prevents chasing completed moves)
    SPOT_MOVE_WINDOW_SHORT = 15          # Minutes - immediate momentum
    SPOT_MOVE_WINDOW_LONG = 90           # Minutes - broader context (now 90)
    MAX_LONG_MOVE_PCT = 0.02             # 2% - reject if 90m move too big
    
    # Signal quality and persistence (NEW - reduces noise)
    MIN_SCANS_FOR_SIGNAL = 2             # Signal must appear in 2+ scans
    SIGNAL_PERSISTENCE_WINDOW = 3        # Check last 3 scans
    STRADDLE_SCORE_THRESHOLD = 3         # 3 out of 4 conditions (was 4)
    DIRECTIONAL_CONFIDENCE_THRESHOLD = 65 # 65% confidence (was 70%)
    
    # Analysis parameters
    OHLC_INTERVAL = "5minute"
    HIST_RANGE_MINUTES = 120             # History to fetch for VWAP
    OI_COMPARISON_WINDOW = 30            # Minutes for OI change calculation
    SPOT_MOVE_WINDOW = 15                # Minutes for spot move calculation (legacy)
    
    # API Rate limiting
    API_SLEEP_SECONDS = 0.3
    BATCH_SIZE = 10                      # Symbols to process per batch
    
    # Scanning schedule (NEW - optimized for market activity)
    SCAN_INTERVAL_MINUTES = 15           # Scan every 15 minutes (reduces noise)
    HIGH_ACTIVITY_HOURS = [(9, 15, 10, 30), (14, 30, 15, 30)]  # (start_h, start_m, end_h, end_m)
    
    # Market hours (IST)
    MARKET_OPEN_HOUR = 9
    MARKET_OPEN_MINUTE = 15
    MARKET_CLOSE_HOUR = 15
    MARKET_CLOSE_MINUTE = 30
    
    # Logging
    LOG_LEVEL = logging.INFO
    
    # Realistic expectations (for user reference)
    EXPECTED_STRADDLE_SIGNALS_PER_DAY = 3      # Realistic count
    EXPECTED_DIRECTIONAL_SIGNALS_PER_DAY = 15  # More common


# ==================== LOGGING SETUP ====================

def setup_logging():
    """Configure logging"""
    logging.basicConfig(
        level=Config.LOG_LEVEL,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(f'scanner_{datetime.now().strftime("%Y%m%d")}.log'),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

logger = setup_logging()


# ==================== UTILITY FUNCTIONS ====================

def validate_config():
    """Validate configuration before starting"""
    errors = []
    
    if Config.API_KEY == "your_api_key":
        errors.append("API_KEY not set")
    if Config.ACCESS_TOKEN == "your_access_token":
        errors.append("ACCESS_TOKEN not set")
    if not (0 < Config.THRESH_STRADDLE_VWAP_PCT < 1):
        errors.append("Invalid THRESH_STRADDLE_VWAP_PCT")
    
    if errors:
        raise ValueError(f"Configuration errors: {', '.join(errors)}")


def is_market_open() -> bool:
    """Check if market is currently open"""
    now = datetime.now()
    
    # Weekend check
    if now.weekday() > 4:
        return False
    
    # Market hours check
    market_start = now.replace(
        hour=Config.MARKET_OPEN_HOUR, 
        minute=Config.MARKET_OPEN_MINUTE, 
        second=0, 
        microsecond=0
    )
    market_end = now.replace(
        hour=Config.MARKET_CLOSE_HOUR, 
        minute=Config.MARKET_CLOSE_MINUTE, 
        second=0, 
        microsecond=0
    )
    
    return market_start <= now <= market_end


def load_universe(path: str) -> List[str]:
    """Load stock symbols from CSV"""
    try:
        df = pd.read_csv(path)
        if 'Symbol' not in df.columns:
            raise ValueError("CSV must have 'Symbol' column")
        symbols = df['Symbol'].astype(str).str.strip().unique().tolist()
        logger.info(f"Loaded {len(symbols)} Symbols from {path}")
        return symbols
    except Exception as e:
        logger.error(f"Failed to load universe: {e}")
        raise


def compute_vwap(df_ohlc: pd.DataFrame) -> Optional[float]:
    """Calculate Volume Weighted Average Price"""
    if df_ohlc.empty or 'volume' not in df_ohlc.columns:
        return None
    
    # Typical price
    typical_price = (df_ohlc['high'] + df_ohlc['low'] + df_ohlc['close']) / 3.0
    
    # VWAP
    total_volume = df_ohlc['volume'].sum()
    if total_volume == 0:
        return None
    
    vwap = (typical_price * df_ohlc['volume']).sum() / total_volume
    return float(vwap)




# ==================== MAIN SCANNER CLASS ====================

class StraddleScanner:
    """Main scanner class with optimized API usage and state management"""
    
    def __init__(self, api_key: str, access_token: str):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Caches
        self.instrument_cache: Dict = {}
        self.token_to_symbol: Dict = {}
        self.equity_tokens: Dict = {}  # Separate cache for equity tokens
        
        # Historical tracking
        self.oi_snapshots: Dict[str, List[Tuple]] = defaultdict(list)
        self.straddle_snapshots: Dict[str, List[Tuple]] = defaultdict(list)
        
        # Signal persistence tracking (NEW - reduces noise)
        self.signal_history: Dict[str, List[Tuple]] = defaultdict(list)  # (timestamp, signal, score, direction, confidence)
        
        # Initialize
        self._load_instruments()
        logger.info("StraddleScanner initialized successfully")
        logger.info(f"Signal persistence: {Config.MIN_SCANS_FOR_SIGNAL} scans required, window={Config.SIGNAL_PERSISTENCE_WINDOW}")
        logger.info(f"Straddle threshold: {Config.STRADDLE_SCORE_THRESHOLD}/4, Directional threshold: {Config.DIRECTIONAL_CONFIDENCE_THRESHOLD}%")
    
    def _load_instruments(self):
        """Load NSE (equities) and NFO (options) instruments and build cache"""
        logger.info("Loading instrument master...")
        try:
            # Load both NSE and NFO
            nse_instruments = self.kite.instruments("NSE")
            nfo_instruments = self.kite.instruments("NFO")
            
            # Process NSE instruments (equities)
            for inst in nse_instruments:
                symbol = inst.get('tradingsymbol')
                token = inst.get('instrument_token')
                
                # Store equity tokens separately for historical data calls
                if inst.get('instrument_type') == 'EQ':
                    self.equity_tokens[symbol] = token
                
                self.instrument_cache[symbol] = {
                    'token': token,
                    'exchange': inst.get('exchange'),
                    'instrument_type': inst.get('instrument_type'),
                    'strike': inst.get('strike'),
                    'expiry': inst.get('expiry'),
                    'lot_size': inst.get('lot_size', 0),
                    'name': inst.get('name', '')
                }
                
                self.token_to_symbol[token] = symbol
            
            # Process NFO instruments (options)
            for inst in nfo_instruments:
                symbol = inst.get('tradingsymbol')
                token = inst.get('instrument_token')
                
                self.instrument_cache[symbol] = {
                    'token': token,
                    'exchange': inst.get('exchange'),
                    'instrument_type': inst.get('instrument_type'),
                    'strike': inst.get('strike'),
                    'expiry': inst.get('expiry'),
                    'lot_size': inst.get('lot_size', 0),
                    'name': inst.get('name', '')  # Underlying stock name
                }
                
                self.token_to_symbol[token] = symbol
            
            logger.info(f"Loaded {len(self.instrument_cache)} instruments")
            logger.info(f"Equity tokens cached: {len(self.equity_tokens)}")
            
        except Exception as e:
            logger.error(f"Failed to load instruments: {e}")
            raise
    
    def _find_atm_options(self, underlying_symbol: str, spot_price: float) -> Tuple[Optional[str], Optional[str]]:
        """
        Find ATM CE and PE option symbols for given underlying
        Returns: (ce_symbol, pe_symbol)
        """
        # Filter options for this underlying from NFO
        options = []
        for symbol, data in self.instrument_cache.items():
            # Match NFO options by name field (underlying) or symbol prefix
            if (data['exchange'] == 'NFO' and 
                data['instrument_type'] in ['CE', 'PE'] and
                data['strike'] is not None):
                
                underlying_name = data.get('name', '')
                
                # Match by name or symbol prefix
                if (underlying_name == underlying_symbol or 
                    symbol.startswith(underlying_symbol)):
                    
                    options.append({
                        'symbol': symbol,
                        'strike': data['strike'],
                        'expiry': data['expiry'],
                        'type': data['instrument_type']
                    })
        
        if not options:
            logger.warning(f"No options found for {underlying_symbol}")
            return None, None
        
        # Convert to DataFrame
        options_df = pd.DataFrame(options)
        options_df['expiry'] = pd.to_datetime(options_df['expiry'])
        
        # Find nearest expiry (weekly options will be closest)
        nearest_expiry = options_df['expiry'].min()
        
        # Filter to nearest expiry
        nearest_options = options_df[options_df['expiry'] == nearest_expiry]
        
        # Find ATM strike (closest to spot)
        strikes = nearest_options['strike'].unique()
        atm_strike = min(strikes, key=lambda x: abs(x - spot_price))
        
        # Get CE and PE at ATM strike
        atm_options = nearest_options[nearest_options['strike'] == atm_strike]
        
        ce_symbol = atm_options[atm_options['type'] == 'CE']['symbol'].values
        pe_symbol = atm_options[atm_options['type'] == 'PE']['symbol'].values
        
        ce = ce_symbol[0] if len(ce_symbol) > 0 else None
        pe = pe_symbol[0] if len(pe_symbol) > 0 else None
        
        if ce and pe:
            logger.debug(f"{underlying_symbol}: Spot={spot_price}, ATM={atm_strike}, CE={ce}, PE={pe}")
        
        return ce, pe
    
    def _fetch_historical_data(self, instrument_key, from_dt: datetime, 
                               to_dt: datetime, interval: str) -> pd.DataFrame:
        """
        Fetch historical OHLC data
        instrument_key: instrument_token (int) for historical data API
        """
        try:
            data = self.kite.historical_data(instrument_key, from_dt, to_dt, interval)
            df = pd.DataFrame(data)
            
            if not df.empty:
                # Standardize datetime column
                if 'date' in df.columns:
                    df['datetime'] = pd.to_datetime(df['date'])
                else:
                    df['datetime'] = pd.to_datetime(df['datetime'])
            
            return df
            
        except Exception as e:
            logger.error(f"Historical data fetch failed for {instrument_key}: {e}")
            return pd.DataFrame()
    
    def _get_straddle_vwap(self, ce_symbol: str, pe_symbol: str, 
                           from_dt: datetime, to_dt: datetime) -> Optional[float]:
        """Calculate VWAP of straddle (CE + PE) premium"""
        try:
            ce_token = self.instrument_cache[ce_symbol]['token']
            pe_token = self.instrument_cache[pe_symbol]['token']
            
            df_ce = self._fetch_historical_data(ce_token, from_dt, to_dt, Config.OHLC_INTERVAL)
            df_pe = self._fetch_historical_data(pe_token, from_dt, to_dt, Config.OHLC_INTERVAL)
            
            if df_ce.empty or df_pe.empty:
                return None
            
            # Align dataframes on datetime
            df_ce = df_ce.set_index('datetime')
            df_pe = df_pe.set_index('datetime')
            
            # Calculate straddle OHLC
            df_straddle = pd.DataFrame()
            df_straddle['high'] = df_ce['high'] + df_pe['high']
            df_straddle['low'] = df_ce['low'] + df_pe['low']
            df_straddle['close'] = df_ce['close'] + df_pe['close']
            df_straddle['volume'] = (df_ce['volume'] + df_pe['volume']) / 2
            
            return compute_vwap(df_straddle.reset_index())
            
        except Exception as e:
            logger.error(f"Straddle VWAP calculation failed: {e}")
            return None
    
    def _calculate_oi_change(self, symbol: str, ce_oi: float, pe_oi: float) -> Tuple[float, float]:
        """
        Calculate OI change over configured window
        Returns: (ce_oi_change_pct, pe_oi_change_pct)
        """
        now = datetime.now()
        
        # Add current snapshot
        self.oi_snapshots[symbol].append((now, ce_oi, pe_oi))
        
        # Clean old snapshots (keep last 2 hours)
        cutoff = now - timedelta(hours=2)
        self.oi_snapshots[symbol] = [
            snap for snap in self.oi_snapshots[symbol] if snap[0] > cutoff
        ]
        
        # Find baseline snapshot
        target_time = now - timedelta(minutes=Config.OI_COMPARISON_WINDOW)
        baseline = None
        
        for timestamp, ce, pe in self.oi_snapshots[symbol]:
            if timestamp <= target_time:
                baseline = (ce, pe)
                break
        
        if not baseline:
            # Not enough history yet
            return 0.0, 0.0
        
        ce_change_pct = (ce_oi - baseline[0]) / max(1, baseline[0])
        pe_change_pct = (pe_oi - baseline[1]) / max(1, baseline[1])
        
        return ce_change_pct, pe_change_pct
    
    def _calculate_straddle_change(self, symbol: str, current_straddle: float) -> float:
        """
        Calculate straddle premium change over configured window
        Returns: straddle_change_pct
        """
        now = datetime.now()
        
        # Add current snapshot
        self.straddle_snapshots[symbol].append((now, current_straddle))
        
        # Clean old snapshots
        cutoff = now - timedelta(hours=2)
        self.straddle_snapshots[symbol] = [
            snap for snap in self.straddle_snapshots[symbol] if snap[0] > cutoff
        ]
        
        # Find baseline
        target_time = now - timedelta(minutes=30)  # 30-min window for straddle
        baseline = None
        
        for timestamp, straddle in self.straddle_snapshots[symbol]:
            if timestamp <= target_time:
                baseline = straddle
                break
        
        if not baseline:
            return 0.0
        
        change_pct = (current_straddle - baseline) / baseline
        return change_pct
    
    def _calculate_spot_move(self, df_spot: pd.DataFrame) -> float:
        """
        Calculate spot percentage move over configured window
        """
        if df_spot.empty:
            return 0.0
        
        # Calculate number of bars for the window
        interval_minutes = {'1minute': 1, '5minute': 5, '15minute': 15, '30minute': 30}
        minutes_per_bar = interval_minutes.get(Config.OHLC_INTERVAL, 5)
        bars_needed = max(1, int(Config.SPOT_MOVE_WINDOW / minutes_per_bar))
        
        closes = df_spot['close'].values
        
        if len(closes) <= bars_needed:
            return 0.0
        
        prev_close = closes[-(bars_needed + 1)]
        current_close = closes[-1]
        
        pct_change = (current_close - prev_close) / prev_close
        return pct_change
    
    def _calculate_spot_move_multi_tf(self, df_spot: pd.DataFrame) -> Tuple[float, float]:
        """
        Calculate spot moves over multiple timeframes (15m and 60m)
        Returns: (move_15m, move_60m)
        
        This helps identify:
        - Early trends: Both positive and accelerating
        - Post-spike consolidation: 60m big, 15m small (AVOID)
        """
        if df_spot.empty:
            return 0.0, 0.0
        
        interval_minutes = {'1minute': 1, '5minute': 5, '15minute': 15, '30minute': 30}
        minutes_per_bar = interval_minutes.get(Config.OHLC_INTERVAL, 5)
        
        closes = df_spot['close'].values
        
        # 15-minute move
        bars_15m = max(1, int(Config.SPOT_MOVE_WINDOW_SHORT / minutes_per_bar))
        if len(closes) > bars_15m:
            move_15m = (closes[-1] - closes[-(bars_15m + 1)]) / closes[-(bars_15m + 1)]
        else:
            move_15m = 0.0
        
        # 60-minute move
        bars_60m = max(1, int(Config.SPOT_MOVE_WINDOW_LONG / minutes_per_bar))
        if len(closes) > bars_60m:
            move_60m = (closes[-1] - closes[-(bars_60m + 1)]) / closes[-(bars_60m + 1)]
        else:
            move_60m = 0.0
        
        return move_15m, move_60m
    
    
    
    
    def _evaluate_persistent_signal(self, symbol: str, current_straddle_signal: bool, 
                                     current_score: int, current_direction: str,
                                     current_directional_conf: int) -> Tuple[bool, int, bool, int]:
        """
        Check if signals persist across multiple scans to reduce noise
        Returns: (persistent_straddle_signal, avg_straddle_score, 
                 persistent_directional_signal, avg_directional_conf)
        
        Logic:
        - Tracks last N scans (SIGNAL_PERSISTENCE_WINDOW)
        - Signal confirmed if appears in MIN_SCANS_FOR_SIGNAL out of last N
        - Reduces whipsawing and false positives
        """
        now = datetime.now()
        
        # Store current signal data
        self.signal_history[symbol].append((
            now, 
            current_straddle_signal, 
            current_score,
            current_direction,
            current_directional_conf
        ))
        
        # Keep only last N scans
        cutoff = now - timedelta(minutes=Config.SIGNAL_PERSISTENCE_WINDOW * Config.SCAN_INTERVAL_MINUTES)
        self.signal_history[symbol] = [
            entry for entry in self.signal_history[symbol] if entry[0] > cutoff
        ]
        
        # Limit to window size
        self.signal_history[symbol] = self.signal_history[symbol][-Config.SIGNAL_PERSISTENCE_WINDOW:]
        
        # Need minimum scans for confirmation
        if len(self.signal_history[symbol]) < Config.MIN_SCANS_FOR_SIGNAL:
            return False, current_score, False, current_directional_conf
        
        # Extract recent data
        recent_straddle_signals = [sig for _, sig, _, _, _ in self.signal_history[symbol]]
        recent_scores = [score for _, _, score, _, _ in self.signal_history[symbol]]
        recent_directions = [direction for _, _, _, direction, _ in self.signal_history[symbol]]
        recent_directional_confs = [conf for _, _, _, _, conf in self.signal_history[symbol]]
        
        # Straddle persistence: signal in at least MIN_SCANS_FOR_SIGNAL
        straddle_signal_count = sum(recent_straddle_signals)
        persistent_straddle = straddle_signal_count >= Config.MIN_SCANS_FOR_SIGNAL
        avg_score = int(sum(recent_scores) / len(recent_scores))
        
        # Directional persistence: same direction with high confidence in MIN_SCANS_FOR_SIGNAL
        directional_qualified = [
            (d, c) for d, c in zip(recent_directions, recent_directional_confs)
            if d in ['BULLISH', 'BEARISH'] and c >= Config.DIRECTIONAL_CONFIDENCE_THRESHOLD
        ]
        
        persistent_directional = False
        avg_directional_conf = current_directional_conf
        
        if len(directional_qualified) >= Config.MIN_SCANS_FOR_SIGNAL:
            # Check if consistent direction
            directions = [d for d, _ in directional_qualified]
            if directions.count(directions[0]) >= Config.MIN_SCANS_FOR_SIGNAL:
                persistent_directional = True
                avg_directional_conf = int(sum(c for _, c in directional_qualified) / len(directional_qualified))
        
        return persistent_straddle, avg_score, persistent_directional, avg_directional_conf
    
    def _get_trade_recommendation(self, straddle_signal: bool, straddle_score: int, 
                                   direction: str, directional_confidence: int) -> str:
        """
        Combine straddle and directional analysis to recommend best trade
        Uses RELAXED thresholds for more realistic signal generation
        
        Returns: Trade recommendation string
        """
        
        # Strong directional signal with relaxed confidence threshold
        if directional_confidence >= Config.DIRECTIONAL_CONFIDENCE_THRESHOLD:
            if direction == "BULLISH":
                return "BUY CALL (Directional)"
            elif direction == "BEARISH":
                return "BUY PUT (Directional)"
        
        # Straddle signal with relaxed scoring (3/4 instead of 4/4)
        if straddle_signal or straddle_score >= Config.STRADDLE_SCORE_THRESHOLD:
            if direction == "NEUTRAL":
                return "BUY STRADDLE (Non-directional)"
            elif direction == "BULLISH" and directional_confidence >= 50:
                return "CALL HEAVY (Straddle + Extra Call)"
            elif direction == "BEARISH" and directional_confidence >= 50:
                return "PUT HEAVY (Straddle + Extra Put)"
            else:
                return "BUY STRADDLE"
        
        # Medium signals (more lenient watch criteria)
        if straddle_score >= 2:  # Was 3
            if direction in ["BULLISH", "BEARISH"] and directional_confidence >= 45:
                return f"WATCH ({direction} bias, pending confirmation)"
            else:
                return "WATCH (Straddle developing)"
        
        if directional_confidence >= 45:  # Was 50
            if direction == "BULLISH":
                return "WATCH (Bullish bias developing)"
            elif direction == "BEARISH":
                return "WATCH (Bearish bias developing)"
        
        # Weak or conflicting signals
        return "NO TRADE"
    
    def _evaluate_directional_signal(self, metrics: Dict) -> Tuple[str, int, float]:
        """
        Evaluate directional trade opportunity (CALL/PUT buying)
        Returns: (direction, confidence, expected_move_pct)
        
        Direction: "BULLISH", "BEARISH", "NEUTRAL", "AVOID"
        Confidence: 0-100 score
        Expected Move: % move expected based on premium/momentum
        """
        
        spot_15m = metrics.get('spot_move_pct', 0)
        spot_60m = metrics.get('spot_move_60m_pct', 0)
        ce_oi_change = metrics.get('ce_oi_change_pct', 0)
        pe_oi_change = metrics.get('pe_oi_change_pct', 0)
        straddle_vs_vwap = metrics.get('straddle_vs_vwap_pct', 0)
        
        # Check if moves are too large (already done)
        if abs(spot_15m) > Config.MAX_SPOT_MOVE_PCT or abs(spot_60m) > 0.035:
            return "AVOID", 0, 0.0
        
        # Calculate OI bias (positive = bullish, negative = bearish)
        oi_bias = ce_oi_change - pe_oi_change
        
        # Check momentum consistency and acceleration
        momentum_accelerating_up = (
            spot_60m > 0 and spot_15m > 0 and 
            spot_15m >= spot_60m * 0.5  # 15m is at least 50% of 60m
        )
        momentum_accelerating_down = (
            spot_60m < 0 and spot_15m < 0 and 
            abs(spot_15m) >= abs(spot_60m) * 0.5
        )
        
        # BULLISH SCORE (0-100)
        bullish_score = 0
        
        if spot_15m > 0.002:  # 0.2%+ recent upward momentum (was 0.3%)
            bullish_score += 20
        if spot_60m > 0.004:  # 0.4%+ sustained uptrend (was 0.5%)
            bullish_score += 20
        if ce_oi_change > 0.02:  # 2%+ call OI building (was 3%)
            bullish_score += 25
        if pe_oi_change < -0.005:  # Put OI declining (was -1%)
            bullish_score += 15
        if oi_bias > 0.03:  # Strong call bias over puts (was 0.04)
            bullish_score += 10
        if momentum_accelerating_up:  # Acceleration pattern
            bullish_score += 10
        
        # BEARISH SCORE (0-100)
        bearish_score = 0
        
        if spot_15m < -0.002:  # 0.2%+ recent downward momentum (was 0.3%)
            bearish_score += 20
        if spot_60m < -0.004:  # 0.4%+ sustained downtrend (was 0.5%)
            bearish_score += 20
        if pe_oi_change > 0.02:  # 2%+ put OI building (was 3%)
            bearish_score += 25
        if ce_oi_change < -0.005:  # Call OI declining (was -1%)
            bearish_score += 15
        if oi_bias < -0.03:  # Strong put bias over calls (was -0.04)
            bearish_score += 10
        if momentum_accelerating_down:  # Acceleration pattern
            bearish_score += 10
        
        # Determine direction and confidence (RELAXED thresholds)
        direction = "NEUTRAL"
        confidence = 0
        
        if bullish_score > bearish_score and bullish_score >= 45:  # Was 50
            direction = "BULLISH"
            confidence = min(bullish_score, 100)
        elif bearish_score > bullish_score and bearish_score >= 45:  # Was 50
            direction = "BEARISH"
            confidence = min(bearish_score, 100)
        elif straddle_vs_vwap > 0.04 and abs(oi_bias) < 0.025:  # Was 0.05 and 0.03
            # High premium but no clear OI bias = neutral/straddle territory
            direction = "NEUTRAL"
            confidence = 50
        else:
            direction = "AVOID"
            confidence = 0
        
        # Estimate expected move based on premium expansion and momentum
        # Premium expansion often precedes actual price move
        expected_move = 0.0
        if straddle_vs_vwap > 0:
            # Higher premium = bigger expected move
            # Typically premium expansion = 1.5-2x the actual move
            expected_move = straddle_vs_vwap * 1.5
            
            # Adjust based on momentum strength
            if abs(spot_60m) > 0.01:  # Strong momentum already
                expected_move = max(expected_move, abs(spot_60m) * 1.3)
        
        return direction, confidence, expected_move
    
    def _evaluate_signal(self, metrics: Dict) -> Tuple[bool, int]:
        """
        Evaluate if metrics meet signal criteria
        Returns: (signal_triggered, score)
        
        Strategy: Find premium expansion BEFORE big move (not after)
        - Premium should be elevated (IV spike)
        - Spot move should be moderate (not exhausted)
        - Avoid chasing completed moves
        - Avoid post-spike consolidation patterns
        """
        
        spot_move_15m = abs(metrics.get('spot_move_pct', 0))
        spot_move_60m = abs(metrics.get('spot_move_60m_pct', 0))
        
        # CRITICAL CHECK 1: Detect post-spike consolidation
        # Pattern: Big 60m move but small 15m move = spike already happened, now consolidating
        if spot_move_60m > Config.MAX_LONG_MOVE_PCT and spot_move_15m < Config.THRESH_SPOT_MOVE_PCT:
            logger.warning(
                f"Post-spike consolidation detected: "
                f"60m move {spot_move_60m*100:.2f}% but 15m only {spot_move_15m*100:.2f}% "
                f"- spike already done, AVOID"
            )
            return False, 0
        
        # CRITICAL CHECK 2: Reject if 15m move too big (chasing)
        if spot_move_15m > Config.MAX_SPOT_MOVE_PCT:
            logger.warning(
                f"15m move {spot_move_15m*100:.2f}% exceeds max {Config.MAX_SPOT_MOVE_PCT*100}% "
                f"- too late to enter"
            )
            return False, 0
        
        # CRITICAL CHECK 3: Reject if 60m move way too big (exhausted)
        if spot_move_60m > 0.035:  # 3.5% in 60 minutes = definitely exhausted
            logger.warning(
                f"60m move {spot_move_60m*100:.2f}% too large - trend exhausted"
            )
            return False, 0
        
        # Check straddle premium is in optimal range
        straddle_vwap_pct = metrics.get('straddle_vs_vwap_pct', 0)
        if straddle_vwap_pct > Config.MAX_STRADDLE_VWAP_PCT:
            logger.warning(
                f"Straddle premium {straddle_vwap_pct*100:.2f}% too high - overpriced"
            )
            return False, 0
        
        # Evaluate individual conditions
        conditions = {
            'straddle_above_vwap': (
                Config.MIN_STRADDLE_VWAP_PCT <= straddle_vwap_pct <= Config.MAX_STRADDLE_VWAP_PCT
            ),
            'spot_momentum': (
                spot_move_15m >= Config.THRESH_SPOT_MOVE_PCT
            ),
            'call_oi_building': (
                metrics.get('ce_oi_change_pct', 0) >= Config.THRESH_CALL_OI_BUILD_PCT
            ),
            'straddle_expansion': (
                metrics.get('straddle_change_pct', 0) >= Config.THRESH_STRADDLE_MOVE_PCT
            )
        }
        
        score = sum(conditions.values())
        
        # RELAXED: Signal at 3/4 instead of 4/4
        signal = score >= Config.STRADDLE_SCORE_THRESHOLD  # 3 instead of all(conditions)
        
        # Additional validation: For high scores, check momentum consistency
        if score >= 2:
            # Good pattern: 15m and 90m both positive and aligned
            # Bad pattern: 90m big, 15m small (consolidation after spike)
            if spot_move_60m > 0 and spot_move_15m > 0:
                momentum_ratio = spot_move_15m / max(spot_move_60m, 0.001)
                if momentum_ratio < 0.3:  # 15m move is <30% of 90m move
                    logger.info(
                        f"Momentum decelerating: 15m/90m ratio {momentum_ratio:.2f} "
                        f"- reducing confidence"
                    )
        
        return signal, score
    
    def scan_symbol(self, symbol: str) -> Optional[Dict]:
        """
        Scan single symbol and return metrics
        """
        try:
            logger.info(f"Scanning {symbol}...")
            
            # Time windows
            now = datetime.now()
            from_dt = now - timedelta(minutes=Config.HIST_RANGE_MINUTES)
            to_dt = now
            
            # Check if symbol exists in equity cache
            if symbol not in self.equity_tokens:
                logger.warning(f"Symbol {symbol} not found in equity instruments")
                return None
            
            # Get instrument token for historical data (must use token, not string)
            spot_token = self.equity_tokens[symbol]
            spot_key = f"NSE:{symbol}"  # For quote/ltp calls (uses string format)
            
            # Fetch spot historical using TOKEN
            df_spot = self._fetch_historical_data(spot_token, from_dt, to_dt, Config.OHLC_INTERVAL)
            
            if df_spot.empty:
                logger.warning(f"No historical data for {symbol}")
                return None
            
            # Get current spot price for ATM selection (uses string format)
            spot_quote = self.kite.ltp(spot_key)
            spot_ltp = spot_quote[spot_key]['last_price']
            
            # Find ATM options
            ce_symbol, pe_symbol = self._find_atm_options(symbol, spot_ltp)
            
            if not ce_symbol or not pe_symbol:
                logger.warning(f"Could not find ATM options for {symbol}")
                return None
            
            # Batch quote for CE and PE (uses string format with NFO exchange)
            ce_key = f"NFO:{ce_symbol}"
            pe_key = f"NFO:{pe_symbol}"
            
            quotes = self.kite.quote([ce_key, pe_key])
            
            ce_ltp = quotes[ce_key]['last_price']
            pe_ltp = quotes[pe_key]['last_price']
            ce_oi = quotes[ce_key].get('oi', 0)
            pe_oi = quotes[pe_key].get('oi', 0)
            
            straddle_ltp = ce_ltp + pe_ltp
            
            # Calculate metrics
            spot_vwap = compute_vwap(df_spot)
            straddle_vwap = self._get_straddle_vwap(ce_symbol, pe_symbol, from_dt, to_dt)
            
            # Straddle vs its VWAP
            straddle_vs_vwap_pct = None
            if straddle_vwap:
                straddle_vs_vwap_pct = (straddle_ltp - straddle_vwap) / straddle_vwap
            
            # Multi-timeframe spot momentum (CRITICAL for avoiding post-spike entries)
            spot_move_15m, spot_move_60m = self._calculate_spot_move_multi_tf(df_spot)
            
            # Legacy single timeframe (for backward compatibility)
            spot_move_pct = spot_move_15m
            
            # OI changes
            ce_oi_change_pct, pe_oi_change_pct = self._calculate_oi_change(
                symbol, ce_oi, pe_oi
            )
            
            # Straddle expansion
            straddle_change_pct = self._calculate_straddle_change(symbol, straddle_ltp)
            
            # Build metrics dict
            metrics = {
                'symbol': symbol,
                'timestamp': now.isoformat(),
                'spot_ltp': round(spot_ltp, 2),
                'spot_vwap': round(spot_vwap, 2) if spot_vwap else None,
                'spot_move_pct': round(spot_move_pct * 100, 2),  # 15m move
                'spot_move_60m_pct': round(spot_move_60m * 100, 2),  # 60m move (NEW)
                'ce_symbol': ce_symbol,
                'pe_symbol': pe_symbol,
                'ce_ltp': round(ce_ltp, 2),
                'pe_ltp': round(pe_ltp, 2),
                'straddle_ltp': round(straddle_ltp, 2),
                'straddle_vwap': round(straddle_vwap, 2) if straddle_vwap else None,
                'straddle_vs_vwap_pct': round(straddle_vs_vwap_pct * 100, 2) if straddle_vs_vwap_pct else None,
                'straddle_change_pct': round(straddle_change_pct * 100, 2),
                'ce_oi': int(ce_oi),
                'pe_oi': int(pe_oi),
                'ce_oi_change_pct': round(ce_oi_change_pct * 100, 2),
                'pe_oi_change_pct': round(pe_oi_change_pct * 100, 2),
            }
            
            # Evaluate signals - BOTH straddle and directional
            straddle_signal, straddle_score = self._evaluate_signal({
                'straddle_vs_vwap_pct': straddle_vs_vwap_pct or 0,
                'spot_move_pct': spot_move_15m,
                'spot_move_60m_pct': spot_move_60m,
                'ce_oi_change_pct': ce_oi_change_pct,
                'straddle_change_pct': straddle_change_pct
            })
            
            # Directional signal evaluation
            direction, directional_confidence, expected_move = self._evaluate_directional_signal({
                'spot_move_pct': spot_move_15m,
                'spot_move_60m_pct': spot_move_60m,
                'ce_oi_change_pct': ce_oi_change_pct,
                'pe_oi_change_pct': pe_oi_change_pct,
                'straddle_vs_vwap_pct': straddle_vs_vwap_pct or 0,
                'straddle_change_pct': straddle_change_pct
            })
            
            # Check signal persistence (NEW - reduces noise/whipsawing)
            persistent_straddle, avg_straddle_score, persistent_directional, avg_directional_conf = \
                self._evaluate_persistent_signal(
                    symbol, straddle_signal, straddle_score, direction, directional_confidence
                )
            
            # Use persistent signals for final recommendation
            final_straddle_signal = persistent_straddle if len(self.signal_history[symbol]) >= Config.MIN_SCANS_FOR_SIGNAL else straddle_signal
            final_directional_conf = avg_directional_conf if len(self.signal_history[symbol]) >= Config.MIN_SCANS_FOR_SIGNAL else directional_confidence
            
            # Determine recommended trade
            recommended_trade = self._get_trade_recommendation(
                final_straddle_signal, avg_straddle_score if persistent_straddle else straddle_score, 
                direction, final_directional_conf
            )
            
            # Add to metrics
            metrics['score'] = straddle_score
            metrics['signal'] = final_straddle_signal
            metrics['signal_persistent'] = persistent_straddle  # NEW
            metrics['direction'] = direction
            metrics['directional_confidence'] = directional_confidence
            metrics['directional_persistent'] = persistent_directional  # NEW
            metrics['expected_move_pct'] = round(expected_move * 100, 2)
            metrics['recommended_trade'] = recommended_trade
            metrics['scan_count'] = len(self.signal_history[symbol])  # NEW - track how many scans
            
            # Log detailed results for high scorers OR high directional confidence OR persistent signals
            if straddle_score >= 2 or directional_confidence >= 55 or persistent_straddle or persistent_directional:
                logger.info(f"{symbol}: ⭐ OPPORTUNITY DETECTED")
                logger.info(f"  STRADDLE: Score={straddle_score}/4, Signal={final_straddle_signal}, Persistent={persistent_straddle}")
                logger.info(f"  DIRECTIONAL: {direction} (Confidence: {directional_confidence}%), Persistent={persistent_directional}")
                logger.info(f"  → RECOMMENDED: {recommended_trade}")
                logger.info(f"  Scan History: {len(self.signal_history[symbol])} scans tracked")
                logger.info(f"  Spot Move 15m: {spot_move_15m*100:.2f}% | 90m: {spot_move_60m*100:.2f}%")
                logger.info(f"  CE OI: {ce_oi_change_pct*100:.2f}% | PE OI: {pe_oi_change_pct*100:.2f}%")
                logger.info(f"  Expected Move: {expected_move*100:.2f}%")
            else:
                logger.info(f"{symbol}: Score={straddle_score}/4, Direction={direction}({directional_confidence}%), Trade={recommended_trade}")
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error scanning {symbol}: {e}", exc_info=True)
            return None
    
    def scan_universe(self, symbols: List[str]) -> pd.DataFrame:
        """
        Scan all symbols in universe
        Returns DataFrame with all results
        """
        results = []
        
        for i, symbol in enumerate(symbols, 1):
            logger.info(f"Processing {i}/{len(symbols)}: {symbol}")
            
            metrics = self.scan_symbol(symbol)
            if metrics:
                results.append(metrics)
            
            # Rate limiting
            time.sleep(Config.API_SLEEP_SECONDS)
        
        df = pd.DataFrame(results)
        return df
    
    def get_signals(self, df_results: pd.DataFrame) -> pd.DataFrame:
        """Filter results to only signals"""
        if df_results.empty:
            return df_results
        return df_results[df_results['signal'] == True].copy()



# ==================== MAIN EXECUTION ====================

def main():
    """Main execution function"""
    
    # Validate configuration
    try:
        validate_config()
    except ValueError as e:
        logger.error(f"Configuration invalid: {e}")
        return
    
    # Check market hours
    if not is_market_open():
        logger.warning("Market is currently closed. Results may not be meaningful.")
        proceed = input("Continue anyway? (y/n): ")
        if proceed.lower() != 'y':
            return
    
    # Load universe
    try:
        universe = load_universe(Config.UNIVERSE_CSV)
    except Exception as e:
        logger.error(f"Failed to load universe: {e}")
        return
    
    # Initialize scanner
    logger.info("Initializing scanner...")
    scanner = StraddleScanner(Config.API_KEY, Config.ACCESS_TOKEN)
    
    # Run scan
    logger.info(f"Starting scan of {len(universe)} symbols...")
    start_time = datetime.now()
    
    results_df = scanner.scan_universe(universe)
    
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_file = f"scan_results_{timestamp}.csv"
    results_df.to_csv(output_file, index=False)
    logger.info(f"Results saved to {output_file}")
    
    # Display signals - BOTH straddle and directional
    signals_df = scanner.get_signals(results_df)
    
    # Get directional opportunities (relaxed confidence threshold)
    if not results_df.empty:
        directional_df = results_df[
            (results_df['directional_confidence'] >= Config.DIRECTIONAL_CONFIDENCE_THRESHOLD) & 
            (results_df['direction'].isin(['BULLISH', 'BEARISH']))
        ].copy()
        
        # Also get persistent directional signals even if slightly below threshold
        persistent_directional_df = results_df[
            (results_df['directional_persistent'] == True)
        ].copy()
        
        # Combine
        directional_df = pd.concat([directional_df, persistent_directional_df]).drop_duplicates(subset=['symbol'])
    else:
        directional_df = pd.DataFrame()
    
    print("\n" + "="*80)
    print(f"SCAN COMPLETE - Duration: {duration:.1f} seconds")
    print(f"Symbols scanned: {len(results_df)}")
    print(f"Straddle signals: {len(signals_df)} (3/4 scoring)")
    print(f"Directional signals: {len(directional_df)} (65%+ confidence)")
    print(f"Scanner Mode: Optimized for realistic signal frequency")
    print("="*80)
    
    # Display STRADDLE signals
    if not signals_df.empty:
        print("\n🎯 STRADDLE SIGNALS (3/4 conditions met):")
        print("-" * 80)
        
        straddle_cols = [
            'symbol', 'score', 'signal_persistent', 'recommended_trade', 
            'straddle_ltp', 'straddle_vs_vwap_pct', 'expected_move_pct', 'scan_count'
        ]
        
        print(signals_df[straddle_cols].to_string(index=False))
        print("-" * 80)
        
        # Save signals separately
        signals_file = f"straddle_signals_{timestamp}.csv"
        signals_df.to_csv(signals_file, index=False)
        logger.info(f"Straddle signals saved to {signals_file}")
    
    # Display DIRECTIONAL signals
    if not directional_df.empty:
        print("\n📈 DIRECTIONAL SIGNALS (65%+ confidence OR persistent):")
        print("-" * 80)
        
        directional_cols = [
            'symbol', 'direction', 'directional_confidence', 'directional_persistent',
            'recommended_trade', 'spot_move_pct', 'spot_move_60m_pct', 
            'expected_move_pct', 'scan_count'
        ]
        
        print(directional_df[directional_cols].to_string(index=False))
        print("-" * 80)
        
        # Save directional signals
        directional_file = f"directional_signals_{timestamp}.csv"
        directional_df.to_csv(directional_file, index=False)
        logger.info(f"Directional signals saved to {directional_file}")
    
    # If no strong signals, show opportunities to watch
    if signals_df.empty and directional_df.empty:
        print("\n✓ No strong signals found")
        
        # Show top opportunities (score >= 2 OR confidence >= 45)
        if not results_df.empty:
            watch_list = results_df[
                (results_df['score'] >= 2) | 
                (results_df['directional_confidence'] >= 45)
            ].nlargest(15, ['score', 'directional_confidence'])
            
            if not watch_list.empty:
                print("\n⚠️  TOP OPPORTUNITIES TO WATCH (15 Max):")
                print("-" * 80)
                watch_cols = [
                    'symbol', 'recommended_trade', 'score', 'direction', 
                    'directional_confidence', 'spot_move_pct', 'scan_count'
                ]
                print(watch_list[watch_cols].to_string(index=False))
                print("-" * 80)
                print(f"\nNote: Signals strengthen after {Config.MIN_SCANS_FOR_SIGNAL}+ scans (persistence filter)")
    
    # Summary statistics
    if not results_df.empty:
        print(f"\nStraddle Score Distribution:")
        print(results_df['score'].value_counts().sort_index())
        
        print(f"\nDirectional Bias Distribution:")
        print(results_df['direction'].value_counts())
        
        print(f"\nPersistent Signals:")
        print(f"  Straddle: {results_df['signal_persistent'].sum()}")
        print(f"  Directional: {results_df['directional_persistent'].sum()}")
        
        print(f"\nRecommended Trades Summary:")
        print(results_df['recommended_trade'].value_counts().head(10))


if __name__ == "__main__":
    main()
