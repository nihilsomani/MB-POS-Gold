import pandas as pd
import numpy as np

# Column harmonization so we can consume historical/trending CSVs that may
# have renamed writer metrics (e.g., *_pct vs *_score, *_value vs *_hhi).
WRITER_COLUMN_ALIASES = {
    'writer_call_wall_strength_score': [
        'writer_call_wall_strength_score',
        'writer_call_wall_strength_pct',
        'seller_call_wall_strength_score',
    ],
    'writer_put_wall_strength_score': [
        'writer_put_wall_strength_score',
        'writer_put_wall_strength_pct',
        'seller_put_wall_strength_score',
    ],
    'writer_call_wall_distance_pct': [
        'writer_call_wall_distance_pct',
        'writer_call_wall_distance_percent',
    ],
    'writer_put_wall_distance_pct': [
        'writer_put_wall_distance_pct',
        'writer_put_wall_distance_percent',
    ],
    'writer_call_oi_hhi': [
        'writer_call_oi_hhi',
        'writer_call_oi_value',
        'seller_call_oi_hhi',
    ],
    'writer_put_oi_hhi': [
        'writer_put_oi_hhi',
        'writer_put_oi_value',
        'seller_put_oi_hhi',
    ],
    'writer_call_oi_concentration_pct': [
        'writer_call_oi_concentration_pct',
        'writer_call_oi_concentration_percent',
        'seller_call_concentration_pct',
    ],
    'writer_put_oi_concentration_pct': [
        'writer_put_oi_concentration_pct',
        'writer_put_oi_concentration_percent',
        'seller_put_concentration_pct',
    ],
    'writer_call_writer_strength_percent': [
        'writer_call_writer_strength_percent',
        'writer_call_writer_strength_pct',
        'seller_call_writer_strength_percent',
    ],
    'writer_put_writer_strength_percent': [
        'writer_put_writer_strength_percent',
        'writer_put_writer_strength_pct',
        'seller_put_writer_strength_percent',
    ],
    'writer_second_call_oi_ratio': [
        'writer_second_call_oi_ratio',
        'writer_second_call_oi_pct',
    ],
    'writer_second_put_oi_ratio': [
        'writer_second_put_oi_ratio',
        'writer_second_put_oi_pct',
    ],
}

REQUIRED_WRITER_COLUMNS = list(WRITER_COLUMN_ALIASES.keys())


def harmonize_writer_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Rename known writer columns to canonical names and validate presence."""
    missing_after_alias = []

    for canonical, aliases in WRITER_COLUMN_ALIASES.items():
        if canonical in df.columns:
            continue
        for alias in aliases:
            if alias in df.columns:
                df = df.rename(columns={alias: canonical})
                break
        else:
            missing_after_alias.append(canonical)

    if missing_after_alias:
        raise KeyError(
            "Missing required writer columns even after alias harmonization: "
            + ", ".join(missing_after_alias)
        )

    return df

def analyze_directional_opportunity(row):
    """Comprehensive directional analysis using all available metrics"""
    signal = "NEUTRAL"
    strength = 0
    comments = []
    confidence_tags = []
    confidence_score = 0.0

    def add_confidence(tag, weight):
        nonlocal confidence_score
        confidence_tags.append(tag)
        confidence_score += weight
    
    # 1. PRICE-OI DIVERGENCE ANALYSIS
    oi_change = row['current_oi_change_percent']
    price_change = row['current_price_change_percent']
    
    # Short Covering (Best bullish signal)
    if oi_change < -10 and price_change > 3:
        signal = "STRONG_BULLISH"
        strength = 9
        comments.append(f"🔥 STRONG Short Covering: OI-{abs(oi_change):.1f}%, Price+{price_change:.1f}%")
    elif oi_change < -5 and price_change > 2:
        signal = "BULLISH"
        strength = 7
        comments.append(f"Short Covering: OI-{abs(oi_change):.1f}%, Price+{price_change:.1f}%")
    
    # Fresh Shorts Building (Best bearish signal)
    elif oi_change > 10 and price_change < -3:
        signal = "STRONG_BEARISH"
        strength = 9
        comments.append(f"🔥 STRONG Fresh Shorts: OI+{oi_change:.1f}%, Price-{abs(price_change):.1f}%")
    elif oi_change > 5 and price_change < -2:
        signal = "BEARISH"
        strength = 7
        comments.append(f"Fresh Shorts: OI+{oi_change:.1f}%, Price-{abs(price_change):.1f}%")
    
    # Long Buildup
    elif oi_change > 10 and price_change > 2:
        signal = "BULLISH"
        strength = 7
        comments.append(f"Long Buildup: OI+{oi_change:.1f}%, Price+{price_change:.1f}%")
    elif oi_change > 5 and price_change > 1:
        signal = "BULLISH"
        strength = 5
        comments.append(f"Moderate Long Buildup: OI+{oi_change:.1f}%, Price+{price_change:.1f}%")
    
    # Short Buildup
    elif oi_change > 10 and price_change < -2:
        signal = "BEARISH"
        strength = 7
        comments.append(f"Short Buildup: OI+{oi_change:.1f}%, Price-{abs(price_change):.1f}%")
    
    # Long Unwinding
    elif oi_change < -10 and price_change < -2:
        signal = "BEARISH"
        strength = 6
        comments.append(f"Long Unwinding: OI-{abs(oi_change):.1f}%, Price-{abs(price_change):.1f}%")
    
    # 2. Z-SCORE ANALYSIS (Statistical significance)
    oi_zscore = abs(row['current_oi_zscore'])
    price_zscore = abs(row['current_price_zscore'])
    
    if oi_zscore > 2 or price_zscore > 2:
        strength += 1
        comments.append(f"Statistically significant move (OI-Z:{row['current_oi_zscore']:.2f}, Price-Z:{row['current_price_zscore']:.2f})")
        add_confidence("stat_significant", 0.75)
    
    # 3. ROLLOVER QUALITY ANALYSIS
    rollover_pct = row['rollover_percent']
    rollover_quality = row['rollover_quality_index']
    
    if rollover_pct > 8 and rollover_quality > 6:
        strength += 2
        comments.append(f"✅ Strong Rollover: {rollover_pct:.1f}% (Quality:{rollover_quality:.1f}/10) - High Conviction")
        add_confidence("strong_rollover", 1.25)
    elif rollover_pct > 5 and rollover_quality > 4:
        strength += 1
        comments.append(f"Good Rollover: {rollover_pct:.1f}% (Quality:{rollover_quality:.1f}/10)")
    elif rollover_pct < 3:
        strength -= 2
        comments.append(f"⚠️ Weak Rollover: {rollover_pct:.1f}% (Quality:{rollover_quality:.1f}/10) - Low Conviction")
    
    # 4. PRICE POSITIONING (Distance from extremes)
    dist_from_low = row['current_fut_latest_close_vs_series_low_pct']
    is_low_protected = row['current_fut_is_low_protected']
    
    if signal in ["BULLISH", "STRONG_BULLISH"]:
        if dist_from_low > 15:
            strength += 1
            comments.append(f"Good upside room: {dist_from_low:.1f}% above series low")
        elif dist_from_low > 10:
            comments.append(f"Moderate room: {dist_from_low:.1f}% above series low")
    
    if dist_from_low < 2:
        comments.append(f"⚠️ Very close to series low ({dist_from_low:.1f}%)")
        if signal in ["BEARISH", "STRONG_BEARISH"]:
            strength -= 2
            comments.append("Limited downside - contrarian risk")
    
    # 5. OPTIONS BARRIER ANALYSIS
    
    # Call Wall Analysis
    call_wall_dist = row['writer_call_wall_distance_pct']
    call_wall_strength = row['writer_call_wall_strength_score']
    call_concentration = row['writer_call_oi_concentration_pct']
    call_hhi = row['writer_call_oi_hhi']
    call_writer_strength = row['writer_call_writer_strength_percent']
    
    # HHI > 0.15 indicates high concentration (strong barrier)
    if call_hhi > 0.15 and call_wall_strength > 50:
        comments.append(f"🧱 STRONG Call Barrier at +{call_wall_dist:.1f}% (HHI:{call_hhi:.2f}, Strength:{call_wall_strength:.0f})")
        if signal in ["BULLISH", "STRONG_BULLISH"] and call_wall_dist < 3:
            strength -= 2
            comments.append(f"⚠️ Resistance too close for bulls")
        add_confidence("strong_call_wall", 1.0)
    elif call_concentration > 25 and call_writer_strength > 55:
        comments.append(f"Call Wall: {call_concentration:.1f}% concentrated, Writers {call_writer_strength:.0f}% strong")
    
    # Put Wall Analysis  
    put_wall_dist = row['writer_put_wall_distance_pct']
    put_wall_strength = row['writer_put_wall_strength_score']
    put_concentration = row['writer_put_oi_concentration_pct']
    put_hhi = row['writer_put_oi_hhi']
    put_writer_strength = row['writer_put_writer_strength_percent']
    
    if put_hhi > 0.15 and put_wall_strength > 50:
        comments.append(f"🧱 STRONG Put Barrier at -{put_wall_dist:.1f}% (HHI:{put_hhi:.2f}, Strength:{put_wall_strength:.0f})")
        if signal in ["BEARISH", "STRONG_BEARISH"] and put_wall_dist < 3:
            strength -= 2
            comments.append(f"⚠️ Support too close for bears")
        add_confidence("strong_put_wall", 1.0)
    elif put_concentration > 25 and put_writer_strength > 55:
        comments.append(f"Put Wall: {put_concentration:.1f}% concentrated, Writers {put_writer_strength:.0f}% strong")
    
    # 6. PCR ANALYSIS (Contrarian indicator)
    pcr = row['writer_pcr_oi']
    
    if pcr > 1.3:
        comments.append(f"High PCR {pcr:.2f} - Excessive put buying (Contrarian Bullish)")
        if signal in ["BULLISH", "STRONG_BULLISH"]:
            strength += 1
            add_confidence("contrarian_pcr", 0.75)
    elif pcr < 0.55:
        comments.append(f"Low PCR {pcr:.2f} - Call heavy (Contrarian Bearish)")
        if signal in ["BEARISH", "STRONG_BEARISH"]:
            strength += 1
    elif 0.6 <= pcr <= 0.75:
        comments.append(f"PCR {pcr:.2f} - Mild bullish bias")
    
    # 7. SECONDARY STRIKE ANALYSIS (Diversification of walls)
    second_call_ratio = row['writer_second_call_oi_ratio']
    second_put_ratio = row['writer_second_put_oi_ratio']
    
    if second_call_ratio < 0.5:
        comments.append(f"⚠️ Call OI highly concentrated (2nd strike only {second_call_ratio:.0%} of max)")
    
    if second_put_ratio < 0.5:
        comments.append(f"⚠️ Put OI highly concentrated (2nd strike only {second_put_ratio:.0%} of max)")
    
    # 8. VOLATILITY RISK ASSESSMENT
    realized_vol = row['current_realized_vol_annualized']
    max_single_day = row['current_max_single_day_move_pct']
    max_drawdown = abs(row['current_max_drawdown_pct'])
    
    if realized_vol > 20:
        comments.append(f"⚠️ High volatility {realized_vol:.1f}% (Max day:{max_single_day:.1f}%)")
        strength -= 1
    elif realized_vol < 12:
        comments.append(f"✅ Low volatility {realized_vol:.1f}% - Stable stock")
    
    if max_drawdown > 5:
        comments.append(f"Recent drawdown: -{max_drawdown:.1f}%")
    
    # 9. PRICE-OI RATIO (Efficiency metric)
    price_oi_ratio = row['price_oi_ratio_primary']
    if price_oi_ratio < -1:
        comments.append(f"Negative price momentum vs OI ({price_oi_ratio:.2f})")
    
    # 10. ROLL COST ANALYSIS
    roll_cost_pct = row['roll_cost_percent_of_spot']
    term_structure = row['term_structure_slope_percent']
    
    if abs(roll_cost_pct) > 1:
        if roll_cost_pct > 0:
            comments.append(f"Steep contango: Roll cost {roll_cost_pct:.2f}% (bearish for carry)")
        else:
            comments.append(f"Backwardation: Roll cost {roll_cost_pct:.2f}% (bullish for carry)")
    
    # 11. TODAY'S OI VS HISTORICAL
    todays_oi_vs_avg = row['todays_oi_vs_daily_avg_percent']
    if abs(todays_oi_vs_avg) > 200:
        comments.append(f"⚠️ Unusual OI activity today: {todays_oi_vs_avg:+.0f}% vs daily avg")
        strength += 1
    
    # FINAL ADJUSTMENTS
    strength = max(0, min(10, strength))
    
    # Calculate targets based on walls and historical moves
    targets = []
    stop_loss = None
    risk_reward = None
    
    if signal in ["BULLISH", "STRONG_BULLISH"]:
        max_excursion = row['current_max_excursion_pct']
        target1 = row['spot_price'] * (1 + min(call_wall_dist * 0.7, max_excursion * 0.8) / 100)
        target2 = row['writer_max_call_oi_strike']
        targets = [round(target1, 2), target2]
        stop_loss = round(row['spot_price'] * (1 - min(2, max_drawdown * 0.6) / 100), 2)
        
        potential_gain = (target1 - row['spot_price']) / row['spot_price'] * 100
        potential_loss = (row['spot_price'] - stop_loss) / row['spot_price'] * 100
        risk_reward = round(potential_gain / potential_loss, 2) if potential_loss > 0 else 0
        
    elif signal in ["BEARISH", "STRONG_BEARISH"]:
        max_drawdown_pct = abs(row['current_max_drawdown_pct'])
        target1 = row['spot_price'] * (1 - min(put_wall_dist * 0.7, max_drawdown_pct * 0.8) / 100)
        target2 = row['writer_max_put_oi_strike']
        targets = [round(target1, 2), target2]
        stop_loss = round(row['spot_price'] * (1 + 2 / 100), 2)
        
        potential_gain = (row['spot_price'] - target1) / row['spot_price'] * 100
        potential_loss = (stop_loss - row['spot_price']) / row['spot_price'] * 100
        risk_reward = round(potential_gain / potential_loss, 2) if potential_loss > 0 else 0
    
    # Confidence score based on multiple confirming factors
    confidence = min(confidence_score, 5.0)
    if confidence >= 3:
        comments.append(f"✅ HIGH CONFIDENCE ({confidence:.1f} pts from {len(confidence_tags)} factors)")
    
    return {
        'signal': signal,
        'strength': strength,
        'confidence_factors': round(confidence, 2),
        'targets': targets,
        'stop_loss': stop_loss,
        'risk_reward': risk_reward,
        'comments': ' | '.join(comments) if comments else 'No clear signal'
    }

def analyze_straddle_opportunity(row):
    """Comprehensive straddle analysis using all metrics"""
    score = 0
    comments = []
    red_flags = []
    green_flags = []
    recommendation = "AVOID"
    
    # ATM Premium Collection
    atm_premium = row['atm_call_last_price'] + row['atm_put_last_price']
    premium_pct = (atm_premium / row['spot_price']) * 100
    
    # 1. IV vs RV ANALYSIS (Most Critical)
    iv_call = row['atm_call_implied_vol']
    iv_put = row['atm_put_implied_vol']
    iv_avg = (iv_call + iv_put) / 2
    rv = row['current_realized_vol_annualized']
    iv_rv_ratio = iv_avg / rv if rv > 0 else 0
    
    if iv_rv_ratio > 3:
        score += 5
        green_flags.append(f"🔥 EXCELLENT IV/RV:{iv_rv_ratio:.2f} (IV:{iv_avg:.1f}% vs RV:{rv:.1f}%)")
    elif iv_rv_ratio > 2.5:
        score += 4
        green_flags.append(f"Excellent IV/RV:{iv_rv_ratio:.2f}")
    elif iv_rv_ratio > 2:
        score += 3
        green_flags.append(f"Good IV/RV:{iv_rv_ratio:.2f}")
    elif iv_rv_ratio > 1.5:
        score += 1
        comments.append(f"Moderate IV/RV:{iv_rv_ratio:.2f}")
    else:
        score -= 3
        red_flags.append(f"❌ Poor IV/RV:{iv_rv_ratio:.2f} - IV not inflated enough")
    
    # IV Skew analysis
    iv_skew = abs(iv_call - iv_put)
    if iv_skew > 5:
        comments.append(f"IV skew {iv_skew:.1f}% (directional bias exists)")
        score -= 1
    
    # 2. REALIZED VOLATILITY CHECK
    if rv < 10:
        score += 4
        green_flags.append(f"Very stable: RV {rv:.1f}%")
    elif rv < 15:
        score += 2
        green_flags.append(f"Stable: RV {rv:.1f}%")
    elif rv > 20:
        score -= 3
        red_flags.append(f"❌ High volatility: RV {rv:.1f}% - Risky")
    
    # 3. HISTORICAL MOVEMENT ANALYSIS
    max_single_day = row['current_max_single_day_move_pct']
    avg_daily_range = row['current_avg_daily_range_pct']
    avg_abs_move = row['current_avg_abs_daily_move_pct']
    max_drawdown = abs(row['current_max_drawdown_pct'])
    max_excursion = row['current_max_excursion_pct']
    
    if max_single_day < 1.5 and avg_daily_range < 2:
        score += 3
        green_flags.append(f"Tight range: Max {max_single_day:.1f}%, Avg {avg_daily_range:.1f}%")
    elif max_single_day > 2.5 or avg_daily_range > 3:
        score -= 2
        red_flags.append(f"❌ Wide swings: Max {max_single_day:.1f}%, Avg range {avg_daily_range:.1f}%")
    
    if max_drawdown > 5 or max_excursion > 5:
        comments.append(f"Recent extremes: DD-{max_drawdown:.1f}%, Exc+{max_excursion:.1f}%")
    
    # 4. CALL WALL ANALYSIS (Comprehensive)
    call_wall_dist = row['writer_call_wall_distance_pct']
    call_wall_strength = row['writer_call_wall_strength_score']
    call_concentration = row['writer_call_oi_concentration_pct']
    call_hhi = row['writer_call_oi_hhi']
    call_writer_strength = row['writer_call_writer_strength_percent']
    second_call_ratio = row['writer_second_call_oi_ratio']
    
    # HHI-based scoring
    if call_hhi > 0.15:
        score += 2
        green_flags.append(f"Strong call concentration: HHI {call_hhi:.2f}")
    elif call_hhi < 0.08:
        score -= 1
        comments.append(f"Dispersed call OI: HHI {call_hhi:.2f}")
    
    # Distance and strength
    if call_wall_dist > 4 and call_wall_strength > 45:
        score += 3
        green_flags.append(f"Strong call wall at +{call_wall_dist:.1f}% (Strength:{call_wall_strength:.0f})")
    elif call_wall_dist > 3 and call_wall_strength > 35:
        score += 2
        comments.append(f"Good call wall at +{call_wall_dist:.1f}%")
    elif call_wall_dist < 2:
        score -= 2
        red_flags.append(f"❌ Call wall too close at +{call_wall_dist:.1f}%")
    
    # Writer strength
    if call_writer_strength > 60:
        score += 1
        comments.append(f"Strong call writers: {call_writer_strength:.0f}%")
    
    # Concentration check
    if call_concentration > 30:
        comments.append(f"High call concentration: {call_concentration:.0f}%")
    
    # Secondary strike diversification
    if second_call_ratio < 0.4:
        comments.append(f"⚠️ Call OI very concentrated (2nd:{second_call_ratio:.0%})")
    
    # 5. PUT WALL ANALYSIS (Comprehensive)
    put_wall_dist = row['writer_put_wall_distance_pct']
    put_wall_strength = row['writer_put_wall_strength_score']
    put_concentration = row['writer_put_oi_concentration_pct']
    put_hhi = row['writer_put_oi_hhi']
    put_writer_strength = row['writer_put_writer_strength_percent']
    second_put_ratio = row['writer_second_put_oi_ratio']
    
    if put_hhi > 0.15:
        score += 2
        green_flags.append(f"Strong put concentration: HHI {put_hhi:.2f}")
    elif put_hhi < 0.08:
        score -= 1
        comments.append(f"Dispersed put OI: HHI {put_hhi:.2f}")
    
    if put_wall_dist > 4 and put_wall_strength > 45:
        score += 3
        green_flags.append(f"Strong put wall at -{put_wall_dist:.1f}% (Strength:{put_wall_strength:.0f})")
    elif put_wall_dist > 3 and put_wall_strength > 35:
        score += 2
        comments.append(f"Good put wall at -{put_wall_dist:.1f}%")
    elif put_wall_dist < 2:
        score -= 2
        red_flags.append(f"❌ Put wall too close at -{put_wall_dist:.1f}%")
    
    if put_writer_strength > 60:
        score += 1
        comments.append(f"Strong put writers: {put_writer_strength:.0f}%")
    
    if put_concentration > 30:
        comments.append(f"High put concentration: {put_concentration:.0f}%")
    
    if second_put_ratio < 0.4:
        comments.append(f"⚠️ Put OI very concentrated (2nd:{second_put_ratio:.0%})")
    
    # 6. ROLLOVER ANALYSIS
    rollover_pct = row['rollover_percent']
    rollover_quality = row['rollover_quality_index']
    
    if rollover_pct > 7 and rollover_quality > 6:
        score += 3
        green_flags.append(f"Strong rollover: {rollover_pct:.1f}% (Q:{rollover_quality:.1f})")
    elif rollover_pct > 4 and rollover_quality > 4:
        score += 1
        comments.append(f"Good rollover: {rollover_pct:.1f}%")
    elif rollover_pct < 3:
        score -= 3
        red_flags.append(f"❌ Poor rollover: {rollover_pct:.1f}% - Low conviction")
    
    # 7. PCR ANALYSIS (Balance check)
    pcr = row['writer_pcr_oi']
    
    if 0.75 <= pcr <= 0.95:
        score += 2
        green_flags.append(f"Balanced PCR: {pcr:.2f}")
    elif 0.6 <= pcr <= 1.1:
        score += 1
        comments.append(f"Reasonable PCR: {pcr:.2f}")
    elif pcr > 1.3:
        score -= 2
        red_flags.append(f"❌ High PCR {pcr:.2f} - Put heavy (directional bias)")
    elif pcr < 0.5:
        score -= 2
        red_flags.append(f"❌ Low PCR {pcr:.2f} - Call heavy (directional bias)")
    
    # 8. TIME TO EXPIRY
    days = row['days_to_current_expiry']
    
    if days < 5:
        score -= 4
        red_flags.append(f"❌ Only {days} days - EXTREME gamma risk")
    elif days < 10:
        score -= 2
        red_flags.append(f"⚠️ Only {days} days - High gamma risk")
    elif days > 20:
        score += 2
        green_flags.append(f"{days} days - Good theta decay window")
    elif days > 14:
        score += 1
        comments.append(f"{days} days to expiry")
    
    # 9. POSITION FROM SERIES LOW (Risk check)
    dist_from_low = row['current_fut_latest_close_vs_series_low_pct']
    is_protected = row['current_fut_is_low_protected']
    
    if dist_from_low < 1:
        score -= 3
        red_flags.append(f"❌ Near series low {dist_from_low:.1f}% - Breakdown risk")
    elif dist_from_low < 3:
        score -= 1
        comments.append(f"⚠️ Close to low: {dist_from_low:.1f}%")
    elif dist_from_low > 8:
        score += 1
        comments.append(f"Safe from low: {dist_from_low:.1f}%")
    
    # 10. OI CHANGES (Directional bias check)
    oi_change = row['current_oi_change_percent']
    price_change = row['current_price_change_percent']
    
    # Strong directional moves = bad for straddle
    if abs(oi_change) > 15 or abs(price_change) > 3:
        score -= 2
        red_flags.append(f"❌ Strong directional move: OI{oi_change:+.1f}%, Price{price_change:+.1f}%")
    elif abs(price_change) > 2:
        score -= 1
        comments.append(f"Recent move: Price{price_change:+.1f}%")
    
    # 11. PREMIUM ADEQUACY
    if premium_pct > 4.5:
        score += 3
        green_flags.append(f"Excellent premium: ₹{atm_premium:.2f} ({premium_pct:.2f}%)")
    elif premium_pct > 3.5:
        score += 2
        green_flags.append(f"Good premium: ₹{atm_premium:.2f} ({premium_pct:.2f}%)")
    elif premium_pct > 2.5:
        score += 1
        comments.append(f"Decent premium: ₹{atm_premium:.2f} ({premium_pct:.2f}%)")
    else:
        score -= 2
        red_flags.append(f"❌ Low premium: ₹{atm_premium:.2f} ({premium_pct:.2f}%)")
    
    # 12. GREEKS ANALYSIS
    atm_gamma = row['atm_call_gamma']
    atm_theta = abs(row['atm_call_theta'])
    atm_vega = row['atm_call_vega']
    
    # High gamma = more risk near expiry
    if atm_gamma > 0.02 and days < 10:
        comments.append(f"⚠️ High gamma {atm_gamma:.3f} with low DTE - Risky")
    
    # Theta decay
    if atm_theta > 0.5:
        comments.append(f"Good theta decay: -{atm_theta:.2f}/day")
    
    # 13. NEXT MONTH COMPARISON
    next_rv = row['next_realized_vol_annualized']
    if abs(rv - next_rv) > 3:
        comments.append(f"Vol changing: Current {rv:.1f}% vs Next {next_rv:.1f}%")
    
    # FINAL RECOMMENDATION
    if score >= 12:
        recommendation = "EXCELLENT"
    elif score >= 9:
        recommendation = "VERY_GOOD"
    elif score >= 6:
        recommendation = "GOOD"
    elif score >= 3:
        recommendation = "MODERATE"
    elif score >= 0:
        recommendation = "WEAK"
    else:
        recommendation = "AVOID"
    
    # Calculate breakevens
    upper_be = row['atm_strike'] + atm_premium
    lower_be = row['atm_strike'] - atm_premium
    profit_range_pct = (atm_premium * 2 / row['spot_price']) * 100
    
    # Max profit and loss zones
    max_profit = atm_premium
    max_profit_pct = premium_pct
    
    # Expected move based on IV
    expected_move_pct = iv_avg * np.sqrt(days/365)
    expected_move_points = row['spot_price'] * expected_move_pct / 100
    
    prob_profit = "High" if profit_range_pct > expected_move_pct * 2 else "Moderate" if profit_range_pct > expected_move_pct else "Low"
    
    # Strategy recommendation
    if recommendation in ["EXCELLENT", "VERY_GOOD", "GOOD"]:
        if days < 10:
            lower_wing = row['writer_max_put_oi_strike']
            upper_wing = row['writer_max_call_oi_strike']
            strategy = f"Iron Condor: Sell {row['atm_strike']} Straddle + Buy {lower_wing}P/{upper_wing}C"
        elif days < 15:
            strategy = f"Short Straddle @ {row['atm_strike']} (Monitor closely, consider wings)"
        else:
            strategy = f"Short Straddle @ {row['atm_strike']}"
    elif recommendation == "MODERATE":
        strategy = f"Small position Short Straddle or Iron Butterfly @ {row['atm_strike']}"
    else:
        strategy = "Skip - Wait for better setup"
    
    # Compile all comments
    all_comments = []
    if green_flags:
        all_comments.append("GREEN: " + " | ".join(green_flags))
    if red_flags:
        all_comments.append("RED: " + " | ".join(red_flags))
    if comments:
        all_comments.append("INFO: " + " | ".join(comments))
    
    final_comments = " || ".join(all_comments)
    
    return {
        'recommendation': recommendation,
        'score': score,
        'atm_strike': row['atm_strike'],
        'premium': round(atm_premium, 2),
        'premium_pct': round(premium_pct, 2),
        'lower_breakeven': round(lower_be, 2),
        'upper_breakeven': round(upper_be, 2),
        'profit_range_pct': round(profit_range_pct, 2),
        'iv_rv_ratio': round(iv_rv_ratio, 2),
        'expected_move_pct': round(expected_move_pct, 2),
        'prob_profit': prob_profit,
        'max_profit': round(max_profit, 2),
        'max_profit_pct': round(max_profit_pct, 2),
        'strategy': strategy,
        'call_hhi': round(call_hhi, 3),
        'put_hhi': round(put_hhi, 3),
        'comments': final_comments
    }

def scan_fno_data(input_csv, output_csv):
    """Main scanner function with comprehensive analysis"""
    
    # Read data
    df = pd.read_csv(input_csv)
    df = harmonize_writer_columns(df)
    
    print(f"Analyzing {len(df)} symbols...")
    print("="*80)
    
    # Analyze each stock
    results = []
    
    for idx, row in df.iterrows():
        symbol = row['symbol']
        
        # Directional analysis
        dir_analysis = analyze_directional_opportunity(row)
        
        # Straddle analysis
        straddle_analysis = analyze_straddle_opportunity(row)
        
        # Combine results
        result = {
            # Basic Info
            'Symbol': symbol,
            'Spot_Price': row['spot_price'],
            'Days_To_Expiry': row['days_to_current_expiry'],
            
            # Directional Metrics
            'Dir_Signal': dir_analysis['signal'],
            'Dir_Strength': dir_analysis['strength'],
            'Dir_Confidence_Factors': dir_analysis['confidence_factors'],
            'Dir_Targets': str(dir_analysis['targets']),
            'Dir_Stop_Loss': dir_analysis['stop_loss'],
            'Dir_Risk_Reward': dir_analysis['risk_reward'],
            'Dir_Comments': dir_analysis['comments'],
            
            # Straddle Metrics
            'Straddle_Recommendation': straddle_analysis['recommendation'],
            'Straddle_Score': straddle_analysis['score'],
            'Straddle_Strike': straddle_analysis['atm_strike'],
            'Straddle_Premium_Rs': straddle_analysis['premium'],
            'Straddle_Premium_Pct': straddle_analysis['premium_pct'],
            'Straddle_Lower_BE': straddle_analysis['lower_breakeven'],
            'Straddle_Upper_BE': straddle_analysis['upper_breakeven'],
            'Straddle_Profit_Range_Pct': straddle_analysis['profit_range_pct'],
            'Straddle_Max_Profit_Rs': straddle_analysis['max_profit'],
            'Straddle_Max_Profit_Pct': straddle_analysis['max_profit_pct'],
            'Straddle_IV_RV_Ratio': straddle_analysis['iv_rv_ratio'],
            'Straddle_Expected_Move_Pct': straddle_analysis['expected_move_pct'],
            'Straddle_Profit_Probability': straddle_analysis['prob_profit'],
            'Straddle_Call_HHI': straddle_analysis['call_hhi'],
            'Straddle_Put_HHI': straddle_analysis['put_hhi'],
            'Straddle_Strategy': straddle_analysis['strategy'],
            'Straddle_Comments': straddle_analysis['comments'],
            
            # Key Reference Metrics
            'OI_Change_Pct': round(row['current_oi_change_percent'], 2),
            'Price_Change_Pct': round(row['current_price_change_percent'], 2),
            'OI_Zscore': round(row['current_oi_zscore'], 2),
            'Price_Zscore': round(row['current_price_zscore'], 2),
            'Rollover_Pct': round(row['rollover_percent'], 2),
            'Rollover_Quality': round(row['rollover_quality_index'], 1),
            'PCR': round(row['writer_pcr_oi'], 2),
            'Realized_Vol': round(row['current_realized_vol_annualized'], 2),
            'Call_IV': round(row['atm_call_implied_vol'], 2),
            'Put_IV': round(row['atm_put_implied_vol'], 2),
            'Call_Wall_Dist_Pct': round(row['writer_call_wall_distance_pct'], 2),
            'Put_Wall_Dist_Pct': round(row['writer_put_wall_distance_pct'], 2),
            'Call_Wall_Strength': round(row['writer_call_wall_strength_score'], 0),
            'Put_Wall_Strength': round(row['writer_put_wall_strength_score'], 0),
            'Call_Concentration_Pct': round(row['writer_call_oi_concentration_pct'], 1),
            'Put_Concentration_Pct': round(row['writer_put_oi_concentration_pct'], 1),
            'Call_Writer_Strength_Pct': round(row['writer_call_writer_strength_percent'], 1),
            'Put_Writer_Strength_Pct': round(row['writer_put_writer_strength_percent'], 1),
            'Max_Single_Day_Move_Pct': round(row['current_max_single_day_move_pct'], 2),
            'Avg_Daily_Range_Pct': round(row['current_avg_daily_range_pct'], 2),
            'Distance_From_Series_Low_Pct': round(row['current_fut_latest_close_vs_series_low_pct'], 2),
        }
        
        results.append(result)
    
    # Create output dataframe
    output_df = pd.DataFrame(results)
    
    # Create composite scores for sorting
    # Normalize combined directional score so confidence weight never
    # overwhelms raw strength (both limited to 0-10 and 0-5 respectively).
    output_df['Dir_Total_Score'] = (
        output_df['Dir_Strength'] * 1.5 +
        output_df['Dir_Confidence_Factors'] * 0.8
    )
    
    output_df['Straddle_Total_Score'] = output_df['Straddle_Score']
    
    # Save to CSV
    output_df.to_csv(output_csv, index=False)
    
    print(f"\n✅ Analysis complete! Results saved to {output_csv}")
    print(f"Total symbols analyzed: {len(output_df)}")
    print("="*80)
    
    # DIRECTIONAL OPPORTUNITIES
    print("\n" + "🎯 TOP DIRECTIONAL OPPORTUNITIES (Strength >= 7)".center(80))
    print("="*80)
    strong_dir = output_df[output_df['Dir_Strength'] >= 7].sort_values('Dir_Total_Score', ascending=False)
    
    if len(strong_dir) > 0:
        for idx, row in strong_dir.head(10).iterrows():
            print(f"\n{row['Symbol']} - {row['Dir_Signal']} (Strength: {row['Dir_Strength']}/10)")
            print(f"  Price: ₹{row['Spot_Price']} | Targets: {row['Dir_Targets']} | SL: {row['Dir_Stop_Loss']}")
            print(f"  R:R = {row['Dir_Risk_Reward']} | Confidence Factors: {row['Dir_Confidence_Factors']}")
            print(f"  OI: {row['OI_Change_Pct']:+.1f}% | Price: {row['Price_Change_Pct']:+.1f}% | Rollover: {row['Rollover_Pct']:.1f}%")
            print(f"  💬 {row['Dir_Comments'][:150]}...")
    else:
        print("No strong directional setups found.")
    
    # STRADDLE OPPORTUNITIES
    print("\n" + "📉 TOP STRADDLE OPPORTUNITIES (Score >= 6 & Dir NEUTRAL)".center(80))
    print("="*80)
    good_straddles = output_df[(output_df['Straddle_Score'] >= 6) & (output_df['Dir_Signal'] == 'NEUTRAL')].sort_values('Straddle_Total_Score', ascending=False)
    
    if len(good_straddles) > 0:
        for idx, row in good_straddles.head(10).iterrows():
            print(f"\n{row['Symbol']} - {row['Straddle_Recommendation']} (Score: {row['Straddle_Score']}/15)")
            print(f"  Strike: {row['Straddle_Strike']} | Premium: ₹{row['Straddle_Premium_Rs']} ({row['Straddle_Premium_Pct']:.2f}%)")
            print(f"  Breakevens: {row['Straddle_Lower_BE']} - {row['Straddle_Upper_BE']} (±{row['Straddle_Profit_Range_Pct']:.1f}%)")
            print(f"  IV/RV: {row['Straddle_IV_RV_Ratio']:.2f} | Expected Move: {row['Straddle_Expected_Move_Pct']:.1f}% | Profit Prob: {row['Straddle_Profit_Probability']}")
            print(f"  HHI: Call {row['Straddle_Call_HHI']:.3f}, Put {row['Straddle_Put_HHI']:.3f} | Days: {row['Days_To_Expiry']}")
            print(f"  📋 {row['Straddle_Strategy']}")
            print(f"  💬 {row['Straddle_Comments'][:200]}...")
    else:
        print("No good straddle opportunities found.")
    
    # SUMMARY STATISTICS
    print("\n" + "📊 SUMMARY STATISTICS".center(80))
    print("="*80)
    
    dir_dist = output_df['Dir_Signal'].value_counts()
    print("\nDirectional Signal Distribution:")
    for signal, count in dir_dist.items():
        print(f"  {signal}: {count}")
    
    straddle_dist = output_df['Straddle_Recommendation'].value_counts()
    print("\nStraddle Recommendation Distribution:")
    for rec, count in straddle_dist.items():
        print(f"  {rec}: {count}")
    
    print(f"\nAverage Straddle IV/RV Ratio: {output_df['Straddle_IV_RV_Ratio'].mean():.2f}")
    print(f"Average Realized Volatility: {output_df['Realized_Vol'].mean():.1f}%")
    print(f"Average Rollover: {output_df['Rollover_Pct'].mean():.1f}%")
    
    # High conviction plays
    print("\n" + "⭐ HIGH CONVICTION PLAYS".center(80))
    print("="*80)
    
    high_conviction_dir = output_df[
        (output_df['Dir_Strength'] >= 7) & 
        (output_df['Dir_Confidence_Factors'] >= 3)
    ].sort_values('Dir_Total_Score', ascending=False)
    
    if len(high_conviction_dir) > 0:
        print("\nDirectional (Strength >= 7 & Confidence >= 3):")
        for idx, row in high_conviction_dir.head(5).iterrows():
            print(f"  {row['Symbol']}: {row['Dir_Signal']} | Strength {row['Dir_Strength']} | Factors {row['Dir_Confidence_Factors']}")
    
    high_conviction_straddle = output_df[
        (output_df['Straddle_Score'] >= 9) & 
        (output_df['Straddle_IV_RV_Ratio'] >= 2.5)
    ].sort_values('Straddle_Total_Score', ascending=False)
    
    if len(high_conviction_straddle) > 0:
        print("\nStraddle (Score >= 9 & IV/RV >= 2.5):")
        for idx, row in high_conviction_straddle.head(5).iterrows():
            print(f"  {row['Symbol']}: {row['Straddle_Recommendation']} | Score {row['Straddle_Score']} | IV/RV {row['Straddle_IV_RV_Ratio']:.2f}")
    
    return output_df

# Usage
if __name__ == "__main__":
    # Replace with your file paths
    input_file = "trend_results_adaptive_v10_nuance_20251115_201738.csv"
    output_file = "fno_comprehensive_analysis.csv"
    
    results = scan_fno_data(input_file, output_file)
    
    print("\n" + "="*80)
    print("Analysis complete! Check the output CSV for full details.")
    print("="*80)