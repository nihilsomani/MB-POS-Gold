"""
Pro Desk Pattern Engine - Advanced Pattern Detection
----------------------------------------------------

Enhanced version with 20-day multi-phase OI pattern detection:
  • Accumulation Ramp: Early entry for CALL buys (3-phase detection)
  • Distribution Dome: Early entry for PUT buys (3-phase detection)
  • Strangle Squeeze: Breakout timing for directional trades

Reuses core analytics from pro_desk_pattern_engine.py and adds:
  - Strike-specific OI tracking (OTM/ATM/ITM)
  - 20-day lookback window for pattern detection
  - Multi-phase pattern state machine
  - Pattern-based early entry signals

Key Features:
  • All features from base engine (scoring, recommendations, etc.)
  • Advanced pattern detection with phase tracking
  • Strike-specific intelligence (OTM/ATM/ITM OI)
  • Early entry signals (3-5 days ahead of price moves)
  • Pattern-based recommendations with confidence scores
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
from typing import Dict, List, Tuple, Optional
from datetime import date, timedelta

import numpy as np
import pandas as pd

# Import core functions from base engine
# Note: Import from same directory - use sys.path to ensure proper import
import sys
from pathlib import Path
_script_dir = Path(__file__).parent
if str(_script_dir) not in sys.path:
    sys.path.insert(0, str(_script_dir))

import pro_desk_pattern_engine as base_engine

# Re-export constants and functions we need
# Advanced engine uses advanced master file by default
MASTER_PATH = (Path(__file__).resolve().parents[3] / "data" / "daily_trend_master_advanced.csv")
DEFAULT_LOOKBACK = base_engine.DEFAULT_LOOKBACK
MIN_ROWS_REQUIRED = base_engine.MIN_ROWS_REQUIRED

# Advanced pattern detection constants
PATTERN_LOOKBACK = 5  # 20 days for advanced pattern detection
OTM_THRESHOLD_PCT = 0.02  # 2% OTM threshold (strike > current_price * 1.02 for calls, < current_price * 0.98 for puts)
ATM_THRESHOLD_PCT = 0.01  # 1% ATM threshold (within 1% of current price)
ITM_THRESHOLD_PCT = 0.02  # 2% ITM threshold (strike < current_price * 0.98 for calls, > current_price * 1.02 for puts)

# Pattern detection thresholds
ACCUMULATION_RAMP_PHASE1_OI_GROWTH_MIN = 0.5  # % per day minimum for phase 1
ACCUMULATION_RAMP_PHASE2_ACCELERATION_MIN = 0.3  # Acceleration threshold
ACCUMULATION_RAMP_PHASE3_PRICE_GROWTH_MIN = 0.5  # % per day minimum for phase 3

DISTRIBUTION_DOME_PHASE1_OI_GROWTH_MIN = 2.0  # Heavy writing in phase 1
DISTRIBUTION_DOME_PHASE2_SIDEWAYS_RANGE = 0.5  # Max price movement in phase 2
DISTRIBUTION_DOME_PHASE3_OI_UNWINDING_MIN = -1.0  # OI declining in phase 3

STRANGLE_SQUEEZE_OI_BUILDUP_MIN = 1.0  # % per day minimum OI buildup
STRANGLE_SQUEEZE_IV_DECLINE_MIN = -0.5  # IV declining per day
STRANGLE_SQUEEZE_RANGE_COMPRESSION_MAX = 1.5  # Max daily range %


def _classify_strike_oi(option_chain: pd.DataFrame, current_price: float) -> Dict[str, float]:
    """
    Classify options OI by strike level (OTM/ATM/ITM).
    
    Args:
        option_chain: DataFrame with columns: 'strike', 'oi', 'instrument_type' (CE/PE)
        current_price: Current spot/futures price
    
    Returns:
        Dict with: otm_call_oi, atm_call_oi, itm_call_oi, otm_put_oi, atm_put_oi, itm_put_oi
    """
    if option_chain.empty or 'strike' not in option_chain.columns or 'oi' not in option_chain.columns:
        return {
            'otm_call_oi': 0.0,
            'atm_call_oi': 0.0,
            'itm_call_oi': 0.0,
            'otm_put_oi': 0.0,
            'atm_put_oi': 0.0,
            'itm_put_oi': 0.0,
        }
    
    calls = option_chain[option_chain['instrument_type'] == 'CE'].copy()
    puts = option_chain[option_chain['instrument_type'] == 'PE'].copy()
    
    # Classify calls
    otm_calls = calls[calls['strike'] > current_price * (1 + OTM_THRESHOLD_PCT)]
    atm_calls = calls[
        (calls['strike'] >= current_price * (1 - ATM_THRESHOLD_PCT)) &
        (calls['strike'] <= current_price * (1 + ATM_THRESHOLD_PCT))
    ]
    itm_calls = calls[calls['strike'] < current_price * (1 - ITM_THRESHOLD_PCT)]
    
    # Classify puts
    otm_puts = puts[puts['strike'] < current_price * (1 - OTM_THRESHOLD_PCT)]
    atm_puts = puts[
        (puts['strike'] >= current_price * (1 - ATM_THRESHOLD_PCT)) &
        (puts['strike'] <= current_price * (1 + ATM_THRESHOLD_PCT))
    ]
    itm_puts = puts[puts['strike'] > current_price * (1 + ITM_THRESHOLD_PCT)]
    
    return {
        'otm_call_oi': float(otm_calls['oi'].sum()) if not otm_calls.empty else 0.0,
        'atm_call_oi': float(atm_calls['oi'].sum()) if not atm_calls.empty else 0.0,
        'itm_call_oi': float(itm_calls['oi'].sum()) if not itm_calls.empty else 0.0,
        'otm_put_oi': float(otm_puts['oi'].sum()) if not otm_puts.empty else 0.0,
        'atm_put_oi': float(atm_puts['oi'].sum()) if not atm_puts.empty else 0.0,
        'itm_put_oi': float(itm_puts['oi'].sum()) if not itm_puts.empty else 0.0,
    }


def _detect_accumulation_ramp(window_20d: pd.DataFrame, strike_oi_history: List[Dict]) -> Optional[Dict]:
    """
    Detect "Accumulation Ramp" pattern:
    - Phase 1 (Days 1-10): Slow OI buildup at OTM calls, price flat
    - Phase 2 (Days 11-15): Acceleration in OI buildup
    - Phase 3 (Days 16-20): Price starts following OI
    
    Returns pattern dict with phase, confidence, and action signal, or None if not detected.
    """
    if len(window_20d) < 20 or len(strike_oi_history) < 20:
        return None
    
    # Split into phases
    phase1 = window_20d.iloc[0:10]
    phase2 = window_20d.iloc[10:15]
    phase3 = window_20d.iloc[15:20]
    
    phase1_oi = [s.get('otm_call_oi', 0) for s in strike_oi_history[0:10]]
    phase2_oi = [s.get('otm_call_oi', 0) for s in strike_oi_history[10:15]]
    phase3_oi = [s.get('otm_call_oi', 0) for s in strike_oi_history[15:20]]
    
    # Phase 1: Slow OI buildup, price flat
    if len(phase1_oi) < 2:
        return None
    phase1_oi_growth = ((phase1_oi[-1] - phase1_oi[0]) / phase1_oi[0] * 100.0) if phase1_oi[0] > 0 else 0.0
    phase1_price_growth = phase1['price_return_pct'].dropna().mean() if 'price_return_pct' in phase1.columns else 0.0
    
    # Phase 2: Acceleration
    if len(phase2_oi) < 2:
        return None
    phase2_oi_growth = ((phase2_oi[-1] - phase2_oi[0]) / phase2_oi[0] * 100.0) if phase2_oi[0] > 0 else 0.0
    phase2_acceleration = phase2_oi_growth - phase1_oi_growth
    
    # Phase 3: Price follows
    phase3_price_growth = phase3['price_return_pct'].dropna().mean() if 'price_return_pct' in phase3.columns else 0.0
    phase3_oi_growth = ((phase3_oi[-1] - phase3_oi[0]) / phase3_oi[0] * 100.0) if phase3_oi[0] > 0 else 0.0
    
    # Pattern detection logic
    phase1_ok = (phase1_oi_growth > ACCUMULATION_RAMP_PHASE1_OI_GROWTH_MIN and 
                 abs(phase1_price_growth) < 0.3)  # Slow buildup, price flat
    phase2_ok = (phase2_acceleration > ACCUMULATION_RAMP_PHASE2_ACCELERATION_MIN)  # Acceleration
    phase3_ok = (phase3_price_growth > ACCUMULATION_RAMP_PHASE3_PRICE_GROWTH_MIN and 
                 phase3_oi_growth > 0)  # Price follows
    
    if phase1_ok and phase2_ok and phase3_ok:
        # Determine current phase
        current_day = len(window_20d)
        if current_day <= 10:
            current_phase = 1
            action = "MONITOR"
        elif current_day <= 15:
            current_phase = 2
            action = "PREPARE" if current_day >= 14 else "MONITOR"
        else:
            current_phase = 3
            action = "BUY_CALLS"
        
        # Calculate confidence (0-100)
        confidence = min(100, 50 + (phase2_acceleration * 10) + (phase3_price_growth * 20))
        
        return {
            'pattern': 'ACCUMULATION_RAMP',
            'phase': current_phase,
            'confidence': round(confidence, 1),
            'action': action,
            'direction': 'BULLISH',
            'description': f"Phase {current_phase}/3: OI accumulation at OTM calls, acceleration detected",
            'entry_signal': current_day >= 15,  # Signal on day 15-16
        }
    
    return None


def _detect_distribution_dome(window_20d: pd.DataFrame, strike_oi_history: List[Dict], current_price: float) -> Optional[Dict]:
    """
    Detect "Distribution Dome" pattern:
    - Phase 1 (Days 1-5): Heavy call writing at resistance (OTM calls)
    - Phase 2 (Days 6-15): Sideways price, OI stays high
    - Phase 3 (Days 16-20): OI unwinding begins
    
    Returns pattern dict with phase, confidence, and action signal, or None if not detected.
    """
    if len(window_20d) < 20 or len(strike_oi_history) < 20:
        return None
    
    # Split into phases
    phase1 = window_20d.iloc[0:5]
    phase2 = window_20d.iloc[5:15]
    phase3 = window_20d.iloc[15:20]
    
    phase1_oi = [s.get('otm_call_oi', 0) for s in strike_oi_history[0:5]]
    phase2_oi = [s.get('otm_call_oi', 0) for s in strike_oi_history[5:15]]
    phase3_oi = [s.get('otm_call_oi', 0) for s in strike_oi_history[15:20]]
    
    # Phase 1: Heavy call writing (OI buildup at OTM calls = writing)
    if len(phase1_oi) < 2:
        return None
    phase1_oi_growth = ((phase1_oi[-1] - phase1_oi[0]) / max(phase1_oi[0], 1) * 100.0)
    
    # Phase 2: Sideways price, OI stays high
    phase2_price_range = phase2['daily_range_pct'].dropna().mean() if 'daily_range_pct' in phase2.columns else 0.0
    phase2_price_displacement = abs((phase2['close'].iloc[-1] - phase2['close'].iloc[0]) / phase2['close'].iloc[0] * 100.0) if len(phase2) > 0 else 0.0
    phase2_oi_avg = np.mean(phase2_oi) if phase2_oi else 0.0
    
    # Phase 3: OI unwinding
    if len(phase3_oi) < 2:
        return None
    phase3_oi_growth = ((phase3_oi[-1] - phase3_oi[0]) / max(phase3_oi[0], 1) * 100.0)
    
    # Pattern detection logic
    phase1_ok = (phase1_oi_growth > DISTRIBUTION_DOME_PHASE1_OI_GROWTH_MIN)  # Heavy writing
    phase2_ok = (phase2_price_displacement < DISTRIBUTION_DOME_PHASE2_SIDEWAYS_RANGE and
                 phase2_oi_avg > np.mean(phase1_oi) * 0.9)  # Sideways, OI high
    phase3_ok = (phase3_oi_growth < DISTRIBUTION_DOME_PHASE3_OI_UNWINDING_MIN)  # OI unwinding
    
    if phase1_ok and phase2_ok and phase3_ok:
        # Determine current phase
        current_day = len(window_20d)
        if current_day <= 5:
            current_phase = 1
            action = "MONITOR"
        elif current_day <= 15:
            current_phase = 2
            action = "MONITOR"
        else:
            current_phase = 3
            action = "BUY_PUTS"
        
        # Calculate confidence
        confidence = min(100, 50 + (abs(phase3_oi_growth) * 5) + (phase2_oi_avg / max(np.mean(phase1_oi), 1) * 20))
        
        return {
            'pattern': 'DISTRIBUTION_DOME',
            'phase': current_phase,
            'confidence': round(confidence, 1),
            'action': action,
            'direction': 'BEARISH',
            'description': f"Phase {current_phase}/3: Call writing at resistance, OI unwinding",
            'entry_signal': current_day >= 16,  # Signal on day 16-17
        }
    
    return None


def _detect_strangle_squeeze(window_20d: pd.DataFrame, strike_oi_history: List[Dict], iv_history: List[float]) -> Optional[Dict]:
    """
    Detect "Strangle Squeeze" pattern:
    - Consistent OI buildup at both OTM calls AND OTM puts
    - IV declining over 20 days
    - Price compressing into tighter range
    
    Returns pattern dict with confidence and action signal, or None if not detected.
    """
    if len(window_20d) < 20 or len(strike_oi_history) < 20:
        return None
    
    # OI buildup at both OTM calls and puts
    otm_call_oi_start = strike_oi_history[0].get('otm_call_oi', 0)
    otm_call_oi_end = strike_oi_history[-1].get('otm_call_oi', 0)
    otm_put_oi_start = strike_oi_history[0].get('otm_put_oi', 0)
    otm_put_oi_end = strike_oi_history[-1].get('otm_put_oi', 0)
    
    call_oi_growth = ((otm_call_oi_end - otm_call_oi_start) / max(otm_call_oi_start, 1) * 100.0) if otm_call_oi_start > 0 else 0.0
    put_oi_growth = ((otm_put_oi_end - otm_put_oi_start) / max(otm_put_oi_start, 1) * 100.0) if otm_put_oi_start > 0 else 0.0
    
    # IV declining
    if len(iv_history) < 20:
        return None
    iv_start = iv_history[0] if iv_history[0] is not None else None
    iv_end = iv_history[-1] if iv_history[-1] is not None else None
    iv_decline = ((iv_end - iv_start) / iv_start * 100.0) if (iv_start and iv_start > 0) else 0.0
    
    # Price compressing
    range_start = window_20d['daily_range_pct'].iloc[0:10].mean() if 'daily_range_pct' in window_20d.columns else 0.0
    range_end = window_20d['daily_range_pct'].iloc[-10:].mean() if 'daily_range_pct' in window_20d.columns else 0.0
    range_compression = range_start - range_end  # Positive = compressing
    
    # Pattern detection logic
    oi_buildup_ok = (call_oi_growth > STRANGLE_SQUEEZE_OI_BUILDUP_MIN and 
                     put_oi_growth > STRANGLE_SQUEEZE_OI_BUILDUP_MIN)  # Both building
    iv_decline_ok = (iv_decline < STRANGLE_SQUEEZE_IV_DECLINE_MIN)  # IV declining
    compression_ok = (range_end < STRANGLE_SQUEEZE_RANGE_COMPRESSION_MAX and 
                      range_compression > 0.2)  # Range compressing
    
    if oi_buildup_ok and iv_decline_ok and compression_ok:
        # Determine direction based on which side has more OI
        if call_oi_growth > put_oi_growth * 1.2:
            direction = 'BULLISH'
            action = "PREPARE_CALLS"
        elif put_oi_growth > call_oi_growth * 1.2:
            direction = 'BEARISH'
            action = "PREPARE_PUTS"
        else:
            direction = 'NEUTRAL'
            action = "PREPARE_BREAKOUT"
        
        # Calculate confidence
        confidence = min(100, 60 + (min(call_oi_growth, put_oi_growth) * 2) + (abs(iv_decline) * 3) + (range_compression * 10))
        
        return {
            'pattern': 'STRANGLE_SQUEEZE',
            'phase': 3,  # All conditions met = ready for breakout
            'confidence': round(confidence, 1),
            'action': action,
            'direction': direction,
            'description': f"OI buildup both sides, IV declining, range compressing - breakout imminent",
            'entry_signal': True,  # Ready for breakout
        }
    
    return None


def analyze_master_advanced(master_path: Path, lookback: int = DEFAULT_LOOKBACK, pattern_lookback: int = PATTERN_LOOKBACK) -> pd.DataFrame:
    """
    Advanced pattern detection engine.
    
    First runs base analysis, then adds advanced pattern detection with 20-day lookback.
    
    NOTE: Full pattern detection requires strike-specific OI data (OTM/ATM/ITM).
    Current implementation uses aggregate OI as proxy - will be enhanced when strike-specific data is available.
    """
    # Run base analysis (10-day lookback for scoring)
    report_df = base_engine.analyze_master(master_path, lookback)
    
    if report_df.empty:
        return report_df
    
    # Load master data for pattern detection (need 20-day history)
    df = pd.read_csv(master_path, parse_dates=['date', 'expiry'])
    df['date'] = df['date'].dt.date
    df.sort_values(['symbol', 'contract_type', 'date'], inplace=True)
    
    # For now, we'll add pattern detection as a placeholder
    # Full implementation requires strike-specific OI data in master file
    # This is a framework that can be enhanced when strike-specific data is available
    
    def _detect_patterns_for_symbol(symbol: str, contract: str) -> Dict:
        """Detect advanced patterns for a symbol/contract."""
        symbol_data = df[(df['symbol'] == symbol) & (df['contract_type'] == contract)].sort_values('date')
        
        if len(symbol_data) < pattern_lookback:
            return {
                'advanced_pattern': None,
                'pattern_phase': None,
                'pattern_confidence': None,
                'pattern_action': None,
                'pattern_direction': None,
                'pattern_description': None,
            }
        
        window_20d = symbol_data.tail(pattern_lookback).copy()
        
        # For now, use aggregate options OI as proxy (will be enhanced with strike-specific data)
        # This is a placeholder - full implementation needs strike-specific OI in master file
        strike_oi_history = []
        iv_history = []
        
        for _, row in window_20d.iterrows():
            # Use strike-specific OI if available (from OTTrendScannerV2_advanced), otherwise fall back to estimate
            otm_call_oi = row.get('otm_call_oi')
            otm_put_oi = row.get('otm_put_oi')
            
            if otm_call_oi is None or otm_put_oi is None:
                # Fallback: estimate OTM OI as 30% of total (typical distribution)
                # This happens if master file doesn't have strike-specific data yet
                call_oi = float(row.get('options_call_oi', 0) or 0)
                put_oi = float(row.get('options_put_oi', 0) or 0)
                otm_call_oi = call_oi * 0.3
                otm_put_oi = put_oi * 0.3
            
            strike_oi_history.append({
                'otm_call_oi': float(otm_call_oi) if otm_call_oi is not None else 0.0,
                'otm_put_oi': float(otm_put_oi) if otm_put_oi is not None else 0.0,
            })
            iv_history.append(row.get('IVPercentile'))  # IV percentile from screener
        
        current_price = float(window_20d['close'].iloc[-1]) if 'close' in window_20d.columns else None
        
        # Try to detect patterns (will work better with real strike-specific data)
        patterns = []
        
        # Accumulation Ramp
        acc_ramp = _detect_accumulation_ramp(window_20d, strike_oi_history)
        if acc_ramp:
            patterns.append(acc_ramp)
        
        # Distribution Dome
        if current_price:
            dist_dome = _detect_distribution_dome(window_20d, strike_oi_history, current_price)
            if dist_dome:
                patterns.append(dist_dome)
        
        # Strangle Squeeze
        strangle = _detect_strangle_squeeze(window_20d, strike_oi_history, iv_history)
        if strangle:
            patterns.append(strangle)
        
        # Return strongest pattern
        if patterns:
            strongest = max(patterns, key=lambda p: p.get('confidence', 0))
            return {
                'advanced_pattern': strongest.get('pattern'),
                'pattern_phase': strongest.get('phase'),
                'pattern_confidence': strongest.get('confidence'),
                'pattern_action': strongest.get('action'),
                'pattern_direction': strongest.get('direction'),
                'pattern_description': strongest.get('description'),
            }
        
        return {
            'advanced_pattern': None,
            'pattern_phase': None,
            'pattern_confidence': None,
            'pattern_action': None,
            'pattern_direction': None,
            'pattern_description': None,
        }
    
    # Apply pattern detection to report
    pattern_data = []
    for _, row in report_df.iterrows():
        patterns = _detect_patterns_for_symbol(row['symbol'], row['contract_type'])
        pattern_data.append(patterns)
    
    # Add pattern columns to report
    for key in ['advanced_pattern', 'pattern_phase', 'pattern_confidence', 'pattern_action', 'pattern_direction', 'pattern_description']:
        report_df[key] = [p.get(key) for p in pattern_data]
    
    # Enhance directional trade score with pattern signals
    def _enhance_directional_score_with_pattern(row):
        base_score = row.get('directional_trade_score', 0.0)
        pattern = row.get('advanced_pattern')
        pattern_confidence = row.get('pattern_confidence', 0.0)
        pattern_action = row.get('pattern_action', '')
        core = row.get('core_label', '')
        
        if not pattern or pattern_confidence < 50:
            return base_score
        
        # Pattern bonus based on alignment with core trend
        pattern_bonus = 0.0
        
        if pattern == 'ACCUMULATION_RAMP' and core == 'TREND_LONG':
            pattern_bonus = pattern_confidence * 0.3  # Up to +30 points
        elif pattern == 'DISTRIBUTION_DOME' and core == 'TREND_SHORT':
            pattern_bonus = pattern_confidence * 0.3  # Up to +30 points
        elif pattern == 'STRANGLE_SQUEEZE':
            pattern_bonus = pattern_confidence * 0.25  # Up to +25 points
        
        # Entry signal bonus
        if 'BUY' in pattern_action or 'PREPARE' in pattern_action:
            pattern_bonus += 5  # Early entry signal
        
        enhanced_score = min(100.0, base_score + pattern_bonus)
        return round(enhanced_score, 1)
    
    report_df['directional_trade_score_enhanced'] = report_df.apply(_enhance_directional_score_with_pattern, axis=1)
    
    # Update recommendations based on enhanced scores
    def _update_directional_reco_with_pattern(row):
        enhanced_score = row.get('directional_trade_score_enhanced', 0.0)
        pattern = row.get('advanced_pattern')
        pattern_action = row.get('pattern_action', '')
        core = row.get('core_label', '')
        
        # Use enhanced score for recommendation
        if enhanced_score >= 75:
            return "STRONG_BUY"
        elif enhanced_score >= 60:
            return "BUY"
        elif enhanced_score >= 40:
            return "CAUTION"
        else:
            return "AVOID"
    
    report_df['directional_trade_recommendation'] = report_df.apply(_update_directional_reco_with_pattern, axis=1)
    
    # Update summary notes with pattern information
    def _enhance_summary_note_with_pattern(row):
        base_note = row.get('summary_note', '')
        pattern = row.get('advanced_pattern')
        pattern_phase = row.get('pattern_phase')
        pattern_confidence = row.get('pattern_confidence')
        pattern_action = row.get('pattern_action')
        pattern_description = row.get('pattern_description')
        
        if pattern and pattern_confidence:
            pattern_info = f" | 🔥 Pattern: {pattern} (Phase {pattern_phase}, Confidence: {pattern_confidence}%, Action: {pattern_action})"
            if pattern_description:
                pattern_info += f" - {pattern_description}"
            return base_note + pattern_info
        
        return base_note
    
    report_df['summary_note'] = report_df.apply(_enhance_summary_note_with_pattern, axis=1)
    
    return report_df


def main():
    parser = argparse.ArgumentParser(description="Pro Desk Pattern Engine - Advanced Pattern Detection")
    parser.add_argument("--lookback", type=int, default=DEFAULT_LOOKBACK,
                        help="Number of most recent trading days per symbol (for base scoring)")
    parser.add_argument("--pattern-lookback", type=int, default=PATTERN_LOOKBACK,
                        help="Number of days for advanced pattern detection (default: 20)")
    parser.add_argument("--output", type=str, default="data/pro_desk_pattern_report_advanced.csv",
                        help="Path to save the advanced pattern report")
    parser.add_argument("--top", type=int, default=10,
                        help="Number of top entries per category to print")
    args = parser.parse_args()

    report_df = analyze_master_advanced(MASTER_PATH, args.lookback, args.pattern_lookback)
    if report_df.empty:
        print("No symbols met the minimum data requirement.")
        return

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    report_df.sort_values('directional_trade_score_enhanced', ascending=False).to_csv(output_path, index=False)
    print(f"Advanced pattern report saved to {output_path} ({len(report_df)} rows).")

    # Print pattern detections
    pattern_subset = report_df[report_df['advanced_pattern'].notna()].sort_values('pattern_confidence', ascending=False)
    if not pattern_subset.empty:
        print(f"\n=== Advanced Pattern Detections (Top {min(args.top, len(pattern_subset))}) ===")
        for _, row in pattern_subset.head(args.top).iterrows():
            print(
                f"{row['symbol']} [{row['contract_type']}] "
                f"Pattern: {row['advanced_pattern']} (Phase {row['pattern_phase']}, Confidence: {row['pattern_confidence']}%) "
                f"Action: {row['pattern_action']} | {row['pattern_description']}"
            )
            if 'summary_note' in row and pd.notna(row.get('summary_note')):
                print(f"  📋 Summary: {row['summary_note']}")

    # Print enhanced directional candidates
    dir_subset = report_df[
        (report_df['directional_candidate'] == True) &
        (report_df['advanced_pattern'].notna())
    ].sort_values('directional_trade_score_enhanced', ascending=False)
    
    if not dir_subset.empty:
        print(f"\n=== Enhanced DIRECTIONAL Candidates (with Pattern Signals) (Top {min(args.top, len(dir_subset))}) ===")
        for _, row in dir_subset.head(args.top).iterrows():
            direction = "CALL" if row.get('core_label') == 'TREND_LONG' else "PUT"
            print(
                f"{row['symbol']} [{direction}] "
                f"Enhanced Score: {row.get('directional_trade_score_enhanced', 'N/A')} "
                f"Pattern: {row.get('advanced_pattern', 'N/A')} ({row.get('pattern_confidence', 'N/A')}%) "
                f"Action: {row.get('pattern_action', 'N/A')} | {row.get('policy_brief', '')}"
            )
            if 'summary_note' in row and pd.notna(row.get('summary_note')):
                print(f"  📋 Summary: {row['summary_note']}")


if __name__ == "__main__":
    main()

