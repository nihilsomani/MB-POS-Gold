"""
Stock Fundamental Analysis System (Ollama Version)
Analyzes balance sheets, annual reports, and concall transcripts to classify companies
Uses FREE local LLM via Ollama - No API key required!
"""

import os
import json
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple
import re
from datetime import datetime
import requests

class StockFundamentalAnalyzer:
    def __init__(self, model: str = "llama3", downloads_dir: str = "downloads", 
                 ollama_url: str = "http://localhost:11434"):
        """
        Initialize the analyzer with Ollama (FREE local LLM) and document paths
        
        Args:
            model: Ollama model name (default: "llama3")
                   Options: llama3, mistral, phi, gemma, etc.
            downloads_dir: Path to downloads folder (default: "downloads")
                Expected structure:
                downloads/
                  ├── concalls/          (conference call transcripts)
                  ├── annual_reports/    (annual reports)
                  └── balance_sheets/    (balance sheet data)
            ollama_url: Ollama API URL (default: http://localhost:11434)
        """
        self.model = model
        self.ollama_url = ollama_url
        self.api_endpoint = f"{ollama_url}/api/generate"
        self.downloads_dir = Path(downloads_dir)
        self.concalls_dir = self.downloads_dir / "concalls"
        self.reports_dir = self.downloads_dir / "annual_reports"
        self.balance_sheets_dir = self.downloads_dir / "balance_sheets"
        
        # Create directories if they don't exist
        self.concalls_dir.mkdir(parents=True, exist_ok=True)
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        self.balance_sheets_dir.mkdir(parents=True, exist_ok=True)
        
        # Check if Ollama is running
        self._check_ollama_connection()
    
    def _check_ollama_connection(self):
        """Check if Ollama is running and accessible"""
        try:
            response = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            if response.status_code == 200:
                available_models = [m['name'] for m in response.json().get('models', [])]
                if available_models:
                    print(f"✓ Ollama connected! Available models: {', '.join(available_models)}")
                    if self.model not in [m.split(':')[0] for m in available_models]:
                        print(f"⚠ Warning: Model '{self.model}' not found. Available: {available_models}")
                        print(f"  Run: ollama pull {self.model}")
                else:
                    print(f"⚠ Ollama running but no models found. Run: ollama pull {self.model}")
            else:
                print(f"⚠ Ollama connection issue. Status: {response.status_code}")
        except requests.exceptions.ConnectionError:
            print("❌ Cannot connect to Ollama!")
            print("   1. Install: https://ollama.com/")
            print(f"   2. Pull model: ollama pull {self.model}")
            print("   3. Ollama runs automatically after install")
        except Exception as e:
            print(f"⚠ Ollama check failed: {e}")
    
    def _query_ollama(self, prompt: str, max_tokens: int = 4000, retries: int = 2) -> str:
        """
        Query Ollama LLM with a prompt (with retry logic)
        
        Args:
            prompt: The prompt to send
            max_tokens: Maximum tokens in response
            retries: Number of retries on timeout
            
        Returns:
            The LLM response text
        """
        import time
        from requests.exceptions import Timeout, ConnectionError
        
        for attempt in range(retries + 1):
            try:
                payload = {
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "num_predict": max_tokens,
                        "temperature": 0.1
                    }
                }
                
                # Progressive timeout: first attempt 3 min, then 5 min
                timeout = 180 if attempt == 0 else 300
                
                if attempt > 0:
                    print(f"   ⏳ Retry {attempt}/{retries} (timeout: {timeout}s)...")
                    time.sleep(2)  # Brief pause before retry
                
                response = requests.post(self.api_endpoint, json=payload, timeout=timeout)
                
                if response.status_code == 200:
                    return response.json()['response']
                else:
                    print(f"⚠ Ollama error {response.status_code}: {response.text}")
                    if attempt < retries:
                        continue
                    return ""
                    
            except Timeout:
                print(f"⚠ Timeout after {timeout}s")
                if attempt < retries:
                    print(f"   🔄 Will retry with longer timeout...")
                    continue
                else:
                    print(f"❌ Max retries reached. Ollama may be overloaded or prompt too complex.")
                    print(f"   💡 Tip: Try using a smaller model (phi) or restart Ollama")
                    return ""
                    
            except ConnectionError as e:
                print(f"❌ Connection error: {e}")
                print(f"   💡 Check if Ollama is running: ollama serve")
                return ""
                
            except Exception as e:
                print(f"❌ Error querying Ollama: {e}")
                if attempt < retries:
                    continue
                return ""
        
        return ""
        
    def read_documents(self, company_symbol: str) -> Dict[str, str]:
        """
        Read all documents for a company by symbol
        
        Args:
            company_symbol: Stock symbol (e.g., 'RELIANCE', 'TCS')
            
        Returns:
            Dictionary with 'balance_sheet', 'annual_report', and 'concall' text
        """
        documents = {
            'balance_sheet': '',
            'annual_report': '',
            'concall': ''
        }
        
        # Read balance sheet
        balance_sheets = list(self.balance_sheets_dir.glob(f"{company_symbol}*"))
        if balance_sheets:
            try:
                content = balance_sheets[0].read_text(encoding='utf-8', errors='ignore')
                documents['balance_sheet'] = content
                print(f"   ✓ Found balance sheet: {balance_sheets[0].name}")
            except Exception as e:
                print(f"   ✗ Error reading balance sheet: {e}")
        
        # Read annual report
        reports = list(self.reports_dir.glob(f"{company_symbol}*"))
        if reports:
            try:
                if reports[0].suffix.lower() == '.pdf':
                    content = self._extract_pdf_text(str(reports[0]))
                else:
                    content = reports[0].read_text(encoding='utf-8', errors='ignore')
                documents['annual_report'] = content
                print(f"   ✓ Found annual report: {reports[0].name}")
            except Exception as e:
                print(f"   ✗ Error reading annual report: {e}")
        
        # Read concall transcript
        concalls = list(self.concalls_dir.glob(f"{company_symbol}*"))
        if concalls:
            try:
                if concalls[0].suffix.lower() == '.pdf':
                    content = self._extract_pdf_text(str(concalls[0]))
                else:
                    content = concalls[0].read_text(encoding='utf-8', errors='ignore')
                documents['concall'] = content
                print(f"   ✓ Found concall: {concalls[0].name}")
            except Exception as e:
                print(f"   ✗ Error reading concall: {e}")
        
        if not any(documents.values()):
            print(f"   ⚠ Warning: No documents found for {company_symbol}")
                
        return documents
    
    def _extract_pdf_text(self, pdf_path: str) -> str:
        """Extract text from PDF file"""
        try:
            import PyPDF2
            text = ""
            with open(pdf_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                for page in reader.pages:
                    text += page.extract_text() + "\n"
            return text
        except ImportError:
            print("   ⚠ PyPDF2 not installed. Install with: pip install PyPDF2")
            return ""
        except Exception as e:
            print(f"   ✗ Error extracting PDF: {e}")
            return ""
    
    def extract_financial_metrics(self, balance_sheet: str) -> Dict:
        """Extract key financial metrics from balance sheet"""
        # Check balance sheet size
        if not balance_sheet:
            return {"error": "No balance sheet data"}
        
        bs_size = len(balance_sheet)
        if bs_size > 50000:
            print(f"   ⚠ Large balance sheet ({bs_size} chars) - using excerpt only")
        
        # Limit data size more aggressively to prevent timeouts
        data_snippet = balance_sheet[:5000] if len(balance_sheet) > 5000 else balance_sheet
        
        prompt = f"""You are a financial analyst. Extract key metrics from this balance sheet for recent years.

Focus on these key metrics:
1. Revenue
2. Net Profit
3. Total Assets
4. Total Debt
5. Shareholders Equity

Balance Sheet (excerpt):
{data_snippet}

Return ONLY valid JSON format. Keep it concise.
Example: {{"2023": {{"revenue": 1000, "net_profit": 100}}, "2022": {{"revenue": 900, "net_profit": 80}}}}

JSON:"""

        response_text = self._query_ollama(prompt, max_tokens=2000)
        
        try:
            # Extract JSON from response (in case model adds extra text)
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                metrics = json.loads(json_match.group())
            else:
                metrics = json.loads(response_text)
        except:
            metrics = {"error": "Could not parse metrics", "raw": response_text[:500]}
            
        return metrics
    
    def analyze_turnaround_potential(self, documents: Dict[str, str], metrics: Dict) -> Dict:
        """Analyze if company is a turnaround candidate"""
        prompt = f"""You are a financial analyst. Analyze if this company is a TURNAROUND candidate.

Turnaround signals:
- Past losses → recent profitability
- Improving cash flows
- Debt reduction
- Management changes
- Market share recovery

Financial Metrics:
{json.dumps(metrics, indent=2)[:2000]}

Annual Report (excerpt):
{documents['annual_report'][:5000]}

Concall (excerpt):
{documents['concall'][:5000]}

Return ONLY valid JSON:
{{
    "is_turnaround": true,
    "confidence_score": 75,
    "key_indicators": ["reducing losses", "debt reduction"],
    "timeline": "medium-term",
    "risks": ["market competition"],
    "catalysts": ["new product launch"],
    "summary": "Company showing improvement in margins and reducing debt"
}}

JSON Response:"""

        response_text = self._query_ollama(prompt, max_tokens=1500)
        
        try:
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                analysis = json.loads(json_match.group())
            else:
                analysis = json.loads(response_text)
        except:
            analysis = {"error": "Parse error", "raw": response_text[:300]}
            
        return analysis
    
    def analyze_growth_profile(self, documents: Dict[str, str], metrics: Dict) -> Dict:
        """Analyze company's growth profile"""
        prompt = f"""You are a financial analyst. Analyze this company's GROWTH profile.

Growth indicators:
- Revenue growth >15% YoY
- Expanding margins
- Market share gains
- Product innovation
- Geographic expansion

Financial Metrics:
{json.dumps(metrics, indent=2)[:2000]}

Annual Report (excerpt):
{documents['annual_report'][:5000]}

Concall (excerpt):
{documents['concall'][:5000]}

Return ONLY valid JSON:
{{
    "is_growth_company": true,
    "growth_stage": "high-growth",
    "revenue_cagr_3y": 25.5,
    "profit_cagr_3y": 30.2,
    "growth_drivers": ["new product", "market expansion"],
    "sustainability_score": 80,
    "growth_risks": ["competition"],
    "summary": "Strong growth company with sustainable drivers"
}}

JSON Response:"""

        response_text = self._query_ollama(prompt, max_tokens=1500)
        
        try:
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                analysis = json.loads(json_match.group())
            else:
                analysis = json.loads(response_text)
        except:
            analysis = {"error": "Parse error", "raw": response_text[:300]}
            
        return analysis
    
    def analyze_moat_strength(self, documents: Dict[str, str], industry: str) -> Dict:
        """Analyze company's competitive moat"""
        prompt = f"""You are a financial analyst. Analyze this company's COMPETITIVE MOAT in {industry} industry.

Moat types: Brand, Network Effects, Cost Advantages, Switching Costs, IP/Regulatory, Technology

Annual Report (excerpt):
{documents['annual_report'][:6000]}

Concall (excerpt):
{documents['concall'][:5000]}

Return ONLY valid JSON:
{{
    "has_moat": true,
    "moat_strength": "wide",
    "moat_types": ["brand", "switching costs"],
    "moat_score": 85,
    "competitive_advantages": ["market leader", "brand recognition"],
    "threats_to_moat": ["new entrants"],
    "industry_position": "leader",
    "summary": "Strong moat with brand power and customer loyalty"
}}

JSON Response:"""

        response_text = self._query_ollama(prompt, max_tokens=1500)
        
        try:
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                analysis = json.loads(json_match.group())
            else:
                analysis = json.loads(response_text)
        except:
            analysis = {"error": "Parse error", "raw": response_text[:300]}
            
        return analysis
    
    def compare_rate_of_change(self, companies_data: List[Dict], industry: str) -> Dict:
        """Compare rate of change across companies in same industry"""
        
        # Prepare comparison data
        comparison_text = f"Industry: {industry}\n\n"
        for i, company in enumerate(companies_data):
            comparison_text += f"Company {i+1}: {company['name']}\n"
            comparison_text += f"Metrics: {json.dumps(company.get('metrics', {}), indent=2)[:500]}\n"
            comparison_text += f"Growth: {json.dumps(company.get('growth', {}), indent=2)[:300]}\n\n"
        
        prompt = f"""You are a financial analyst. Compare these {industry} companies by rate of change (momentum).

{comparison_text[:8000]}

Analyze: Revenue growth, profitability improvement, market share, efficiency

Return ONLY valid JSON:
{{
    "industry": "{industry}",
    "ranking": [
        {{
            "company": "Company A",
            "rank": 1,
            "change_score": 85,
            "momentum": "accelerating",
            "key_changes": ["revenue up 30%", "margin expansion"]
        }}
    ],
    "industry_insights": "Overall industry growing fast",
    "relative_performance": "Company A outpacing peers"
}}

JSON Response:"""

        response_text = self._query_ollama(prompt, max_tokens=2000)
        
        try:
            json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
            if json_match:
                comparison = json.loads(json_match.group())
            else:
                comparison = json.loads(response_text)
        except:
            comparison = {"error": "Parse error", "raw": response_text[:300]}
            
        return comparison
    
    def analyze_company(self, company_name: str, company_symbol: str, industry: str) -> Dict:
        """Complete analysis for a single company"""
        print(f"\n{'='*60}")
        print(f"Analyzing: {company_name} ({company_symbol})")
        print(f"{'='*60}")
        
        # Read documents
        print("Reading documents...")
        documents = self.read_documents(company_symbol)
        
        # Extract metrics
        print("Extracting financial metrics...")
        metrics = {}
        if documents['balance_sheet']:
            metrics = self.extract_financial_metrics(documents['balance_sheet'])
        
        # Turnaround analysis
        print("Analyzing turnaround potential...")
        turnaround = self.analyze_turnaround_potential(documents, metrics)
        
        # Growth analysis
        print("Analyzing growth profile...")
        growth = self.analyze_growth_profile(documents, metrics)
        
        # Moat analysis
        print("Analyzing competitive moat...")
        moat = self.analyze_moat_strength(documents, industry)
        
        return {
            'name': company_name,
            'industry': industry,
            'metrics': metrics,
            'turnaround': turnaround,
            'growth': growth,
            'moat': moat,
            'analyzed_at': datetime.now().isoformat()
        }
    
    def generate_report(self, results: List[Dict], output_file: str = 'analysis_report.json'):
        """Generate comprehensive analysis report"""
        report = {
            'generated_at': datetime.now().isoformat(),
            'total_companies': len(results),
            'companies': results,
            'summary': {
                'turnaround_candidates': [],
                'growth_companies': [],
                'moat_companies': []
            }
        }
        
        # Categorize companies
        for result in results:
            if result.get('turnaround', {}).get('is_turnaround'):
                report['summary']['turnaround_candidates'].append(result['name'])
            if result.get('growth', {}).get('is_growth_company'):
                report['summary']['growth_companies'].append(result['name'])
            if result.get('moat', {}).get('moat_strength') in ['wide', 'narrow']:
                report['summary']['moat_companies'].append(result['name'])
        
        # Save report
        with open(output_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\n{'='*60}")
        print(f"Report saved to: {output_file}")
        print(f"{'='*60}")
        print(f"Turnaround Candidates: {len(report['summary']['turnaround_candidates'])}")
        print(f"Growth Companies: {len(report['summary']['growth_companies'])}")
        print(f"Companies with Moat: {len(report['summary']['moat_companies'])}")
        
        return report
    
    def print_single_company_report(self, result: Dict):
        """Print detailed analysis report for a single company to console"""
        print(f"\n{'='*70}")
        print(f"DETAILED ANALYSIS REPORT".center(70))
        print(f"{'='*70}")
        
        print(f"\n📊 Company: {result['name']}")
        print(f"   Industry: {result['industry']}")
        print(f"   Analyzed: {result['analyzed_at']}")
        
        # Financial Metrics
        print(f"\n{'─'*70}")
        print("💰 FINANCIAL METRICS")
        print(f"{'─'*70}")
        
        if 'error' not in result.get('metrics', {}):
            metrics = result['metrics']
            if metrics:
                # Show latest year metrics
                years = sorted(metrics.keys(), reverse=True)
                if years:
                    latest_year = years[0]
                    print(f"\nLatest Year ({latest_year}):")
                    year_data = metrics[latest_year]
                    if isinstance(year_data, dict):
                        for key, value in year_data.items():
                            if value is not None:
                                print(f"   • {key.replace('_', ' ').title()}: {value}")
                
                # Show trend across years
                if len(years) > 1:
                    print(f"\nHistorical Trend ({years[-1]} → {years[0]}):")
                    print(f"   Years covered: {', '.join(years)}")
        else:
            print(f"   ⚠ Error extracting metrics: {result['metrics'].get('error', 'Unknown')}")
        
        # Turnaround Analysis
        print(f"\n{'─'*70}")
        print("🔄 TURNAROUND POTENTIAL")
        print(f"{'─'*70}")
        
        turnaround = result.get('turnaround', {})
        if 'error' not in turnaround:
            print(f"\n   Is Turnaround: {'✅ YES' if turnaround.get('is_turnaround') else '❌ NO'}")
            print(f"   Confidence: {turnaround.get('confidence_score', 0)}/100")
            print(f"   Timeline: {turnaround.get('timeline', 'N/A').title()}")
            
            if turnaround.get('key_indicators'):
                print(f"\n   Key Indicators:")
                for indicator in turnaround.get('key_indicators', [])[:5]:
                    print(f"      • {indicator}")
            
            if turnaround.get('catalysts'):
                print(f"\n   Catalysts:")
                for catalyst in turnaround.get('catalysts', [])[:5]:
                    print(f"      • {catalyst}")
            
            if turnaround.get('risks'):
                print(f"\n   Risks:")
                for risk in turnaround.get('risks', [])[:5]:
                    print(f"      • {risk}")
            
            if turnaround.get('summary'):
                print(f"\n   Summary: {turnaround.get('summary')}")
        else:
            print(f"   ⚠ Error: {turnaround.get('error', 'Unknown')}")
        
        # Growth Analysis
        print(f"\n{'─'*70}")
        print("📈 GROWTH PROFILE")
        print(f"{'─'*70}")
        
        growth = result.get('growth', {})
        if 'error' not in growth:
            print(f"\n   Is Growth Company: {'✅ YES' if growth.get('is_growth_company') else '❌ NO'}")
            print(f"   Growth Stage: {growth.get('growth_stage', 'N/A').title()}")
            
            if growth.get('revenue_cagr_3y') is not None:
                print(f"   Revenue CAGR (3Y): {growth.get('revenue_cagr_3y')}%")
            if growth.get('profit_cagr_3y') is not None:
                print(f"   Profit CAGR (3Y): {growth.get('profit_cagr_3y')}%")
            
            print(f"   Sustainability Score: {growth.get('sustainability_score', 0)}/100")
            
            if growth.get('growth_drivers'):
                print(f"\n   Growth Drivers:")
                for driver in growth.get('growth_drivers', [])[:5]:
                    print(f"      • {driver}")
            
            if growth.get('growth_risks'):
                print(f"\n   Growth Risks:")
                for risk in growth.get('growth_risks', [])[:5]:
                    print(f"      • {risk}")
            
            if growth.get('summary'):
                print(f"\n   Summary: {growth.get('summary')}")
        else:
            print(f"   ⚠ Error: {growth.get('error', 'Unknown')}")
        
        # Moat Analysis
        print(f"\n{'─'*70}")
        print("🏰 COMPETITIVE MOAT")
        print(f"{'─'*70}")
        
        moat = result.get('moat', {})
        if 'error' not in moat:
            print(f"\n   Has Moat: {'✅ YES' if moat.get('has_moat') else '❌ NO'}")
            print(f"   Moat Strength: {moat.get('moat_strength', 'N/A').upper()}")
            print(f"   Moat Score: {moat.get('moat_score', 0)}/100")
            print(f"   Industry Position: {moat.get('industry_position', 'N/A').title()}")
            
            if moat.get('moat_types'):
                print(f"\n   Moat Types:")
                for mtype in moat.get('moat_types', []):
                    print(f"      • {mtype.title()}")
            
            if moat.get('competitive_advantages'):
                print(f"\n   Competitive Advantages:")
                for advantage in moat.get('competitive_advantages', [])[:5]:
                    print(f"      • {advantage}")
            
            if moat.get('threats_to_moat'):
                print(f"\n   Threats to Moat:")
                for threat in moat.get('threats_to_moat', [])[:5]:
                    print(f"      • {threat}")
            
            if moat.get('summary'):
                print(f"\n   Summary: {moat.get('summary')}")
        else:
            print(f"   ⚠ Error: {moat.get('error', 'Unknown')}")
        
        # Final Summary
        print(f"\n{'='*70}")
        print("📋 INVESTMENT SUMMARY")
        print(f"{'='*70}")
        
        summary_items = []
        if turnaround.get('is_turnaround'):
            summary_items.append("✅ Turnaround Candidate")
        if growth.get('is_growth_company'):
            summary_items.append("✅ Growth Company")
        if moat.get('moat_strength') in ['wide', 'narrow']:
            summary_items.append(f"✅ Has {moat.get('moat_strength', '').title()} Moat")
        
        if summary_items:
            print("\n" + "\n".join(f"   {item}" for item in summary_items))
        else:
            print("\n   ⚠ No strong investment characteristics identified")
        
        print(f"\n{'='*70}\n")


def interactive_menu():
    """Interactive console menu for analyzer"""
    import sys
    
    # Fix Windows console encoding
    if sys.platform == 'win32':
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except:
            pass
    
    print("="*70)
    print("Stock Fundamental Analyzer (Ollama - FREE Local LLM)".center(70))
    print("="*70)
    
    # Configuration
    MODEL = "llama3"  # or "mistral", "phi", "gemma", etc.
    DOWNLOADS_DIR = "downloads"
    
    # Initialize analyzer
    print("\n🔄 Initializing analyzer...")
    analyzer = StockFundamentalAnalyzer(model=MODEL, downloads_dir=DOWNLOADS_DIR)
    
    while True:
        print("\n" + "="*70)
        print("MAIN MENU")
        print("="*70)
        print("\n1. 🔍 Analyze Single Company (Detailed Console Output)")
        print("2. 📊 Scan Multiple Companies (Batch Mode)")
        print("3. ⚙️  Settings")
        print("4. ❌ Exit")
        
        choice = input("\nEnter your choice (1-4): ").strip()
        
        if choice == '1':
            # Single company analysis
            single_company_mode(analyzer)
        
        elif choice == '2':
            # Scan multiple companies
            scan_mode(analyzer)
        
        elif choice == '3':
            # Settings
            settings_menu(analyzer)
        
        elif choice == '4':
            print("\n👋 Thank you for using Stock Fundamental Analyzer!")
            print("="*70)
            break
        
        else:
            print("\n⚠️  Invalid choice. Please enter 1, 2, 3, or 4.")


def single_company_mode(analyzer):
    """Analyze a single company with detailed console output"""
    print("\n" + "="*70)
    print("SINGLE COMPANY ANALYSIS")
    print("="*70)
    
    # Get company details
    company_name = input("\nEnter company name (e.g., Reliance Industries): ").strip()
    if not company_name:
        print("⚠️  Company name cannot be empty.")
        return
    
    company_symbol = input("Enter stock symbol (e.g., RELIANCE): ").strip().upper()
    if not company_symbol:
        print("⚠️  Stock symbol cannot be empty.")
        return
    
    industry = input("Enter industry (e.g., Diversified, Technology): ").strip()
    if not industry:
        industry = "Unknown"
    
    # Confirm
    print(f"\n📋 Analyzing: {company_name} ({company_symbol}) - {industry}")
    confirm = input("Continue? (y/n): ").strip().lower()
    
    if confirm != 'y':
        print("❌ Analysis cancelled.")
        return
    
    # Analyze
    try:
        result = analyzer.analyze_company(company_name, company_symbol, industry)
        
        # Print detailed report to console
        analyzer.print_single_company_report(result)
        
        # Ask to save
        save = input("💾 Save detailed report to JSON? (y/n): ").strip().lower()
        if save == 'y':
            filename = f"{company_symbol}_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(filename, 'w') as f:
                json.dump(result, f, indent=2)
            print(f"✅ Report saved to: {filename}")
    
    except Exception as e:
        print(f"\n❌ Error analyzing {company_name}: {str(e)}")
        import traceback
        traceback.print_exc()


def scan_mode(analyzer):
    """Scan multiple companies in batch mode"""
    print("\n" + "="*70)
    print("BATCH SCAN MODE")
    print("="*70)
    
    print("\n📋 Enter companies to analyze (one per line)")
    print("   Format: CompanyName,SYMBOL,Industry")
    print("   Example: Reliance Industries,RELIANCE,Diversified")
    print("   (Enter blank line when done)")
    
    companies = []
    while True:
        line = input(f"\nCompany {len(companies)+1} (or press Enter to finish): ").strip()
        if not line:
            break
        
        parts = [p.strip() for p in line.split(',')]
        if len(parts) < 2:
            print("⚠️  Invalid format. Use: CompanyName,SYMBOL,Industry")
            continue
        
        company = {
            'name': parts[0],
            'symbol': parts[1].upper(),
            'industry': parts[2] if len(parts) > 2 else 'Unknown'
        }
        companies.append(company)
        print(f"   ✅ Added: {company['name']} ({company['symbol']})")
    
    if not companies:
        print("\n⚠️  No companies added. Returning to main menu.")
        return
    
    # Confirm
    print(f"\n📊 Ready to analyze {len(companies)} companies:")
    for i, c in enumerate(companies, 1):
        print(f"   {i}. {c['name']} ({c['symbol']}) - {c['industry']}")
    
    confirm = input("\nContinue? (y/n): ").strip().lower()
    if confirm != 'y':
        print("❌ Scan cancelled.")
        return
    
    # Analyze
    print(f"\n{'='*70}")
    print("STARTING BATCH ANALYSIS")
    print(f"{'='*70}")
    
    results = []
    for i, company in enumerate(companies, 1):
        print(f"\n[{i}/{len(companies)}] Analyzing {company['name']}...")
        try:
            result = analyzer.analyze_company(
                company['name'],
                company['symbol'],
                company['industry']
            )
            results.append(result)
            print(f"✅ Completed: {company['name']}")
        except Exception as e:
            print(f"❌ Error analyzing {company['name']}: {str(e)}")
    
    if not results:
        print("\n⚠️  No successful analyses. Returning to main menu.")
        return
    
    # Generate report
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = f"batch_analysis_{timestamp}.json"
    report = analyzer.generate_report(results, output_file=report_file)
    
    # Print summary
    print("\n" + "="*70)
    print("BATCH ANALYSIS SUMMARY")
    print("="*70)
    
    for company in results:
        print(f"\n📊 {company['name']} ({company.get('industry', 'Unknown')})")
        print(f"   Turnaround: {'✅ YES' if company['turnaround'].get('is_turnaround') else '❌ NO'}")
        print(f"   Growth: {'✅ YES' if company['growth'].get('is_growth_company') else '❌ NO'}")
        print(f"   Moat: {company['moat'].get('moat_strength', 'N/A').upper()}")
    
    # Compare companies in same industry
    industries = {}
    for r in results:
        ind = r.get('industry', 'Unknown')
        if ind not in industries:
            industries[ind] = []
        industries[ind].append(r)
    
    for industry, comps in industries.items():
        if len(comps) > 1:
            print(f"\n📈 Comparing {industry} companies...")
            try:
                comparison = analyzer.compare_rate_of_change(comps, industry)
                if 'ranking' in comparison:
                    print(f"\n   Rankings:")
                    for rank_item in comparison['ranking'][:5]:
                        print(f"      {rank_item.get('rank', '?')}. {rank_item.get('company', 'Unknown')}")
                        print(f"         Momentum: {rank_item.get('momentum', 'N/A')}")
            except Exception as e:
                print(f"   ⚠️  Comparison failed: {e}")


def settings_menu(analyzer):
    """Settings configuration menu"""
    print("\n" + "="*70)
    print("SETTINGS")
    print("="*70)
    
    print(f"\n   Current Model: {analyzer.model}")
    print(f"   Downloads Directory: {analyzer.downloads_dir}")
    print(f"   Ollama URL: {analyzer.ollama_url}")
    
    print("\n1. Change Model")
    print("2. Test Ollama Connection")
    print("3. Back to Main Menu")
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice == '1':
        print("\nAvailable models: llama3, mistral, phi, gemma")
        print("(Make sure model is downloaded: ollama pull <model>)")
        new_model = input("\nEnter model name: ").strip().lower()
        if new_model:
            analyzer.model = new_model
            print(f"✅ Model changed to: {new_model}")
            analyzer._check_ollama_connection()
    
    elif choice == '2':
        analyzer._check_ollama_connection()
    
    elif choice == '3':
        return
    
    else:
        print("⚠️  Invalid choice.")


# Main entry point
if __name__ == "__main__":
    try:
        interactive_menu()
    except KeyboardInterrupt:
        print("\n\n⚠️  Program interrupted by user.")
        print("👋 Thank you for using Stock Fundamental Analyzer!")
        print("="*70)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()