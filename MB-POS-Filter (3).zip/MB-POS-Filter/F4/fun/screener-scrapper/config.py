"""
Configuration file for the Screener.in Web Scraper

This file contains all the configurable settings for the scraper.
Modify these values according to your needs.
"""

# Base Configuration
BASE_URL = "https://www.screener.in"
OUTPUT_DIR = "output"

# Rate Limiting Settings
DEFAULT_DELAY_RANGE = (1, 3)  # (min_seconds, max_seconds)
ADVANCED_DELAY_RANGE = (1, 2)  # For advanced scraper

# Advanced Scraper Settings
MAX_WORKERS = 3  # Number of parallel workers
REQUEST_TIMEOUT = 30  # Request timeout in seconds
RETRY_ATTEMPTS = 3  # Number of retry attempts for failed requests

# Logging Configuration
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
LOG_FORMAT = "%(asctime)s - %(levelname)s - %(message)s"

# Data Processing Settings
# List of companies to scrape (leave empty to scrape all available)
CUSTOM_COMPANIES = [
    # 'RELIANCE',  # Reliance Industries
    # 'TCS',       # Tata Consultancy Services
    # 'HDFCBANK',  # HDFC Bank
    # 'INFY',      # Infosys
    # 'ICICIBANK', # ICICI Bank
    # 'SBIN',      # State Bank of India
    # 'BHARTIARTL', # Bharti Airtel
    # 'ITC',       # ITC Limited
    # 'KOTAKBANK', # Kotak Mahindra Bank
    # 'AXISBANK'   # Axis Bank
]

# Financial Metrics to Extract
# These are the metrics that will be extracted from each company page
EXTRACTED_METRICS = [
    'Market Cap',
    'Current Price', 
    'High / Low',
    'Stock P/E',
    'Book Value',
    'Dividend Yield',
    'ROCE',
    'ROE',
    'Face Value',
    'EPS',
    'Industry PE',
    '3Yrs PE',
    'Free Cash Flow 3Yrs',
    'Price to Cash Flow',
    'Price to Earning',
    'Price to book value',
    'Intrinsic Value',
    'OPM',
    'Enterprise Value',
    'PEG Ratio',
    'Earning Power',
    'Net block',
    'Price to Sales',
    'Int Coverage',
    'Asset Turnover'
]

# CSV Output Settings
CSV_ENCODING = 'utf-8'
INCLUDE_RAW_VALUES = True  # Include raw text values alongside numeric values
TIMESTAMP_FORMAT = "%Y%m%d_%H%M%S"

# User Agent Settings
USER_AGENTS = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
]

# Request Headers
DEFAULT_HEADERS = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Cache-Control': 'max-age=0',
}

# Error Handling Settings
MAX_RETRIES = 3
BACKOFF_FACTOR = 2  # Exponential backoff multiplier
RETRY_STATUS_CODES = [500, 502, 503, 504, 429]  # HTTP status codes to retry

# Data Validation Settings
MIN_VALID_METRICS = 5  # Minimum number of metrics that should be extracted for a successful scrape
VALID_PRICE_RANGE = (1, 100000)  # Valid range for stock prices
VALID_PE_RANGE = (0, 1000)  # Valid range for P/E ratios

# Debug Settings
DEBUG_MODE = False  # Set to True for detailed logging
SAVE_HTML_SNAPSHOTS = False  # Save HTML snapshots for debugging
HTML_SNAPSHOT_DIR = "debug_snapshots"

# Performance Settings
BATCH_SIZE = 10  # Number of companies to process in each batch
PROGRESS_UPDATE_INTERVAL = 5  # Update progress every N companies

# Output File Naming
OUTPUT_FILE_PREFIX = "screener_metrics"
SUMMARY_FILE_SUFFIX = "_summary.txt"

# Data Processing Options
REMOVE_DUPLICATES = True
SORT_BY_COLUMN = "company_name"  # Column to sort results by
FILTER_INVALID_DATA = True  # Remove rows with invalid/missing data

# Advanced Features
ENABLE_PARALLEL_PROCESSING = True
ENABLE_RETRY_LOGIC = True
ENABLE_RATE_LIMITING = True
ENABLE_DATA_VALIDATION = True

# Custom CSS Selectors (in case website structure changes)
CSS_SELECTORS = {
    'company_ratios': 'div.company-ratios',
    'ratio_items': 'li.flex.flex-space-between',
    'metric_name': 'span.name',
    'metric_value': 'span.nowrap.value',
    'company_name': 'h1.company-name',
    'sector': 'a.sector',
    'company_links': 'a[href*="/company/"]'
}

# Export Settings
EXPORT_FORMATS = ['csv']  # Future: ['csv', 'json', 'excel']
COMPRESS_OUTPUT = False  # Gzip compress output files
CREATE_BACKUP = True  # Create backup of previous output files 