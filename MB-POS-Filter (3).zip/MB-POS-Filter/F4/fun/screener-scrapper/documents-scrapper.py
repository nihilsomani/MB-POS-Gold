import pandas as pd
import requests
from bs4 import BeautifulSoup
import os
import time
from urllib.parse import urljoin, urlparse, parse_qs
import logging
import re
import json

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ScreenerScraper:
    def __init__(self, input_csv='input.csv', output_dir='downloads'):
        self.input_csv = input_csv
        self.output_dir = output_dir
        self.base_url = 'https://www.screener.in'
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Create output directories
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'annual_reports'), exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'concalls'), exist_ok=True)
    
    def get_company_page(self, symbol):
        """Fetch company page from screener.in"""
        url = f'{self.base_url}/company/{symbol}/'
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            return response.text
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching page for {symbol}: {e}")
            return None
    
    def find_section_by_heading(self, soup, heading_text):
        """Find a section in the page by its heading text"""
        # Search through the page content
        page_text = soup.get_text()
        
        # Find the position of the heading
        if heading_text.lower() not in page_text.lower():
            return None
        
        # Find all text nodes and their parent elements
        for element in soup.find_all(text=re.compile(heading_text, re.IGNORECASE)):
            parent = element.parent
            # Navigate up to find a container (usually h2, h3, or section)
            for _ in range(5):  # Look up to 5 levels
                if parent and parent.name in ['h2', 'h3', 'h4', 'section', 'div']:
                    # Found a potential section header
                    # Now find the next list or div with content
                    next_element = parent.find_next_sibling()
                    if not next_element:
                        parent = parent.parent
                        if parent:
                            next_element = parent.find_next_sibling()
                    
                    return next_element if next_element else parent
                parent = parent.parent if parent else None
        
        return None
    
    def parse_documents(self, html, symbol):
        """Parse the documents section and extract latest Annual Report and Concall (Enhanced)"""
        soup = BeautifulSoup(html, 'html.parser')
        
        documents = {
            'annual_report': None,
            'concall': None
        }
        
        # Method 1: Look for Annual Reports heading and section
        try:
            # Find the "Annual reports" section more reliably
            annual_heading = soup.find(string=re.compile(r'Annual reports', re.IGNORECASE))
            if annual_heading:
                # Get the parent container
                annual_section = annual_heading.find_parent()
                if annual_section:
                    # Look for next sibling or parent's next sibling
                    annual_container = annual_section.find_next_sibling()
                    if not annual_container:
                        annual_container = annual_section.find_parent().find_next_sibling()
                    
                    if annual_container:
                        # Find all links in this section
                        all_links = annual_container.find_all('a', href=True)
                        
                        for link in all_links:
                            href = link.get('href')
                            link_text = link.get_text(strip=True)
                            
                            # Check if it's a PDF link (various formats)
                            if any(indicator in href.lower() for indicator in ['.pdf', 'annpdf', 'annual', 'report']):
                                # Extract year from link text or href
                                year_match = re.search(r'(20\d{2})', link_text + ' ' + href)
                                year = year_match.group(1) if year_match else 'Latest'
                                
                                documents['annual_report'] = {
                                    'text': f"Annual Report {year}",
                                    'url': href if href.startswith('http') else urljoin(self.base_url, href),
                                    'source': 'bse' if 'bse' in href.lower() else 'screener'
                                }
                                logger.info(f"{symbol}: Found Annual Report - {year} (Source: {documents['annual_report']['source']})")
                                break
                        
                        if not documents['annual_report']:
                            logger.warning(f"{symbol}: Annual Reports section found but no valid links")
                    else:
                        logger.warning(f"{symbol}: Could not find Annual Reports container")
                else:
                    logger.warning(f"{symbol}: Could not find Annual Reports parent")
            else:
                logger.warning(f"{symbol}: No Annual Reports heading found")
        except Exception as e:
            logger.error(f"{symbol}: Error parsing Annual Reports - {e}")
        
        # Method 2: Look for Concalls section (Enhanced v2)
        try:
            concall_heading = soup.find(string=re.compile(r'Concalls', re.IGNORECASE))
            if concall_heading:
                # Structure: <div class="documents concalls">
                #              <div class="flex..."><h3>Concalls</h3></div>
                #              <div class="show-more-box"><ul class="list-links">...</ul></div>
                #            </div>
                
                concall_container = None
                
                # Method 1: Try to find parent with class "concalls" or "documents"
                concall_root = concall_heading.find_parent('div', class_=re.compile(r'concalls|documents'))
                
                if concall_root:
                    # Now find the ul.list-links anywhere inside this root
                    ul_list = concall_root.find('ul', class_=re.compile(r'list-links'))
                    if ul_list:
                        concall_container = ul_list
                    else:
                        # Fallback: just use the root and search for all links
                        concall_container = concall_root
                else:
                    # Fallback method: navigate from h3
                    concall_section = concall_heading.find_parent()
                    if concall_section:
                        # Try going up one level (h3 -> flex div)
                        parent_div = concall_section.find_parent()
                        if parent_div:
                            # Find next sibling (show-more-box)
                            concall_container = parent_div.find_next_sibling()
                            if concall_container:
                                # Look for ul.list-links inside
                                ul_list = concall_container.find('ul', class_=re.compile(r'list-links'))
                                if ul_list:
                                    concall_container = ul_list
                
                if concall_container:
                        # Find all links in concalls section
                        all_links = concall_container.find_all('a', href=True)
                        logger.debug(f"{symbol}: Found {len(all_links)} links in concalls container")
                        
                        # Strategy 1: Look for "Transcript" links (highest priority)
                        transcript_link = None
                        for link in all_links:
                            link_text = link.get_text(strip=True).lower()
                            if 'transcript' in link_text:
                                transcript_link = link
                                logger.debug(f"{symbol}: Found transcript link via Strategy 1")
                                break
                        
                        # Strategy 2: If no transcript, look for any PDF link in first concall item
                        if not transcript_link:
                            logger.debug(f"{symbol}: Strategy 1 failed, trying Strategy 2 (PDF links)")
                            for link in all_links:
                                href = link.get('href')
                                # Check if link points to a PDF
                                if any(indicator in href.lower() for indicator in ['.pdf', 'attachhis', 'corpfiling']):
                                    transcript_link = link
                                    logger.debug(f"{symbol}: Found PDF link via Strategy 2")
                                    break
                        
                        # Strategy 3: If still nothing, take the first link (might be API endpoint)
                        if not transcript_link and all_links:
                            logger.debug(f"{symbol}: Strategy 2 failed, trying Strategy 3 (document links)")
                            # Only take links that look like they could be documents
                            for link in all_links[:5]:  # Check first 5 links only
                                href = link.get('href')
                                link_text = link.get_text(strip=True).lower()
                                # Skip navigation links like "add missing"
                                if any(skip in link_text for skip in ['add', 'missing', 'more', 'show']):
                                    continue
                                # Accept links that might be documents
                                if any(accept in link_text for accept in ['notes', 'ppt', 'rec', '2024', '2025']) or \
                                   any(accept in href.lower() for accept in ['api', 'download', 'pdf', 'bse']):
                                    transcript_link = link
                                    logger.debug(f"{symbol}: Found document link via Strategy 3")
                                    break
                        
                        if transcript_link:
                            href = transcript_link.get('href')
                            link_text = transcript_link.get_text(strip=True)
                            
                            # Try to find the period/date from nearby text or parent
                            parent = transcript_link.find_parent('li') or transcript_link.find_parent('div')
                            period = 'Latest'
                            
                            if parent:
                                parent_text = parent.get_text(strip=True)
                                # Extract month/year pattern
                                period_match = re.search(r'(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s*(20\d{2})', parent_text)
                                if period_match:
                                    period = period_match.group(0)
                                else:
                                    # Try to extract just year
                                    year_match = re.search(r'(20\d{2})', parent_text)
                                    if year_match:
                                        period = year_match.group(1)
                            
                            # Make full URL
                            full_url = href if href.startswith('http') else urljoin(self.base_url, href)
                            
                            documents['concall'] = {
                                'text': f"Concall Transcript {period}",
                                'url': full_url,
                                'source': 'bse' if 'bse' in href.lower() else 'screener'
                            }
                            logger.info(f"{symbol}: Found Concall - {period} (Source: {documents['concall']['source']}) - Link text: '{link_text[:50]}'")
                        else:
                            logger.warning(f"{symbol}: Concalls section found but no valid links detected (checked {len(all_links)} links)")
                else:
                    logger.warning(f"{symbol}: Could not find Concalls container")
            else:
                logger.warning(f"{symbol}: No Concalls heading found")
        except Exception as e:
            logger.error(f"{symbol}: Error parsing Concalls - {e}")
            import traceback
            logger.debug(traceback.format_exc())
        
        return documents
    
    def download_pdf(self, url, output_path, source='screener'):
        """Download PDF file with enhanced handling for BSE, screener.in API and external links"""
        try:
            # Special handling for different sources
            if 'bseindia.com' in url.lower():
                logger.info(f"   Downloading from BSE India...")
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'application/pdf,*/*',
                    'Referer': 'https://www.bseindia.com/'
                }
                response = self.session.get(url, headers=headers, timeout=60, stream=True, allow_redirects=True)
            
            elif 'screener.in/api' in url.lower() or '/api/' in url.lower():
                # Screener.in API endpoints
                logger.info(f"   Downloading from Screener.in API...")
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'application/pdf,*/*',
                    'Referer': 'https://www.screener.in/'
                }
                response = self.session.get(url, headers=headers, timeout=60, stream=True, allow_redirects=True)
            
            else:
                # Standard download
                logger.info(f"   Downloading...")
                response = self.session.get(url, timeout=60, stream=True, allow_redirects=True)
            
            response.raise_for_status()
            
            # Check if response is actually a PDF
            content_type = response.headers.get('Content-Type', '').lower()
            
            # Get content (handle streaming vs non-streaming)
            if hasattr(response, 'iter_content'):
                content = b''.join(chunk for chunk in response.iter_content(chunk_size=8192) if chunk)
            else:
                content = response.content
            
            # Verify it's a PDF
            if len(content) < 4:
                logger.warning(f"   Response is too small ({len(content)} bytes)")
                return False
            
            first_bytes = content[:4]
            if first_bytes != b'%PDF':
                # Check content-type as fallback
                if 'pdf' not in content_type and 'octet-stream' not in content_type:
                    logger.warning(f"   Response doesn't appear to be a PDF (Content-Type: {content_type}, First bytes: {first_bytes})")
                    # Check if it's HTML error page
                    if b'<html' in content[:100].lower() or b'<!doctype' in content[:100].lower():
                        logger.error(f"   Received HTML instead of PDF (likely error page)")
                        return False
                    # Try to save anyway
                    logger.info(f"   Attempting to save despite warning...")
            
            # Save the file
            with open(output_path, 'wb') as f:
                f.write(content)
            
            # Verify file size
            file_size = os.path.getsize(output_path)
            if file_size < 1024:  # Less than 1KB, probably not a real PDF
                logger.warning(f"   Downloaded file is very small ({file_size} bytes), likely invalid")
                # Delete the invalid file
                os.remove(output_path)
                return False
            
            logger.info(f"   ✅ Downloaded: {os.path.basename(output_path)} ({file_size / 1024:.1f} KB)")
            return True
            
        except requests.exceptions.HTTPError as e:
            logger.error(f"   ❌ HTTP Error {e.response.status_code}: {url[:80]}...")
            return False
        except requests.exceptions.Timeout:
            logger.error(f"   ❌ Timeout downloading: {url[:80]}...")
            return False
        except requests.exceptions.RequestException as e:
            logger.error(f"   ❌ Request error: {str(e)[:100]}")
            return False
        except Exception as e:
            logger.error(f"   ❌ Error downloading: {str(e)[:100]}")
            return False
    
    def process_symbol(self, symbol):
        """Process a single company symbol (Enhanced)"""
        logger.info(f"\n{'='*60}")
        logger.info(f"Processing: {symbol}")
        logger.info(f"{'='*60}")
        
        # Get company page
        html = self.get_company_page(symbol)
        if not html:
            logger.error(f"{symbol}: Failed to fetch company page")
            return False
        
        # Parse documents
        documents = self.parse_documents(html, symbol)
        
        downloaded_count = 0
        
        # Download Annual Report
        if documents['annual_report']:
            logger.info(f"\n📄 Annual Report:")
            logger.info(f"   Year: {documents['annual_report']['text']}")
            logger.info(f"   URL: {documents['annual_report']['url'][:80]}...")
            
            filename = f"{symbol}_Annual_Report.pdf"
            output_path = os.path.join(self.output_dir, 'annual_reports', filename)
            
            if self.download_pdf(
                documents['annual_report']['url'], 
                output_path, 
                source=documents['annual_report'].get('source', 'screener')
            ):
                downloaded_count += 1
        else:
            logger.info(f"\n📄 Annual Report: Not found")
        
        # Download Concall
        if documents['concall']:
            logger.info(f"\n📞 Conference Call:")
            logger.info(f"   Period: {documents['concall']['text']}")
            logger.info(f"   URL: {documents['concall']['url'][:80]}...")
            
            filename = f"{symbol}_Concall.pdf"
            output_path = os.path.join(self.output_dir, 'concalls', filename)
            
            if self.download_pdf(
                documents['concall']['url'], 
                output_path,
                source=documents['concall'].get('source', 'screener')
            ):
                downloaded_count += 1
        else:
            logger.info(f"\n📞 Conference Call: Not found")
        
        # Summary
        logger.info(f"\n✅ {symbol}: Downloaded {downloaded_count}/2 documents")
        
        # Be respectful to the server
        time.sleep(2)
        return downloaded_count > 0
    
    def run(self):
        """Main execution method (Enhanced)"""
        try:
            logger.info("\n" + "="*60)
            logger.info("ENHANCED DOCUMENT SCRAPER")
            logger.info("="*60)
            
            # Read input CSV
            df = pd.read_csv(self.input_csv)
            
            if 'Symbol' not in df.columns:
                logger.error("CSV must contain a 'Symbol' column")
                return
            
            symbols = df['Symbol'].dropna().unique()
            logger.info(f"\n✅ Loaded {len(symbols)} symbols from {self.input_csv}")
            logger.info(f"📁 Output directory: {self.output_dir}")
            
            # Track statistics
            total_symbols = len(symbols)
            successful = 0
            failed = 0
            total_docs_downloaded = 0
            
            # Process each symbol
            for idx, symbol in enumerate(symbols, 1):
                logger.info(f"\n[{idx}/{len(symbols)}] {symbol}")
                
                result = self.process_symbol(symbol)
                
                if result:
                    successful += 1
                else:
                    failed += 1
            
            # Count downloaded files
            concalls_count = len([f for f in os.listdir(os.path.join(self.output_dir, 'concalls')) if f.endswith('.pdf')]) if os.path.exists(os.path.join(self.output_dir, 'concalls')) else 0
            reports_count = len([f for f in os.listdir(os.path.join(self.output_dir, 'annual_reports')) if f.endswith('.pdf')]) if os.path.exists(os.path.join(self.output_dir, 'annual_reports')) else 0
            
            # Final summary
            logger.info("\n" + "="*60)
            logger.info("✅ SCRAPING COMPLETED!")
            logger.info("="*60)
            logger.info(f"\n📊 Summary:")
            logger.info(f"   Total symbols processed: {total_symbols}")
            logger.info(f"   Successful: {successful}")
            logger.info(f"   Failed: {failed}")
            logger.info(f"   Success rate: {successful/total_symbols*100:.1f}%")
            logger.info(f"\n📁 Documents Downloaded:")
            logger.info(f"   Conference Calls: {concalls_count}")
            logger.info(f"   Annual Reports: {reports_count}")
            logger.info(f"   Total: {concalls_count + reports_count}")
            logger.info(f"\n💾 Files saved to:")
            logger.info(f"   {os.path.abspath(self.output_dir)}")
            logger.info("="*60)
            
        except FileNotFoundError:
            logger.error(f"Input file '{self.input_csv}' not found")
        except Exception as e:
            logger.error(f"Error during execution: {e}")
            import traceback
            traceback.print_exc()

if __name__ == '__main__':
    # Create input.csv example if it doesn't exist
    if not os.path.exists('input.csv'):
        example_df = pd.DataFrame({
            'Symbol': ['LLOYDSME','NPST','AVANTEL','WAAREEENER','VADILALIND','SOLARINDS','INDRAMEDCO','ANANDRATHI','PIIND','JSLL','PRUDENT','TATAELXSI','PAGEIND','DOMS','JBCHEPHARM','HBLENGINE','HYUNDAI','MRPL','BIKAJI','JYOTHYLAB','RPGLIFE','ABBOTINDIA','ESABINDIA','SHRIPISTON','TRENT','MM','ASIANPAINT','SUPREMEIND','3MINDIA','CUMMINSIND','FORCEMOT','DRREDDY','GUJTHEM','MEDANTA','PREMEXPLN','STYLAMIND','TORNTPHARM','EICHERMOT','SAFARI','BECTORFOOD','FCL','BRITANNIA','CMSINFO','KKCL','ECLERX','ELECON','INGERRAND','CGPOWER','NEWGEN','TCS','AUTOAXLES','LTTS','EMAMILTD','JINDALSAW','RKFORGE','ROLEXRINGS','UNOMINDA','VENUSPIPES','AJANTPHARM','CAMS','SHARDAMOTR','SONACOMS','SWARAJENG','HAPPYFORGE','MANYAVAR','SBCL','KFINTECH','MSUMI','SKFINDIA','AKZOINDIA','NEULANDLAB','ACI','AEGISLOG','LTIM','CHAMBLFERT','GALLANTT','JAIBALAJI','CIPLA','CARBORUNIV','USHAMART','BERGEPAINT','JSL','LALPATHLAB','POLYMED','RPEL','BAYERCROP','INDIGOPNTS','JKTYRE','TI','HCLTECH','KPITTECH','MRF','LUPIN','NUCLEUS','CHENNPETRO','CAMPUS','GHCL','QPOWER','SUMICHEM','BANCOINDIA','DBCORP','KEI','PNCINFRA','TIPSMUSIC','ZENSARTECH','IRCTC','OLECTRA','PIDILITIND','TVSMOTOR','KSCL','AGI','DHANUKA','LGBBROSLTD','MAHSEAMLES','NDRAUTO']
        })
        example_df.to_csv('input.csv', index=False)
        logger.info("Created example input.csv with sample symbols")
    
    # Run scraper
    scraper = ScreenerScraper(input_csv='input.csv', output_dir='downloads')
    scraper.run()