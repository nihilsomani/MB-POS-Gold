import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import re
import logging
from typing import Dict, List, Optional, Tuple, Any
import json
from urllib.parse import urljoin, urlparse
import random
from datetime import datetime
import os
import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from robust_csv_saver import RobustCSVSaver

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('enhanced_robust_scraper.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class EnhancedRobustScraper:
    """
    Enhanced robust web scraper for screener.in with proper JSON handling
    """
    
    def __init__(self, 
                 base_url: str = "https://www.screener.in", 
                 delay_range: Tuple[int, int] = (1, 3),
                 max_workers: int = 3,
                 timeout: int = 30,
                 retry_attempts: int = 3):
        """
        Initialize the enhanced robust scraper
        
        Args:
            base_url: Base URL for screener.in
            delay_range: Range of seconds to delay between requests (min, max)
            max_workers: Maximum number of concurrent workers
            timeout: Request timeout in seconds
            retry_attempts: Number of retry attempts for failed requests
        """
        self.base_url = base_url
        self.delay_range = delay_range
        self.max_workers = max_workers
        self.timeout = timeout
        self.retry_attempts = retry_attempts
        
        # Thread-local session for each worker
        self.session_local = threading.local()
        
        # Rate limiting
        self.request_lock = threading.Lock()
        self.last_request_time = 0
        
        # Robust CSV saver
        self.csv_saver = RobustCSVSaver()
        
        # Financial metrics mapping
        self.metrics_mapping = {
            'Market Cap': 'market_cap',
            'Current Price': 'current_price',
            'High / Low': 'high_low',
            'Stock P/E': 'pe_ratio',
            'Book Value': 'book_value',
            'Dividend Yield': 'dividend_yield',
            'ROCE': 'roce',
            'ROE': 'roe',
            'Face Value': 'face_value',
            'EPS': 'eps',
            'Industry PE': 'industry_pe',
            '3Yrs PE': 'pe_3yrs',
            'Free Cash Flow 3Yrs': 'fcf_3yrs',
            'Price to Cash Flow': 'price_to_cash_flow',
            'Price to Earning': 'price_to_earning',
            'Price to book value': 'price_to_book',
            'Intrinsic Value': 'intrinsic_value',
            'OPM': 'opm',
            'Enterprise Value': 'enterprise_value',
            'PEG Ratio': 'peg_ratio',
            'Earning Power': 'earning_power',
            'Net block': 'net_block',
            'Price to Sales': 'price_to_sales',
            'Int Coverage': 'interest_coverage',
            'Asset Turnover': 'asset_turnover'
        }
        
    def _get_session(self):
        """Get thread-local session"""
        if not hasattr(self.session_local, 'session'):
            session = requests.Session()
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
            })
            self.session_local.session = session
        return self.session_local.session
    
    def _rate_limit(self):
        """Implement rate limiting"""
        with self.request_lock:
            current_time = time.time()
            time_since_last = current_time - self.last_request_time
            min_delay = self.delay_range[0]
            
            if time_since_last < min_delay:
                time.sleep(min_delay - time_since_last)
            
            self.last_request_time = time.time()
    
    def _delay(self):
        """Random delay between requests"""
        delay = random.uniform(*self.delay_range)
        time.sleep(delay)
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize text"""
        if not text:
            return ""
        
        # Remove extra whitespace and normalize
        text = re.sub(r'\s+', ' ', text.strip())
        
        # Remove special characters that might cause CSV issues
        text = re.sub(r'[^\w\s\-\.\,\%\₹\(\)]', '', text)
        
        return text
    
    def _extract_number(self, text: str) -> Optional[float]:
        """Extract numeric value from text"""
        if not text:
            return None
        
        # Remove currency symbols and other non-numeric characters
        cleaned = re.sub(r'[^\d\.\-]', '', text)
        
        try:
            return float(cleaned) if cleaned else None
        except ValueError:
            return None
    
    def _extract_high_low(self, text: str) -> Tuple[Optional[float], Optional[float]]:
        """Extract high and low values from text like '₹ 469 / 217'"""
        if not text:
            return None, None
        
        # Extract numbers from text like "₹ 469 / 217"
        numbers = re.findall(r'[\d,]+', text)
        if len(numbers) >= 2:
            try:
                high = float(numbers[0].replace(',', ''))
                low = float(numbers[1].replace(',', ''))
                return high, low
            except ValueError:
                pass
        
        return None, None
    
    def _get_page_with_retry(self, url: str) -> Optional[BeautifulSoup]:
        """Get page content with retry logic"""
        session = self._get_session()
        
        for attempt in range(self.retry_attempts):
            try:
                self._rate_limit()
                
                response = session.get(url, timeout=self.timeout)
                response.raise_for_status()
                
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Verify we got a valid page
                if soup.find('title') and 'screener.in' in soup.find('title').get_text():
                    return soup
                else:
                    logger.warning(f"Invalid page content from {url}")
                    
            except requests.RequestException as e:
                logger.warning(f"Request failed (attempt {attempt + 1}/{self.retry_attempts}): {e}")
                if attempt < self.retry_attempts - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                    
            except Exception as e:
                logger.error(f"Unexpected error fetching {url}: {e}")
                break
        
        return None
    
    def extract_company_metrics(self, company_url: str) -> Dict[str, Any]:
        """
        Extract financial metrics from a company page with enhanced error handling
        
        Args:
            company_url: URL of the company page
            
        Returns:
            Dictionary containing extracted metrics
        """
        soup = self._get_page_with_retry(company_url)
        if not soup:
            return {
                'company_url': company_url,
                'scraped_at': datetime.now().isoformat(),
                'status': 'failed_to_load_page'
            }
            
        metrics = {
            'company_url': company_url,
            'scraped_at': datetime.now().isoformat(),
            'status': 'success'
        }
        
        try:
            # Extract company name
            company_name_elem = soup.find('h1', class_='company-name')
            if company_name_elem:
                metrics['company_name'] = self._clean_text(company_name_elem.get_text())
                
            # Extract sector
            sector_elem = soup.find('a', class_='sector')
            if sector_elem:
                metrics['sector'] = self._clean_text(sector_elem.get_text())
                
            # Find the company ratios section
            ratios_section = soup.find('div', class_='company-ratios')
            if not ratios_section:
                logger.warning(f"No company ratios section found on {company_url}")
                metrics['status'] = 'no_ratios_found'
                return metrics
                
            # Find all ratio items
            ratio_items = ratios_section.find_all('li', class_='flex flex-space-between')
            
            extracted_metrics = 0
            for item in ratio_items:
                name_span = item.find('span', class_='name')
                value_span = item.find('span', class_='nowrap value')
                
                if not name_span or not value_span:
                    continue
                    
                metric_name = self._clean_text(name_span.get_text())
                metric_value = self._clean_text(value_span.get_text())
                
                if not metric_name:
                    continue
                    
                # Extract numeric value
                numeric_value = self._extract_number(metric_value)
                
                # Handle special cases
                if metric_name == 'High / Low':
                    high, low = self._extract_high_low(metric_value)
                    metrics['high_price'] = high
                    metrics['low_price'] = low
                    metrics['high_low_raw'] = metric_value
                else:
                    # Use standardized column names
                    clean_name = self.metrics_mapping.get(metric_name, metric_name.lower().replace(' ', '_'))
                    metrics[clean_name] = numeric_value
                    metrics[f'{clean_name}_raw'] = metric_value
                    
                extracted_metrics += 1
                
            metrics['metrics_extracted'] = extracted_metrics
            
            # Extract quarterly data with enhanced error handling
            quarterly_data = self._extract_quarterly_data(soup)
            if quarterly_data and quarterly_data.get('data'):
                metrics['quarterly_data'] = quarterly_data
                metrics['has_quarterly_data'] = True
            else:
                metrics['has_quarterly_data'] = False
                metrics['quarterly_data'] = {}
            
            # Extract profit & loss data with enhanced error handling
            pnl_data = self._extract_profit_loss_data(soup)
            if pnl_data and pnl_data.get('data'):
                metrics['pnl_data'] = pnl_data
                metrics['has_pnl_data'] = True
            else:
                metrics['has_pnl_data'] = False
                metrics['pnl_data'] = {}
            
            # Extract balance sheet data with enhanced error handling
            balance_sheet_data = self._extract_balance_sheet_data(soup)
            if balance_sheet_data and balance_sheet_data.get('data'):
                metrics['balance_sheet_data'] = balance_sheet_data
                metrics['has_balance_sheet_data'] = True
            else:
                metrics['has_balance_sheet_data'] = False
                metrics['balance_sheet_data'] = {}
            
            # Extract additional information if available
            self._extract_additional_info(soup, metrics)
            
        except Exception as e:
            logger.error(f"Error processing {company_url}: {e}")
            metrics['status'] = 'processing_error'
            metrics['error'] = str(e)
            
        return metrics
    
    def _extract_quarterly_data(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """
        Extract quarterly financial data with enhanced error handling
        """
        quarterly_data = {}
        
        try:
            # Find the quarters section
            quarters_section = soup.find('section', id='quarters')
            if not quarters_section:
                logger.debug("No quarters section found")
                return {}
                
            # Find the quarterly results table
            table = quarters_section.find('table', class_='data-table')
            if not table:
                logger.debug("No quarterly data table found")
                return {}
                
            # Extract column headers (quarters)
            headers = []
            header_row = table.find('thead').find('tr')
            if header_row:
                header_cells = header_row.find_all('th')
                for cell in header_cells:
                    header_text = self._clean_text(cell.get_text())
                    if header_text and header_text != '':
                        headers.append(header_text)
            
            # Extract data rows
            data_rows = []
            tbody = table.find('tbody')
            if tbody:
                rows = tbody.find_all('tr')
                for row in rows:
                    # Skip the PDF links row
                    if 'font-size-14' in row.get('class', []):
                        continue
                        
                    cells = row.find_all(['td', 'th'])
                    if len(cells) > 1:  # Must have at least metric name and one value
                        metric_name = self._clean_text(cells[0].get_text())
                        if metric_name and metric_name != 'Raw PDF':
                            row_data = {'metric': metric_name}
                            
                            # Extract values for each quarter
                            for i, cell in enumerate(cells[1:], 1):
                                if i <= len(headers):
                                    quarter = headers[i-1]
                                    value_text = self._clean_text(cell.get_text())
                                    numeric_value = self._extract_number(value_text)
                                    row_data[quarter] = numeric_value
                                    row_data[f'{quarter}_raw'] = value_text
                            
                            data_rows.append(row_data)
            
            quarterly_data = {
                'quarters': headers,
                'data': data_rows,
                'total_quarters': len(headers),
                'total_metrics': len(data_rows)
            }
            
            # Extract upcoming result date if available
            upcoming_elem = quarters_section.find('span', class_='badge')
            if upcoming_elem:
                upcoming_text = self._clean_text(upcoming_elem.get_text())
                if 'Upcoming result date:' in upcoming_text:
                    date_match = re.search(r'(\d{1,2}\s+\w+\s+\d{4})', upcoming_text)
                    if date_match:
                        quarterly_data['upcoming_result_date'] = date_match.group(1)
            
            logger.info(f"Extracted quarterly data: {len(headers)} quarters, {len(data_rows)} metrics")
            return quarterly_data
            
        except Exception as e:
            logger.error(f"Error extracting quarterly data: {e}")
            return {}
    
    def _extract_profit_loss_data(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """
        Extract year-wise Profit & Loss data with enhanced error handling
        """
        pnl_data = {}
        
        try:
            # Find the profit-loss section
            pnl_section = soup.find('section', id='profit-loss')
            if not pnl_section:
                logger.debug("No profit-loss section found")
                return {}
                
            # Find the P&L data table
            table = pnl_section.find('table', class_='data-table')
            if not table:
                logger.debug("No P&L data table found")
                return {}
                
            # Extract column headers (years)
            headers = []
            header_row = table.find('thead').find('tr')
            if header_row:
                header_cells = header_row.find_all('th')
                for cell in header_cells:
                    header_text = self._clean_text(cell.get_text())
                    if header_text and header_text != '':
                        headers.append(header_text)
            
            # Extract data rows
            data_rows = []
            tbody = table.find('tbody')
            if tbody:
                rows = tbody.find_all('tr')
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) > 1:  # Must have at least metric name and one value
                        metric_name = self._clean_text(cells[0].get_text())
                        if metric_name and metric_name != '':
                            row_data = {'metric': metric_name}
                            
                            # Extract values for each year
                            for i, cell in enumerate(cells[1:], 1):
                                if i <= len(headers):
                                    year = headers[i-1]
                                    value_text = self._clean_text(cell.get_text())
                                    numeric_value = self._extract_number(value_text)
                                    row_data[year] = numeric_value
                                    row_data[f'{year}_raw'] = value_text
                            
                            data_rows.append(row_data)
            
            pnl_data = {
                'years': headers,
                'data': data_rows,
                'total_years': len(headers),
                'total_metrics': len(data_rows)
            }
            
            # Extract growth metrics if available
            growth_tables = pnl_section.find_all('table', class_='ranges-table')
            growth_metrics = {}
            
            for table in growth_tables:
                rows = table.find_all('tr')
                if rows:
                    # Get table title
                    title_cell = rows[0].find('th')
                    if title_cell:
                        title = self._clean_text(title_cell.get_text())
                        
                        # Extract growth data
                        growth_data = {}
                        for row in rows[1:]:  # Skip header row
                            cells = row.find_all(['td', 'th'])
                            if len(cells) >= 2:
                                period = self._clean_text(cells[0].get_text())
                                value = self._clean_text(cells[1].get_text())
                                growth_data[period] = value
                        
                        growth_metrics[title] = growth_data
            
            pnl_data['growth_metrics'] = growth_metrics
            
            logger.info(f"Extracted P&L data: {len(headers)} years, {len(data_rows)} metrics")
            return pnl_data
            
        except Exception as e:
            logger.error(f"Error extracting P&L data: {e}")
            return {}
    
    def _extract_balance_sheet_data(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """
        Extract year-wise Balance Sheet data with enhanced error handling
        """
        balance_sheet_data = {}
        
        try:
            # Find the balance-sheet section
            balance_sheet_section = soup.find('section', id='balance-sheet')
            if not balance_sheet_section:
                logger.debug("No balance-sheet section found")
                return {}
                
            # Find the Balance Sheet data table
            table = balance_sheet_section.find('table', class_='data-table')
            if not table:
                logger.debug("No Balance Sheet data table found")
                return {}
                
            # Extract column headers (years)
            headers = []
            header_row = table.find('thead').find('tr')
            if header_row:
                header_cells = header_row.find_all('th')
                for cell in header_cells:
                    header_text = self._clean_text(cell.get_text())
                    if header_text and header_text != '':
                        headers.append(header_text)
            
            # Extract data rows
            data_rows = []
            tbody = table.find('tbody')
            if tbody:
                rows = tbody.find_all('tr')
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    if len(cells) > 1:  # Must have at least metric name and one value
                        metric_name = self._clean_text(cells[0].get_text())
                        if metric_name and metric_name != '':
                            row_data = {'metric': metric_name}
                            
                            # Extract values for each year
                            for i, cell in enumerate(cells[1:], 1):
                                if i <= len(headers):
                                    year = headers[i-1]
                                    value_text = self._clean_text(cell.get_text())
                                    numeric_value = self._extract_number(value_text)
                                    row_data[year] = numeric_value
                                    row_data[f'{year}_raw'] = value_text
                            
                            data_rows.append(row_data)
            
            balance_sheet_data = {
                'years': headers,
                'data': data_rows,
                'total_years': len(headers),
                'total_metrics': len(data_rows)
            }
            
            # Extract growth metrics if available
            growth_tables = balance_sheet_section.find_all('table', class_='ranges-table')
            growth_metrics = {}
            
            for table in growth_tables:
                rows = table.find_all('tr')
                if rows:
                    # Get table title
                    title_cell = rows[0].find('th')
                    if title_cell:
                        title = self._clean_text(title_cell.get_text())
                        
                        # Extract growth data
                        growth_data = {}
                        for row in rows[1:]:  # Skip header row
                            cells = row.find_all(['td', 'th'])
                            if len(cells) >= 2:
                                period = self._clean_text(cells[0].get_text())
                                value = self._clean_text(cells[1].get_text())
                                growth_data[period] = value
                        
                        growth_metrics[title] = growth_data
            
            balance_sheet_data['growth_metrics'] = growth_metrics
            
            logger.info(f"Extracted Balance Sheet data: {len(headers)} years, {len(data_rows)} metrics")
            return balance_sheet_data
            
        except Exception as e:
            logger.error(f"Error extracting Balance Sheet data: {e}")
            return {}
    
    def _extract_additional_info(self, soup: BeautifulSoup, metrics: Dict[str, Any]):
        """Extract additional information from the page"""
        try:
            # Extract company description
            desc_elem = soup.find('div', class_='company-description')
            if desc_elem:
                metrics['description'] = self._clean_text(desc_elem.get_text())
                
            # Extract stock exchange info
            exchange_elem = soup.find('span', class_='exchange')
            if exchange_elem:
                metrics['exchange'] = self._clean_text(exchange_elem.get_text())
                
            # Extract market cap category
            cap_elem = soup.find('span', class_='market-cap')
            if cap_elem:
                metrics['market_cap_category'] = self._clean_text(cap_elem.get_text())
                
        except Exception as e:
            logger.warning(f"Error extracting additional info: {e}")
    
    def scrape_companies_parallel(self, company_urls: List[str] = None, max_companies: int = None) -> pd.DataFrame:
        """
        Scrape financial metrics for multiple companies using parallel processing
        
        Args:
            company_urls: List of company URLs to scrape
            max_companies: Maximum number of companies to scrape (for testing)
            
        Returns:
            DataFrame containing all extracted metrics
        """
        if company_urls is None:
            company_urls = self.get_company_list()
            
        if max_companies:
            company_urls = company_urls[:max_companies]
            
        all_metrics = []
        successful_scrapes = 0
        failed_scrapes = 0
        
        logger.info(f"Starting to scrape {len(company_urls)} companies with {self.max_workers} workers")
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all scraping tasks
            future_to_url = {executor.submit(self.extract_company_metrics, url): url 
                           for url in company_urls}
            
            # Process completed tasks
            for future in as_completed(future_to_url):
                url = future_to_url[future]
                try:
                    metrics = future.result()
                    if metrics and metrics.get('status') == 'success':
                        all_metrics.append(metrics)
                        successful_scrapes += 1
                        company_name = metrics.get('company_name', 'Unknown')
                        logger.info(f"Successfully scraped: {company_name}")
                    else:
                        failed_scrapes += 1
                        logger.warning(f"Failed to extract metrics from {url}")
                except Exception as e:
                    failed_scrapes += 1
                    logger.error(f"Error scraping {url}: {e}")
                    
        logger.info(f"Scraping completed. Successful: {successful_scrapes}, Failed: {failed_scrapes}")
        
        if all_metrics:
            df = pd.DataFrame(all_metrics)
            return df
        else:
            logger.warning("No data was scraped successfully")
            return pd.DataFrame()
    
    def save_to_robust_csv(self, df: pd.DataFrame, filename: str = None) -> str:
        """
        Save scraped data to robust CSV file
        
        Args:
            df: DataFrame to save
            filename: Output filename (auto-generated if None)
            
        Returns:
            Path to saved file
        """
        return self.csv_saver.save_robust_csv(df, filename)
    
    def get_company_list(self, list_url: str = None) -> List[str]:
        """
        Get list of company URLs to scrape
        
        Args:
            list_url: URL of the page containing company links
            
        Returns:
            List of company URLs
        """
        if not list_url:
            # Default to NSE 500 companies page
            list_url = f"{self.base_url}/screener/equity/"
            
        soup = self._get_page_with_retry(list_url)
        if not soup:
            return []
            
        company_urls = []
        
        # Find company links (adjust selector based on actual page structure)
        company_links = soup.find_all('a', href=re.compile(r'/company/[^/]+/$'))
        
        for link in company_links:
            href = link.get('href')
            if href:
                full_url = urljoin(self.base_url, href)
                company_urls.append(full_url)
        
        return company_urls

def main():
    """Main function to run the enhanced robust scraper"""
    # Import the updated company list
    from updated_company_list import get_company_list
    
    # Initialize the scraper
    scraper = EnhancedRobustScraper(
        max_workers=3,
        delay_range=(2, 4),
        retry_attempts=3
    )
    
    # Get the updated company URLs
    company_urls = get_company_list()
    
    print(f"Starting to scrape {len(company_urls)} companies...")
    
    # Scrape companies
    df = scraper.scrape_companies_parallel(company_urls)
    
    if not df.empty:
        # Save to robust CSV
        output_file = scraper.save_to_robust_csv(df, "updated_95_companies_robust.csv")
        print(f"Results saved to: {output_file}")
        
        # Validate the data
        validation_results = scraper.csv_saver.validate_json_data(df)
        print(f"Validation results:")
        print(f"Valid companies: {len(validation_results['valid_companies'])}")
        print(f"Invalid companies: {len(validation_results['invalid_companies'])}")
        
        if validation_results['invalid_companies']:
            print(f"Companies with issues: {validation_results['invalid_companies']}")
    else:
        print("No data was scraped successfully")

if __name__ == "__main__":
    main() 