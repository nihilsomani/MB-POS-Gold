# Profit & Loss (P&L) Extraction Feature

## Overview

The advanced screener scraper now includes comprehensive **Profit & Loss (P&L) data extraction** from screener.in. This feature extracts year-wise financial data including sales, expenses, operating profit, net profit, and various growth metrics.

## What Data is Extracted

### Main P&L Metrics
- **Sales/Revenue** - Year-wise sales figures
- **Expenses** - Total expenses for each year
- **Operating Profit** - Operating profit before interest and tax
- **OPM %** - Operating Profit Margin percentage
- **Other Income** - Non-operating income
- **Interest** - Interest expenses
- **Depreciation** - Depreciation and amortization
- **Profit before tax** - Profit before tax
- **Tax %** - Effective tax rate
- **Net Profit** - Final net profit
- **EPS in Rs** - Earnings per share
- **Dividend Payout %** - Dividend payout ratio

### Growth Metrics
- **Compounded Sales Growth** - 10Y, 5Y, 3Y, TTM growth rates
- **Compounded Profit Growth** - 10Y, 5Y, 3Y, TTM growth rates
- **Stock Price CAGR** - Stock price compound annual growth rates
- **Return on Equity** - ROE for different time periods

## How to Use

### Basic Usage

```python
from advanced_screener_scraper import AdvancedScreenerScraper

# Initialize scraper
scraper = AdvancedScreenerScraper(max_workers=2)

# Scrape a single company
metrics = scraper.scrape_single_company('RELIANCE')

# Check if P&L data was extracted
if metrics.get('has_pnl_data'):
    pnl_data = metrics['pnl_data']
    print(f"Years: {pnl_data['total_years']}")
    print(f"Metrics: {pnl_data['total_metrics']}")
```

### Multiple Companies

```python
# Scrape multiple companies
company_urls = [
    'https://www.screener.in/company/RELIANCE/',
    'https://www.screener.in/company/TCS/',
    'https://www.screener.in/company/HDFCBANK/'
]

df = scraper.scrape_companies_parallel(company_urls)
output_file = scraper.save_to_csv(df, "companies_with_pnl.csv")
```

## Output Files

### Main CSV File
The main CSV file includes a `has_pnl_data` column indicating whether P&L data was successfully extracted.

### P&L Data Files
For each company with P&L data, a separate CSV file is created in the `output/pnl_data/` directory:

```
output/
├── companies_with_pnl.csv          # Main results
└── pnl_data/
    ├── RELIANCE_pnl.csv           # P&L data for Reliance
    ├── TCS_pnl.csv               # P&L data for TCS
    ├── HDFCBANK_pnl.csv          # P&L data for HDFC Bank
    └── pnl_summary.txt           # Summary of all P&L data
```

### P&L CSV Structure
Each P&L CSV file contains:
- `company_name` - Company name
- `company_url` - Company URL
- `scraped_at` - Timestamp
- `metric` - P&L metric name (Sales, Expenses, etc.)
- Year columns (Mar 2014, Mar 2015, etc.) - Numeric values
- Year_raw columns (Mar 2014_raw, Mar 2015_raw, etc.) - Raw text values

## Example P&L Data

```csv
company_name,company_url,scraped_at,metric,Mar 2014,Mar 2015,Mar 2016,Mar 2014_raw,Mar 2015_raw,Mar 2016_raw
Reliance Industries,https://www.screener.in/company/RELIANCE/,2024-01-15T10:30:00,Sales,433521.0,374372.0,272583.0,433,521,374,372,272,583
Reliance Industries,https://www.screener.in/company/RELIANCE/,2024-01-15T10:30:00,Expenses,398586.0,336923.0,230802.0,398,586,336,923,230,802
Reliance Industries,https://www.screener.in/company/RELIANCE/,2024-01-15T10:30:00,Operating Profit,34935.0,37449.0,41781.0,34,935,37,449,41,781
```

## Testing the Feature

Run the test script to verify P&L extraction:

```bash
python test_pnl_extraction.py
```

This will:
1. Test P&L extraction for a single company
2. Test multiple companies
3. Verify CSV output generation

## Configuration

The P&L extraction is automatically enabled. No additional configuration is required. The scraper will:

1. Check for the `profit-loss` section on each company page
2. Extract all available P&L data
3. Include growth metrics if available
4. Save data in separate CSV files

## Error Handling

- If a company doesn't have P&L data, `has_pnl_data` will be `False`
- Missing data points are handled gracefully
- Unicode encoding issues are automatically fixed
- Failed extractions are logged for debugging

## Performance

- P&L extraction adds minimal overhead to the scraping process
- Data is extracted in parallel with other metrics
- Separate CSV files are created efficiently
- Memory usage is optimized for large datasets

## Integration with Existing Features

The P&L extraction works seamlessly with:
- ✅ Custom company lists
- ✅ Parallel processing
- ✅ Quarterly data extraction
- ✅ Unicode encoding fixes
- ✅ Error handling and retries
- ✅ CSV output with proper encoding

## Troubleshooting

### No P&L Data Found
- Check if the company has a `profit-loss` section on screener.in
- Verify the company symbol is correct
- Check the scraper logs for any errors

### Missing Years
- Some companies may not have data for all years
- The scraper handles missing data gracefully
- Check the raw data columns for original values

### Encoding Issues
- The scraper automatically fixes Unicode encoding issues
- CSV files are saved with UTF-8-BOM encoding
- Use the `fix_csv_encoding.py` utility if needed

## Future Enhancements

Potential improvements:
- Balance Sheet extraction
- Cash Flow statement extraction
- Comparative analysis features
- Growth trend analysis
- Export to different formats (Excel, JSON)

## Support

For issues or questions about the P&L extraction feature:
1. Check the scraper logs for error messages
2. Run the test script to verify functionality
3. Review the generated CSV files for data quality 