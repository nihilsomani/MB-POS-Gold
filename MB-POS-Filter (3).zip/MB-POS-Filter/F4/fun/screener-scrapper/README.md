# 📊 Screener.in Financial Data Scraper

> **Comprehensive, production-ready web scraper** for extracting financial data from screener.in

A powerful Python-based web scraper designed to extract comprehensive financial metrics, statements, and quarterly data from [screener.in](https://www.screener.in), India's most popular stock analysis platform.

## ✨ Features

### 🎯 Core Capabilities
- **Comprehensive Financial Metrics** - 25+ key ratios and metrics per company
- **Historical Data** - Multi-year P&L statements, balance sheets, and cash flow data
- **Quarterly Results** - Recent quarterly performance with YoY/QoQ comparisons
- **Parallel Processing** - Multi-threaded scraping for faster data collection
- **Robust Error Handling** - Automatic retries, rate limiting, and graceful failures
- **Unicode Support** - Proper handling of ₹ (Rupee) and special characters
- **Data Validation** - Built-in validation and quality checks
- **CSV Export** - Clean, organized CSV files with separate data type directories

### 📈 Data Extracted

#### Basic Metrics
- Market Cap, Current Price, 52-week High/Low
- P/E Ratio, Book Value, Dividend Yield
- ROE, ROCE, EPS
- Industry PE, PEG Ratio, Intrinsic Value
- And 15+ more financial ratios

#### Advanced Financial Statements
1. **Profit & Loss (P&L)**
   - Revenue, expenses, profits
   - Operating margins, EBITDA
   - Growth metrics and trends
   
2. **Balance Sheet**
   - Assets (current, non-current, fixed)
   - Liabilities (current, non-current)
   - Equity, reserves, working capital
   - Debt structure (short-term, long-term)

3. **Quarterly Results**
   - Quarter-over-quarter trends
   - Recent performance indicators
   - Upcoming result dates

4. **Cash Flow**
   - Operating, investing, financing activities
   - Free cash flow
   - Cash generation trends

---

## 🚀 Quick Start

### Installation

```bash
# Clone or download the project
cd screener-scrapper

# Install dependencies
pip install -r requirements.txt

# Verify installation
python quick_start.py
```

### Basic Usage

```python
from advanced_screener_scraper import AdvancedScreenerScraper

# Initialize scraper
scraper = AdvancedScreenerScraper()

# Scrape a single company
metrics = scraper.scrape_single_company('RELIANCE')
print(f"Price: ₹{metrics['current_price']}")
print(f"Market Cap: ₹{metrics['market_cap']} Cr")

# Save to CSV
import pandas as pd
df = pd.DataFrame([metrics])
scraper.save_to_csv(df, "reliance_data.csv")
```

### Multiple Companies

```python
# Scrape multiple companies with parallel processing
scraper = AdvancedScreenerScraper(max_workers=3)

companies = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY']
company_urls = [f"https://www.screener.in/company/{c}/" for c in companies]

df = scraper.scrape_companies_parallel(company_urls=company_urls)
scraper.save_to_csv(df, "top_companies.csv")
```

---

## 📁 Project Structure

```
screener-scrapper/
│
├── 🎯 Core Files
│   ├── advanced_screener_scraper.py  # Main scraper (production-ready)
│   ├── config.py                      # Configuration settings
│   ├── custom_companies_config.py     # Company lists
│   ├── robust_csv_saver.py            # CSV handling utilities
│   └── requirements.txt               # Dependencies
│
├── 🛠️ Utilities
│   ├── scraper_utils.py               # Utility functions
│   ├── scraper_examples.py            # Usage examples
│   └── quick_start.py                 # Quick test script
│
├── 📂 Output Structure
│   └── output/
│       ├── [main_data].csv            # Main metrics file
│       ├── pnl_data/                  # P&L statements
│       ├── balance_sheet_data/        # Balance sheets
│       ├── quarterly_data/            # Quarterly results
│       └── cash_flow_data/            # Cash flow statements
│
└── 📚 Documentation
    └── README.md                      # This file
```

---

## 🔧 Configuration

### Basic Configuration

```python
scraper = AdvancedScreenerScraper(
    base_url="https://www.screener.in",
    delay_range=(1, 3),      # Random delay between requests (seconds)
    max_workers=3,           # Number of parallel threads
    timeout=30,              # Request timeout (seconds)
    retry_attempts=3         # Number of retries for failed requests
)
```

### Using Config File

Edit `config.py`:

```python
# Rate limiting
DEFAULT_DELAY_RANGE = (1, 3)
MAX_WORKERS = 3
REQUEST_TIMEOUT = 30
RETRY_ATTEMPTS = 3

# Custom companies
CUSTOM_COMPANIES = [
    'RELIANCE',
    'TCS',
    'HDFCBANK',
    # Add more...
]
```

---

## 📊 Output Format

### Main CSV File

Contains all basic metrics for each company:

```csv
company_name,sector,current_price,market_cap,pe_ratio,roe,roce,...
Reliance Industries,Oil & Gas,2456.75,1654321.50,18.45,12.34,15.67,...
TCS,IT,3456.80,1234567.90,25.67,28.90,32.45,...
```

### Data Type CSVs

Each company gets separate detailed CSVs in subdirectories:

**P&L Data** (`output/pnl_data/RELIANCE_pnl.csv`):
```csv
metric,Mar 2020,Mar 2021,Mar 2022,Mar 2023,Mar 2024
Sales +,1234.5,1456.7,1678.9,1890.1,2012.3
Operating Profit,234.5,267.8,289.1,312.4,345.6
...
```

**Balance Sheet** (`output/balance_sheet_data/RELIANCE_balance_sheet.csv`):
```csv
metric,Mar 2020,Mar 2021,Mar 2022,Mar 2023,Mar 2024
Total Assets,5000,5500,6000,6500,7000
Total Liabilities,2000,2200,2400,2600,2800
...
```

---

## 💡 Usage Examples

### Example 1: Basic Scraping

```python
from advanced_screener_scraper import AdvancedScreenerScraper

scraper = AdvancedScreenerScraper()
metrics = scraper.scrape_single_company('TCS')

if metrics['status'] == 'success':
    print(f"Company: {metrics['company_name']}")
    print(f"Sector: {metrics['sector']}")
    print(f"Price: ₹{metrics['current_price']}")
    print(f"P/E: {metrics['pe_ratio']}")
```

### Example 2: Custom Company List

```python
# Define your portfolio
my_portfolio = ['RELIANCE', 'TCS', 'HDFCBANK', 'ICICIBANK']

scraper = AdvancedScreenerScraper(max_workers=2)
all_metrics = []

for company in my_portfolio:
    metrics = scraper.scrape_single_company(company)
    if metrics:
        all_metrics.append(metrics)

# Save results
import pandas as pd
df = pd.DataFrame(all_metrics)
scraper.save_to_csv(df, "my_portfolio_analysis.csv")
```

### Example 3: Quarterly Focus

```python
# Focus on companies with quarterly data
scraper = AdvancedScreenerScraper()

companies = ['RELIANCE', 'TCS', 'INFY']
results = []

for company in companies:
    metrics = scraper.scrape_single_company(company)
    
    if metrics.get('has_quarterly_data'):
        print(f"{company}: {metrics['quarterly_quarters_count']} quarters available")
        results.append(metrics)

# Quarterly CSVs saved to output/quarterly_data/
```

### Example 4: Parallel Batch Processing

```python
# Scrape large number of companies efficiently
companies = ['RELIANCE', 'TCS', 'HDFCBANK', ...] # 100+ companies

scraper = AdvancedScreenerScraper(
    max_workers=5,
    delay_range=(1, 2)
)

# Convert to URLs
urls = [f"https://www.screener.in/company/{c}/" for c in companies]

# Scrape in parallel
df = scraper.scrape_companies_parallel(company_urls=urls)

# Save
scraper.save_to_csv(df, "large_batch_results.csv")
```

---

## 🛠️ Utility Functions

### Data Validation

```python
from scraper_utils import validate_company_data, print_validation_report

# Load data
df = pd.read_csv("output/my_data.csv")

# Validate
validation = validate_company_data(df)
print_validation_report(validation)
```

### Fix Encoding Issues

```python
from scraper_utils import fix_csv_encoding

# Fix Unicode issues in existing CSV
fix_csv_encoding(
    input_file="old_data.csv",
    output_file="fixed_data.csv"
)
```

### Merge Multiple Files

```python
from scraper_utils import merge_csv_files

# Combine multiple scraping sessions
files = [
    "output/batch1.csv",
    "output/batch2.csv",
    "output/batch3.csv"
]

merge_csv_files(files, "combined_data.csv")
```

### Directory Summary

```python
from scraper_utils import print_directory_summary

# Show what data you have
print_directory_summary("output")
```

---

## 🔒 Best Practices

### 1. **Respect Rate Limits**
```python
# Use appropriate delays
scraper = AdvancedScreenerScraper(
    delay_range=(2, 5),  # Longer delays for politeness
    max_workers=2        # Fewer parallel requests
)
```

### 2. **Start Small**
```python
# Test with few companies first
df = scraper.scrape_companies_parallel(max_companies=5)
```

### 3. **Handle Errors Gracefully**
```python
try:
    metrics = scraper.scrape_single_company('COMPANY')
    if metrics['status'] == 'success':
        # Process data
        pass
except Exception as e:
    print(f"Error: {e}")
```

### 4. **Monitor Progress**
```python
# Check logs
# advanced_screener_scraper.log contains detailed logs
```

### 5. **Validate Data**
```python
from scraper_utils import validate_company_data

df = pd.read_csv("output/data.csv")
validation = validate_company_data(df)

if validation['failed'] > 0:
    print(f"Warning: {validation['failed']} companies failed")
```

---

## 🐛 Troubleshooting

### Common Issues

**1. Import Errors**
```bash
# Solution: Install dependencies
pip install -r requirements.txt
```

**2. Network Timeouts**
```python
# Solution: Increase timeout
scraper = AdvancedScreenerScraper(timeout=60)
```

**3. Rate Limiting (429 errors)**
```python
# Solution: Increase delays
scraper = AdvancedScreenerScraper(
    delay_range=(3, 6),
    max_workers=2
)
```

**4. Encoding Issues (â‚¹ instead of ₹)**
```python
# Solution: Use utility to fix
from scraper_utils import fix_csv_encoding
fix_csv_encoding("input.csv", "fixed.csv")
```

**5. No Data Extracted**
- Check if website structure changed
- Verify company symbols are correct
- Review log files for errors

### Log Files

Check these files for detailed information:
- `advanced_screener_scraper.log` - Main scraper logs
- `output/[file]_summary.txt` - Scraping summaries

---

## 📚 Advanced Features

### Custom Data Extraction

```python
# Access detailed data structures
metrics = scraper.scrape_single_company('RELIANCE')

if '_detailed_data' in metrics:
    detailed = metrics['_detailed_data']
    
    # P&L data
    if 'pnl_data' in detailed:
        pnl = detailed['pnl_data']
        print(f"Years: {pnl['years']}")
        print(f"Metrics: {pnl['total_metrics']}")
    
    # Quarterly data
    if 'quarterly_data' in detailed:
        qtr = detailed['quarterly_data']
        print(f"Quarters: {qtr['quarters']}")
```

### Robust CSV Handling

```python
from robust_csv_saver import RobustCSVSaver

saver = RobustCSVSaver()

# Save with JSON handling
saver.save_robust_csv(df, "robust_output.csv")

# Load with JSON parsing
df = saver.load_from_csv("robust_output.csv")
```

### Custom Configuration

```python
import config

# Override defaults
config.MAX_WORKERS = 5
config.DEFAULT_DELAY_RANGE = (2, 4)
config.RETRY_ATTEMPTS = 5

scraper = AdvancedScreenerScraper(
    max_workers=config.MAX_WORKERS,
    delay_range=config.DEFAULT_DELAY_RANGE,
    retry_attempts=config.RETRY_ATTEMPTS
)
```

---

## 📖 API Reference

### AdvancedScreenerScraper

**Constructor:**
```python
__init__(base_url, delay_range, max_workers, timeout, retry_attempts)
```

**Main Methods:**
- `scrape_single_company(company_symbol)` - Scrape one company
- `scrape_companies_parallel(company_urls, max_companies)` - Parallel scraping
- `extract_company_metrics(company_url)` - Low-level extraction
- `save_to_csv(df, filename)` - Save with proper formatting
- `get_company_list(list_url)` - Get company URLs

**Private Methods:**
- `_extract_quarterly_data(soup)` - Extract quarterly data
- `_extract_profit_loss_data(soup)` - Extract P&L data
- `_extract_balance_sheet_data(soup)` - Extract balance sheet
- `_extract_cash_flow_data(soup)` - Extract cash flow
- `_clean_text(text)` - Unicode cleaning
- `_extract_number(text)` - Number extraction

---

## 🤝 Contributing

Contributions are welcome! Areas for improvement:
- Additional financial metrics
- Enhanced error handling
- Performance optimizations
- Documentation improvements
- Test coverage

---

## ⚖️ Legal & Ethical Considerations

### Important Notes

1. **Terms of Service** - Review and comply with screener.in's terms of service
2. **Rate Limiting** - Always use appropriate delays to avoid overwhelming servers
3. **Data Usage** - Use scraped data responsibly and in accordance with laws
4. **Attribution** - Consider providing attribution when using scraped data
5. **Personal Use** - This tool is designed for educational and personal research

### Responsible Scraping

```python
# Good practice:
scraper = AdvancedScreenerScraper(
    delay_range=(2, 5),    # Respectful delays
    max_workers=2          # Conservative parallelism
)

# Not recommended:
# delay_range=(0, 0.5)   # Too aggressive
# max_workers=20         # Too many parallel requests
```

---

## 📦 Dependencies

```
requests>=2.28.0        # HTTP requests
beautifulsoup4>=4.11.0  # HTML parsing
pandas>=1.5.0           # Data manipulation
lxml>=4.9.0             # XML/HTML parser
html5lib>=1.1           # HTML5 parser
```

---

## 🎯 Use Cases

1. **Portfolio Analysis** - Track your stock investments
2. **Fundamental Research** - Deep dive into company financials
3. **Comparative Analysis** - Compare multiple companies
4. **Historical Trends** - Analyze multi-year performance
5. **Quarterly Tracking** - Monitor quarterly results
6. **Data Science Projects** - Build financial models
7. **Automated Reporting** - Generate periodic financial reports

---

## 📞 Support

For issues, questions, or suggestions:

1. Check the troubleshooting section
2. Review log files for error details
3. Verify all dependencies are installed
4. Test with a single company first
5. Check website connectivity

---

## 📜 Version History

**v1.0** (2025-10-16)
- Consolidated from multiple scraper versions
- Unified utilities and examples
- Comprehensive documentation
- Production-ready code

---

## 🙏 Acknowledgments

- Data source: [screener.in](https://www.screener.in)
- Built with: Python, BeautifulSoup, Pandas, Requests

---

## ⚠️ Disclaimer

This scraper is provided as-is without warranties. Users are responsible for:
- Compliance with website terms of service
- Compliance with applicable laws
- Responsible and ethical use of the tool
- Data accuracy verification

The authors are not responsible for any misuse of this tool or legal consequences arising from its use.

---

**Happy Scraping! 📊🚀**

For more examples, see `scraper_examples.py`  
For utilities, see `scraper_utils.py`  
For quick testing, run `quick_start.py`

