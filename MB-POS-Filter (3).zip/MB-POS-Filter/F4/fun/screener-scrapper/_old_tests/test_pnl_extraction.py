#!/usr/bin/env python3
"""
Test script to verify P&L extraction functionality
"""

from advanced_screener_scraper import AdvancedScreenerScraper
import pandas as pd

def test_pnl_extraction():
    """Test the P&L extraction functionality"""
    
    print("Testing P&L Extraction")
    print("=" * 40)
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Test with a well-known company that should have P&L data
    company_symbol = 'RELIANCE'
    print(f"Testing P&L extraction for {company_symbol}...")
    
    try:
        metrics = scraper.scrape_single_company(company_symbol)
        
        if metrics and metrics.get('status') == 'success':
            print("✓ Successfully scraped company data")
            
            # Check if P&L data was extracted
            has_pnl = metrics.get('has_pnl_data', False)
            print(f"Has P&L data: {has_pnl}")
            
            if has_pnl:
                pnl_data = metrics.get('pnl_data', {})
                print(f"✓ P&L data extracted successfully")
                print(f"  Years: {pnl_data.get('total_years', 0)}")
                print(f"  Metrics: {pnl_data.get('total_metrics', 0)}")
                
                # Show some sample data
                if 'data' in pnl_data and pnl_data['data']:
                    print("\nSample P&L metrics:")
                    for i, row in enumerate(pnl_data['data'][:5]):  # Show first 5 metrics
                        metric_name = row.get('metric', 'Unknown')
                        print(f"  {i+1}. {metric_name}")
                
                # Show growth metrics if available
                if 'growth_metrics' in pnl_data:
                    print("\nGrowth metrics:")
                    for title, data in pnl_data['growth_metrics'].items():
                        print(f"  {title}:")
                        for period, value in data.items():
                            print(f"    {period}: {value}")
            else:
                print("✗ No P&L data found")
                
        else:
            print("✗ Failed to scrape company data")
            
    except Exception as e:
        print(f"✗ Error: {e}")

def test_multiple_companies():
    """Test P&L extraction for multiple companies"""
    
    print("\n" + "="*40)
    print("Testing P&L extraction for multiple companies...")
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=2)
    
    # Test with a few companies
    test_companies = ['RELIANCE', 'TCS', 'HDFCBANK']
    
    for company in test_companies:
        print(f"\nTesting {company}...")
        try:
            metrics = scraper.scrape_single_company(company)
            
            if metrics and metrics.get('status') == 'success':
                has_pnl = metrics.get('has_pnl_data', False)
                company_name = metrics.get('company_name', company)
                print(f"  ✓ {company_name}: {'Has P&L' if has_pnl else 'No P&L'}")
                
                if has_pnl:
                    pnl_data = metrics.get('pnl_data', {})
                    print(f"    Years: {pnl_data.get('total_years', 0)}, Metrics: {pnl_data.get('total_metrics', 0)}")
            else:
                print(f"  ✗ {company}: Failed to scrape")
                
        except Exception as e:
            print(f"  ✗ {company}: Error - {e}")

def test_csv_output():
    """Test saving P&L data to CSV"""
    
    print("\n" + "="*40)
    print("Testing CSV output with P&L data...")
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Test with a single company
    company_symbol = 'RELIANCE'
    print(f"Scraping {company_symbol} and saving to CSV...")
    
    try:
        metrics = scraper.scrape_single_company(company_symbol)
        
        if metrics and metrics.get('status') == 'success':
            # Create DataFrame
            df = pd.DataFrame([metrics])
            
            # Save to CSV
            filename = scraper.save_to_csv(df, "test_pnl_output.csv")
            print(f"✓ Data saved to: {filename}")
            
            # Check if P&L files were created
            import os
            pnl_dir = os.path.join('output', 'pnl_data')
            if os.path.exists(pnl_dir):
                pnl_files = [f for f in os.listdir(pnl_dir) if f.endswith('.csv')]
                print(f"✓ P&L files created: {len(pnl_files)}")
                for file in pnl_files:
                    print(f"  - {file}")
            else:
                print("✗ No P&L directory created")
                
        else:
            print("✗ Failed to scrape company data")
            
    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    test_pnl_extraction()
    test_multiple_companies()
    test_csv_output()
    
    print("\n" + "="*40)
    print("P&L extraction test completed!") 