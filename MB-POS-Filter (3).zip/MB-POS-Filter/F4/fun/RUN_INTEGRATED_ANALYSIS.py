#!/usr/bin/env python3
"""
Quick Start: Integrated Quantitative + Qualitative Analysis
============================================================

This is your main entry point for professional investment analysis.

Usage:
    python RUN_INTEGRATED_ANALYSIS.py
    
What it does:
    1. Quantitative Filter (4-tier pyramid) - financial_scanner.py data
    2. Qualitative Analysis - PDFs from downloads/
    3. Final integrated decision with confidence ratings
    
Output:
    - integrated_analysis_*.csv (Complete results)
    - Console report with HIGH CONVICTION BUYS
"""

import os
import sys

def check_prerequisites():
    """Check if all required data exists"""
    
    print("\n" + "="*70)
    print("CHECKING PREREQUISITES...")
    print("="*70)
    
    issues = []
    
    # 1. Check output directory (from my_scraper.py)
    if not os.path.exists("output/pnl_data"):
        issues.append("❌ output/pnl_data not found")
        issues.append("   → Run: cd screener-scrapper && python my_scraper.py")
    else:
        pnl_count = len([f for f in os.listdir("output/pnl_data") if f.endswith('.csv')])
        print(f"✅ Quantitative data: {pnl_count} companies")
    
    # 2. Check downloads directory (from documents-scrapper.py)
    concalls_exist = os.path.exists("downloads/concalls")
    reports_exist = os.path.exists("downloads/annual_reports")
    
    if concalls_exist:
        concall_count = len([f for f in os.listdir("downloads/concalls") if f.endswith('.pdf')])
        print(f"✅ Concalls downloaded: {concall_count} PDFs")
    else:
        concall_count = 0
        issues.append("⚠️ downloads/concalls not found")
    
    if reports_exist:
        report_count = len([f for f in os.listdir("downloads/annual_reports") if f.endswith('.pdf')])
        print(f"✅ Annual reports downloaded: {report_count} PDFs")
    else:
        report_count = 0
        issues.append("⚠️ downloads/annual_reports not found")
    
    if not concalls_exist and not reports_exist:
        issues.append("   → Run: cd screener-scrapper && python documents-scrapper.py")
    
    # 3. Check PyPDF2
    try:
        import PyPDF2
        print("✅ PyPDF2 installed")
    except ImportError:
        issues.append("❌ PyPDF2 not installed")
        issues.append("   → Installing now...")
        import subprocess
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'PyPDF2', '--quiet'])
        print("✅ PyPDF2 installed")
    
    print()
    
    if issues:
        print("ISSUES FOUND:")
        for issue in issues:
            print(f"  {issue}")
        print()
    
    # Estimate
    if pnl_count > 0:
        docs = concall_count + report_count
        time_est = (pnl_count * 2 + docs * 0.5) / 60
        print(f"⏱️  Estimated analysis time: {time_est:.1f} minutes")
        print(f"   ({pnl_count} quant analyses + {docs} PDFs)")
    
    return len([i for i in issues if i.startswith('❌')]) == 0


def main():
    """Run integrated analysis"""
    
    print("\n" + "🎯 "*35)
    print("\nINTEGRATED INVESTMENT ANALYZER")
    print("Combining Quantitative (Numbers) + Qualitative (Documents)")
    print("\n" + "🎯 "*35)
    
    # Check prerequisites
    if not check_prerequisites():
        print("\n⚠️  Please resolve critical issues (❌) before continuing.")
        print("   You can still run with warnings (⚠️) but results will be limited.\n")
        
        response = input("Continue anyway? (y/n): ")
        if response.lower() != 'y':
            print("\n👋 Exiting. Run prerequisites first.")
            return
    
    print("\n" + "="*70)
    print("STARTING INTEGRATED ANALYSIS...")
    print("="*70)
    
    # Import and run
    from integrated_analyzer import IntegratedAnalyzer
    
    # Fix paths - Use absolute paths to workspace root
    import os
    workspace_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))
    data_dir = os.path.join(workspace_root, 'output')
    downloads_dir = os.path.join(workspace_root, 'downloads')
    
    print(f"\n📂 Data directory: {data_dir}")
    print(f"📂 Downloads directory: {downloads_dir}")
    
    analyzer = IntegratedAnalyzer(
        data_dir=data_dir,
        downloads_dir=downloads_dir
    )
    
    # Analyze all companies
    df = analyzer.scan_all_companies()
    
    # Generate report
    analyzer.generate_report(df)
    
    # Save results
    filename = analyzer.save_results(df)
    
    print(f"\n✅ ANALYSIS COMPLETE!")
    print(f"\n📁 Open {filename} to see:")
    print("   - HIGH_CONVICTION_BUY: Best opportunities")
    print("   - BUY: Good opportunities")
    print("   - WATCH: Monitor these")
    print("   - PASS: Skip these")
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠️  Analysis interrupted by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

