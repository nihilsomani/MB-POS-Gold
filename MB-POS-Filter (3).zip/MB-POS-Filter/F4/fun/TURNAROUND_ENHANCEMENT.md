# Turnaround Detection & Quality Scoring Enhancement

## Problem Statement

Companies like **ETERNAL** were getting **Grade D (Poor)** despite:
- ✅ Fast growth (41.6% CAGR)
- ✅ Moderate Moat (70/100)
- ✅ Expanding margins (-11% → 14%)
- ✅ Strong FCF conversion (1.01x)

**Why?** Historical ROIC of **2.31%** (years of losses) killed the score.

**But:** Recent concall shows 25%+ revenue guidance, margin expansion to 28-30%, strong order book!

**Issue:** System looked **backward** (historical capital efficiency) and ignored **forward** signals (guidance, momentum).

---

## Solution Implemented

### **1. Enhanced ROIC Scoring with Turnaround Detection**

#### **Before:**
```python
roic = current_year_roic
if roic > 25: points += 40
elif roic > 20: points += 35
elif roic > 15: points += 25
elif roic > 10: points += 10
else: points += 0  # ← ETERNAL gets 0 here (ROIC 2.31%)
```

#### **After:**
```python
# Calculate 3-year average ROIC
roic_3y = [Mar 2022 ROIC, Mar 2023 ROIC, Mar 2024 ROIC]
roic_avg_3y = average(roic_3y)

# Blended ROIC: 50% current, 50% 3-year avg (rewards improvement)
roic_blended = (roic_current * 0.5 + roic_avg_3y * 0.5)

# Detect turnaround: was <5%, now >10%
if roic_3y[0] < 5 and roic_current > 10:
    is_turnaround = True
    strengths.append("🔄 Turnaround: ROIC improved to X%")

# Score on blended ROIC (gives credit to trends)
if roic_blended > 25: points += 40
elif roic_blended > 20: points += 35
elif roic_blended > 15: points += 25
elif roic_blended > 10: points += 15  # ← Increased from 10
elif roic_blended > 5: points += 8    # ← NEW tier for emerging quality
elif is_turnaround and roic_current > 8: points += 12  # ← Bonus for turnarounds
```

**Impact for ETERNAL:**
- Before: 0 points (ROIC 2.31%)
- After: ~8-12 points (turnaround bonus + blended scoring)

---

### **2. Margin Improvement Detection**

#### **New Logic:**
```python
# Check 3-year margin trend
margin_2022 = -11%
margin_2023 = 9%
margin_2024 = 12%

margin_expansion_bps = (12% - (-11%)) * 100 = +2,300 bps!

if margin_expansion_bps > 500:  # 5%+ expansion
    margin_improving = True
    strengths.append("📈 Margin Expansion: +2,300bps")
    points += 12  # Bonus for improving margins

# Score even low margins if improving
if gross_margin > 15 and margin_improving:
    points += 12  # ← Was 0 before!
```

**Impact for ETERNAL:**
- Before: 0 points (margin 12%, need >20%)
- After: ~12 points (12% margin + 2,300 bps expansion!)

---

### **3. Enhanced Integrated Decision for Turnarounds**

#### **New Decision Logic:**
```python
if quant_decision == 'PASS':
    # Check for turnaround signals
    is_turnaround = metrics.get('is_turnaround', False)
    margin_improving = metrics.get('margin_improving', False)
    moat_score = metrics.get('moat_score', 0)
    
    # Special case: Turnaround + Strong Qual + Moderate Moat
    if qual_score > 85 and (is_turnaround or margin_improving) and moat_score >= 50:
        final = 'WATCH'
        reason = "Turnaround story: Weak historical BUT strong forward guidance + improving margins"
        action = "⚠️ WATCH - Turnaround with exceptional management"
    
    # Regular exceptional qual upgrade
    elif qual_score > 85:
        final = 'WATCH'
        reason = "Weak historical BUT exceptional management + strong forward guidance"
        action = "⚠️ WATCH - Exceptional qual despite weak quant"
    
    else:
        final = 'PASS'
```

---

## Expected Impact on ETERNAL

### **Quantitative Improvements:**

#### **Quality Score:**
**Before:**
- ROIC: 0 pts (2.31%)
- FCF: 25 pts (1.01x)
- Margin: 0 pts (12%)
- FCF Consist: 5 pts
- **Total: 30 pts → Grade D**

**After:**
- ROIC: 12 pts (turnaround bonus)
- FCF: 25 pts (1.01x)
- Margin: 12 pts (12% + improving)
- FCF Consist: 5 pts
- **Total: 54 pts → Grade C** ⬆️

#### **Strengths Now Include:**
- ✅ Strong Cash Conversion (1.01x)
- ✅ **🔄 Turnaround: ROIC improved** ← NEW!
- ✅ **📈 Margin Expansion: +2,300bps** ← NEW!

---

### **Qualitative Analysis (from Concall):**

When concall is analyzed, expects to find:
- ✅ **Strong revenue guidance (25%+)**: +15 pts
- ✅ **Strong margin guidance (28-30%)**: +10 pts
- ✅ **Strong balance sheet (₹2.4 bn net cash)**: +5 pts
- ✅ **CDMO ramp-up**: +10 pts (earning trigger)
- ✅ **Clear strategic initiatives**: +10 pts
- ✅ **Management consistency**: +10 pts

**Expected Qual Score: 80-95** (instead of default 50)

---

### **Final Integrated Decision:**

**Before Enhancement:**
```
Quant: Grade D (30 pts)
Qual: No analysis (50 default)
Final: PASS - Poor business quality
```

**After Enhancement:**
```
Quant: Grade C (54 pts) - Turnaround detected
  • 🔄 Turnaround: ROIC improved
  • 📈 Margin Expansion: +2,300bps
  • Strong Cash Conversion (1.01x)
  • Fast Growth (41.6% CAGR)

Qual: Score 85-95 (from concall/report)
  • ✅ Strong revenue guidance (25%+ growth)
  • ✅ Strong margin guidance (28-30%)
  • ✅ Strong balance sheet (net cash)
  • ✅ CDMO ramp-up (earning trigger)
  • ✅ Clear strategic initiatives

Moat: Moderate (70 pts) - Fast growth + margins expanding

Final: ⚠️ WATCH - Turnaround with exceptional management
  Confidence: Medium
  Reason: "Turnaround story: Weak historical BUT strong forward 
           guidance (25%+ revenue, 28-30% margins) + improving metrics"
```

**Caveat:** ⚠️ P/E 133 is still expensive - needs to deliver on guidance!

---

## Key Philosophy Change

### **Before:**
- 100% backward-looking (historical capital efficiency)
- Turnarounds penalized for past mistakes
- Concalls ignored for quantitative assessment

### **After:**
- **Blended:** 50% historical + 50% recent trends
- **Turnarounds get credit** for improvement trajectory
- **Concalls provide forward guidance** with specific numbers
- **Final decision integrates:**
  - Historical performance (numbers)
  - Recent trends (improving margins/ROIC)
  - Forward guidance (concall specifics)
  - Management quality (execution consistency)

---

## Formula Summary

### **Enhanced Quality Score:**
```
Points = ROIC (0-40, with turnaround bonus)
       + FCF Conversion (0-30)
       + Margin (0-20, with improvement bonus)
       + FCF Consistency (0-10)
```

### **Enhanced Qual Score:**
```
Score = 50 (baseline)
      + Management Quality (-50 to +50)
      + Strategic Updates (0 to +20)
      + Guidance/Outlook (-15 to +20)  ← Now extracts quantitative targets!
      + Earning Triggers (0 to +25)
      + Consistency (-20 to +20)
      + Moat Validation (-30 to +30)
      + Capital Allocation (-20 to +20)
```

### **Final Decision (Turnaround-Aware):**
```
IF quant_decision == PASS:
    IF qual_score > 85 AND (turnaround OR margin_improving) AND moat >= 50:
        → WATCH (turnaround story)
    ELIF qual_score > 85:
        → WATCH (exceptional qual)
    ELSE:
        → PASS
```

---

## Real-World Example: ETERNAL

### **What Killed It Before:**
- Years of losses (2015-2021)
- ROIC only 2.31% (huge equity base from past losses)
- Margins only 12% (but were -289%!)

### **What Saves It Now:**
- **Turnaround detected**: Margins -11% → 12% (+2,300 bps)
- **Strong growth**: 41.6% CAGR (revenue 527 → 6,622 Cr)
- **Moderate Moat**: 70/100 (fast growth + margin expansion)
- **Concall guidance**: 25%+ revenue, 28-30% margins, CDMO ramp-up
- **Management quality**: Capital-focused, transparent, strong execution

### **New Decision:**
**⚠️ WATCH** - Turnaround with exceptional management

**Investment Thesis:**
- High-risk, high-reward turnaround
- Management delivering on promises
- Margins expanding toward industry norms
- Strong forward guidance
- BUT: P/E 133 means you're paying for perfection!

**Action:** Monitor closely - if they deliver on guidance, could be multi-bagger. If they miss, avoid.

---

## Files Modified

1. ✅ `investment_filter.py` - Enhanced quality scoring with turnaround detection
2. ✅ `integrated_analyzer.py` - Enhanced guidance extraction + turnaround-aware decisions
3. ✅ `analyze_all_with_documents.py` - Enhanced document analysis

**The system now blends historical data with forward-looking guidance for high-conviction decisions!** 🎯

