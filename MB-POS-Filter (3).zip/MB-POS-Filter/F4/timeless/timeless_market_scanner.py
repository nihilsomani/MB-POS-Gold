"""
Timeless Market Scanner
Scans universe of stocks for Contraction → Expansion in Uptrend signals
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import logging
import time
import os
from pathlib import Path

from timeless_market_strategy import TimelessMarketStrategy, Signal

try:
    from kiteconnect import KiteConnect
    KITE_AVAILABLE = True
except ImportError:
    KITE_AVAILABLE = False
    logging.warning("KiteConnect not available. Running in simulation mode.")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class TimelessMarketScanner:
    """
    Scanner for Timeless Market Strategy signals
    """
    
    def __init__(self, 
                 api_key: Optional[str] = None,
                 access_token: Optional[str] = None,
                 strategy_config: Optional[Dict] = None):
        """
        Initialize scanner with Kite credentials and strategy config
        """
        self.strategy = TimelessMarketStrategy(strategy_config)
        
        if KITE_AVAILABLE and api_key and access_token:
            self.kite = KiteConnect(api_key=api_key)
            self.kite.set_access_token(access_token)
            self.use_kite = True
            self.instrument_cache = None
            self.symbol_token_map = {}
            self.last_request_time = 0
            self.min_request_interval = 0.35  # Rate limiting
        else:
            self.use_kite = False
            logger.warning("KiteConnect not configured. Scanner will use mock data.")
    
    def _rate_limit(self):
        """Enforce rate limiting for Kite API"""
        if not self.use_kite:
            return
        
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            time.sleep(self.min_request_interval - time_since_last)
        
        self.last_request_time = time.time()
    
    def load_instruments(self):
        """Load NSE instruments from Kite"""
        if not self.use_kite:
            logger.warning("Cannot load instruments without KiteConnect")
            return False
        
        try:
            self._rate_limit()
            instruments = self.kite.instruments("NSE")
            self.instrument_cache = pd.DataFrame(instruments)
            
            for _, row in self.instrument_cache.iterrows():
                if row['segment'] == 'NSE':
                    self.symbol_token_map[row['tradingsymbol']] = row['instrument_token']
            
            logger.info(f"Loaded {len(self.symbol_token_map)} NSE instruments")
            return True
        except Exception as e:
            logger.error(f"Error loading instruments: {e}")
            return False
    
    def get_historical_data_kite(self, 
                                  symbol: str,
                                  days: int = 200,
                                  interval: str = "day") -> Optional[pd.DataFrame]:
        """
        Fetch historical data from Kite API
        """
        if not self.use_kite:
            return None
        
        if not self.symbol_token_map:
            if not self.load_instruments():
                return None
        
        # Try exact match first
        token = self.symbol_token_map.get(symbol)
        
        # If not found, try with -BE suffix (Book Entry segment)
        if not token and not symbol.endswith('-BE'):
            token = self.symbol_token_map.get(f"{symbol}-BE")
            if token:
                logger.info(f"Found {symbol} in BE segment as {symbol}-BE")
        
        if not token:
            logger.warning(f"Token not found for symbol: {symbol}")
            return None
        
        try:
            self._rate_limit()
            from_date = (datetime.now() - timedelta(days=days + 50)).date()
            to_date = datetime.now().date()
            
            data = self.kite.historical_data(token, from_date, to_date, interval)
            
            if not data:
                return None
            
            df = pd.DataFrame(data)
            
            # Normalize column names (handle case variations)
            df.columns = df.columns.str.lower()
            
            # Ensure datetime index
            if 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date'])
                df.set_index('date', inplace=True)
            elif isinstance(df.index, pd.DatetimeIndex):
                pass  # Already datetime index
            else:
                df.index = pd.to_datetime(df.index)
            
            # Ensure required columns
            required = ['open', 'high', 'low', 'close', 'volume']
            if not all(col in df.columns for col in required):
                logger.error(f"Missing columns for {symbol}: {df.columns.tolist()}")
                return None
            
            # Sort by date
            df.sort_index(inplace=True)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def get_historical_data_by_token(self, 
                                      instrument_token: int,
                                      days: int = 200,
                                      interval: str = "day") -> Optional[pd.DataFrame]:
        """
        Fetch historical data from Kite API using instrument token directly
        Useful for indices where symbol lookup might fail
        """
        if not self.use_kite:
            return None
        
        try:
            self._rate_limit()
            from_date = (datetime.now() - timedelta(days=days + 50)).date()
            to_date = datetime.now().date()
            
            data = self.kite.historical_data(instrument_token, from_date, to_date, interval)
            
            if not data:
                return None
            
            df = pd.DataFrame(data)
            df.columns = df.columns.str.lower()
            
            if 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date'])
                df.set_index('date', inplace=True)
            
            df.sort_index(inplace=True)
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for token {instrument_token}: {e}")
            return None
    
    def scan_symbols(self, 
                     symbols: List[str],
                     min_quality_score: float = 55.0,
                     market_index_symbol: str = "NIFTY 500") -> List[Signal]:
        """
        Scan list of symbols for trading signals with market regime filter
        
        Args:
            symbols: List of trading symbols to scan
            min_quality_score: Minimum quality score to include (0-100)
            market_index_symbol: Market index for regime filter (default: NIFTY 500)
        
        Returns:
            List of Signal objects
        """
        all_signals = []
        
        # Fetch market index data once for regime filtering
        market_data = None
        if self.use_kite:
            try:
                logger.info(f"Fetching market index data for regime filter...")
                
                # Use instrument token directly for indices (more reliable than symbol lookup)
                # Nifty 500 token = 265, Nifty 50 token = 256
                market_index_token = 265  # Nifty 500
                
                market_data = self.get_historical_data_by_token(market_index_token, days=100)
                
                if market_data is not None and not market_data.empty:
                    logger.info(f"✅ Market regime data loaded (Nifty 500, {len(market_data)} days)")
                else:
                    # Fallback to Nifty 50 if Nifty 500 fails
                    logger.info("Trying Nifty 50 as fallback...")
                    market_data = self.get_historical_data_by_token(256, days=100)
                    if market_data is not None and not market_data.empty:
                        logger.info(f"✅ Market regime data loaded (Nifty 50, {len(market_data)} days)")
                
                if market_data is None or market_data.empty:
                    logger.warning("⚠️ Market index data unavailable. Regime filter disabled.")
                    logger.warning("   Scanner will work without market regime filter.")
            except Exception as e:
                logger.warning(f"Failed to fetch market data: {e}. Regime filter disabled.")
        
        logger.info(f"Scanning {len(symbols)} symbols...")
        
        for i, symbol in enumerate(symbols, 1):
            try:
                if i % 50 == 0:
                    logger.info(f"Progress: {i}/{len(symbols)} symbols processed")
                
                # Fetch historical data
                df = self.get_historical_data_kite(symbol)
                
                if df is None or df.empty:
                    continue
                
                # Detect signals with market regime filter
                signals = self.strategy.detect_signals(df, symbol=symbol, market_data=market_data)
                
                # Filter by quality score
                signals = [s for s in signals if s.quality_score >= min_quality_score]
                
                all_signals.extend(signals)
                
            except Exception as e:
                logger.error(f"Error scanning {symbol}: {e}")
                continue
        
        # Sort by quality score (highest first)
        all_signals.sort(key=lambda x: x.quality_score, reverse=True)
        
        logger.info(f"Found {len(all_signals)} signals above quality threshold {min_quality_score}")
        
        return all_signals
    
    def scan_from_csv(self, 
                      csv_path: str,
                      symbol_column: str = "Symbol",
                      min_quality_score: float = 55.0) -> List[Signal]:
        """
        Scan symbols from CSV file
        
        Args:
            csv_path: Path to CSV file with symbols
            symbol_column: Column name containing symbols
            min_quality_score: Minimum quality score
        
        Returns:
            List of Signal objects
        """
        try:
            df = pd.read_csv(csv_path)
            
            if symbol_column not in df.columns:
                logger.error(f"Column '{symbol_column}' not found in CSV. Available: {df.columns.tolist()}")
                return []
            
            symbols = df[symbol_column].dropna().unique().tolist()
            logger.info(f"Loaded {len(symbols)} symbols from {csv_path}")
            
            return self.scan_symbols(symbols, min_quality_score)
            
        except Exception as e:
            logger.error(f"Error loading CSV: {e}")
            return []
    
    def save_signals_to_csv(self, signals: List[Signal], output_path: Optional[str] = None):
        """
        Save signals to CSV file
        """
        if not signals:
            logger.warning("No signals to save")
            return
        
        # Convert signals to DataFrame
        data = []
        for signal in signals:
            data.append({
                'Symbol': signal.symbol,
                'Date': signal.date,
                'Entry_Price': signal.entry_price,
                'Stop_Loss': signal.stop_loss,
                'Target': signal.target,
                'Risk_Reward': signal.risk_reward,
                'Quality_Score': signal.quality_score,
                'ROC': signal.signals.get('roc', 0),
                'RSI': signal.signals.get('rsi', 0),
                'Volume_Ratio': signal.signals.get('volume_ratio', 0),
                'BB_Width_Percentile': signal.signals.get('bb_width_percentile', 0),
                'ATR_Percentile': signal.signals.get('atr_percentile', 0),
                'Notes': signal.notes
            })
        
        df = pd.DataFrame(data)
        
        # Generate output filename if not provided
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"timeless_signals_{timestamp}.csv"
            # Save in timeless directory
            output_path = os.path.join(os.path.dirname(__file__), output_path)
        
        df.to_csv(output_path, index=False)
        logger.info(f"Saved {len(signals)} signals to {output_path}")
        
        return output_path
    
    def print_signals_summary(self, signals: List[Signal], top_n: int = 10):
        """
        Print formatted summary of signals
        """
        if not signals:
            print("\n❌ No signals found")
            return
        
        print(f"\n{'='*80}")
        print(f"TIMELESS MARKET STRATEGY - SIGNAL SUMMARY")
        print(f"{'='*80}")
        print(f"Total Signals: {len(signals)}")
        print(f"\nTop {min(top_n, len(signals))} Signals:")
        print(f"{'-'*80}")
        
        for i, signal in enumerate(signals[:top_n], 1):
            print(f"\n{i}. {signal.symbol} | Quality: {signal.quality_score:.1f}")
            print(f"   Date: {signal.date}")
            print(f"   Entry: ₹{signal.entry_price:.2f} | Stop: ₹{signal.stop_loss:.2f} | Target: ₹{signal.target:.2f}")
            print(f"   Risk:Reward: 1:{signal.risk_reward:.2f} | SL%: {((signal.entry_price - signal.stop_loss) / signal.entry_price * 100):.2f}%")
            print(f"   {signal.notes}")
        
        print(f"\n{'='*80}\n")


def main():
    """
    Main scanning function - can be customized based on requirements
    """
    import json
    
    # Load configuration
    # Uncomment to use config.json:
    # try:
    #     with open('config.json', 'r') as f:
    #         config = json.load(f)
    #     api_key = config.get('api_key')
    #     access_token = config.get('access_token')
    #     symbols_file = config.get('symbols_file', 'data/FNOStock.csv')
    # except:
    #     logger.warning("config.json not found. Using defaults.")
    #     api_key = None
    #     access_token = None
    #     symbols_file = 'data/FNOStock.csv'
    
    # For now, use placeholder values - user should update
    api_key = None
    access_token = None
    symbols_file = None
    
    # Initialize scanner
    scanner = TimelessMarketScanner(
        api_key=api_key,
        access_token=access_token,
        strategy_config={
            'ema_short': 21,
            'ema_long': 55,
            'roc_period': 10,
            'bb_width_percentile': 20,
            'atr_percentile_max': 25,
            'volume_multiplier': 1.5
        }
    )
    
    # Scan from CSV if provided, else use sample symbols
    if symbols_file and os.path.exists(symbols_file):
        signals = scanner.scan_from_csv(symbols_file, min_quality_score=55.0)
    else:
        # Sample scan with popular stocks
        sample_symbols = [
            'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK',
            'HINDUNILVR', 'BHARTIARTL', 'SBIN', 'BAJFINANCE', 'ITC'
        ]
        
        if scanner.use_kite:
            signals = scanner.scan_symbols(sample_symbols, min_quality_score=55.0)
        else:
            logger.warning("Cannot scan without KiteConnect. Please configure API credentials.")
            signals = []
    
    # Display results
    scanner.print_signals_summary(signals, top_n=20)
    
    # Save to CSV
    if signals:
        output_file = scanner.save_signals_to_csv(signals)
        print(f"📊 Results saved to: {output_file}")
    
    return signals


if __name__ == "__main__":
    main()

