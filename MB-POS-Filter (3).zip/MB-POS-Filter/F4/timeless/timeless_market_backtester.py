"""
Timeless Market Strategy Backtester
=====================================
Backtests the Contraction → Expansion in Uptrend strategy
Implements the 4 enduring principles of market behavior

Strategy:
- Wait for contraction (BB width/ATR low)
- Enter on expansion breakout with volume
- Exit on climax or trailing stop (EMA)

Author: Timeless Market Strategy
Date: 2025-01-XX
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import warnings
import time
import json
import os
import sys
import pickle
import hashlib
from typing import Dict, List, Optional, Tuple
from pathlib import Path

from timeless_market_strategy import TimelessMarketStrategy, Signal

warnings.filterwarnings('ignore')

import logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# =============================================================================
# CONFIGURATION SECTION
# =============================================================================

# API Configuration
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "dU6sC06YhCWvLLhK3l7ANE0gtz6FTIkZ"

# Market Index for Regime Filter
MARKET_INDEX_SYMBOL = "NIFTY 500"  # Will use Nifty 500 for market regime
MARKET_INDEX_INSTRUMENT = 265  # Nifty 500 instrument token

# Backtest Period
BACKTEST_START_DATE = "2022-01-01"
BACKTEST_END_DATE = datetime.now().strftime("%Y-%m-%d")
INTERVAL = 'day'  # Daily data for intraday signals

# Portfolio Configuration
INITIAL_CAPITAL = 1000000  # Starting capital (₹10 Lakhs)
RISK_PER_TRADE = 0.01      # 1% risk per trade (adjusted for ATR-based wider stops)
MAX_POSITIONS = 10         # Maximum concurrent positions

# Transaction Costs (Zerodha charges)
STATUTORY_COSTS_PCT = 0.00239  # 0.239% (STT, stamp duty, exchange charges, DP)
MARKET_IMPACT_PCT = 0.003      # 0.3% (market impact)
BID_ASK_SPREAD_PCT = 0.002     # 0.2% (spread)
SLIPPAGE_PCT = 0.002           # 0.2% (execution variance)
TOTAL_COST_PER_TRADE = STATUTORY_COSTS_PCT + MARKET_IMPACT_PCT + BID_ASK_SPREAD_PCT + SLIPPAGE_PCT  # ~1%

# Strategy Parameters
STRATEGY_CONFIG = {
    'ema_short': 21,
    'ema_long': 55,
    'roc_period': 10,
    'bb_width_percentile': 20,
    'atr_percentile_max': 25,
    'volume_multiplier': 1.5,
    'stop_atr_multiplier': 1.8,  # Wider ATR-based stops (was 1.5)
    'use_ema_trailing': True
}

# Signal Filters
MIN_QUALITY_SCORE = 55.0  # Lower threshold - more opportunities while filtering very worst setups
MAX_POSITION_AGE_DAYS = 60  # Maximum holding period (exit if still holding)

# Output Directories
OUTPUT_DIR = os.path.join(os.path.dirname(__file__), 'backtest_results')
CACHE_DIR = os.path.join(os.path.dirname(__file__), 'cache')

# API Rate Limiting
API_CALL_DELAY = 0.35
MAX_RETRIES = 3
RETRY_DELAY = 1

# Data Files
SYMBOL_COLUMN = 'Symbol'
UNIVERSE_FILE = None  # Set in main() based on argument

# =============================================================================
# BACKTESTER CLASS
# =============================================================================

class TimelessMarketBacktester:
    """
    Backtester for Timeless Market Strategy
    """
    
    def __init__(self, api_key, access_token):
        """Initialize backtester"""
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Setup directories
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        os.makedirs(CACHE_DIR, exist_ok=True)
        
        # Initialize strategy
        self.strategy = TimelessMarketStrategy(STRATEGY_CONFIG)
        
        # Storage for backtest results
        self.trade_log = []
        self.daily_equity = []
        
        print("="*80)
        print("🔬 TIMELESS MARKET STRATEGY BACKTESTER")
        print("="*80)
        print(f"📅 Period: {BACKTEST_START_DATE} to {BACKTEST_END_DATE}")
        print(f"💼 Max Positions: {MAX_POSITIONS}")
        print(f"💰 Initial Capital: ₹{INITIAL_CAPITAL:,.0f}")
        print(f"💸 Transaction Costs: {TOTAL_COST_PER_TRADE*100:.2f}% per round trip")
        print(f"📊 Min Quality Score: {MIN_QUALITY_SCORE}")
        print("="*80)
    
    # =========================================================================
    # INFRASTRUCTURE
    # =========================================================================
    
    def _rate_limit_delay(self):
        """Rate limiting"""
        time.sleep(API_CALL_DELAY)
    
    def _api_call_with_retry(self, func, *args, **kwargs):
        """API call with retry logic"""
        for attempt in range(MAX_RETRIES):
            try:
                self._rate_limit_delay()
                return func(*args, **kwargs)
            except Exception as e:
                if "Too many requests" in str(e) or "rate limit" in str(e).lower():
                    if attempt < MAX_RETRIES - 1:
                        time.sleep(RETRY_DELAY * (attempt + 1))
                        continue
                raise e
        return None
    
    def get_instrument_token(self, tradingsymbol):
        """Get instrument token"""
        try:
            instruments = self._api_call_with_retry(self.kite.instruments, "NSE")
            if instruments:
                instrument = next((item for item in instruments 
                                 if item['tradingsymbol'] == tradingsymbol), None)
                return instrument['instrument_token'] if instrument else None
            return None
        except:
            return None
    
    def get_historical_data(self, instrument_token, from_date, to_date, interval='day'):
        """Fetch historical data"""
        try:
            data = self._api_call_with_retry(
                self.kite.historical_data,
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            if data is None or not data:
                return pd.DataFrame()
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date'])
                if df['date'].dt.tz is not None:
                    df['date'] = df['date'].dt.tz_localize(None)
                df.set_index('date', inplace=True)
                # Normalize column names
                df.columns = df.columns.str.lower()
            return df
        except Exception as e:
            logger.error(f"Error fetching data: {e}")
            return pd.DataFrame()
    
    # =========================================================================
    # POSITION MANAGEMENT
    # =========================================================================
    
    def calculate_position_size(self, entry_price, stop_loss, available_capital):
        """Calculate position size based on risk per trade"""
        risk_amount = available_capital * RISK_PER_TRADE
        risk_per_share = abs(entry_price - stop_loss)
        
        if risk_per_share == 0:
            return 0
        
        quantity = int(risk_amount / risk_per_share)
        max_affordable = int(available_capital / entry_price)
        quantity = min(quantity, max_affordable)
        
        return max(1, quantity)
    
    def apply_costs(self, price, quantity, is_entry=True):
        """Apply transaction costs"""
        if is_entry:
            adjusted_price = price * (1 + TOTAL_COST_PER_TRADE)
        else:
            adjusted_price = price * (1 - TOTAL_COST_PER_TRADE)
        return adjusted_price
    
    # =========================================================================
    # BACKTEST ENGINE
    # =========================================================================
    
    def _get_cache_key(self, symbols_list):
        """Generate cache key based on symbols, dates, and interval"""
        cache_str = f"{sorted(symbols_list)}_{BACKTEST_START_DATE}_{BACKTEST_END_DATE}_{INTERVAL}"
        return hashlib.md5(cache_str.encode()).hexdigest()
    
    def load_backtest_data(self, symbols_list):
        """
        Load historical data for all symbols + market index (with caching)
        Returns: Tuple[Dict[str, pd.DataFrame], pd.DataFrame] (stocks_data, market_data)
        """
        print(f"\n📥 Loading historical data for {len(symbols_list)} symbols + market index...")
        
        # Check cache first
        cache_key = self._get_cache_key(symbols_list)
        cache_file = os.path.join(CACHE_DIR, f'backtest_data_{cache_key}.pkl')
        
        if os.path.exists(cache_file):
            try:
                print("   💾 Loading from cache...")
                with open(cache_file, 'rb') as f:
                    cached_data = pickle.load(f)
                    # Check if cache has market data (new format)
                    if isinstance(cached_data, tuple) and len(cached_data) == 2:
                        stocks_data, market_data = cached_data
                        print(f"✅ Loaded {len(stocks_data)} symbols + market index from cache")
                        return stocks_data, market_data
                    else:
                        # Old cache format without market data
                        print("   Cache is old format, fetching fresh data...")
            except Exception as e:
                logger.warning(f"Cache load failed: {e}. Fetching fresh data...")
        
        # Fetch fresh data
        stocks_data = {}
        from_date = datetime.strptime(BACKTEST_START_DATE, "%Y-%m-%d").date()
        to_date = datetime.strptime(BACKTEST_END_DATE, "%Y-%m-%d").date()
        
        # First, fetch market index data (Nifty 500)
        print(f"   Fetching {MARKET_INDEX_SYMBOL} data for market regime...")
        market_data = self.get_historical_data(MARKET_INDEX_INSTRUMENT, from_date, to_date, INTERVAL)
        if market_data.empty:
            logger.warning(f"Failed to fetch {MARKET_INDEX_SYMBOL} data. Market regime filter will be disabled.")
            market_data = None
        
        for i, symbol in enumerate(symbols_list, 1):
            if i % 50 == 0:
                print(f"   Progress: {i}/{len(symbols_list)}")
            
            token = self.get_instrument_token(symbol)
            if not token:
                continue
            
            df = self.get_historical_data(token, from_date, to_date, INTERVAL)
            if not df.empty and len(df) >= 100:  # Need enough data
                stocks_data[symbol] = df
        
        # Save to cache (both stocks and market data)
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump((stocks_data, market_data), f)
            print(f"💾 Cached data for {len(stocks_data)} symbols + market index")
        except Exception as e:
            logger.warning(f"Cache save failed: {e}")
        
        print(f"✅ Loaded data for {len(stocks_data)} symbols + market index")
        return stocks_data, market_data
    
    def run_backtest(self, stocks_data, market_data=None):
        """
        Main backtesting engine
        
        Args:
            stocks_data: Dict of stock DataFrames
            market_data: DataFrame for market index (Nifty 500) for regime filter
        """
        print("\n" + "="*80)
        print("🚀 STARTING TIMELESS MARKET STRATEGY BACKTEST")
        print("="*80)
        
        if not stocks_data:
            print("❌ No data available")
            return pd.DataFrame()
        
        # Pre-calculate indicators for all symbols (ONE TIME - huge speedup!)
        print("⚙️  Pre-calculating indicators for all symbols...")
        stocks_data_with_indicators = {}
        for i, (symbol, df) in enumerate(stocks_data.items(), 1):
            if i % 50 == 0:
                print(f"   Progress: {i}/{len(stocks_data)}")
            df_with_indicators = self.strategy.calculate_indicators(df)
            if not df_with_indicators.empty:
                stocks_data_with_indicators[symbol] = df_with_indicators
        print(f"✅ Pre-calculated indicators for {len(stocks_data_with_indicators)} symbols")
        
        # Use the pre-calculated data
        stocks_data = stocks_data_with_indicators
        
        # Initialize tracking
        portfolio_value = INITIAL_CAPITAL
        positions = {}  # {symbol: {entry_date, entry_price, stop_loss, target, quantity, quality_score}}
        
        # Get all trading dates
        all_dates = set()
        for df in stocks_data.values():
            all_dates.update(df.index)
        
        trading_dates = sorted(all_dates)
        trading_dates = [d for d in trading_dates 
                        if d >= datetime.strptime(BACKTEST_START_DATE, "%Y-%m-%d")
                        and d <= datetime.strptime(BACKTEST_END_DATE, "%Y-%m-%d")]
        
        print(f"📅 Processing {len(trading_dates)} trading days")
        
        # Main backtest loop
        for i, current_date in enumerate(trading_dates):
            if i % 50 == 0:
                print(f"   Progress: {current_date.strftime('%Y-%m-%d')} ({i}/{len(trading_dates)}) | "
                      f"Positions: {len(positions)} | Value: ₹{portfolio_value:,.0f}")
            
            # Check exits first
            positions_to_exit = []
            for symbol, pos in positions.items():
                if symbol not in stocks_data:
                    continue
                
                df = stocks_data[symbol]
                df_filtered = df[df.index <= current_date]
                if df_filtered.empty:
                    continue
                
                current_price = df_filtered['close'].iloc[-1]
                entry_price = pos['entry_price']
                stop_loss = pos['stop_loss']
                target = pos['target']
                
                # === TRAILING STOP LOGIC: 2.5x ATR (wider - let winners run) ===
                # Calculate ATR for trailing
                if len(df_filtered) >= 14:
                    current_atr = df_filtered['atr'].iloc[-1]
                    # Trail with 2.5x ATR below current price (wider than before)
                    atr_trailing_stop = current_price - (current_atr * 2.5)
                    
                    # Only move stop up, never down
                    if atr_trailing_stop > stop_loss:
                        stop_loss = atr_trailing_stop
                
                # Exit conditions
                exit_reason = None
                exit_price = current_price
                
                # 0. 3-DAY KILL SWITCH: Exit failed breakouts early
                # If down 3% or more within first 3 days → Exit at -3% level
                # Prevents small losses from becoming big losses (caps loss at 3%)
                holding_days = (current_date - pos['entry_date']).days
                pnl_pct = ((current_price - entry_price) / entry_price) * 100
                
                if holding_days <= 3 and pnl_pct <= -3.0:
                    exit_reason = "Failed breakout (3-day rule)"
                    # Exit at -3% level, not at current market (prevents gap-down disasters)
                    exit_price = entry_price * 0.97
                
                # 1. Stop loss hit (now includes trailing stop)
                elif current_price <= stop_loss:
                    exit_reason = "Stop Loss"
                    exit_price = stop_loss
                
                # 2. Target hit
                elif current_price >= target:
                    exit_reason = "Target Hit"
                    exit_price = target
                
                # 3. Check climax exit using strategy
                elif len(df_filtered) >= 100:
                    # Use pre-calculated indicators (no recalculation needed)
                    latest_ind = df_filtered.iloc[-1] if not df_filtered.empty else None
                    if latest_ind is not None:
                        should_exit, exit_r = self.strategy.check_exit(
                            df_filtered, entry_price, pos['entry_date']
                        )
                        if should_exit:
                            exit_reason = exit_r
                            exit_price = current_price
                
                # 4. Max holding period (only exit if in profit or at breakeven)
                # Note: holding_days already calculated above for 3-day rule
                if holding_days >= MAX_POSITION_AGE_DAYS and not exit_reason:
                    # Don't exit losers at max period - let them run or hit stop
                    if current_price >= entry_price * 0.98:  # Only exit if not down more than 2%
                        exit_reason = "Max Holding Period"
                        exit_price = current_price
                
                # Execute exit
                if exit_reason:
                    exit_price = self.apply_costs(exit_price, pos['quantity'], is_entry=False)
                    pnl = (exit_price - entry_price) * pos['quantity']
                    pnl_pct = (exit_price - entry_price) / entry_price * 100
                    
                    self.trade_log.append({
                        'symbol': symbol,
                        'entry_date': pos['entry_date'].strftime('%Y-%m-%d'),
                        'exit_date': current_date.strftime('%Y-%m-%d'),
                        'entry_price': round(entry_price, 2),
                        'exit_price': round(exit_price, 2),
                        'stop_loss': round(pos['stop_loss'], 2),
                        'target': round(pos['target'], 2),
                        'quantity': pos['quantity'],
                        'pnl': round(pnl, 2),
                        'pnl_pct': round(pnl_pct, 2),
                        'exit_reason': exit_reason,
                        'holding_days': holding_days,
                        'quality_score': pos['quality_score']
                    })
                    
                    portfolio_value += pnl
                    positions_to_exit.append(symbol)
            
            # Remove exited positions
            for symbol in positions_to_exit:
                del positions[symbol]
            
            # Check for new entries (only if we have capacity)
            if len(positions) < MAX_POSITIONS:
                for symbol, df in stocks_data.items():
                    if symbol in positions:
                        continue
                    
                    df_filtered = df[df.index <= current_date]
                    if len(df_filtered) < 100:  # Need enough data
                        continue
                    
                    # Detect signals (using pre-calculated indicators + market regime filter)
                    signals = self.strategy.detect_signals(df_filtered, symbol=symbol, market_data=market_data)
                    # Note: detect_signals will use pre-calculated indicators since df_filtered already has them
                
                    if signals:
                        signal = signals[0]  # Take best signal
                        if signal.quality_score < MIN_QUALITY_SCORE:
                            continue
                        
                        # Calculate position size
                        available_capital = portfolio_value / MAX_POSITIONS
                        quantity = self.calculate_position_size(
                            signal.entry_price, signal.stop_loss, available_capital
                        )
                        
                        if quantity > 0:
                            entry_price = self.apply_costs(signal.entry_price, quantity, is_entry=True)
                            
                            positions[symbol] = {
                                'entry_date': current_date,
                                'entry_price': entry_price,
                                'stop_loss': signal.stop_loss,
                                'target': signal.target,
                                'quantity': quantity,
                                'quality_score': signal.quality_score
                            }
                            
                            break  # Only take one signal per day
            
            # Track equity
            current_equity = portfolio_value
            # Add unrealized P&L
            for symbol, pos in positions.items():
                if symbol in stocks_data:
                    df = stocks_data[symbol]
                    df_filtered = df[df.index <= current_date]
                    if not df_filtered.empty:
                        current_price = df_filtered['close'].iloc[-1]
                        unrealized_pnl = (current_price - pos['entry_price']) * pos['quantity']
                        current_equity += unrealized_pnl
            
            self.daily_equity.append({
                'date': current_date,
                'equity': current_equity,
                'positions': len(positions)
            })
        
        print("\n✅ Backtest complete!")
        return self._calculate_results()
    
    def _calculate_results(self):
        """Calculate backtest results"""
        if not self.trade_log:
            print("❌ No trades executed")
            return pd.DataFrame()
        
        trades_df = pd.DataFrame(self.trade_log)
        equity_df = pd.DataFrame(self.daily_equity)
        equity_df.set_index('date', inplace=True)
        
        # Calculate metrics
        total_trades = len(trades_df)
        winning_trades = len(trades_df[trades_df['pnl'] > 0])
        losing_trades = len(trades_df[trades_df['pnl'] < 0])
        win_rate = winning_trades / total_trades if total_trades > 0 else 0
        
        total_pnl = trades_df['pnl'].sum()
        avg_win = trades_df[trades_df['pnl'] > 0]['pnl'].mean() if winning_trades > 0 else 0
        avg_loss = trades_df[trades_df['pnl'] < 0]['pnl'].mean() if losing_trades > 0 else 0
        
        gross_profit = trades_df[trades_df['pnl'] > 0]['pnl'].sum() if winning_trades > 0 else 0
        gross_loss = abs(trades_df[trades_df['pnl'] < 0]['pnl'].sum()) if losing_trades > 0 else 1
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0
        
        # Drawdown
        equity_df['equity'] = equity_df['equity'].astype(float)
        equity_df['cummax'] = equity_df['equity'].expanding().max()
        equity_df['drawdown'] = equity_df['equity'] - equity_df['cummax']
        max_drawdown = abs(equity_df['drawdown'].min())
        max_drawdown_pct = (max_drawdown / equity_df['cummax'].max()) * 100 if equity_df['cummax'].max() > 0 else 0
        
        # Sharpe ratio
        if len(equity_df) > 1:
            returns = equity_df['equity'].pct_change().dropna()
            if len(returns) > 0 and returns.std() > 0:
                sharpe_ratio = returns.mean() / returns.std() * np.sqrt(252)
            else:
                sharpe_ratio = 0
        else:
            sharpe_ratio = 0
        
        # CAGR
        if len(equity_df) > 1:
            first_value = equity_df['equity'].iloc[0]
            last_value = equity_df['equity'].iloc[-1]
            total_return = ((last_value - INITIAL_CAPITAL) / INITIAL_CAPITAL) * 100
            
            days = (equity_df.index[-1] - equity_df.index[0]).days
            years = days / 365.25
            if years > 0:
                cagr = ((last_value / INITIAL_CAPITAL) ** (1 / years) - 1) * 100
            else:
                cagr = 0
        else:
            total_return = 0
            cagr = 0
        
        avg_holding_days = trades_df['holding_days'].mean()
        
        # Print results
        print("\n" + "="*80)
        print("📊 BACKTEST RESULTS")
        print("="*80)
        print(f"Total Trades:        {total_trades}")
        print(f"Winning Trades:      {winning_trades}")
        print(f"Losing Trades:       {losing_trades}")
        print(f"Win Rate:            {win_rate*100:.2f}%")
        print(f"\n💰 P&L METRICS")
        print(f"Total P&L:           ₹{total_pnl:,.2f}")
        print(f"Total Return:        {total_return:.2f}%")
        print(f"CAGR:                {cagr:.2f}%")
        print(f"Average Win:         ₹{avg_win:,.2f}")
        print(f"Average Loss:        ₹{avg_loss:,.2f}")
        print(f"Profit Factor:       {profit_factor:.2f}")
        print(f"\n📉 RISK METRICS")
        print(f"Max Drawdown:        ₹{max_drawdown:,.2f}")
        print(f"Max Drawdown %:      {max_drawdown_pct:.2f}%")
        print(f"Sharpe Ratio:        {sharpe_ratio:.2f}")
        print(f"\n⏱️  OTHER METRICS")
        print(f"Avg Holding Days:    {avg_holding_days:.1f}")
        print("="*80)
        
        # Save results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save trades
        trades_file = os.path.join(OUTPUT_DIR, f'timeless_trades_{timestamp}.csv')
        trades_df.to_csv(trades_file, index=False)
        print(f"\n💾 Trades saved to: {trades_file}")
        
        # Save equity curve
        equity_file = os.path.join(OUTPUT_DIR, f'timeless_equity_{timestamp}.csv')
        equity_df.to_csv(equity_file)
        print(f"💾 Equity curve saved to: {equity_file}")
        
        return trades_df


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Main execution function"""
    import logging
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    global logger
    logger = logging.getLogger(__name__)
    
    try:
        # Check for universe file argument
        if len(sys.argv) > 1:
            universe_file = sys.argv[1]
        else:
            # Simple path: just check data/ folder from workspace root
            universe_file = "data/nifty500.csv"
        
        if not os.path.exists(universe_file):
            print(f"❌ Universe file not found: {universe_file}")
            print(f"Usage: python timeless_market_backtester.py <symbols.csv>")
            print(f"Or place nifty500.csv in the data/ folder")
            return
        
        # Load universe
        print(f"\n📁 Loading universe from: {universe_file}")
        try:
            universe_df = pd.read_csv(universe_file)
            if SYMBOL_COLUMN not in universe_df.columns:
                # Try common column names
                for col in ['Symbol', 'SYMBOL', 'symbol', 'Stock', 'STOCK']:
                    if col in universe_df.columns:
                        universe_df = universe_df.rename(columns={col: SYMBOL_COLUMN})
                        break
                else:
                    print(f"❌ Symbol column not found. Available: {universe_df.columns.tolist()}")
                    return
            
            symbols_list = universe_df[SYMBOL_COLUMN].dropna().unique().tolist()
            print(f"✅ Loaded {len(symbols_list)} symbols")
        except Exception as e:
            print(f"❌ Error loading file: {e}")
            return
        
        # Initialize backtester
        backtester = TimelessMarketBacktester(API_KEY, ACCESS_TOKEN)
        
        # Load historical data (stocks + market index for regime filter)
        stocks_data, market_data = backtester.load_backtest_data(symbols_list[:200])  # Limit for testing
        
        # Run backtest with market regime filter
        results_df = backtester.run_backtest(stocks_data, market_data)
        
        if not results_df.empty:
            print(f"\n✅ Backtest completed successfully!")
            print(f"   Total trades: {len(results_df)}")
        else:
            print("\n⚠️ Backtest completed but no trades were executed")
        
    except KeyboardInterrupt:
        print("\n\n⚠️ Backtest interrupted by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
