"""
Momentum Breakout Scanner (Stan Weinstein / Shake Pryzby Style)
================================================================

Scans for early-stage breakout opportunities with:
1. Price near 3-month highs (within 5% of 60-day high)
2. Weekly performance ≥ +10%
3. Strong liquidity (avg turnover > ₹5-10 crore)
4. Volatility filter (ATR% > 2-3%)

Based on Stage Analysis / Momentum Breakout methodology
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import pandas_ta as ta
from datetime import datetime, timedelta
import logging
import os
import pickle
import time
from typing import Optional, List, Dict, Tuple
from dataclasses import dataclass
import openpyxl
from openpyxl.styles import PatternFill, Font, Alignment

# ==============================================================================
# Configuration
# ==============================================================================

# --- Logging Setup ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Kite Connect API Credentials ---
# IMPORTANT: Replace with your actual credentials or use environment variables
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "ag9KpKehMcYZILhTs8STLPKcf9dAQxyT"

# --- Scanner Parameters ---
@dataclass
class ScannerConfig:
    """Configuration for momentum breakout scanner"""
    # Price proximity to 3-month high (60 trading days)
    lookback_days: int = 60
    near_high_threshold: float = 0.95  # Within 5% of high
    
    # Weekly momentum (5 trading days)
    weekly_days: int = 5
    weekly_gain_threshold: float = 0.10  # 10% gain
    
    # Liquidity filter (in Rupees)
    min_avg_turnover: float = 5e7  # 5 crore minimum
    turnover_lookback: int = 20
    
    # ATR volatility filter
    atr_period: int = 14
    min_atr_percent: float = 2.0  # 2% minimum
    max_atr_percent: float = 15.0  # 15% maximum (filter out extreme volatility)
    
    # Historical data lookback (need extra for indicators)
    # Note: This is CALENDAR days. After weekends/holidays, you get ~50-60% as trading days
    # So 180 calendar days ≈ 90-110 trading days (enough for 60-day lookback + buffer)
    total_lookback_days: int = 180
    
    # API rate limiting
    api_delay_seconds: float = 0.35
    max_retries: int = 3
    
    # Output configuration
    output_file: str = "momentum_breakout_signals_{timestamp}.xlsx"
    min_signals_for_export: int = 1

config = ScannerConfig()

# --- Caching Setup ---
# Get script directory to create cache relative to script location, not working directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(SCRIPT_DIR, "MB_Breakout_Cache")
INSTRUMENTS_CACHE_FILE = os.path.join(CACHE_DIR, "nse_instruments.pkl")
HISTORICAL_CACHE_DIR = os.path.join(CACHE_DIR, "historical")
os.makedirs(HISTORICAL_CACHE_DIR, exist_ok=True)
os.makedirs(CACHE_DIR, exist_ok=True)

# --- Custom Universe ---
UNIVERSE_CSV = os.path.join(SCRIPT_DIR, "..", "..", "..", "data", "29oct2025_sector_marketcap_freefloat_20251101_150338.csv")

# ==============================================================================
# Data Classes
# ==============================================================================

@dataclass
class BreakoutSignal:
    """Data class for breakout signals"""
    symbol: str
    date: datetime
    close_price: float
    
    # Price metrics
    distance_from_3m_high_pct: float
    three_month_high: float
    
    # Momentum metrics
    weekly_return_pct: float
    
    # Liquidity metrics
    avg_turnover_cr: float
    
    # Volatility metrics
    atr_percent: float
    atr_value: float
    
    # Volume confirmation
    volume_ratio: float  # Current vs 20-day average
    
    # Additional metrics
    price_above_50ma: bool
    price_above_200ma: bool
    rs_rating: float  # Relative strength vs broader market (0-100)
    
    # Scoring
    breakout_score: float  # Composite score (0-100)
    
    def __repr__(self):
        return f"BreakoutSignal({self.symbol}, Score={self.breakout_score:.1f}, Weekly={self.weekly_return_pct:.1f}%)"

# ==============================================================================
# Helper Functions
# ==============================================================================

def load_nse_instruments(kite_instance):
    """Loads NSE instruments from cache or fetches from API."""
    if os.path.exists(INSTRUMENTS_CACHE_FILE):
        try:
            with open(INSTRUMENTS_CACHE_FILE, "rb") as f:
                instruments = pickle.load(f)
            logger.info(f"Loaded NSE instruments from cache: {INSTRUMENTS_CACHE_FILE}")
            if isinstance(instruments, list) and len(instruments) > 0 and 'instrument_token' in instruments[0]:
                return instruments
            else:
                logger.warning("Cached instruments file seems invalid. Refetching.")
                os.remove(INSTRUMENTS_CACHE_FILE)
        except Exception as e:
            logger.error(f"Error loading instruments from cache: {e}. Refetching.")
            if os.path.exists(INSTRUMENTS_CACHE_FILE):
                os.remove(INSTRUMENTS_CACHE_FILE)
    
    logger.info("Fetching NSE instruments from Kite API...")
    try:
        instruments = kite_instance.instruments(exchange="NSE")
        with open(INSTRUMENTS_CACHE_FILE, "wb") as f:
            pickle.dump(instruments, f)
        logger.info(f"Cached NSE instruments to {INSTRUMENTS_CACHE_FILE}")
        return instruments
    except Exception as e:
        logger.error(f"Failed to fetch NSE instruments from API: {e}")
        raise

def load_universe_symbols():
    """Loads stock symbols from the custom universe CSV file."""
    if not os.path.exists(UNIVERSE_CSV):
        logger.error(f"Universe CSV not found: {UNIVERSE_CSV}")
        raise FileNotFoundError(f"Universe CSV not found: {UNIVERSE_CSV}")
    try:
        df = pd.read_csv(UNIVERSE_CSV)
        if 'Symbol' not in df.columns:
            logger.error("Universe CSV must have a 'Symbol' column.")
            raise ValueError("Universe CSV must have a 'Symbol' column.")
        symbols = df['Symbol'].unique().tolist()
        logger.info(f"Loaded {len(symbols)} unique symbols from {UNIVERSE_CSV}")
        return symbols
    except Exception as e:
        logger.error(f"Error reading Universe CSV {UNIVERSE_CSV}: {e}")
        raise

def get_historical_data_cached(kite_instance, symbol, token, from_date, to_date, interval="day"):
    """Fetches historical data using caching."""
    from_date_str = from_date.strftime('%Y%m%d')
    to_date_str = to_date.strftime('%Y%m%d')
    cache_file = os.path.join(HISTORICAL_CACHE_DIR, f"{symbol}_{token}_{from_date_str}_{to_date_str}_{interval}.pkl")
    
    if os.path.exists(cache_file):
        try:
            with open(cache_file, "rb") as f:
                data = pickle.load(f)
            logger.info(f"Loading historical data for {symbol} from cache.")
            if isinstance(data, list):
                return data
            else:
                logger.warning(f"Invalid data format in cache file {cache_file}. Refetching.")
                os.remove(cache_file)
        except Exception as e:
            logger.warning(f"Could not load {symbol} from cache: {e}. Refetching.")
            if os.path.exists(cache_file):
                os.remove(cache_file)
    
    logger.info(f"Fetching historical data for {symbol} from Kite API...")
    try:
        time.sleep(config.api_delay_seconds)
        data = kite_instance.historical_data(
            instrument_token=token,
            from_date=from_date,
            to_date=to_date,
            interval=interval
        )
        if data:
            with open(cache_file, "wb") as f:
                pickle.dump(data, f)
            logger.info(f"Cached historical data for {symbol}")
        else:
            logger.info(f"No data returned for {symbol}. Not caching.")
        return data
    except Exception as e:
        logger.error(f"Error fetching historical data for {symbol} (Token: {token}): {e}")
        return []

def calculate_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    """Calculate Average True Range using pandas_ta"""
    atr = ta.atr(high=df['high'], low=df['low'], close=df['close'], length=period)
    return atr

def calculate_moving_averages(df: pd.DataFrame) -> Tuple[pd.Series, pd.Series]:
    """Calculate 50-day and 200-day moving averages"""
    ma_50 = df['close'].rolling(window=50).mean()
    ma_200 = df['close'].rolling(window=200).mean()
    return ma_50, ma_200

def calculate_relative_strength(df: pd.DataFrame, market_df: pd.DataFrame) -> float:
    """
    Calculate relative strength rating (0-100)
    Compares stock performance vs market over multiple timeframes
    """
    if df is None or market_df is None or len(df) < 60 or len(market_df) < 60:
        return 50.0  # Neutral if insufficient data
    
    try:
        # Align dates
        common_dates = df.index.intersection(market_df.index)
        if len(common_dates) < 60:
            return 50.0
        
        stock_prices = df.loc[common_dates, 'close']
        market_prices = market_df.loc[common_dates, 'close']
        
        # Calculate returns over multiple periods
        periods = [5, 10, 20, 60]
        rs_scores = []
        
        for period in periods:
            if len(stock_prices) < period:
                continue
            stock_return = (stock_prices.iloc[-1] / stock_prices.iloc[-period] - 1) * 100
            market_return = (market_prices.iloc[-1] / market_prices.iloc[-period] - 1) * 100
            
            # Relative performance
            relative_perf = stock_return - market_return
            rs_scores.append(relative_perf)
        
        if not rs_scores:
            return 50.0
        
        # Weighted average (more weight to recent periods)
        weights = np.array([0.4, 0.3, 0.2, 0.1])[:len(rs_scores)]
        avg_rs = np.average(rs_scores, weights=weights)
        
        # Convert to 0-100 scale (assuming +/- 50% relative performance as extremes)
        rs_rating = 50 + (avg_rs * 1.0)  # Scale factor
        rs_rating = max(0, min(100, rs_rating))  # Clamp to 0-100
        
        return rs_rating
    except Exception as e:
        logger.warning(f"Error calculating relative strength: {e}")
        return 50.0

def calculate_breakout_score(signal: BreakoutSignal) -> float:
    """
    Calculate composite breakout score (0-100)
    Higher score = stronger breakout setup
    """
    score = 0.0
    
    # 1. Proximity to 3-month high (0-25 points)
    # Closer to high = better
    proximity_score = (1 - signal.distance_from_3m_high_pct / 100) * 25
    score += proximity_score
    
    # 2. Weekly momentum (0-25 points)
    # 10% = 25 points, 20% = 35 points (bonus), capped at 35
    momentum_score = min(35, (signal.weekly_return_pct / 10) * 25)
    score += momentum_score
    
    # 3. Liquidity (0-15 points)
    # Scale: 5cr = 15 points, 50cr = 30 points (bonus), capped at 30
    liquidity_score = min(30, (signal.avg_turnover_cr / 5) * 15)
    score += liquidity_score
    
    # 4. ATR% (0-10 points)
    # Ideal range: 3-8%, outside gets penalty
    if 3 <= signal.atr_percent <= 8:
        atr_score = 10
    elif 2 <= signal.atr_percent <= 10:
        atr_score = 7
    else:
        atr_score = 3
    score += atr_score
    
    # 5. Volume confirmation (0-10 points)
    # Volume ratio > 1.5 = good confirmation
    if signal.volume_ratio >= 2.0:
        volume_score = 10
    elif signal.volume_ratio >= 1.5:
        volume_score = 7
    elif signal.volume_ratio >= 1.0:
        volume_score = 4
    else:
        volume_score = 0
    score += volume_score
    
    # 6. Moving average alignment (0-10 points)
    ma_score = 0
    if signal.price_above_50ma:
        ma_score += 5
    if signal.price_above_200ma:
        ma_score += 5
    score += ma_score
    
    # 7. Relative strength (0-15 points)
    # RS > 60 = strong, RS > 80 = exceptional
    rs_score = min(15, max(0, (signal.rs_rating - 50) / 50 * 15))
    score += rs_score
    
    # Normalize to 0-100 (theoretical max is ~135 with bonuses, typical is 0-100)
    normalized_score = min(100, score)
    
    return normalized_score

# ==============================================================================
# Main Scanner Logic
# ==============================================================================

def scan_stock_for_breakout(df: pd.DataFrame, symbol: str, market_df: Optional[pd.DataFrame] = None) -> Optional[BreakoutSignal]:
    """
    Scan a single stock for momentum breakout signal
    
    Returns BreakoutSignal if all conditions met, None otherwise
    """
    try:
        # Need at least 60 trading days for 60-day lookback calculation
        MIN_REQUIRED_DAYS = 60
        if df is None or len(df) < MIN_REQUIRED_DAYS:
            return None
        
        # Ensure data is sorted
        df = df.sort_index()
        
        # Get latest data point
        latest = df.iloc[-1]
        current_date = df.index[-1]
        current_close = latest['close']
        
        # 1. Check price near 3-month high (60 trading days)
        if len(df) < config.lookback_days:
            return None
        
        lookback_df = df.iloc[-config.lookback_days:]
        three_month_high = lookback_df['high'].max()
        
        distance_from_high_pct = ((three_month_high - current_close) / three_month_high) * 100
        
        if distance_from_high_pct > (100 - config.near_high_threshold * 100):
            # Not within 5% of 3-month high
            return None
        
        # 2. Check weekly performance (5 trading days)
        if len(df) < config.weekly_days:
            return None
        
        weekly_start_price = df.iloc[-(config.weekly_days + 1)]['close']
        weekly_return_pct = ((current_close - weekly_start_price) / weekly_start_price) * 100
        
        if weekly_return_pct < (config.weekly_gain_threshold * 100):
            # Weekly gain less than 10%
            return None
        
        # 3. Check liquidity (average turnover)
        if len(df) < config.turnover_lookback:
            return None
        
        turnover_df = df.iloc[-config.turnover_lookback:]
        avg_turnover = (turnover_df['close'] * turnover_df['volume']).mean()
        avg_turnover_cr = avg_turnover / 1e7  # Convert to crores
        
        if avg_turnover < config.min_avg_turnover:
            # Insufficient liquidity
            return None
        
        # 4. Check ATR% (volatility filter)
        atr_series = calculate_atr(df, period=config.atr_period)
        if atr_series is None or pd.isna(atr_series.iloc[-1]):
            return None
        
        atr_value = atr_series.iloc[-1]
        atr_percent = (atr_value / current_close) * 100
        
        if atr_percent < config.min_atr_percent or atr_percent > config.max_atr_percent:
            # Not enough volatility or too much
            return None
        
        # === All core conditions passed! Calculate additional metrics ===
        
        # Moving averages
        ma_50, ma_200 = calculate_moving_averages(df)
        price_above_50ma = current_close > ma_50.iloc[-1] if not pd.isna(ma_50.iloc[-1]) else False
        price_above_200ma = current_close > ma_200.iloc[-1] if not pd.isna(ma_200.iloc[-1]) else False
        
        # Volume ratio
        avg_volume = df.iloc[-20:]['volume'].mean()
        current_volume = latest['volume']
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1.0
        
        # Relative strength
        rs_rating = calculate_relative_strength(df, market_df)
        
        # Create signal
        signal = BreakoutSignal(
            symbol=symbol,
            date=current_date,
            close_price=current_close,
            distance_from_3m_high_pct=distance_from_high_pct,
            three_month_high=three_month_high,
            weekly_return_pct=weekly_return_pct,
            avg_turnover_cr=avg_turnover_cr,
            atr_percent=atr_percent,
            atr_value=atr_value,
            volume_ratio=volume_ratio,
            price_above_50ma=price_above_50ma,
            price_above_200ma=price_above_200ma,
            rs_rating=rs_rating,
            breakout_score=0.0  # Will be calculated next
        )
        
        # Calculate composite score
        signal.breakout_score = calculate_breakout_score(signal)
        
        logger.info(f"✓ SIGNAL: {signal.symbol} - Score: {signal.breakout_score:.1f}, Weekly: {signal.weekly_return_pct:.1f}%")
        
        return signal
        
    except Exception as e:
        logger.error(f"Error scanning {symbol}: {e}")
        return None

def export_signals_to_excel(signals: List[BreakoutSignal], output_file: str):
    """Export breakout signals to formatted Excel file"""
    if not signals:
        logger.warning("No signals to export")
        return
    
    # Convert signals to DataFrame
    data = []
    for sig in signals:
        data.append({
            'Symbol': sig.symbol,
            'Date': sig.date.strftime('%Y-%m-%d'),
            'Close': f"₹{sig.close_price:.2f}",
            'Score': f"{sig.breakout_score:.1f}",
            'Weekly Gain %': f"{sig.weekly_return_pct:.2f}%",
            '3M High': f"₹{sig.three_month_high:.2f}",
            'Dist from High %': f"{sig.distance_from_3m_high_pct:.2f}%",
            'Avg Turnover (Cr)': f"₹{sig.avg_turnover_cr:.1f}",
            'ATR %': f"{sig.atr_percent:.2f}%",
            'Volume Ratio': f"{sig.volume_ratio:.2f}x",
            'Above 50MA': '✓' if sig.price_above_50ma else '✗',
            'Above 200MA': '✓' if sig.price_above_200ma else '✗',
            'RS Rating': f"{sig.rs_rating:.0f}",
        })
    
    df = pd.DataFrame(data)
    
    # Sort by score descending
    df_display = df.copy()
    df_display['_score_num'] = [sig.breakout_score for sig in signals]
    df_display = df_display.sort_values('_score_num', ascending=False)
    df_display = df_display.drop(columns=['_score_num'])
    
    # Export to Excel
    logger.info(f"Exporting {len(signals)} signals to {output_file}...")
    df_display.to_excel(output_file, index=False, engine='openpyxl')
    
    # Apply formatting
    wb = openpyxl.load_workbook(output_file)
    ws = wb.active
    
    # Header formatting
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    header_font = Font(bold=True, color="FFFFFF", size=11)
    
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
    
    # Score-based row coloring
    green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    yellow_fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
    
    for row_idx in range(2, ws.max_row + 1):
        score_val = float(ws[f"D{row_idx}"].value)
        
        if score_val >= 75:
            row_fill = green_fill
        elif score_val >= 60:
            row_fill = yellow_fill
        else:
            row_fill = None
        
        if row_fill:
            for col_idx in range(1, ws.max_column + 1):
                ws.cell(row=row_idx, column=col_idx).fill = row_fill
    
    # Adjust column widths
    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if len(str(cell.value)) > max_length:
                    max_length = len(str(cell.value))
            except:
                pass
        adjusted_width = min(max_length + 2, 30)
        ws.column_dimensions[column_letter].width = adjusted_width
    
    wb.save(output_file)
    logger.info(f"✓ Formatted signals exported to {output_file}")

# ==============================================================================
# Main Execution
# ==============================================================================

def run_momentum_breakout_scanner():
    """Main scanner execution function"""
    logger.info("=" * 80)
    logger.info("MOMENTUM BREAKOUT SCANNER - Stan Weinstein / Shake Pryzby Style")
    logger.info("=" * 80)
    
    # Initialize Kite Connect
    try:
        kite = KiteConnect(api_key=API_KEY)
        kite.set_access_token(ACCESS_TOKEN)
        logger.info("✓ Kite Connect initialized")
    except Exception as e:
        logger.error(f"Kite Connect initialization failed: {e}")
        return
    
    # Define date ranges
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=config.total_lookback_days)
    logger.info(f"Data range: {start_date} to {end_date}")
    
    # Load instruments and universe
    try:
        instruments = load_nse_instruments(kite)
        instruments_df = pd.DataFrame(instruments)
        equity_instruments = instruments_df[
            (instruments_df["segment"] == "NSE") &
            (instruments_df["instrument_type"] == "EQ")
        ].copy()
        logger.info(f"Found {len(equity_instruments)} NSE Equity instruments")
        
        custom_symbols = load_universe_symbols()
        equity_instruments = equity_instruments[equity_instruments["tradingsymbol"].isin(custom_symbols)]
        logger.info(f"Filtered to {len(equity_instruments)} instruments from universe")
        
        if equity_instruments.empty:
            logger.error("No matching instruments found. Exiting.")
            return
        
        instrument_map = equity_instruments.set_index('instrument_token')['tradingsymbol'].to_dict()
        
    except Exception as e:
        logger.error(f"Error during instrument/universe loading: {e}")
        return
    
    # Fetch NIFTY 50 data for relative strength calculation
    logger.info("Fetching NIFTY 50 data for relative strength calculation...")
    nifty_token = 256265  # NIFTY 50 instrument token
    nifty_data = get_historical_data_cached(kite, "NIFTY50", nifty_token, start_date, end_date)
    market_df = None
    
    if nifty_data:
        market_df = pd.DataFrame(nifty_data)
        market_df['date'] = pd.to_datetime(market_df['date']).dt.tz_localize(None)
        market_df.set_index('date', inplace=True)
        for col in ['open', 'high', 'low', 'close', 'volume']:
            if col in market_df.columns:
                market_df[col] = pd.to_numeric(market_df[col], errors='coerce')
        logger.info("✓ NIFTY 50 data loaded")
    else:
        logger.warning("Could not load NIFTY 50 data. RS rating will be neutral.")
    
    # Scan all stocks
    logger.info("=" * 80)
    logger.info("SCANNING STOCKS FOR MOMENTUM BREAKOUT SIGNALS")
    logger.info("=" * 80)
    
    signals = []
    total_stocks = len(instrument_map)
    scanned_count = 0
    
    for token, symbol in instrument_map.items():
        scanned_count += 1
        if scanned_count % 50 == 0:
            logger.info(f"Progress: {scanned_count}/{total_stocks} stocks scanned...")
        
        # Fetch historical data
        data_list = get_historical_data_cached(kite, symbol, token, start_date, end_date)
        
        if not data_list:
            continue
        
        # Process data
        df = pd.DataFrame(data_list)
        try:
            df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
            df.set_index('date', inplace=True)
            
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            df.dropna(subset=['open', 'high', 'low', 'close'], inplace=True)
            
            if df.empty:
                continue
            
            # Scan for breakout
            signal = scan_stock_for_breakout(df, symbol, market_df)
            
            if signal:
                signals.append(signal)
                
        except Exception as e:
            logger.error(f"Error processing {symbol}: {e}")
            continue
    
    logger.info("=" * 80)
    logger.info(f"SCAN COMPLETE: Found {len(signals)} momentum breakout signals")
    logger.info("=" * 80)
    
    # Export results
    if len(signals) >= config.min_signals_for_export:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = config.output_file.format(timestamp=timestamp)
        export_signals_to_excel(signals, output_file)
        
        # Print top signals
        sorted_signals = sorted(signals, key=lambda x: x.breakout_score, reverse=True)
        logger.info("\nTOP 10 SIGNALS:")
        logger.info("-" * 80)
        for i, sig in enumerate(sorted_signals[:10], 1):
            logger.info(f"{i}. {sig.symbol:15s} | Score: {sig.breakout_score:5.1f} | Weekly: {sig.weekly_return_pct:6.2f}% | RS: {sig.rs_rating:5.0f}")
    else:
        logger.info(f"Only {len(signals)} signal(s) found. Minimum {config.min_signals_for_export} required for export.")
    
    logger.info("\nScanner finished successfully!")

# ==============================================================================
# Entry Point
# ==============================================================================

if __name__ == "__main__":
    run_momentum_breakout_scanner()

