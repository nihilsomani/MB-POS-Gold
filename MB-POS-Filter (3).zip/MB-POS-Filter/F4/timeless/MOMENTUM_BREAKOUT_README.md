# Momentum Breakout Scanner

## Overview

The **Momentum Breakout Scanner** implements the Stan Weinstein / Shake Pryzby "Stage Analysis" methodology to identify early-stage breakout opportunities in stocks. This scanner finds stocks that are:

- 🚀 Breaking out near 3-month highs
- 💪 Showing strong weekly momentum (+10% or more)
- 💰 Highly liquid (avoiding "slow crap")
- 📊 Exhibiting healthy volatility

## Methodology

### Core Philosophy

Based on the principle that **"the best time to buy is when a stock is breaking out of a base near its 52-week high with expanding momentum and volume."**

This scanner identifies stocks transitioning from **Stage 1 (Accumulation)** to **Stage 2 (Markup)** in the Weinstein Stage Analysis framework.

### Scan Conditions

#### 1. Price Near 3-Month Highs ✅
```python
close >= 0.95 * rolling_max(high, 60)
```
- Stock must be within **5% of its 60-day high**
- Ensures we're catching breakouts, not chasing laggards
- 60 trading days ≈ 3 months

#### 2. Strong Weekly Momentum ✅
```python
weekly_change = (close / close.shift(5)) - 1
weekly_change >= 0.10
```
- Requires **10%+ gain over the past week** (5 trading days)
- Shows recent momentum burst
- Confirms buyer interest

#### 3. Liquidity Filter ✅
```python
avg_turnover = (close * volume).rolling(20).mean()
avg_turnover >= 5e7  # ₹5 crore minimum
```
- Average daily turnover must exceed **₹5 crore**
- Eliminates illiquid "junk" stocks
- Ensures easy entry/exit

#### 4. Volatility (ATR) Filter ✅
```python
atr_pct = (ATR(14) / close) * 100
2.0 <= atr_pct <= 15.0
```
- ATR as % of price must be between **2% and 15%**
- Too low = dead money, too high = gambling
- Sweet spot for trending moves

## Enhanced Features

Beyond the core Weinstein methodology, this scanner adds:

### 1. **Composite Scoring System (0-100)**

Each signal receives a quality score based on:

| Component | Weight | Description |
|-----------|--------|-------------|
| Proximity to High | 25 pts | Closer = better |
| Weekly Momentum | 25 pts | 10% = 25pts, 20% = 35pts (bonus) |
| Liquidity | 15 pts | ₹5cr = 15pts, ₹50cr = 30pts (bonus) |
| ATR % | 10 pts | 3-8% ideal range |
| Volume Confirmation | 10 pts | 2x avg volume = 10pts |
| MA Alignment | 10 pts | Above 50MA & 200MA |
| Relative Strength | 15 pts | Outperformance vs NIFTY 50 |

**Score Interpretation:**
- 🟢 **75-100**: Exceptional setup - highest priority
- 🟡 **60-74**: Good setup - worth investigating
- ⚪ **<60**: Marginal - proceed with caution

### 2. **Relative Strength Rating (0-100)**

Compares stock performance vs NIFTY 50 over multiple timeframes (5, 10, 20, 60 days) with recent periods weighted more heavily.

- **>80**: Market leader, exceptional outperformance
- **60-80**: Strong performer
- **40-60**: Market performer
- **<40**: Underperformer

### 3. **Volume Confirmation**

- Calculates volume ratio (current vs 20-day average)
- Higher volume = stronger institutional interest
- Filters out weak, low-volume breakouts

### 4. **Moving Average Alignment**

- Checks if price is above 50-day MA (intermediate trend)
- Checks if price is above 200-day MA (long-term trend)
- Both true = ideal alignment

## File Structure

```
timeless/
├── momentum_breakout_scanner.py    # Main scanner script
├── MOMENTUM_BREAKOUT_README.md     # This file
└── MB_Breakout_Cache/              # Cache directory (created automatically)
    ├── nse_instruments.pkl         # Instruments cache
    └── historical/                 # Historical data cache
```

## Usage

### Prerequisites

```bash
pip install pandas numpy kiteconnect pandas_ta openpyxl
```

### Configuration

Edit the following in `momentum_breakout_scanner.py`:

```python
# API Credentials
API_KEY = "your_kite_api_key"
ACCESS_TOKEN = "your_access_token"

# Universe file (CSV with 'Symbol' column)
UNIVERSE_CSV = os.path.join("..", "data", "MCAP7000.csv")

# Scanner parameters (optional tuning)
@dataclass
class ScannerConfig:
    near_high_threshold: float = 0.95      # 5% from high
    weekly_gain_threshold: float = 0.10    # 10% weekly gain
    min_avg_turnover: float = 5e7          # ₹5 crore
    min_atr_percent: float = 2.0           # 2% ATR minimum
    max_atr_percent: float = 15.0          # 15% ATR maximum
```

### Running the Scanner

```bash
cd C:\nihil\finance_ai_ws\MB-POS-Filter\F4\timeless
python momentum_breakout_scanner.py
```

### Output

The scanner generates:
1. **Console output** with scan progress and top signals
2. **Excel file** with all signals, formatted and colored by score:
   - Filename: `momentum_breakout_signals_YYYYMMDD_HHMMSS.xlsx`
   - Green rows: Score ≥75 (exceptional)
   - Yellow rows: Score 60-74 (good)
   - White rows: Score <60 (marginal)

### Excel Columns

| Column | Description |
|--------|-------------|
| Symbol | Stock trading symbol |
| Date | Signal date |
| Close | Current price |
| Score | Composite quality score (0-100) |
| Weekly Gain % | Past week return |
| 3M High | 60-day high price |
| Dist from High % | How far from 3M high |
| Avg Turnover (Cr) | 20-day avg turnover in crores |
| ATR % | ATR as % of price |
| Volume Ratio | Current vs avg volume |
| Above 50MA | ✓ or ✗ |
| Above 200MA | ✓ or ✗ |
| RS Rating | Relative strength (0-100) |

## Trading Guidelines

### Entry Rules

1. **Wait for confirmation**: Don't buy on signal alone
   - Look for volume surge on breakout day
   - Ensure breakout isn't on extremely high volume (exhaustion)

2. **Score-based priority**:
   - Score ≥75: Highest priority, tight stops
   - Score 60-74: Good setups, normal stops
   - Score <60: Pass or very small position

3. **Relative Strength matters**:
   - RS ≥60: Strong stocks in any market
   - RS <40: Avoid even with good score (weak relative performance)

### Position Sizing

Based on ATR and score:

```
Position Size = (Risk Amount) / (ATR × 2)
```

- Higher score = can risk more
- Lower ATR% = can use tighter stops

### Stop Loss

**Initial Stop**: Below the breakout base or pivot
- Typically 1.5-2× ATR below entry
- Never more than 8-10% from entry

**Trailing Stop**: As position moves
- 2× ATR trailing stop
- Or use 50MA / 20MA as dynamic support

### Take Profit Targets

The scanner doesn't set specific targets, but consider:

1. **Short-term swing**: +15-25% (1.5-2.5R)
2. **Medium-term trend**: +50-100% (5-10R)
3. **Long-term position**: Trail with 50MA until broken

Use the **Weekly Gain %** as a guide for recent momentum speed.

### Risk Management

**Golden Rules:**
- Never risk more than 1-2% of capital per trade
- Max 3-5 open positions from scanner signals
- If 3 consecutive signals fail, pause and review
- Strong RS + High Score = most reliable combinations

## Performance Tips

### Caching

The scanner caches:
- NSE instruments list (1 day)
- Historical data per stock (permanent until manual delete)

**To refresh cache:**
```bash
# Delete cache folder
rm -rf MB_Breakout_Cache/
```

### Speed Optimization

- First run: ~15-30 minutes (fetching data)
- Subsequent runs: ~5-10 minutes (using cache)
- 500 stocks universe: ~10-15 API calls per stock

### Rate Limiting

- API delay: 0.35 seconds between requests
- Respects Kite Connect rate limits
- Add retry logic for failed requests

## Customization

### Adjusting Filters

For more aggressive scanning:
```python
near_high_threshold: float = 0.90      # Within 10% of high
weekly_gain_threshold: float = 0.07    # 7% weekly gain
min_avg_turnover: float = 2e7          # ₹2 crore
```

For more conservative scanning:
```python
near_high_threshold: float = 0.98      # Within 2% of high
weekly_gain_threshold: float = 0.15    # 15% weekly gain
min_avg_turnover: float = 10e7         # ₹10 crore
```

### Adding Custom Filters

In `scan_stock_for_breakout()`, add your logic:

```python
# Example: Require positive 3-month return
three_month_return = (current_close / df.iloc[-60]['close'] - 1) * 100
if three_month_return < 0:
    return None
```

## Interpretation Examples

### Example 1: Strong Signal
```
Symbol: RELIANCE
Score: 87.3
Weekly Gain: 12.5%
Dist from High: 1.2%
ATR%: 4.5%
Volume Ratio: 2.1x
RS Rating: 78
Above 50MA: ✓
Above 200MA: ✓
```
**Interpretation:** Exceptional setup. Strong momentum, low distance from high, excellent volume, strong RS. High-priority trade.

### Example 2: Marginal Signal
```
Symbol: EXAMPLE
Score: 58.2
Weekly Gain: 10.1%
Dist from High: 4.8%
ATR%: 11.2%
Volume Ratio: 0.9x
RS Rating: 42
Above 50MA: ✗
Above 200MA: ✗
```
**Interpretation:** Meets minimum criteria but weak quality. High volatility, no volume confirmation, poor RS, below MAs. Pass or very small position.

## Backtesting Notes

This scanner is **NOT backtested** in the current implementation. It's a real-time signal generator.

For backtesting:
1. Use the `timeless_market_backtester.py` as template
2. Adapt the `scan_stock_for_breakout()` logic
3. Test over historical periods
4. Validate edge before live trading

## Limitations

1. **Not a standalone system**: Use with other analysis (price action, support/resistance, sector trends)
2. **Market regime matters**: Works best in bull markets or strong sectors
3. **False breakouts**: Not all signals work; proper stop losses critical
4. **Liquidity in practice**: Exchange-reported turnover vs actual execution may differ
5. **Weekend gaps**: Weekly % can be misleading if large gap on Monday

## References

- **Stan Weinstein**: *Secrets for Profiting in Bull and Bear Markets* (1988)
- **Mark Minervini**: *Think & Trade Like a Champion* (momentum breakout variations)
- **IBD Methodology**: RS Rating and momentum ranking systems
- **Shake Pryzby**: Modern applications of Stage Analysis on Twitter/X

## Support

For issues or enhancements, check:
- Project documentation in `MB-POS-Filter/F4/`
- Other scanners in `scan/` and `timeless/` folders
- Strategy implementations for backtesting templates

---

**Disclaimer**: This scanner is for educational purposes. Always do your own research and use proper risk management. Past performance does not guarantee future results.

