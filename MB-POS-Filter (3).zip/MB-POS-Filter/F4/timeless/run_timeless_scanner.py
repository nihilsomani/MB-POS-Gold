"""
Timeless Market Scanner - Runner
Usage: python run_timeless_scanner.py [symbols.csv]
"""

import sys
import os
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from timeless_market_scanner import TimelessMarketScanner
from timeless_market_strategy import TimelessMarketStrategy
import json

def find_config_file():
    """Find config.json in current dir, parent dirs, or workspace root"""
    current_dir = Path(__file__).parent
    workspace_root = Path(__file__).parent.parent.parent.parent.parent
    
    # Search in order: current, parent, workspace root
    search_paths = [
        current_dir / 'config.json',
        current_dir.parent / 'config.json',
        workspace_root / 'config.json',
        workspace_root / 'config.json'
    ]
    
    for config_path in search_paths:
        if config_path.exists():
            return config_path
    
    return None

def main():
    """Run the scanner with configuration"""
    
    # Try to load config.json from various locations
    config = {}
    config_file = find_config_file()
    
    if config_file:
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            print(f"✓ Loaded config.json from: {config_file}")
        except Exception as e:
            print(f"⚠ Error loading config.json: {e}")
            print("Using default configuration")
    else:
        print("⚠ config.json not found. Using default configuration.")
        print("To use KiteConnect, create config.json with:")
        print('  {"api_key": "your_key", "access_token": "your_token", "symbols_file": "data/symbols.csv"}')
    
    # Get credentials
    api_key = "3bi2yh8g830vq3y6"
    access_token = "7uCdOd1Je1xRzfajiTYrlts6bgH4CV46"
    symbols_file = "data/momentum.csv"
    
    # Check for CSV argument
    if len(sys.argv) > 1:
        symbols_file = sys.argv[1]
        print(f"📂 Using symbols file from argument: {symbols_file}")
    
    # Strategy configuration
    strategy_config = {
        'ema_short': 21,
        'ema_long': 55,
        'roc_period': 10,
        'bb_width_percentile': 20,
        'atr_percentile_max': 25,
        'volume_multiplier': 1.5,
        'stop_atr_multiplier': 1.8
    }
    
    # Initialize scanner
    print("\n" + "="*80)
    print("TIMELESS MARKET STRATEGY - SCANNER")
    print("="*80 + "\n")
    
    scanner = TimelessMarketScanner(
        api_key=api_key,
        access_token=access_token,
        strategy_config=strategy_config
    )
    
    # Determine what to scan
    # Check if symbols_file exists in various locations
    symbols_path = None
    if symbols_file:
        # Try current dir, parent dirs, or workspace root
        current_dir = Path(__file__).parent
        workspace_root = Path(__file__).parent.parent.parent.parent.parent
        
        search_paths = [
            Path(symbols_file),
            current_dir / symbols_file,
            current_dir.parent / symbols_file,
            workspace_root / symbols_file
        ]
        
        for path in search_paths:
            if path.exists():
                symbols_path = path
                break
    
    if symbols_path:
        print(f"📂 Scanning symbols from: {symbols_path}")
        signals = scanner.scan_from_csv(str(symbols_path), min_quality_score=55.0)
    elif scanner.use_kite:
        print("📋 Scanning sample Nifty 50 stocks...")
        sample_symbols = [
            'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK',
            'HINDUNILVR', 'BHARTIARTL', 'SBIN', 'BAJFINANCE', 'ITC',
            'KOTAKBANK', 'LT', 'AXISBANK', 'MARUTI', 'TITAN',
            'ASIANPAINT', 'ULTRACEMCO', 'TECHM', 'WIPRO', 'NTPC'
        ]
        signals = scanner.scan_symbols(sample_symbols, min_quality_score=55.0)
    else:
        print("❌ Cannot scan without KiteConnect credentials.")
        print("\nTo use the scanner:")
        print("1. Create config.json with your KiteConnect credentials")
        print("2. Or pass credentials directly to TimelessMarketScanner")
        print("\nAlternatively, use the strategy directly with your own data:")
        print("  from timeless_market_strategy import TimelessMarketStrategy")
        print("  strategy = TimelessMarketStrategy()")
        print("  signals = strategy.detect_signals(your_df, symbol='SYMBOL')")
        return []
    
    # Display results
    if signals:
        scanner.print_signals_summary(signals, top_n=20)
        output_file = scanner.save_signals_to_csv(signals)
        print(f"💾 Results saved to: {output_file}\n")
    else:
        print("\n❌ No signals found above quality threshold.\n")
    
    return signals


if __name__ == "__main__":
    signals = main()

