# Aditya Khemka - Key Investment Insights & Strategic Framework

## CORE INVESTMENT PHILOSOPHY

### 1. **The Reality-First Approach**
> "Top line is vanity, bottom line is sanity. Cash flow is reality."

**Reading Order for Financial Statements:**
1. **Cash Flow Statement** (FIRST - Reality)
2. **Balance Sheet** (SECOND - Foundation)
3. **P&L Statement** (LAST - Can skip if exhausted)

**Rationale:** Cash flow reveals the true health of a business, while P&L can be manipulated through accounting choices.

---

## THE 10-PARAMETER FRAMEWORK (Great, Good, Ugly)

### Scoring System:
- **+3**: Very good on parameter
- **+2**: Average on parameter
- **-2**: Poor on parameter (HEAVY PENALTY)

### Score Interpretation:
- **Below 20**: Ugly company (avoid)
- **20-23**: Good company
- **Above 23**: Great company (rare)

### The 10 Parameters (5 Qualitative + 5 Quantitative):

#### **Qualitative Parameters:**
1. **Management Integrity** (NON-NEGOTIABLE)
   - If score is -2 here, reject immediately regardless of other factors
   - Look for: Alignment with minority shareholders
   
2. **Promoter Track Record**
   - Delivery on promises
   - Capital allocation decisions
   
3. **Related Party Transactions**
   - Inter-corporate deposits
   - Loan guarantees to other entities
   - Royalty arrangements
   - Acquisitions from related parties
   
4. **Frugality & Capital Discipline**
   - Promoter salary (should be minimal, not max 10% of PBT)
   - Office culture and expenses
   - Buybacks vs excessive perks
   
5. **Accounting Conservatism**
   - Goodwill amortization period (10 years = conservative, 40 years = aggressive)
   - Preference for clean balance sheet over reported profit

#### **Quantitative Parameters:**
1. **Operating History** (>10 years preferred)
2. **Return on Investment** (above industry average)
3. **Secular Growth** (consistent, predictable)
4. **Cash Flow Adequacy**
5. **Working Capital Efficiency**

---

## WORKING CAPITAL AS BUSINESS STRENGTH INDICATOR

### Key Principle:
**Tight working capital = Strong bargaining power = Superior business model**

### What Strong Bargaining Power Looks Like:
- **With Customers:** "Give me money, then I will give you goods"
- **With Vendors:** "Send the machine, money after six months"

### Example: Hospitals
- Customers pay deposit BEFORE treatment
- Vendors provide equipment with extended payment terms
- Result: Minimal working capital required

---

## HEALTHCARE VALUE CHAIN - 5 BUCKETS

### **Bucket 1: Branded Generics** ⭐ (LOVE THIS)
**Examples:** Torrent Pharma, FDC (Electral, Zifi), Ipca (Zerdon)

**Why Invest:**
- **Pricing Power:** Consumer doesn't care about price
- Doctor prescribes brand name (Dolo, Crocin), not generic
- **Asset-Light:** No manufacturing needed, just branding
- **Margins:** High due to pricing power
- **ROE:** Explodes due to low asset base + high margins

**Quote:** "Invest in a business where your consumer doesn't care how much he is paying"

**Economics:**
- Brand becomes the category (like Fevicol, Xerox)
- Consistent 10-12% top-line growth
- Operating leverage: If top-line grows 8%, bottom-line grows 10-13%

### **Bucket 2: Unbranded Generics** ❌ (AVOID)
**Examples:** US Generic Business

**Why Avoid:**
- Pure commodity business
- Buying decision based ONLY on price ("Give me the cheapest one")
- Supply > Demand (chronic oversupply)
- Unpredictable competition entry
- Even promoters can't predict outcomes

**Only Invest When:**
- Extreme undervaluation
- EBITDA margins at rock bottom (world thinks business is finished)
- Exit when EBITDA reaches 10-15% (world thinks it's next FMCG)
- **Play the cycle only, not buy-and-hold**

### **Bucket 3: API/CDMO** ✅ (BULLISH NOW)
**Context:**
- China: $40B API exports, 70-80% global supply
- India: $4B API exports
- Geopolitical shift: Western companies moving from China to India

**Why Bullish:**
- **Sovereignty > Cost:** Western nations prioritizing supply chain security
- Companies doing capex = order visibility
- India's COVID vaccine diplomacy created trust
- China's weaponization of supply scared customers

**Investment Thesis:** "Western companies are saying: Take money, set up plant, then I will place orders"

### **Bucket 4: Diagnostics** ⭐⭐ (MOST BULLISH - First Order Beneficiary)
**Examples:** Thyrocare (best pick)

**Why Most Bullish:**
- **Only 15% organized, 85% unorganized**
- Organized growing at 15-25% top-line
- Unorganized growing at 6-7%
- Market share consolidation to organized players

**Investment Order:**
1. First comes diagnostics
2. Then medicines/pharma
3. Then hospitals (if pharma fails)

**Thyrocare Case Study:**
- COVID = extreme optimism → avoided
- Post-COVID = extreme pessimism → bought at ₹450-500
- Current price: ₹1200 (2.5x in 3 years)
- New management: NABL certification all 32 labs (quality edge)
- Geographic expansion: 3,500 → 10,000 pincodes

### **Bucket 5: Hospitals** ⭐ (LOVE THIS)
**Examples:** HCG (Healthcare Global), Fortis

**Why Invest:**
- **Only business where seller tells buyer:** What to buy, how much, for how long, when to return
- Buyer only says: "Yes sir, please sir"
- Massive under-penetration:
  - Global average: 2.7 beds/1000 population
  - Singapore: 12 beds/1000
  - India: 0.5 beds/1000
- Even if capacity quadruples overnight, still underpenetrated

**Business Model Preference:**
- **Super-specialty (Oncology) > Multi-specialty**
  - Oncology: Patient returns as long as alive (recurring revenue)
  - Multi-specialty: Patient comes once, may not return for 20-30 years (treadmill business)

**Valuation Approach:**
- Avoid expensive (Apollo, Max at 60-80x cash flow)
- Buy reasonable (HCG at 25x cash flow)
- When cash flow doubles, money doubles + multiple expansion likely

---

## KEY VALUATION METRICS

### Primary Metric: **EV/Operating Cash Flow**
- **Why:** Cash = reality, not accounting games
- **Pharma Industry Average:** ~35x forward
- **Red Flags:** 
  - 50-100x+ = overvalued
  - Negative cash flow with ₹45,000 Cr market cap = infinite multiple (AVOID)

### Cash Flow Statement Published: Every 6 months (not quarterly)

---

## CASE STUDIES

### **Best Investment: Ipca Laboratories**
**Entry:** ₹200-250 | **Current:** ₹1300-1400 (6-7 years)

**Situation:**
- USFDA issue → Plant shutdown and rebuild
- Revenue: ₹200 Cr → ₹0
- Costs: ₹100 Cr → ₹120 Cr (higher due to upgrades)
- **Profit swing:** ₹100 Cr profit → ₹120 Cr loss
- Stock fell: ₹450 → ₹200

**Analysis:**
- **Promoter Quality:** Honest, ruthless capital allocation, frugal
  - No lift in 2-story office building
  - Biggest car: Camry (₹20L)
  - No second cup of tea in meetings (frugality indicator)
- **Business Outside US:** Worth 100% upside at current price
- **US Business Recovery:** Bonus upside

**Investment Thesis:**
Two scenarios, both win:
1. **Shut down US:** Profit jumps ₹80 Cr → ₹200 Cr
2. **Fix US:** Profit jumps ₹80 Cr → ₹300 Cr (₹200 + ₹100)

**Outcome:** Took 2.5 years, DSP owned >10% equity (rare conviction)

---

### **Worst Investment: Omega-3 Acid Generic**
**Entry:** Bought on strong Q1 | **Exit:** Booked loss

**What Went Wrong:**
- Believed in "only generic" story
- Q1: $10M revenue from product
- Q2: $0 revenue (had front-loaded 2-3 quarters inventory)
- Two competitors entered before Q3
- Price competition → volume share loss → P&L destroyed

**Lesson Learned:**
> "US generic business is commodity. Management cannot predict, nor can I. Only friend is margin of safety. Buy when world thinks it's finished (low EBITDA margins), sell when world thinks it's next FMCG (10-15% EBITDA). Play cycles only."

---

### **Great Company: Torrent Pharma**
**Entry:** ₹500 (10 years ago) | **Current:** ₹3500 (7x)
**Framework Score:** 27/30 (highest ever seen)

**Why Great:**
- Secular growth: 10-12% top-line, 10-13% bottom-line (operating leverage)
- Promoter: 75% shareholding, never diverted money
- No ICDs, no loan guarantees, minimal salary
- **Conservative accounting:** Amortizes goodwill over 10 years (not 40)
- Keeps balance sheet clean even if profit looks lower

---

### **Current Holdings Examples:**
1. **Jubilant Pharmova:** ₹400-450 → ₹1200 (3x in 3.5 years)
   - API/CDMO tailwinds
   - Radiopharmaceuticals (diagnostic auxiliary)
   - Negative sentiment post-demerger = opportunity
   - Always cash generative (positive OCF even when PAT negative)

2. **FDC Limited (Electral, Zifi):**
   - Brand = Category
   - Asset-light, pricing power
   - ₹1400-1500 Cr revenue
   - 5 buybacks in 10 years (cash generation with no reinvestment needs)
   - No listed competitors for specific brands

---

## RED FLAGS - UGLY COMPANY EXAMPLE (Hyderabad Pharma)

**What to Avoid:**
- ✗ Loans to promoter's other businesses (real estate from pharma)
- ✗ Buying promoter's US entity to cash out promoter
- ✗ Useless acquisitions with no value
- ✗ Salary = exactly 10% of PBT (legal maximum, shows greed)
- ✗ Royalty to promoter for brand usage
- ✗ Related party transactions hidden in disclosures

**Result:** 3% IRR over decade (below FD)

---

## SELL DISCIPLINE - BULL/BEAR/BASE FRAMEWORK

### Process:
1. **Project 3 Earnings Scenarios:**
   - Base (expected)
   - Bull (everything goes right)
   - Bear (everything goes wrong)

2. **Project 3 Multiples:**
   - Base multiple
   - Bull multiple
   - Bear multiple

3. **Calculate 3 Prices:**
   - Bull Price = Bull Earnings × Bull Multiple
   - Base Price = Base Earnings × Base Multiple
   - Bear Price = Bear Earnings × Bear Multiple

### Sell Trigger:
**If 3-year expected return arrives in 6 months with NO fundamental change:**
- Book profit immediately
- Redeploy in stock with 100-200% upside potential

**Example:** Aster, Max
- Expected ₹100 → ₹200 in 3 years
- Stock went ₹100 → ₹200 in 6 months (fancy, not fundamentals)
- SOLD → redeployed elsewhere

**Philosophy:** "Don't fall in love with stocks that made you money"

---

## PROMOTER ANALYSIS - WHAT TO LOOK FOR

### Green Flags (Torrent, Ipca, Jubilant):
- ✓ High promoter shareholding (75%+)
- ✓ No money diversion
- ✓ No inter-corporate deposits
- ✓ No loan guarantees
- ✓ Minimal salary
- ✓ Frugal culture (small cars, simple offices)
- ✓ Conservative accounting choices
- ✓ Clean balance sheet prioritized over reported profit

### Due Diligence Approach (From Brazil Experience):
> "Take nothing on face value. If they said cash is 500, don't assume it's 500. Assume it's 50. Now find proof whether it's 500 or not."

### What to Research:
- Google search board of directors of acquisition targets
- Check for batchmates, relatives in Cayman entities
- Don't trust "non-related party" labels
- Verify beneficial ownership

### Interview Tactic:
**DON'T be vocal about what you discover**
- Know it, use it for decision making
- Don't advertise on conference calls
- Relationships matter in business
- Asking tough questions publicly can get you blacklisted

---

## MACRO VIEW & MARKET OUTLOOK

### Current Market Assessment (2023-2024):
**Nifty Valuation:**
- Historical average: 18-19x PE, 13-14% growth → PEG 1.5x
- Current: 22-23x PE, 8-9% growth → PEG 2.5x
- **Verdict:** Downside > Upside

### Expected Scenario:
**Time correction, not price correction**
- Earnings will keep growing
- Market will stay flat
- PEG will compress over 1-2 years
- **Passive investing era is over**
- **Active stock picking will outperform**

### Liquidity Support:
**Why market won't crash:**
- Real estate: Not making money
- Fixed income: Not attractive
- Gold: Recent rally, some interest
- Equity: ONLY attractive option by default
- **All savings flowing into equity = floor under market**

### When Rally Resumes:
Once fundamentals catch up to valuations (1-2 years)

---

## OTHER SECTORS CURRENTLY BULLISH ON

1. **Lending Businesses**
   - NBFCs (specific)
   - MFIs (Microfinance - selective quality)

2. **PSU Banks**
   - Good numbers
   - Multiples haven't re-rated enough
   - Potential value

3. **Consumption Stories**
   - Tax rationalization in recent budget
   - Lower GST
   - Potential for consumption stock revival

---

## PERSONAL INVESTING PHILOSOPHY

### Asset Allocation (Age/Family Dependent):
- **50% Equity**
- **30% Fixed Income** (Debt funds, arbitrage funds)
- **20% Real Estate**

**Fixed Income Returns:**
- Arbitrage funds: 7-8% (equity taxation benefit)
- Debt funds: 10%+ in rate cut cycle

**Current position:** Debt funds (expecting rate cuts to continue)

### Return Expectations:
> "I don't expect my capital to compound at 20%. If I can compound at 10% with 6% inflation, I'm gaining 4% purchasing power per year. That's very good."

**Why This Matters:**
- Right expectations → balanced risk profile
- Avoids excessive risk-taking
- Sustainable long-term approach

### Track Record:
- **DSP Fund:** 30%+ CAGR
- **Increat Healthcare Funds (2.5 years):** 50%+ CAGR
- **Increat Other Funds:** 20-23% CAGR

---

## LEARNING SOURCES & PHILOSOPHY

### Books That Shaped Investing:
1. **"Psychology of Money" - Morgan Housel**
   - Keep expectations right
   - Manage risk profile
   - Purchasing power focus

2. **"The Joys of Compounding" - Gautam Baid**
   - **Key lesson:** "To not act is a choice"
   - Best action is often no action
   - Patience and waiting

### Learning Philosophy:
> "Read 1-2 books, but IMPLEMENT what you learned. Reading 1000 books without implementation is useless."

**Focus:**
- Action over analysis paralysis
- Learn by doing and making mistakes
- Don't be afraid to make mistakes
- Break the "reading-planning" loop without action

---

## INTERVIEW/HIRING FRAMEWORK

### Key Questions for Analysts:
1. **List 10 investment mistakes you've made**
   - Tests self-awareness
   - Tests learning ability
   - Tests honesty

2. **How do you analyze P&L, Balance Sheet, Cash Flow?**
   - What are most important line items?
   - Which do you read first?

3. **Negative reserves scenario:**
   - Company with negative book value
   - Is it a no-go?
   - What could cause this?
   - Should we still pursue?

**Purpose:** Judge understanding of accounting, books, and thinking process

---

## CAREER ADVICE

### Sell-Side vs Buy-Side:

**Sell-Side (Investment Banking, Equity Research):**
- ✓ Easier entry point for freshers
- ✓ Higher starting salary (₹1L - ₹5L/month entry)
- ✓ Faster wealth building (if you survive)
- ✗ High burnout (18-hour days common)
- ✗ No skin in the game
- ✗ Shorter careers (few grey-haired analysts)
- ✗ Paid to have one-dimensional view

**Buy-Side (Asset Management):**
- ✓ Paid to learn life skill (investing)
- ✓ Better work-life balance
- ✓ 360-degree view (listen to 10 analysts, make own decision)
- ✓ Longer sustainable career (grey-haired managers common)
- ✓ Fiduciary responsibility (skin in game)
- ✗ Harder entry from scratch (₹80K - ₹4L/month entry)
- ✗ Lower salary than sell-side (for equivalent role)

**Recommendation:**
- Get into buy-side directly if possible (rare)
- Otherwise: 2-5 years sell-side → then move to buy-side
- Buy-side rarely hires freshers (need experience first)

---

## HOSPITAL VS HOTEL COMPARISON (Current Opportunity)

### Valuations:
- **Hotels:** 35-40x EBITDA
- **Hospitals:** 20-30x EBITDA

### Business Quality:
**Hotels:**
- Discretionary expense (voluntary)
- May not return even if experience was good (want variety)
- Customer decides when/if to spend

**Hospitals:**
- Involuntary expense (non-discretionary)
- Repeat visits (they know your history)
- Captive customer base

**Decision:** "No-brainer - never touch hotel, always buy cheaper hospital"

> "Excel sheet mistake: People input 5% ARR growth every year. Real life = 20% one year, -10% another year. I learned this early."

---

## CRITICAL MISTAKES TO AVOID

### 1. **Excel Sheet Projection Errors**
- Assuming current trends continue forever
- Linear growth assumptions
- Ignoring cyclicality

### 2. **Trust Without Verification**
> "Another lesson I learned in life: Don't trust anyone, do your own work."

**Example:** Lehman said "zero exposure" to housing crisis in Dec 2007
- Stock hit all-time highs
- Joined Jan 2008
- Bankrupt by Oct 2008

### 3. **Trusting Labels Over People**
> "I trusted the label more than the people. The label is nothing, it's an illusion. It's the people that count."

**How to Identify Right People:**
- Mental wavelength must match
- Shared philosophy on business ethics
- Same approach to client relationships
- Common goals without friction

### 4. **Falling in Love with Stocks**
Especially stocks that made you money - use strict sell discipline framework

### 5. **Being Too Vocal About Discoveries**
- Know what you know
- Use it for decisions
- Don't advertise publicly
- Protect relationships

---

## UNIQUE INSIGHTS FROM LATIN AMERICA EXPERIENCE

### Brazil Market Learnings:
- 9% GDP on healthcare (vs India 3%)
- Dental insurance extremely expensive
- Culture: Brush after every coffee/snack
- 4.5 day work week
- Warm, welcoming society
- Strong invitation culture

### Due Diligence Lessons:
- Language barriers (Portuguese, Spanish)
- No Google Translate then - hired translators
- Literal translations caused issues
- **Mindset:** "Look at accounts with suspicion all the time"
- **Realized:** Business has day-to-day volatility
- Shareholders expecting quarterly perfection unrealistic
- "Variation is part of life, volatility is part of business"

---

## THE LEHMAN CRISIS EXPERIENCE - LESSONS

### What Happened:
- Joined Jan 2008 (stock at all-time high)
- Management claimed zero exposure
- Sep 2008: Bankruptcy filing at midnight
- Working at 11:30 PM as usual
- Senior bosses disappeared to 26th floor
- Found out on Bloomberg TV, not company email

### Emotional Reactions Observed:
1. **Grief:** 50-year-olds crying (70-80% net worth in Lehman ESOP)
2. **Anger:** Broken laptops, desks, chairs, fridges
3. **Helplessness:** Security escort out, leave everything

### Personal Crisis:
- Hotel room on company credit card → invalid
- Visa sponsored by company → invalid
- Hotel: "Come take luggage, then figure out payment"
- Embassy: "Visa not valid, come to airport"
- All in 10-12 hours

### Why Lehman Failed (Personal View):
> "They did bad deals. Morgan Stanley, Goldman also got stuck. Everyone got stuck. Why only Lehman made an example? Greater powers at work."

### What Was Right About Lehman:
- Great company to work for
- Everyone worked 18 hours (common, not exceptional)
- Worked 3 hours sleep days
- Well compensated
- Fast career graphs for performers
- Just bad luck

### Leadership Failure:
> "To face a storm is one thing. To leave colleagues alone in the storm is different. Storms happen in every business. But to disappear and lock yourself away - never acceptable."

**This betrayal led to rejecting Barclays offer and moving to Nomura Europe instead**

---

## CONFERENCE CALL INCIDENT - SUN PHARMA

### The Question:
**Context:** Whistleblower sued Sun Pharma, gave documents to press

**Aditya's Logic:**
- "If someone made frivolous allegations against me, I would counter-sue for defamation"
- Looking for that aggressive defense as sign of innocence
- Guilty party stays quiet, innocent party defends aggressively

**Question Asked:**
"He has sued you. He gave your proprietary documents to press. What are you doing? If you're not guilty, defend yourself. If guilty, you'll stay quiet. How do you defend? Make him pay for his brashness."

**Answer:** "Matter under investigation, cannot comment, will cooperate"

**Outcome:** Sun Pharma later settled with fine

**Media Interpretation:** Twisted to "suing the whistleblower" (not the intent)

**Lesson:** Questions taken out of context, be careful with public statements

---

## HEALTHCARE INDIA MACRO OPPORTUNITY

### Current Penetration:
- India: 3.5% of GDP on healthcare
- America: 19%
- Mexico: 6%
- Brazil: 7-8%
- Singapore: 12%

### Thesis:
> "India is at the beginning of healthcare journey. Healthcare will grow very secularly. No doubt."

**Investment Priority:**
1. First-order beneficiaries (Diagnostics)
2. Second-order (Pharma)
3. Third-order (Hospitals)
4. Parallel: CRO services supporting all three

---

## BRAND POWER - ELECTRAL & ZIFI CASE

### Electral (FDC Limited):
- **What it is:** ORS (Oral Rehydration Solution)
- **Brand power:** People say "Electral" not "ORS"
  - Like Cadbury (not "chocolate")
  - Like Fevicol (not "adhesive")
  - Like Sugar Free (not "artificial sweetener")

### The Economics:
- **Brand = Category = Pricing Power**
- Consumer doesn't care about price
- 500 ORS brands in India
- Only Electral sells

### Asset-Light Model:
- HUL doesn't make soap, makes brands (Lux, Dove)
- FDC doesn't make products, makes brands (Electral, Zifi)
- **Result:** 
  - Small asset base (denominator)
  - High margins from pricing power (numerator)
  - **ROE explodes**

### Cash Generation:
- Revenue: ₹1400-1500 Cr
- Business throws cash
- Can't reinvest (no assets needed)
- **Solution:** 5 buybacks in 10 years
- Buyback vs dividend = tax efficiency choice

### No Competition:
- No competitors for specific brands
- Other branded generic companies exist (Eris, Ipca, Sun, JB - Rantac)
- But each has own brand monopoly in their category

---

## FINAL WISDOM

### On Gullibility:
> "I would not be as gullible as I was at beginning of career. I would be more skeptical."

### On People vs Institutions:
> "I trusted the label more than the people. Label is illusion. It's the people."

### On Mental Wavelength:
> "Mental wavelength should match. If everyone's mentality is different, working towards common goal involves friction."

### On Asset Management Philosophy:
**Two Approaches:**
1. Gather assets, lie to clients, show dreams, bring money
2. Do right by client, money will come

**Both make you rich eventually. It's what you're comfortable with.**

### On Implementation:
> "Don't be afraid to make mistakes. Don't be afraid to act. Do things and learn. Don't get stuck in reading-planning loop without action."

---

## QUICK REFERENCE CHECKLIST

### Before Buying Any Stock:
- [ ] Read Cash Flow statement first
- [ ] Read Balance Sheet second
- [ ] Read P&L last (or skip)
- [ ] Score on 10-parameter framework
- [ ] Management integrity non-negotiable
- [ ] Check working capital efficiency
- [ ] Verify promoter shareholding & behavior
- [ ] Look for conservative accounting choices
- [ ] Google board members of acquisitions
- [ ] Check for related party transactions
- [ ] Calculate EV/OCF ratio
- [ ] Determine bull/bear/base price
- [ ] Identify margin of safety
- [ ] Understand bargaining power (both sides)
- [ ] Assess if consumer cares about price

### After Buying:
- [ ] Monitor quarterly fundamentals
- [ ] Track bull/bear/base scenarios
- [ ] Update price targets
- [ ] Sell if 3-year return comes in 6 months
- [ ] Don't fall in love with position
- [ ] Redeploy capital actively
- [ ] Review working capital trends
- [ ] Watch for red flags (ICDs, guarantees, etc.)

### Portfolio Construction:
- [ ] First-order beneficiaries prioritized
- [ ] Asset-light businesses with pricing power
- [ ] Secular growth over cyclical
- [ ] Branded over commodities
- [ ] Super-specialty over multi-specialty (hospitals)
- [ ] Organized over unorganized (diagnostics)
- [ ] Sovereignty plays (API/CDMO)
- [ ] Frugal promoters over flashy ones

---

## SUMMARY: THE ESSENCE

**Investment is not about marrying the prettiest girl.**

It's about finding the right balance between:
1. Quality of business model
2. Price paid for it
3. Future value of asset

**Success factors:**
- Cash flow focus (reality over accounting)
- Management integrity (non-negotiable)
- Working capital (reveals bargaining power)
- Pricing power (consumer doesn't care)
- Asset-light models (high ROE)
- Secular growth (predictable)
- First-order beneficiaries (diagnostics in healthcare)
- Sell discipline (don't fall in love)
- Active management (passive era over)
- Right expectations (4% real return is great)
- Learn by doing (not just reading)
- Right people (wavelength match)

**The ultimate edge:**
> "To not act is a choice. The best action is often no action."

---

*Framework extracted from podcast interview with Aditya Khemka, healthcare investor and fund manager at Increat*
*Track record: 30%+ CAGR at DSP, 50%+ CAGR at Increat (healthcare funds)*

