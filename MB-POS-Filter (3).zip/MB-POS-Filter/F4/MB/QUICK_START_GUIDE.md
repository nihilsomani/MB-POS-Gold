# MultiBeggar Backtester - Quick Start Guide

## 🎯 What You Have Now

A **comprehensive backtesting framework** to test your MultiBeggar scanner with different configurations and find the most profitable CAGR-maximizing settings.

## 📁 Files Created

| File | Purpose |
|------|---------|
| `MBBacktester.py` | Main backtesting engine (comprehensive parameter testing) |
| `run_mb_backtest.py` | Simple CLI to run predefined scenarios |
| `analyze_mb_results.py` | Visualize and analyze backtest results |
| `MB_BACKTEST_README.md` | Detailed documentation |
| `MB_TESTING_PRIORITIES.md` | Step-by-step testing workflow (2-3 weeks) |
| `mb_config_template.json` | Configuration template (easy parameter editing) |
| `QUICK_START_GUIDE.md` | This file! |

## 🚀 Getting Started (5 Minutes)

### Step 1: Install Dependencies
```bash
pip install pandas numpy pandas_ta matplotlib seaborn kiteconnect python-dateutil
```

### Step 2: Set API Credentials
Edit `MBBacktester.py` or `run_mb_backtest.py`:
```python
API_KEY = "your_api_key_here"
ACCESS_TOKEN = "your_access_token_here"
```

### Step 3: Run Your First Backtest
```bash
cd c:\nihil\finance_ai_ws\MB-POS-Filter\F4\MB
python run_mb_backtest.py --scenario default
```

**This will:**
- Fetch data for all symbols in `data/MCAP-great2500.csv`
- Run backtest from 2022-01-01 to 2025-10-23
- Test scanner's default settings
- Show performance metrics (CAGR, Sharpe, Max DD, Win Rate)

### Expected Output:
```
=============================================================================
BACKTEST RESULTS
=============================================================================
Final Equity: ₹X,XXX,XXX
CAGR: XX.XX%
Max Drawdown: -XX.XX%
Sharpe Ratio: X.XX
Win Rate: XX.XX%
Number of Trades: XX
Avg Hold Period: XX days
```

## 📊 What to Test First

### Test 1: Validate Scanner (Day 1)
**Goal:** Ensure backtest matches live scanner signals

```bash
python run_mb_backtest.py --scenario default
```

**Check:**
- Are signals realistic? (5-20 per month from 2500 stocks)
- Win rate >50%?
- CAGR >20%?

### Test 2: Compare Strategies (Day 1-2)
**Goal:** Find best risk/reward profile

```bash
python run_mb_backtest.py --compare default aggressive conservative trend_rider
```

**Look for:**
- Which has highest CAGR?
- Which has best Sharpe (risk-adjusted)?
- Which matches your risk tolerance?

### Test 3: Optimize Exit Strategy (Day 2-3)
**Goal:** Exits have HUGE impact on long-term holds

```bash
# Test trailing stop levels
python run_mb_backtest.py --sensitivity trailing_stop_pct --param-values 0.10 0.12 0.15 0.18 0.20

# Test hold periods
python run_mb_backtest.py --sensitivity hold_period_max --param-values 26 39 52 78 104
```

**Key Question:** Tight stops (lower DD) vs wide stops (higher CAGR)?

### Test 4: Optimize Entry Filters (Day 3-5)
**Goal:** Better entries = better performance

```bash
# Test TRIX threshold
python run_mb_backtest.py --sensitivity trix_threshold --param-values 0.5 1.0 1.5 2.0 2.5

# Test RSI threshold
python run_mb_backtest.py --sensitivity rsi_threshold --param-values 60 65 70 75 80

# Test entry conditions
python run_mb_backtest.py --sensitivity entry_conditions_required --param-values 3 4 5 6
```

**Key Question:** More signals (looser filters) vs better signals (stricter filters)?

### Test 5: Full Parameter Sweep (Day 5-7)
**Goal:** Discover unexpected optimal combinations

Edit `MBBacktester.py`:
```python
RUN_PARAMETER_SWEEP = True
RUN_SENSITIVITY_ANALYSIS = False
```

Run:
```bash
python MBBacktester.py
```

**WARNING:** This will test hundreds of combinations (takes hours!)

### Test 6: Validate Out-of-Sample (Day 7-8)
**Goal:** Ensure strategy isn't overfit

Edit `MBBacktester.py`:
```python
RUN_OUT_OF_SAMPLE = True
TRAIN_START = "2022-01-01"
TRAIN_END = "2024-01-01"    # Train on 2 years
TEST_START = "2024-01-01"
TEST_END = "2025-10-23"      # Test on recent data
```

**Success:** OOS CAGR within 50% of in-sample (e.g., if IS=40%, OOS=20%+)

## 📈 Analyzing Results

### After Running Tests:
```bash
# Visualize results
python analyze_mb_results.py --results mb_backtest_results/parameter_test_results_20251023_120000.pkl

# This creates:
# - Parameter impact plots (how each parameter affects CAGR)
# - Correlation matrix (which parameters matter most)
# - Pareto frontier (optimal risk/return combinations)
# - Top 10 configurations ranking
# - Insights report (text summary)
```

### Key Metrics to Watch:

| Metric | Target | Red Flag |
|--------|--------|----------|
| **CAGR (OOS)** | >20% | <15% |
| **Max Drawdown** | <25% | >35% |
| **Sharpe Ratio** | >1.5 | <0.8 |
| **Win Rate** | >55% | <45% |
| **Num Trades** | >30 | <10 |

## ⚠️ Common Issues & Solutions

### Issue 1: "No data prepared"
**Solution:**
- Check API credentials
- Verify `data/MCAP-great2500.csv` exists
- Check internet connection

### Issue 2: "Backtest takes forever"
**Solutions:**
- Start with fewer symbols (test on 100-200 stocks first)
- Use cache (data is cached after first fetch)
- Reduce parameter grid size

### Issue 3: "All configs have similar results"
**Possible causes:**
- Not enough historical data
- Transaction costs too high (masking differences)
- Parameter ranges too narrow

**Solution:** Check `mb_backtest.log` for details

### Issue 4: "CAGR looks too good to be true (>100%)"
**Red flag:** Likely overfitting or survivorship bias

**Solutions:**
- Run out-of-sample validation
- Check if you're testing on live symbols only (survivor bias)
- Reduce parameter optimization (fewer knobs to overfit)

## 🎓 Understanding the Results

### Scenario Comparison Output:
```
Scenario    | CAGR (%) | Max DD (%) | Sharpe | Win Rate (%) | Trades
------------------------------------------------------------------------
default     | 32.50    | -22.30     | 1.65   | 58.20        | 45
aggressive  | 28.10    | -18.50     | 1.48   | 52.10        | 78
conservative| 29.80    | -25.10     | 1.52   | 61.30        | 28
trend_rider | 38.20    | -28.40     | 1.72   | 57.90        | 32
```

**Interpretation:**
- **trend_rider** has highest CAGR (38.2%) but highest DD (28.4%)
  → Best for risk-tolerant traders
  
- **aggressive** has lowest DD (18.5%) but lower CAGR (28.1%)
  → Best for risk-averse traders
  
- **default** is balanced (32.5% CAGR, 22.3% DD, 1.65 Sharpe)
  → Good starting point

**Choose based on your risk tolerance!**

## 🔥 Pro Tips

### Tip 1: Start Simple
Don't test everything at once! Follow this order:
1. Validate scanner (default config)
2. Optimize exit strategy (biggest impact)
3. Optimize entry filters
4. Fine-tune position sizing
5. Validate out-of-sample

### Tip 2: Watch for Red Flags
- **Win rate <45%**: Filters catching false signals
- **Max DD >35%**: Need tighter stops
- **Too few trades (<20)**: Not enough data to validate
- **OOS collapse**: Strategy overfit

### Tip 3: Don't Overfit!
- Fewer parameters = more robust
- Out-of-sample validation is CRITICAL
- If a config looks perfect, it's probably overfit

### Tip 4: Paper Trade Before Real Money
Even if backtest looks amazing:
1. Paper trade for 2-3 months
2. Compare live results to backtest
3. Only go live if they match

## 📚 Next Steps

### Week 1: Foundation
- [ ] Run default scenario
- [ ] Compare 5 predefined scenarios
- [ ] Test exit strategies (trailing stops)

### Week 2: Optimization
- [ ] Sensitivity analysis (TRIX, RSI, KC distance)
- [ ] Test entry conditions (3/6, 4/6, 5/6)
- [ ] Test position sizing methods

### Week 3: Validation
- [ ] Full parameter sweep
- [ ] Out-of-sample validation
- [ ] Monte Carlo robustness test
- [ ] Benchmark comparison (vs Nifty 500)

### After Testing:
- [ ] Document optimal configuration
- [ ] Create trading playbook
- [ ] Paper trade for 2-3 months
- [ ] Start with small capital (10-20%)
- [ ] Scale up if live matches backtest

## 🆘 Need Help?

### Check These First:
1. **`mb_backtest.log`** - Detailed execution log
2. **`MB_BACKTEST_README.md`** - Full documentation
3. **`MB_TESTING_PRIORITIES.md`** - Testing workflow guide

### Common Questions:

**Q: How long does a backtest take?**
A: 10-30 minutes for default config, 2-8 hours for full sweep (depends on internet, API rate limits)

**Q: Can I test on fewer symbols to speed up?**
A: Yes! Edit `SYMBOLS_CSV` to point to a smaller file (e.g., Nifty 100)

**Q: What if I don't have Kite API?**
A: You'll need historical data. The framework expects OHLCV data. Modify `KiteDataFetcher` to read from CSV/database instead.

**Q: Is 1% transaction cost realistic?**
A: Yes, for small/mid caps. Includes brokerage, STT, taxes, slippage, market impact. For large caps, you can reduce to 0.5%.

## 🎯 Success Criteria

### Your strategy is production-ready if:
✅ CAGR >20% (out-of-sample)  
✅ Max Drawdown <25%  
✅ Sharpe Ratio >1.5  
✅ Win Rate >55%  
✅ At least 30 trades (statistical significance)  
✅ Beats Nifty 500 by 2x (risk-adjusted)  
✅ Stable across different time periods  

### If strategy fails validation:
- Analyze failure modes (are filters too loose? too tight?)
- Try alternative approaches (mean reversion, volatility breakout)
- Consider combining with other systems (RRG + MB hybrid?)

---

## 🚀 Ready to Begin?

```bash
# Step 1: Run default
python run_mb_backtest.py --scenario default

# Step 2: Compare strategies
python run_mb_backtest.py --compare default aggressive conservative trend_rider

# Step 3: Analyze results
python analyze_mb_results.py --results mb_backtest_results/parameter_test_results_*.pkl

# Step 4: Read the output and decide next tests
cat mb_backtest_results/analysis_insights.txt
```

**Good luck with your testing!** 🎉

Remember: **Past performance ≠ future results**. Backtest thoroughly, validate out-of-sample, paper trade, then start small with real money.

---

*Questions? Read `MB_BACKTEST_README.md` and `MB_TESTING_PRIORITIES.md` for detailed guidance.*

