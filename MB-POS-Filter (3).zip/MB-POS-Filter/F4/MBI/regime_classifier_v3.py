"""
Market Regime Classifier V3 (Index-Aware)
==========================================
Enhanced with Nifty 500 index confirmation to reduce noise.

Key improvements over V2:
- Detects divergences (EM vs Index)
- Classifies market types (broad rally, narrow rally, etc.)
- Adjusts position sizing based on confirmation
- Reduces false positives significantly

Based on Oct-Nov 2024 analysis showing 3 false positives from V2.
"""

from typing import Optional, List, Tuple
from dataclasses import dataclass
from enum import Enum
import logging

logger = logging.getLogger(__name__)

# Import config thresholds
try:
    from config import (
        REGIME_BEAR, REGIME_REPAIR, REGIME_EARLY, REGIME_HEALTHY,
        REGIME_STRONG, REGIME_EXTREME,
        EM_CRASH_THRESHOLD_3D, EM_CRASH_THRESHOLD_5D,
        EM_DECLINING_THRESHOLD, EM_RISING_THRESHOLD,
        EUPHORIA_EM_THRESHOLD, EUPHORIA_EM_PLATEAU_DAYS,
        EUPHORIA_EM_SPIKE, EUPHORIA_BREADTH_DIVERGENCE_DAYS,
        EUPHORIA_RATIO_PEAK, EUPHORIA_52WH_THRESHOLD,
        EUPHORIA_52WH_DECLINE_THRESHOLD, EUPHORIA_SMA_OVEREXTENSION
    )
except ImportError:
    logger.warning("Could not import from config.py, using defaults")
    REGIME_BEAR = 12
    REGIME_REPAIR = 15
    REGIME_EARLY = 18
    REGIME_HEALTHY = 40
    REGIME_STRONG = 60
    REGIME_EXTREME = 75
    EM_CRASH_THRESHOLD_3D = -10
    EM_CRASH_THRESHOLD_5D = -15
    EM_DECLINING_THRESHOLD = -3
    EM_RISING_THRESHOLD = 3
    EUPHORIA_EM_THRESHOLD = 75
    EUPHORIA_EM_PLATEAU_DAYS = 3
    EUPHORIA_EM_SPIKE = 20
    EUPHORIA_BREADTH_DIVERGENCE_DAYS = 3
    EUPHORIA_RATIO_PEAK = 400
    EUPHORIA_52WH_THRESHOLD = 30
    EUPHORIA_52WH_DECLINE_THRESHOLD = 0.5
    EUPHORIA_SMA_OVEREXTENSION = 85


class MarketRegime(Enum):
    """Market regime states (V3 - Index-Aware)"""
    BEAR_CONTROL = "Bear Control"
    REPAIR_ZONE = "Repair Zone"
    EARLY_MOMENTUM = "Early Momentum"
    HEALTHY_BULLISH = "Healthy Bullish"
    STRONG_BULLISH = "Strong Bullish"
    EXTREME_BULLISH = "Extreme Bullish"
    DETERIORATING = "Deteriorating"
    DIVERGENCE = "Divergence"  # NEW: High EM but index weak
    UNKNOWN = "Unknown"
    
    def __str__(self):
        return self.value


class MarketType(Enum):
    """Market type based on EM + Index"""
    BROAD_RALLY = "Broad Rally"  # High EM + Rising Index = BEST
    RECOVERY = "Recovery"  # Mid EM + Rising Index
    NARROW_RALLY = "Narrow Rally"  # Low EM + Rising Index = FRAGILE
    DIVERGENCE_RALLY = "Divergence Rally"  # High EM + Falling Index = CAUTION
    BROAD_DECLINE = "Broad Decline"  # Low EM + Falling Index = AVOID
    CONSOLIDATION = "Consolidation"  # Flat index
    UNKNOWN = "Unknown"
    
    def __str__(self):
        return self.value


@dataclass
class RegimeClassificationV3:
    """Result of V3 regime classification"""
    regime: MarketRegime
    market_type: MarketType
    em_score: float
    em_trend: str
    index_trend: str
    position_size: float  # 0.0 to 1.5 (can exceed 100% with confirmation)
    trading_action: str
    confidence: float
    divergence_warning: bool  # True if EM and Index disagree
    
    def __str__(self):
        div_flag = " [DIVERGENCE!]" if self.divergence_warning else ""
        return (f"{self.regime.value} | {self.market_type.value} | "
                f"EM={self.em_score:.1f}% ({self.em_trend}) | "
                f"Index={self.index_trend} | Size={self.position_size:.0%}{div_flag}")


class TrendBasedRegimeClassifierV3:
    """
    V3 Classifier with Index Awareness.
    
    Reduces noise by requiring index confirmation for high-conviction trades.
    Uses thresholds from config.py.
    """
    
    def __init__(self):
        logger.info(
            f"TrendBasedRegimeClassifierV3 initialized with thresholds: "
            f"Bear<{REGIME_BEAR}, Repair<{REGIME_REPAIR}, Early<{REGIME_EARLY}, "
            f"Healthy<{REGIME_HEALTHY}, Strong<{REGIME_STRONG}, Extreme<{REGIME_EXTREME}"
        )
        logger.info("V3 Enhancement: Index-aware classification to reduce false positives")
    
    def classify(
        self,
        em_score: float,
        em_change_1d: Optional[float] = None,
        em_change_3d: Optional[float] = None,
        em_change_5d: Optional[float] = None,
        index_trend: str = 'unknown',
        index_pct_change_5d: float = 0.0
    ) -> RegimeClassificationV3:
        """
        Classify regime based on EM + Index (V3).
        
        Args:
            em_score: Current EM
            em_change_1d: EM change from yesterday
            em_change_3d: EM change from 3 days ago
            em_change_5d: EM change from 5 days ago
            index_trend: 'rising', 'falling', 'flat', or 'unknown'
            index_pct_change_5d: Index 5-day % change
        
        Returns:
            RegimeClassificationV3 with market type and position sizing
        """
        # Determine EM trend (same as V2)
        em_trend = self._analyze_em_trend(em_change_1d, em_change_3d, em_change_5d)
        
        # Detect divergence (V3.6: now includes index_pct_change_5d)
        divergence = self._detect_divergence(em_score, em_trend, index_trend, index_pct_change_5d)
        
        # Classify market type
        market_type = self._classify_market_type(em_score, em_trend, index_trend)
        
        # Base classification on EM (similar to V2)
        base_regime, base_position, base_action, base_confidence = \
            self._base_classification(em_score, em_trend)
        
        # Adjust based on index confirmation (NEW in V3!)
        final_regime, final_position, final_action, final_confidence = \
            self._adjust_for_index(
                base_regime, base_position, base_action, base_confidence,
                em_score, em_trend, index_trend, index_pct_change_5d, divergence
            )
        
        return RegimeClassificationV3(
            regime=final_regime,
            market_type=market_type,
            em_score=em_score,
            em_trend=em_trend,
            index_trend=index_trend,
            position_size=final_position,
            trading_action=final_action,
            confidence=final_confidence,
            divergence_warning=divergence
        )
    
    def _analyze_em_trend(
        self,
        change_1d: Optional[float],
        change_3d: Optional[float],
        change_5d: Optional[float]
    ) -> str:
        """Analyze EM trend (same as V2)"""
        if change_1d is None:
            return 'unknown'
        
        # Crash detection
        if change_3d is not None and change_3d < EM_CRASH_THRESHOLD_3D:
            return 'crashing'
        if change_5d is not None and change_5d < EM_CRASH_THRESHOLD_5D:
            return 'crashing'
        
        # Use 3-day change if available
        primary_change = change_3d if change_3d is not None else change_1d
        
        if primary_change > EM_RISING_THRESHOLD:
            return 'rising'
        elif primary_change < EM_DECLINING_THRESHOLD:
            return 'declining'
        else:
            return 'stable'
    
    def _detect_divergence(
        self,
        em_score: float,
        em_trend: str,
        index_trend: str,
        index_pct_change_5d: float = 0.0
    ) -> bool:
        """
        Detect divergence between EM and Index.
        
        Divergence = EM and Index moving in opposite directions
        
        CRITICAL: Also flag when EM is high but index is FLAT after weakness!
        (Oct 29-31 pattern: EM recovered but index still weak)
        """
        if index_trend == 'unknown':
            return False  # Can't detect without index data
        
        # High EM but index falling = DIVERGENCE (Oct 1-8 pattern)
        if em_score >= REGIME_HEALTHY and index_trend == 'falling':
            return True
        
        # EM rising but index falling = DIVERGENCE
        if em_trend == 'rising' and index_trend == 'falling':
            return True
        
        # HIGH EM but index FLAT and still down from recent levels = DIVERGENCE
        # (Oct 29-31: EM 75%, index flat but down -2.7% over 5 days)
        if em_score >= REGIME_STRONG and index_trend == 'flat' and index_pct_change_5d < -1.0:
            return True
        
        # EM rising but index flat and weak = DIVERGENCE
        if em_trend == 'rising' and index_trend == 'flat' and index_pct_change_5d < -2.0:
            return True
        
        # EM falling but index rising = Minor divergence (usually short-term)
        # Not as critical, so we don't flag it
        
        return False
    
    def _classify_market_type(
        self,
        em_score: float,
        em_trend: str,
        index_trend: str
    ) -> MarketType:
        """
        Classify market type based on EM level + Index trend.
        
        This is the KEY enhancement in V3!
        """
        if index_trend == 'unknown':
            return MarketType.UNKNOWN
        
        # Classify EM level
        em_high = em_score >= REGIME_HEALTHY  # EM >= 40%
        em_mid = REGIME_EARLY <= em_score < REGIME_HEALTHY  # EM 18-40%
        em_low = em_score < REGIME_EARLY  # EM < 18%
        
        # Market type matrix
        if em_high and index_trend == 'rising':
            return MarketType.BROAD_RALLY  # BEST - Nov 14-29 pattern
        
        elif em_mid and index_trend == 'rising':
            return MarketType.RECOVERY  # GOOD - Breadth improving
        
        elif em_low and index_trend == 'rising':
            return MarketType.NARROW_RALLY  # FRAGILE - Only large caps
        
        elif em_high and index_trend == 'falling':
            return MarketType.DIVERGENCE_RALLY  # CAUTION - Oct 1-8 pattern
        
        elif em_low and index_trend == 'falling':
            return MarketType.BROAD_DECLINE  # AVOID - Oct 21-22 pattern
        
        else:  # Flat index
            return MarketType.CONSOLIDATION
    
    def _base_classification(
        self,
        em_score: float,
        em_trend: str
    ) -> tuple:
        """
        Base classification based on EM only (V2 logic).
        This gets adjusted by index confirmation.
        """
        # Same as V2, but returns tuple for adjustment
        if em_score < REGIME_BEAR:
            return (MarketRegime.BEAR_CONTROL, 0.0, 
                    "CASH - No trades (most setups failing)", 0.9)
        
        elif em_score < REGIME_REPAIR:
            if em_trend == 'rising':
                return (MarketRegime.REPAIR_ZONE, 0.3,
                        "PROBE SMALL - Recovery starting", 0.6)
            else:
                return (MarketRegime.REPAIR_ZONE, 0.0,
                        "OBSERVE - Still weak", 0.7)
        
        elif em_score < REGIME_EARLY:
            if em_trend in ['rising', 'stable']:
                return (MarketRegime.EARLY_MOMENTUM, 0.5,
                        "SELECTIVE - Improving conditions", 0.7)
            else:
                return (MarketRegime.EARLY_MOMENTUM, 0.3,
                        "CAUTIOUS - Weakening", 0.6)
        
        elif em_score < REGIME_HEALTHY:
            if em_trend == 'crashing':
                return (MarketRegime.DETERIORATING, 0.0,
                        "EXIT - EM crashing", 0.9)
            elif em_trend == 'declining':
                return (MarketRegime.HEALTHY_BULLISH, 0.5,
                        "REDUCE - Weakening", 0.7)
            else:
                return (MarketRegime.HEALTHY_BULLISH, 1.0,
                        "FULL EXPOSURE - Healthy conditions", 0.8)
        
        elif em_score < REGIME_STRONG:
            if em_trend == 'crashing':
                return (MarketRegime.DETERIORATING, 0.0,
                        "EXIT ALL - EM crashing from highs!", 1.0)
            elif em_trend == 'declining':
                return (MarketRegime.STRONG_BULLISH, 0.5,
                        "TRIM TO 50% - EM weakening", 0.8)
            elif em_trend in ['rising', 'stable']:
                return (MarketRegime.STRONG_BULLISH, 1.2,
                        "AGGRESSIVE - Strong momentum", 0.9)
            else:
                return (MarketRegime.STRONG_BULLISH, 1.0,
                        "FULL EXPOSURE - Strong conditions", 0.8)
        
        elif em_score < REGIME_EXTREME:  # 60 <= EM < 75 (upper strong zone)
            if em_trend == 'crashing':
                return (MarketRegime.DETERIORATING, 0.0,
                        "EXIT ALL - EM crashing from highs!", 1.0)
            elif em_trend == 'declining':
                return (MarketRegime.STRONG_BULLISH, 0.3,
                        "TRIM TO 30% - Strong momentum slipping", 0.8)
            elif em_trend in ['rising', 'stable']:
                return (MarketRegime.STRONG_BULLISH, 1.2,
                        "AGGRESSIVE - Strong momentum", 0.9)
            else:
                return (MarketRegime.STRONG_BULLISH, 1.0,
                        "FULL EXPOSURE - Strong conditions", 0.8)
        else:  # EM >= REGIME_EXTREME
            if em_trend == 'crashing':
                return (MarketRegime.DETERIORATING, 0.0,
                        "EXIT EVERYTHING - Blow-off top reversing!", 1.0)
            elif em_trend == 'declining':
                return (MarketRegime.EXTREME_BULLISH, 0.3,
                        "TRIM TO 30% - Extreme momentum slipping (monitor crash risk)", 0.8)
            elif em_trend in ['rising', 'stable']:
                return (MarketRegime.EXTREME_BULLISH, 1.0,
                        "RIDE THE WAVE - Extreme but sustained", 0.7)
            else:
                return (MarketRegime.EXTREME_BULLISH, 0.7,
                        "PARTIAL TRIM - Extreme levels", 0.6)
    
    def _adjust_for_index(
        self,
        base_regime: MarketRegime,
        base_position: float,
        base_action: str,
        base_confidence: float,
        em_score: float,
        em_trend: str,
        index_trend: str,
        index_pct_change: float,
        divergence: bool
    ) -> tuple:
        """
        Adjust position sizing based on index confirmation.
        
        This is the CORE NOISE REDUCTION logic!
        """
        # If no index data, use base classification
        if index_trend == 'unknown':
            return (base_regime, base_position, base_action, base_confidence)
        
        # Crash signals always override (highest priority)
        if em_trend == 'crashing':
            return (MarketRegime.DETERIORATING, 0.0, 
                    "EXIT ALL - EM crashing!", 1.0)
        
        # If divergence detected, reduce position
        if divergence:
            adjusted_position = base_position * 0.5  # Reduce to 50%
            adjusted_action = f"DIVERGENCE: {base_action} (Reduced due to EM-Index mismatch)"
            adjusted_confidence = base_confidence * 0.7
            
            # Change regime to DIVERGENCE if in bullish zone
            if base_regime in [MarketRegime.STRONG_BULLISH, MarketRegime.EXTREME_BULLISH]:
                return (MarketRegime.DIVERGENCE, adjusted_position,
                        adjusted_action, adjusted_confidence)
            else:
                return (base_regime, adjusted_position, adjusted_action, adjusted_confidence)
        
        # If both EM and Index confirm (BEST signal!), can increase position
        if em_score >= REGIME_HEALTHY and em_trend == 'rising' and index_trend == 'rising':
            # This is the Nov 14-29 pattern - BEST environment!
            enhanced_position = min(base_position * 1.2, 1.5)  # Up to 150%
            enhanced_action = f"{base_action} + Index Confirms - HIGH CONVICTION!"
            enhanced_confidence = min(base_confidence * 1.1, 1.0)
            
            return (base_regime, enhanced_position, enhanced_action, enhanced_confidence)
        
        # If index falling but EM not crashing, be cautious
        if index_trend == 'falling' and em_score >= REGIME_HEALTHY:
            # Reduce position (breadth without leadership)
            cautious_position = base_position * 0.4  # Reduce to 40%
            cautious_action = "CAUTION: Index weak despite high EM (Divergence)"
            cautious_confidence = base_confidence * 0.6
            
            return (MarketRegime.DIVERGENCE, cautious_position,
                    cautious_action, cautious_confidence)
        
        # Otherwise, use base classification
        return (base_regime, base_position, base_action, base_confidence)


# =============================================================================
# Euphoria Detection
# =============================================================================


class EuphoriaDetector:
    """Detect high-risk euphoria / exhaustion patterns."""

    def __init__(self):
        self.em_threshold = EUPHORIA_EM_THRESHOLD
        self.plateau_days = EUPHORIA_EM_PLATEAU_DAYS
        self.em_spike = EUPHORIA_EM_SPIKE
        self.divergence_days = EUPHORIA_BREADTH_DIVERGENCE_DAYS
        self.ratio_peak = EUPHORIA_RATIO_PEAK
        self.wh_threshold = EUPHORIA_52WH_THRESHOLD
        self.wh_decline_threshold = EUPHORIA_52WH_DECLINE_THRESHOLD
        self.sma_overextension = EUPHORIA_SMA_OVEREXTENSION

    def detect(
        self,
        em_score: Optional[float],
        em_history: List[Optional[float]],
        ratio_45: Optional[float],
        ratio_45_history: List[Optional[float]],
        wh_count: Optional[int],
        wh_history: List[Optional[int]],
        sma_20: Optional[float],
        sma_50: Optional[float],
        index_trend: Optional[str],
        index_chng_5d: Optional[float]
    ) -> Tuple[str, str, List[str]]:
        warnings: List[str] = []
        severity = 0

        em_signal, em_conf = self._check_em_exhaustion(em_score, em_history)
        if em_signal:
            warnings.append(f"EM: {em_signal}")
            severity += 3 if em_conf == "HIGH" else 2

        breadth_signal, breadth_conf = self._check_breadth_divergence(
            index_trend, index_chng_5d, ratio_45_history
        )
        if breadth_signal:
            warnings.append(f"Breadth: {breadth_signal}")
            severity += 3 if breadth_conf == "HIGH" else 2

        wh_signal, wh_conf = self._check_wh_exhaustion(wh_count, wh_history)
        if wh_signal:
            warnings.append(f"52WH: {wh_signal}")
            severity += 2 if wh_conf == "MEDIUM" else 1

        sma_signal = self._check_sma_overextension(sma_20, sma_50)
        if sma_signal:
            warnings.append(f"SMA: {sma_signal}")
            severity += 1

        if severity >= 6:
            return "EXTREME", "HIGH", warnings
        if severity >= 4:
            return "HIGH", "MEDIUM", warnings
        if severity >= 2:
            return "MODERATE", "MEDIUM", warnings
        return "NORMAL", "LOW", warnings

    def _check_em_exhaustion(
        self,
        em_score: Optional[float],
        em_history: List[Optional[float]]
    ) -> Tuple[Optional[str], Optional[str]]:
        history = [v for v in em_history if v is not None]
        if em_score is None or len(history) < 2:
            return None, None

        em_change = em_score - history[-2]
        if em_change >= self.em_spike:
            return "PARABOLIC SPIKE", "HIGH"

        if em_score >= self.em_threshold:
            plateau = 0
            for i in range(len(history) - 1, max(-1, len(history) - self.plateau_days - 1), -1):
                if history[i] is not None and history[i] >= self.em_threshold:
                    if i > 0 and history[i] <= history[i - 1]:
                        plateau += 1
                    else:
                        break
                else:
                    break
            if plateau >= self.plateau_days:
                return f"PLATEAU ({plateau}d)", "MEDIUM"
        return None, None

    def _check_breadth_divergence(
        self,
        index_trend: Optional[str],
        index_chng_5d: Optional[float],
        ratio_history: List[Optional[float]]
    ) -> Tuple[Optional[str], Optional[str]]:
        clean_history = [v for v in ratio_history if v is not None]
        if len(clean_history) < 4:
            return None, None

        current_ratio = clean_history[-1]

        if index_trend == "rising" and (index_chng_5d or 0) > 0.3:
            declining = 0
            for i in range(len(clean_history) - 1, max(0, len(clean_history) - 4), -1):
                if i > 0 and clean_history[i] < clean_history[i - 1]:
                    declining += 1
            if declining >= self.divergence_days:
                return "NEGATIVE DIVERGENCE", "HIGH"

        if len(clean_history) >= 5:
            recent_max = max(clean_history[-5:])
            if recent_max >= self.ratio_peak and current_ratio < recent_max * 0.6:
                decline_pct = (1 - current_ratio / recent_max) * 100
                return f"ROLLOVER (-{decline_pct:.0f}%)", "HIGH"

        return None, None

    def _check_wh_exhaustion(
        self,
        wh_count: Optional[int],
        wh_history: List[Optional[int]]
    ) -> Tuple[Optional[str], Optional[str]]:
        clean_history = [v for v in wh_history if v is not None]
        if wh_count is None or len(clean_history) < 5:
            return None, None

        recent_max = max(clean_history[-5:])
        if recent_max >= self.wh_threshold and wh_count < recent_max * self.wh_decline_threshold:
            decline_pct = (1 - wh_count / recent_max) * 100
            return f"EXHAUSTION (-{decline_pct:.0f}%)", "MEDIUM"
        return None, None

    def _check_sma_overextension(
        self,
        sma_20: Optional[float],
        sma_50: Optional[float]
    ) -> Optional[str]:
        if sma_20 is None or sma_50 is None:
            return None
        if sma_20 >= self.sma_overextension and sma_50 >= self.sma_overextension:
            return "OVEREXTENDED"
        return None


# =============================================================================
# Testing
# =============================================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(message)s')
    
    print("\n" + "="*80)
    print("V3 CLASSIFIER TEST - Index-Aware")
    print("="*80 + "\n")
    
    classifier = TrendBasedRegimeClassifierV3()
    
    # Test cases from Oct-Nov 2024
    test_cases = [
        # (em, 1d, 3d, 5d, index_trend, index_pct, description)
        (65, +2, +8, +12, 'falling', -3.1, "Oct 1-8: High EM but index fell (FALSE POSITIVE in V2)"),
        (69, +5, +17, +30, 'flat', -0.5, "Oct 28-31: EM spike after crash but index flat (FALSE POSITIVE in V2)"),
        (60, +1, +0, -5, 'falling', -4.0, "Nov 1-4: High EM but about to crash (FALSE POSITIVE in V2)"),
        (78, +6, +18, +39, 'rising', +3.3, "Nov 14-29: High EM + rising index (TRUE POSITIVE - BEST!)"),
        (53, -12, -12, -12, 'falling', -2.4, "Oct 17: EM crashed (TRUE NEGATIVE - good exit signal)"),
    ]
    
    print("Comparing V2 vs V3 on actual Oct-Nov 2024 scenarios:\n")
    
    for em, ch1, ch3, ch5, idx_trend, idx_pct, desc in test_cases:
        result = classifier.classify(em, ch1, ch3, ch5, idx_trend, idx_pct)
        
        print(f"{desc}")
        print(f"  Input: EM={em}%, EM_3d={ch3:+.0f}, Index={idx_trend} ({idx_pct:+.1f}%)")
        print(f"  V3 Result: {result}")
        print()

