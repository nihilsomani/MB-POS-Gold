"""
EM (Equity Momentum) Calculator
================================
Calculates the follow-through success rate of Pocket Pivots market-wide.

EM = (Successful PPDs / Total PPDs) × 100

This is the primary metric for determining market regime and tradability.
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timedelta
from collections import defaultdict
import logging

from pocket_pivot_detector import PocketPivotSignal

logger = logging.getLogger(__name__)


class EMCalculator:
    """
    Calculates Equity Momentum (EM) score based on Pocket Pivot follow-through.
    
    Configuration:
    - lookback_days: How many days back to aggregate PPDs (default: 10)
    - min_sample_size: Minimum PPDs required for valid EM (default: 5)
    - smoothing: Apply smoothing to EM values (default: False)
    """
    
    def __init__(
        self,
        lookback_days: int = 10,
        min_sample_size: int = 5,
        smoothing: bool = False
    ):
        self.lookback_days = lookback_days
        self.min_sample_size = min_sample_size
        self.smoothing = smoothing
        
        # Storage for historical PPDs
        self.ppd_history: Dict[datetime, List[PocketPivotSignal]] = defaultdict(list)
        
        logger.info(f"EMCalculator initialized: lookback={lookback_days}d, "
                   f"min_sample={min_sample_size}")
    
    def add_ppds(self, ppds: List[PocketPivotSignal], date: datetime):
        """Add PPDs for a specific date to history"""
        self.ppd_history[date].extend(ppds)
        logger.debug(f"Added {len(ppds)} PPDs for {date.strftime('%Y-%m-%d')}")
    
    def calculate_em(
        self,
        current_date: datetime,
        ppds_with_followthrough: Optional[List[PocketPivotSignal]] = None
    ) -> Tuple[float, Dict]:
        """
        Calculate EM for a specific date.
        
        Args:
            current_date: Date to calculate EM for
            ppds_with_followthrough: Optional list of PPDs with follow-through already tracked.
                                     If None, uses stored history.
        
        Returns:
            Tuple of (EM score, metadata dict)
        """
        current_date = pd.to_datetime(current_date).tz_localize(None)
        
        # Get PPDs from the lookback window
        start_date = current_date - timedelta(days=self.lookback_days)
        
        if ppds_with_followthrough is not None:
            # Use provided PPDs
            relevant_ppds = [
                p for p in ppds_with_followthrough
                if start_date <= pd.to_datetime(p.date).tz_localize(None) <= current_date
            ]
        else:
            # Use stored history
            relevant_ppds = []
            for date, ppds in self.ppd_history.items():
                date_normalized = pd.to_datetime(date).tz_localize(None)
                if start_date <= date_normalized <= current_date:
                    relevant_ppds.extend(ppds)
        
        # Filter to only PPDs with follow-through tracking completed
        tracked_ppds = [p for p in relevant_ppds if p.is_success is not None]
        
        # Check minimum sample size
        if len(tracked_ppds) < self.min_sample_size:
            logger.debug(
                f"EM for {current_date.strftime('%Y-%m-%d')}: "
                f"Insufficient data ({len(tracked_ppds)} PPDs, need {self.min_sample_size})"
            )
            return 0.0, {
                'valid': False,
                'reason': 'insufficient_sample',
                'ppd_count': len(tracked_ppds),
                'min_required': self.min_sample_size
            }
        
        # Calculate success rate
        success_count = sum(1 for p in tracked_ppds if p.is_success)
        em_score = (success_count / len(tracked_ppds)) * 100
        
        metadata = {
            'valid': True,
            'ppd_count': len(tracked_ppds),
            'success_count': success_count,
            'failure_count': len(tracked_ppds) - success_count,
            'lookback_start': start_date,
            'lookback_end': current_date,
            'avg_follow_through_score': np.mean([p.follow_through_score for p in tracked_ppds])
        }
        
        logger.info(
            f"EM for {current_date.strftime('%Y-%m-%d')}: {em_score:.2f} "
            f"({success_count}/{len(tracked_ppds)} PPDs succeeded)"
        )
        
        return em_score, metadata
    
    def calculate_em_series(
        self,
        date_range: List[datetime],
        all_ppds: List[PocketPivotSignal]
    ) -> pd.DataFrame:
        """
        Calculate EM for a range of dates.
        
        Args:
            date_range: List of dates to calculate EM for
            all_ppds: List of all PPDs with follow-through tracking completed
        
        Returns:
            DataFrame with columns: date, EM, ppd_count, success_count, valid
        """
        results = []
        
        for date in date_range:
            em_score, metadata = self.calculate_em(date, all_ppds)
            
            results.append({
                'date': date,
                'EM': em_score,
                'ppd_count': metadata.get('ppd_count', 0),
                'success_count': metadata.get('success_count', 0),
                'valid': metadata.get('valid', False)
            })
        
        df = pd.DataFrame(results)
        
        # Apply smoothing if requested
        if self.smoothing and len(df) > 2:
            # Simple 3-day moving average
            df['EM_smoothed'] = df['EM'].rolling(window=3, center=True, min_periods=1).mean()
            df['EM'] = df['EM_smoothed']
            df.drop('EM_smoothed', axis=1, inplace=True)
        
        # Calculate day-to-day change
        df['EM_change'] = df['EM'].diff()
        
        return df
    
    def calculate_em_for_date_simple(
        self,
        ppds_in_window: List[PocketPivotSignal]
    ) -> Tuple[float, bool, int, int]:
        """
        Simplified EM calculation given a list of PPDs.
        
        Args:
            ppds_in_window: List of PPDs (with follow-through tracked) in the lookback window
        
        Returns:
            Tuple of (EM score, is_valid, ppd_count, success_count)
        """
        # Filter to tracked PPDs
        tracked = [p for p in ppds_in_window if p.is_success is not None]
        
        if len(tracked) < self.min_sample_size:
            return 0.0, False, len(tracked), 0
        
        success_count = sum(1 for p in tracked if p.is_success)
        em_score = (success_count / len(tracked)) * 100
        
        return em_score, True, len(tracked), success_count
    
    def get_historical_em_range(
        self,
        start_date: datetime,
        end_date: datetime
    ) -> pd.DataFrame:
        """Get EM values for a historical date range from stored history"""
        dates = pd.date_range(start=start_date, end=end_date, freq='D')
        return self.calculate_em_series(dates.tolist(), [])
    
    def get_recent_em_trend(self, recent_days: int = 5) -> Dict:
        """
        Analyze recent EM trend.
        
        Returns:
            Dict with trend analysis (improving, declining, stable)
        """
        if not self.ppd_history:
            return {'trend': 'unknown', 'reason': 'no_data'}
        
        # Get last N dates with data
        sorted_dates = sorted(self.ppd_history.keys(), reverse=True)
        recent_dates = sorted_dates[:recent_days]
        
        if len(recent_dates) < 2:
            return {'trend': 'unknown', 'reason': 'insufficient_history'}
        
        # Calculate EM for each date
        em_values = []
        for date in reversed(recent_dates):  # Chronological order
            em_score, metadata = self.calculate_em(date)
            if metadata['valid']:
                em_values.append(em_score)
        
        if len(em_values) < 2:
            return {'trend': 'unknown', 'reason': 'insufficient_valid_data'}
        
        # Analyze trend
        first_half_avg = np.mean(em_values[:len(em_values)//2])
        second_half_avg = np.mean(em_values[len(em_values)//2:])
        
        change = second_half_avg - first_half_avg
        
        if change > 2:
            trend = 'improving'
        elif change < -2:
            trend = 'declining'
        else:
            trend = 'stable'
        
        return {
            'trend': trend,
            'change': change,
            'recent_values': em_values,
            'first_half_avg': first_half_avg,
            'second_half_avg': second_half_avg
        }


# ==============================================================================
# Testing / Example Usage
# ==============================================================================

if __name__ == "__main__":
    from pocket_pivot_detector import PocketPivotSignal
    
    # Configure logging for testing
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Create sample PPDs with follow-through results
    base_date = datetime(2024, 1, 1)
    sample_ppds = []
    
    # Days 1-5: 8 PPDs, 2 successful (25% = weak market)
    for i in range(8):
        ppd = PocketPivotSignal(
            symbol=f"STOCK{i}",
            date=base_date + timedelta(days=i % 5),
            open_price=100.0,
            close_price=105.0,
            high_price=106.0,
            low_price=100.0,
            volume=5000000,
            percent_gain=5.0,
            volume_vs_avg=2.0,
            volume_percentile=80.0,
            volume_vs_red_days=1.5,
            follow_through_score=0.8 if i < 2 else 0.3,  # 2 successes
            is_success=(i < 2)
        )
        sample_ppds.append(ppd)
    
    # Days 6-10: 10 PPDs, 8 successful (80% = strong market)
    for i in range(10):
        ppd = PocketPivotSignal(
            symbol=f"STOCK{i+8}",
            date=base_date + timedelta(days=6 + i % 4),
            open_price=100.0,
            close_price=105.0,
            high_price=106.0,
            low_price=100.0,
            volume=5000000,
            percent_gain=5.0,
            volume_vs_avg=2.0,
            volume_percentile=80.0,
            volume_vs_red_days=1.5,
            follow_through_score=0.8 if i < 8 else 0.3,  # 8 successes
            is_success=(i < 8)
        )
        sample_ppds.append(ppd)
    
    print(f"\n{'='*80}")
    print(f"EM CALCULATOR TEST")
    print(f"{'='*80}\n")
    
    # Test EM calculation
    calculator = EMCalculator(lookback_days=10, min_sample_size=5)
    
    # Calculate for day 5 (should show ~25% EM)
    test_date_1 = base_date + timedelta(days=5)
    em_1, meta_1 = calculator.calculate_em(test_date_1, sample_ppds)
    print(f"EM on Day 5: {em_1:.1f}% (Expected ~25%)")
    print(f"  PPDs: {meta_1['ppd_count']}, Successes: {meta_1.get('success_count', 'N/A')}\n")
    
    # Calculate for day 10 (should show higher EM due to recent successes)
    test_date_2 = base_date + timedelta(days=10)
    em_2, meta_2 = calculator.calculate_em(test_date_2, sample_ppds)
    print(f"EM on Day 10: {em_2:.1f}%")
    print(f"  PPDs: {meta_2['ppd_count']}, Successes: {meta_2.get('success_count', 'N/A')}\n")
    
    # Calculate series
    date_range = [base_date + timedelta(days=i) for i in range(11)]
    em_series = calculator.calculate_em_series(date_range, sample_ppds)
    
    print("EM Series:")
    print(em_series[['date', 'EM', 'ppd_count', 'valid']].to_string(index=False))

