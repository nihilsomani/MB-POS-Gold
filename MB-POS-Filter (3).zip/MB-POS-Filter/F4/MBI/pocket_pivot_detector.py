"""
Pocket Pivot Detector
=====================
Identifies institutional accumulation signals based on price + volume criteria.

A Pocket Pivot Day (PPD) occurs when:
1. Stock gains ≥ 4.5% (close vs open)
2. Volume exceeds accumulation threshold
3. Price action suggests buying pressure
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


@dataclass
class PocketPivotSignal:
    """Data class for a detected pocket pivot"""
    symbol: str
    date: datetime
    open_price: float
    close_price: float
    high_price: float
    low_price: float
    volume: int
    
    # Metrics
    percent_gain: float  # Close vs open
    volume_vs_avg: float  # Volume / 50-day average
    volume_percentile: float  # Percentile in last 60 days
    volume_vs_red_days: float  # Volume / max(last 10 red day volumes)
    
    # Status (for follow-through tracking)
    follow_through_score: Optional[float] = None
    is_success: Optional[bool] = None
    
    def __str__(self):
        return (f"{self.symbol} on {self.date.strftime('%Y-%m-%d')}: "
                f"+{self.percent_gain:.2f}% | Vol: {self.volume_vs_avg:.1f}x avg")


class PocketPivotDetector:
    """
    Detects Pocket Pivot signals in stock data.
    
    Configuration parameters:
    - ppd_threshold: Minimum % gain (default: 4.5)
    - volume_multiplier: Minimum volume vs 50-day avg (default: 1.5)
    - volume_percentile_threshold: Minimum percentile (default: 75)
    - use_red_day_volume: Check against red days (default: True)
    """
    
    def __init__(
        self,
        ppd_threshold: float = 4.5,
        volume_multiplier: float = 1.5,
        volume_percentile_threshold: float = 75,
        use_red_day_volume: bool = True
    ):
        self.ppd_threshold = ppd_threshold
        self.volume_multiplier = volume_multiplier
        self.volume_percentile_threshold = volume_percentile_threshold
        self.use_red_day_volume = use_red_day_volume
        
        logger.info(f"PocketPivotDetector initialized: threshold={ppd_threshold}%, "
                   f"vol_mult={volume_multiplier}x, percentile={volume_percentile_threshold}")
    
    def detect_pocket_pivots(
        self,
        df: pd.DataFrame,
        symbol: str,
        target_date: Optional[datetime] = None
    ) -> List[PocketPivotSignal]:
        """
        Detect pocket pivot signals in a DataFrame.
        
        Args:
            df: DataFrame with OHLCV data (must have 'date' index)
            symbol: Stock symbol
            target_date: If specified, only check this date. Otherwise check all dates.
        
        Returns:
            List of PocketPivotSignal objects
        """
        if df.empty:
            logger.warning(f"Empty DataFrame for {symbol}")
            return []
        
        # Ensure required columns exist
        required_cols = ['open', 'high', 'low', 'close', 'volume']
        if not all(col in df.columns for col in required_cols):
            logger.error(f"Missing required columns for {symbol}. Have: {df.columns.tolist()}")
            return []
        
        # Calculate metrics needed for detection
        df = df.copy()
        df['percent_gain'] = ((df['close'] - df['open']) / df['open']) * 100
        df['volume_ma50'] = df['volume'].rolling(window=50, min_periods=20).mean()
        df['volume_vs_avg'] = df['volume'] / df['volume_ma50']
        df['volume_percentile'] = df['volume'].rolling(window=60, min_periods=20).apply(
            lambda x: (x.iloc[-1] > x).sum() / len(x) * 100 if len(x) > 0 else 0,
            raw=False
        )
        
        # Calculate red day volume max (for last 10 down days)
        if self.use_red_day_volume:
            df['is_red_day'] = df['close'] < df['open']
            df['red_day_volume'] = df['volume'].where(df['is_red_day'], np.nan)
            df['max_red_volume_10d'] = df['red_day_volume'].rolling(
                window=10, min_periods=5
            ).max()
            df['volume_vs_red_days'] = df['volume'] / df['max_red_volume_10d']
        else:
            df['volume_vs_red_days'] = np.nan
        
        # Filter to target date if specified
        if target_date is not None:
            target_date_normalized = pd.to_datetime(target_date).tz_localize(None)
            df = df[df.index == target_date_normalized]
            if df.empty:
                logger.debug(f"No data for {symbol} on {target_date}")
                return []
        
        # Detect pocket pivots
        ppd_signals = []
        
        for idx, row in df.iterrows():
            # Check basic criteria
            if pd.isna(row['percent_gain']) or pd.isna(row['volume_vs_avg']):
                continue
            
            # Must meet gain threshold
            if row['percent_gain'] < self.ppd_threshold:
                continue
            
            # Must meet at least ONE volume criterion
            volume_criteria_met = []
            
            # Criterion 1: Volume > 1.5x average
            if not pd.isna(row['volume_vs_avg']) and row['volume_vs_avg'] >= self.volume_multiplier:
                volume_criteria_met.append("vol_vs_avg")
            
            # Criterion 2: Volume in top percentile
            if not pd.isna(row['volume_percentile']) and row['volume_percentile'] >= self.volume_percentile_threshold:
                volume_criteria_met.append("percentile")
            
            # Criterion 3: Volume > max red day volume
            if (self.use_red_day_volume and 
                not pd.isna(row['volume_vs_red_days']) and 
                row['volume_vs_red_days'] >= 1.0):
                volume_criteria_met.append("vs_red_days")
            
            # If no volume criteria met, skip
            if not volume_criteria_met:
                continue
            
            # Valid Pocket Pivot!
            ppd = PocketPivotSignal(
                symbol=symbol,
                date=idx.to_pydatetime() if hasattr(idx, 'to_pydatetime') else idx,
                open_price=float(row['open']),
                close_price=float(row['close']),
                high_price=float(row['high']),
                low_price=float(row['low']),
                volume=int(row['volume']),
                percent_gain=float(row['percent_gain']),
                volume_vs_avg=float(row['volume_vs_avg']) if not pd.isna(row['volume_vs_avg']) else 0.0,
                volume_percentile=float(row['volume_percentile']) if not pd.isna(row['volume_percentile']) else 0.0,
                volume_vs_red_days=float(row['volume_vs_red_days']) if not pd.isna(row['volume_vs_red_days']) else 0.0
            )
            
            logger.debug(f"PPD detected: {ppd} (volume criteria: {', '.join(volume_criteria_met)})")
            ppd_signals.append(ppd)
        
        return ppd_signals
    
    def detect_for_universe(
        self,
        stock_data: Dict[str, pd.DataFrame],
        target_date: datetime
    ) -> List[PocketPivotSignal]:
        """
        Detect pocket pivots across entire universe for a specific date.
        
        Args:
            stock_data: Dict mapping symbol -> DataFrame with OHLCV data
            target_date: Date to check for PPDs
        
        Returns:
            List of all PocketPivotSignals detected on that date
        """
        all_ppds = []
        
        for symbol, df in stock_data.items():
            ppds = self.detect_pocket_pivots(df, symbol, target_date)
            all_ppds.extend(ppds)
        
        if all_ppds:
            logger.info(f"Detected {len(all_ppds)} pocket pivots on {target_date.strftime('%Y-%m-%d')}")
        
        return all_ppds
    
    def get_statistics(self, ppds: List[PocketPivotSignal]) -> Dict:
        """Get summary statistics for a list of pocket pivots"""
        if not ppds:
            return {
                'count': 0,
                'avg_gain': 0.0,
                'avg_volume_mult': 0.0,
                'symbols': []
            }
        
        return {
            'count': len(ppds),
            'avg_gain': np.mean([p.percent_gain for p in ppds]),
            'max_gain': max([p.percent_gain for p in ppds]),
            'avg_volume_mult': np.mean([p.volume_vs_avg for p in ppds]),
            'symbols': [p.symbol for p in ppds]
        }


# ==============================================================================
# Testing / Example Usage
# ==============================================================================

if __name__ == "__main__":
    # Configure logging for testing
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    
    # Create sample data
    dates = pd.date_range('2024-01-01', periods=100, freq='D')
    sample_data = pd.DataFrame({
        'open': 100 + np.random.randn(100).cumsum(),
        'high': 105 + np.random.randn(100).cumsum(),
        'low': 95 + np.random.randn(100).cumsum(),
        'close': 100 + np.random.randn(100).cumsum(),
        'volume': np.random.randint(1000000, 5000000, 100)
    }, index=dates)
    
    # Add a fake pocket pivot day
    sample_data.loc[dates[50], 'open'] = 100
    sample_data.loc[dates[50], 'close'] = 105  # +5% gain
    sample_data.loc[dates[50], 'volume'] = 8000000  # High volume
    
    # Test detector
    detector = PocketPivotDetector()
    ppds = detector.detect_pocket_pivots(sample_data, "TEST")
    
    print(f"\n{'='*80}")
    print(f"POCKET PIVOT DETECTOR TEST")
    print(f"{'='*80}\n")
    print(f"Detected {len(ppds)} pocket pivots in sample data:\n")
    
    for ppd in ppds:
        print(f"  {ppd}")
    
    if ppds:
        stats = detector.get_statistics(ppds)
        print(f"\nStatistics:")
        print(f"  Average gain: {stats['avg_gain']:.2f}%")
        print(f"  Average volume multiplier: {stats['avg_volume_mult']:.2f}x")

