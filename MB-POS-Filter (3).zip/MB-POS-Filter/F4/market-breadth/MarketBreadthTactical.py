"""
Market Breadth Tactical Scanner
================================

Daily trading signal generator based on New Highs/New Lows and Advance/Decline analysis.

Key Features:
1. New Highs/New Lows (13-week lookback) - Classic breadth indicator
2. Advance/Decline ratio tracking
3. 4-day trend analysis (T, T-1, T-2, T-3)
4. Signal Scoring System (-10 to +10 scale)
5. SQLite caching for fast performance
6. Detailed per-stock CSV output with rankings

Output:
- Console: Market pulse signal with score
- CSV: Detailed stock-by-stock analysis
- Insights: Top gainers/losers, new highs/lows, volatility rankings

Usage:
    python MarketBreadthTactical.py

Best For: Daily trading signals, momentum shifts, short-term tactical decisions

Author: Market Analysis Framework
Version: 1.0.0
"""

import pandas as pd
from kiteconnect import KiteConnect
import logging
import os
import json
from datetime import date, timedelta, datetime
import time
import numpy as np
import sqlite3
from pathlib import Path

# --- Configuration ---
# API Credentials - Use environment variables in production
API_KEY = os.environ.get('KITE_API_KEY', "3bi2yh8g830vq3y6")
API_SECRET = os.environ.get('KITE_API_SECRET', "YOUR_API_SECRET")
ACCESS_TOKEN = os.environ.get('KITE_ACCESS_TOKEN', "IPu3YFNqPkAlRsmQ6R7whtIhJSJsLsKf")

# Stock List & Cache Configuration
STOCK_LIST_CSV = "../../../data/Nifty50stocks.csv"
CSV_SYMBOL_COLUMN = "Symbol"
CACHE_DIR = Path("./cache")
INSTRUMENT_CACHE_FILE = CACHE_DIR / "instrument_cache.json"
HISTORY_CACHE_DB = CACHE_DIR / "historical_data.db"
CACHE_EXPIRY_DAYS = 1  # Refresh instrument cache after this many days

# Indicator Parameters
MA_BREADTH = 50  # Moving Average Period for Breadth Check
NHNL_LOOKBACK = 13  # Lookback period for New Highs/Lows (approx 52 weeks)
DAYS_TO_COMPARE = 4  # Number of days to analyze the trend (Today + previous 3 days)
HISTORY_DAYS = int((NHNL_LOOKBACK + DAYS_TO_COMPARE + 39) * 2)  # Extra buffer

# Rate Limiting Parameters
API_CALLS_PER_MINUTE = 60  # Kite API limit (adjust based on your plan)
API_CALLS_BUFFER = 0.5  # Safety buffer to stay under limit (90% of max)
API_BATCH_SIZE = 10  # Process stocks in batches for progress tracking

# Output Configuration
OUTPUT_DIR = Path("./output")

# --- Setup Logging ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("tactical_breadth.log"),
        logging.StreamHandler()
    ]
)

# --- Rate Limiter Class ---
class RateLimiter:
    """Manages API call rate limiting to prevent exceeding quota."""
    
    def __init__(self, calls_per_minute, buffer_factor=0.9):
        self.call_interval = 60.0 / (calls_per_minute * buffer_factor)
        self.last_call_time = 0
        self.calls_made = 0
    
    def wait_if_needed(self):
        """Wait if necessary to maintain the rate limit."""
        current_time = time.time()
        time_since_last = current_time - self.last_call_time
        
        if time_since_last < self.call_interval:
            wait_time = self.call_interval - time_since_last
            time.sleep(wait_time)
        
        self.last_call_time = time.time()
        self.calls_made += 1
        return self.calls_made

# --- Cache Management Functions ---
def ensure_cache_dir():
    """Create cache directory if it doesn't exist."""
    CACHE_DIR.mkdir(exist_ok=True)
    OUTPUT_DIR.mkdir(exist_ok=True)

def initialize_db():
    """Initialize SQLite database for historical data cache."""
    conn = sqlite3.connect(HISTORY_CACHE_DB)
    cursor = conn.cursor()
    
    # Create tables if they don't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS historical_data (
        symbol TEXT,
        date TEXT,
        open REAL,
        high REAL,
        low REAL,
        close REAL,
        volume INTEGER,
        last_updated TEXT,
        PRIMARY KEY (symbol, date)
    )
    ''')
    
    # Create index on symbol for faster queries
    cursor.execute('CREATE INDEX IF NOT EXISTS idx_symbol ON historical_data (symbol)')
    conn.commit()
    conn.close()

def cache_instruments(kite):
    """Fetch and cache instrument tokens from Kite API."""
    try:
        instruments = kite.instruments("NSE")
        instrument_map = {ins['tradingsymbol']: ins['instrument_token'] for ins in instruments}
        
        cache_data = {
            "last_updated": datetime.now().isoformat(),
            "instruments": instrument_map
        }
        
        with open(INSTRUMENT_CACHE_FILE, 'w') as f:
            json.dump(cache_data, f)
        
        logging.info(f"Cached {len(instrument_map)} instruments to {INSTRUMENT_CACHE_FILE}")
        return instrument_map
    
    except Exception as e:
        logging.error(f"Error caching instruments: {e}", exc_info=True)
        return {}

def get_instrument_tokens(kite):
    """Get instrument tokens from cache or refresh if expired."""
    if not INSTRUMENT_CACHE_FILE.exists():
        logging.info("Instrument cache not found, creating new cache")
        return cache_instruments(kite)
    
    try:
        with open(INSTRUMENT_CACHE_FILE, 'r') as f:
            cache_data = json.load(f)
        
        # Check if cache is expired
        last_updated = datetime.fromisoformat(cache_data["last_updated"])
        cache_age = (datetime.now() - last_updated).days
        
        if cache_age >= CACHE_EXPIRY_DAYS:
            logging.info(f"Instrument cache expired ({cache_age} days old), refreshing")
            return cache_instruments(kite)
        
        logging.info(f"Using cached instruments ({len(cache_data['instruments'])} tokens)")
        return cache_data["instruments"]
    
    except Exception as e:
        logging.error(f"Error reading instrument cache: {e}", exc_info=True)
        return cache_instruments(kite)

def get_cached_history(symbol, from_date, to_date):
    """Retrieve historical data from cache if available."""
    conn = sqlite3.connect(HISTORY_CACHE_DB)
    cursor = conn.cursor()
    
    # Convert dates to strings for SQLite query
    from_date_str = from_date.strftime('%Y-%m-%d')
    to_date_str = to_date.strftime('%Y-%m-%d')
    
    cursor.execute(
        "SELECT date, open, high, low, close, volume FROM historical_data "
        "WHERE symbol = ? AND date BETWEEN ? AND ? "
        "ORDER BY date",
        (symbol, from_date_str, to_date_str)
    )
    
    records = cursor.fetchall()
    conn.close()
    
    if not records:
        return None
    
    # Convert to DataFrame with proper column names
    df = pd.DataFrame(records, columns=['date', 'open', 'high', 'low', 'close', 'volume'])
    df['date'] = pd.to_datetime(df['date']).dt.date
    
    return df

def cache_historical_data(symbol, data):
    """Store historical data in SQLite cache."""
    if data is None or data.empty:
        return
    
    conn = sqlite3.connect(HISTORY_CACHE_DB)
    cursor = conn.cursor()
    
    # Prepare data for insertion
    now = datetime.now().isoformat()
    records = []
    
    for _, row in data.iterrows():
        date_str = row['date'].strftime('%Y-%m-%d') if isinstance(row['date'], date) else row['date']
        record = (
            symbol, date_str, row['open'], row['high'], 
            row['low'], row['close'], row.get('volume', 0), now
        )
        records.append(record)
    
    # Use INSERT OR REPLACE to update existing records
    cursor.executemany(
        "INSERT OR REPLACE INTO historical_data "
        "(symbol, date, open, high, low, close, volume, last_updated) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        records
    )
    
    conn.commit()
    conn.close()
    logging.debug(f"Cached {len(records)} data points for {symbol}")

# --- Core Functions ---
def initialize_kite(api_key, access_token):
    """Initializes the KiteConnect client with error handling."""
    try:
        kite = KiteConnect(api_key=api_key)
        kite.set_access_token(access_token)
        
        # Verify connection by fetching a basic profile attribute
        profile = kite.profile()
        logging.info(f"Connected to Kite as user: {profile.get('user_id', 'Unknown')}")
        return kite
    except Exception as e:
        logging.error(f"Error initializing Kite Connect: {e}", exc_info=True)
        return None

def read_stock_list(csv_filepath, symbol_column):
    """Reads the stock list from CSV with validation and error handling."""
    try:
        df = pd.read_csv(csv_filepath)
        
        if symbol_column not in df.columns:
            logging.error(f"Column '{symbol_column}' not found in {csv_filepath}")
            return None
        
        # Clean symbols: strip whitespace, remove duplicates, filter empty
        symbols = df[symbol_column].astype(str).str.strip()
        symbols = symbols[symbols != ""].unique().tolist()
        
        if not symbols:
            logging.error(f"No valid symbols found in {csv_filepath}")
            return None
            
        logging.info(f"Read {len(symbols)} unique symbols from {csv_filepath}")
        return symbols
    
    except FileNotFoundError:
        logging.error(f"CSV file not found: {csv_filepath}")
        return None
    except Exception as e:
        logging.error(f"Error reading CSV file {csv_filepath}: {e}", exc_info=True)
        return None

def get_historical_data(kite, symbol, days_history, rate_limiter, instrument_tokens, interval="day"):
    """Fetches historical data with caching and rate limiting."""
    to_date = date.today()
    from_date = to_date - timedelta(days=days_history)
    
    # First try to get data from cache
    cached_data = get_cached_history(symbol, from_date, to_date)
    if cached_data is not None and len(cached_data) >= NHNL_LOOKBACK + DAYS_TO_COMPARE:
        logging.info(f"{symbol}: Using cached historical data ({len(cached_data)} records)")
        return cached_data
    else:
        if cached_data is not None:
            logging.info(f"{symbol}: Cached data insufficient ({len(cached_data)} records), will fetch from API")
        else:
            logging.info(f"{symbol}: No cached data, will fetch from API")
    
    # If not in cache or insufficient, fetch from API
    instrument = f"NSE:{symbol}"
    
    try:
        # Use instrument token if available for more efficient API calls
        instrument_param = instrument_tokens.get(symbol, instrument)
        
        # Wait for rate limiting if needed
        call_count = rate_limiter.wait_if_needed()
        if call_count % 20 == 0:
            logging.info(f"Made {call_count} API calls so far")
        
        logging.info(f"Fetching historical data for {symbol} ({from_date} to {to_date}) from API")
        records = kite.historical_data(instrument_param, from_date, to_date, interval)
        
        if not records:
            logging.warning(f"No historical data received for {symbol} from API")
            return None
        
        df = pd.DataFrame(records)
        
        # Convert 'date' column to date objects
        if pd.api.types.is_datetime64_any_dtype(df['date']):
            df['date'] = df['date'].dt.date
        else:
            df['date'] = pd.to_datetime(df['date']).dt.date
        
        # Sort by date (ascending)
        df = df.sort_values(by='date').reset_index(drop=True)
        
        # Basic validation
        required_cols = ['date', 'open', 'high', 'low', 'close']
        if not all(col in df.columns for col in required_cols):
            logging.warning(f"Missing required columns in data for {symbol}")
            return None
        
        # Check data sufficiency
        min_required_length = NHNL_LOOKBACK + DAYS_TO_COMPARE
        if len(df) < min_required_length:
            logging.warning(f"Insufficient data points for {symbol} (got {len(df)}, need ~{min_required_length})")
            return None
        
        logging.info(f"{symbol}: Successfully fetched {len(df)} records from API")
        # Cache the fetched data
        cache_historical_data(symbol, df)
        
        return df
    
    except Exception as e:
        logging.error(f"Error fetching data for {symbol}: {e}")
        return None

def calculate_indicators_over_time(df, ma_period, nhnl_lookback, num_days):
    """Calculates multiple market breadth indicators with optimized performance."""
    required_length = max(ma_period, nhnl_lookback) + num_days - 1
    if df is None or df.empty or len(df) < required_length:
        logging.warning(f"Indicator calc: DataFrame empty or too short (len={len(df) if df is not None else 0}, required={required_length})")
        return None
    
    try:
        # Vectorized calculations for performance
        # Moving Average
        ma_col = f'SMA_{ma_period}'
        df[ma_col] = df['close'].rolling(window=ma_period, min_periods=ma_period).mean()
        
        # Advance/Decline
        df['prev_close'] = df['close'].shift(1)
        df['advance'] = (df['close'] > df['prev_close']) & (~df['prev_close'].isna())
        df['decline'] = (df['close'] < df['prev_close']) & (~df['prev_close'].isna())
        
        # New Highs/Lows with minimum periods requirement
        min_nhnl_periods = int(nhnl_lookback * 0.9)
        df['rolling_high'] = df['high'].rolling(window=nhnl_lookback, min_periods=min_nhnl_periods).max().shift(1)
        df['rolling_low'] = df['low'].rolling(window=nhnl_lookback, min_periods=min_nhnl_periods).min().shift(1)
        
        df['new_high'] = (df['high'] >= df['rolling_high']) & (~df['rolling_high'].isna())
        df['new_low'] = (df['low'] <= df['rolling_low']) & (~df['rolling_low'].isna())
        
        # Extract valid data for final analysis
        valid_data = df.dropna(subset=[ma_col, 'prev_close', 'rolling_high', 'rolling_low'])
        
        if len(valid_data) < num_days:
            return None
        
        last_n_rows = valid_data.tail(num_days).copy()
        
        # Prepare results dict with all indicators
        results = {
            'date': last_n_rows['date'].tolist(),
            'above_ma': (last_n_rows['close'] > last_n_rows[ma_col]).tolist(),
            'advance': last_n_rows['advance'].tolist(),
            'decline': last_n_rows['decline'].tolist(),
            'new_high': last_n_rows['new_high'].tolist(),
            'new_low': last_n_rows['new_low'].tolist()
        }
        
        # Validation check
        if not all(len(v) == num_days for k, v in results.items()):
            return None
        
        return results
    
    except Exception as e:
        logging.error(f"Error calculating indicators: {e}", exc_info=True)
        return None

def generate_stock_detail_csv(historical_data_dict, ma_period, nhnl_lookback, days_to_compare, output_filename=None):
    """
    Generate a detailed CSV file with per-stock metrics and breadth indicators.
    
    Args:
        historical_data_dict: Dictionary mapping symbols to their historical DataFrame
        ma_period: Period for Moving Average calculation
        nhnl_lookback: Lookback period for New Highs/Lows
        days_to_compare: Number of days to analyze
        output_filename: Optional custom filename for output CSV
    
    Returns:
        Pandas DataFrame containing detailed per-stock data
    """
    import pandas as pd
    from datetime import datetime
    import os
    
    # Create output directory if it doesn't exist
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Generate filename if not provided
    if output_filename is None:
        current_date = datetime.now().strftime("%Y%m%d")
        output_filename = os.path.join(OUTPUT_DIR, f"tactical_detail_{current_date}.csv")
    
    # Get list of symbols from the dictionary
    symbols = list(historical_data_dict.keys())
    total_symbols = len(symbols)
    
    print(f"\nGenerating detailed analysis for {total_symbols} symbols...")
    
    # List to hold all stock data
    all_stock_data = []
    
    # Process each symbol
    for idx, symbol in enumerate(symbols):
        # Display progress every 10%
        if idx % max(1, total_symbols // 10) == 0:
            print(f"Processing: {idx}/{total_symbols} stocks ({idx/total_symbols*100:.1f}%)")
        
        # Skip if we don't have historical data for this symbol
        if symbol not in historical_data_dict or historical_data_dict[symbol] is None:
            continue
            
        # Get historical data for this symbol
        hist_data = historical_data_dict[symbol]
        
        # Calculate indicators
        ma_col = f'SMA_{ma_period}'
        
        # Check if we need to calculate MA
        if ma_col not in hist_data.columns:
            hist_data[ma_col] = hist_data['close'].rolling(window=ma_period, min_periods=ma_period).mean()
        
        # Calculate other indicators
        hist_data['prev_close'] = hist_data['close'].shift(1)
        hist_data['advance'] = (hist_data['close'] > hist_data['prev_close']) & (~hist_data['prev_close'].isna())
        hist_data['decline'] = (hist_data['close'] < hist_data['prev_close']) & (~hist_data['prev_close'].isna())
        
        # New Highs/Lows
        min_nhnl_periods = int(nhnl_lookback * 0.9)
        hist_data['rolling_high'] = hist_data['high'].rolling(window=nhnl_lookback, min_periods=min_nhnl_periods).max().shift(1)
        hist_data['rolling_low'] = hist_data['low'].rolling(window=nhnl_lookback, min_periods=min_nhnl_periods).min().shift(1)
        
        hist_data['new_high'] = (hist_data['high'] >= hist_data['rolling_high']) & (~hist_data['rolling_high'].isna())
        hist_data['new_low'] = (hist_data['low'] <= hist_data['rolling_low']) & (~hist_data['rolling_low'].isna())
        
        # Get last N days for analysis
        last_n_days = hist_data.tail(days_to_compare).copy()
        
        # Skip if we don't have enough data
        if len(last_n_days) < days_to_compare:
            continue
            
        # Create a data record for this stock
        stock_record = {'Symbol': symbol}
        
        # Add data for each day
        for i in range(days_to_compare):
            # Reverse index for display (newest first)
            rev_idx = days_to_compare - 1 - i
            day_label = f"T-{rev_idx}" if rev_idx > 0 else "T"
            
            # Get current row
            try:
                row = last_n_days.iloc[i]
            except IndexError:
                # Skip if day doesn't exist
                continue
                
            # Add date
            date_val = row['date'] if 'date' in row else row.name
            date_str = date_val.strftime('%Y-%m-%d') if hasattr(date_val, 'strftime') else str(date_val)
            stock_record[f'Date_{day_label}'] = date_str
            
            # Add price data
            stock_record[f'Close_{day_label}'] = row['close']
            
            # Add % change
            if i > 0:
                prev_close = last_n_days.iloc[i-1]['close']
                pct_change = ((row['close'] - prev_close) / prev_close) * 100
                stock_record[f'Change%_{day_label}'] = round(pct_change, 2)
            
            # Add indicator values
            stock_record[f'Above_MA{ma_period}_{day_label}'] = row['close'] > row[ma_col]
            stock_record[f'Advance_{day_label}'] = row['advance']
            stock_record[f'Decline_{day_label}'] = row['decline']
            stock_record[f'New_High_{day_label}'] = row['new_high']
            stock_record[f'New_Low_{day_label}'] = row['new_low']
        
        # Add latest close
        stock_record['Latest_Close'] = last_n_days.iloc[-1]['close']
        
        # Add latest MA value
        latest_ma = last_n_days.iloc[-1][ma_col]
        stock_record[f'Latest_{ma_col}'] = latest_ma
        
        # Calculate % from MA
        pct_from_ma = ((stock_record['Latest_Close'] - latest_ma) / latest_ma) * 100
        stock_record['Pct_From_MA'] = round(pct_from_ma, 2)
        
        # Count New Highs and New Lows over the period
        stock_record['Period_New_Highs'] = last_n_days['new_high'].sum()
        stock_record['Period_New_Lows'] = last_n_days['new_low'].sum()
        
        # Calculate volatility
        returns = last_n_days['close'].pct_change().dropna()
        volatility = returns.std() * 100 if len(returns) > 0 else 0
        stock_record['Period_Volatility'] = round(volatility, 2)
        
        # Calculate trend consistency
        advances = last_n_days['advance'].sum()
        trend_consistency = (advances / len(last_n_days)) * 100
        stock_record['Trend_Consistency'] = round(trend_consistency, 2)
        
        # Add to main list
        all_stock_data.append(stock_record)
    
    # Check if we have any data
    if not all_stock_data:
        print("No valid data to create detailed CSV")
        return None
    
    # Convert to DataFrame
    df = pd.DataFrame(all_stock_data)
    
    # Write to CSV
    df.to_csv(output_filename, index=False)
    print(f"\nDetailed stock analysis saved to: {output_filename}")
    
    return df


def analyze_stock_detail(df):
    """
    Analyze the detailed stock data and provide actionable insights.
    
    Args:
        df: DataFrame with stock details
        
    Returns:
        Dictionary with analysis results
    """
    if df is None or len(df) == 0:
        return {"error": "No data available for analysis"}
    
    insights = {}
    
    # 1. Top performers (latest day)
    if 'Change%_T' in df.columns:
        insights['top_gainers'] = df.nlargest(10, 'Change%_T')[['Symbol', 'Change%_T', 'Latest_Close']]
        insights['top_losers'] = df.nsmallest(10, 'Change%_T')[['Symbol', 'Change%_T', 'Latest_Close']]
    
    # 2. Stocks furthest from MA
    if 'Pct_From_MA' in df.columns:
        insights['most_above_ma'] = df.nlargest(10, 'Pct_From_MA')[['Symbol', 'Pct_From_MA', 'Latest_Close']]
        insights['most_below_ma'] = df.nsmallest(10, 'Pct_From_MA')[['Symbol', 'Pct_From_MA', 'Latest_Close']]
    
    # 3. Stocks with multiple new highs/lows
    if 'Period_New_Highs' in df.columns:
        # Stocks with at least 2 new highs
        multi_nh = df[df['Period_New_Highs'] >= 2]
        insights['multiple_new_highs'] = multi_nh.nlargest(10, 'Period_New_Highs')[['Symbol', 'Period_New_Highs', 'Latest_Close']]
    
    if 'Period_New_Lows' in df.columns:
        # Stocks with at least 2 new lows
        multi_nl = df[df['Period_New_Lows'] >= 2]
        insights['multiple_new_lows'] = multi_nl.nlargest(10, 'Period_New_Lows')[['Symbol', 'Period_New_Lows', 'Latest_Close']]
    
    # 4. Most volatile stocks
    if 'Period_Volatility' in df.columns:
        insights['highest_volatility'] = df.nlargest(10, 'Period_Volatility')[['Symbol', 'Period_Volatility', 'Latest_Close']]
    
    # 5. Most consistent trending stocks
    if 'Trend_Consistency' in df.columns:
        insights['most_consistent_uptrend'] = df.nlargest(10, 'Trend_Consistency')[['Symbol', 'Trend_Consistency', 'Latest_Close']]
    
    # 6. Overall market breadth stats
    above_ma_col = next((col for col in df.columns if col.startswith('Above_MA') and col.endswith('_T')), None)
    new_high_col = next((col for col in df.columns if col.startswith('New_High_T')), None)
    new_low_col = next((col for col in df.columns if col.startswith('New_Low_T')), None)
    
    insights['stats'] = {
        'total_stocks': len(df),
        'above_ma': sum(df[above_ma_col]) if above_ma_col else 0,
        'new_highs_today': sum(df[new_high_col]) if new_high_col else 0,
        'new_lows_today': sum(df[new_low_col]) if new_low_col else 0
    }
    
    # Calculate MA distribution
    if 'Pct_From_MA' in df.columns:
        bins = [-100, -20, -10, -5, 0, 5, 10, 20, 100]
        labels = ['< -20%', '-20% to -10%', '-10% to -5%', '-5% to 0%', 
                 '0% to 5%', '5% to 10%', '10% to 20%', '> 20%']
        
        df['MA_Range'] = pd.cut(df['Pct_From_MA'], bins=bins, labels=labels)
        ma_dist = df['MA_Range'].value_counts().sort_index()
        
        insights['ma_distribution'] = {label: count for label, count in zip(ma_dist.index, ma_dist.values)}
    
    return insights


def print_stock_insights(insights):
    """Print insights from the stock detail analysis in a readable format."""
    if 'error' in insights:
        print(f"Error: {insights['error']}")
        return
    
    print("\n" + "="*80)
    print("DETAILED STOCK INSIGHTS")
    print("="*80)
    
    # Print overall stats
    if 'stats' in insights:
        stats = insights['stats']
        print(f"\nANALYZED: {stats['total_stocks']} stocks")
        if 'above_ma' in stats:
            above_ma_pct = (stats['above_ma'] / stats['total_stocks']) * 100
            print(f"ABOVE MA: {stats['above_ma']} stocks ({above_ma_pct:.1f}%)")
        if 'new_highs_today' in stats and 'new_lows_today' in stats:
            print(f"NEW HIGHS TODAY: {stats['new_highs_today']} stocks")
            print(f"NEW LOWS TODAY: {stats['new_lows_today']} stocks")
    
    # Print top gainers
    if 'top_gainers' in insights and not insights['top_gainers'].empty:
        print("\nTOP GAINERS TODAY:")
        top_gainers = insights['top_gainers']
        for idx, row in top_gainers.iterrows():
            print(f"  {row['Symbol']}: +{row['Change%_T']:.2f}% (₹{row['Latest_Close']:.2f})")
    
    # Print top losers
    if 'top_losers' in insights and not insights['top_losers'].empty:
        print("\nTOP LOSERS TODAY:")
        top_losers = insights['top_losers']
        for idx, row in top_losers.iterrows():
            print(f"  {row['Symbol']}: {row['Change%_T']:.2f}% (₹{row['Latest_Close']:.2f})")
    
    # Print stocks with multiple new highs
    if 'multiple_new_highs' in insights and not insights['multiple_new_highs'].empty:
        print("\nSTOCKS WITH MULTIPLE NEW HIGHS:")
        multi_nh = insights['multiple_new_highs']
        for idx, row in multi_nh.iterrows():
            print(f"  {row['Symbol']}: {int(row['Period_New_Highs'])} days (₹{row['Latest_Close']:.2f})")
    
    # Print stocks with multiple new lows
    if 'multiple_new_lows' in insights and not insights['multiple_new_lows'].empty:
        print("\nSTOCKS WITH MULTIPLE NEW LOWS:")
        multi_nl = insights['multiple_new_lows']
        for idx, row in multi_nl.iterrows():
            print(f"  {row['Symbol']}: {int(row['Period_New_Lows'])} days (₹{row['Latest_Close']:.2f})")
    
    # Print stocks furthest above MA
    if 'most_above_ma' in insights and not insights['most_above_ma'].empty:
        print("\nSTOCKS FURTHEST ABOVE MA:")
        above_ma = insights['most_above_ma']
        for idx, row in above_ma.iterrows():
            print(f"  {row['Symbol']}: +{row['Pct_From_MA']:.2f}% (₹{row['Latest_Close']:.2f})")
    
    # Print stocks furthest below MA
    if 'most_below_ma' in insights and not insights['most_below_ma'].empty:
        print("\nSTOCKS FURTHEST BELOW MA:")
        below_ma = insights['most_below_ma']
        for idx, row in below_ma.iterrows():
            print(f"  {row['Symbol']}: {row['Pct_From_MA']:.2f}% (₹{row['Latest_Close']:.2f})")
    
    # Print MA distribution
    if 'ma_distribution' in insights:
        print("\nMA DISTRIBUTION:")
        dist = insights['ma_distribution']
        total = sum(dist.values())
        for label in sorted(dist.keys()):
            count = dist[label]
            percentage = (count / total) * 100
            print(f"  {label}: {count} stocks ({percentage:.1f}%)")
    
    print("\n" + "="*80)


def generate_market_pulse(daily_stats, valid_stocks_analyzed):
    """Generate a comprehensive market pulse analysis with correct signal weighting."""
    if valid_stocks_analyzed == 0:
        return "Insufficient data for analysis."
    
    # Calculate derived metrics
    ma_perc = [(c / valid_stocks_analyzed) * 100 for c in daily_stats['above_ma']]
    
    # Calculate A/D ratio with safe division
    ad_ratio = []
    for a, d in zip(daily_stats['advancers'], daily_stats['decliners']):
        if d > 0:
            ad_ratio.append(round(a / d, 2))
        elif a > 0:
            ad_ratio.append(float('inf'))
        else:
            ad_ratio.append(0.0)
    
    # Extract latest vs previous metrics
    latest_ma_perc = ma_perc[0]
    prev_ma_perc = ma_perc[1] if len(ma_perc) > 1 else 0
    latest_ad_ratio = ad_ratio[0]
    prev_ad_ratio = ad_ratio[1] if len(ad_ratio) > 1 else 0
    latest_nh = daily_stats['new_highs'][0]
    prev_nh = daily_stats['new_highs'][1] if len(daily_stats['new_highs']) > 1 else 0
    latest_nl = daily_stats['new_lows'][0]
    prev_nl = daily_stats['new_lows'][1] if len(daily_stats['new_lows']) > 1 else 0
    
    # Signal scoring system (positive = bullish, negative = bearish)
    signal_score = 0
    detailed_signals = []
    
    # Prepare analysis text
    analysis = []
    
    # Analyze MA Breadth trend
    ma_change = latest_ma_perc - prev_ma_perc
    if ma_change < -10:
        analysis.append(f"MA Breadth: Significantly deteriorating ({latest_ma_perc:.1f}% vs {prev_ma_perc:.1f}%)")
        signal_score -= 3
        detailed_signals.append(f"MA Breadth significantly down: {ma_change:.1f}% [Score: -3]")
    elif ma_change < -5:
        analysis.append(f"MA Breadth: Deteriorating ({latest_ma_perc:.1f}% vs {prev_ma_perc:.1f}%)")
        signal_score -= 2
        detailed_signals.append(f"MA Breadth down: {ma_change:.1f}% [Score: -2]")
    elif ma_change < -2:
        analysis.append(f"MA Breadth: Weakening ({latest_ma_perc:.1f}% vs {prev_ma_perc:.1f}%)")
        signal_score -= 1
        detailed_signals.append(f"MA Breadth slightly down: {ma_change:.1f}% [Score: -1]")
    elif ma_change > 10:
        analysis.append(f"MA Breadth: Strong improvement ({latest_ma_perc:.1f}% vs {prev_ma_perc:.1f}%)")
        signal_score += 3
        detailed_signals.append(f"MA Breadth significantly up: {ma_change:.1f}% [Score: +3]")
    elif ma_change > 5:
        analysis.append(f"MA Breadth: Improving ({latest_ma_perc:.1f}% vs {prev_ma_perc:.1f}%)")
        signal_score += 2
        detailed_signals.append(f"MA Breadth up: {ma_change:.1f}% [Score: +2]")
    elif ma_change > 2:
        analysis.append(f"MA Breadth: Slightly improving ({latest_ma_perc:.1f}% vs {prev_ma_perc:.1f}%)")
        signal_score += 1
        detailed_signals.append(f"MA Breadth slightly up: {ma_change:.1f}% [Score: +1]")
    else:
        analysis.append(f"MA Breadth: Stable ({latest_ma_perc:.1f}%)")
        detailed_signals.append(f"MA Breadth stable [Score: 0]")
    
    # Analyze absolute MA Breadth position
    if latest_ma_perc > 80:
        analysis.append(f"MA Breadth > 80%: Strongly overbought condition")
        signal_score -= 1  # Overbought is usually negative for future returns
        detailed_signals.append(f"MA Breadth overbought: {latest_ma_perc:.1f}% [Score: -1]")
    elif latest_ma_perc > 70:
        analysis.append(f"MA Breadth > 70%: Potential overbought condition")
    elif latest_ma_perc < 20:
        analysis.append(f"MA Breadth < 20%: Strongly oversold condition")
        signal_score += 1  # Oversold is usually positive for future returns
        detailed_signals.append(f"MA Breadth oversold: {latest_ma_perc:.1f}% [Score: +1]")
    elif latest_ma_perc < 30:
        analysis.append(f"MA Breadth < 30%: Potential oversold condition")
    
    # Analyze A/D Ratio trend - weight less than NH/NL and MA trends
    ad_change_pct = ((latest_ad_ratio - prev_ad_ratio) / max(0.01, prev_ad_ratio)) * 100
    if ad_change_pct < -50:
        analysis.append(f"A/D Ratio: Significant weakening ({latest_ad_ratio:.2f} vs {prev_ad_ratio:.2f})")
        signal_score -= 2
        detailed_signals.append(f"A/D Ratio significantly down: {ad_change_pct:.0f}% [Score: -2]")
    elif ad_change_pct < -20:
        analysis.append(f"A/D Ratio: Weakening ({latest_ad_ratio:.2f} vs {prev_ad_ratio:.2f})")
        signal_score -= 1
        detailed_signals.append(f"A/D Ratio down: {ad_change_pct:.0f}% [Score: -1]")
    elif ad_change_pct > 50:
        analysis.append(f"A/D Ratio: Strong improvement ({latest_ad_ratio:.2f} vs {prev_ad_ratio:.2f})")
        signal_score += 2
        detailed_signals.append(f"A/D Ratio significantly up: {ad_change_pct:.0f}% [Score: +2]")
    elif ad_change_pct > 20:
        analysis.append(f"A/D Ratio: Improving ({latest_ad_ratio:.2f} vs {prev_ad_ratio:.2f})")
        signal_score += 1
        detailed_signals.append(f"A/D Ratio up: {ad_change_pct:.0f}% [Score: +1]")
    else:
        analysis.append(f"A/D Ratio: Relatively stable ({latest_ad_ratio:.2f} vs {prev_ad_ratio:.2f})")
        detailed_signals.append(f"A/D Ratio stable [Score: 0]")
    
    # Analyze NH/NL with proper weighting for changes
    nhnl_analysis = []
    
    # New Lows analysis - weight changes in low numbers appropriately
    if latest_nl > 0 and prev_nl > 0:
        nl_change_pct = ((latest_nl - prev_nl) / prev_nl) * 100
    else:
        nl_change_pct = 100 if latest_nl > prev_nl else -100 if latest_nl < prev_nl else 0
    
    # Important: weight the significance of NL changes based on absolute values
    nl_significance = min(1.0, latest_nl / (0.02 * valid_stocks_analyzed))  # 2% threshold for full significance
    
    if nl_change_pct > 100 and latest_nl >= 5:
        nhnl_analysis.append(f"NL surged ({prev_nl}->{latest_nl}, +{nl_change_pct:.0f}%)")
        adjusted_score = -2 * nl_significance
        signal_score += adjusted_score
        detailed_signals.append(f"New Lows surged: {nl_change_pct:.0f}% [Score: {adjusted_score:.1f}]")
    elif nl_change_pct > 50 and latest_nl >= 3:
        nhnl_analysis.append(f"NL increased ({prev_nl}->{latest_nl}, +{nl_change_pct:.0f}%)")
        adjusted_score = -1 * nl_significance
        signal_score += adjusted_score
        detailed_signals.append(f"New Lows increased: {nl_change_pct:.0f}% [Score: {adjusted_score:.1f}]")
    elif nl_change_pct < -50 and prev_nl >= 5:
        nhnl_analysis.append(f"NL decreased significantly ({prev_nl}->{latest_nl})")
        adjusted_score = 2 * nl_significance
        signal_score += adjusted_score
        detailed_signals.append(f"New Lows decreased: {nl_change_pct:.0f}% [Score: {adjusted_score:.1f}]")
    elif nl_change_pct < 0 and prev_nl >= 3:
        nhnl_analysis.append(f"NL decreased ({prev_nl}->{latest_nl})")
        adjusted_score = 1 * nl_significance
        signal_score += adjusted_score
        detailed_signals.append(f"New Lows slightly decreased [Score: {adjusted_score:.1f}]")
    
    # New Highs analysis - a key breadth indicator, weight it appropriately
    if latest_nh > 0 and prev_nh > 0:
        nh_change_pct = ((latest_nh - prev_nh) / prev_nh) * 100
    else:
        nh_change_pct = 100 if latest_nh > prev_nh else -100 if latest_nh < prev_nh else 0
    
    # Weight NH changes based on market context
    nh_significance = min(1.0, latest_nh / (0.05 * valid_stocks_analyzed))  # 5% threshold for full significance
    
    if nh_change_pct > 100 and latest_nh >= 10:
        nhnl_analysis.append(f"NH surged ({prev_nh}->{latest_nh}, +{nh_change_pct:.0f}%)")
        adjusted_score = 3 * nh_significance
        signal_score += adjusted_score
        detailed_signals.append(f"New Highs surged: {nh_change_pct:.0f}% [Score: +{adjusted_score:.1f}]")
    elif nh_change_pct > 50 and latest_nh >= 5:
        nhnl_analysis.append(f"NH increased ({prev_nh}->{latest_nh}, +{nh_change_pct:.0f}%)")
        adjusted_score = 2 * nh_significance
        signal_score += adjusted_score
        detailed_signals.append(f"New Highs increased: {nh_change_pct:.0f}% [Score: +{adjusted_score:.1f}]")
    elif nh_change_pct < -50 and prev_nh >= 10:
        nhnl_analysis.append(f"NH decreased significantly ({prev_nh}->{latest_nh})")
        adjusted_score = -3 * nh_significance
        signal_score += adjusted_score
        detailed_signals.append(f"New Highs decreased: {nh_change_pct:.0f}% [Score: {adjusted_score:.1f}]")
    elif nh_change_pct < -20 and prev_nh >= 5:
        nhnl_analysis.append(f"NH decreased ({prev_nh}->{latest_nh})")
        adjusted_score = -2 * nh_significance
        signal_score += adjusted_score
        detailed_signals.append(f"New Highs decreased: {nh_change_pct:.0f}% [Score: {adjusted_score:.1f}]")
    
    if nhnl_analysis:
        analysis.append("NH/NL: " + "; ".join(nhnl_analysis))
    else:
        analysis.append(f"NH/NL: Stable (NH:{latest_nh}, NL:{latest_nl})")
        detailed_signals.append(f"NH/NL stable [Score: 0]")
    
    # Calculate NH-NL spread and its change
    nhnl_spread = latest_nh - latest_nl
    prev_spread = prev_nh - prev_nl
    spread_change = nhnl_spread - prev_spread
    spread_change_pct = 0
    
    if abs(prev_spread) > 0:
        spread_change_pct = (spread_change / abs(prev_spread)) * 100
    
    # Weight the spread change by its significance
    spread_significance = min(1.0, abs(nhnl_spread) / (0.05 * valid_stocks_analyzed))
    
    if spread_change > 0 and spread_change_pct > 20:
        analysis.append(f"NH-NL Spread: Improving ({prev_spread}->{nhnl_spread}, +{spread_change})")
        adjusted_score = 2 * spread_significance
        signal_score += adjusted_score
        detailed_signals.append(f"NH-NL Spread improved: +{spread_change} [Score: +{adjusted_score:.1f}]")
    elif spread_change < 0 and spread_change_pct < -20:
        analysis.append(f"NH-NL Spread: Deteriorating ({prev_spread}->{nhnl_spread}, {spread_change})")
        adjusted_score = -2 * spread_significance
        signal_score += adjusted_score
        detailed_signals.append(f"NH-NL Spread deteriorated: {spread_change} [Score: {adjusted_score:.1f}]")
    else:
        analysis.append(f"NH-NL Spread: {prev_spread}->{nhnl_spread} ({spread_change:+})")
    
    # Overall market pulse determination based on weighted score
    market_pulse = ""
    if signal_score >= 4:
        market_pulse = "STRONG BULLISH SIGNAL: Multiple indicators show significant improvement."
    elif signal_score >= 2:
        market_pulse = "BULLISH: Breadth indicators suggest improvement."
    elif signal_score <= -4:
        market_pulse = "STRONG BEARISH SIGNAL: Multiple indicators show significant deterioration."
    elif signal_score <= -2:
        market_pulse = "BEARISH: Breadth indicators suggest deterioration."
    elif signal_score > 0:
        market_pulse = "MODERATELY BULLISH: Slight improvement in breadth indicators."
    elif signal_score < 0:
        market_pulse = "MODERATELY BEARISH: Slight deterioration in breadth indicators."
    else:
        market_pulse = "NEUTRAL: Breadth signals are mixed or stable."
    
    # Add score to market pulse
    market_pulse += f" [Signal Score: {signal_score:.1f}]"
    
    # Additional market context analysis based on absolute levels
    additional_insight = ""
    
    # Analyze absolute NH-NL levels
    nh_percentage = (latest_nh / valid_stocks_analyzed) * 100
    nl_percentage = (latest_nl / valid_stocks_analyzed) * 100
    
    if nh_percentage > 15 and nl_percentage < 1:
        additional_insight += "Strong and broad market participation with numerous new highs and minimal new lows. "
    elif nh_percentage > 10 and nl_percentage < 2:
        additional_insight += "Healthy market breadth with solid new high participation. "
    elif nh_percentage < 2 and nl_percentage > 5:
        additional_insight += "Deteriorating market breadth with few new highs and expanding new lows. "
    elif latest_nh < latest_nl and latest_nl > 10:
        additional_insight += "Concerning breadth with new lows exceeding new highs. "
    
    # Contradiction detection
    if signal_score > 2 and latest_ma_perc < 40:
        additional_insight += "Note: Positive breadth signals despite low percentage above MA50 could indicate early stage recovery. "
    elif signal_score < -2 and latest_ma_perc > 60:
        additional_insight += "Warning: Negative breadth signals despite high percentage above MA50 could indicate deterioration beneath the surface. "
    
    # Combine all analysis components
    full_analysis = {
        "indicators": analysis,
        "market_pulse": market_pulse,
        "additional_insight": additional_insight,
        "detailed_signals": detailed_signals,
        "signal_score": signal_score
    }
    
    return full_analysis


# --- Main Execution ---
def main():
    start_time = time.time()
    logging.info(f"--- Starting Market Breadth Tactical Scanner ({DAYS_TO_COMPARE}-Day Trend) ---")
    
    # Setup cache directories
    ensure_cache_dir()
    initialize_db()
    
    # Initialize rate limiter
    rate_limiter = RateLimiter(API_CALLS_PER_MINUTE, API_CALLS_BUFFER)
    
    # 1. Initialize Kite Connect
    kite = initialize_kite(API_KEY, ACCESS_TOKEN)
    if not kite:
        logging.critical("Failed to initialize Kite Connect. Exiting.")
        return
    
    # 2. Get instrument tokens (cached)
    instrument_tokens = get_instrument_tokens(kite)
    
    # 3. Read Stock List
    symbols = read_stock_list(STOCK_LIST_CSV, CSV_SYMBOL_COLUMN)
    if not symbols:
        logging.critical("Failed to read stock list. Exiting.")
        return
    
    logging.info(f"Read {len(symbols)} symbols from {STOCK_LIST_CSV}")
    total_stocks = len(symbols)
    # Initialize daily aggregate counts
    daily_stats = {
        'dates': [""] * DAYS_TO_COMPARE,
        'above_ma': [0] * DAYS_TO_COMPARE,
        'advancers': [0] * DAYS_TO_COMPARE,
        'decliners': [0] * DAYS_TO_COMPARE,
        'new_highs': [0] * DAYS_TO_COMPARE,
        'new_lows': [0] * DAYS_TO_COMPARE,
    }
    
    valid_stocks_analyzed = 0
    failed_symbols = []
    latest_dates_captured = False
    
    # Dictionary to store historical data for detailed stock analysis
    historical_data_dict = {}
    
    # Process in batches for better progress indication
    logging.info(f"Analyzing {total_stocks} stocks in batches of {API_BATCH_SIZE}...")
    
    # 4. Process stocks in batches
    for batch_start in range(0, total_stocks, API_BATCH_SIZE):
        batch_end = min(batch_start + API_BATCH_SIZE, total_stocks)
        batch_symbols = symbols[batch_start:batch_end]
        
        logging.info(f"Processing batch {batch_start//API_BATCH_SIZE + 1}/{(total_stocks-1)//API_BATCH_SIZE + 1} ({batch_end}/{total_stocks} stocks): {batch_symbols}")
        
        for symbol in batch_symbols:
            # Fetch historical data (using cache when available)
            hist_data = get_historical_data(kite, symbol, HISTORY_DAYS, rate_limiter, instrument_tokens)
            
            # Store data for detailed analysis even if we skip it for breadth
            if hist_data is not None:
                historical_data_dict[symbol] = hist_data
            
            if hist_data is None:
                failed_symbols.append(f"{symbol} (Data Error)")
                continue
            
            # Calculate indicators
            indicator_results = calculate_indicators_over_time(hist_data, MA_BREADTH, NHNL_LOOKBACK, DAYS_TO_COMPARE)
            
            if indicator_results is None:
                failed_symbols.append(f"{symbol} (Calc Error)")
                continue
            
            # Process successful results
            valid_stocks_analyzed += 1
            
            # Capture dates from first successful stock
            if not latest_dates_captured:
                daily_stats['dates'] = [d.strftime('%Y-%m-%d') for d in reversed(indicator_results['date'])]
                latest_dates_captured = True
            
            # Update aggregate counts
            for i in range(DAYS_TO_COMPARE):
                day_idx = DAYS_TO_COMPARE - 1 - i  # Map oldest to newest
                
                if indicator_results['above_ma'][i]: daily_stats['above_ma'][day_idx] += 1
                if indicator_results['advance'][i]: daily_stats['advancers'][day_idx] += 1
                if indicator_results['decline'][i]: daily_stats['decliners'][day_idx] += 1
                if indicator_results['new_high'][i]: daily_stats['new_highs'][day_idx] += 1
                if indicator_results['new_low'][i]: daily_stats['new_lows'][day_idx] += 1
    
    # 5. Generate Market Breadth Results & Analysis
    execution_time = time.time() - start_time
    logging.info(f"Analysis completed in {execution_time:.2f} seconds")
    
    if valid_stocks_analyzed > 0:
        print("\n" + "="*80)
        print(f"MARKET BREADTH TACTICAL REPORT ({datetime.now().strftime('%Y-%m-%d %H:%M')})")
        print("="*80)
        print(f"Universe: {total_stocks} symbols | Successfully Analyzed: {valid_stocks_analyzed}")
        
        date_range_str = "N/A"
        if latest_dates_captured and len(daily_stats['dates']) == DAYS_TO_COMPARE:
            date_range_str = f"{daily_stats['dates'][-1]} to {daily_stats['dates'][0]}"
        print(f"Date Range: {date_range_str}")
        print("-" * 80)
        
        # Display data table
        header1 = f"{'Metric':<20} |"
        header2 = f"{'':<20} |"
        
        for i in range(DAYS_TO_COMPARE - 1, -1, -1):
            day_label = f"T-{i}" if i > 0 else "T (Latest)"
            header1 += f"{day_label:^14} |"
            date_str = daily_stats['dates'][i] if latest_dates_captured else " "
            header2 += f"{date_str:^14} |"
        
        print(header1)
        print(header2)
        print("-" * 80)
        
        # Format rows
        def format_row(label, data_list, formatting=None, percentage=False):
            row_str = f"{label:<20} |"
            
            for i in range(DAYS_TO_COMPARE - 1, -1, -1):
                value = data_list[i]
                
                if percentage:
                    row_str += f"{value:.1f}%".center(14) + " |"
                elif formatting:
                    row_str += f"{formatting(value)}".center(14) + " |"
                else:
                    row_str += f"{value}".center(14) + " |"
                    
            return row_str
        
        # Calculate percentages for display
        ma_perc = [(c / valid_stocks_analyzed) * 100 for c in daily_stats['above_ma']]
        
        # Display metrics
        print(format_row(f'% Above MA{MA_BREADTH}', ma_perc, percentage=True))
        print(format_row('Advancers', daily_stats['advancers']))
        print(format_row('Decliners', daily_stats['decliners']))
        
        # A/D Ratio
        ad_ratio = []
        for a, d in zip(daily_stats['advancers'], daily_stats['decliners']):
            if d > 0:
                ad_ratio.append(round(a / d, 2))
            elif a > 0:
                ad_ratio.append(float('inf'))
            else:
                ad_ratio.append(0.0)
                
        print(format_row('A/D Ratio', ad_ratio, lambda x: "∞" if x == float('inf') else f"{x:.2f}"))
        
        # New Highs/Lows
        print(format_row(f'New Highs({NHNL_LOOKBACK}d)', daily_stats['new_highs']))
        print(format_row(f'New Lows({NHNL_LOOKBACK}d)', daily_stats['new_lows']))
        
        # NH-NL Spread
        nh_nl_spread = [h - l for h, l in zip(daily_stats['new_highs'], daily_stats['new_lows'])]
        print(format_row('NH-NL Spread', nh_nl_spread))
        print("-" * 80)
        
        # Generate market pulse analysis
        market_analysis = generate_market_pulse(daily_stats, valid_stocks_analyzed)
        
        # Display summary analysis
        print("\nMARKET BREADTH ANALYSIS")
        print("-" * 50)
        
        for indicator in market_analysis["indicators"]:
            print(f"• {indicator}")
            
        print("\nMARKET PULSE:")
        print(f">> {market_analysis['market_pulse']}")
        
        if market_analysis["additional_insight"]:
            print("\nADDITIONAL CONTEXT:")
            print(market_analysis["additional_insight"])
        
        # 6. Generate and analyze detailed stock data
        if historical_data_dict:
            detailed_df = generate_stock_detail_csv(historical_data_dict, MA_BREADTH, NHNL_LOOKBACK, DAYS_TO_COMPARE)
            
            if detailed_df is not None:
                insights = analyze_stock_detail(detailed_df)
                print_stock_insights(insights)
        
        # Cache statistics
        cache_stats = {}
        try:
            conn = sqlite3.connect(HISTORY_CACHE_DB)
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM historical_data")
            cache_stats["total_records"] = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(DISTINCT symbol) FROM historical_data")
            cache_stats["unique_symbols"] = cursor.fetchone()[0]
            
            cursor.execute("SELECT MIN(last_updated), MAX(last_updated) FROM historical_data")
            min_date, max_date = cursor.fetchone()
            cache_stats["oldest_record"] = min_date
            cache_stats["newest_record"] = max_date
            conn.close()
        except Exception as e:
            logging.error(f"Error getting cache stats: {e}")
        
        print("\nPERFORMANCE METRICS")
        print("-" * 50)
        print(f"Execution Time: {execution_time:.2f} seconds")
        print(f"API Calls Made: {rate_limiter.calls_made}")
        
        if cache_stats:
            print(f"Cache Size: {cache_stats.get('total_records', 'N/A')} records for {cache_stats.get('unique_symbols', 'N/A')} symbols")
            
        if failed_symbols:
            print(f"\nSkipped/Failed {len(failed_symbols)} symbols (showing first 10):")
            print(", ".join(failed_symbols[:10]) + ('...' if len(failed_symbols) > 10 else ''))
    else:
        print("\n--- Market Breadth Analysis Failed ---")
        print("Could not analyze any stocks successfully.")
        print("Check logs for errors (API connection, data fetching, etc.)")


if __name__ == "__main__":
    main()

