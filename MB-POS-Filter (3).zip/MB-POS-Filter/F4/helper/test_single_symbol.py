"""
Quick test script to debug metric extraction for a single symbol.
Run this to see what metrics are available on screener.in
"""

import requests
from bs4 import BeautifulSoup
import sys
import io

# Fix Windows console encoding
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
}

def test_symbol(symbol):
    """Test extraction for a single symbol"""
    url = f"https://www.screener.in/company/{symbol}/"
    print(f"\n{'='*70}")
    print(f"Testing: {symbol}")
    print(f"URL: {url}")
    print(f"{'='*70}\n")
    
    try:
        response = requests.get(url, headers=HEADERS, timeout=15)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Print top-ratios section
        print("=" * 70)
        print("TOP RATIOS SECTION (#top-ratios)")
        print("=" * 70)
        found_ratios = False
        for row in soup.select("ul#top-ratios li"):
            key_elem = row.select_one("span.name")
            val_elem = row.select_one("span.number, span.value")
            if key_elem and val_elem:
                print(f"  {key_elem.text.strip():30s} = {val_elem.text.strip()}")
                found_ratios = True
        
        if not found_ratios:
            print("  [!] No data found in #top-ratios section")
        
        # Print all sections
        print("\n" + "=" * 70)
        print("ALL SECTIONS ON PAGE")
        print("=" * 70)
        sections = soup.find_all('section')
        for section in sections:
            section_id = section.get('id', 'No ID')
            section_class = section.get('class', 'No Class')
            print(f"  Section ID: {section_id}, Class: {section_class}")
        
        # Check for analysis/compounded growth section
        print("\n" + "=" * 70)
        print("ANALYSIS SECTION (Compounded Growth)")
        print("=" * 70)
        compound_section = soup.find('section', {'id': 'analysis'})
        if compound_section:
            print("[OK] Found #analysis section")
            tables = compound_section.find_all('table')
            print(f"  Tables found: {len(tables)}")
            for i, table in enumerate(tables):
                print(f"\n  TABLE {i+1}:")
                rows = table.find_all('tr')
                for row in rows[:5]:  # Show first 5 rows
                    cells = row.find_all(['td', 'th'])
                    row_data = [cell.get_text(strip=True) for cell in cells]
                    print(f"    {' | '.join(row_data)}")
        else:
            print("  [!] No #analysis section found")
        
        # Check RATIOS section (important!)
        print("\n" + "=" * 70)
        print("RATIOS SECTION")
        print("=" * 70)
        ratios_section = soup.find('section', {'id': 'ratios'})
        if ratios_section:
            print("[OK] Found #ratios section")
            tables = ratios_section.find_all('table')
            print(f"  Tables found: {len(tables)}")
            for i, table in enumerate(tables):
                print(f"\n  TABLE {i+1}:")
                rows = table.find_all('tr')
                for row in rows[:15]:  # Show first 15 rows
                    cells = row.find_all(['td', 'th'])
                    if cells:
                        row_data = [cell.get_text(strip=True) for cell in cells]
                        print(f"    {' | '.join(row_data[:5])}")  # Show first 5 columns
        else:
            print("  [!] No #ratios section found")
        
        # Check cash flow section
        print("\n" + "=" * 70)
        print("CASH FLOW SECTION")
        print("=" * 70)
        cashflow_section = soup.find('section', {'id': 'cash-flow'})
        if cashflow_section:
            print("[OK] Found #cash-flow section")
            table = cashflow_section.find('table')
            if table:
                rows = table.find_all('tr')
                print(f"  Rows found: {len(rows)}")
                for row in rows[:15]:
                    cells = row.find_all(['td', 'th'])
                    if cells:
                        label = cells[0].get_text(strip=True)
                        row_data = [cell.get_text(strip=True) for cell in cells[:4]]
                        print(f"    {' | '.join(row_data)}")
        else:
            print("  [!] No #cash-flow section found")
        
        # Check quarters section for OPM
        print("\n" + "=" * 70)
        print("QUARTERS SECTION (for Operating Margin)")
        print("=" * 70)
        quarters_section = soup.find('section', {'id': 'quarters'})
        if quarters_section:
            print("[OK] Found #quarters section")
            table = quarters_section.find('table')
            if table:
                rows = table.find_all('tr')
                for row in rows[:10]:
                    cells = row.find_all(['td', 'th'])
                    if cells:
                        label = cells[0].get_text(strip=True)
                        if 'opm' in label.lower() or 'operating' in label.lower():
                            row_data = [cell.get_text(strip=True) for cell in cells[:5]]
                            print(f"  >>> {' | '.join(row_data)}")
        else:
            print("  [!] No #quarters section found")
        
        # Save HTML for inspection
        with open(f"debug_{symbol}.html", "w", encoding='utf-8') as f:
            f.write(str(soup.prettify()))
        print(f"\n[OK] HTML saved to debug_{symbol}.html for inspection")
        
    except Exception as e:
        print(f"[ERROR] {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    symbol = sys.argv[1] if len(sys.argv) > 1 else "DCBBANK"
    test_symbol(symbol)

