"""
Unified Comprehensive Stock Fundamental Scraper with AI-Powered Scoring
========================================================================

Best-in-class web scraper for screener.in that extracts & scores fundamental data:
1. Sector hierarchy (Level 1-4 breadcrumb trail)
2. Market capitalization (in Crores)
3. Shareholding Pattern (Promoter, FII, DII, Public)
4. Free Float Calculation
5. Financial Ratios (P/E, P/B, ROE, ROCE, Debt/Equity)
6. Growth Metrics (EPS Growth, Revenue Growth)
7. Operational Metrics (Operating Margin, Free Cash Flow, Interest Coverage)
8. Dividend Metrics (Dividend Yield)
9. INTELLIGENT SCORING SYSTEM (0-100 scale)

Combines the best features from multiple scrapers into a single, robust solution.

Data Points Extracted (30+ metrics per stock):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 Basic Info:
  - Sector Classification (4 levels)
  - Market Cap & Free Float Market Cap

👥 Shareholding:
  - Promoter, FII, DII, Public, Free Float %

💰 Valuation:
  - P/E Ratio, P/B Ratio, Price to Sales

📈 Profitability:
  - ROE, ROCE, Operating Margin

🚀 Growth:
  - 3-Year EPS Growth, 3-Year Revenue Growth

💵 Financial Health:
  - Debt to Equity, Free Cash Flow, Interest Coverage

💎 Income:
  - Dividend Yield

🏆 SCORING SYSTEM (12 weighted metrics):
  Each metric scored 0-10, then weighted by importance:
  
  PRIMARY METRICS (90% of total weight):
  ├─ EPS Growth (>10% YoY)           → 20% weight
  ├─ Revenue Growth (>10% YoY)       → 15% weight
  ├─ ROE (>15%)                      → 15% weight
  ├─ Debt/Equity (<1)                → 10% weight
  ├─ ROCE (>10%)                     → 10% weight
  ├─ Free Cash Flow (Positive)       → 10% weight
  ├─ P/E Ratio (10-20 ideal)         → 10% weight
  ├─ Operating Margin (>15%)         → 5% weight
  └─ P/B Ratio (<1 ideal)            → 5% weight
  
  SUPPLEMENTARY METRICS (6% of total weight):
  ├─ Dividend Yield (1.5-3.5%)       → 2% weight
  ├─ Price to Sales (<1)             → 2% weight
  └─ Interest Coverage (>5)          → 2% weight
  
  TOTAL SCORE: Weighted sum normalized to 0-100 scale
  Higher score = Stronger fundamentals

Features:
- Rate-limited requests (1-2s random delay)
- Robust error handling with detailed logging
- Timestamped outputs
- Progress tracking
- Case-insensitive symbol detection
- Duplicate symbol handling
- Clean number parsing
- Comprehensive analytics and insights
- Intelligent fundamental scoring
- Top performers identification
- Best opportunities (High Score + Low Free Float)

Usage:
    python sector-marketcap-scraper.py

Output:
    29oct2025_sector_marketcap_freefloat_YYYYMMDD_HHMMSS.csv
    (Includes all metrics + individual scores + total score)

Author: Market Analysis Framework
Version: 4.0.0 - Intelligent Scoring Edition
"""

import pandas as pd
import requests
from bs4 import BeautifulSoup
import time
import random
from datetime import datetime
import logging
import os
from typing import Dict, List, Optional

# ============================================================================
# CONFIGURATION
# ============================================================================

# Input/Output Configuration
INPUT_CSV = "data/MCAPgreat300-22oct.csv"  # Input CSV with Symbol column
OUTPUT_DIR = "./output"  # Output directory

# Scraping Configuration
BASE_URL = "https://www.screener.in/company/{}/"
DELAY_RANGE = (1, 2)  # Random delay range in seconds
TIMEOUT = 15  # Request timeout in seconds
DEBUG_MODE = False  # Set to True to save HTML and see debug info

# Headers for requests
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Accept-Encoding': 'gzip, deflate',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}

# ============================================================================
# LOGGING SETUP
# ============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("sector_marketcap_scraper.log", encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def clean_market_cap(text: str) -> float:
    """
    Clean and convert market cap text to float (in Crores).
    
    Args:
        text: Market cap text (e.g., "₹ 1,23,456 Cr.")
    
    Returns:
        float: Market cap in Crores
    """
    if not text:
        return 0.0
    
    # Remove currency symbols, commas, and 'Cr.'
    cleaned = text.replace("₹", "").replace(",", "").replace("Cr.", "").replace("Cr", "").strip()
    
    try:
        return float(cleaned)
    except ValueError:
        logger.warning(f"Could not parse market cap: {text}")
        return 0.0

def clean_percentage(text: str) -> float:
    """
    Clean and convert percentage text to float.
    
    Args:
        text: Percentage text (e.g., "65.23%", "65.23 %")
    
    Returns:
        float: Percentage value
    """
    if not text:
        return 0.0
    
    # Remove % sign and extra spaces
    cleaned = text.replace("%", "").replace(",", "").strip()
    
    try:
        return float(cleaned)
    except ValueError:
        logger.warning(f"Could not parse percentage: {text}")
        return 0.0

def clean_number(text: str) -> float:
    """
    Clean and convert general numeric text to float.
    Handles various formats like "1,234.56", "12.5%", etc.
    
    Args:
        text: Number text
    
    Returns:
        float: Numeric value
    """
    if not text:
        return 0.0
    
    # Remove common symbols and spaces
    cleaned = text.replace(",", "").replace("%", "").replace("₹", "").strip()
    
    # Handle negative values in parentheses
    if cleaned.startswith("(") and cleaned.endswith(")"):
        cleaned = "-" + cleaned[1:-1]
    
    try:
        return float(cleaned)
    except ValueError:
        logger.warning(f"Could not parse number: {text}")
        return 0.0

# ============================================================================
# SCORING FUNCTIONS
# ============================================================================

def calculate_metric_score(metric_name: str, value: float) -> float:
    """
    Calculate score (0-10) for a given metric based on ideal ranges.
    
    Args:
        metric_name: Name of the metric
        value: Value of the metric
    
    Returns:
        float: Score between 0 and 10
    """
    if value == 0.0:
        return 0.0
    
    score = 0.0
    
    # EPS Growth: > 10% is ideal, 0-30% range mapped to 0-10
    if metric_name == 'EPS_Growth_3Yr_%':
        if value >= 30:
            score = 10.0
        elif value >= 10:
            score = 5.0 + ((value - 10) / 20) * 5  # 10-30% maps to 5-10
        elif value > 0:
            score = (value / 10) * 5  # 0-10% maps to 0-5
        else:
            score = 0.0  # Negative growth
    
    # Revenue Growth: > 10% is ideal, 0-30% range mapped to 0-10
    elif metric_name == 'Revenue_Growth_3Yr_%':
        if value >= 30:
            score = 10.0
        elif value >= 10:
            score = 5.0 + ((value - 10) / 20) * 5
        elif value > 0:
            score = (value / 10) * 5
        else:
            score = 0.0
    
    # Debt to Equity: < 1 is ideal, 0 is best
    elif metric_name == 'Debt_to_Equity':
        if value == 0:
            score = 10.0
        elif value <= 0.5:
            score = 9.0 - (value / 0.5) * 1  # 0-0.5 maps to 10-9
        elif value <= 1.0:
            score = 7.0 - ((value - 0.5) / 0.5) * 2  # 0.5-1.0 maps to 9-7
        elif value <= 2.0:
            score = 3.0 - ((value - 1.0) / 1.0) * 4  # 1-2 maps to 7-3
        else:
            score = max(0.0, 3.0 - (value - 2.0) * 0.5)  # >2 decreases further
    
    # ROE: > 15% is ideal
    elif metric_name == 'ROE_%':
        if value >= 25:
            score = 10.0
        elif value >= 15:
            score = 7.0 + ((value - 15) / 10) * 3  # 15-25% maps to 7-10
        elif value >= 10:
            score = 4.0 + ((value - 10) / 5) * 3  # 10-15% maps to 4-7
        elif value > 0:
            score = (value / 10) * 4  # 0-10% maps to 0-4
        else:
            score = 0.0
    
    # ROCE: > 10% is ideal
    elif metric_name == 'ROCE_%':
        if value >= 20:
            score = 10.0
        elif value >= 10:
            score = 7.0 + ((value - 10) / 10) * 3  # 10-20% maps to 7-10
        elif value >= 5:
            score = 4.0 + ((value - 5) / 5) * 3  # 5-10% maps to 4-7
        elif value > 0:
            score = (value / 5) * 4  # 0-5% maps to 0-4
        else:
            score = 0.0
    
    # Operating Margin: > 15% is ideal
    elif metric_name == 'Operating_Margin_%':
        if value >= 25:
            score = 10.0
        elif value >= 15:
            score = 7.0 + ((value - 15) / 10) * 3  # 15-25% maps to 7-10
        elif value >= 10:
            score = 5.0 + ((value - 10) / 5) * 2  # 10-15% maps to 5-7
        elif value > 0:
            score = (value / 10) * 5  # 0-10% maps to 0-5
        else:
            score = 0.0
    
    # P/E Ratio: 10-20 is ideal range
    elif metric_name == 'PE_Ratio':
        if 10 <= value <= 20:
            score = 10.0
        elif 5 <= value < 10:
            score = 5.0 + ((value - 5) / 5) * 5  # 5-10 maps to 5-10
        elif 20 < value <= 30:
            score = 7.0 - ((value - 20) / 10) * 3  # 20-30 maps to 10-7
        elif value < 5:
            score = max(0.0, value)  # Very low P/E might be risky
        elif value > 30:
            score = max(0.0, 7.0 - (value - 30) * 0.2)  # >30 decreases score
        else:
            score = 5.0
    
    # P/B Ratio: Close to 1 or < 1 is ideal
    elif metric_name == 'PB_Ratio':
        if value <= 1:
            score = 10.0
        elif value <= 2:
            score = 8.0 - (value - 1) * 2  # 1-2 maps to 10-8
        elif value <= 3:
            score = 5.0 - (value - 2) * 3  # 2-3 maps to 8-5
        else:
            score = max(0.0, 5.0 - (value - 3) * 1)  # >3 decreases further
    
    # Free Cash Flow: Positive and growing (we'll score positive values)
    elif metric_name == 'Free_Cash_Flow_Crores':
        if value >= 1000:
            score = 10.0
        elif value >= 500:
            score = 8.0 + ((value - 500) / 500) * 2
        elif value >= 100:
            score = 5.0 + ((value - 100) / 400) * 3
        elif value > 0:
            score = (value / 100) * 5
        else:
            score = 0.0
    
    # Dividend Yield: 1-4% is good range
    elif metric_name == 'Dividend_Yield_%':
        if 1.5 <= value <= 3.5:
            score = 10.0
        elif 1.0 <= value < 1.5:
            score = 7.0 + ((value - 1.0) / 0.5) * 3
        elif 3.5 < value <= 5:
            score = 8.0 - ((value - 3.5) / 1.5) * 3
        elif 0 < value < 1.0:
            score = value * 7  # 0-1% maps to 0-7
        elif value > 5:
            score = max(0.0, 8.0 - (value - 5) * 1)  # >5% might indicate issues
        else:
            score = 5.0  # No dividend is neutral for growth stocks
    
    # Price to Sales: < 1 is ideal
    elif metric_name == 'Price_to_Sales':
        if value <= 1:
            score = 10.0
        elif value <= 2:
            score = 8.0 - (value - 1) * 2  # 1-2 maps to 10-8
        elif value <= 3:
            score = 5.0 - (value - 2) * 3  # 2-3 maps to 8-5
        else:
            score = max(0.0, 5.0 - (value - 3) * 1)
    
    # Interest Coverage: > 5 is ideal
    elif metric_name == 'Interest_Coverage':
        if value >= 10:
            score = 10.0
        elif value >= 5:
            score = 7.0 + ((value - 5) / 5) * 3  # 5-10 maps to 7-10
        elif value >= 2:
            score = 4.0 + ((value - 2) / 3) * 3  # 2-5 maps to 4-7
        elif value > 0:
            score = (value / 2) * 4  # 0-2 maps to 0-4
        else:
            score = 0.0
    
    return round(score, 2)

def calculate_fundamental_score(metrics: Dict[str, float]) -> Dict[str, float]:
    """
    Calculate individual scores and total fundamental score using percentage-based weights.
    
    Args:
        metrics: Dictionary of financial metrics
    
    Returns:
        dict: Individual scores and total score (0-100 scale)
    
    Weighting Strategy:
        - EPS Growth: 20%
        - Revenue Growth: 15%
        - ROE: 15%
        - Debt to Equity: 10%
        - ROCE: 10%
        - Free Cash Flow: 10%
        - P/E Ratio: 10%
        - Operating Margin: 5%
        - P/B Ratio: 5%
        - Additional metrics (Dividend, P/S, Interest Coverage): 6% distributed
        Total: 106% (normalized to 100%)
    """
    scores = {}
    
    # Percentage-based weights (total = 106%, will be normalized)
    metric_weights = {
        'EPS_Growth_3Yr_%': 20.0,        # Growth metrics
        'Revenue_Growth_3Yr_%': 15.0,
        'ROE_%': 15.0,                    # Profitability (most important)
        'ROCE_%': 10.0,
        'Free_Cash_Flow_Crores': 10.0,   # Cash generation
        'Debt_to_Equity': 10.0,           # Financial health
        'PE_Ratio': 10.0,                 # Valuation
        'Operating_Margin_%': 5.0,
        'PB_Ratio': 5.0,
        'Dividend_Yield_%': 2.0,          # Income (lower priority)
        'Price_to_Sales': 2.0,            # Alternative valuation
        'Interest_Coverage': 2.0          # Debt servicing ability
    }
    
    total_score = 0.0
    total_weight = 0.0
    scored_metrics = 0
    
    for metric_name, weight in metric_weights.items():
        value = metrics.get(metric_name, 0.0)
        score = calculate_metric_score(metric_name, value)
        scores[f'{metric_name}_Score'] = score
        
        # Only add to total if metric has a valid value
        if value != 0.0:
            # Score is 0-10, multiply by weight (percentage)
            weighted_score = score * weight
            total_score += weighted_score
            total_weight += weight
            scored_metrics += 1
    
    # Calculate final score (0-100 scale)
    if total_weight > 0:
        # Total possible = 10 (max score) * total_weight
        # Actual score = total_score / (10 * total_weight) * 100
        max_possible = 10.0 * total_weight
        scores['Total_Score'] = round((total_score / max_possible) * 100, 2)
        scores['Metrics_Scored'] = scored_metrics
        scores['Weight_Coverage_%'] = round((total_weight / sum(metric_weights.values())) * 100, 2)
    else:
        scores['Total_Score'] = 0.0
        scores['Metrics_Scored'] = 0
        scores['Weight_Coverage_%'] = 0.0
    
    return scores

# ============================================================================
# SCRAPER CLASS
# ============================================================================

class UnifiedScreenerScraper:
    """
    Unified scraper for sector hierarchy and market cap extraction.
    """
    
    def __init__(self, delay_range: tuple = DELAY_RANGE, timeout: int = TIMEOUT):
        """
        Initialize the scraper.
        
        Args:
            delay_range: Tuple of (min, max) delay in seconds
            timeout: Request timeout in seconds
        """
        self.delay_range = delay_range
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update(HEADERS)
        self._debug_printed = False
    
    def extract_sector_hierarchy(self, soup: BeautifulSoup, symbol: str) -> List[str]:
        """
        Extract sector breadcrumb hierarchy from peer comparison section.
        
        Args:
            soup: BeautifulSoup object of the page
            symbol: Stock symbol (for logging)
        
        Returns:
            list: Sector levels (e.g., ['Financials', 'Banks', 'Private Banks'])
        """
        breadcrumb_levels = []
        
        # Method: Peer Comparison breadcrumb trail
        peer_comparison_div = soup.find('div', string=lambda text: text and 'peer comparison' in text.lower())
        
        if not peer_comparison_div:
            peer_h2 = soup.find('h2', string=lambda text: text and 'peer comparison' in text.lower())
            if peer_h2:
                peer_comparison_div = peer_h2.parent
        
        if peer_comparison_div:
            sub_p = peer_comparison_div.find('p', class_='sub')
            if sub_p:
                breadcrumb_links = sub_p.find_all('a')
                for link in breadcrumb_links:
                    text = link.get_text(strip=True)
                    if text:
                        breadcrumb_levels.append(text)
                
                if breadcrumb_levels:
                    logger.info(f"  Found {len(breadcrumb_levels)} sector levels for {symbol}")
                    return breadcrumb_levels
        
        logger.warning(f"  No sector breadcrumb found for {symbol}")
        return []
    
    def extract_market_cap(self, soup: BeautifulSoup, symbol: str) -> Optional[float]:
        """
        Extract market capitalization from top ratios section.
        
        Args:
            soup: BeautifulSoup object of the page
            symbol: Stock symbol (for logging)
        
        Returns:
            float: Market cap in Crores, or None if not found
        """
        try:
            # Look for Market Cap in top ratios
            for row in soup.select("ul#top-ratios li"):
                try:
                    key = row.select_one("span.name")
                    val = row.select_one("span.number, span.value")
                    
                    if key and val:
                        key_text = key.text.strip()
                        if "Market Cap" in key_text:
                            market_cap_text = val.text.strip()
                            market_cap = clean_market_cap(market_cap_text)
                            if market_cap > 0:
                                logger.info(f"  Market Cap for {symbol}: Rs {market_cap:,.2f} Cr")
                                return market_cap
                except Exception as e:
                    continue
            
            logger.warning(f"  Market Cap not found for {symbol}")
            return None
        
        except Exception as e:
            logger.error(f"  Error extracting market cap for {symbol}: {e}")
            return None
    
    def extract_shareholding_pattern(self, soup: BeautifulSoup, symbol: str) -> Dict[str, float]:
        """
        Extract shareholding pattern (Promoters, FII, DII, Public).
        
        Args:
            soup: BeautifulSoup object of the page
            symbol: Stock symbol (for logging)
        
        Returns:
            dict: Shareholding percentages with keys:
                - Promoter_Holding
                - FII_Holding
                - DII_Holding
                - Public_Holding
                - Free_Float (calculated)
        """
        shareholding = {
            'Promoter_Holding': 0.0,
            'FII_Holding': 0.0,
            'DII_Holding': 0.0,
            'Public_Holding': 0.0,
            'Free_Float': 0.0
        }
        
        try:
            # Method 1: Try to find shareholding pattern table
            # Look for the shareholding section
            shareholding_section = soup.find('section', {'id': 'shareholding'})
            
            if shareholding_section:
                # Find the most recent shareholding data (usually in the first table)
                table = shareholding_section.find('table')
                if table:
                    rows = table.find_all('tr')
                    for row in rows:
                        cells = row.find_all(['td', 'th'])
                        if len(cells) >= 2:
                            label = cells[0].get_text(strip=True)
                            # Get the most recent value (usually the last column)
                            value_cells = [c for c in cells[1:] if c.get_text(strip=True)]
                            if value_cells:
                                value_text = value_cells[-1].get_text(strip=True)
                                value = clean_percentage(value_text)
                                
                                # Match different label variations
                                label_lower = label.lower()
                                if 'promoter' in label_lower:
                                    shareholding['Promoter_Holding'] = value
                                    logger.info(f"  Promoter Holding for {symbol}: {value:.2f}%")
                                elif 'fii' in label_lower or 'foreign' in label_lower:
                                    shareholding['FII_Holding'] = value
                                    logger.info(f"  FII Holding for {symbol}: {value:.2f}%")
                                elif 'dii' in label_lower or 'domestic' in label_lower:
                                    shareholding['DII_Holding'] = value
                                    logger.info(f"  DII Holding for {symbol}: {value:.2f}%")
                                elif 'public' in label_lower:
                                    shareholding['Public_Holding'] = value
                                    logger.info(f"  Public Holding for {symbol}: {value:.2f}%")
            
            # Method 2: Alternative - Look for text patterns in the page
            if shareholding['Promoter_Holding'] == 0.0:
                # Try to find in any text content
                page_text = soup.get_text()
                # This is a backup method - less reliable
                
            # Calculate Free Float
            # Free Float = 100% - Promoter Holding
            # Some definitions also subtract strategic holdings, but typically it's just promoter holding
            shareholding['Free_Float'] = 100.0 - shareholding['Promoter_Holding']
            
            if shareholding['Promoter_Holding'] > 0:
                logger.info(f"  Free Float for {symbol}: {shareholding['Free_Float']:.2f}%")
            else:
                logger.warning(f"  Shareholding pattern not found for {symbol}")
            
            return shareholding
            
        except Exception as e:
            logger.error(f"  Error extracting shareholding for {symbol}: {e}")
            return shareholding
    
    def extract_financial_metrics(self, soup: BeautifulSoup, symbol: str) -> Dict[str, float]:
        """
        Extract key financial metrics and ratios.
        
        Args:
            soup: BeautifulSoup object of the page
            symbol: Stock symbol (for logging)
        
        Returns:
            dict: Financial metrics including P/E, P/B, ROE, ROCE, Debt/Equity, etc.
        """
        metrics = {
            'PE_Ratio': 0.0,
            'PB_Ratio': 0.0,
            'ROE_%': 0.0,
            'ROCE_%': 0.0,
            'Debt_to_Equity': 0.0,
            'EPS_Growth_3Yr_%': 0.0,
            'Revenue_Growth_3Yr_%': 0.0,
            'Operating_Margin_%': 0.0,
            'Free_Cash_Flow_Crores': 0.0,
            'Dividend_Yield_%': 0.0,
            'Price_to_Sales': 0.0,
            'Interest_Coverage': 0.0
        }
        
        try:
            # Debug: Print all available labels in top-ratios (ALWAYS for now to debug)
            logger.info(f"\n  === Available metrics in #top-ratios for {symbol} ===")
            top_ratios_labels = []
            for row in soup.select("ul#top-ratios li"):
                key_elem = row.select_one("span.name")
                # FIXED: Use nested selector to match the actual HTML structure
                val_elem = row.select_one("span.value span.number") or row.select_one("span.number") or row.select_one("span.value")
                if key_elem and val_elem:
                    label = key_elem.text.strip()
                    value = val_elem.text.strip()
                    top_ratios_labels.append(f"{label}: {value}")
                    if DEBUG_MODE:
                        logger.info(f"  {label}: {value}")
            
            if not DEBUG_MODE:
                logger.info(f"  Found {len(top_ratios_labels)} items: {', '.join([l.split(':')[0] for l in top_ratios_labels])}")
            
            # Extract from top-ratios section
            for row in soup.select("ul#top-ratios li"):
                try:
                    key_elem = row.select_one("span.name")
                    # Value can be nested: span.value > span.number OR direct span.number
                    val_elem = row.select_one("span.value span.number") or row.select_one("span.number") or row.select_one("span.value")
                    
                    if key_elem and val_elem:
                        key_text = key_elem.text.strip()
                        val_text = val_elem.text.strip()
                        
                        # P/E Ratio
                        if "Stock P/E" in key_text or key_text == "Stock P/E" or "P/E" in key_text:
                            if metrics['PE_Ratio'] == 0.0:  # Only set if not already set
                                metrics['PE_Ratio'] = clean_number(val_text)
                                logger.info(f"  P/E Ratio for {symbol}: {metrics['PE_Ratio']:.2f}")
                        
                        # P/B Ratio (various labels)
                        elif "price to book" in key_text.lower() or "price to book value" in key_text.lower() or key_text.upper() == "P/B":
                            if metrics['PB_Ratio'] == 0.0:
                                metrics['PB_Ratio'] = clean_number(val_text)
                                logger.info(f"  ✓ P/B Ratio (top-ratios) for {symbol}: {metrics['PB_Ratio']:.2f}")
                        
                        # ROE
                        elif key_text == "ROE" or "Return on Equity" in key_text:
                            if metrics['ROE_%'] == 0.0:
                                metrics['ROE_%'] = clean_percentage(val_text)
                                logger.info(f"  ROE for {symbol}: {metrics['ROE_%']:.2f}%")
                        
                        # ROCE
                        elif key_text == "ROCE" or "Return on Capital" in key_text:
                            if metrics['ROCE_%'] == 0.0:
                                metrics['ROCE_%'] = clean_percentage(val_text)
                                logger.info(f"  ROCE for {symbol}: {metrics['ROCE_%']:.2f}%")
                        
                        # Debt to Equity (check case-insensitive)
                        elif "debt to equity" in key_text.lower() or "debt-to-equity" in key_text.lower():
                            if metrics['Debt_to_Equity'] == 0.0:
                                metrics['Debt_to_Equity'] = clean_number(val_text)
                                logger.info(f"  ✓ Debt to Equity (top-ratios) for {symbol}: {metrics['Debt_to_Equity']:.2f}")
                            else:
                                logger.info(f"  (Skipping Debt to Equity - already set to {metrics['Debt_to_Equity']})")
                        
                        # Operating Margin (OPM - with or without %)
                        elif key_text.upper() == "OPM" or key_text == "OPM %" or "operating margin" in key_text.lower():
                            if metrics['Operating_Margin_%'] == 0.0:
                                metrics['Operating_Margin_%'] = clean_percentage(val_text)
                                logger.info(f"  ✓ Operating Margin (top-ratios) for {symbol}: {metrics['Operating_Margin_%']:.2f}%")
                        
                        # Dividend Yield
                        elif "Dividend Yield" in key_text or key_text == "Dividend Yield":
                            if metrics['Dividend_Yield_%'] == 0.0:
                                metrics['Dividend_Yield_%'] = clean_percentage(val_text)
                                logger.info(f"  Dividend Yield for {symbol}: {metrics['Dividend_Yield_%']:.2f}%")
                        
                        # Price to Sales (P/S Ratio - case-insensitive)
                        elif "price to sales" in key_text.lower() or "price/sales" in key_text.lower() or key_text.upper() == "P/S":
                            if metrics['Price_to_Sales'] == 0.0:
                                metrics['Price_to_Sales'] = clean_number(val_text)
                                logger.info(f"  ✓ Price to Sales (top-ratios) for {symbol}: {metrics['Price_to_Sales']:.2f}")
                        
                        # Interest Coverage (multiple variations)
                        elif "interest coverage" in key_text.lower() or "interest cover" in key_text.lower() or "int coverage" in key_text.lower():
                            if metrics['Interest_Coverage'] == 0.0:
                                metrics['Interest_Coverage'] = clean_number(val_text)
                                logger.info(f"  ✓ Interest Coverage (top-ratios) for {symbol}: {metrics['Interest_Coverage']:.2f}")
                
                except Exception as e:
                    continue
            
            # Look in #ratios section for additional metrics (comprehensive search)
            ratios_section = soup.find('section', {'id': 'ratios'})
            if ratios_section:
                tables = ratios_section.find_all('table')
                for table in tables:
                    rows = table.find_all('tr')
                    for row in rows:
                        cells = row.find_all(['td', 'th'])
                        if len(cells) >= 2:
                            label = cells[0].get_text(strip=True)
                            # Get the most recent value (last non-empty column)
                            value_cells = [c for c in cells[1:] if c.get_text(strip=True) and c.get_text(strip=True) != '-']
                            if not value_cells:
                                continue
                            value_text = value_cells[-1].get_text(strip=True)
                            
                            label_lower = label.lower()
                            
                            # Debt to Equity (various possible labels)
                            if metrics['Debt_to_Equity'] == 0.0:
                                if ('debt' in label_lower and 'equity' in label_lower) or 'debt/equity' in label_lower or 'd/e' in label_lower:
                                    metrics['Debt_to_Equity'] = clean_number(value_text)
                                    logger.info(f"  Debt to Equity (ratios) for {symbol}: {metrics['Debt_to_Equity']:.2f}")
                            
                            # Operating Margin (OPM) - might also be in ratios
                            if metrics['Operating_Margin_%'] == 0.0:
                                if 'opm' in label_lower or 'operating margin' in label_lower or 'operating profit margin' in label_lower:
                                    metrics['Operating_Margin_%'] = clean_percentage(value_text)
                                    logger.info(f"  Operating Margin (ratios) for {symbol}: {metrics['Operating_Margin_%']:.2f}%")
                            
                            # Interest Coverage (various labels)
                            if metrics['Interest_Coverage'] == 0.0:
                                if 'interest coverage' in label_lower or 'interest cover' in label_lower or 'times interest earned' in label_lower:
                                    metrics['Interest_Coverage'] = clean_number(value_text)
                                    logger.info(f"  Interest Coverage (ratios) for {symbol}: {metrics['Interest_Coverage']:.2f}")
                            
                            # Price to Sales
                            if metrics['Price_to_Sales'] == 0.0:
                                if 'price to sales' in label_lower or 'price/sales' in label_lower or 'p/s' in label_lower:
                                    metrics['Price_to_Sales'] = clean_number(value_text)
                                    logger.info(f"  Price to Sales (ratios) for {symbol}: {metrics['Price_to_Sales']:.2f}")
            
            # Also check balance-sheet section for Debt/Equity if not found
            if metrics['Debt_to_Equity'] == 0.0:
                balance_sheet = soup.find('section', {'id': 'balance-sheet'})
                if balance_sheet:
                    tables = balance_sheet.find_all('table')
                    for table in tables:
                        rows = table.find_all('tr')
                        for row in rows:
                            cells = row.find_all(['td', 'th'])
                            if len(cells) >= 2:
                                label = cells[0].get_text(strip=True)
                                label_lower = label.lower()
                                if 'debt' in label_lower and 'equity' in label_lower:
                                    value_cells = [c for c in cells[1:] if c.get_text(strip=True) and c.get_text(strip=True) != '-']
                                    if value_cells:
                                        value_text = value_cells[-1].get_text(strip=True)
                                        metrics['Debt_to_Equity'] = clean_number(value_text)
                                        logger.info(f"  Debt to Equity (balance-sheet) for {symbol}: {metrics['Debt_to_Equity']:.2f}")
                                        break
            
            # Calculate P/B Ratio if we have Book Value
            if metrics['PB_Ratio'] == 0.0:
                # Try to find current price and book value to calculate P/B
                current_price = 0.0
                book_value = 0.0
                
                for row in soup.select("ul#top-ratios li"):
                    key_elem = row.select_one("span.name")
                    # FIXED: Use nested selector to match actual HTML
                    val_elem = row.select_one("span.value span.number") or row.select_one("span.number") or row.select_one("span.value")
                    if key_elem and val_elem:
                        key_text = key_elem.text.strip()
                        val_text = val_elem.text.strip()
                        
                        if 'Current Price' in key_text:
                            current_price = clean_number(val_text)
                        elif 'Book Value' in key_text:
                            book_value = clean_number(val_text)
                
                if current_price > 0 and book_value > 0:
                    metrics['PB_Ratio'] = round(current_price / book_value, 2)
                    logger.info(f"  P/B Ratio (calculated: {current_price:.0f}/{book_value:.0f}) for {symbol}: {metrics['PB_Ratio']:.2f}")
                elif current_price == 0 or book_value == 0:
                    logger.warning(f"  P/B Ratio calculation failed for {symbol}: Price={current_price}, BookValue={book_value}")
            
            # Extract growth metrics - Look in profit-loss section for 10-year data table
            pl_section = soup.find('section', {'id': 'profit-loss'})
            if pl_section and (metrics['Revenue_Growth_3Yr_%'] == 0.0 or metrics['EPS_Growth_3Yr_%'] == 0.0):
                tables = pl_section.find_all('table')
                for table in tables:
                    rows = table.find_all('tr')
                    if len(rows) > 0:
                        # Try to find the header row with years
                        header_row = rows[0]
                        header_cells = header_row.find_all(['th', 'td'])
                        
                        # Parse all year columns
                        year_columns = []
                        for idx, cell in enumerate(header_cells[1:], 1):  # Skip first column (labels)
                            cell_text = cell.get_text(strip=True)
                            # Check if it's a year or date
                            if any(char.isdigit() for char in cell_text):
                                year_columns.append(idx)
                        
                        # Process data rows
                        for row in rows[1:]:
                            cells = row.find_all(['td', 'th'])
                            if len(cells) >= 2:
                                label = cells[0].get_text(strip=True)
                                label_lower = label.lower()
                                
                                # Sales/Revenue Growth - calculate from oldest to newest year
                                if ('sales' in label_lower or 'revenue' in label_lower) and metrics['Revenue_Growth_3Yr_%'] == 0.0:
                                    if len(year_columns) >= 4 and len(cells) > max(year_columns):
                                        try:
                                            # Get oldest value (3-4 years ago)
                                            oldest_val = clean_number(cells[year_columns[-4]].get_text(strip=True))
                                            # Get newest value
                                            newest_val = clean_number(cells[year_columns[-1]].get_text(strip=True))
                                            
                                            if oldest_val > 0 and newest_val > 0:
                                                # Calculate CAGR
                                                years = 3
                                                cagr = ((newest_val / oldest_val) ** (1 / years) - 1) * 100
                                                metrics['Revenue_Growth_3Yr_%'] = round(cagr, 2)
                                                logger.info(f"  Revenue Growth (calculated) for {symbol}: {metrics['Revenue_Growth_3Yr_%']:.2f}%")
                                        except:
                                            pass
                                
                                # EPS Growth
                                elif 'eps' in label_lower and 'in rs' in label_lower and metrics['EPS_Growth_3Yr_%'] == 0.0:
                                    if len(year_columns) >= 4 and len(cells) > max(year_columns):
                                        try:
                                            oldest_val = clean_number(cells[year_columns[-4]].get_text(strip=True))
                                            newest_val = clean_number(cells[year_columns[-1]].get_text(strip=True))
                                            
                                            if oldest_val > 0 and newest_val > 0:
                                                years = 3
                                                cagr = ((newest_val / oldest_val) ** (1 / years) - 1) * 100
                                                metrics['EPS_Growth_3Yr_%'] = round(cagr, 2)
                                                logger.info(f"  EPS Growth (calculated) for {symbol}: {metrics['EPS_Growth_3Yr_%']:.2f}%")
                                        except:
                                            pass
            
            # Extract Operating Margin from quarters section
            if metrics['Operating_Margin_%'] == 0.0:
                quarters_section = soup.find('section', {'id': 'quarters'})
                if quarters_section:
                    table = quarters_section.find('table')
                    if table:
                        rows = table.find_all('tr')
                        for row in rows:
                            cells = row.find_all(['td', 'th'])
                            if len(cells) >= 2:
                                label = cells[0].get_text(strip=True)
                                if 'OPM %' in label or label == 'OPM %' or 'OPM%' in label:
                                    # Get most recent quarter (last column)
                                    value_cells = [c for c in cells[1:] if c.get_text(strip=True) and c.get_text(strip=True) != '-']
                                    if value_cells:
                                        opm_text = value_cells[-1].get_text(strip=True)
                                        metrics['Operating_Margin_%'] = clean_percentage(opm_text)
                                        logger.info(f"  Operating Margin (quarters) for {symbol}: {metrics['Operating_Margin_%']:.2f}%")
                                        break
            
            # Extract/Calculate Free Cash Flow from cash flow section
            cashflow_section = soup.find('section', {'id': 'cash-flow'})
            if cashflow_section and metrics['Free_Cash_Flow_Crores'] == 0.0:
                table = cashflow_section.find('table')
                if table:
                    rows = table.find_all('tr')
                    operating_cf = 0.0
                    investing_cf = 0.0
                    
                    for row in rows:
                        cells = row.find_all(['td', 'th'])
                        if len(cells) >= 2:
                            label = cells[0].get_text(strip=True)
                            label_lower = label.lower()
                            
                            # Get most recent value (last column)
                            value_cells = [c for c in cells[1:] if c.get_text(strip=True) and c.get_text(strip=True) != '-']
                            if value_cells:
                                value_text = value_cells[-1].get_text(strip=True)
                                
                                # Look for Free Cash Flow (direct)
                                if 'free cash flow' in label_lower:
                                    metrics['Free_Cash_Flow_Crores'] = clean_number(value_text)
                                    logger.info(f"  Free Cash Flow for {symbol}: ₹{metrics['Free_Cash_Flow_Crores']:.2f} Cr")
                                    break
                                
                                # Collect components to calculate FCF
                                elif 'operating activity' in label_lower or 'cash from operating' in label_lower:
                                    operating_cf = clean_number(value_text)
                                elif 'investing activity' in label_lower or 'cash from investing' in label_lower:
                                    investing_cf = clean_number(value_text)
                    
                    # Calculate FCF if not found directly: Operating CF + Investing CF (investing is usually negative)
                    if metrics['Free_Cash_Flow_Crores'] == 0.0 and operating_cf != 0.0:
                        metrics['Free_Cash_Flow_Crores'] = operating_cf + investing_cf  # investing_cf is typically negative
                        logger.info(f"  Free Cash Flow (calculated) for {symbol}: ₹{metrics['Free_Cash_Flow_Crores']:.2f} Cr")
            
            # Final comprehensive search for any missing critical metrics in ALL tables
            if metrics['Debt_to_Equity'] == 0.0 or metrics['Price_to_Sales'] == 0.0 or metrics['Interest_Coverage'] == 0.0:
                all_tables = soup.find_all('table')
                for table in all_tables:
                    rows = table.find_all('tr')
                    for row in rows:
                        cells = row.find_all(['td', 'th'])
                        if len(cells) >= 2:
                            label = cells[0].get_text(strip=True).lower()
                            value_cells = [c for c in cells[1:] if c.get_text(strip=True) and c.get_text(strip=True) != '-']
                            if not value_cells:
                                continue
                            value_text = value_cells[-1].get_text(strip=True)
                            
                            # Very aggressive search for remaining metrics
                            if metrics['Debt_to_Equity'] == 0.0:
                                if 'debt' in label and ('equity' in label or 'capital' in label):
                                    val = clean_number(value_text)
                                    if val > 0 and val < 100:  # Sanity check (D/E rarely > 100)
                                        metrics['Debt_to_Equity'] = val
                                        logger.info(f"  Debt to Equity (comprehensive search) for {symbol}: {val:.2f}")
                            
                            if metrics['Interest_Coverage'] == 0.0:
                                if 'interest' in label and ('coverage' in label or 'cover' in label):
                                    val = clean_number(value_text)
                                    if val > 0 and val < 1000:  # Sanity check
                                        metrics['Interest_Coverage'] = val
                                        logger.info(f"  Interest Coverage (comprehensive search) for {symbol}: {val:.2f}")
                            
                            if metrics['Price_to_Sales'] == 0.0:
                                if 'price' in label and 'sales' in label:
                                    val = clean_number(value_text)
                                    if val > 0 and val < 100:  # Sanity check
                                        metrics['Price_to_Sales'] = val
                                        logger.info(f"  Price to Sales (comprehensive search) for {symbol}: {val:.2f}")
            
            # For banks/financial companies, Debt/Equity might not be applicable - set to 0 is okay
            # But log it for transparency
            if metrics['Debt_to_Equity'] == 0.0:
                logger.info(f"  Note: Debt to Equity not found for {symbol} (may not be applicable for financial companies)")
            
            # Debug: Print what we found
            if DEBUG_MODE:
                logger.info(f"\n  === DEBUG: Metrics extracted for {symbol} ===")
                for key, value in metrics.items():
                    status = "✓" if value != 0.0 else "✗"
                    logger.info(f"  {status} {key}: {value}")
            
            # Summary log
            found_count = sum(1 for v in metrics.values() if v != 0.0)
            logger.info(f"  Found {found_count}/12 financial metrics for {symbol}")
            
            # Warn about commonly missing metrics
            missing = []
            if metrics['Debt_to_Equity'] == 0.0:
                missing.append("Debt/Equity")
            if metrics['Price_to_Sales'] == 0.0:
                missing.append("Price/Sales")
            if metrics['Interest_Coverage'] == 0.0:
                missing.append("Interest Coverage")
            
            if missing:
                logger.warning(f"  Missing: {', '.join(missing)} - may not be available on screener.in for {symbol}")
            
            return metrics
            
        except Exception as e:
            logger.error(f"  Error extracting financial metrics for {symbol}: {e}")
            return metrics
    
    def scrape_symbol(self, symbol: str) -> Dict:
        """
        Scrape sector hierarchy, market cap, and shareholding pattern for a single symbol.
        
        Args:
            symbol: Stock symbol to scrape
        
        Returns:
            dict: Scraped data including sector levels, market cap, and shareholding
        """
        url = BASE_URL.format(symbol.upper())
        logger.info(f"Fetching {symbol} from {url}")
        
        # Rate limiting
        time.sleep(random.uniform(*self.delay_range))
        
        try:
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract sector hierarchy
            sector_levels = self.extract_sector_hierarchy(soup, symbol)
            
            # Extract market cap
            market_cap = self.extract_market_cap(soup, symbol)
            
            # Extract shareholding pattern
            shareholding = self.extract_shareholding_pattern(soup, symbol)
            
            # Extract financial metrics
            financial_metrics = self.extract_financial_metrics(soup, symbol)
            
            # Build result dictionary
            result = {
                'Symbol': symbol.upper(),
                'Market_Cap_Crores': market_cap if market_cap is not None else 0.0,
            }
            
            # Add sector levels
            for i, level in enumerate(sector_levels, 1):
                result[f'Sector_Level_{i}'] = level
            
            # Fill missing levels with None
            max_levels = 4
            for i in range(len(sector_levels) + 1, max_levels + 1):
                result[f'Sector_Level_{i}'] = None
            
            # Add shareholding data
            result['Promoter_Holding_%'] = shareholding['Promoter_Holding']
            result['FII_Holding_%'] = shareholding['FII_Holding']
            result['DII_Holding_%'] = shareholding['DII_Holding']
            result['Public_Holding_%'] = shareholding['Public_Holding']
            result['Free_Float_%'] = shareholding['Free_Float']
            
            # Calculate Free Float Market Cap
            if market_cap and market_cap > 0:
                result['Free_Float_Market_Cap_Crores'] = (market_cap * shareholding['Free_Float']) / 100.0
            else:
                result['Free_Float_Market_Cap_Crores'] = 0.0
            
            # Add financial metrics
            result['PE_Ratio'] = financial_metrics['PE_Ratio']
            result['PB_Ratio'] = financial_metrics['PB_Ratio']
            result['ROE_%'] = financial_metrics['ROE_%']
            result['ROCE_%'] = financial_metrics['ROCE_%']
            result['Debt_to_Equity'] = financial_metrics['Debt_to_Equity']
            result['EPS_Growth_3Yr_%'] = financial_metrics['EPS_Growth_3Yr_%']
            result['Revenue_Growth_3Yr_%'] = financial_metrics['Revenue_Growth_3Yr_%']
            result['Operating_Margin_%'] = financial_metrics['Operating_Margin_%']
            result['Free_Cash_Flow_Crores'] = financial_metrics['Free_Cash_Flow_Crores']
            result['Dividend_Yield_%'] = financial_metrics['Dividend_Yield_%']
            result['Price_to_Sales'] = financial_metrics['Price_to_Sales']
            result['Interest_Coverage'] = financial_metrics['Interest_Coverage']
            
            # Calculate fundamental scores
            scores = calculate_fundamental_score(financial_metrics)
            result.update(scores)
            
            result['Status'] = 'Success'
            result['Scraped_At'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            logger.info(f"Successfully scraped {symbol}")
            return result
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed for {symbol}: {e}")
            return self._create_error_result(symbol, f"Request failed: {e}")
        
        except Exception as e:
            logger.error(f"Error processing {symbol}: {e}")
            return self._create_error_result(symbol, f"Processing error: {e}")
    
    def _create_error_result(self, symbol: str, error_msg: str) -> Dict:
        """Create a result dictionary for failed scrapes."""
        base_result = {
            'Symbol': symbol.upper(),
            'Market_Cap_Crores': 0.0,
            'Sector_Level_1': None,
            'Sector_Level_2': None,
            'Sector_Level_3': None,
            'Sector_Level_4': None,
            'Promoter_Holding_%': 0.0,
            'FII_Holding_%': 0.0,
            'DII_Holding_%': 0.0,
            'Public_Holding_%': 0.0,
            'Free_Float_%': 0.0,
            'Free_Float_Market_Cap_Crores': 0.0,
            'PE_Ratio': 0.0,
            'PB_Ratio': 0.0,
            'ROE_%': 0.0,
            'ROCE_%': 0.0,
            'Debt_to_Equity': 0.0,
            'EPS_Growth_3Yr_%': 0.0,
            'Revenue_Growth_3Yr_%': 0.0,
            'Operating_Margin_%': 0.0,
            'Free_Cash_Flow_Crores': 0.0,
            'Dividend_Yield_%': 0.0,
            'Price_to_Sales': 0.0,
            'Interest_Coverage': 0.0,
        }
        
        # Add empty scores
        empty_metrics = {k: 0.0 for k in base_result.keys() if k not in ['Symbol', 'Market_Cap_Crores']}
        scores = calculate_fundamental_score(empty_metrics)
        base_result.update(scores)
        
        base_result['Status'] = error_msg
        base_result['Scraped_At'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        return base_result
    
    def scrape_symbols(self, symbols: List[str]) -> pd.DataFrame:
        """
        Scrape multiple symbols.
        
        Args:
            symbols: List of stock symbols
        
        Returns:
            DataFrame: Results for all symbols
        """
        logger.info(f"Starting scrape for {len(symbols)} symbols")
        results = []
        
        for i, symbol in enumerate(symbols, 1):
            logger.info(f"\n{'='*60}")
            logger.info(f"Progress: [{i}/{len(symbols)}] - {(i/len(symbols)*100):.1f}%")
            logger.info(f"{'='*60}")
            
            result = self.scrape_symbol(symbol)
            results.append(result)
        
        df = pd.DataFrame(results)
        
        # Summary statistics
        successful = df[df['Status'] == 'Success']
        logger.info(f"\n{'='*60}")
        logger.info(f"SCRAPING SUMMARY")
        logger.info(f"{'='*60}")
        logger.info(f"Total symbols: {len(df)}")
        logger.info(f"Successful: {len(successful)} ({len(successful)/len(df)*100:.1f}%)")
        logger.info(f"Failed: {len(df) - len(successful)}")
        
        return df

# ============================================================================
# MAIN FUNCTION
# ============================================================================

def main():
    """Main execution function."""
    
    print("\n" + "="*70)
    print("🚀 COMPREHENSIVE STOCK FUNDAMENTAL SCRAPER WITH SCORING")
    print("="*70)
    print("📊 Extracting: Sector | Market Cap | Shareholding | Free Float")
    print("💰 Financial: P/E | P/B | ROE | ROCE | Debt/Equity | OPM | P/S")
    print("📈 Growth: EPS Growth | Revenue Growth | Free Cash Flow")
    print("💎 Advanced: Interest Coverage | Dividend Yield")
    print("🏆 SCORING: 12 weighted metrics → Total Score (0-100)")
    print("="*70 + "\n")
    
    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # Load input CSV
    if not os.path.exists(INPUT_CSV):
        logger.error(f"Input file not found: {INPUT_CSV}")
        return
    
    try:
        df_input = pd.read_csv(INPUT_CSV)
        logger.info(f"Loaded input file: {INPUT_CSV}")
    except Exception as e:
        logger.error(f"Failed to read CSV: {e}")
        return
    
    # Find symbol column (case-insensitive)
    symbol_col = None
    for col in df_input.columns:
        if col.strip().lower() == 'symbol':
            symbol_col = col
            break
    
    if symbol_col is None:
        logger.error(f"'Symbol' column not found in CSV")
        logger.error(f"Available columns: {df_input.columns.tolist()}")
        return
    
    # Prepare symbol list
    symbols = (
        df_input[symbol_col]
        .dropna()
        .astype(str)
        .str.upper()
        .str.strip()
        .unique()
        .tolist()
    )
    
    if not symbols:
        logger.error("No symbols found in CSV")
        return
    
    logger.info(f"Preview symbols: {symbols[:10]}")
    logger.info(f"Total unique symbols: {len(symbols)}")
    
    # Initialize scraper
    scraper = UnifiedScreenerScraper()
    
    # Scrape all symbols
    df_results = scraper.scrape_symbols(symbols)
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_file = os.path.join(OUTPUT_DIR, f"29oct2025_sector_marketcap_freefloat_{timestamp}.csv")
    df_results.to_csv(output_file, index=False)
    
    print("\n" + "="*60)
    print("✅ SCRAPING COMPLETED")
    print("="*60)
    print(f"📁 Output file: {output_file}")
    print(f"📊 Total records: {len(df_results)}")
    
    # Display sample results
    print("\n📋 First 5 results (Key Columns):")
    # Show key columns for preview
    preview_cols = ['Symbol', 'Total_Score', 'Market_Cap_Crores', 'PE_Ratio', 'ROE_%', 'Free_Float_%', 'Status']
    available_cols = [col for col in preview_cols if col in df_results.columns]
    if available_cols:
        print(df_results[available_cols].head().to_string(index=False))
    else:
        print(df_results.head().to_string(index=False))
    
    # Display sector distribution
    if 'Sector_Level_1' in df_results.columns:
        print("\n📊 Top Sector Distribution:")
        sector_counts = df_results['Sector_Level_1'].value_counts().head(10)
        print(sector_counts.to_string())
    
    # Display market cap statistics
    successful_df = df_results[df_results['Status'] == 'Success']
    if len(successful_df) > 0:
        if 'Market_Cap_Crores' in df_results.columns:
            print("\n💰 Market Cap Statistics:")
            print(f"  Average: ₹{successful_df['Market_Cap_Crores'].mean():,.2f} Cr")
            print(f"  Median:  ₹{successful_df['Market_Cap_Crores'].median():,.2f} Cr")
            print(f"  Max:     ₹{successful_df['Market_Cap_Crores'].max():,.2f} Cr")
            print(f"  Min:     ₹{successful_df['Market_Cap_Crores'].min():,.2f} Cr")
        
        # Display shareholding statistics
        if 'Promoter_Holding_%' in df_results.columns:
            promoter_df = successful_df[successful_df['Promoter_Holding_%'] > 0]
            if len(promoter_df) > 0:
                print("\n📈 Shareholding Pattern Statistics:")
                print(f"  Average Promoter Holding: {promoter_df['Promoter_Holding_%'].mean():.2f}%")
                print(f"  Average FII Holding:      {promoter_df['FII_Holding_%'].mean():.2f}%")
                print(f"  Average DII Holding:      {promoter_df['DII_Holding_%'].mean():.2f}%")
                print(f"  Average Free Float:       {promoter_df['Free_Float_%'].mean():.2f}%")
                
                # Show low free float stocks
                print("\n🔒 Top 10 Stocks with Lowest Free Float:")
                low_float = promoter_df.nsmallest(10, 'Free_Float_%')[['Symbol', 'Promoter_Holding_%', 'Free_Float_%', 'Market_Cap_Crores']]
                print(low_float.to_string(index=False))
                
                # Show high free float stocks
                print("\n🔓 Top 10 Stocks with Highest Free Float:")
                high_float = promoter_df.nlargest(10, 'Free_Float_%')[['Symbol', 'Promoter_Holding_%', 'Free_Float_%', 'Market_Cap_Crores']]
                print(high_float.to_string(index=False))
        
        # Display financial metrics statistics
        if 'PE_Ratio' in df_results.columns:
            financial_df = successful_df[successful_df['PE_Ratio'] > 0]
            if len(financial_df) > 0:
                print("\n📊 Financial Metrics - Average Statistics:")
                print(f"  Average P/E Ratio:        {financial_df['PE_Ratio'].mean():.2f}")
                print(f"  Average P/B Ratio:        {financial_df['PB_Ratio'].mean():.2f}")
                print(f"  Average ROE:              {financial_df['ROE_%'].mean():.2f}%")
                print(f"  Average ROCE:             {financial_df['ROCE_%'].mean():.2f}%")
                print(f"  Average Debt/Equity:      {financial_df['Debt_to_Equity'].mean():.2f}")
                print(f"  Average Operating Margin: {financial_df['Operating_Margin_%'].mean():.2f}%")
                
                # Show growth statistics if available
                growth_df = successful_df[(successful_df['EPS_Growth_3Yr_%'] != 0) | (successful_df['Revenue_Growth_3Yr_%'] != 0)]
                if len(growth_df) > 0:
                    print("\n📈 Growth Metrics - Average Statistics:")
                    print(f"  Average EPS Growth (3Yr):     {growth_df['EPS_Growth_3Yr_%'].mean():.2f}%")
                    print(f"  Average Revenue Growth (3Yr): {growth_df['Revenue_Growth_3Yr_%'].mean():.2f}%")
                
                # Top quality stocks by ROE
                print("\n⭐ Top 10 Stocks by ROE (Return on Equity):")
                top_roe = financial_df.nlargest(10, 'ROE_%')[['Symbol', 'ROE_%', 'ROCE_%', 'PE_Ratio', 'Debt_to_Equity']]
                print(top_roe.to_string(index=False))
                
                # Top growth stocks
                if len(growth_df) > 0:
                    print("\n🚀 Top 10 Stocks by Revenue Growth (3Yr):")
                    top_growth = growth_df.nlargest(10, 'Revenue_Growth_3Yr_%')[['Symbol', 'Revenue_Growth_3Yr_%', 'EPS_Growth_3Yr_%', 'ROE_%', 'PE_Ratio']]
                    print(top_growth.to_string(index=False))
                
                # Value stocks - Low P/E with good ROE
                value_df = financial_df[(financial_df['PE_Ratio'] > 0) & (financial_df['PE_Ratio'] < 20) & (financial_df['ROE_%'] > 15)]
                if len(value_df) > 0:
                    print("\n💎 Potential Value Stocks (P/E < 20, ROE > 15%):")
                    value_stocks = value_df.nsmallest(10, 'PE_Ratio')[['Symbol', 'PE_Ratio', 'PB_Ratio', 'ROE_%', 'Debt_to_Equity', 'Free_Float_%']]
                    print(value_stocks.to_string(index=False))
        
        # Display scoring analysis
        if 'Total_Score' in df_results.columns:
            scored_df = successful_df[successful_df['Total_Score'] > 0]
            if len(scored_df) > 0:
                print("\n" + "="*70)
                print("🏆 FUNDAMENTAL SCORING ANALYSIS")
                print("="*70)
                print("\n📐 Weighting System Applied:")
                print("  EPS Growth: 20% | Revenue Growth: 15% | ROE: 15%")
                print("  Debt/Equity: 10% | ROCE: 10% | FCF: 10% | P/E: 10%")
                print("  Operating Margin: 5% | P/B: 5%")
                print("  Dividend Yield: 2% | P/S: 2% | Interest Coverage: 2%")
                print("\nScoring Summary:")
                print(f"  Average Total Score:  {scored_df['Total_Score'].mean():.2f}/100")
                print(f"  Median Total Score:   {scored_df['Total_Score'].median():.2f}/100")
                print(f"  Highest Score:        {scored_df['Total_Score'].max():.2f}/100")
                print(f"  Lowest Score:         {scored_df['Total_Score'].min():.2f}/100")
                print(f"  Average Metrics Scored: {scored_df['Metrics_Scored'].mean():.1f}/12 metrics")
                if 'Weight_Coverage_%' in scored_df.columns:
                    print(f"  Average Weight Coverage: {scored_df['Weight_Coverage_%'].mean():.1f}% of total")
                
                # Top 15 stocks by fundamental score
                print("\n🥇 TOP 15 FUNDAMENTALLY STRONG STOCKS (by Total Score):")
                print("="*70)
                top_stocks_cols = ['Symbol', 'Total_Score', 'ROE_%', 'Revenue_Growth_3Yr_%', 'PE_Ratio', 'Debt_to_Equity', 'Free_Float_%']
                top_stocks_available = [col for col in top_stocks_cols if col in scored_df.columns]
                top_15 = scored_df.nlargest(15, 'Total_Score')[top_stocks_available]
                print(top_15.to_string(index=False))
                
                # Score categories
                excellent = len(scored_df[scored_df['Total_Score'] >= 75])
                very_good = len(scored_df[(scored_df['Total_Score'] >= 60) & (scored_df['Total_Score'] < 75)])
                good = len(scored_df[(scored_df['Total_Score'] >= 50) & (scored_df['Total_Score'] < 60)])
                average = len(scored_df[(scored_df['Total_Score'] >= 40) & (scored_df['Total_Score'] < 50)])
                below_avg = len(scored_df[scored_df['Total_Score'] < 40])
                
                print("\n📊 Score Distribution:")
                print(f"  Excellent (75-100):   {excellent} stocks ({excellent/len(scored_df)*100:.1f}%)")
                print(f"  Very Good (60-74):    {very_good} stocks ({very_good/len(scored_df)*100:.1f}%)")
                print(f"  Good (50-59):         {good} stocks ({good/len(scored_df)*100:.1f}%)")
                print(f"  Average (40-49):      {average} stocks ({average/len(scored_df)*100:.1f}%)")
                print(f"  Below Average (<40):  {below_avg} stocks ({below_avg/len(scored_df)*100:.1f}%)")
                
                # High score + Low free float = Best opportunities
                excellent_low_float = scored_df[(scored_df['Total_Score'] >= 60) & (scored_df['Free_Float_%'] < 40)]
                if len(excellent_low_float) > 0:
                    print("\n💎 BEST OPPORTUNITIES: High Score + Low Free Float:")
                    print("="*70)
                    best_opp_cols = ['Symbol', 'Total_Score', 'Free_Float_%', 'ROE_%', 'Revenue_Growth_3Yr_%', 'PE_Ratio', 'Market_Cap_Crores']
                    best_opp_available = [col for col in best_opp_cols if col in excellent_low_float.columns]
                    best_opportunities = excellent_low_float.nlargest(10, 'Total_Score')[best_opp_available]
                    print(best_opportunities.to_string(index=False))
                
                # Bottom performers (for awareness)
                if len(scored_df) >= 10:
                    print("\n⚠️ BOTTOM 10 STOCKS (by Total Score) - Avoid or Research Further:")
                    print("="*70)
                    bottom_10_cols = ['Symbol', 'Total_Score', 'ROE_%', 'Debt_to_Equity', 'PE_Ratio', 'Revenue_Growth_3Yr_%']
                    bottom_10_available = [col for col in bottom_10_cols if col in scored_df.columns]
                    bottom_10 = scored_df.nsmallest(10, 'Total_Score')[bottom_10_available]
                    print(bottom_10.to_string(index=False))
    
    print("\n" + "="*70)
    print("✨ SCRAPING & ANALYSIS COMPLETED!")
    print("="*70)
    print(f"📁 Full data saved to: {output_file}")
    print(f"📊 Total columns: {len(df_results.columns)}")
    print(f"📈 Includes: Metrics + Individual Scores + Total Score (0-100)")
    print("\n💡 Use Total_Score column to rank stocks by fundamental strength!")
    print("="*70)

if __name__ == "__main__":
    main()

