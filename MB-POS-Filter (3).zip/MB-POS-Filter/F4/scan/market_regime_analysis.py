"""
Market Regime Analysis - Test Strategy Across Different Market Conditions

Tests strategy performance in:
- Bull markets (2023-2024)
- Bear markets (2022)
- Recent period (last 6 months)
- Different quarters
"""

import pandas as pd
from datetime import datetime, timedelta
from compare_risk_reward_cached import CachedDataFetcher
from backtest_scanner import EMAPullbackBacktester
import logging

logging.getLogger().setLevel(logging.WARNING)


def run_regime_analysis(api_key, access_token, input_csv):
    """Test strategy across different market regimes"""
    
    print("\n" + "="*80)
    print("📈 MARKET REGIME ANALYSIS")
    print("="*80)
    print("Testing strategy performance across different market conditions")
    print("This helps validate strategy robustness")
    print("="*80 + "\n")
    
    # Read symbols
    try:
        input_df = pd.read_csv(input_csv)
        if 'Symbol' not in input_df.columns:
            print("❌ Input CSV must have 'Symbol' column")
            return None
        symbols = input_df['Symbol'].dropna().unique().tolist()
        print(f"Found {len(symbols)} symbols to test\n")
    except Exception as e:
        print(f"❌ Error reading CSV: {e}")
        return None
    
    # Define market regimes (periods)
    regimes = {
        'Bull_Market_2023': (datetime(2023, 1, 1), datetime(2023, 12, 31)),
        'Bull_Market_2024': (datetime(2024, 1, 1), datetime(2024, 12, 31)),
        'Strong_Bull_Q4_2023': (datetime(2023, 10, 1), datetime(2023, 12, 31)),
        'Recent_6_Months': (datetime.now() - timedelta(days=180), datetime.now()),
        'Recent_3_Months': (datetime.now() - timedelta(days=90), datetime.now()),
        'Full_Period_2023-2025': (datetime(2023, 1, 1), datetime.now()),
    }
    
    # Top 3 configurations to test (from risk/reward analysis)
    configs = [
        ("Current 2:1", 0.03, 0.06, 1, "Balanced - Your current setting"),
        ("Moderate 2:1", 0.04, 0.08, 1, "Higher returns, higher risk"),
        ("Tighter 3:1", 0.02, 0.06, 1, "Lower risk, lower returns"),
    ]
    
    all_results = []
    
    # Test each configuration in each regime
    for config_name, sl, target, quality, desc in configs:
        print("\n" + "="*80)
        print(f"Testing: {config_name} ({desc})")
        print(f"Settings: {sl*100:.1f}% SL / {target*100:.1f}% Target")
        print("="*80)
        
        regime_results = []
        
        for regime_name, (start_date, end_date) in regimes.items():
            print(f"\n[{regime_name}] {start_date.date()} to {end_date.date()}")
            
            try:
                # Create backtester
                backtester = EMAPullbackBacktester(api_key, access_token)
                
                # Load or fetch cached data
                fetcher = CachedDataFetcher(backtester, symbols, start_date, end_date, 
                                           cache_file=f'cache_{regime_name}.pkl')
                data_cache = fetcher.fetch_all_data()
                
                if len(data_cache) < 10:
                    print("   ⚠️ Insufficient data")
                    continue
                
                # Configure backtester
                backtester.initial_capital = 1000000
                backtester.max_position_size = 0.05
                backtester.stop_loss_pct = sl
                backtester.target_pct = target
                backtester.max_holding_days = 20
                backtester.min_quality_score = quality
                
                # Reset
                backtester.trades = []
                backtester.current_capital = backtester.initial_capital
                
                # Run backtest using cached data
                for symbol, df in data_cache.items():
                    if symbol == '_metadata':
                        continue
                    
                    try:
                        start_idx = df[df['date'] >= start_date].index[0] if len(df[df['date'] >= start_date]) > 0 else 60
                        
                        i_idx = start_idx
                        while i_idx < len(df):
                            setup_found, setup_type, quality_score, details = backtester.identify_setup(df, i_idx)
                            
                            if setup_found and quality_score >= backtester.min_quality_score:
                                trade_result = backtester.simulate_trade(symbol, df, i_idx, setup_type, quality_score, details)
                                
                                if trade_result:
                                    backtester.trades.append(trade_result)
                                    exit_idx = df[df['date'] == trade_result['Exit_Date']].index[0]
                                    i_idx = exit_idx + 1
                                    continue
                            
                            i_idx += 1
                    except:
                        continue
                
                # Analyze results
                if len(backtester.trades) > 0:
                    trades_df = pd.DataFrame(backtester.trades)
                    
                    total_trades = len(trades_df)
                    winning_trades = len(trades_df[trades_df['Net_PnL'] > 0])
                    win_rate = (winning_trades / total_trades) * 100
                    total_return = ((backtester.current_capital - backtester.initial_capital) / backtester.initial_capital) * 100
                    
                    # Profit factor
                    gross_profit = trades_df[trades_df['Net_PnL'] > 0]['Net_PnL'].sum()
                    gross_loss = abs(trades_df[trades_df['Net_PnL'] < 0]['Net_PnL'].sum())
                    profit_factor = gross_profit / gross_loss if gross_loss > 0 else float('inf')
                    
                    # Drawdown
                    trades_df['Cumulative_PnL'] = trades_df['Net_PnL'].cumsum()
                    trades_df['Cumulative_Peak'] = trades_df['Cumulative_PnL'].cummax()
                    trades_df['Drawdown'] = trades_df['Cumulative_PnL'] - trades_df['Cumulative_Peak']
                    max_drawdown = trades_df['Drawdown'].min()
                    max_drawdown_pct = (max_drawdown / backtester.initial_capital) * 100
                    
                    # Days in period
                    days = (end_date - start_date).days
                    annualized_return = (total_return / days) * 365 if days > 0 else 0
                    
                    result = {
                        'Config': config_name,
                        'Regime': regime_name,
                        'Start': start_date.date(),
                        'End': end_date.date(),
                        'Days': days,
                        'Trades': total_trades,
                        'Win_Rate': round(win_rate, 2),
                        'Total_Return': round(total_return, 2),
                        'Annualized_Return': round(annualized_return, 2),
                        'Profit_Factor': round(profit_factor, 2),
                        'Max_Drawdown': round(max_drawdown_pct, 2),
                        'Avg_Trade_PnL': round(trades_df['Net_PnL'].mean(), 2),
                    }
                    
                    regime_results.append(result)
                    all_results.append(result)
                    
                    print(f"   ✓ Return: {total_return:.1f}% ({annualized_return:.0f}% annual) | WR: {win_rate:.1f}% | Trades: {total_trades} | DD: {max_drawdown_pct:.1f}%")
                else:
                    print(f"   ⚠️ No trades executed")
                    
            except Exception as e:
                print(f"   ❌ Error: {str(e)[:60]}")
                continue
        
        # Summary for this config across all regimes
        if regime_results:
            avg_return = sum(r['Total_Return'] for r in regime_results) / len(regime_results)
            avg_wr = sum(r['Win_Rate'] for r in regime_results) / len(regime_results)
            avg_dd = sum(r['Max_Drawdown'] for r in regime_results) / len(regime_results)
            
            print(f"\n{config_name} - Overall:")
            print(f"  Avg Return: {avg_return:.1f}% | Avg WR: {avg_wr:.1f}% | Avg DD: {avg_dd:.1f}%")
            print(f"  Tested in {len(regime_results)} regimes")
    
    # Generate comprehensive report
    if len(all_results) > 0:
        results_df = pd.DataFrame(all_results)
        
        # Save results
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_file = f"market_regime_analysis_{timestamp}.csv"
        results_df.to_csv(output_file, index=False)
        
        print("\n\n" + "="*80)
        print("📊 MARKET REGIME ANALYSIS RESULTS")
        print("="*80)
        
        # Best config per regime
        print("\n🏆 BEST CONFIGURATION PER MARKET REGIME:")
        print("-" * 80)
        
        for regime in regimes.keys():
            regime_data = results_df[results_df['Regime'] == regime]
            if len(regime_data) > 0:
                best = regime_data.loc[regime_data['Total_Return'].idxmax()]
                print(f"\n{regime}:")
                print(f"  Winner: {best['Config']}")
                print(f"  Return: {best['Total_Return']}% | Win Rate: {best['Win_Rate']}% | Trades: {best['Trades']}")
                print(f"  Drawdown: {best['Max_Drawdown']}% | PF: {best['Profit_Factor']}")
        
        # Most consistent config (works in all regimes)
        print("\n\n💎 MOST CONSISTENT CONFIGURATION:")
        print("-" * 80)
        
        consistency_scores = {}
        for config_name in results_df['Config'].unique():
            config_data = results_df[results_df['Config'] == config_name]
            
            # Score based on:
            # - Positive returns in all regimes
            # - Consistent win rate
            # - Low drawdown variance
            
            positive_returns = len(config_data[config_data['Total_Return'] > 0])
            total_regimes = len(config_data)
            
            if total_regimes > 0:
                avg_return = config_data['Total_Return'].mean()
                return_std = config_data['Total_Return'].std()
                avg_wr = config_data['Win_Rate'].mean()
                avg_dd = config_data['Max_Drawdown'].mean()
                
                # Consistency score (higher is better)
                score = (
                    (positive_returns / total_regimes) * 40 +  # 40% weight on always positive
                    (avg_return / 10) * 30 +                   # 30% weight on avg return
                    (100 - return_std) / 10 * 20 +             # 20% weight on consistency
                    (avg_wr / 10) * 10                         # 10% weight on win rate
                )
                
                consistency_scores[config_name] = {
                    'score': score,
                    'positive_regimes': f"{positive_returns}/{total_regimes}",
                    'avg_return': avg_return,
                    'return_std': return_std,
                    'avg_wr': avg_wr,
                    'avg_dd': avg_dd,
                }
        
        # Sort by consistency score
        sorted_configs = sorted(consistency_scores.items(), key=lambda x: x[1]['score'], reverse=True)
        
        for i, (config_name, metrics) in enumerate(sorted_configs, 1):
            print(f"\n{i}. {config_name}")
            print(f"   Consistency Score: {metrics['score']:.1f}/100")
            print(f"   Positive Returns: {metrics['positive_regimes']} regimes")
            print(f"   Avg Return: {metrics['avg_return']:.1f}% (±{metrics['return_std']:.1f}%)")
            print(f"   Avg Win Rate: {metrics['avg_wr']:.1f}%")
            print(f"   Avg Drawdown: {metrics['avg_dd']:.1f}%")
        
        # Performance matrix
        print("\n\n📈 PERFORMANCE MATRIX (Total Return %):")
        print("-" * 80)
        
        pivot = results_df.pivot_table(
            values='Total_Return',
            index='Config',
            columns='Regime',
            aggfunc='first'
        ).round(1)
        print(pivot.to_string())
        
        print("\n\n📊 WIN RATE MATRIX (%):")
        print("-" * 80)
        
        pivot_wr = results_df.pivot_table(
            values='Win_Rate',
            index='Config',
            columns='Regime',
            aggfunc='first'
        ).round(1)
        print(pivot_wr.to_string())
        
        # Recommendations
        print("\n\n" + "="*80)
        print("💡 RECOMMENDATIONS")
        print("="*80)
        
        best_consistent = sorted_configs[0]
        print(f"\n⭐ MOST ROBUST: {best_consistent[0]}")
        print(f"   Works consistently across {best_consistent[1]['positive_regimes']} market regimes")
        print(f"   Average return: {best_consistent[1]['avg_return']:.1f}%")
        print(f"   Use this if you want reliability across all market conditions")
        
        # Best for bull markets
        bull_data = results_df[results_df['Regime'].str.contains('Bull')]
        if len(bull_data) > 0:
            best_bull = bull_data.loc[bull_data['Total_Return'].idxmax()]
            print(f"\n🐂 BEST FOR BULL MARKETS: {best_bull['Config']}")
            print(f"   Avg return in bull markets: {bull_data[bull_data['Config']==best_bull['Config']]['Total_Return'].mean():.1f}%")
        
        print("\n" + "="*80)
        print(f"Full results saved to: {output_file}")
        print("="*80 + "\n")
        
        return results_df
    
    else:
        print("\n❌ No results generated")
        return None


if __name__ == "__main__":
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "RcFSX2nfdWmuiF02bjuO1gUdSEMnVF8z"
    INPUT_CSV = "data\\sector_marketcap_20251022_225409.csv"
    
    print("\n⏱️  MARKET REGIME ANALYSIS")
    print("    This will test your strategy across different market periods")
    print("    Helps validate robustness and identify best use cases")
    print("    Expected time: 10-15 minutes")
    print("☕ Good time for a coffee break!\n")
    
    # Run analysis
    results = run_regime_analysis(API_KEY, ACCESS_TOKEN, INPUT_CSV)
    
    if results is not None:
        print("\n✅ Market regime analysis complete!")
        print("   Now you know which configuration works best in which market!")
    else:
        print("\n❌ Analysis failed")

