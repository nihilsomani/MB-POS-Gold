import os
import csv
import time
import logging
import datetime
import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from typing import Dict, List, Tuple, Optional
import scipy.signal as signal
from scipy.stats import linregress, entropy, kurtosis, skew
from scipy.stats import zscore  # For outlier detection

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("stage2_scanner.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class Stage2MomentumScanner:
    """
    Scanner implementing the "Stage 2 Momentum Breakout with VCP Confirmation" strategy
    using Kite Connect API with enhanced stage detection, volume analysis, and RS metrics.
    Uses NIFTY 500 as the benchmark index for all RS calculations.
    """

    def __init__(self, api_key: str, access_token: str):
        """
        Initialize the scanner with Kite Connect credentials.

        Args:
            api_key: The API key for Kite Connect
            access_token: The access token for Kite Connect
        """
        self.api_key = api_key
        self.access_token = access_token
        self.kite = KiteConnect(api_key=self.api_key)
        try:
            self.kite.set_access_token(self.access_token)
        except Exception as e:
            logger.error(f"Failed to set access token: {e}")
            raise

        # Cache for instruments to minimize API calls
        self.instruments_cache = {}
        self.token_symbol_map = {}
        self.exchange = "NSE"

        # Market benchmark for relative strength comparison
        self.benchmark_index = "NIFTY 500"
        self.benchmark_data = None

        # Store RS scores for Mansfield ranking
        self.all_rs_scores = []

        # Parameters for the strategy
        self.params = {
            "min_liquidity_volume": 100000,
            "ma_periods": [50, 150, 200],
            "rs_lookback_period": 55,
            "min_rs_percentile": 70,
            "vcp_max_pullbacks": 6,
            "volume_breakout_threshold": 1.5,
            "volume_avg_period": 50,
            # New parameters for transition detection
            "ma_alignment_days_threshold": 14,
            "ma_alignment_confidence_threshold": 0.6,
            # Adaptive parameters optimized for 2.5 years of data
            "rs_lookback_short": 30,      # Increased from 20 for better short-term analysis
            "rs_lookback_medium": 90,     # Increased from 55 for better medium-term analysis
            "rs_lookback_long": 500,      # Increased from 200 to utilize full 2.5 years
            "volume_avg_period_short": 30, # Increased from 20
            "volume_avg_period_long": 90,  # Increased from 50
            "atr_lookback": 21,           # Increased from 14 for more stable ATR
            "atr_trend_lookback": 30,     # Increased from 20
            "pullback_volume_reduction": 0.7,
            "pullback_depth_reduction_pct": 0.8,
            "breakout_volume_threshold_strong": 2.0,
            "breakout_price_threshold_strong": 1.02,
            "breakout_volume_threshold_moderate": 1.5,
            "breakout_price_threshold_moderate": 1.01,
            # Enhanced follow-through parameters
            "follow_through_days": 10,     # Increased from 5 for better confirmation
            "follow_through_volume_threshold": 1.2,
            "follow_through_short_days": 3,  # Short-term follow-through (3 days)
            "follow_through_medium_days": 7, # Medium-term follow-through (7 days)
            "follow_through_long_days": 15,  # Long-term follow-through (15 days)
            "follow_through_price_threshold": 0.98,  # Allow 2% pullback during follow-through
            "follow_through_volume_consistency": 0.7  # 70% of days should have above-average volume
        }

        # Rate limiting for API calls
        self.last_api_call = 0
        self.api_call_delay = 0.25  # 250ms

    def _rate_limit(self) -> None:
        """Implement rate limiting to avoid hitting API limits."""
        elapsed = time.time() - self.last_api_call
        if elapsed < self.api_call_delay:
            time.sleep(self.api_call_delay - elapsed)
        self.last_api_call = time.time()

    def load_instruments(self) -> None:
        """Load all NSE instruments and cache them."""
        logger.info("Loading instruments...")
        self._rate_limit()
        try:
            all_instruments = self.kite.instruments(exchange=self.exchange)
        except Exception as e:
            logger.error(f"Failed to load instruments: {e}")
            raise

        for instrument in all_instruments:
            symbol = instrument["tradingsymbol"]
            token = instrument["instrument_token"]
            self.instruments_cache[symbol] = instrument
            self.token_symbol_map[token] = symbol

        logger.info(f"Loaded {len(self.instruments_cache)} instruments")

    def load_benchmark_data(self, days: int = 700) -> None:
        """
        Load NIFTY 500 benchmark data for relative strength calculations.

        Args:
            days: Number of historical days to fetch (default: 900 for 2.5 years)
        """
        logger.info(f"Loading benchmark data for {self.benchmark_index}...")

        benchmark_token = None
        for symbol, instrument in self.instruments_cache.items():
            if self.benchmark_index in symbol:
                benchmark_token = instrument["instrument_token"]
                break

        if not benchmark_token:
            raise ValueError(f"Benchmark index {self.benchmark_index} not found")

        to_date = datetime.datetime.now().date()
        from_date = to_date - datetime.timedelta(days=days)

        self._rate_limit()
        try:
            benchmark_historical = self.kite.historical_data(
                benchmark_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
        except Exception as e:
            logger.error(f"Failed to load benchmark data: {e}")
            raise

        self.benchmark_data = pd.DataFrame(benchmark_historical)
        if self.benchmark_data.empty:
            raise ValueError("No benchmark data retrieved")
        logger.info(f"Loaded {len(self.benchmark_data)} days of benchmark data")

    def get_historical_data(self, symbol: str, days: int = 900) -> Optional[pd.DataFrame]:
        """
        Get historical data for a symbol.

        Args:
            symbol: The trading symbol
            days: Number of historical days to fetch (default: 900 for 2.5 years)

        Returns:
            DataFrame with historical OHLCV data or None if failed
        """
        if symbol not in self.instruments_cache:
            logger.warning(f"Symbol {symbol} not found in instruments cache")
            return None

        instrument_token = self.instruments_cache[symbol]["instrument_token"]

        to_date = datetime.datetime.now().date()
        from_date = to_date - datetime.timedelta(days=days)

        try:
            self._rate_limit()
            historical_data = self.kite.historical_data(
                instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            if not historical_data:
                logger.warning(f"No historical data for {symbol}")
                return None

            df = pd.DataFrame(historical_data)
            df['date'] = pd.to_datetime(df['date'])
            return df
        except Exception as e:
            logger.error(f"Error fetching historical data for {symbol}: {e}")
            return None

    def calculate_moving_averages(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate moving averages for the given dataframe.

        Args:
            df: DataFrame with price data

        Returns:
            DataFrame with moving averages added
        """
        for period in self.params["ma_periods"]:
            df[f'sma_{period}'] = df['close'].rolling(window=period).mean()
            df[f'vwma_{period}'] = (df['close'] * df['volume']).rolling(window=period).sum() / df['volume'].rolling(window=period).sum()
        return df

    def calculate_rsi(self, df: pd.DataFrame, period: int = 14) -> float:
        """
        Calculate Relative Strength Index (RSI).

        Args:
            df: DataFrame with close prices
            period: Lookback period

        Returns:
            Latest RSI value
        """
        try:
            delta = df['close'].diff()
            gain = delta.where(delta > 0, 0).rolling(window=period).mean()
            loss = -delta.where(delta < 0, 0).rolling(window=period).mean()
            rs = gain / loss if loss.mean() != 0 else float('inf')
            rsi = 100 - (100 / (1 + rs))
            return rsi.iloc[-1] if not rsi.empty else 50.0
        except Exception as e:
            logger.warning(f"Error calculating RSI: {e}")
            return 50.0

    def calculate_macd(self, df: pd.DataFrame) -> float:
        """
        Calculate MACD signal line difference.

        Args:
            df: DataFrame with close prices

        Returns:
            Latest MACD signal difference
        """
        try:
            ema_12 = df['close'].ewm(span=12, adjust=False).mean()
            ema_26 = df['close'].ewm(span=26, adjust=False).mean()
            macd = ema_12 - ema_26
            signal_line = macd.ewm(span=9, adjust=False).mean()
            return (macd - signal_line).iloc[-1]
        except Exception as e:
            logger.warning(f"Error calculating MACD: {e}")
            return 0.0

    def calculate_momentum_acceleration(self, df: pd.DataFrame) -> float:
        """Calculate the acceleration of momentum using rate of change of ROC."""
        try:
            # 10-day Rate of Change
            roc_10 = (df['close'] / df['close'].shift(10) - 1) * 100

            # Rate of change of the ROC (acceleration)
            roc_acceleration = roc_10.diff(5).iloc[-1]

            # Normalize acceleration
            normalized_accel = np.tanh(roc_acceleration / 5)

            return normalized_accel
        except Exception as e:
            logger.warning(f"Error calculating momentum acceleration: {e}")
            return 0.0

    def calculate_relative_strength(self, df: pd.DataFrame) -> Dict:
        """
        Calculate relative strength against NIFTY 500 with multi-timeframe analysis.

        Args:
            df: DataFrame with price data

        Returns:
            Dictionary with RS metrics
        """
        if self.benchmark_data is None:
            logger.warning("Benchmark data not loaded. Loading now...")
            self.load_benchmark_data()

        start_date = max(df['date'].min(), self.benchmark_data['date'].min())
        stock_data = df[df['date'] >= start_date].copy()
        benchmark_data = self.benchmark_data[self.benchmark_data['date'] >= start_date].copy()

        # Multi-timeframe RS
        rs_scores = {}
        for period, name in [
            (self.params["rs_lookback_short"], "short"),
            (self.params["rs_lookback_medium"], "medium"),
            (self.params["rs_lookback_long"], "long")
        ]:
            lookback = min(period, len(stock_data) - 1)
            if lookback < 10:
                rs_scores[name] = 0.0
                continue

            stock_change = (stock_data['close'].iloc[-1] / stock_data['close'].iloc[-lookback - 1]) - 1
            benchmark_change = (benchmark_data['close'].iloc[-1] / benchmark_data['close'].iloc[-lookback - 1]) - 1
            rs_scores[name] = (stock_change + 1) / (benchmark_change + 1) if benchmark_change != -1 else float('inf')

        # Momentum oscillators
        rsi = self.calculate_rsi(stock_data)
        macd_signal = self.calculate_macd(stock_data)

        # Composite RS score
        composite_rs = (
            0.5 * rs_scores.get("medium", 0.0) +
            0.3 * rs_scores.get("short", 0.0) +
            0.2 * rs_scores.get("long", 0.0)
        ) if rs_scores.get("medium", 0.0) != float('inf') else 0.0

        return {
            "composite_rs": composite_rs,
            "short_term_rs": rs_scores.get("short", 0.0),
            "medium_term_rs": rs_scores.get("medium", 0.0),
            "long_term_rs": rs_scores.get("long", 0.0),
            "rsi": rsi,
            "macd_signal": macd_signal,
            "percentile": 0.0
        }

    def predict_ma_alignment(self, df: pd.DataFrame) -> Dict:
        """Predict when moving averages will align based on recent trends."""
        try:
            recent_data = df.tail(30).copy()

            # Calculate daily change rates for moving averages
            sma_50_change = recent_data['sma_50'].diff().mean()
            sma_150_change = recent_data['sma_150'].diff().mean()

            # Current values
            current_sma_50 = df['sma_50'].iloc[-1]
            current_sma_150 = df['sma_150'].iloc[-1]

            # If SMA50 is rising faster than SMA150
            if sma_50_change > sma_150_change:
                # Calculate days until crossover
                gap = current_sma_150 - current_sma_50
                daily_convergence = sma_50_change - sma_150_change

                if daily_convergence > 0:
                    days_to_alignment = int(gap / daily_convergence)

                    return {
                        "alignment_prediction": True,
                        "days_to_alignment": days_to_alignment,
                        "confidence": min(1.0, 30 / max(days_to_alignment, 1))  # Higher confidence for closer dates
                    }

            return {"alignment_prediction": False, "days_to_alignment": float('inf'), "confidence": 0.0}
        except Exception as e:
            logger.warning(f"Error predicting MA alignment: {e}")
            return {"alignment_prediction": False, "days_to_alignment": float('inf'), "confidence": 0.0}

    def identify_stage(self, df: pd.DataFrame) -> Dict:
        """
        Identify stage using a weighted scoring system with transition detection,
        including volume and volatility analysis.

        Args:
            df: DataFrame with price and volume data

        Returns:
            Dictionary with stage, stage scores, and transition confidence
        """
        if len(df) < max(self.params["ma_periods"]) + 30:
            return {"stage": "Insufficient data", "scores": {}, "confidence": 0.0}

        latest = df.iloc[-1]
        price = latest['close']
        sma_20 = df['close'].rolling(window=20).mean().iloc[-1]
        sma_50 = latest['sma_50']
        sma_150 = latest['sma_150']
        sma_200 = latest['sma_200']

        periods = 30
        x = np.arange(periods)
        try:
            sma_50_slope, _, _, _, _ = linregress(x, df['sma_50'].iloc[-periods:])
            sma_150_slope, _, _, _, _ = linregress(x, df['sma_150'].iloc[-periods:])
            sma_200_slope, _, _, _, _ = linregress(x, df['sma_200'].iloc[-periods:])
        except Exception as e:
            logger.warning(f"Error calculating slopes: {e}")
            return {"stage": "Indeterminate", "scores": {}, "confidence": 0.0}

        weights = {
            "price_vs_sma20": 0.2,
            "price_vs_sma200": 0.3,
            "ma_alignment": 0.2,
            "slope_trend": 0.15,
            "volume_analysis": 0.1,
            "volatility": 0.05
        }

        stage_scores = {
            "Stage 1": 0.0,
            "Stage 2": 0.0,
            "Stage 3": 0.0,
            "Stage 4": 0.0,
            "Stage 1-2 Transition": 0.0  # New transition stage
        }

        # Price vs SMA20 scoring
        price_sma20_ratio = price / sma_20 if sma_20 != 0 else 1.0
        stage_scores["Stage 1"] += weights["price_vs_sma20"] * (1.0 if 0.95 <= price_sma20_ratio <= 1.05 else 0.2)
        stage_scores["Stage 2"] += weights["price_vs_sma20"] * (1.0 if price_sma20_ratio > 1.05 else 0.2)
        stage_scores["Stage 3"] += weights["price_vs_sma20"] * (1.0 if 0.95 <= price_sma20_ratio <= 1.05 else 0.3)
        stage_scores["Stage 4"] += weights["price_vs_sma20"] * (1.0 if price_sma20_ratio < 0.95 else 0.2)

        # Price vs SMA200 scoring
        price_sma200_ratio = price / sma_200 if sma_200 != 0 else 1.0
        stage_scores["Stage 1"] += weights["price_vs_sma200"] * (1.0 if price_sma200_ratio <= 1.0 else 0.2)
        stage_scores["Stage 2"] += weights["price_vs_sma200"] * (1.0 if price_sma200_ratio > 1.0 else 0.2)
        stage_scores["Stage 3"] += weights["price_vs_sma200"] * (1.0 if price_sma200_ratio >= 1.0 else 0.3)
        stage_scores["Stage 4"] += weights["price_vs_sma200"] * (1.0 if price_sma200_ratio < 1.0 else 0.2)

        # MA alignment scoring
        ma_aligned = sma_50 > sma_150 > sma_200
        stage_scores["Stage 2"] += weights["ma_alignment"] * (1.0 if ma_aligned else 0.2)
        stage_scores["Stage 1"] += weights["ma_alignment"] * (0.5 if not ma_aligned else 0.3)
        stage_scores["Stage 3"] += weights["ma_alignment"] * (0.7 if not ma_aligned else 0.3)
        stage_scores["Stage 4"] += weights["ma_alignment"] * (0.5 if not ma_aligned else 0.3)

        # Slope trend scoring
        slope_score = (sma_50_slope + sma_150_slope + sma_200_slope) / 3.0
        slope_normalized = np.tanh(slope_score * 1000)
        stage_scores["Stage 2"] += weights["slope_trend"] * max(0.0, slope_normalized)
        stage_scores["Stage 4"] += weights["slope_trend"] * max(0.0, -slope_normalized)
        stage_scores["Stage 1"] += weights["slope_trend"] * (0.5 if abs(slope_normalized) < 0.2 else 0.3)
        stage_scores["Stage 3"] += weights["slope_trend"] * (0.5 if abs(slope_normalized) < 0.2 else 0.3)

        # Transition detection for Stage 1 to Stage 2
        sma_50_to_150_gap = (sma_50 / sma_150 - 1) * 100  # Percentage gap
        price_to_sma50_gap = (price / sma_50 - 1) * 100

        stage_1_to_2_transition = (
            price > sma_50 > sma_150 * 0.985 and  # SMA50 within 1.5% of crossing SMA150
            price_to_sma50_gap > 5 and  # Price accelerating above SMA50
            sma_50_slope > 0 and  # SMA50 trending up
            price > sma_200  # Price above SMA200
        )

        if stage_1_to_2_transition:
            stage_scores["Stage 1-2 Transition"] = (
                weights["price_vs_sma20"] * (1.0 if price_sma20_ratio > 1.05 else 0.5) +
                weights["price_vs_sma200"] * (1.0 if price_sma20_ratio > 1.0 else 0.5) +
                weights["ma_alignment"] * (1.0 - min(abs(sma_50_to_150_gap) / 1.5, 1.0)) +
                weights["slope_trend"] * max(0.0, slope_normalized)
            )

        # Enhance Stage 2 scoring with forward-looking metrics
        if price > sma_50 and sma_50_slope > 0:
            # Calculate distance to proper alignment
            alignment_score = 1.0 - min(abs((sma_50 / sma_150) - 1) * 10, 1.0)

            # Adjust Stage 2 score
            stage_scores["Stage 2"] += weights["ma_alignment"] * alignment_score

            # Reduce Stage 3 score if momentum is accelerating
            momentum_accel = self.calculate_momentum_acceleration(df)
            if momentum_accel > 0.3:
                stage_scores["Stage 3"] *= (1.0 - min(momentum_accel, 0.5))

        # --- NEW VOLUME AND VOLATILITY ANALYSIS ---
        volume_score = self._analyze_volume(df)
        stage_scores["Stage 3"] += weights["volume_analysis"] * max(0.0, volume_score)
        stage_scores["Stage 4"] += weights["volume_analysis"] * max(0.0, -volume_score)

        volatility_score = self._analyze_volatility(df)
        stage_scores["Stage 3"] += weights["volatility"] * volatility_score
        stage_scores["Stage 4"] += weights["volatility"] * volatility_score  # Volatility is high in both

        # --- END NEW ANALYSIS ---

        # Normalize scores
        total_score = sum(stage_scores.values())
        if total_score > 0:
            for stage in stage_scores:
                stage_scores[stage] /= total_score

        primary_stage = max(stage_scores, key=stage_scores.get)

        # Calculate confidence
        score_array = np.array(list(stage_scores.values()))
        confidence = 1.0 - entropy(score_array) / np.log(len(stage_scores)) if total_score > 0 else 0.0

        # Adjust confidence for transitions
        if stage_1_to_2_transition and primary_stage == "Stage 1-2 Transition":
            transition_confidence = 1.0 - min(abs(sma_50_to_150_gap) / 1.5, 1.0)
            confidence = max(confidence, transition_confidence)

        return {
            "stage": primary_stage,
            "scores": stage_scores,
            "confidence": confidence
        }

    def _analyze_volume(self, df: pd.DataFrame) -> float:
        """
        Analyze volume patterns to help identify Stage 3 and Stage 4.

        Args:
            df: DataFrame with price and volume data

        Returns:
            A score indicating volume characteristics (positive for Stage 3, negative for Stage 4)
        """
        volume_score = 0.0
        volume = df['volume']
        close_price = df['close']
        volume_ma = volume.rolling(window=20).mean()

        # Volume spikes on down days (Stage 3/4)
        down_days = close_price < close_price.shift(1)
        volume_spikes_down = (volume > volume_ma * 1.5) & down_days
        volume_score -= volume_spikes_down.sum() / len(volume)  # Negative contribution

        # Decreasing volume on up days (Stage 3)
        up_days = close_price > close_price.shift(1)
        decreasing_up_volume = (volume.shift(1) > volume) & up_days
        volume_score += decreasing_up_volume.sum() / len(volume)

        # Overall volume trend
        volume_trend = volume.rolling(window=10).mean().diff().mean()
        volume_score -= np.tanh(volume_trend * 10)  # Negative for downtrend

        return volume_score

    def _analyze_volatility(self, df: pd.DataFrame) -> float:
        """
        Analyze volatility to help identify Stage 3 and Stage 4.

        Args:
            df: DataFrame with price data

        Returns:
            A score indicating volatility characteristics (positive for Stage 3/4)
        """

        atr = self._calculate_atr(df)
        atr_change = atr.diff().mean()
        volatility_score = np.tanh(atr_change * 10)  # Positive for increasing volatility

        # Additional volatility measures (optional)
        # price_range_std = (df['high'] - df['low']).rolling(window=20).std().mean()
        # volatility_score += price_range_std / df['close'].mean()

        return volatility_score

    def _calculate_atr(self, df: pd.DataFrame, period: int = 14) -> pd.Series:
        """
        Calculate Average True Range (ATR).

        Args:
            df: DataFrame with high, low, close prices
            period: Lookback period for ATR

        Returns:
            Series of ATR values
        """
        high_low = df['high'] - df['low']
        high_close_prev = np.abs(df['high'] - df['close'].shift(1))
        low_close_prev = np.abs(df['low'] - df['close'].shift(1))
        true_range = pd.concat([high_low, high_close_prev, low_close_prev], axis=1).max(axis=1)
        atr = true_range.rolling(period).mean()
        return atr
    
    def calculate_obv(self, df: pd.DataFrame) -> pd.Series:
        """
        Calculate On-Balance Volume (OBV).

        Args:
            df: DataFrame with close and volume data

        Returns:
            Series with OBV values
        """
        try:
            direction = np.sign(df['close'].diff())
            obv = (direction * df['volume']).cumsum().fillna(0)
            return obv
        except Exception as e:
            logger.warning(f"Error calculating OBV: {e}")
            return pd.Series(np.zeros(len(df)), index=df.index)

    def calculate_vwap(self, df: pd.DataFrame) -> pd.Series:
        """
        Calculate Volume-Weighted Average Price (VWAP).

        Args:
            df: DataFrame with high, low, close, and volume data

        Returns:
            Series with VWAP values
        """
        try:
            typical_price = (df['high'] + df['low'] + df['close']) / 3
            vwap = (typical_price * df['volume']).cumsum() / df['volume'].cumsum()
            return vwap
        except Exception as e:
            logger.warning(f"Error calculating VWAP: {e}")
            return df['close']

    def calculate_volume_profile(self, df: pd.DataFrame, bins: int = 50) -> Dict:
        """
        Calculate volume profile to identify support/resistance levels.

        Args:
            df: DataFrame with close and volume data
            bins: Number of price bins

        Returns:
            Dictionary with price levels and volume
        """
        try:
            price_range = df['close'].max() - df['close'].min()
            if price_range == 0:
                return {"levels": [], "volumes": []}

            hist, bin_edges = np.histogram(df['close'], bins=bins, weights=df['volume'])
            return {
                "levels": (bin_edges[:-1] + bin_edges[1:]) / 2,
                "volumes": hist
            }
        except Exception as e:
            logger.warning(f"Error calculating volume profile: {e}")
            return {"levels": [], "volumes": []}

    def detect_vcp(self, df: pd.DataFrame) -> Dict:
        """
        Enhanced VCP detection with OBV and volume profile.

        Args:
            df: DataFrame with price and volume data

        Returns:
            Dictionary with VCP analysis results
        """
        if len(df) < 150:
            return {"vcp_detected": False, "reason": "Insufficient data"}

        analysis_window = df.iloc[-150:].copy()  # Increased from 100 to 150 days for better pattern recognition

        obv = self.calculate_obv(analysis_window)
        analysis_window['obv'] = obv

        high_low = analysis_window['high'] - analysis_window['low']
        high_close = np.abs(analysis_window['high'] - analysis_window['close'].shift(1))
        low_close = np.abs(analysis_window['low'] - analysis_window['close'].shift(1))
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        atr_14 = true_range.rolling(self.params["atr_lookback"]).mean()
        atr_14_latest = atr_14.iloc[-1] if not atr_14.empty else analysis_window['close'].std()

        try:
            highs_idx = signal.find_peaks(analysis_window['high'], distance=5, prominence=atr_14_latest * 0.5)[0]
            lows_idx = signal.find_peaks(-analysis_window['low'], distance=5, prominence=atr_14_latest * 0.5)[0]
        except Exception as e:
            logger.warning(f"Error detecting peaks/troughs: {e}")
            return {"vcp_detected": False, "reason": "Peak detection failed"}

        pullbacks = []
        high_prices = analysis_window['high'].iloc[highs_idx].values
        high_indices = highs_idx
        low_prices = analysis_window['low'].iloc[lows_idx].values
        low_indices = lows_idx

        i = 0
        for h_idx, h_price in zip(high_indices, high_prices):
            next_lows = [(l_idx, l_price) for l_idx, l_price in zip(low_indices, low_prices)
                          if l_idx > h_idx]
            if next_lows and i < len(high_indices) - 1:
                l_idx, l_price = next_lows[0]
                pullback_pct = (h_price - l_price) / h_price * 100
                volume_during = analysis_window['volume'].iloc[h_idx:l_idx + 1].mean()
                obv_during = analysis_window['obv'].iloc[l_idx] - analysis_window['obv'].iloc[h_idx]
                atr_normalized_range = (h_price - l_price) / atr_14_latest if atr_14_latest != 0 else float('inf')

                pullbacks.append({
                    'high_idx': h_idx,
                    'low_idx': l_idx,
                    'high_price': h_price,
                    'low_price': l_price,
                    'pullback_pct': pullback_pct,
                    'avg_volume': volume_during,
                    'obv_change': obv_during,
                    'atr_normalized_range': atr_normalized_range
                })
                i += 1

        vol_profile = self.calculate_volume_profile(analysis_window)
        key_levels = []
        if vol_profile["volumes"].size > 0:
            top_levels_idx = np.argsort(vol_profile["volumes"])[-3:]
            key_levels = vol_profile["levels"][top_levels_idx].tolist()

        vcp_characteristics = {
            'vcp_detected': False,
            'pullbacks': len(pullbacks),
            'decreasing_depth': False,
            'volume_dry_up': False,
            'obv_dry_up': False,
            'tight_contraction': False,
            'contraction_count': len(pullbacks),
            'key_levels': key_levels,
            'volume_profile': vol_profile,
            'atr_trend_decreasing': False,
            'atr_reduction_percentage': 0.0
        }

        if 2 <= len(pullbacks) <= self.params["vcp_max_pullbacks"]:
            depths = [p['pullback_pct'] for p in pullbacks]
            volumes = [p['avg_volume'] for p in pullbacks]
            obv_changes = [p['obv_change'] for p in pullbacks]
            atr_ranges = [p['atr_normalized_range'] for p in pullbacks]

            expected_depths = [25, 15, 8][:len(pullbacks)]
            vcp_characteristics['decreasing_depth'] = (
                len(depths) > 1 and
                all(depths[i] <= depths[i - 1] * self.params["pullback_depth_reduction_pct"] for i in range(1, len(depths))) and
                all(depth <= expected for depth, expected in zip(depths, expected_depths))
            )

            avg_volume = analysis_window['volume'].mean()
            if len(volumes) >= 2:
                vcp_characteristics['volume_dry_up'] = (
                    volumes[-1] < volumes[-2] * self.params["pullback_volume_reduction"] and
                    volumes[-1] < avg_volume * 0.5
                )
                vcp_characteristics['obv_dry_up'] = (
                    obv_changes[-1] < obv_changes[-2] * 0.5 if len(obv_changes) >= 2 else False
                )

            if len(atr_ranges) >= 2:
                vcp_characteristics['tight_contraction'] = (
                    atr_ranges[-1] < 1.0 and
                    atr_ranges[-1] < atr_ranges[-2] * 0.6
                )

            # Check ATR Trend
            atr_trend = atr_14.tail(self.params["atr_trend_lookback"])
            atr_trend_decreasing = all(atr_trend.iloc[i] < atr_trend.iloc[i - 1] for i in range(1, len(atr_trend)))
            vcp_characteristics['atr_trend_decreasing'] = atr_trend_decreasing

            if atr_trend_decreasing and len(atr_trend) > 0:
                vcp_characteristics['atr_reduction_percentage'] = (atr_trend.iloc[0] - atr_trend.iloc[-1]) / atr_trend.iloc[0] * 100

            vcp_characteristics['vcp_detected'] = (
                vcp_characteristics['decreasing_depth'] and
                vcp_characteristics['volume_dry_up'] and
                vcp_characteristics['obv_dry_up'] and
                vcp_characteristics['tight_contraction'] and
                vcp_characteristics['atr_trend_decreasing']
            )

        return vcp_characteristics

    def detect_breakout(self, df: pd.DataFrame, vcp_data: Dict) -> Dict:
        """
        Enhanced breakout detection with VWAP and volume profile.

        Args:
            df: DataFrame with price and volume data
            vcp_data: VCP analysis results

        Returns:
            Dictionary with breakout analysis results
        """
        if len(df) < self.params["volume_avg_period"] + 5:
            return {"breakout_detected": False, "reason": "Insufficient data"}

        recent_data = df.iloc[-self.params["volume_avg_period"] - 5:].copy()
        avg_volume = recent_data['volume'].iloc[:-5].mean()

        recent_data['vwap'] = self.calculate_vwap(recent_data)

        breakout_data = {
            'breakout_detected': False,
            'breakout_day': None,
            'volume_surge': False,
            'price_breakout': False,
            'vwap_breakout': False,
            'breakout_strength': 0.0,
            'volume_profile_confluence': False,  # Added
            'breakout_strength_category': 'None',  # Added
            'follow_through_confirmed': False  # Added
        }

        if vcp_data['vcp_detected'] and vcp_data['pullbacks'] >= 2:
            pullback_highs = [p['high_price'] for p in vcp_data.get('pullbacks', [])]
            resistance_level = max(pullback_highs) * 0.98 if pullback_highs else recent_data['high'].iloc[:-5].max()
        else:
            resistance_level = max(vcp_data.get('key_levels', [recent_data['high'].iloc[:-5].max()]))

        for i in range(1, min(6, len(recent_data))):
            idx = -i
            if recent_data['close'].iloc[idx] > resistance_level:
                current_volume = recent_data['volume'].iloc[idx]
                volume_ratio = current_volume / avg_volume if avg_volume != 0 else 0

                if volume_ratio > self.params["volume_breakout_threshold"]:
                    breakout_data['breakout_detected'] = True
                    breakout_data['breakout_day'] = (
                        recent_data['date'].iloc[idx].strftime('%Y-%m-%d')
                        if pd.api.types.is_datetime64_any_dtype(recent_data['date'])
                        else str(recent_data['date'].iloc[idx])
                    )
                    breakout_data['volume_surge'] = True
                    breakout_data['price_breakout'] = True
                    breakout_data['vwap_breakout'] = recent_data['close'].iloc[idx] > recent_data['vwap'].iloc[idx]

                    breakout_data['breakout_strength'] = volume_ratio

                    # Check for Volume Profile Confluence
                    for level in vcp_data.get('key_levels', []):
                        if abs(recent_data['close'].iloc[idx] - level) / level < 0.01:  # Within 1% of the level
                            breakout_data['volume_profile_confluence'] = True
                            break

                    # Classify Breakout Strength
                    if volume_ratio > self.params["breakout_volume_threshold_strong"] and recent_data['close'].iloc[idx] / resistance_level > self.params["breakout_price_threshold_strong"]:
                        breakout_data['breakout_strength_category'] = 'Strong'
                    elif volume_ratio > self.params["breakout_volume_threshold_moderate"] and recent_data['close'].iloc[idx] / resistance_level > self.params["breakout_price_threshold_moderate"]:
                        breakout_data['breakout_strength_category'] = 'Moderate'
                    else:
                        breakout_data['breakout_strength_category'] = 'Weak'

                    break

        # Enhanced Follow-Through Detection
        if breakout_data['breakout_detected']:
            breakout_day_index = recent_data.index[recent_data['date'].astype(str) == breakout_data['breakout_day']].tolist()
            if breakout_day_index:
                breakout_day_index = breakout_day_index[0]
                breakout_price = recent_data['close'].iloc[breakout_day_index]
                
                # Multi-timeframe follow-through analysis
                follow_through_results = {}
                
                for timeframe, days in [
                    ("short", self.params["follow_through_short_days"]),
                    ("medium", self.params["follow_through_medium_days"]),
                    ("long", self.params["follow_through_long_days"])
                ]:
                    end_idx = min(breakout_day_index + days, recent_data.index[-1])
                    follow_through_data = recent_data.loc[breakout_day_index + 1:end_idx]
                    
                    if not follow_through_data.empty:
                        # Volume analysis
                        follow_through_volume = follow_through_data['volume'].mean()
                        volume_above_avg = (follow_through_data['volume'] > avg_volume).sum()
                        volume_consistency = volume_above_avg / len(follow_through_data)
                        
                        # Price analysis
                        min_price = follow_through_data['close'].min()
                        max_price = follow_through_data['close'].max()
                        final_price = follow_through_data['close'].iloc[-1]
                        
                        # Price should not fall below breakout price by more than threshold
                        price_holds = min_price >= breakout_price * self.params["follow_through_price_threshold"]
                        
                        # Final price should be higher than breakout
                        price_advances = final_price > breakout_price
                        
                        # Volume should be consistently above average
                        volume_confirms = volume_consistency >= self.params["follow_through_volume_consistency"]
                        
                        follow_through_results[timeframe] = {
                            "confirmed": price_holds and price_advances and volume_confirms,
                            "volume_ratio": follow_through_volume / avg_volume if avg_volume > 0 else 0,
                            "volume_consistency": volume_consistency,
                            "price_holds": price_holds,
                            "price_advances": price_advances,
                            "min_price": min_price,
                            "max_price": max_price,
                            "final_price": final_price,
                            "price_range_pct": ((max_price - min_price) / breakout_price) * 100
                        }
                
                # Overall follow-through confirmation
                # Require at least medium-term confirmation for strong signals
                short_confirmed = follow_through_results.get("short", {}).get("confirmed", False)
                medium_confirmed = follow_through_results.get("medium", {}).get("confirmed", False)
                long_confirmed = follow_through_results.get("long", {}).get("confirmed", False)
                
                # Enhanced confirmation logic
                if long_confirmed:
                    follow_through_strength = "Strong"
                    follow_through_confirmed = True
                elif medium_confirmed:
                    follow_through_strength = "Moderate"
                    follow_through_confirmed = True
                elif short_confirmed:
                    follow_through_strength = "Weak"
                    follow_through_confirmed = True
                else:
                    follow_through_strength = "None"
                    follow_through_confirmed = False
                
                breakout_data.update({
                    'follow_through_confirmed': follow_through_confirmed,
                    'follow_through_strength': follow_through_strength,
                    'follow_through_analysis': follow_through_results
                })

        return breakout_data

    def analyze_stock(self, symbol: str) -> Dict:
        """
        Perform a complete analysis of a stock with transition enhancements.

        Args:
            symbol: The trading symbol

        Returns:
            Dictionary with analysis results
        """
        logger.info(f"Analyzing {symbol}...")

        df = self.get_historical_data(symbol)
        if df is None or len(df) < max(self.params["ma_periods"]) + 30:
            return {
                "symbol": symbol,
                "analysis_complete": False,
                "reason": "Insufficient historical data"
            }

        df = self.calculate_moving_averages(df)

        rs_data = self.calculate_relative_strength(df)

        stage_data = self.identify_stage(df)

        vcp_data = self.detect_vcp(df)

        breakout_data = self.detect_breakout(df, vcp_data)

        alignment_prediction = self.predict_ma_alignment(df)

        momentum_accel = self.calculate_momentum_acceleration(df)

        avg_volume = df['volume'].tail(self.params["volume_avg_period_short"]).mean()
        meets_liquidity = avg_volume >= self.params["min_liquidity_volume"]

        # Calculate Kurtosis and Skewness
        returns = df['close'].pct_change().dropna()
        kurt = kurtosis(returns)
        skw = skew(returns)

        analysis_results = {
            "symbol": symbol,
            "analysis_complete": True,
            "timestamp": datetime.datetime.now().isoformat(),
            "current_price": df['close'].iloc[-1],
            "stage": stage_data["stage"],
            "stage_scores": stage_data["scores"],
            "stage_confidence": stage_data["confidence"],
            "moving_averages": {
                "sma_50": df['sma_50'].iloc[-1],
                "sma_150": df['sma_150'].iloc[-1],
                "sma_200": df['sma_200'].iloc[-1],
                "ma_alignment": df['sma_50'].iloc[-1] > df['sma_150'].iloc[-1] > df['sma_200'].iloc[-1],
                "vwma_50": df['vwma_50'].iloc[-1],
                "vwma_150": df['vwma_150'].iloc[-1],
                "vwma_200": df['vwma_200'].iloc[-1],
            },
            "relative_strength": {
                "rs_score": rs_data["composite_rs"],
                "rs_percentile": rs_data["percentile"],
                "meets_threshold": rs_data["percentile"] >= self.params["min_rs_percentile"],
                "short_term_rs": rs_data["short_term_rs"],
                "medium_term_rs": rs_data["medium_term_rs"],
                "long_term_rs": rs_data["long_term_rs"],
                "rsi": rs_data["rsi"],
                "macd_signal": rs_data["macd_signal"]
            },
            "vcp_analysis": vcp_data,
            "breakout_analysis": breakout_data,
            "volume_analysis": {
                "obv_dry_up": vcp_data.get("obv_dry_up", False),
                "vwap_breakout": breakout_data.get("vwap_breakout", False),
                "key_levels": vcp_data.get("key_levels", []),
                "volume_profile_confluence": breakout_data.get("volume_profile_confluence", False)
            },
            "liquidity": {
                "avg_volume": avg_volume,
                "meets_threshold": meets_liquidity
            },
            "strategy_match": False,
            "ma_alignment_prediction": alignment_prediction,
            "momentum_acceleration": momentum_accel,
            "watchlist_category": "NONE",
            "kurtosis": kurt,
            "skewness": skw
        }

        if analysis_results["analysis_complete"]:
            self.all_rs_scores.append((symbol, rs_data["composite_rs"]))

        return analysis_results

    def scan_from_csv(self, csv_file_path: str, output_file: str = "stage2_results.csv") -> List[Dict]:
        """
        Scan stocks from a CSV file and analyze them with enhanced transition logic.

        Args:
            csv_file_path: Path to CSV file with symbols
            output_file: Path to save results CSV

        Returns:
            List of analysis results
        """
        if not os.path.exists(csv_file_path):
            raise FileNotFoundError(f"CSV file not found: {csv_file_path}")

        symbols = []
        try:
            with open(csv_file_path, 'r') as csv_file:
                reader = csv.DictReader(csv_file)
                for row in reader:
                    if 'Symbol' in row:
                        symbols.append(row['Symbol'])
                    elif 'symbol' in row:
                        symbols.append(row['symbol'])
                    else:
                        logger.warning(f"No Symbol column found in row: {row}")
        except Exception as e:
            logger.error(f"Error reading CSV file: {e}")
            raise

        logger.info(f"Loaded {len(symbols)} symbols from CSV")

        if not self.instruments_cache:
            self.load_instruments()

        if self.benchmark_data is None:
            self.load_benchmark_data()

        results = []
        self.all_rs_scores = []

        for symbol in symbols:
            try:
                analysis = self.analyze_stock(symbol)
                results.append(analysis)

                if analysis.get("analysis_complete", False):
                    logger.info(f"{symbol}: Stage {analysis['stage']}, "
                                f"RS Score {analysis['relative_strength']['rs_score']:.2f}, "
                                f"VCP Detected: {analysis['vcp_analysis']['vcp_detected']}, "
                                f"Breakout: {analysis['breakout_analysis']['breakout_detected']}")
                else:
                    logger.warning(f"{symbol}: Analysis incomplete - {analysis.get('reason', 'Unknown reason')}")
            except Exception as e:
                logger.error(f"Error analyzing {symbol}: {e}")
                results.append({
                    "symbol": symbol,
                    "analysis_complete": False,
                    "reason": str(e)
                })

        # Calculate RS percentiles and assign signals
        rs_scores = [score for _, score in self.all_rs_scores if score != float('inf')]
        for result in results:
            if result.get("analysis_complete", False):
                rs_score = result["relative_strength"]["rs_score"]
                if rs_score != float('inf') and rs_scores:
                    percentile = sum(1 for x in rs_scores if x < rs_score) / len(rs_scores) * 100
                    result["relative_strength"]["rs_percentile"] = percentile
                    result["relative_strength"]["meets_threshold"] = percentile >= self.params["min_rs_percentile"]

                # Strategy match logic
                strategy_match = (
                    ("Stage 2" in result["stage"] or "Stage 1-2" in result["stage"]) and
                    result["moving_averages"]["ma_alignment"] and
                    result["relative_strength"]["meets_threshold"] and
                    (result["vcp_analysis"]["vcp_detected"] or result["breakout_analysis"]["breakout_detected"]) and
                    result["liquidity"]["meets_threshold"] and
                    result["relative_strength"]["rsi"] > 50.0 and
                    result["relative_strength"]["macd_signal"] > 0
                )
                result["strategy_match"] = strategy_match

                # Watchlist logic for potential breakouts
                alignment_prediction = result["ma_alignment_prediction"]
                if not strategy_match and alignment_prediction.get("alignment_prediction", False):
                    days_to_alignment = alignment_prediction.get("days_to_alignment", float('inf'))
                    alignment_confidence = alignment_prediction.get("confidence", 0)

                    if days_to_alignment <= self.params["ma_alignment_days_threshold"] and \
                            alignment_confidence > self.params["ma_alignment_confidence_threshold"]:
                        if result["breakout_analysis"]["breakout_detected"]:
                            result["watchlist_category"] = "IMMINENT ALIGNMENT"

                # Enhanced journey phase logic
                journey_phase = "Unknown"
                if "Stage 1" in result["stage"] and "Stage 1-2" not in result["stage"]:
                    if result["moving_averages"]["sma_50"] > result["moving_averages"]["sma_150"] * 0.985:
                        if result["breakout_analysis"]["breakout_detected"]:
                            journey_phase = "Stage 1 Breakout - Alignment Imminent"
                        else:
                            journey_phase = "Late Stage 1 - Watch for Alignment"
                    else:
                        journey_phase = "Base Building"
                elif "Stage 1-2" in result["stage"]:
                    if result["vcp_analysis"]["vcp_detected"] and not result["breakout_analysis"]["breakout_detected"]:
                        journey_phase = "VCP Formed, Awaiting Breakout"
                    elif result["breakout_analysis"]["breakout_detected"]:
                        journey_phase = "Early Breakout, Entering Stage 2"
                    else:
                        journey_phase = "Early Transition to Stage 2"
                elif "Stage 2" in result["stage"]:
                    if result["breakout_analysis"]["breakout_detected"]:
                        journey_phase = "Fresh Stage 2 Breakout"
                    else:
                        journey_phase = "Established Stage 2 Uptrend"
                elif "Stage 3" in result["stage"]:
                    if result["relative_strength"]["rsi"] > 75 and \
                            result["momentum_acceleration"] > 0.5:
                        journey_phase = "Strong Momentum in Late Stage 2 - Monitor Closely"
                    else:
                        journey_phase = "Topping Phase, Caution Advised"
                elif "Stage 4" in result["stage"]:
                    journey_phase = "Downtrend, Avoid"
                result["journey_phase"] = journey_phase

                # Signal logic
                signal = "NEUTRAL"
                if strategy_match:
                    if result["breakout_analysis"]["breakout_detected"] and "Stage 2" in result["stage"]:
                        signal = "STRONG BUY"
                    elif "Stage 1-2" in result["stage"] and result["vcp_analysis"]["vcp_detected"]:
                        signal = "BUY"
                    elif "Stage 2" in result["stage"]:
                        signal = "HOLD/ADD"
                elif result["watchlist_category"] == "IMMINENT ALIGNMENT":
                    signal = "POTENTIAL BUY - MA ALIGNMENT PENDING"
                elif "Stage 3" in result["stage"]:
                    signal = "REDUCE"
                elif "Stage 4" in result["stage"]:
                    signal = "AVOID/SELL"
                result["signal"] = signal

        self._save_results_to_csv(results, output_file)
        return results

    def _save_results_to_csv(self, results: List[Dict], output_file: str) -> None:
        """
        Save analysis results to a CSV file with new transition fields.

        Args:
            results: List of analysis results
            output_file: Path to save the CSV file
        """
        flattened_results = []
        for result in results:
            if not result.get("analysis_complete", False):
                flattened_results.append({
                    "Symbol": result.get("symbol", ""),
                    "Analysis Complete": False,
                    "Reason": result.get("reason", "")
                })
                continue

            flat_result = {
                "Symbol": result["symbol"],
                "Analysis Complete": True,
                "Timestamp": result["timestamp"],
                "Current Price": result["current_price"],
                "Stage": result["stage"],
                "Stage Confidence": result["stage_confidence"],
                "Stage 1 Score": result["stage_scores"].get("Stage 1", 0.0),
                "Stage 2 Score": result["stage_scores"].get("Stage 2", 0.0),
                "Stage 3 Score": result["stage_scores"].get("Stage 3", 0.0),
                "Stage 4 Score": result["stage_scores"].get("Stage 4", 0.0),
                "Stage 1-2 Transition Score": result["stage_scores"].get("Stage 1-2 Transition", 0.0),
                "Journey Phase": result["journey_phase"],
                "Signal": result["signal"],
                "Strategy Match": result["strategy_match"],
                "SMA 50": result["moving_averages"]["sma_50"],
                "SMA 150": result["moving_averages"]["sma_150"],
                "SMA 200": result["moving_averages"]["sma_200"],
                "MA Alignment": result["moving_averages"]["ma_alignment"],
                "VWMA 50": result["moving_averages"]["vwma_50"],
                "VWMA 150": result["moving_averages"]["vwma_150"],
                "VWMA 200": result["moving_averages"]["vwma_200"],
                "RS Score": result["relative_strength"]["rs_score"],
                "RS Percentile": result["relative_strength"]["rs_percentile"],
                "RS Meets Threshold": result["relative_strength"]["meets_threshold"],
                "Short Term RS": result["relative_strength"]["short_term_rs"],
                "Medium Term RS": result["relative_strength"]["medium_term_rs"],
                "Long Term RS": result["relative_strength"]["long_term_rs"],
                "RSI": result["relative_strength"]["rsi"],
                "MACD Signal": result["relative_strength"]["macd_signal"],
                "VCP Detected": result["vcp_analysis"]["vcp_detected"],
                "VCP Pullbacks": result["vcp_analysis"].get("pullbacks", 0),
                "VCP Decreasing Depth": result["vcp_analysis"].get("decreasing_depth", False),
                "VCP Decreasing Volume": result["vcp_analysis"].get("volume_dry_up", False),
                "VCP Tight Contraction": result["vcp_analysis"].get("tight_contraction", False),
                "VCP ATR Decreasing": result["vcp_analysis"].get("atr_trend_decreasing", False),
                "VCP ATR Reduction %": result["vcp_analysis"].get("atr_reduction_percentage", 0.0),
                "OBV Dry Up": result["volume_analysis"]["obv_dry_up"],
                "VWAP Breakout": result["volume_analysis"]["vwap_breakout"],
                "Key Levels": ",".join(map(str, result["volume_analysis"]["key_levels"])),
                "Volume Profile Confluence": result["volume_analysis"].get("volume_profile_confluence", False),
                "Breakout Detected": result["breakout_analysis"]["breakout_detected"],
                "Breakout Day": result["breakout_analysis"].get("breakout_day", ""),
                "Breakout Strength": result["breakout_analysis"].get("breakout_strength", 0.0),
                "Breakout Strength Category": result["breakout_analysis"].get("breakout_strength_category", "None"),
                "Follow Through Confirmed": result["breakout_analysis"].get("follow_through_confirmed", False),
                "Follow Through Strength": result["breakout_analysis"].get("follow_through_strength", "None"),
                "Follow Through Short Term": result["breakout_analysis"].get("follow_through_analysis", {}).get("short", {}).get("confirmed", False),
                "Follow Through Medium Term": result["breakout_analysis"].get("follow_through_analysis", {}).get("medium", {}).get("confirmed", False),
                "Follow Through Long Term": result["breakout_analysis"].get("follow_through_analysis", {}).get("long", {}).get("confirmed", False),
                "Follow Through Volume Consistency": result["breakout_analysis"].get("follow_through_analysis", {}).get("medium", {}).get("volume_consistency", 0.0),
                "Follow Through Price Range %": result["breakout_analysis"].get("follow_through_analysis", {}).get("medium", {}).get("price_range_pct", 0.0),
                "Avg Volume": result["liquidity"]["avg_volume"],
                "Meets Liquidity": result["liquidity"]["meets_threshold"],
                "MA Alignment Prediction": result["ma_alignment_prediction"]["alignment_prediction"],
                "Days to Alignment": result["ma_alignment_prediction"]["days_to_alignment"],
                "Alignment Confidence": result["ma_alignment_prediction"]["confidence"],
                "Momentum Acceleration": result["momentum_acceleration"],
                "Watchlist Category": result["watchlist_category"],
                "Kurtosis": result["kurtosis"],
                "Skewness": result["skewness"]
            }
            flattened_results.append(flat_result)

        try:
            df = pd.DataFrame(flattened_results)
            df.to_csv(output_file, index=False)
            logger.info(f"Results saved to {output_file}")
        except Exception as e:
            logger.error(f"Error saving results to CSV: {e}")
            raise

def main():
    import argparse

    parser = argparse.ArgumentParser(description="Stage 2 Momentum Breakout Scanner")
    parser.add_argument("--api_key", required=True, help="Kite Connect API Key")
    parser.add_argument("--access_token", required=True, help="Kite Connect Access Token")
    parser.add_argument("--csv_file", required=True, help="Path to CSV file with stock symbols")
    parser.add_argument("--output_file", default="stage2_results.csv", help="Path to save results CSV")

    args = parser.parse_args()
    # python '.\New folder\stage_analysis\vcptraderstrategygemeni.py'   --api_key 3bi2yh8g830vq3y6   --access_token mCwr1PCgqh5VtVTcFbeid8suESSSgYex   --csv_file data/MCAP25To50.csv   --output_file stage2_results.csv
    try:
        scanner = Stage2MomentumScanner(
            api_key=args.api_key,
            access_token=args.access_token
        )

        scanner.scan_from_csv(args.csv_file, args.output_file)

        logger.info("Scanning complete!")
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        raise

if __name__ == "__main__":
    main()