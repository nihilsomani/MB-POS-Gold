import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import time
import os
import json
from datetime import datetime, timedelta
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class EnhancedRSIDivergenceScanner:
    def __init__(self, api_key, access_token):
        """
        Initialize the Enhanced RSI Divergence Scanner with multiple filters
        
        Args:
            api_key: Kite Connect API key
            access_token: Kite Connect access token
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.instruments = None
        self.instruments_cache_file = 'nse_instruments_cache.json'
        self.rate_limit_delay = 0.34  # ~3 requests per second to stay under limit
        
    def load_or_fetch_instruments(self):
        """Load instruments from cache or fetch from Kite"""
        if os.path.exists(self.instruments_cache_file):
            cache_time = os.path.getmtime(self.instruments_cache_file)
            if time.time() - cache_time < 86400:  # 24 hours
                logger.info("Loading instruments from cache...")
                with open(self.instruments_cache_file, 'r') as f:
                    self.instruments = pd.DataFrame(json.load(f))
                logger.info(f"Loaded {len(self.instruments)} instruments from cache")
                return
        
        logger.info("Fetching instruments from Kite Connect...")
        instruments = self.kite.instruments("NSE")
        self.instruments = pd.DataFrame(instruments)
        
        with open(self.instruments_cache_file, 'w') as f:
            json.dump(self.instruments.to_dict('records'), f)
        logger.info(f"Cached {len(self.instruments)} instruments")
    
    def get_instrument_token(self, symbol):
        """Get instrument token for a given symbol"""
        if self.instruments is None:
            self.load_or_fetch_instruments()
        
        instrument = self.instruments[self.instruments['tradingsymbol'] == symbol]
        if not instrument.empty:
            return instrument.iloc[0]['instrument_token']
        
        instrument = self.instruments[self.instruments['tradingsymbol'] == f"{symbol}-EQ"]
        if not instrument.empty:
            return instrument.iloc[0]['instrument_token']
        
        return None
    
    def calculate_rsi(self, data, period=14):
        """Calculate RSI without using TA-Lib"""
        delta = data.diff()
        gain = (delta.where(delta > 0, 0)).fillna(0)
        loss = (-delta.where(delta < 0, 0)).fillna(0)
        
        avg_gain = gain.ewm(com=period-1, min_periods=period).mean()
        avg_loss = loss.ewm(com=period-1, min_periods=period).mean()
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def calculate_ema(self, data, period):
        """Calculate Exponential Moving Average"""
        return data.ewm(span=period, adjust=False).mean()
    
    def calculate_sma(self, data, period):
        """Calculate Simple Moving Average"""
        return data.rolling(window=period).mean()
    
    def calculate_atr(self, df, period=14):
        """Calculate Average True Range"""
        high = df['high']
        low = df['low']
        close = df['close']
        
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=period).mean()
        
        return atr
    
    def calculate_adx(self, df, period=14):
        """Calculate Average Directional Index (ADX) for trend strength"""
        high = df['high']
        low = df['low']
        close = df['close']
        
        # Calculate +DM and -DM
        plus_dm = high.diff()
        minus_dm = -low.diff()
        
        plus_dm[plus_dm < 0] = 0
        minus_dm[minus_dm < 0] = 0
        
        # True Range
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        
        # Smooth the values
        atr = tr.rolling(window=period).mean()
        plus_di = 100 * (plus_dm.rolling(window=period).mean() / atr)
        minus_di = 100 * (minus_dm.rolling(window=period).mean() / atr)
        
        # Calculate DX and ADX
        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        adx = dx.rolling(window=period).mean()
        
        return adx, plus_di, minus_di
    
    def calculate_volume_profile(self, df, period=20):
        """Calculate volume trend"""
        df['volume_sma'] = df['volume'].rolling(window=period).mean()
        df['volume_ratio'] = df['volume'] / df['volume_sma']
        return df
    
    def identify_support_resistance(self, df, window=20):
        """Identify if price is near support or resistance"""
        df['rolling_high'] = df['high'].rolling(window=window).max()
        df['rolling_low'] = df['low'].rolling(window=window).min()
        
        current_price = df['close'].iloc[-1]
        range_size = df['rolling_high'].iloc[-1] - df['rolling_low'].iloc[-1]
        
        # Check if near support (bottom 15% of range)
        near_support = (current_price - df['rolling_low'].iloc[-1]) / range_size < 0.15
        
        # Check if near resistance (top 15% of range)
        near_resistance = (df['rolling_high'].iloc[-1] - current_price) / range_size < 0.15
        
        return near_support, near_resistance
    
    def find_pivots(self, data, left=5, right=5):
        """Find pivot highs and lows"""
        pivot_highs = np.zeros(len(data), dtype=bool)
        pivot_lows = np.zeros(len(data), dtype=bool)
        
        for i in range(left, len(data) - right):
            is_high = True
            for j in range(i - left, i + right + 1):
                if j != i and data.iloc[j] >= data.iloc[i]:
                    is_high = False
                    break
            pivot_highs[i] = is_high
            
            is_low = True
            for j in range(i - left, i + right + 1):
                if j != i and data.iloc[j] <= data.iloc[i]:
                    is_low = False
                    break
            pivot_lows[i] = is_low
        
        return pivot_highs, pivot_lows
    
    def calculate_trend(self, df, short_period=20, long_period=50):
        """
        Determine overall trend direction
        Returns: 1 (uptrend), -1 (downtrend), 0 (sideways)
        """
        df['ema_short'] = self.calculate_ema(df['close'], short_period)
        df['ema_long'] = self.calculate_ema(df['close'], long_period)
        
        current_short = df['ema_short'].iloc[-1]
        current_long = df['ema_long'].iloc[-1]
        
        # Price position relative to EMAs
        price = df['close'].iloc[-1]
        
        if current_short > current_long and price > current_short:
            return 1  # Strong uptrend
        elif current_short < current_long and price < current_short:
            return -1  # Strong downtrend
        else:
            return 0  # Sideways/transitional
    
    def detect_divergences_with_filters(self, df, lbL=5, lbR=5, range_lower=5, range_upper=60):
        """
        Detect RSI divergences with multiple quality filters
        
        Filters Applied:
        1. RSI Extreme Levels (>70 for bearish, <30 for bullish)
        2. Trend Alignment (only counter-trend divergences)
        3. Volume Confirmation
        4. Support/Resistance proximity
        5. ADX for trend strength
        6. Multiple timeframe alignment
        """
        # Calculate all indicators
        df['rsi'] = self.calculate_rsi(df['close'], period=14)
        df['atr'] = self.calculate_atr(df, period=14)
        df['adx'], df['plus_di'], df['minus_di'] = self.calculate_adx(df, period=14)
        df = self.calculate_volume_profile(df, period=20)
        
        # Trend analysis
        trend = self.calculate_trend(df)
        
        # Support/Resistance
        near_support, near_resistance = self.identify_support_resistance(df)
        
        # Find pivots in RSI
        pivot_highs, pivot_lows = self.find_pivots(df['rsi'], left=lbL, right=lbR)
        
        df['rsi_pivot_high'] = pivot_highs
        df['rsi_pivot_low'] = pivot_lows
        
        results = {
            'regular_bullish': False,
            'hidden_bullish': False,
            'regular_bearish': False,
            'hidden_bearish': False,
            'current_rsi': df['rsi'].iloc[-1] if not df['rsi'].isna().all() else None,
            'last_close': df['close'].iloc[-1],
            'trend': 'Uptrend' if trend == 1 else 'Downtrend' if trend == -1 else 'Sideways',
            'adx': round(df['adx'].iloc[-1], 2) if not df['adx'].isna().all() else None,
            'volume_ratio': round(df['volume_ratio'].iloc[-1], 2) if 'volume_ratio' in df else None,
            'filter_score': 0,
            'signal_quality': 'None',
            'filters_passed': []
        }
        
        # Check for bullish divergences
        pivot_low_indices = np.where(pivot_lows)[0]
        if len(pivot_low_indices) >= 2:
            for i in range(len(pivot_low_indices) - 1, 0, -1):
                current_pivot = pivot_low_indices[i]
                prev_pivot = pivot_low_indices[i-1]
                
                bars_between = current_pivot - prev_pivot
                if range_lower <= bars_between <= range_upper:
                    # Regular Bullish: Price makes lower low, RSI makes higher low
                    if (df['low'].iloc[current_pivot] < df['low'].iloc[prev_pivot] and
                        df['rsi'].iloc[current_pivot] > df['rsi'].iloc[prev_pivot]):
                        
                        results['regular_bullish'] = True
                        results['rb_rsi_diff'] = round(df['rsi'].iloc[current_pivot] - df['rsi'].iloc[prev_pivot], 2)
                        results['rb_price_diff_pct'] = round((df['low'].iloc[prev_pivot] - df['low'].iloc[current_pivot]) / df['low'].iloc[prev_pivot] * 100, 2)
                        
                        # Apply filters
                        filter_score = 0
                        filters_passed = []
                        
                        # Filter 1: RSI in oversold zone (<35, ideal <30)
                        if df['rsi'].iloc[current_pivot] < 35:
                            filter_score += 2
                            filters_passed.append('RSI_Oversold')
                            if df['rsi'].iloc[current_pivot] < 30:
                                filter_score += 1
                                filters_passed.append('RSI_Deep_Oversold')
                        
                        # Filter 2: Trend alignment (better in downtrend or sideways)
                        if trend <= 0:
                            filter_score += 2
                            filters_passed.append('Trend_Aligned')
                        
                        # Filter 3: Near support level
                        if near_support:
                            filter_score += 2
                            filters_passed.append('Near_Support')
                        
                        # Filter 4: Volume confirmation (higher volume on divergence)
                        if df['volume_ratio'].iloc[current_pivot] > 1.2:
                            filter_score += 1
                            filters_passed.append('Volume_Surge')
                        
                        # Filter 5: ADX shows weakening trend (ADX declining)
                        if len(df) > current_pivot + 5:
                            adx_current = df['adx'].iloc[current_pivot]
                            adx_prev = df['adx'].iloc[current_pivot - 5]
                            if not pd.isna(adx_current) and not pd.isna(adx_prev):
                                if adx_current < adx_prev:
                                    filter_score += 1
                                    filters_passed.append('Weakening_Trend')
                        
                        # Filter 6: Strong divergence (RSI difference > 5)
                        if results['rb_rsi_diff'] > 5:
                            filter_score += 1
                            filters_passed.append('Strong_Divergence')
                        
                        results['rb_filter_score'] = filter_score
                        results['rb_filters_passed'] = filters_passed
                    
                    # Hidden Bullish: Price makes higher low, RSI makes lower low
                    if (df['low'].iloc[current_pivot] > df['low'].iloc[prev_pivot] and
                        df['rsi'].iloc[current_pivot] < df['rsi'].iloc[prev_pivot]):
                        
                        results['hidden_bullish'] = True
                        results['hb_rsi_diff'] = round(df['rsi'].iloc[prev_pivot] - df['rsi'].iloc[current_pivot], 2)
                        
                        # Apply filters for hidden bullish
                        filter_score = 0
                        filters_passed = []
                        
                        # Filter 1: Must be in uptrend (continuation pattern)
                        if trend == 1:
                            filter_score += 3
                            filters_passed.append('Uptrend_Continuation')
                        
                        # Filter 2: Price near support in uptrend
                        if near_support:
                            filter_score += 2
                            filters_passed.append('Pullback_Support')
                        
                        # Filter 3: Volume on recent bar
                        if df['volume_ratio'].iloc[-1] > 1.0:
                            filter_score += 1
                            filters_passed.append('Volume_Confirm')
                        
                        results['hb_filter_score'] = filter_score
                        results['hb_filters_passed'] = filters_passed
                    
                    break
        
        # Check for bearish divergences
        pivot_high_indices = np.where(pivot_highs)[0]
        if len(pivot_high_indices) >= 2:
            for i in range(len(pivot_high_indices) - 1, 0, -1):
                current_pivot = pivot_high_indices[i]
                prev_pivot = pivot_high_indices[i-1]
                
                bars_between = current_pivot - prev_pivot
                if range_lower <= bars_between <= range_upper:
                    # Regular Bearish: Price makes higher high, RSI makes lower high
                    if (df['high'].iloc[current_pivot] > df['high'].iloc[prev_pivot] and
                        df['rsi'].iloc[current_pivot] < df['rsi'].iloc[prev_pivot]):
                        
                        results['regular_bearish'] = True
                        results['rbe_rsi_diff'] = round(df['rsi'].iloc[prev_pivot] - df['rsi'].iloc[current_pivot], 2)
                        results['rbe_price_diff_pct'] = round((df['high'].iloc[current_pivot] - df['high'].iloc[prev_pivot]) / df['high'].iloc[prev_pivot] * 100, 2)
                        
                        # Apply filters
                        filter_score = 0
                        filters_passed = []
                        
                        # Filter 1: RSI in overbought zone (>65, ideal >70)
                        if df['rsi'].iloc[current_pivot] > 65:
                            filter_score += 2
                            filters_passed.append('RSI_Overbought')
                            if df['rsi'].iloc[current_pivot] > 70:
                                filter_score += 1
                                filters_passed.append('RSI_Deep_Overbought')
                        
                        # Filter 2: Trend alignment (better in uptrend or sideways)
                        if trend >= 0:
                            filter_score += 2
                            filters_passed.append('Trend_Aligned')
                        
                        # Filter 3: Near resistance level
                        if near_resistance:
                            filter_score += 2
                            filters_passed.append('Near_Resistance')
                        
                        # Filter 4: Volume confirmation
                        if df['volume_ratio'].iloc[current_pivot] > 1.2:
                            filter_score += 1
                            filters_passed.append('Volume_Surge')
                        
                        # Filter 5: ADX shows weakening trend
                        if len(df) > current_pivot + 5:
                            adx_current = df['adx'].iloc[current_pivot]
                            adx_prev = df['adx'].iloc[current_pivot - 5]
                            if not pd.isna(adx_current) and not pd.isna(adx_prev):
                                if adx_current < adx_prev:
                                    filter_score += 1
                                    filters_passed.append('Weakening_Trend')
                        
                        # Filter 6: Strong divergence
                        if results['rbe_rsi_diff'] > 5:
                            filter_score += 1
                            filters_passed.append('Strong_Divergence')
                        
                        results['rbe_filter_score'] = filter_score
                        results['rbe_filters_passed'] = filters_passed
                    
                    # Hidden Bearish: Price makes lower high, RSI makes higher high
                    if (df['high'].iloc[current_pivot] < df['high'].iloc[prev_pivot] and
                        df['rsi'].iloc[current_pivot] > df['rsi'].iloc[prev_pivot]):
                        
                        results['hidden_bearish'] = True
                        results['hbe_rsi_diff'] = round(df['rsi'].iloc[current_pivot] - df['rsi'].iloc[prev_pivot], 2)
                        
                        # Apply filters for hidden bearish
                        filter_score = 0
                        filters_passed = []
                        
                        # Filter 1: Must be in downtrend (continuation pattern)
                        if trend == -1:
                            filter_score += 3
                            filters_passed.append('Downtrend_Continuation')
                        
                        # Filter 2: Price near resistance in downtrend
                        if near_resistance:
                            filter_score += 2
                            filters_passed.append('Rally_Resistance')
                        
                        # Filter 3: Volume on recent bar
                        if df['volume_ratio'].iloc[-1] > 1.0:
                            filter_score += 1
                            filters_passed.append('Volume_Confirm')
                        
                        results['hbe_filter_score'] = filter_score
                        results['hbe_filters_passed'] = filters_passed
                    
                    break
        
        # Determine overall signal quality
        max_score = 0
        best_signal = 'None'
        
        if results['regular_bullish'] and 'rb_filter_score' in results:
            if results['rb_filter_score'] > max_score:
                max_score = results['rb_filter_score']
                best_signal = 'Regular_Bullish'
        
        if results['hidden_bullish'] and 'hb_filter_score' in results:
            if results['hb_filter_score'] > max_score:
                max_score = results['hb_filter_score']
                best_signal = 'Hidden_Bullish'
        
        if results['regular_bearish'] and 'rbe_filter_score' in results:
            if results['rbe_filter_score'] > max_score:
                max_score = results['rbe_filter_score']
                best_signal = 'Regular_Bearish'
        
        if results['hidden_bearish'] and 'hbe_filter_score' in results:
            if results['hbe_filter_score'] > max_score:
                max_score = results['hbe_filter_score']
                best_signal = 'Hidden_Bearish'
        
        results['filter_score'] = max_score
        results['best_signal'] = best_signal
        
        # Quality classification
        if max_score >= 7:
            results['signal_quality'] = 'Excellent'
        elif max_score >= 5:
            results['signal_quality'] = 'Good'
        elif max_score >= 3:
            results['signal_quality'] = 'Fair'
        else:
            results['signal_quality'] = 'Poor'
        
        return results
    
    def scan_symbol(self, symbol, interval="day", days=100):
        """Scan a single symbol for RSI divergences with filters"""
        try:
            token = self.get_instrument_token(symbol)
            if token is None:
                logger.warning(f"Symbol {symbol} not found")
                return None
            
            from_date = datetime.now() - timedelta(days=days)
            to_date = datetime.now()
            
            logger.info(f"Fetching data for {symbol}...")
            historical_data = self.kite.historical_data(
                instrument_token=token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            time.sleep(self.rate_limit_delay)
            
            if not historical_data:
                logger.warning(f"No data received for {symbol}")
                return None
            
            df = pd.DataFrame(historical_data)
            
            if len(df) < 60:
                logger.warning(f"Insufficient data for {symbol}")
                return None
            
            # Detect divergences with filters
            divergences = self.detect_divergences_with_filters(df)
            
            result = {
                'symbol': symbol,
                'regular_bullish': divergences['regular_bullish'],
                'hidden_bullish': divergences['hidden_bullish'],
                'regular_bearish': divergences['regular_bearish'],
                'hidden_bearish': divergences['hidden_bearish'],
                'current_rsi': round(divergences['current_rsi'], 2) if divergences['current_rsi'] else None,
                'last_close': round(divergences['last_close'], 2),
                'trend': divergences['trend'],
                'adx': divergences['adx'],
                'volume_ratio': divergences['volume_ratio'],
                'filter_score': divergences['filter_score'],
                'signal_quality': divergences['signal_quality'],
                'best_signal': divergences['best_signal'],
                'scan_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            
            # Add specific filter details
            if divergences['regular_bullish'] and 'rb_filter_score' in divergences:
                result['rb_filters'] = ','.join(divergences['rb_filters_passed'])
                result['rb_rsi_diff'] = divergences.get('rb_rsi_diff')
                result['rb_price_diff_pct'] = divergences.get('rb_price_diff_pct')
            
            if divergences['regular_bearish'] and 'rbe_filter_score' in divergences:
                result['rbe_filters'] = ','.join(divergences['rbe_filters_passed'])
                result['rbe_rsi_diff'] = divergences.get('rbe_rsi_diff')
                result['rbe_price_diff_pct'] = divergences.get('rbe_price_diff_pct')
            
            if divergences['hidden_bullish'] and 'hb_filter_score' in divergences:
                result['hb_filters'] = ','.join(divergences['hb_filters_passed'])
            
            if divergences['hidden_bearish'] and 'hbe_filter_score' in divergences:
                result['hbe_filters'] = ','.join(divergences['hbe_filters_passed'])
            
            logger.info(f"Scanned {symbol}: Quality={result['signal_quality']}, Score={result['filter_score']}")
            return result
            
        except Exception as e:
            logger.error(f"Error scanning {symbol}: {str(e)}")
            return None
    
    def scan_from_csv(self, input_file='input.csv', output_file='divergence_results_filtered.csv', 
                      interval="day", min_quality='Fair'):
        """
        Scan symbols from input CSV and output filtered results
        
        Args:
            input_file: Input CSV file with 'Symbol' column
            output_file: Output CSV file for results
            interval: Candle interval
            min_quality: Minimum signal quality ('Excellent', 'Good', 'Fair', 'Poor')
        """
        self.load_or_fetch_instruments()
        
        logger.info(f"Reading symbols from {input_file}...")
        input_df = pd.read_csv(input_file)
        
        if 'Symbol' not in input_df.columns:
            raise ValueError("Input CSV must have a 'Symbol' column")
        
        symbols = input_df['Symbol'].dropna().unique().tolist()
        logger.info(f"Found {len(symbols)} symbols to scan")
        
        results = []
        for i, symbol in enumerate(symbols, 1):
            logger.info(f"Scanning {i}/{len(symbols)}: {symbol}")
            result = self.scan_symbol(symbol, interval=interval)
            if result:
                results.append(result)
        
        if results:
            results_df = pd.DataFrame(results)
            
            # Sort by filter score (best signals first)
            results_df = results_df.sort_values('filter_score', ascending=False)
            
            # Save all results
            results_df.to_csv(output_file, index=False)
            logger.info(f"Saved {len(results)} results to {output_file}")
            
            # Filter for quality signals
            quality_map = {'Excellent': 3, 'Good': 2, 'Fair': 1, 'Poor': 0}
            min_quality_level = quality_map.get(min_quality, 0)
            
            filtered_df = results_df[results_df['signal_quality'].map(quality_map) >= min_quality_level]
            
            if not filtered_df.empty:
                filtered_file = output_file.replace('.csv', '_quality_signals.csv')
                filtered_df.to_csv(filtered_file, index=False)
                logger.info(f"Saved {len(filtered_df)} quality signals to {filtered_file}")
            
            # Print summary
            print("\n" + "="*80)
            print("ENHANCED SCAN SUMMARY")
            print("="*80)
            print(f"Total symbols scanned: {len(results)}")
            print(f"\nDivergences Found:")
            print(f"  Regular Bullish: {results_df['regular_bullish'].sum()}")
            print(f"  Hidden Bullish: {results_df['hidden_bullish'].sum()}")
            print(f"  Regular Bearish: {results_df['regular_bearish'].sum()}")
            print(f"  Hidden Bearish: {results_df['hidden_bearish'].sum()}")
            print(f"\nSignal Quality Distribution:")
            print(f"  Excellent (Score ≥7): {(results_df['signal_quality'] == 'Excellent').sum()}")
            print(f"  Good (Score 5-6): {(results_df['signal_quality'] == 'Good').sum()}")
            print(f"  Fair (Score 3-4): {(results_df['signal_quality'] == 'Fair').sum()}")
            print(f"  Poor (Score <3): {(results_df['signal_quality'] == 'Poor').sum()}")
            
            if not filtered_df.empty:
                print(f"\nTop Quality Signals ({min_quality}+):")
                for idx, row in filtered_df.head(10).iterrows():
                    print(f"  {row['symbol']}: {row['best_signal']} | Quality: {row['signal_quality']} | Score: {row['filter_score']}")
            
            print(f"\nResults saved to: {output_file}")
            if not filtered_df.empty:
                print(f"Quality signals saved to: {filtered_file}")
            print("="*80)
        else:
            logger.warning("No results to save")


def main():
    """Main function to run the enhanced scanner"""
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "dqU0357OnskSNW4PrvTTrKK7xQfZYgGo"
    
    if API_KEY == "your_api_key_here" or ACCESS_TOKEN == "your_access_token_here":
        print("\n" + "="*80)
        print("SETUP REQUIRED")
        print("="*80)
        print("Please update the API_KEY and ACCESS_TOKEN in the script")
        print("\nOr set environment variables:")
        print("  export KITE_API_KEY='your_api_key'")
        print("  export KITE_ACCESS_TOKEN='your_access_token'")
        print("="*80)
        return
    
    API_KEY = os.getenv('KITE_API_KEY', API_KEY)
    ACCESS_TOKEN = os.getenv('KITE_ACCESS_TOKEN', ACCESS_TOKEN)
    
    scanner = EnhancedRSIDivergenceScanner(api_key=API_KEY, access_token=ACCESS_TOKEN)
    
    scanner.scan_from_csv(
        input_file='data/sector_marketcap_great8000.csv',
        output_file='divergence_results_filtered.csv',
        interval='day',
        min_quality='Fair'  # Only output Fair or better signals
    )


if __name__ == "__main__":
    main()