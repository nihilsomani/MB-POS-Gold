import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import warnings
import time
import json
import os
import math
import argparse
import sys
from typing import Dict, List, Optional, Tuple
warnings.filterwarnings('ignore')

# =============================================================================
# CONFIGURATION SECTION - MODIFY THESE VALUES AS NEEDED
# =============================================================================

# API Configuration
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "5IulsHNBG204irQQSiaZENN6kou5yh3C"

# Data Analysis Configuration
WEEKS_BACK = 13                    # Number of weeks for historical data analysis
MOMENTUM_PERIOD = 5                # Period for momentum calculation (in weeks)
TAIL_LENGTH = 5                   # Number of data points for tail visualization
CACHE_EXPIRY_HOURS = 24            # Cache expiry time in hours

# Rate Limiting Configuration
API_CALL_DELAY = 0.1               # Delay between API calls (seconds)
MAX_RETRIES = 3                    # Maximum retry attempts for API calls
RETRY_DELAY = 5                    # Delay between retries (seconds)

# Scoring Configuration
SCORING_WEIGHTS = {
    'quadrant_scores': {
        'Leading': 90,
        'Improving': 70,
        'Weakening': 40,
        'Lagging': 20
    },
    'rs_ratio_multiplier': 0.4,
    'momentum_multiplier': 0.4,
    'distance_multiplier': 0.2,
    'movement_bonuses': {
        'toward_leading': 30,
        'toward_improving': 20,
        'toward_lagging_penalty': -15
    },
    'velocity_max_bonus': 25
}

# Backtester-Optimized Scoring Weights (for Quarterly Momentum Strategy)
BACKTESTER_SCORING_WEIGHTS = {
    'quadrant_scores': {
        'Leading': 60,          # REDUCED from 90 (avoid late entries)
        'Improving': 95,        # INCREASED from 70 (enter early)
        'Weakening': 30,        # Reduced from 40
        'Lagging': 10           # Reduced from 20
    },
    'rs_ratio_multiplier': 0.35,
    'momentum_multiplier': 0.45,     # Increased (reward momentum)
    'distance_multiplier': 0.15,     # Reduced
    'movement_bonuses': {
        'toward_leading': 35,
        'toward_improving': 25,
        'toward_lagging_penalty': -20
    },
    'velocity_max_bonus': 20
}

# Quarterly Momentum Strategy Configuration
QTR_MOMENTUM_CONFIG = {
    'name': 'Quarterly Momentum Strategy',
    'description': 'Optimized quarterly rotation strategy based on backtest learnings',
    'portfolio_size': 10,
    'min_score': 185,
    'max_score': 273,                    # ⭐ OPTIMIZED: 76.77% CAGR, 2.40 Sharpe (filters overbought 274-277)
    'prefer_leading': True,
    'exclude_sectors': [],              # Add sectors to exclude
    'check_market_regime': True,         # Check Nifty 500 health before entry
    'benchmark_for_regime': 'NIFTY 500',
    'nifty_sma_period': 200,            # 200-day SMA for market regime
    'min_market_strength': 2,           # Need 2/3 conditions for full entry
    'rebalance_frequency': 'quarterly',  # Next rebalance dates
    'scoring_weights': BACKTESTER_SCORING_WEIGHTS
}

# Output Configuration
CREATE_INDIVIDUAL_SECTOR_CSV = True    # Create CSV for each sector
CREATE_MASTER_SUMMARY_CSV = True       # Create master summary CSV
CREATE_SECTOR_LEADERS_CSV = True       # Create sector leaders CSV
CREATE_OPPORTUNITY_TIERS_CSV = True    # Create opportunity tiers CSV
CREATE_COMBINED_ANALYSIS_CSV = True    # Create combined analysis CSV

# Display Configuration
TOP_OPPORTUNITIES_DISPLAY = 5      # Number of top opportunities to display per sector
TOP_OVERALL_DISPLAY = 15           # Number of top opportunities to display in master summary
SECTOR_LEADERS_COUNT = 3           # Number of top stocks to show per sector

# File Configuration
DATA_FILE_PATH = 'data\\Sector-MCAP-great2500-output.csv'  # Path to input CSV file
SYMBOL_COLUMN = 'symbol'           # Column name containing stock symbols
SECTOR_COLUMN = 'Level_4'          # Column name containing sector information
BENCHMARK_INDEX = 'NIFTY 50'       # Benchmark index for comparison

# =============================================================================

class RRGScanner:
    def __init__(self, api_key, access_token, cache_dir='cache', 
                 weeks_back=None, momentum_period=None, tail_length=None, scoring_weights=None):
        """
        Initialize RRG Scanner with Kite Connect
        
        Args:
            api_key: Your Kite Connect API key
            access_token: Your Kite Connect access token
            cache_dir: Directory to store cached data
            weeks_back: Number of weeks for historical data (default: 21)
            momentum_period: Period for momentum calculation (default: 5)
            tail_length: Number of data points for tail visualization (default: 10)
            scoring_weights: Custom scoring weights dict
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Cache management
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)
        self.instruments_cache_file = os.path.join(cache_dir, 'nse_instruments.json')
        self.cache_expiry_hours = CACHE_EXPIRY_HOURS
        
        # Rate limiting
        self.api_call_delay = API_CALL_DELAY
        self.max_retries = MAX_RETRIES
        self.retry_delay = RETRY_DELAY
        
        # RRG Parameters - use config values if not provided
        self.weeks_back = weeks_back or WEEKS_BACK
        self.momentum_period = momentum_period or MOMENTUM_PERIOD
        self.tail_length = tail_length or TAIL_LENGTH
        
        # Scoring weights - use config values if not provided
        self.scoring_weights = scoring_weights or SCORING_WEIGHTS
        
        # NSE sector indices mapping
        self.sector_indices = {
            'NIFTY AUTO': 'NIFTY AUTO',
            'NIFTY BANK': 'NIFTY BANK', 
            'NIFTY ENERGY': 'NIFTY ENERGY',
            'NIFTY FMCG': 'NIFTY FMCG',
            'NIFTY HEALTHCARE': 'NIFTY HEALTHCARE',
            'NIFTY IT': 'NIFTY IT',
            'NIFTY MEDIA': 'NIFTY MEDIA',
            'NIFTY METAL': 'NIFTY METAL',
            'NIFTY PHARMA': 'NIFTY PHARMA',
            'NIFTY PSU BANK': 'NIFTY PSU BANK',
            'NIFTY REALTY': 'NIFTY REALTY',
            'NIFTY PRIVATE BANK': 'NIFTY PRIVATE BANK'
        }
        
        self.benchmark = 'NIFTY 50'
        
        # Load instruments cache
        self.instruments_cache = self._load_instruments_cache()
    
    def _load_instruments_cache(self) -> Dict:
        """Load instruments from cache if valid, otherwise return empty dict"""
        try:
            if os.path.exists(self.instruments_cache_file):
                with open(self.instruments_cache_file, 'r') as f:
                    cache_data = json.load(f)
                
                # Check if cache is still valid
                cache_time = datetime.fromisoformat(cache_data.get('timestamp', '2000-01-01'))
                if (datetime.now() - cache_time).total_seconds() < self.cache_expiry_hours * 3600:
                    print(f"📁 Loaded {len(cache_data.get('instruments', []))} instruments from cache")
                    return cache_data.get('instruments', [])
                else:
                    print("🕐 Instruments cache expired, will refresh")
        except Exception as e:
            print(f"⚠️ Error loading cache: {e}")
        
        return []
    
    def _save_instruments_cache(self, instruments: List[Dict]):
        """Save instruments to cache"""
        try:
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'instruments': instruments
            }
            with open(self.instruments_cache_file, 'w') as f:
                json.dump(cache_data, f, indent=2)
            print(f"💾 Cached {len(instruments)} instruments")
        except Exception as e:
            print(f"⚠️ Error saving cache: {e}")
    
    def _rate_limit_delay(self):
        """Add delay between API calls to respect rate limits"""
        time.sleep(self.api_call_delay)
    
    def _api_call_with_retry(self, func, *args, **kwargs):
        """Make API call with retry logic and rate limiting"""
        for attempt in range(self.max_retries):
            try:
                self._rate_limit_delay()
                return func(*args, **kwargs)
            except Exception as e:
                if "Too many requests" in str(e) or "rate limit" in str(e).lower():
                    if attempt < self.max_retries - 1:
                        print(f"⏳ Rate limit hit, waiting {self.retry_delay}s before retry {attempt + 1}/{self.max_retries}")
                        time.sleep(self.retry_delay * (attempt + 1))  # Exponential backoff
                        continue
                raise e
        return None
        
    def get_historical_data(self, instrument_token, from_date, to_date, interval='week'):
        """
        Fetch historical data from Kite Connect with rate limiting
        
        Args:
            instrument_token: NSE instrument token
            from_date: Start date
            to_date: End date  
            interval: Data interval (day, week, month)
        
        Returns:
            DataFrame with OHLCV data
        """
        try:
            data = self._api_call_with_retry(
                self.kite.historical_data,
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            
            if data is None:
                return pd.DataFrame()
                
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date'])
                df.set_index('date', inplace=True)
            return df
        except Exception as e:
            print(f"Error fetching data for {instrument_token}: {e}")
            return pd.DataFrame()
    
    def get_instrument_token(self, tradingsymbol):
        """
        Get instrument token for a trading symbol using cache
        """
        try:
            # First check cache
            if self.instruments_cache:
                instrument = next((item for item in self.instruments_cache 
                                 if item['tradingsymbol'] == tradingsymbol), None)
                if instrument:
                    return instrument['instrument_token']
            
            # If not in cache, fetch from API and update cache
            print(f"🔄 Fetching instruments from API (not in cache)")
            instruments = self._api_call_with_retry(self.kite.instruments, "NSE")
            
            if instruments:
                # Update cache
                self._save_instruments_cache(instruments)
                self.instruments_cache = instruments
                
                # Find the instrument
                instrument = next((item for item in instruments 
                                 if item['tradingsymbol'] == tradingsymbol), None)
                return instrument['instrument_token'] if instrument else None
            
            return None
        except Exception as e:
            print(f"Error getting instrument token for {tradingsymbol}: {e}")
            return None
    
    def calculate_relative_strength(self, sector_data, benchmark_data):
        """
        Calculate relative strength ratio
        
        Args:
            sector_data: DataFrame with sector price data
            benchmark_data: DataFrame with benchmark price data
            
        Returns:
            Series with RS ratio
        """
        # Ensure both datasets have same index
        common_dates = sector_data.index.intersection(benchmark_data.index)
        sector_aligned = sector_data.loc[common_dates, 'close']
        benchmark_aligned = benchmark_data.loc[common_dates, 'close']
        
        # Calculate RS ratio (normalize to 100)
        rs_ratio = (sector_aligned / benchmark_aligned) * 100
        rs_ratio = rs_ratio / rs_ratio.iloc[0] * 100  # Normalize to start at 100
        
        return rs_ratio
    
    def calculate_rs_momentum(self, rs_ratio, period=10):
        """
        Calculate RS momentum (rate of change of RS)
        
        Args:
            rs_ratio: Series with RS ratio values
            period: Period for momentum calculation
            
        Returns:
            Series with RS momentum
        """
        rs_momentum = rs_ratio.pct_change(period) * 100 + 100
        return rs_momentum
    
    def get_quadrant(self, rs_ratio, rs_momentum, benchmark_rs=100, benchmark_momentum=100):
        """
        Determine which quadrant a security is in
        
        Returns:
            String indicating quadrant: 'Leading', 'Weakening', 'Lagging', 'Improving'
        """
        if rs_ratio >= benchmark_rs and rs_momentum >= benchmark_momentum:
            return 'Leading'
        elif rs_ratio < benchmark_rs and rs_momentum >= benchmark_momentum:
            return 'Weakening'
        elif rs_ratio < benchmark_rs and rs_momentum < benchmark_momentum:
            return 'Lagging'
        else:  # rs_ratio >= benchmark_rs and rs_momentum < benchmark_momentum
            return 'Improving'
    
    def calculate_rrg_data(self, weeks_back=None, momentum_period=None):
        """
        Calculate RRG data for all sectors
        
        Args:
            weeks_back: Number of weeks of historical data (uses instance default if None)
            momentum_period: Period for momentum calculation (uses instance default if None)
            
        Returns:
            DataFrame with RRG coordinates for each sector
        """
        # Use instance parameters if not provided
        weeks_back = weeks_back or self.weeks_back
        momentum_period = momentum_period or self.momentum_period
        
        end_date = datetime.now()
        start_date = end_date - timedelta(weeks=weeks_back)
        
        # Get benchmark data
        benchmark_token = self.get_instrument_token(self.benchmark)
        if not benchmark_token:
            raise ValueError(f"Could not find instrument token for {self.benchmark}")
            
        benchmark_data = self.get_historical_data(
            benchmark_token, start_date, end_date, 'week'
        )
        
        if benchmark_data.empty:
            raise ValueError("Could not fetch benchmark data")
        
        results = []
        
        for sector_name, sector_symbol in self.sector_indices.items():
            try:
                sector_token = self.get_instrument_token(sector_symbol)
                if not sector_token:
                    print(f"Skipping {sector_name}: No instrument token found")
                    continue
                    
                sector_data = self.get_historical_data(
                    sector_token, start_date, end_date, 'week'
                )
                
                if sector_data.empty:
                    print(f"Skipping {sector_name}: No data available")
                    continue
                
                # Calculate RS ratio and momentum
                rs_ratio = self.calculate_relative_strength(sector_data, benchmark_data)
                rs_momentum = self.calculate_rs_momentum(rs_ratio, momentum_period)
                
                # Get latest values
                current_rs = rs_ratio.iloc[-1] if not rs_ratio.empty else 100
                current_momentum = rs_momentum.iloc[-1] if not rs_momentum.empty else 100
                
                # Determine quadrant
                quadrant = self.get_quadrant(current_rs, current_momentum)
                
                # Calculate tail data (configurable length for visualization)
                tail_length = min(self.tail_length, len(rs_ratio))
                tail_rs = rs_ratio.iloc[-tail_length:].tolist()
                tail_momentum = rs_momentum.iloc[-tail_length:].tolist()
                
                results.append({
                    'Sector': sector_name,
                    'Symbol': sector_symbol,
                    'RS_Ratio': current_rs,
                    'RS_Momentum': current_momentum,
                    'Quadrant': quadrant,
                    'Tail_RS': tail_rs,
                    'Tail_Momentum': tail_momentum,
                    'Distance_from_Center': np.sqrt((current_rs - 100)**2 + (current_momentum - 100)**2)
                })
                
                print(f"✓ Processed {sector_name}: {quadrant}")
                
            except Exception as e:
                print(f"✗ Error processing {sector_name}: {e}")
                continue
        
        return pd.DataFrame(results)
    
    def scan_sectors(self):
        """
        Main scanning function - returns RRG analysis
        
        Returns:
            Dictionary with categorized sectors
        """
        print("🔍 Starting RRG Sector Scan...")
        print("=" * 50)
        
        try:
            rrg_data = self.calculate_rrg_data()
            
            if rrg_data.empty:
                return {"error": "No data could be processed"}
            
            # Categorize sectors by quadrant
            leading = rrg_data[rrg_data['Quadrant'] == 'Leading'].sort_values('Distance_from_Center', ascending=False)
            weakening = rrg_data[rrg_data['Quadrant'] == 'Weakening'].sort_values('RS_Ratio', ascending=False)
            lagging = rrg_data[rrg_data['Quadrant'] == 'Lagging'].sort_values('Distance_from_Center')
            improving = rrg_data[rrg_data['Quadrant'] == 'Improving'].sort_values('RS_Momentum', ascending=False)
            
            # Print results
            print("\n📈 LEADING QUADRANT (Buy Focus):")
            print("-" * 40)
            for _, row in leading.iterrows():
                print(f"  • {row['Sector']:<20} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
            
            print("\n📉 WEAKENING QUADRANT (Monitor/Correction):")
            print("-" * 40)
            for _, row in weakening.iterrows():
                print(f"  • {row['Sector']:<20} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
            
            print("\n🔻 LAGGING QUADRANT (Avoid/Value Play):")
            print("-" * 40)
            for _, row in lagging.iterrows():
                print(f"  • {row['Sector']:<20} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
            
            print("\n📊 IMPROVING QUADRANT (Early Entry):")
            print("-" * 40)
            for _, row in improving.iterrows():
                print(f"  • {row['Sector']:<20} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
            
            return {
                'data': rrg_data,
                'leading': leading,
                'weakening': weakening, 
                'lagging': lagging,
                'improving': improving,
                'summary': self._generate_summary(rrg_data)
            }
            
        except Exception as e:
            print(f"❌ Error in sector scan: {e}")
            return {"error": str(e)}
    
    def _generate_summary(self, rrg_data):
        """Generate trading summary and recommendations"""
        leading_count = len(rrg_data[rrg_data['Quadrant'] == 'Leading'])
        improving_count = len(rrg_data[rrg_data['Quadrant'] == 'Improving'])
        total_strong = leading_count + improving_count
        
        market_strength = "Strong" if total_strong >= 6 else "Moderate" if total_strong >= 3 else "Weak"
        
        return {
            'market_strength': market_strength,
            'leading_sectors': leading_count,
            'improving_sectors': improving_count,
            'total_opportunity': total_strong,
            'recommendation': self._get_recommendation(market_strength, total_strong)
        }
    
    def _get_recommendation(self, strength, total_strong):
        """Generate trading recommendation based on sector analysis"""
        if strength == "Strong":
            return f"🟢 Market shows broad strength with {total_strong} sectors in buy zones. Focus on leading sectors for momentum plays."
        elif strength == "Moderate":
            return f"🟡 Selective opportunity with {total_strong} strong sectors. Stock selection becomes crucial."
        else:
            return f"🔴 Limited sector strength detected. Consider defensive positioning or wait for better setup."
    
    def generate_comprehensive_analysis(self, rrg_data):
        """
        Generate comprehensive analysis with detailed scoring for CSV output.
        
        Args:
            rrg_data: DataFrame with RRG analysis results
            
        Returns:
            DataFrame with enhanced analysis and scoring
        """
        if rrg_data.empty:
            return pd.DataFrame()
        
        # Add comprehensive scoring
        enhanced_data = self._add_opportunity_scores(rrg_data)
        
        # Add additional analysis columns
        enhanced_data = self._add_analysis_columns(enhanced_data)
        
        # Add recommendation column
        enhanced_data = self._add_recommendations(enhanced_data)
        
        return enhanced_data
    
    def _add_analysis_columns(self, data):
        """Add additional analysis columns for comprehensive scoring"""
        data = data.copy()
        
        # Add trend strength analysis
        data['Trend_Strength'] = data.apply(self._calculate_trend_strength, axis=1)
        
        # Add momentum quality score
        data['Momentum_Quality'] = data.apply(self._calculate_momentum_quality, axis=1)
        
        # Add risk assessment
        data['Risk_Level'] = data.apply(self._calculate_risk_level, axis=1)
        
        # Add position sizing recommendation
        data['Position_Size'] = data.apply(self._calculate_position_size, axis=1)
        
        # Add time horizon recommendation
        data['Time_Horizon'] = data.apply(self._calculate_time_horizon, axis=1)
        
        return data
    
    def _calculate_trend_strength(self, row):
        """Calculate trend strength based on RS and momentum"""
        rs = row['RS_Ratio']
        momentum = row['RS_Momentum']
        
        # Strong trend if both RS and momentum are well above 100
        if rs >= 110 and momentum >= 110:
            return 'Very Strong'
        elif rs >= 105 and momentum >= 105:
            return 'Strong'
        elif rs >= 100 and momentum >= 100:
            return 'Moderate'
        elif rs >= 95 and momentum >= 95:
            return 'Weak'
        else:
            return 'Very Weak'
    
    def _calculate_momentum_quality(self, row):
        """Calculate momentum quality based on velocity and direction"""
        velocity = row.get('Velocity_Factor', 0)
        direction = row.get('Movement_Direction', 'Unknown')
        
        # High quality if moving toward leading with good velocity
        if direction == 'Toward Leading' and velocity > 5:
            return 'Excellent'
        elif direction == 'Toward Leading' and velocity > 2:
            return 'Good'
        elif direction == 'Toward Improving' and velocity > 3:
            return 'Good'
        elif velocity > 1:
            return 'Fair'
        else:
            return 'Poor'
    
    def _calculate_risk_level(self, row):
        """Calculate risk level based on position and volatility"""
        quadrant = row['Quadrant']
        distance = row['Distance_from_Center']
        
        if quadrant == 'Leading' and distance < 15:
            return 'Low'
        elif quadrant in ['Leading', 'Improving'] and distance < 25:
            return 'Medium'
        elif quadrant == 'Weakening':
            return 'High'
        else:
            return 'Very High'
    
    def _calculate_position_size(self, row):
        """Calculate recommended position size based on score and risk"""
        score = row['Opportunity_Score']
        risk = row['Risk_Level']
        
        if score >= 200 and risk == 'Low':
            return 'Large (5-10%)'
        elif score >= 150 and risk in ['Low', 'Medium']:
            return 'Medium (3-5%)'
        elif score >= 100:
            return 'Small (1-3%)'
        else:
            return 'Avoid'
    
    def _calculate_time_horizon(self, row):
        """Calculate recommended time horizon based on momentum and trend"""
        momentum_quality = row['Momentum_Quality']
        trend_strength = row['Trend_Strength']
        
        if momentum_quality == 'Excellent' and trend_strength in ['Very Strong', 'Strong']:
            return 'Long-term (6+ months)'
        elif momentum_quality in ['Good', 'Excellent']:
            return 'Medium-term (3-6 months)'
        elif momentum_quality == 'Fair':
            return 'Short-term (1-3 months)'
        else:
            return 'Day/Swing trade'
    
    def _add_recommendations(self, data):
        """Add trading recommendations based on comprehensive analysis"""
        data = data.copy()
        
        def get_recommendation(row):
            score = row['Opportunity_Score']
            quadrant = row['Quadrant']
            momentum_quality = row['Momentum_Quality']
            risk_level = row['Risk_Level']
            
            if score >= 200 and quadrant == 'Leading' and risk_level == 'Low':
                return 'STRONG BUY - High conviction long position'
            elif score >= 150 and quadrant in ['Leading', 'Improving'] and risk_level in ['Low', 'Medium']:
                return 'BUY - Good opportunity with moderate risk'
            elif score >= 100 and momentum_quality in ['Good', 'Excellent']:
                return 'WEAK BUY - Consider for portfolio diversification'
            elif quadrant == 'Weakening' and score >= 80:
                return 'HOLD - Monitor for potential reversal'
            elif quadrant == 'Lagging' and score < 50:
                return 'AVOID - Weak relative performance'
            else:
                return 'NEUTRAL - Wait for better setup'
        
        data['Recommendation'] = data.apply(get_recommendation, axis=1)
        return data
    
    def check_market_regime(self, benchmark_symbol='NIFTY 500'):
        """
        Check market health for Quarterly Momentum Strategy
        Returns market regime and whether to enter full portfolio
        
        Returns:
            dict: {
                'regime': 'BULLISH'/'NEUTRAL'/'BEARISH'/'UNKNOWN',
                'score': int (0-3 conditions met),
                'enter_full': bool,
                'details': dict with all metrics
            }
        """
        try:
            print(f"\n🌡️  CHECKING MARKET REGIME ({benchmark_symbol})...")
            print("-" * 60)
            
            # Get benchmark token
            benchmark_token = self.get_instrument_token(benchmark_symbol)
            if not benchmark_token:
                print(f"⚠️ Could not fetch {benchmark_symbol} data, assuming UNKNOWN regime")
                return {
                    'regime': 'UNKNOWN',
                    'score': 0,
                    'enter_full': True,
                    'details': {}
                }
            
            # Fetch daily data for regime analysis (need 200+ days for SMA)
            end_date = datetime.now()
            start_date = end_date - timedelta(days=250)  # ~200 trading days
            
            data = self.get_historical_data(
                benchmark_token,
                start_date,
                end_date,
                interval='day'
            )
            
            if data.empty or len(data) < QTR_MOMENTUM_CONFIG['nifty_sma_period']:
                print(f"⚠️ Insufficient data for regime analysis")
                return {
                    'regime': 'UNKNOWN',
                    'score': 0,
                    'enter_full': True,
                    'details': {'error': 'Insufficient data'}
                }
            
            # Calculate metrics
            sma_period = QTR_MOMENTUM_CONFIG['nifty_sma_period']
            sma_200 = data['close'].rolling(sma_period).mean().iloc[-1]
            current_price = data['close'].iloc[-1]
            
            # Condition 1: Price > 200 SMA
            above_sma = current_price > sma_200
            
            # Condition 2: Last 20 days positive
            last_20_return = (data['close'].iloc[-1] / data['close'].iloc[-20] - 1) if len(data) >= 20 else 0
            recent_positive = last_20_return > 0
            
            # Condition 3: Volatility not elevated
            returns = data['close'].pct_change().dropna()
            current_vol = returns.iloc[-20:].std() * np.sqrt(252) * 100 if len(returns) >= 20 else 50
            avg_vol = returns.iloc[-60:].std() * np.sqrt(252) * 100 if len(returns) >= 60 else 50
            vol_ok = current_vol < avg_vol * 1.5
            
            # Count conditions met
            conditions_met = sum([above_sma, recent_positive, vol_ok])
            
            # Determine regime
            min_strength = QTR_MOMENTUM_CONFIG['min_market_strength']
            if conditions_met >= min_strength:
                regime = 'BULLISH'
                enter_full = True
                portfolio_size = QTR_MOMENTUM_CONFIG['portfolio_size']
            elif conditions_met == 1:
                regime = 'NEUTRAL'
                enter_full = False
                portfolio_size = QTR_MOMENTUM_CONFIG['portfolio_size'] // 2
            else:
                regime = 'BEARISH'
                enter_full = False
                portfolio_size = 0
            
            details = {
                'current_price': round(current_price, 2),
                'sma_200': round(sma_200, 2),
                'above_sma': above_sma,
                'last_20_days_return': round(last_20_return * 100, 2),
                'recent_positive': recent_positive,
                'current_volatility': round(current_vol, 2),
                'avg_volatility': round(avg_vol, 2),
                'vol_ok': vol_ok,
                'conditions_met': conditions_met,
                'recommended_portfolio_size': portfolio_size
            }
            
            # Print results
            print(f"📊 Market Health Analysis:")
            print(f"   Current Price: ₹{details['current_price']:,.2f}")
            print(f"   200-day SMA:   ₹{details['sma_200']:,.2f}")
            print(f"   Above SMA:     {'✅ YES' if above_sma else '❌ NO'}")
            print(f"   Last 20 days:  {details['last_20_days_return']:+.2f}% {'✅' if recent_positive else '❌'}")
            print(f"   Volatility:    {details['current_volatility']:.1f}% (avg: {details['avg_volatility']:.1f}%) {'✅' if vol_ok else '❌'}")
            print(f"\n🎯 Regime: {regime} ({conditions_met}/3 conditions met)")
            print(f"   Recommended Portfolio Size: {portfolio_size} stocks")
            
            return {
                'regime': regime,
                'score': conditions_met,
                'enter_full': enter_full,
                'details': details
            }
            
        except Exception as e:
            print(f"⚠️ Error checking market regime: {e}")
            return {
                'regime': 'UNKNOWN',
                'score': 0,
                'enter_full': True,
                'details': {'error': str(e)}
            }
    
    def get_qtr_momentum_picks(self, manual_exclude_list=None):
        """
        Generate Top 10 stock picks using Quarterly Momentum Strategy
        Based on backtesting optimizations
        
        Args:
            manual_exclude_list: List of symbols to exclude (e.g., recent losers)
        
        Returns:
            dict with recommended stocks and comprehensive analysis
        """
        try:
            print(f"\n{'='*80}")
            print(f"🚀 QUARTERLY MOMENTUM STRATEGY - STOCK PICKER")
            print(f"{'='*80}")
            print(f"Strategy: {QTR_MOMENTUM_CONFIG['name']}")
            print(f"Description: {QTR_MOMENTUM_CONFIG['description']}")
            print(f"Target Portfolio: {QTR_MOMENTUM_CONFIG['portfolio_size']} stocks")
            print(f"Score Range: {QTR_MOMENTUM_CONFIG['min_score']} - {QTR_MOMENTUM_CONFIG['max_score']}")
            print(f"{'='*80}")
            
            # Step 1: Check market regime
            market_regime = None
            recommended_size = QTR_MOMENTUM_CONFIG['portfolio_size']
            
            if QTR_MOMENTUM_CONFIG['check_market_regime']:
                market_regime = self.check_market_regime(QTR_MOMENTUM_CONFIG['benchmark_for_regime'])
                recommended_size = market_regime['details'].get('recommended_portfolio_size', recommended_size)
                
                if market_regime['regime'] == 'BEARISH':
                    print(f"\n⚠️ BEARISH MARKET REGIME DETECTED")
                    print(f"   Recommendation: Wait for better market conditions or reduce position sizes")
            
            # Step 2: Load and scan all stocks
            print(f"\n📥 Loading stock universe from {DATA_FILE_PATH}...")
            df = pd.read_csv(DATA_FILE_PATH)
            df = df.dropna(subset=[SYMBOL_COLUMN, SECTOR_COLUMN])
            df = df.drop_duplicates(subset=[SYMBOL_COLUMN])
            print(f"✅ Loaded {len(df)} stocks from {len(df[SECTOR_COLUMN].unique())} sectors")
            
            # Step 3: Run RRG analysis with backtester weights
            print(f"\n🔄 Running RRG analysis with backtester-optimized weights...")
            stocks_data = {}
            benchmark_data = None
            
            # Load benchmark
            benchmark_token = self.get_instrument_token(BENCHMARK_INDEX)
            if benchmark_token:
                end_date = datetime.now()
                start_date = end_date - timedelta(weeks=self.weeks_back * 2)
                benchmark_data = self.get_historical_data(benchmark_token, start_date, end_date, 'week')
            
            if benchmark_data is None or benchmark_data.empty:
                print(f"❌ Could not load benchmark data")
                return None
            
            # Load stock data
            print(f"   Loading historical data for stocks...")
            for idx, row in df.iterrows():
                symbol = row[SYMBOL_COLUMN]
                sector = row[SECTOR_COLUMN]
                
                try:
                    token = self.get_instrument_token(symbol)
                    if not token:
                        continue
                    
                    end_date = datetime.now()
                    start_date = end_date - timedelta(weeks=self.weeks_back * 2)
                    stock_data = self.get_historical_data(token, start_date, end_date, 'week')
                    
                    if not stock_data.empty and len(stock_data) >= self.weeks_back:
                        stocks_data[symbol] = {
                            'data': stock_data,
                            'sector': sector
                        }
                    
                    if len(stocks_data) % 100 == 0:
                        print(f"      Loaded {len(stocks_data)} stocks...")
                
                except:
                    continue
            
            print(f"✅ Successfully loaded data for {len(stocks_data)} stocks")
            
            # Step 4: Calculate RRG metrics with BACKTESTER weights
            print(f"\n📊 Calculating RRG metrics with backtester scoring...")
            all_results = []
            errors = []
            
            for symbol, stock_info in stocks_data.items():
                try:
                    stock_data = stock_info['data']
                    sector = stock_info['sector']
                    
                    # Calculate RS ratio and momentum
                    rs_ratio = self.calculate_relative_strength(stock_data, benchmark_data)
                    rs_momentum = self.calculate_rs_momentum(rs_ratio, self.momentum_period)
                    
                    if rs_ratio.empty or rs_momentum.empty:
                        continue
                    
                    # Get latest values
                    current_rs = rs_ratio.iloc[-1]
                    current_momentum = rs_momentum.iloc[-1]
                    
                    # Determine quadrant
                    quadrant = self.get_quadrant(current_rs, current_momentum)
                    
                    # Calculate tail data
                    tail_length = min(self.tail_length, len(rs_ratio))
                    tail_rs = rs_ratio.iloc[-tail_length:].tolist()
                    tail_momentum = rs_momentum.iloc[-tail_length:].tolist()
                    
                    # Calculate tail angle and velocity
                    tail_angle, velocity_factor, movement_direction = \
                        self.calculate_tail_angle_and_velocity(tail_rs, tail_momentum)
                    
                    # Distance from center
                    distance = np.sqrt((current_rs - 100)**2 + (current_momentum - 100)**2)
                    
                    # Build result row
                    result_row = {
                        'Symbol': symbol,
                        'Sector': sector,
                        'RS_Ratio': current_rs,
                        'RS_Momentum': current_momentum,
                        'Quadrant': quadrant,
                        'Distance_from_Center': distance,
                        'Tail_Angle': tail_angle,
                        'Velocity_Factor': velocity_factor,
                        'Movement_Direction': movement_direction,
                        'Current_Price': stock_data['close'].iloc[-1]
                    }
                    
                    # Calculate Opportunity Score using BACKTESTER weights
                    weights = QTR_MOMENTUM_CONFIG['scoring_weights']
                    score = 0.0
                    
                    # Base quadrant score
                    score += weights['quadrant_scores'].get(quadrant, 0)
                    
                    # RS ratio bonus
                    score += current_rs * weights['rs_ratio_multiplier']
                    
                    # Momentum bonus
                    score += current_momentum * weights['momentum_multiplier']
                    
                    # Distance bonus
                    score += distance * weights['distance_multiplier']
                    
                    # Movement direction bonuses
                    if movement_direction == 'Toward Leading':
                        score += weights['movement_bonuses']['toward_leading']
                    elif movement_direction == 'Toward Improving':
                        score += weights['movement_bonuses']['toward_improving']
                    elif movement_direction == 'Toward Lagging':
                        score += weights['movement_bonuses']['toward_lagging_penalty']
                    
                    # Velocity bonus
                    if velocity_factor > 0:
                        velocity_bonus = min(velocity_factor / 10, 1.0) * weights['velocity_max_bonus']
                        score += velocity_bonus
                    
                    result_row['Opportunity_Score'] = max(0, score)
                    all_results.append(result_row)
                
                except Exception as e:
                    errors.append(f"{symbol}: {str(e)}")
                    continue
            
            # Create DataFrame
            rrg_df = pd.DataFrame(all_results)
            print(f"✅ Analyzed {len(rrg_df)} stocks")
            
            if errors and len(errors) <= 10:
                print(f"⚠️ Errors for {len(errors)} stocks: {', '.join(errors[:5])}")
            elif errors:
                print(f"⚠️ Errors for {len(errors)} stocks (showing sample)")
            
            if rrg_df.empty:
                print(f"❌ No stocks could be analyzed. Check data availability.")
                return None
            
            # Step 5: Apply filters
            print(f"\n🔍 Applying strategy filters...")
            filtered = rrg_df.copy()
            
            # Filter 1: Score range
            initial_count = len(filtered)
            filtered = filtered[
                (filtered['Opportunity_Score'] >= QTR_MOMENTUM_CONFIG['min_score']) &
                (filtered['Opportunity_Score'] <= QTR_MOMENTUM_CONFIG['max_score'])
            ]
            print(f"   Score filter ({QTR_MOMENTUM_CONFIG['min_score']}-{QTR_MOMENTUM_CONFIG['max_score']}): {initial_count} → {len(filtered)} stocks")
            
            # Filter 2: Exclude sectors
            if QTR_MOMENTUM_CONFIG['exclude_sectors']:
                initial_count = len(filtered)
                filtered = filtered[~filtered['Sector'].isin(QTR_MOMENTUM_CONFIG['exclude_sectors'])]
                print(f"   Sector filter: {initial_count} → {len(filtered)} stocks")
            
            # Filter 3: Manual exclusions
            if manual_exclude_list:
                initial_count = len(filtered)
                filtered = filtered[~filtered['Symbol'].isin(manual_exclude_list)]
                print(f"   Manual exclusions: {initial_count} → {len(filtered)} stocks")
            
            # Filter 4: Prefer Leading quadrant
            if QTR_MOMENTUM_CONFIG['prefer_leading']:
                leading_stocks = filtered[filtered['Quadrant'] == 'Leading'].nlargest(recommended_size, 'Opportunity_Score')
                
                if len(leading_stocks) < recommended_size:
                    remaining = recommended_size - len(leading_stocks)
                    other_stocks = filtered[
                        (filtered['Quadrant'] != 'Leading') &
                        (~filtered['Symbol'].isin(leading_stocks['Symbol']))
                    ].nlargest(remaining, 'Opportunity_Score')
                    
                    top_picks = pd.concat([leading_stocks, other_stocks])
                else:
                    top_picks = leading_stocks
            else:
                top_picks = filtered.nlargest(recommended_size, 'Opportunity_Score')
            
            # Sort by score
            top_picks = top_picks.sort_values('Opportunity_Score', ascending=False).reset_index(drop=True)
            
            print(f"\n✅ Selected {len(top_picks)} stocks for portfolio")
            print(f"   Avg Score: {top_picks['Opportunity_Score'].mean():.1f}")
            print(f"   Leading: {len(top_picks[top_picks['Quadrant']=='Leading'])} | "
                  f"Improving: {len(top_picks[top_picks['Quadrant']=='Improving'])} | "
                  f"Weakening: {len(top_picks[top_picks['Quadrant']=='Weakening'])} | "
                  f"Lagging: {len(top_picks[top_picks['Quadrant']=='Lagging'])}")
            
            # Step 6: Generate recommendations
            from dateutil.relativedelta import relativedelta
            today = datetime.now()
            
            # Calculate next quarter end
            if today.month <= 3:
                next_quarter_end = datetime(today.year, 3, 31)
            elif today.month <= 6:
                next_quarter_end = datetime(today.year, 6, 30)
            elif today.month <= 9:
                next_quarter_end = datetime(today.year, 9, 30)
            else:
                next_quarter_end = datetime(today.year, 12, 31)
            
            # If we're past the quarter end, move to next quarter
            if today > next_quarter_end:
                next_quarter_end = next_quarter_end + relativedelta(months=3)
                # Adjust for quarter end dates
                if next_quarter_end.month == 3:
                    next_quarter_end = datetime(next_quarter_end.year, 3, 31)
                elif next_quarter_end.month == 6:
                    next_quarter_end = datetime(next_quarter_end.year, 6, 30)
                elif next_quarter_end.month == 9:
                    next_quarter_end = datetime(next_quarter_end.year, 9, 30)
                else:
                    next_quarter_end = datetime(next_quarter_end.year, 12, 31)
            
            # Prepare output
            result = {
                'strategy': QTR_MOMENTUM_CONFIG['name'],
                'generated_date': today.strftime('%Y-%m-%d'),
                'entry_date': today.strftime('%Y-%m-%d'),
                'next_rebalance_date': next_quarter_end.strftime('%Y-%m-%d'),
                'market_regime': market_regime,
                'recommended_portfolio_size': recommended_size,
                'actual_picks': len(top_picks),
                'allocation_per_stock': f"{100/len(top_picks):.2f}%" if len(top_picks) > 0 else "0%",
                'avg_opportunity_score': round(top_picks['Opportunity_Score'].mean(), 2) if len(top_picks) > 0 else 0,
                'top_picks': top_picks,
                'filters_applied': {
                    'min_score': QTR_MOMENTUM_CONFIG['min_score'],
                    'max_score': QTR_MOMENTUM_CONFIG['max_score'],
                    'prefer_leading': QTR_MOMENTUM_CONFIG['prefer_leading'],
                    'excluded_sectors': QTR_MOMENTUM_CONFIG['exclude_sectors'],
                    'manual_exclusions': manual_exclude_list or []
                }
            }
            
            return result
            
        except Exception as e:
            print(f"❌ Error generating momentum picks: {e}")
            import traceback
            traceback.print_exc()
            return None

# Example usage and custom scanner functions
class AdvancedRRGScanner(RRGScanner):
    """
    Extended RRG Scanner with additional features
    """
    
    def scan_custom_stocks(self, stock_list, benchmark='NIFTY 50'):
        """
        Scan custom list of stocks instead of sectors
        
        Args:
            stock_list: List of stock symbols to analyze
            benchmark: Benchmark index (default: NIFTY 50)
        
        Returns:
            RRG analysis for the stock list
        """
        print(f"🔍 Scanning {len(stock_list)} custom stocks vs {benchmark}...")
        
        # Similar implementation as calculate_rrg_data but for individual stocks
        end_date = datetime.now()
        start_date = end_date - timedelta(weeks=21)
        
        # Get benchmark data
        benchmark_token = self.get_instrument_token(benchmark)
        benchmark_data = self.get_historical_data(
            benchmark_token, start_date, end_date, 'week'
        )
        
        results = []
        for stock in stock_list:
            try:
                stock_token = self.get_instrument_token(stock)
                if not stock_token:
                    print(f"Skipping {stock}: No instrument token found")
                    continue
                    
                stock_data = self.get_historical_data(
                    stock_token, start_date, end_date, 'week'
                )
                
                if stock_data.empty:
                    print(f"Skipping {stock}: No data available")
                    continue
                
                rs_ratio = self.calculate_relative_strength(stock_data, benchmark_data)
                rs_momentum = self.calculate_rs_momentum(rs_ratio)
                
                current_rs = rs_ratio.iloc[-1]
                current_momentum = rs_momentum.iloc[-1]
                quadrant = self.get_quadrant(current_rs, current_momentum)
                
                # Calculate tail data for visualization
                tail_length = min(self.tail_length, len(rs_ratio))
                tail_rs = rs_ratio.iloc[-tail_length:].tolist()
                tail_momentum = rs_momentum.iloc[-tail_length:].tolist()
                
                results.append({
                    'Stock': stock,
                    'RS_Ratio': current_rs,
                    'RS_Momentum': current_momentum,
                    'Quadrant': quadrant,
                    'Tail_RS': tail_rs,
                    'Tail_Momentum': tail_momentum,
                    'Distance_from_Center': np.sqrt((current_rs - 100)**2 + (current_momentum - 100)**2)
                })
                
                print(f"✓ Processed {stock}: {quadrant}")
                
            except Exception as e:
                print(f"✗ Error processing {stock}: {e}")
                continue
        
        return pd.DataFrame(results)
    
    def scan_stocks_from_csv(self, csv_file_path, symbol_column='Symbol', benchmark='NIFTY 50'):
        """
        Scan stocks from a CSV file
        
        Args:
            csv_file_path: Path to CSV file containing stock symbols
            symbol_column: Name of the column containing stock symbols (default: 'Symbol')
            benchmark: Benchmark index (default: NIFTY 50)
        
        Returns:
            RRG analysis for the stocks in the CSV file
        """
        try:
            # Read CSV file
            df = pd.read_csv(csv_file_path)
            
            if symbol_column not in df.columns:
                print(f"❌ Column '{symbol_column}' not found in CSV file")
                print(f"Available columns: {list(df.columns)}")
                return pd.DataFrame()
            
            # Extract stock symbols
            stock_list = df[symbol_column].dropna().unique().tolist()
            
            print(f"📁 Loaded {len(stock_list)} stocks from {csv_file_path}")
            print(f"Stocks: {', '.join(stock_list[:10])}{'...' if len(stock_list) > 10 else ''}")
            
            # Perform RRG analysis
            results = self.scan_custom_stocks(stock_list, benchmark)
            
            if not results.empty:
                # Print results by quadrant
                self._print_stock_results(results)
                
                # Generate summary
                summary = self._generate_stock_summary(results)
                print(f"\n💡 {summary}")
            
            return results
            
        except FileNotFoundError:
            print(f"❌ CSV file not found: {csv_file_path}")
            return pd.DataFrame()
        except Exception as e:
            print(f"❌ Error reading CSV file: {e}")
            return pd.DataFrame()
    
    def _print_stock_results(self, results):
        """Print stock analysis results by quadrant"""
        leading = results[results['Quadrant'] == 'Leading'].sort_values('Distance_from_Center', ascending=False)
        weakening = results[results['Quadrant'] == 'Weakening'].sort_values('RS_Ratio', ascending=False)
        lagging = results[results['Quadrant'] == 'Lagging'].sort_values('Distance_from_Center')
        improving = results[results['Quadrant'] == 'Improving'].sort_values('RS_Momentum', ascending=False)
        
        print("\n📈 LEADING QUADRANT (Buy Focus):")
        print("-" * 40)
        for _, row in leading.iterrows():
            print(f"  • {row['Stock']:<15} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
        
        print("\n📉 WEAKENING QUADRANT (Monitor/Correction):")
        print("-" * 40)
        for _, row in weakening.iterrows():
            print(f"  • {row['Stock']:<15} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
        
        print("\n🔻 LAGGING QUADRANT (Avoid/Value Play):")
        print("-" * 40)
        for _, row in lagging.iterrows():
            print(f"  • {row['Stock']:<15} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
        
        print("\n📊 IMPROVING QUADRANT (Early Entry):")
        print("-" * 40)
        for _, row in improving.iterrows():
            print(f"  • {row['Stock']:<15} | RS: {row['RS_Ratio']:.2f} | Momentum: {row['RS_Momentum']:.2f}")
    
    def _generate_stock_summary(self, results):
        """Generate summary for stock analysis"""
        leading_count = len(results[results['Quadrant'] == 'Leading'])
        improving_count = len(results[results['Quadrant'] == 'Improving'])
        total_strong = leading_count + improving_count
        
        if total_strong >= len(results) * 0.6:
            return f"🟢 Strong stock selection with {total_strong}/{len(results)} stocks in buy zones"
        elif total_strong >= len(results) * 0.3:
            return f"🟡 Moderate opportunity with {total_strong}/{len(results)} strong stocks"
        else:
            return f"🔴 Limited strength with only {total_strong}/{len(results)} strong stocks"
    
    def get_top_opportunities(self, results, top_n=10):
        """
        Get top N opportunities based on intelligent scoring with tail angle and velocity
        
        Args:
            results: DataFrame with RRG analysis results
            top_n: Number of top opportunities to return
            
        Returns:
            DataFrame with top opportunities including tail analysis
        """
        if results.empty:
            return pd.DataFrame()
        
        # Add comprehensive opportunity scores with tail angle and velocity
        results = self._add_opportunity_scores(results)
        
        # Sort by opportunity score and return top N
        top_opportunities = results.nlargest(top_n, 'Opportunity_Score')
        
        # Select relevant columns for display
        display_columns = ['Stock', 'RS_Ratio', 'RS_Momentum', 'Quadrant', 
                          'Distance_from_Center', 'Tail_Angle', 'Velocity_Factor', 
                          'Movement_Direction', 'Opportunity_Score']
        
        # Only include columns that exist in the dataframe
        available_columns = [col for col in display_columns if col in top_opportunities.columns]
        
        return top_opportunities[available_columns]
    
    def export_comprehensive_csv(self, results, filename=None, include_analysis=True):
        """
        Export comprehensive results to CSV with detailed scoring and analysis
        
        Args:
            results: DataFrame with RRG analysis results
            filename: Output filename (auto-generated if None)
            include_analysis: Whether to include comprehensive analysis columns
        """
        if results.empty:
            print("❌ No results to export")
            return None
        
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"rrg_comprehensive_analysis_{timestamp}.csv"
        
        try:
            # Generate comprehensive analysis if requested
            if include_analysis:
                export_data = self.generate_comprehensive_analysis(results)
            else:
                export_data = results.copy()
            
            # Round numerical columns
            numeric_columns = ['RS_Ratio', 'RS_Momentum', 'Distance_from_Center', 
                             'Opportunity_Score', 'Tail_Angle', 'Velocity_Factor']
            for col in numeric_columns:
                if col in export_data.columns:
                    export_data[col] = export_data[col].round(2)
            
            # Define column order for better readability
            # In export_comprehensive_csv method, update column_order:
            column_order = [
                'Stock', 'Sector', 'RS_Ratio', 'RS_Momentum', 'Quadrant', 
                'Opportunity_Score', 'Recommendation', 'Trend_Strength', 
                'Momentum_Quality', 'Risk_Level', 'Tail_Quality', 'Risk_Comment',
                'Position_Size', 'Time_Horizon',
                'Distance_from_Center', 'Tail_Angle', 'Velocity_Factor', 
                'Movement_Direction', 'Path_Volatility', 'Risk_Signals'
            ]
            # Reorder columns (only include existing columns)
            existing_columns = [col for col in column_order if col in export_data.columns]
            remaining_columns = [col for col in export_data.columns if col not in existing_columns]
            final_column_order = existing_columns + remaining_columns
            
            export_data = export_data[final_column_order]
            
            # Sort by opportunity score (highest first)
            if 'Opportunity_Score' in export_data.columns:
                export_data = export_data.sort_values('Opportunity_Score', ascending=False)
            
            # Add ranking column
            export_data.insert(0, 'Rank', range(1, len(export_data) + 1))
            
            # Export to CSV
            export_data.to_csv(filename, index=False)
            
            # Print summary statistics
            self._print_export_summary(export_data, filename)
            
            return filename
            
        except Exception as e:
            print(f"❌ Error exporting to CSV: {e}")
            return None
    
    def _print_export_summary(self, data, filename):
        """Print summary statistics for the exported data"""
        print(f"\n💾 Comprehensive analysis exported to: {filename}")
        print(f"📊 Total stocks analyzed: {len(data)}")
        
        if 'Recommendation' in data.columns:
            rec_counts = data['Recommendation'].value_counts()
            print(f"\n📈 Recommendation Summary:")
            for rec, count in rec_counts.items():
                print(f"  • {rec}: {count} stocks")
        
        if 'Quadrant' in data.columns:
            quad_counts = data['Quadrant'].value_counts()
            print(f"\n🎯 Quadrant Distribution:")
            for quad, count in quad_counts.items():
                print(f"  • {quad}: {count} stocks")
        
        if 'Opportunity_Score' in data.columns:
            top_5 = data.head(5)
            print(f"\n🏆 Top 5 Opportunities:")
            for _, row in top_5.iterrows():
                print(f"  {row['Rank']}. {row.get('Stock', 'N/A')} - Score: {row['Opportunity_Score']:.1f} - {row.get('Recommendation', 'N/A')}")
        
        print(f"\n📋 Columns included: {len(data.columns)}")
        print(f"📝 Key metrics: RS Ratio, RS Momentum, Opportunity Score, Recommendations, Risk Assessment")
    
    def create_master_summary_csv(self, combined_results, filename):
        """
        Create a master summary CSV with top opportunities across all sectors
        Focus on Leading and Improving quadrants with highest scores
        """
        if combined_results.empty:
            print("❌ No data for master summary")
            return None
        
        try:
            # Filter for Leading and Improving quadrants only
            top_quadrants = combined_results[combined_results['Quadrant'].isin(['Leading', 'Improving'])]
            
            if top_quadrants.empty:
                print("⚠️ No Leading or Improving opportunities found")
                return None
            
            # Clean data - remove rows with NaN Opportunity_Score
            top_quadrants = top_quadrants.dropna(subset=['Opportunity_Score'])
            
            if top_quadrants.empty:
                print("⚠️ No valid opportunities found after cleaning")
                return None
            
            # Sort by opportunity score
            top_quadrants = top_quadrants.sort_values('Opportunity_Score', ascending=False)
            
            # Create master summary with key columns
            master_columns = [
                'Rank', 'Stock', 'Sector', 'Quadrant', 'Opportunity_Score', 
                'Recommendation', 'RS_Ratio', 'RS_Momentum', 'Trend_Strength',
                'Momentum_Quality', 'Risk_Level', 'Position_Size', 'Time_Horizon',
                'Distance_from_Center', 'Movement_Direction'
            ]
            
            # Select only existing columns
            available_columns = [col for col in master_columns if col in top_quadrants.columns]
            master_summary = top_quadrants[available_columns].copy()
            
            # Add ranking
            master_summary.insert(0, 'Overall_Rank', range(1, len(master_summary) + 1))
            
            # Add opportunity tier
            master_summary['Opportunity_Tier'] = master_summary['Opportunity_Score'].apply(self._get_opportunity_tier)
            
            # Add sector rank within each sector (handle NaN values)
            master_summary['Sector_Rank'] = master_summary.groupby('Sector')['Opportunity_Score'].rank(ascending=False, method='dense')
            master_summary['Sector_Rank'] = master_summary['Sector_Rank'].fillna(999).astype(int)
            
            # Add quick action recommendation
            master_summary['Quick_Action'] = master_summary.apply(self._get_quick_action, axis=1)
            
            # Export to CSV
            master_summary.to_csv(filename, index=False)
            
            print(f"🎯 Master Summary exported to: {filename}")
            print(f"📊 Top opportunities: {len(master_summary)} stocks from Leading/Improving quadrants")
            
            # Print top opportunities for quick review
            print(f"\n🏆 TOP {TOP_OVERALL_DISPLAY} OPPORTUNITIES (Master Summary):")
            print("-" * 80)
            for i, (_, row) in enumerate(master_summary.head(TOP_OVERALL_DISPLAY).iterrows(), 1):
                print(f"{i:2d}. {row['Stock']:<12} | {row['Sector']:<18} | {row['Quadrant']:<10} | "
                      f"Score: {row['Opportunity_Score']:.1f} | {row['Quick_Action']}")
            
            return filename
            
        except Exception as e:
            print(f"❌ Error creating master summary: {e}")
            return None
    
    def create_sector_leaders_csv(self, combined_results, filename):
        """
        Create sector leaders CSV - top 3 opportunities from each sector
        """
        if combined_results.empty:
            print("❌ No data for sector leaders")
            return None
        
        try:
            sector_leaders = []
            
            # Get top stocks from each sector
            for sector in combined_results['Sector'].unique():
                sector_data = combined_results[combined_results['Sector'] == sector]
                top_stocks = sector_data.nlargest(SECTOR_LEADERS_COUNT, 'Opportunity_Score')
                
                for idx, (_, row) in enumerate(top_stocks.iterrows(), 1):
                    row_dict = row.to_dict()
                    row_dict['Sector_Rank'] = idx
                    sector_leaders.append(row_dict)
            
            sector_leaders_df = pd.DataFrame(sector_leaders)
            
            if sector_leaders_df.empty:
                print("⚠️ No sector leaders found")
                return None
            
            # Sort by overall opportunity score
            sector_leaders_df = sector_leaders_df.sort_values('Opportunity_Score', ascending=False)
            sector_leaders_df.insert(0, 'Overall_Rank', range(1, len(sector_leaders_df) + 1))
            
            # Select key columns
            key_columns = [
                'Overall_Rank', 'Sector_Rank', 'Stock', 'Sector', 'Quadrant', 
                'Opportunity_Score', 'Recommendation', 'RS_Ratio', 'RS_Momentum',
                'Trend_Strength', 'Risk_Level', 'Position_Size'
            ]
            
            available_columns = [col for col in key_columns if col in sector_leaders_df.columns]
            sector_leaders_summary = sector_leaders_df[available_columns]
            
            # Export to CSV
            sector_leaders_summary.to_csv(filename, index=False)
            
            print(f"📊 Sector Leaders exported to: {filename}")
            print(f"📈 Top {SECTOR_LEADERS_COUNT} from each sector: {len(sector_leaders_summary)} stocks")
            
            return filename
            
        except Exception as e:
            print(f"❌ Error creating sector leaders: {e}")
            return None
    
    def create_opportunity_tiers_csv(self, combined_results, filename):
        """
        Create opportunity tiers CSV - categorize opportunities into tiers
        """
        if combined_results.empty:
            print("❌ No data for opportunity tiers")
            return None
        
        try:
            # Filter for Leading and Improving only
            opportunities = combined_results[combined_results['Quadrant'].isin(['Leading', 'Improving'])]
            
            if opportunities.empty:
                print("⚠️ No opportunities found for tiering")
                return None
            
            # Clean data - remove rows with NaN Opportunity_Score
            opportunities = opportunities.dropna(subset=['Opportunity_Score'])
            
            if opportunities.empty:
                print("⚠️ No valid opportunities found after cleaning")
                return None
            
            # Sort by opportunity score
            opportunities = opportunities.sort_values('Opportunity_Score', ascending=False)
            
            # Create tiers based on opportunity score
            opportunities['Tier'] = opportunities['Opportunity_Score'].apply(self._get_opportunity_tier)
            
            # Add tier-specific recommendations
            opportunities['Tier_Action'] = opportunities.apply(self._get_tier_action, axis=1)
            
            # Group by tiers and add tier ranking (handle NaN values)
            opportunities['Tier_Rank'] = opportunities.groupby('Tier')['Opportunity_Score'].rank(ascending=False, method='dense')
            opportunities['Tier_Rank'] = opportunities['Tier_Rank'].fillna(999).astype(int)
            
            # Select key columns
            tier_columns = [
                'Tier', 'Tier_Rank', 'Stock', 'Sector', 'Quadrant', 'Opportunity_Score',
                'Recommendation', 'Tier_Action', 'RS_Ratio', 'RS_Momentum', 
                'Trend_Strength', 'Risk_Level', 'Position_Size', 'Time_Horizon'
            ]
            
            available_columns = [col for col in tier_columns if col in opportunities.columns]
            tiers_summary = opportunities[available_columns]
            
            # Sort by tier and then by tier rank
            tiers_summary = tiers_summary.sort_values(['Tier', 'Tier_Rank'])
            
            # Export to CSV
            tiers_summary.to_csv(filename, index=False)
            
            print(f"🏆 Opportunity Tiers exported to: {filename}")
            
            # Print tier summary
            tier_counts = tiers_summary['Tier'].value_counts().sort_index()
            print(f"\n📊 Tier Distribution:")
            for tier, count in tier_counts.items():
                print(f"  • {tier}: {count} stocks")
            
            return filename
            
        except Exception as e:
            print(f"❌ Error creating opportunity tiers: {e}")
            return None
    
    def _get_opportunity_tier(self, score):
        """Determine opportunity tier based on score"""
        if score >= 200:
            return 'Tier 1 - Elite'
        elif score >= 150:
            return 'Tier 2 - Strong'
        elif score >= 100:
            return 'Tier 3 - Good'
        elif score >= 75:
            return 'Tier 4 - Fair'
        else:
            return 'Tier 5 - Weak'
    
    def _get_quick_action(self, row):
        """Get quick action recommendation"""
        score = row['Opportunity_Score']
        quadrant = row['Quadrant']
        risk = row.get('Risk_Level', 'Medium')
        
        if score >= 200 and quadrant == 'Leading' and risk == 'Low':
            return 'IMMEDIATE BUY'
        elif score >= 150 and quadrant in ['Leading', 'Improving']:
            return 'STRONG BUY'
        elif score >= 100:
            return 'BUY'
        elif score >= 75:
            return 'WATCH'
        else:
            return 'AVOID'
    
    def _get_tier_action(self, row):
        """Get tier-specific action"""
        tier = row['Tier']
        risk = row.get('Risk_Level', 'Medium')
        
        if 'Elite' in tier:
            return 'High Conviction - Allocate 5-10%'
        elif 'Strong' in tier:
            return 'Strong Buy - Allocate 3-5%'
        elif 'Good' in tier:
            return 'Buy - Allocate 1-3%'
        elif 'Fair' in tier:
            return 'Watch List - Small position'
        else:
            return 'Avoid - Monitor only'
    
    def _calculate_tail_angle_and_velocity(self, results):
        """
        Calculate tail angle and velocity factor for each stock
        
        Args:
            results: DataFrame with RRG analysis results
            
        Returns:
            DataFrame with added Tail_Angle and Velocity_Factor columns
        """
        results = results.copy()
        results['Tail_Angle'] = 0.0
        results['Velocity_Factor'] = 0.0
        results['Movement_Direction'] = 'Unknown'
        
        for idx, row in results.iterrows():
            try:
                tail_rs = row.get('Tail_RS', [])
                tail_momentum = row.get('Tail_Momentum', [])
                
                if len(tail_rs) >= 3 and len(tail_momentum) >= 3:
                    # Calculate deltas for last 3 points
                    delta_rs = tail_rs[-1] - tail_rs[-3]  # Last point - 3rd last point
                    delta_momentum = tail_momentum[-1] - tail_momentum[-3]
                    
                    # Calculate angle using atan2 (returns angle in radians)
                    angle_radians = math.atan2(delta_momentum, delta_rs)
                    angle_degrees = math.degrees(angle_radians)
                    
                    # Normalize angle to 0-360 degrees
                    if angle_degrees < 0:
                        angle_degrees += 360
                    
                    results.at[idx, 'Tail_Angle'] = angle_degrees
                    
                    # Calculate velocity (magnitude of movement)
                    velocity = math.sqrt(delta_rs**2 + delta_momentum**2)
                    results.at[idx, 'Velocity_Factor'] = velocity
                    
                    # Determine movement direction
                    if 0 <= angle_degrees <= 90:
                        results.at[idx, 'Movement_Direction'] = 'Toward Leading'
                    elif 90 < angle_degrees <= 180:
                        results.at[idx, 'Movement_Direction'] = 'Toward Weakening'
                    elif 180 < angle_degrees <= 270:
                        results.at[idx, 'Movement_Direction'] = 'Toward Lagging'
                    else:  # 270 < angle_degrees <= 360
                        results.at[idx, 'Movement_Direction'] = 'Toward Improving'
                        
            except Exception as e:
                # If calculation fails, keep default values
                continue
                
        return results
    
    def _add_opportunity_scores(self, results):
        """Add opportunity scores to results with tail angle and velocity factors"""
        results = results.copy()
        
        # First calculate tail angle and velocity
        results = self._calculate_tail_angle_and_velocity(results)
        
        results['Opportunity_Score'] = 0.0
        
        # Get scoring weights
        weights = self.scoring_weights
        
        # Base quadrant scores (configurable)
        quadrant_scores = weights['quadrant_scores']
        for quadrant, score in quadrant_scores.items():
            mask = results['Quadrant'] == quadrant
            results.loc[mask, 'Opportunity_Score'] += score
        
        # RS ratio bonus (configurable multiplier)
        results['Opportunity_Score'] += results['RS_Ratio'] * weights['rs_ratio_multiplier']
        
        # Momentum bonus (configurable multiplier)
        results['Opportunity_Score'] += results['RS_Momentum'] * weights['momentum_multiplier']
        
        # Distance from center bonus (configurable multiplier)
        results['Opportunity_Score'] += results['Distance_from_Center'] * weights['distance_multiplier']
        
        # Movement bonuses (configurable)
        movement_bonuses = weights['movement_bonuses']
        
        # Movement toward Leading quadrant
        toward_leading_mask = results['Movement_Direction'] == 'Toward Leading'
        results.loc[toward_leading_mask, 'Opportunity_Score'] += movement_bonuses['toward_leading']
        
        # Movement toward Improving quadrant
        toward_improving_mask = results['Movement_Direction'] == 'Toward Improving'
        results.loc[toward_improving_mask, 'Opportunity_Score'] += movement_bonuses['toward_improving']
        
        # VELOCITY FACTOR BONUS - Higher velocity = stronger momentum
        # Normalize velocity and add as bonus (configurable max)
        max_velocity = results['Velocity_Factor'].max()
        if max_velocity > 0:
            velocity_bonus = (results['Velocity_Factor'] / max_velocity) * weights['velocity_max_bonus']
            results['Opportunity_Score'] += velocity_bonus
        
        # PENALTY for moving away from Leading quadrant
        away_from_leading_mask = results['Movement_Direction'] == 'Toward Lagging'
        results.loc[away_from_leading_mask, 'Opportunity_Score'] += movement_bonuses['toward_lagging_penalty']
        
        # Ensure no negative scores
        results['Opportunity_Score'] = results['Opportunity_Score'].clip(lower=0)
        
        return results
    
    def get_sector_stocks(self, sector_name):
        """
        Get list of stocks belonging to a specific sector
        This would need to be implemented based on your data source
        """
        # Placeholder - in practice, you'd maintain a mapping of stocks to sectors
        sector_stocks = {
            'NIFTY IT': ['TCS', 'INFY', 'HCLTECH', 'WIPRO', 'TECHM'],
            'NIFTY BANK': ['HDFCBANK', 'ICICIBANK', 'AXISBANK', 'KOTAKBANK', 'SBIN'],
            'NIFTY PHARMA': ['SUNPHARMA', 'DRREDDY', 'CIPLA', 'DIVISLAB', 'LUPIN'],
            # Add more sectors as needed
        }
        
        return sector_stocks.get(sector_name, [])
    
    def dual_timeframe_analysis(self):
        """
        Analyze RRG on both weekly and monthly timeframes for confirmation
        """
        print("🔍 Running Dual Timeframe RRG Analysis...")
        
        weekly_data = self.calculate_rrg_data(weeks_back=21, momentum_period=5)
        # For monthly, you'd modify the interval parameter in get_historical_data
        
        # Compare weekly vs monthly signals
        analysis = {}
        for _, weekly_row in weekly_data.iterrows():
            sector = weekly_row['Sector']
            weekly_quad = weekly_row['Quadrant']
            
            # Monthly analysis would be similar
            analysis[sector] = {
                'weekly': weekly_quad,
                'monthly': 'Leading',  # Placeholder
                'confluence': weekly_quad == 'Leading'  # Simplified
            }
        
        return analysis

# Add these methods to your AdvancedRRGScanner class

    def _calculate_tail_risk_metrics(self, tail_rs, tail_momentum):
        """
        Extract detailed risk signals from tail behavior
        
        Returns:
            dict with risk_score, signals list, and detailed metrics
        """
        if not isinstance(tail_rs, list) or len(tail_rs) < 5:
            return {
                'risk_score': 0,
                'signals': [],
                'path_volatility': 0,
                'momentum_divergence': False,
                'whipsaw_count': 0,
                'deceleration': False
            }
        
        risk_signals = []
        risk_score = 0
        
        try:
            # Convert to numpy arrays for easier calculation
            tail_rs = np.array(tail_rs)
            tail_momentum = np.array(tail_momentum)
            
            # 1. PATH CONSISTENCY - measure volatility of changes
            rs_changes = np.diff(tail_rs)
            mom_changes = np.diff(tail_momentum)
            rs_volatility = np.std(rs_changes)
            mom_volatility = np.std(mom_changes)
            avg_volatility = (rs_volatility + mom_volatility) / 2
            
            if rs_volatility > 15 or mom_volatility > 15:
                risk_score += 2
                risk_signals.append('Erratic_Path')
            
            # 2. MOMENTUM DIVERGENCE - RS rising but momentum falling
            rs_trend = tail_rs[-1] - tail_rs[-4] if len(tail_rs) >= 4 else 0
            mom_trend = tail_momentum[-1] - tail_momentum[-4] if len(tail_momentum) >= 4 else 0
            
            divergence = False
            if rs_trend > 5 and mom_trend < -5:
                risk_score += 3
                risk_signals.append('Bearish_Divergence')
                divergence = True
            elif rs_trend < -5 and mom_trend > 5:
                risk_signals.append('Bullish_Divergence')
            
            # 3. WHIPSAW DETECTION - count direction changes
            whipsaw_count = 0
            for i in range(1, len(rs_changes)-1):
                if (rs_changes[i-1] * rs_changes[i]) < 0:  # Direction change
                    whipsaw_count += 1
            
            if whipsaw_count > 3:
                risk_score += 2
                risk_signals.append('Whipsaw_Pattern')
            
            # 4. DECELERATION - slowing velocity
            deceleration = False
            if len(tail_rs) >= 5:
                early_velocity = abs(tail_rs[-3] - tail_rs[-5])
                recent_velocity = abs(tail_rs[-1] - tail_rs[-3])
                
                if early_velocity > 10 and recent_velocity < early_velocity * 0.5:
                    risk_score += 2
                    risk_signals.append('Decelerating')
                    deceleration = True
            
            # 5. MOMENTUM SPIKE - unsustainable surge
            if len(mom_changes) >= 2:
                last_mom_change = mom_changes[-1]
                avg_mom_change = np.mean(mom_changes[:-1])
                
                if last_mom_change > avg_mom_change * 2 and last_mom_change > 10:
                    risk_score += 2
                    risk_signals.append('Momentum_Spike')
            
            # 6. ANGLE REVERSAL - sharp turn in trajectory
            if len(tail_rs) >= 6:
                old_angle = math.atan2(
                    tail_momentum[-4] - tail_momentum[-6], 
                    tail_rs[-4] - tail_rs[-6]
                )
                new_angle = math.atan2(
                    tail_momentum[-1] - tail_momentum[-3], 
                    tail_rs[-1] - tail_rs[-3]
                )
                
                angle_change = abs(math.degrees(new_angle - old_angle))
                
                if angle_change > 45:
                    risk_score += 2
                    risk_signals.append('Sharp_Angle_Change')
            
            return {
                'risk_score': risk_score,
                'signals': risk_signals,
                'path_volatility': round(avg_volatility, 2),
                'momentum_divergence': divergence,
                'whipsaw_count': whipsaw_count,
                'deceleration': deceleration
            }
            
        except Exception as e:
            print(f"Error in tail risk calculation: {e}")
            return {
                'risk_score': 0,
                'signals': [],
                'path_volatility': 0,
                'momentum_divergence': False,
                'whipsaw_count': 0,
                'deceleration': False
            }

    def _calculate_risk_level_enhanced(self, row):
        """
        Enhanced risk calculation using position, velocity, angle, and tail behavior
        """
        quadrant = row['Quadrant']
        distance = row['Distance_from_Center']
        velocity = row.get('Velocity_Factor', 0)
        tail_angle = row.get('Tail_Angle', 0)
        movement_dir = row.get('Movement_Direction', 'Unknown')
        tail_rs = row.get('Tail_RS', [])
        tail_momentum = row.get('Tail_Momentum', [])
        
        risk_score = 0
        
        # 1. Base quadrant risk
        base_risk = {
            'Leading': 0,
            'Improving': 1,
            'Weakening': 3,
            'Lagging': 4
        }
        risk_score += base_risk.get(quadrant, 2)
        
        # 2. Tail behavior analysis
        tail_metrics = self._calculate_tail_risk_metrics(tail_rs, tail_momentum)
        risk_score += tail_metrics['risk_score']
        
        # 3. Position extremes
        if distance > 150:
            risk_score += 3  # Overextended - mean reversion risk
        elif distance > 100:
            risk_score += 1  # Extended
        elif distance < 20 and quadrant in ['Leading', 'Improving']:
            risk_score -= 1  # Early in move - lower risk
        
        # 4. Velocity analysis
        if velocity > 40:
            risk_score += 2  # Too fast - unstable
        elif velocity > 25:
            risk_score += 1  # Fast but manageable
        elif velocity < 2 and quadrant in ['Leading', 'Improving']:
            risk_score += 1  # Stalling momentum
        
        # 5. Angle-based directional risk
        if quadrant == 'Leading':
            if 90 < tail_angle < 180:  # Turning toward Weakening
                risk_score += 2
            elif 45 < tail_angle < 90:  # Still good but watch
                risk_score += 0
        elif quadrant == 'Improving':
            if 180 < tail_angle < 270:  # Turning toward Lagging
                risk_score += 2
            elif tail_angle < 45:  # Strong angle toward Leading
                risk_score -= 1
        elif quadrant == 'Weakening':
            if movement_dir == 'Toward Lagging':
                risk_score += 1
        
        # 6. Combined velocity + angle risk
        if velocity > 30 and tail_metrics['path_volatility'] > 10:
            risk_score += 1  # Fast and erratic = high risk
        
        # Cap the risk score
        risk_score = max(0, min(risk_score, 10))
        
        # Convert to category
        if risk_score <= 2:
            return 'Low', tail_metrics
        elif risk_score <= 4:
            return 'Medium', tail_metrics
        elif risk_score <= 6:
            return 'High', tail_metrics
        else:
            return 'Very High', tail_metrics

    def _generate_risk_comment(self, row, tail_metrics):
        """
        Generate human-readable risk commentary based on tail analysis
        """
        comments = []
        
        # Tail signals
        if tail_metrics['signals']:
            signal_descriptions = {
                'Erratic_Path': 'Unstable price path',
                'Bearish_Divergence': 'Price up but momentum fading',
                'Bullish_Divergence': 'Price down but momentum building',
                'Whipsaw_Pattern': 'Choppy back-and-forth movement',
                'Decelerating': 'Momentum slowing down',
                'Momentum_Spike': 'Potential blow-off top',
                'Sharp_Angle_Change': 'Sharp trajectory change'
            }
            
            for signal in tail_metrics['signals']:
                if signal in signal_descriptions:
                    comments.append(signal_descriptions[signal])
        
        # Position-based comments
        distance = row['Distance_from_Center']
        quadrant = row['Quadrant']
        velocity = row.get('Velocity_Factor', 0)
        
        if distance > 150:
            comments.append('Highly extended from baseline')
        elif distance < 30 and quadrant in ['Leading', 'Improving']:
            comments.append('Early in the move')
        
        if velocity > 35:
            comments.append('Very rapid move - caution')
        elif velocity < 3 and quadrant in ['Leading', 'Improving']:
            comments.append('Momentum stalling')
        
        # Angle-based comments
        tail_angle = row.get('Tail_Angle', 0)
        if quadrant == 'Leading' and 90 < tail_angle < 180:
            comments.append('Trajectory turning toward weakness')
        elif quadrant == 'Improving' and 0 <= tail_angle <= 45:
            comments.append('Strong rotation toward leadership')
        
        # Path quality
        if tail_metrics['path_volatility'] > 12:
            comments.append('High path volatility')
        elif tail_metrics['path_volatility'] < 5:
            comments.append('Smooth uptrend')
        
        # Return formatted comment
        if comments:
            return ' | '.join(comments)
        else:
            return 'Clean technical setup'

    def _add_analysis_columns_enhanced(self, data):
        """
        Enhanced version of _add_analysis_columns with tail-based risk
        """
        data = data.copy()
        
        # Initialize columns for tail metrics
        data['Risk_Signals'] = ''
        data['Path_Volatility'] = 0.0
        data['Risk_Comment'] = ''
        data['Tail_Quality'] = ''
        
        # Process each row with enhanced risk calculation
        for idx, row in data.iterrows():
            # Calculate enhanced risk level
            risk_level, tail_metrics = self._calculate_risk_level_enhanced(row)
            data.at[idx, 'Risk_Level'] = risk_level
            
            # Store tail metrics
            data.at[idx, 'Risk_Signals'] = ','.join(tail_metrics['signals']) if tail_metrics['signals'] else 'Clean'
            data.at[idx, 'Path_Volatility'] = tail_metrics['path_volatility']
            
            # Generate risk commentary
            risk_comment = self._generate_risk_comment(row, tail_metrics)
            data.at[idx, 'Risk_Comment'] = risk_comment
            
            # Tail quality assessment
            if not tail_metrics['signals'] and tail_metrics['path_volatility'] < 8:
                data.at[idx, 'Tail_Quality'] = 'Excellent'
            elif len(tail_metrics['signals']) <= 1 and tail_metrics['path_volatility'] < 12:
                data.at[idx, 'Tail_Quality'] = 'Good'
            elif len(tail_metrics['signals']) <= 2:
                data.at[idx, 'Tail_Quality'] = 'Fair'
            else:
                data.at[idx, 'Tail_Quality'] = 'Poor'
        
        # Add other analysis columns (keep existing logic)
        data['Trend_Strength'] = data.apply(self._calculate_trend_strength, axis=1)
        data['Momentum_Quality'] = data.apply(self._calculate_momentum_quality, axis=1)
        data['Position_Size'] = data.apply(self._calculate_position_size, axis=1)
        data['Time_Horizon'] = data.apply(self._calculate_time_horizon, axis=1)
        
        return data

    def _add_recommendations_enhanced(self, data):
        """
        Enhanced recommendations considering tail risk analysis
        """
        data = data.copy()
        
        def get_recommendation(row):
            score = row['Opportunity_Score']
            quadrant = row['Quadrant']
            risk_level = row['Risk_Level']
            tail_quality = row.get('Tail_Quality', 'Fair')
            distance = row['Distance_from_Center']
            risk_signals = row.get('Risk_Signals', '')
            
            # Check for dangerous signals
            has_divergence = 'Bearish_Divergence' in risk_signals
            has_spike = 'Momentum_Spike' in risk_signals
            is_extended = distance > 150
            
            if quadrant == 'Leading':
                if score >= 200 and risk_level == 'Low' and tail_quality in ['Excellent', 'Good']:
                    return 'STRONG BUY - High conviction long position'
                elif score >= 200 and risk_level == 'Medium' and not has_divergence:
                    return 'BUY - Strong but monitor for reversal'
                elif is_extended or has_spike:
                    return 'HOLD/TRIM - Overextended, take partial profits'
                elif has_divergence:
                    return 'CAUTION - Momentum divergence detected'
                elif risk_level in ['Low', 'Medium']:
                    return 'BUY - Good opportunity with acceptable risk'
                else:
                    return 'WEAK BUY - High risk, small position only'
            
            elif quadrant == 'Improving':
                if score >= 150 and tail_quality == 'Excellent' and risk_level in ['Low', 'Medium']:
                    return 'STRONG BUY - Early reversal with quality setup'
                elif score >= 100 and not has_divergence:
                    return 'BUY - Improving momentum, watch for confirmation'
                else:
                    return 'WATCH - Wait for stronger confirmation'
            
            elif quadrant == 'Weakening':
                if risk_signals and 'Bearish_Divergence' in risk_signals:
                    return 'SELL - Weakening with negative divergence'
                else:
                    return 'HOLD/TRAILING STOP - Monitor closely'
            
            else:  # Lagging
                return 'AVOID - Weak relative performance'
        
        data['Recommendation'] = data.apply(get_recommendation, axis=1)
        return data

    # Update the generate_comprehensive_analysis method to use enhanced version
    def generate_comprehensive_analysis(self, rrg_data):
        """
        Generate comprehensive analysis with tail-based risk assessment
        """
        if rrg_data.empty:
            return pd.DataFrame()
        
        # Add comprehensive scoring
        enhanced_data = self._add_opportunity_scores(rrg_data)
        
        # Add enhanced analysis columns with tail risk
        enhanced_data = self._add_analysis_columns_enhanced(enhanced_data)
        
        # Add enhanced recommendations
        enhanced_data = self._add_recommendations_enhanced(enhanced_data)
        
        return enhanced_data


def main():
    """
    RRG scanner that reads from configured CSV file and generates comprehensive CSV analysis.
    All parameters are configurable at the top of the script.
    """
    try:
        # Initialize scanner with configuration values
        advanced_scanner = AdvancedRRGScanner(API_KEY, ACCESS_TOKEN)
        
        # Read the sector data
        try:
            securities_df = pd.read_csv(DATA_FILE_PATH)
            # Clean the data
            securities_df.dropna(subset=[SYMBOL_COLUMN, SECTOR_COLUMN], inplace=True)
            securities_df.drop_duplicates(subset=[SYMBOL_COLUMN], inplace=True)
        except FileNotFoundError:
            print(f"Error: '{DATA_FILE_PATH}' not found.")
            return
        
        # Get all unique sectors
        level_3_sectors = securities_df[SECTOR_COLUMN].unique()
        
        # Store all results for combined analysis
        all_results = []
        
        # Analyze each sector
        for sector in level_3_sectors:
            print(f"\n" + "="*60)
            print(f" RRG Analysis for Sector: {sector}")
            print("="*60)
            
            # Get all symbols for the current sector
            stock_list = securities_df[securities_df[SECTOR_COLUMN] == sector][SYMBOL_COLUMN].tolist()
            
            if not stock_list:
                print(f"No stocks found for sector: {sector}")
                continue
            
            rrg_results = advanced_scanner.scan_custom_stocks(stock_list)
            
            if not rrg_results.empty:
                # Add sector information to results
                rrg_results['Sector'] = sector
                
                # Generate comprehensive analysis for this sector
                rrg_results = advanced_scanner.generate_comprehensive_analysis(rrg_results)
                
                # Print results by quadrant
                advanced_scanner._print_stock_results(rrg_results)
                
                # Get top opportunities
                print(f"\n🏆 Top {TOP_OPPORTUNITIES_DISPLAY} Opportunities in {sector}:")
                print("-" * 60)
                top_5 = advanced_scanner.get_top_opportunities(rrg_results, top_n=TOP_OPPORTUNITIES_DISPLAY)
                for i, (_, row) in enumerate(top_5.iterrows(), 1):
                    tail_info = f" | Angle: {row.get('Tail_Angle', 0):.1f}° | Vel: {row.get('Velocity_Factor', 0):.2f}"
                    movement_info = f" | {row.get('Movement_Direction', 'N/A')}"
                    
                    print(f"{i:2d}. {row['Stock']:<15} | Score: {row['Opportunity_Score']:.1f} | "
                          f"RS: {row['RS_Ratio']:.2f} | Mom: {row['RS_Momentum']:.2f} | {row['Quadrant']}{tail_info}{movement_info}")

                # Export individual sector CSV (if enabled)
                if CREATE_INDIVIDUAL_SECTOR_CSV:
                    sector_filename = f"RRG_Analysis_{sector.replace(' ', '_').replace('&', 'and')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                    print(f"\n💾 Exporting comprehensive analysis for {sector} to {sector_filename}...")
                    advanced_scanner.export_comprehensive_csv(rrg_results, sector_filename, include_analysis=False)
                
                # Add to combined results
                all_results.append(rrg_results)
            else:
                print(f"Could not generate RRG analysis for {sector}.")
        
        # Create combined analysis across all sectors
        if all_results:
            print(f"\n" + "="*80)
            print(" COMBINED ANALYSIS ACROSS ALL SECTORS")
            print("="*80)
            
            # Combine all results
            combined_results = pd.concat(all_results, ignore_index=True)
            
            # Generate comprehensive analysis for combined results
            combined_results = advanced_scanner.generate_comprehensive_analysis(combined_results)
            
            # Export combined comprehensive CSV (if enabled)
            if CREATE_COMBINED_ANALYSIS_CSV:
                combined_filename = f"RRG_Combined_Analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                print(f"\n💾 Exporting combined comprehensive analysis to {combined_filename}...")
                advanced_scanner.export_comprehensive_csv(combined_results, combined_filename, include_analysis=False)
            
            # Create Master Summary CSV with top opportunities (if enabled)
            if CREATE_MASTER_SUMMARY_CSV:
                print(f"\n🎯 Creating Master Summary CSV with top opportunities...")
                master_summary_filename = f"RRG_Master_Summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                advanced_scanner.create_master_summary_csv(combined_results, master_summary_filename)
            
            # Create Sector Leaders Summary (if enabled)
            if CREATE_SECTOR_LEADERS_CSV:
                print(f"\n📊 Creating Sector Leaders Summary...")
                sector_leaders_filename = f"RRG_Sector_Leaders_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                advanced_scanner.create_sector_leaders_csv(combined_results, sector_leaders_filename)
            
            # Create Opportunity Tiers Summary (if enabled)
            if CREATE_OPPORTUNITY_TIERS_CSV:
                print(f"\n🏆 Creating Opportunity Tiers Summary...")
                tiers_filename = f"RRG_Opportunity_Tiers_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
                advanced_scanner.create_opportunity_tiers_csv(combined_results, tiers_filename)
            
            # Print overall market summary
            print(f"\n📊 OVERALL MARKET SUMMARY:")
            print("-" * 50)
            
            if 'Recommendation' in combined_results.columns:
                rec_counts = combined_results['Recommendation'].value_counts()
                print(f"Recommendation Distribution:")
                for rec, count in rec_counts.items():
                    print(f"  • {rec}: {count} stocks")
            
            if 'Quadrant' in combined_results.columns:
                quad_counts = combined_results['Quadrant'].value_counts()
                print(f"\nQuadrant Distribution:")
                for quad, count in quad_counts.items():
                    print(f"  • {quad}: {count} stocks")
            
            # Top overall opportunities
            if 'Opportunity_Score' in combined_results.columns:
                top_opportunities = combined_results.nlargest(TOP_OVERALL_DISPLAY, 'Opportunity_Score')
                print(f"\n🏆 TOP {TOP_OVERALL_DISPLAY} OVERALL OPPORTUNITIES:")
                print("-" * 60)
                for i, (_, row) in enumerate(top_opportunities.iterrows(), 1):
                    print(f"{i:2d}. {row['Stock']:<15} | {row['Sector']:<20} | Score: {row['Opportunity_Score']:.1f} | {row.get('Recommendation', 'N/A')}")
            
            # ========================================================================
            # QUARTERLY MOMENTUM STRATEGY PICKS (NEW!)
            # ========================================================================
            print(f"\n{'='*80}")
            print(f"🚀 GENERATING QUARTERLY MOMENTUM STRATEGY PICKS")
            print(f"{'='*80}")
            
            try:
                # Generate momentum picks using the combined results
                momentum_result = generate_momentum_picks_from_results(
                    combined_results, 
                    advanced_scanner
                )
                
                if momentum_result and not momentum_result['top_picks'].empty:
                    # Export to CSV
                    export_momentum_picks_to_csv(momentum_result)
                    print(f"✅ Quarterly Momentum picks generated successfully!")
                else:
                    print(f"⚠️ No momentum picks generated (check filters or market conditions)")
                    
            except Exception as e:
                print(f"⚠️ Could not generate momentum picks: {e}")

    except Exception as e:
        print(f"❌ An error occurred: {e}")
        print("Please check your API credentials and connection")

def generate_momentum_picks_from_results(combined_results, scanner):
    """
    Generate Quarterly Momentum picks from existing RRG results
    Much simpler than loading all data again!
    
    Args:
        combined_results: DataFrame from standard RRG scan
        scanner: RRGScanner instance
    
    Returns:
        dict with momentum picks and metadata
    """
    try:
        print(f"Strategy: {QTR_MOMENTUM_CONFIG['name']}")
        print(f"Target Portfolio: {QTR_MOMENTUM_CONFIG['portfolio_size']} stocks")
        print(f"Score Range: {QTR_MOMENTUM_CONFIG['min_score']} - {QTR_MOMENTUM_CONFIG['max_score']}")
        
        # Step 1: Check market regime
        market_regime = None
        recommended_size = QTR_MOMENTUM_CONFIG['portfolio_size']
        
        if QTR_MOMENTUM_CONFIG['check_market_regime']:
            market_regime = scanner.check_market_regime(QTR_MOMENTUM_CONFIG['benchmark_for_regime'])
            recommended_size = market_regime['details'].get('recommended_portfolio_size', recommended_size)
            
            if market_regime['regime'] == 'BEARISH':
                print(f"\n⚠️ BEARISH MARKET REGIME - Consider waiting or reducing size")
        
        # Step 2: Use existing combined results and recalculate scores with BACKTESTER weights
        print(f"\n🔍 Applying momentum strategy filters...")
        
        # Recalculate Opportunity Score with backtester weights
        results_copy = combined_results.copy()
        
        # Column mapping: 'Stock' -> 'Symbol', keep others same
        if 'Stock' in results_copy.columns:
            results_copy['Symbol'] = results_copy['Stock']
        
        # Recalculate scores with backtester weights
        weights = QTR_MOMENTUM_CONFIG['scoring_weights']
        
        def calc_backtester_score(row):
            score = 0.0
            score += weights['quadrant_scores'].get(row['Quadrant'], 0)
            score += row['RS_Ratio'] * weights['rs_ratio_multiplier']
            score += row['RS_Momentum'] * weights['momentum_multiplier']
            score += row['Distance_from_Center'] * weights['distance_multiplier']
            
            if row['Movement_Direction'] == 'Toward Leading':
                score += weights['movement_bonuses']['toward_leading']
            elif row['Movement_Direction'] == 'Toward Improving':
                score += weights['movement_bonuses']['toward_improving']
            elif row['Movement_Direction'] == 'Toward Lagging':
                score += weights['movement_bonuses']['toward_lagging_penalty']
            
            if row['Velocity_Factor'] > 0:
                velocity_bonus = min(row['Velocity_Factor'] / 10, 1.0) * weights['velocity_max_bonus']
                score += velocity_bonus
            
            return max(0, score)
        
        results_copy['Momentum_Score'] = results_copy.apply(calc_backtester_score, axis=1)
        
        # Step 3: Apply filters
        filtered = results_copy.copy()
        initial_count = len(filtered)
        
        # Filter 1: Score range
        filtered = filtered[
            (filtered['Momentum_Score'] >= QTR_MOMENTUM_CONFIG['min_score']) &
            (filtered['Momentum_Score'] <= QTR_MOMENTUM_CONFIG['max_score'])
        ]
        print(f"   Score filter ({QTR_MOMENTUM_CONFIG['min_score']}-{QTR_MOMENTUM_CONFIG['max_score']}): {initial_count} → {len(filtered)} stocks")
        
        # Filter 2: Exclude sectors
        if QTR_MOMENTUM_CONFIG['exclude_sectors']:
            initial_count = len(filtered)
            filtered = filtered[~filtered['Sector'].isin(QTR_MOMENTUM_CONFIG['exclude_sectors'])]
            print(f"   Sector filter: {initial_count} → {len(filtered)} stocks")
        
        # Filter 3: Prefer Leading quadrant
        if QTR_MOMENTUM_CONFIG['prefer_leading']:
            leading_stocks = filtered[filtered['Quadrant'] == 'Leading'].nlargest(recommended_size, 'Momentum_Score')
            
            if len(leading_stocks) < recommended_size:
                remaining = recommended_size - len(leading_stocks)
                other_stocks = filtered[
                    (filtered['Quadrant'] != 'Leading') &
                    (~filtered['Symbol'].isin(leading_stocks['Symbol']))
                ].nlargest(remaining, 'Momentum_Score')
                
                top_picks = pd.concat([leading_stocks, other_stocks])
            else:
                top_picks = leading_stocks
        else:
            top_picks = filtered.nlargest(recommended_size, 'Momentum_Score')
        
        # Sort by score
        top_picks = top_picks.sort_values('Momentum_Score', ascending=False).reset_index(drop=True)
        
        # Add Current_Price if missing (estimate from data or use placeholder)
        if 'Current_Price' not in top_picks.columns:
            top_picks['Current_Price'] = 0.0  # Scanner will need to fetch live prices
        
        print(f"\n✅ Selected {len(top_picks)} stocks")
        print(f"   Avg Score: {top_picks['Momentum_Score'].mean():.1f}")
        print(f"   Leading: {len(top_picks[top_picks['Quadrant']=='Leading'])} | "
              f"Improving: {len(top_picks[top_picks['Quadrant']=='Improving'])} | "
              f"Weakening: {len(top_picks[top_picks['Quadrant']=='Weakening'])} | "
              f"Lagging: {len(top_picks[top_picks['Quadrant']=='Lagging'])}")
        
        # Step 4: Generate recommendations
        from dateutil.relativedelta import relativedelta
        today = datetime.now()
        
        # Calculate next quarter end
        if today.month <= 3:
            next_quarter_end = datetime(today.year, 3, 31)
        elif today.month <= 6:
            next_quarter_end = datetime(today.year, 6, 30)
        elif today.month <= 9:
            next_quarter_end = datetime(today.year, 9, 30)
        else:
            next_quarter_end = datetime(today.year, 12, 31)
        
        # If we're past the quarter end, move to next quarter
        if today > next_quarter_end:
            next_quarter_end = next_quarter_end + relativedelta(months=3)
            if next_quarter_end.month == 3:
                next_quarter_end = datetime(next_quarter_end.year, 3, 31)
            elif next_quarter_end.month == 6:
                next_quarter_end = datetime(next_quarter_end.year, 6, 30)
            elif next_quarter_end.month == 9:
                next_quarter_end = datetime(next_quarter_end.year, 9, 30)
            else:
                next_quarter_end = datetime(next_quarter_end.year, 12, 31)
        
        # Prepare final picks with correct column names
        final_picks = top_picks.rename(columns={'Momentum_Score': 'Opportunity_Score'})
        
        # Prepare output
        result = {
            'strategy': QTR_MOMENTUM_CONFIG['name'],
            'generated_date': today.strftime('%Y-%m-%d'),
            'entry_date': today.strftime('%Y-%m-%d'),
            'next_rebalance_date': next_quarter_end.strftime('%Y-%m-%d'),
            'market_regime': market_regime,
            'recommended_portfolio_size': recommended_size,
            'actual_picks': len(final_picks),
            'allocation_per_stock': f"{100/len(final_picks):.2f}%" if len(final_picks) > 0 else "0%",
            'avg_opportunity_score': round(final_picks['Opportunity_Score'].mean(), 2) if len(final_picks) > 0 else 0,
            'top_picks': final_picks,
            'filters_applied': {
                'min_score': QTR_MOMENTUM_CONFIG['min_score'],
                'max_score': QTR_MOMENTUM_CONFIG['max_score'],
                'prefer_leading': QTR_MOMENTUM_CONFIG['prefer_leading'],
                'excluded_sectors': QTR_MOMENTUM_CONFIG['exclude_sectors'],
                'manual_exclusions': []
            }
        }
        
        return result
        
    except Exception as e:
        print(f"❌ Error generating momentum picks from results: {e}")
        import traceback
        traceback.print_exc()
        return None

def export_momentum_picks_to_csv(result):
    """
    Export Quarterly Momentum Strategy picks to CSV with rich metadata
    
    Args:
        result: Result dict from get_qtr_momentum_picks()
    """
    try:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"Quarterly_Momentum_Picks_{timestamp}.csv"
        
        # Prepare main picks data
        picks_df = result['top_picks'].copy()
        
        # Add metadata columns
        picks_df.insert(0, 'Rank', range(1, len(picks_df) + 1))
        picks_df.insert(1, 'Entry_Date', result['entry_date'])
        picks_df.insert(2, 'Next_Rebalance', result['next_rebalance_date'])
        picks_df.insert(3, 'Allocation_%', result['allocation_per_stock'])
        
        # Add regime info if available
        if result['market_regime']:
            regime = result['market_regime']['regime']
            regime_score = result['market_regime']['score']
            picks_df.insert(4, 'Market_Regime', f"{regime} ({regime_score}/3)")
        
        # Reorder columns for better readability
        column_order = [
            'Rank', 'Entry_Date', 'Next_Rebalance', 'Allocation_%', 
            'Symbol', 'Sector', 'Current_Price', 'Opportunity_Score',
            'Quadrant', 'RS_Ratio', 'RS_Momentum', 'Distance_from_Center',
            'Velocity_Factor', 'Movement_Direction', 'Tail_Angle'
        ]
        
        # Add Market_Regime if it exists
        if 'Market_Regime' in picks_df.columns:
            column_order.insert(4, 'Market_Regime')
        
        # Reorder and format
        final_columns = [col for col in column_order if col in picks_df.columns]
        picks_df = picks_df[final_columns]
        
        # Round numeric columns
        picks_df['Current_Price'] = picks_df['Current_Price'].round(2)
        picks_df['Opportunity_Score'] = picks_df['Opportunity_Score'].round(2)
        picks_df['RS_Ratio'] = picks_df['RS_Ratio'].round(2)
        picks_df['RS_Momentum'] = picks_df['RS_Momentum'].round(2)
        picks_df['Distance_from_Center'] = picks_df['Distance_from_Center'].round(2)
        picks_df['Velocity_Factor'] = picks_df['Velocity_Factor'].round(2)
        picks_df['Tail_Angle'] = picks_df['Tail_Angle'].round(2)
        
        # Export to CSV
        picks_df.to_csv(filename, index=False)
        
        print(f"\n{'='*80}")
        print(f"💾 EXPORTED QUARTERLY MOMENTUM PICKS")
        print(f"{'='*80}")
        print(f"   Filename: {filename}")
        print(f"   Total Picks: {len(picks_df)}")
        print(f"   Entry Date: {result['entry_date']}")
        print(f"   Next Rebalance: {result['next_rebalance_date']}")
        print(f"   Allocation per Stock: {result['allocation_per_stock']}")
        
        if result['market_regime']:
            regime = result['market_regime']['regime']
            print(f"   Market Regime: {regime}")
        
        print(f"\n📊 TOP 10 PICKS:")
        print(f"   {'#':<3} {'Symbol':<15} {'Sector':<30} {'Score':<8} {'Quadrant':<12} {'Price':<10}")
        print(f"   {'-'*80}")
        for i, row in picks_df.head(10).iterrows():
            print(f"   {row['Rank']:<3} {row['Symbol']:<15} {row['Sector']:<30} {row['Opportunity_Score']:<8.1f} {row['Quadrant']:<12} ₹{row['Current_Price']:<10.2f}")
        
        print(f"\n{'='*80}")
        
        # Also create a summary file
        summary_filename = f"Quarterly_Momentum_Summary_{timestamp}.txt"
        with open(summary_filename, 'w') as f:
            f.write("="*80 + "\n")
            f.write("QUARTERLY MOMENTUM STRATEGY - STOCK PICKS SUMMARY\n")
            f.write("="*80 + "\n\n")
            f.write(f"Strategy: {result['strategy']}\n")
            f.write(f"Generated: {result['generated_date']}\n")
            f.write(f"Entry Date: {result['entry_date']}\n")
            f.write(f"Next Rebalance: {result['next_rebalance_date']}\n")
            f.write(f"Portfolio Size: {result['actual_picks']} stocks\n")
            f.write(f"Allocation per Stock: {result['allocation_per_stock']}\n")
            f.write(f"Avg Opportunity Score: {result['avg_opportunity_score']}\n\n")
            
            if result['market_regime']:
                f.write(f"MARKET REGIME ANALYSIS:\n")
                f.write(f"-"*40 + "\n")
                regime = result['market_regime']
                f.write(f"Regime: {regime['regime']} ({regime['score']}/3 conditions met)\n")
                details = regime['details']
                f.write(f"Nifty 500: ₹{details.get('current_price', 0):,.2f}\n")
                f.write(f"200-day SMA: ₹{details.get('sma_200', 0):,.2f}\n")
                f.write(f"Above SMA: {'YES' if details.get('above_sma', False) else 'NO'}\n")
                f.write(f"Last 20 days: {details.get('last_20_days_return', 0):+.2f}%\n")
                f.write(f"Volatility: {details.get('current_volatility', 0):.2f}%\n\n")
            
            f.write(f"FILTERS APPLIED:\n")
            f.write(f"-"*40 + "\n")
            filters = result['filters_applied']
            f.write(f"Score Range: {filters['min_score']} - {filters['max_score']}\n")
            f.write(f"Prefer Leading: {filters['prefer_leading']}\n")
            f.write(f"Excluded Sectors: {', '.join(filters['excluded_sectors']) if filters['excluded_sectors'] else 'None'}\n")
            f.write(f"Manual Exclusions: {', '.join(filters['manual_exclusions']) if filters['manual_exclusions'] else 'None'}\n\n")
            
            f.write(f"RECOMMENDED ACTIONS:\n")
            f.write(f"-"*40 + "\n")
            f.write(f"1. Review the {result['actual_picks']} stocks in {filename}\n")
            f.write(f"2. Allocate {result['allocation_per_stock']} to each stock\n")
            f.write(f"3. Enter positions on or around {result['entry_date']}\n")
            f.write(f"4. Monitor fortnightly with 15% individual stock stop-loss\n")
            f.write(f"5. Monitor portfolio-level 10% stop-loss\n")
            f.write(f"6. Rebalance on {result['next_rebalance_date']} (quarter-end)\n\n")
            
            if result['market_regime'] and result['market_regime']['regime'] == 'BEARISH':
                f.write(f"⚠️  WARNING: BEARISH MARKET REGIME\n")
                f.write(f"   Consider waiting for better conditions or reducing position sizes\n\n")
        
        print(f"💾 Summary also saved to: {summary_filename}\n")
        
        return filename
        
    except Exception as e:
        print(f"❌ Error exporting picks to CSV: {e}")
        return None

def run_momentum_strategy(manual_exclude=None):
    """
    Run the Quarterly Momentum Strategy picker
    
    Args:
        manual_exclude: Comma-separated string of symbols to exclude
    """
    try:
        # Parse manual exclusions
        manual_exclude_list = None
        if manual_exclude:
            manual_exclude_list = [s.strip() for s in manual_exclude.split(',')]
            print(f"Manual exclusions: {manual_exclude_list}")
        
        # Initialize scanner with backtester weights
        scanner = RRGScanner(API_KEY, ACCESS_TOKEN, scoring_weights=BACKTESTER_SCORING_WEIGHTS)
        
        # Get momentum picks
        result = scanner.get_qtr_momentum_picks(manual_exclude_list=manual_exclude_list)
        
        if result and result['top_picks'] is not None and not result['top_picks'].empty:
            # Export to CSV
            filename = export_momentum_picks_to_csv(result)
            
            if filename:
                print(f"✅ Quarterly Momentum Strategy picks generated successfully!")
                print(f"📁 Check {filename} for detailed recommendations")
        else:
            print(f"❌ No picks generated. Check market conditions or filters.")
    
    except Exception as e:
        print(f"❌ Error running momentum strategy: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    # Just run the main scanner - it will generate all outputs including momentum picks
    print("📊 Running RRG Scanner with Quarterly Momentum Strategy...")
    main()
    print("\nRRG Scanner script finished.")
