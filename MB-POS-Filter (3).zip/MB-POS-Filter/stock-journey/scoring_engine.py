"""
Scoring Engine
Calculates confidence scores using weighted signals for breakout candidates
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
import logging

from config import config, CONFIDENCE_LEVELS

logger = logging.getLogger(__name__)

class ScoringEngine:
    """Calculates confidence scores using weighted technical signals"""
    
    def __init__(self, config_obj=None):
        self.config = config_obj or config
    
    def normalize_signal(self, series: pd.Series, method: str = 'zscore') -> pd.Series:
        """Normalize a signal to 0-1 range"""
        if series.empty or series.isna().all():
            return pd.Series([0.0] * len(series), index=series.index)
        
        if method == 'zscore':
            # Z-score normalization then sigmoid to 0-1
            mean_val = series.mean()
            std_val = series.std()
            if std_val == 0:
                return pd.Series([0.5] * len(series), index=series.index)
            
            z_scores = (series - mean_val) / std_val
            # Sigmoid function to map to 0-1
            normalized = 1 / (1 + np.exp(-z_scores))
            return normalized
        
        elif method == 'minmax':
            # Min-max normalization
            min_val = series.min()
            max_val = series.max()
            if max_val == min_val:
                return pd.Series([0.5] * len(series), index=series.index)
            
            return (series - min_val) / (max_val - min_val)
        
        elif method == 'percentile':
            # Percentile-based normalization
            return series.rank(pct=True)
        
        else:
            raise ValueError(f"Unknown normalization method: {method}")
    
    def calculate_trend_strength_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate trend strength score (0-1)"""
        if df.empty:
            return pd.Series([], dtype=float)
        
        short_ma = f'ma_short_{self.config.MA_SHORT_WEEKS}w'
        long_ma = f'ma_long_{self.config.MA_LONG_WEEKS}w'
        
        # MA relationship score
        ma_ratio = df[short_ma] / df[long_ma]
        ma_score = self.normalize_signal(ma_ratio, 'minmax')
        
        # MA slope score (positive slope is better)
        slope_score = self.normalize_signal(df['ma_slope'], 'zscore')
        
        # Price vs MA score
        price_ma_ratio = df['close'] / df[short_ma]
        price_score = self.normalize_signal(price_ma_ratio, 'minmax')
        
        # Combine scores
        trend_score = (ma_score * 0.4 + slope_score * 0.4 + price_score * 0.2)
        
        return trend_score.fillna(0.0)
    
    def calculate_range_breakout_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate range breakout score (0-1)"""
        if df.empty:
            return pd.Series([], dtype=float)
        
        range_high_col = f'range_high_{self.config.RANGE_WEEKS}w'
        range_low_col = f'range_low_{self.config.RANGE_WEEKS}w'
        
        # Breakout strength (how far above range high)
        breakout_strength = (df['close'] - df[range_high_col]) / df[range_high_col] * 100
        breakout_score = self.normalize_signal(breakout_strength, 'zscore')
        
        # Range tightness (tighter ranges are better for breakouts)
        range_pct_col = f'range_pct_{self.config.RANGE_WEEKS}w'
        range_tightness = 1 - self.normalize_signal(df[range_pct_col], 'minmax')  # Invert so lower is better
        
        # Combine scores
        range_score = (breakout_score * 0.7 + range_tightness * 0.3)
        
        return range_score.fillna(0.0)
    
    def calculate_volume_confirmation_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate volume confirmation score (0-1)"""
        if df.empty:
            return pd.Series([], dtype=float)
        
        # Volume spike score
        vol_spike_score = self.normalize_signal(df['vol_spike'], 'zscore')
        
        # Volume Z-score (consistency)
        vol_z_score = self.normalize_signal(df.get('vol_z', pd.Series([0] * len(df), index=df.index)), 'zscore')
        
        # Volume trend (increasing volume is better)
        vol_trend = df['volume'].pct_change(4)  # 4-week volume change
        vol_trend_score = self.normalize_signal(vol_trend, 'zscore')
        
        # Combine scores
        volume_score = (vol_spike_score * 0.5 + vol_z_score * 0.3 + vol_trend_score * 0.2)
        
        return volume_score.fillna(0.0)
    
    def calculate_relative_strength_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate relative strength score (0-1)"""
        if df.empty:
            return pd.Series([], dtype=float)
        
        rs_col = f'rs_{self.config.RS_WEEKS}w'
        if rs_col not in df.columns:
            return pd.Series([0.5] * len(df), index=df.index)  # Neutral if no RS data
        
        # RS score (above 1.0 is outperforming)
        rs_score = self.normalize_signal(df[rs_col], 'zscore')
        
        # RS Z-score (consistency)
        rs_z_col = f'rs_z_{self.config.RS_WEEKS}w'
        if rs_z_col in df.columns:
            rs_z_score = self.normalize_signal(df[rs_z_col], 'zscore')
        else:
            rs_z_score = pd.Series([0.5] * len(df), index=df.index)
        
        # Combine scores
        relative_strength_score = (rs_score * 0.7 + rs_z_score * 0.3)
        
        return relative_strength_score.fillna(0.5)
    
    def calculate_atr_volatility_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate ATR/volatility score (0-1, lower volatility is better for bases)"""
        if df.empty:
            return pd.Series([], dtype=float)
        
        atr_col = f'atr_{self.config.ATR_WEEKS}w'
        if atr_col not in df.columns:
            return pd.Series([0.5] * len(df), index=df.index)
        
        # ATR shrink (lower is better for consolidation)
        atr_shrink = df.get('atr_shrink', pd.Series([False] * len(df), index=df.index))
        atr_shrink_score = atr_shrink.astype(float)
        
        # ATR percentile (lower ATR is better for bases)
        atr_percentile = df[atr_col].rank(pct=True)
        atr_low_score = 1 - atr_percentile  # Invert so lower ATR gets higher score
        
        # Combine scores
        volatility_score = (atr_shrink_score * 0.6 + atr_low_score * 0.4)
        
        return volatility_score.fillna(0.5)
    
    def calculate_hhhl_pattern_score(self, df: pd.DataFrame) -> pd.Series:
        """Calculate HHHL pattern score (0-1)"""
        if df.empty:
            return pd.Series([], dtype=float)
        
        # HHHL pattern score
        hhhl_score = df.get('hhhl_pattern', pd.Series([False] * len(df), index=df.index)).astype(float)
        
        # Higher highs score
        higher_highs_score = df.get('higher_highs', pd.Series([False] * len(df), index=df.index)).astype(float)
        
        # Higher lows score
        higher_lows_score = df.get('higher_lows', pd.Series([False] * len(df), index=df.index)).astype(float)
        
        # Combine scores
        pattern_score = (hhhl_score * 0.5 + higher_highs_score * 0.25 + higher_lows_score * 0.25)
        
        return pattern_score.fillna(0.0)
    
    def calculate_confidence_score(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate overall confidence score using weighted signals"""
        if df.empty:
            return df
        
        df = df.copy()
        
        # Calculate individual signal scores
        df['trend_strength_score'] = self.calculate_trend_strength_score(df)
        df['range_breakout_score'] = self.calculate_range_breakout_score(df)
        df['volume_confirmation_score'] = self.calculate_volume_confirmation_score(df)
        df['relative_strength_score'] = self.calculate_relative_strength_score(df)
        df['atr_volatility_score'] = self.calculate_atr_volatility_score(df)
        df['hhhl_pattern_score'] = self.calculate_hhhl_pattern_score(df)
        
        # Calculate weighted confidence score
        weights = self.config.SCORING_WEIGHTS
        df['confidence_score'] = (
            df['trend_strength_score'] * weights['trend_strength'] +
            df['range_breakout_score'] * weights['range_breakout'] +
            df['volume_confirmation_score'] * weights['volume_confirmation'] +
            df['relative_strength_score'] * weights['relative_strength'] +
            df['atr_volatility_score'] * weights['atr_volatility'] +
            df['hhhl_pattern_score'] * weights['hhhl_pattern']
        )
        
        # Ensure confidence score is between 0 and 1
        df['confidence_score'] = df['confidence_score'].clip(0, 1)
        
        # Add confidence level labels
        df['confidence_level'] = df['confidence_score'].apply(self._get_confidence_level)
        
        return df
    
    def _get_confidence_level(self, score: float) -> str:
        """Get confidence level label based on score"""
        if score >= CONFIDENCE_LEVELS['strong']:
            return 'STRONG'
        elif score >= CONFIDENCE_LEVELS['moderate']:
            return 'MODERATE'
        elif score >= CONFIDENCE_LEVELS['watchlist']:
            return 'WATCHLIST'
        else:
            return 'IGNORE'
    
    def get_score_breakdown(self, df: pd.DataFrame) -> Dict[str, any]:
        """Get detailed score breakdown for analysis"""
        if df.empty or 'confidence_score' not in df.columns:
            return {}
        
        latest = df.iloc[-1]
        
        breakdown = {
            'overall_confidence': latest['confidence_score'],
            'confidence_level': latest['confidence_level'],
            'signal_scores': {
                'trend_strength': latest['trend_strength_score'],
                'range_breakout': latest['range_breakout_score'],
                'volume_confirmation': latest['volume_confirmation_score'],
                'relative_strength': latest['relative_strength_score'],
                'atr_volatility': latest['atr_volatility_score'],
                'hhhl_pattern': latest['hhhl_pattern_score']
            },
            'weights': self.config.SCORING_WEIGHTS,
            'weighted_contribution': {
                signal: score * self.config.SCORING_WEIGHTS[signal]
                for signal, score in latest.items()
                if signal.endswith('_score') and signal in self.config.SCORING_WEIGHTS
            }
        }
        
        return breakdown
    
    def filter_by_confidence(self, df: pd.DataFrame, min_confidence: float = None) -> pd.DataFrame:
        """Filter dataframe by minimum confidence score"""
        if df.empty or 'confidence_score' not in df.columns:
            return df
        
        if min_confidence is None:
            min_confidence = CONFIDENCE_LEVELS['watchlist']
        
        return df[df['confidence_score'] >= min_confidence].copy()
    
    def get_top_candidates(self, df: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
        """Get top N candidates by confidence score"""
        if df.empty or 'confidence_score' not in df.columns:
            return df
        
        return df.nlargest(top_n, 'confidence_score')
    
    def validate_scoring(self, df: pd.DataFrame) -> Dict[str, any]:
        """Validate scoring calculations and return diagnostics"""
        if df.empty:
            return {'error': 'Empty dataframe'}
        
        diagnostics = {
            'total_periods': len(df),
            'confidence_score_stats': {},
            'signal_score_stats': {},
            'data_quality_issues': []
        }
        
        if 'confidence_score' in df.columns:
            diagnostics['confidence_score_stats'] = {
                'mean': df['confidence_score'].mean(),
                'std': df['confidence_score'].std(),
                'min': df['confidence_score'].min(),
                'max': df['confidence_score'].max(),
                'median': df['confidence_score'].median()
            }
        
        # Check signal scores
        signal_columns = [col for col in df.columns if col.endswith('_score')]
        for col in signal_columns:
            if col in df.columns:
                diagnostics['signal_score_stats'][col] = {
                    'mean': df[col].mean(),
                    'std': df[col].std(),
                    'min': df[col].min(),
                    'max': df[col].max()
                }
        
        # Check for data quality issues
        if 'confidence_score' in df.columns:
            if df['confidence_score'].isna().any():
                diagnostics['data_quality_issues'].append('Missing confidence scores')
            
            if (df['confidence_score'] < 0).any() or (df['confidence_score'] > 1).any():
                diagnostics['data_quality_issues'].append('Confidence scores outside 0-1 range')
        
        return diagnostics
