"""
Technical Indicators and Weekly Resampling
Implements all the technical indicators and weekly resampling logic
"""

import pandas as pd
import numpy as np
from scipy import stats
from typing import Dict, Tuple, Optional
import logging

from config import config

logger = logging.getLogger(__name__)

class TechnicalIndicators:
    """Technical indicators calculator for weekly and daily data"""
    
    def __init__(self, config_obj=None):
        self.config = config_obj or config
    
    def resample_to_weekly(self, daily_df: pd.DataFrame) -> pd.DataFrame:
        """
        Resample daily data to weekly (Friday close)
        Weekly OHLCV: open = first(day), high = max, low = min, close = last(day), volume = sum(volume)
        """
        if daily_df.empty:
            return daily_df
        
        # Ensure we have a datetime index
        if not isinstance(daily_df.index, pd.DatetimeIndex):
            daily_df.index = pd.to_datetime(daily_df.index)
        
        # Remove timezone info if present to avoid comparison issues
        if daily_df.index.tz is not None:
            daily_df.index = daily_df.index.tz_localize(None)
        
        # Resample to weekly (W-FRI = week ending Friday)
        weekly_data = daily_df.resample('W-FRI').agg({
            'open': 'first',
            'high': 'max', 
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        }).dropna()
        
        # Calculate VWAP for each week
        daily_df_copy = daily_df.copy()
        daily_df_copy['vwap_daily'] = (daily_df_copy['close'] * daily_df_copy['volume']).cumsum() / daily_df_copy['volume'].cumsum()
        
        weekly_vwap = daily_df_copy.resample('W-FRI').agg({
            'vwap_daily': 'last'
        }).dropna()
        
        weekly_data['vwap_week'] = weekly_vwap['vwap_daily']
        
        return weekly_data
    
    def calculate_moving_averages(self, df: pd.DataFrame, 
                                short_period: int = None, 
                                long_period: int = None,
                                trend_period: int = None) -> pd.DataFrame:
        """Calculate moving averages"""
        if df.empty:
            return df
        
        short_period = short_period or self.config.MA_SHORT_WEEKS
        long_period = long_period or self.config.MA_LONG_WEEKS
        trend_period = trend_period or self.config.MA_TREND_WEEKS
        
        df = df.copy()
        
        # Calculate MAs
        df[f'ma_short_{short_period}w'] = df['close'].rolling(window=short_period).mean()
        df[f'ma_long_{long_period}w'] = df['close'].rolling(window=long_period).mean()
        df[f'ma_trend_{trend_period}w'] = df['close'].rolling(window=trend_period).mean()
        
        # Calculate MA slope (4-week change for short MA)
        df['ma_slope'] = (df[f'ma_short_{short_period}w'] - df[f'ma_short_{short_period}w'].shift(4)) / df[f'ma_short_{short_period}w'].shift(4)
        
        return df
    
    def calculate_atr(self, df: pd.DataFrame, period: int = None) -> pd.DataFrame:
        """Calculate Average True Range"""
        if df.empty:
            return df
        
        period = period or self.config.ATR_WEEKS
        df = df.copy()
        
        # Calculate True Range components
        df['prev_close'] = df['close'].shift(1)
        df['tr1'] = df['high'] - df['low']
        df['tr2'] = abs(df['high'] - df['prev_close'])
        df['tr3'] = abs(df['low'] - df['prev_close'])
        
        # True Range is the maximum of the three
        df['tr'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)
        
        # ATR is the rolling mean of TR
        df[f'atr_{period}w'] = df['tr'].rolling(window=period).mean()
        
        # Clean up temporary columns
        df.drop(columns=['prev_close', 'tr1', 'tr2', 'tr3', 'tr'], inplace=True)
        
        return df
    
    def calculate_range_metrics(self, df: pd.DataFrame, period: int = None) -> pd.DataFrame:
        """Calculate range metrics for consolidation detection"""
        if df.empty:
            return df
        
        period = period or self.config.RANGE_WEEKS
        df = df.copy()
        
        # Calculate rolling high and low
        df[f'range_high_{period}w'] = df['close'].rolling(window=period).max()
        df[f'range_low_{period}w'] = df['close'].rolling(window=period).min()
        
        # Range percentage
        df[f'range_pct_{period}w'] = ((df[f'range_high_{period}w'] - df[f'range_low_{period}w']) / 
                                     df[f'range_low_{period}w'] * 100)
        
        # ATR shrink (current ATR vs ATR 20 periods ago)
        atr_col = f'atr_{self.config.ATR_WEEKS}w'
        if atr_col in df.columns:
            df['atr_shrink'] = df[atr_col] / df[atr_col].shift(period) < self.config.ATR_SHRINK_THRESHOLD
        
        return df
    
    def calculate_volume_metrics(self, df: pd.DataFrame, period: int = None) -> pd.DataFrame:
        """Calculate volume metrics"""
        if df.empty:
            return df
        
        period = period or self.config.VOL_MA_WEEKS
        df = df.copy()
        
        # Volume moving average
        df[f'vol_ma_{period}w'] = df['volume'].rolling(window=period).mean()
        
        # Volume spike (latest volume vs MA)
        df['vol_spike'] = df['volume'] / df[f'vol_ma_{period}w']
        
        # Volume Z-score
        vol_std = df['volume'].rolling(window=period).std()
        df['vol_z'] = (df['volume'] - df[f'vol_ma_{period}w']) / vol_std
        
        return df
    
    def calculate_relative_strength(self, price_df: pd.DataFrame, 
                                  benchmark_df: pd.DataFrame, 
                                  period: int = None) -> pd.DataFrame:
        """Calculate relative strength vs benchmark"""
        if price_df.empty or benchmark_df.empty:
            return price_df
        
        period = period or self.config.RS_WEEKS
        df = price_df.copy()
        
        # Align dates
        benchmark_aligned = benchmark_df.reindex(price_df.index, method='ffill')
        
        # Calculate relative strength
        price_returns = df['close'] / df['close'].shift(period)
        benchmark_returns = benchmark_aligned['close'] / benchmark_aligned['close'].shift(period)
        
        df[f'rs_{period}w'] = price_returns / benchmark_returns
        
        # RS Z-score (for normalization)
        rs_mean = df[f'rs_{period}w'].rolling(window=period*2).mean()
        rs_std = df[f'rs_{period}w'].rolling(window=period*2).std()
        df[f'rs_z_{period}w'] = (df[f'rs_{period}w'] - rs_mean) / rs_std
        
        return df
    
    def detect_hhhl_pattern(self, df: pd.DataFrame, lookback: int = 3) -> pd.DataFrame:
        """Detect Higher Highs / Higher Lows pattern"""
        if df.empty:
            return df
        
        df = df.copy()
        
        # Find swing highs and lows using rolling windows
        swing_window = 5  # Look for peaks/troughs in 5-week windows
        
        df['swing_high'] = df['high'].rolling(window=swing_window, center=True).max() == df['high']
        df['swing_low'] = df['low'].rolling(window=swing_window, center=True).min() == df['low']
        
        # Get recent swing highs and lows
        recent_highs = df[df['swing_high']]['high'].tail(lookback)
        recent_lows = df[df['swing_low']]['low'].tail(lookback)
        
        # Check for higher highs
        if len(recent_highs) >= 2:
            df['higher_highs'] = recent_highs.is_monotonic_increasing
        else:
            df['higher_highs'] = False
        
        # Check for higher lows  
        if len(recent_lows) >= 2:
            df['higher_lows'] = recent_lows.is_monotonic_increasing
        else:
            df['higher_lows'] = False
        
        # Overall HHHL pattern
        df['hhhl_pattern'] = df['higher_highs'] & df['higher_lows']
        
        return df
    
    def calculate_breakout_metrics(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate breakout detection metrics"""
        if df.empty:
            return df
        
        df = df.copy()
        
        range_high_col = f'range_high_{self.config.RANGE_WEEKS}w'
        if range_high_col not in df.columns:
            return df
        
        # Breakout level with buffer
        df['breakout_level'] = df[range_high_col] * (1 + self.config.BREAKOUT_BUFFER)
        
        # Breakout signal
        df['breakout_signal'] = df['close'] > df['breakout_level']
        
        # Breakout strength (how far above breakout level)
        df['breakout_strength'] = (df['close'] - df['breakout_level']) / df['breakout_level'] * 100
        
        return df
    
    def calculate_all_indicators(self, daily_df: pd.DataFrame, 
                               benchmark_df: pd.DataFrame = None) -> pd.DataFrame:
        """Calculate all technical indicators for weekly data"""
        if daily_df.empty:
            return daily_df
        
        logger.info("Calculating technical indicators...")
        
        # Resample to weekly
        weekly_df = self.resample_to_weekly(daily_df)
        
        if weekly_df.empty:
            return weekly_df
        
        # Calculate all indicators
        weekly_df = self.calculate_moving_averages(weekly_df)
        weekly_df = self.calculate_atr(weekly_df)
        weekly_df = self.calculate_range_metrics(weekly_df)
        weekly_df = self.calculate_volume_metrics(weekly_df)
        weekly_df = self.detect_hhhl_pattern(weekly_df)
        weekly_df = self.calculate_breakout_metrics(weekly_df)
        
        # Calculate relative strength if benchmark provided
        if benchmark_df is not None:
            weekly_df = self.calculate_relative_strength(weekly_df, benchmark_df)
        
        # Clean up any infinite or NaN values
        weekly_df = weekly_df.replace([np.inf, -np.inf], np.nan)
        
        logger.info(f"Calculated indicators for {len(weekly_df)} weekly periods")
        return weekly_df
    
    def get_latest_values(self, df: pd.DataFrame) -> Dict:
        """Get the latest values for all indicators"""
        if df.empty:
            return {}
        
        latest = df.iloc[-1].to_dict()
        
        # Convert numpy types to Python types for JSON serialization
        for key, value in latest.items():
            if isinstance(value, (np.integer, np.floating)):
                if np.isnan(value) or np.isinf(value):
                    latest[key] = None
                else:
                    latest[key] = float(value) if isinstance(value, np.floating) else int(value)
            elif isinstance(value, np.bool_):
                latest[key] = bool(value)
        
        return latest
