"""
TRIX Monthly Scanner for Kite Connect
Simple, self-contained scanner for monthly timeframe analysis
All configuration in one file - just update the CONFIG section below
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import time
from datetime import datetime, timedelta
import logging
import json
import os
from typing import Dict, List, Optional

# =============================================================================
# CONFIGURATION - EDIT THESE VALUES
# =============================================================================

CONFIG = {
    # Kite Connect Credentials
    "API_KEY": "3bi2yh8g830vq3y6",
    "ACCESS_TOKEN": "kVsfVL0vNhCvKJG7eCY1cH4uhZUFZrXr",
    
    # TRIX Parameters
    "TRIX_LENGTH": 14,              # EMA period for TRIX
    "SIGNAL_TYPE": "SMA",           # "SMA" or "EMA"
    "SIGNAL_LENGTH": 9,             # Signal line period
    "TRIX_MULTIPLIER": 1,           # Scale TRIX values
    
    # Scanning Settings
    "LOOKBACK_DAYS": 1825,          # 5 years for monthly (60 candles)
    "ZERO_TOLERANCE_PERCENT": 4.0,  # ±4% around zero line
    "MIN_VOLUME_RATIO": 0.5,        # Min volume vs 20-period average
    
    # Scoring Weights (total = 100)
    "WEIGHT_CROSSOVER": 30,
    "WEIGHT_NEAR_ZERO": 25,
    "WEIGHT_POSITIVE_HISTOGRAM": 15,
    "WEIGHT_POSITIVE_SLOPE": 10,
    "WEIGHT_VOLUME_BOOST": 10,
    "WEIGHT_MOMENTUM_BONUS": 10,
    
    # Filters (NO LONGER USED - ALL DATA RETURNED)
    "ONLY_CROSSOVERS": False,       # Kept for reference only
    "ONLY_NEAR_ZERO": False,        # Kept for reference only
    "MIN_OPPORTUNITY_SCORE": 0,     # Kept for reference only
    "MAX_RESULTS": None,            # Kept for reference only
    
    # Files
    "INPUT_CSV": "data/MCAP-great2500.csv",       # Input symbols file
    "OUTPUT_CSV": "trix_monthly_results_{timestamp}.csv",
    "CACHE_FILE": "nse_instruments_cache.json",
    "CACHE_HOURS": 24,              # Cache validity
    
    # Rate Limiting
    "MAX_CALLS_PER_SECOND": 3,
    "DELAY_BETWEEN_SYMBOLS": 0.1,
}

# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('trix_monthly_scanner.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


# =============================================================================
# RATE LIMITER
# =============================================================================

class RateLimiter:
    """Simple rate limiter for Kite API"""
    
    def __init__(self, max_calls: int = 3):
        self.max_calls = max_calls
        self.calls = []
    
    def wait_if_needed(self):
        now = time.time()
        self.calls = [t for t in self.calls if now - t < 1.0]
        
        if len(self.calls) >= self.max_calls:
            sleep_time = 1.0 - (now - self.calls[0]) + 0.1
            if sleep_time > 0:
                time.sleep(sleep_time)
                self.calls = []
        
        self.calls.append(time.time())


# =============================================================================
# INSTRUMENT CACHE
# =============================================================================

class InstrumentCache:
    """Cache NSE instruments"""
    
    def __init__(self, kite: KiteConnect):
        self.kite = kite
        self.cache_file = CONFIG["CACHE_FILE"]
        self.cache_hours = CONFIG["CACHE_HOURS"]
        self.instruments = {}
        self._load_or_refresh()
    
    def _load_or_refresh(self):
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    cache_data = json.load(f)
                    cache_time = datetime.fromisoformat(cache_data['timestamp'])
                    
                    if datetime.now() - cache_time < timedelta(hours=self.cache_hours):
                        self.instruments = cache_data['instruments']
                        logger.info(f"✅ Loaded {len(self.instruments)} instruments from cache")
                        return
            except Exception as e:
                logger.warning(f"Cache load failed: {e}")
        
        self._refresh_from_api()
    
    def _refresh_from_api(self):
        logger.info("Fetching instruments from Kite API...")
        try:
            instruments_list = self.kite.instruments("NSE")
            self.instruments = {
                inst['tradingsymbol']: {
                    'instrument_token': inst['instrument_token'],
                    'name': inst['name']
                }
                for inst in instruments_list
            }
            
            cache_data = {
                'timestamp': datetime.now().isoformat(),
                'instruments': self.instruments
            }
            with open(self.cache_file, 'w') as f:
                json.dump(cache_data, f)
            
            logger.info(f"✅ Cached {len(self.instruments)} instruments")
        except Exception as e:
            logger.error(f"Failed to fetch instruments: {e}")
            raise
    
    def get_token(self, symbol: str) -> Optional[int]:
        return self.instruments.get(symbol, {}).get('instrument_token')


# =============================================================================
# TRIX CALCULATOR
# =============================================================================

class TRIXCalculator:
    """Calculate TRIX indicator"""
    
    @staticmethod
    def ema(data: pd.Series, period: int) -> pd.Series:
        return data.ewm(span=period, adjust=False).mean()
    
    @staticmethod
    def sma(data: pd.Series, period: int) -> pd.Series:
        return data.rolling(window=period).mean()
    
    @staticmethod
    def calculate_trix(df: pd.DataFrame) -> pd.DataFrame:
        length = CONFIG["TRIX_LENGTH"]
        signal_type = CONFIG["SIGNAL_TYPE"]
        signal_length = CONFIG["SIGNAL_LENGTH"]
        multiplier = CONFIG["TRIX_MULTIPLIER"]
        
        # Triple EMA
        ema1 = TRIXCalculator.ema(df['close'], length)
        ema2 = TRIXCalculator.ema(ema1, length)
        ema3 = TRIXCalculator.ema(ema2, length)
        
        # TRIX = Rate of Change
        trix = ((ema3 - ema3.shift(1)) / ema3.shift(1)) * 100 * multiplier
        
        # Signal line
        if signal_type.upper() == "EMA":
            signal = TRIXCalculator.ema(trix, signal_length)
        else:
            signal = TRIXCalculator.sma(trix, signal_length)
        
        df['trix'] = trix
        df['signal'] = signal
        df['histogram'] = trix - signal
        
        return df


# =============================================================================
# MAIN SCANNER
# =============================================================================

class TRIXMonthlyScanner:
    """Monthly TRIX Scanner"""
    
    def __init__(self):
        # Validate config
        if CONFIG["API_KEY"] == "your_api_key_here":
            raise ValueError("❌ Please set API_KEY in CONFIG section")
        if CONFIG["ACCESS_TOKEN"] == "your_access_token_here":
            raise ValueError("❌ Please set ACCESS_TOKEN in CONFIG section")
        
        # Initialize
        self.kite = KiteConnect(api_key=CONFIG["API_KEY"])
        self.kite.set_access_token(CONFIG["ACCESS_TOKEN"])
        self.rate_limiter = RateLimiter(CONFIG["MAX_CALLS_PER_SECOND"])
        self.cache = InstrumentCache(self.kite)
        
        logger.info("="*80)
        logger.info("TRIX MONTHLY SCANNER INITIALIZED")
        logger.info("="*80)
        logger.info(f"TRIX Length: {CONFIG['TRIX_LENGTH']}")
        logger.info(f"Signal Type: {CONFIG['SIGNAL_TYPE']} ({CONFIG['SIGNAL_LENGTH']})")
        logger.info(f"Zero Tolerance: ±{CONFIG['ZERO_TOLERANCE_PERCENT']}%")
        logger.info(f"Lookback: {CONFIG['LOOKBACK_DAYS']} days")
        logger.info("="*80)
    
    def resample_to_monthly(self, df: pd.DataFrame) -> pd.DataFrame:
        """Resample daily data to monthly candles"""
        df = df.copy()
        df.set_index('date', inplace=True)
        
        resampled = df.resample('MS').agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        })
        
        resampled = resampled.dropna(subset=['close'])
        resampled.reset_index(inplace=True)
        
        logger.debug(f"Resampled {len(df)} daily → {len(resampled)} monthly candles")
        return resampled
    
    def fetch_and_resample(self, instrument_token: int) -> Optional[pd.DataFrame]:
        """Fetch daily data and resample to monthly"""
        try:
            self.rate_limiter.wait_if_needed()
            
            to_date = datetime.now()
            from_date = to_date - timedelta(days=CONFIG["LOOKBACK_DAYS"])
            
            # Fetch daily data
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            if not data or len(data) < 100:
                return None
            
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df = df.sort_values('date').reset_index(drop=True)
            
            # Resample to monthly
            monthly_df = self.resample_to_monthly(df)
            
            if len(monthly_df) < 50:
                logger.warning(f"Only {len(monthly_df)} monthly candles - need more data")
                return None
            
            return monthly_df
        
        except Exception as e:
            logger.error(f"Error fetching data: {e}")
            return None
    
    def analyze_symbol(self, symbol: str) -> Optional[Dict]:
        """Analyze single symbol - ALWAYS return data if available"""
        logger.info(f"Analyzing {symbol}...")
        
        # Get token
        token = self.cache.get_token(symbol)
        if not token:
            logger.warning(f"Symbol {symbol} not found")
            return None
        
        # Fetch monthly data
        df = self.fetch_and_resample(token)
        if df is None:
            return None
        
        # Calculate TRIX
        df = TRIXCalculator.calculate_trix(df)
        df = df.dropna()
        
        if len(df) < 10:
            return None
        
        # Get latest values and last 2 bars for crossover detection
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        prev2 = df.iloc[-3] if len(df) >= 3 else None
        
        trix_curr = latest['trix']
        signal_curr = latest['signal']
        trix_prev = prev['trix']
        signal_prev = prev['signal']
        
        # Detect crossovers in LAST 2 BARS
        # Bar -1 (latest)
        crossover_bar1 = (trix_prev <= signal_prev) and (trix_curr > signal_curr)
        crossunder_bar1 = (trix_prev >= signal_prev) and (trix_curr < signal_curr)
        
        # Bar -2 (previous)
        crossover_bar2 = False
        crossunder_bar2 = False
        if prev2 is not None:
            trix_prev2 = prev2['trix']
            signal_prev2 = prev2['signal']
            crossover_bar2 = (trix_prev2 <= signal_prev2) and (trix_prev > signal_prev)
            crossunder_bar2 = (trix_prev2 >= signal_prev2) and (trix_prev < signal_prev)
        
        # Any crossover in last 2 bars?
        crossover_recent = crossover_bar1 or crossover_bar2
        crossunder_recent = crossunder_bar1 or crossunder_bar2
        
        # Determine which bar had the crossover
        crossover_bar = "Latest" if crossover_bar1 else ("Previous" if crossover_bar2 else "None")
        crossunder_bar = "Latest" if crossunder_bar1 else ("Previous" if crossunder_bar2 else "None")
        
        # Check near zero
        near_zero = abs(trix_curr) <= CONFIG["ZERO_TOLERANCE_PERCENT"]
        
        # Metrics
        histogram = latest['histogram']
        trix_slope = trix_curr - trix_prev
        
        # Histogram momentum
        hist_values = df['histogram'].tail(5).values
        if len(hist_values) >= 3:
            hist_momentum = "Accelerating" if all(hist_values[i] < hist_values[i+1] 
                                                   for i in range(len(hist_values)-1)) else \
                           "Decelerating" if all(hist_values[i] > hist_values[i+1] 
                                                for i in range(len(hist_values)-1)) else "Mixed"
        else:
            hist_momentum = "N/A"
        
        # Price change
        current_price = latest['close']
        price_change_3m = ((current_price - df.iloc[-4]['close']) / df.iloc[-4]['close'] * 100) \
                          if len(df) >= 4 else 0
        
        # Volume analysis
        avg_volume = df['volume'].tail(20).mean()
        current_volume = latest['volume']
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 0
        
        # Calculate scores (always calculate, regardless of filters)
        signal_strength = self._calc_signal_strength(crossover_recent, near_zero, histogram, trix_slope)
        opportunity_score = self._calc_opportunity_score(crossover_recent, near_zero, histogram, 
                                                         trix_slope, volume_ratio)
        
        # Generate note (always generate, regardless of filters)
        note = self._generate_note(crossover_recent, crossunder_recent, near_zero, trix_curr, 
                                   histogram, hist_momentum, trix_slope, volume_ratio, 
                                   crossover_bar, crossunder_bar)
        
        # ALWAYS return data - no filtering here
        return {
            'symbol': symbol,
            'month': latest['date'].strftime('%Y-%m'),
            'close_price': round(current_price, 2),
            'trix': round(trix_curr, 4),
            'signal': round(signal_curr, 4),
            'histogram': round(histogram, 4),
            'trix_slope': round(trix_slope, 4),
            'distance_from_zero': round(trix_curr, 4),
            'crossover_latest_bar': crossover_bar1,
            'crossover_prev_bar': crossover_bar2,
            'crossover_any_last2': crossover_recent,
            'crossover_at_bar': crossover_bar,
            'crossunder_latest_bar': crossunder_bar1,
            'crossunder_prev_bar': crossunder_bar2,
            'crossunder_any_last2': crossunder_recent,
            'crossunder_at_bar': crossunder_bar,
            'near_zero_line': near_zero,
            'signal_strength': signal_strength,
            'histogram_momentum': hist_momentum,
            'price_change_3m_pct': round(price_change_3m, 2),
            'volume_ratio': round(volume_ratio, 2),
            'avg_volume_20m': int(avg_volume),
            'current_volume': int(current_volume),
            'opportunity_score': opportunity_score,
            'note': note
        }
    
    def _calc_signal_strength(self, crossover: bool, near_zero: bool, 
                             histogram: float, trix_slope: float) -> str:
        if not crossover:
            return "No Signal"
        if near_zero and histogram > 0.01 and trix_slope > 0:
            return "Strong"
        elif near_zero and histogram > 0:
            return "Moderate"
        elif crossover:
            return "Weak"
        return "No Signal"
    
    def _calc_opportunity_score(self, crossover: bool, near_zero: bool, 
                                histogram: float, trix_slope: float, 
                                volume_ratio: float) -> int:
        score = 0
        
        if crossover:
            score += CONFIG["WEIGHT_CROSSOVER"]
        if near_zero:
            score += CONFIG["WEIGHT_NEAR_ZERO"]
        if histogram > 0:
            score += CONFIG["WEIGHT_POSITIVE_HISTOGRAM"]
        if trix_slope > 0:
            score += CONFIG["WEIGHT_POSITIVE_SLOPE"]
        if volume_ratio > 1.2:
            score += CONFIG["WEIGHT_VOLUME_BOOST"]
        if histogram > 0.01 and trix_slope > 0.01:
            score += CONFIG["WEIGHT_MOMENTUM_BONUS"]
        
        return min(score, 100)
    
    def _generate_note(self, crossover: bool, crossunder: bool, near_zero: bool,
                       trix: float, histogram: float, hist_momentum: str,
                       trix_slope: float, volume_ratio: float,
                       crossover_bar: str, crossunder_bar: str) -> str:
        notes = []
        
        # Crossover information
        if crossover:
            if crossover_bar == "Latest":
                if near_zero:
                    notes.append("🎯 PRIME: Bullish crossover THIS MONTH near zero - major reversal signal")
                else:
                    notes.append("✅ Bullish crossover THIS MONTH - momentum shift upward")
            elif crossover_bar == "Previous":
                if near_zero:
                    notes.append("🎯 Recent bullish crossover LAST MONTH near zero - confirm trend")
                else:
                    notes.append("✅ Recent bullish crossover LAST MONTH - early uptrend")
        
        if crossunder:
            if crossunder_bar == "Latest":
                notes.append("⚠️ Bearish crossunder THIS MONTH - momentum shift downward")
            elif crossunder_bar == "Previous":
                notes.append("⚠️ Recent bearish crossunder LAST MONTH - downtrend forming")
        
        if not crossover and not crossunder:
            if near_zero:
                notes.append("⚠️ TRIX near zero - WATCH for crossover signal")
            else:
                if histogram > 0:
                    notes.append("📊 No recent crossover - TRIX above signal (bullish territory)")
                else:
                    notes.append("📊 No recent crossover - TRIX below signal (bearish territory)")
        
        if histogram > 0:
            notes.append(f"📈 Positive histogram ({histogram:.4f}) - bullish momentum")
        else:
            notes.append(f"📉 Negative histogram ({histogram:.4f}) - bearish pressure")
        
        if hist_momentum == "Accelerating":
            notes.append("🚀 Momentum accelerating - strong trend forming")
        elif hist_momentum == "Decelerating":
            notes.append("⚡ Momentum decelerating - trend weakening")
        
        if trix_slope > 0.02:
            notes.append("💪 Strong upward TRIX slope - powerful momentum")
        elif trix_slope < -0.02:
            notes.append("⬇️ Negative TRIX slope - downward pressure")
        
        if volume_ratio > 1.5:
            notes.append(f"📊 High volume ({volume_ratio:.1f}x avg) - strong conviction")
        elif volume_ratio < 0.7:
            notes.append(f"🔇 Low volume ({volume_ratio:.1f}x avg) - weak participation")
        
        if abs(trix) < 1.0:
            notes.append("🎲 Very close to zero - high probability reversal zone")
        
        return " | ".join(notes) if notes else "Neutral - no strong signals"
    
    def scan(self) -> pd.DataFrame:
        """Run the scan - returns data for ALL symbols"""
        # Read input
        input_csv = CONFIG["INPUT_CSV"]
        
        if not os.path.exists(input_csv):
            logger.warning(f"Input file {input_csv} not found, creating sample...")
            sample_df = pd.DataFrame({
                'symbol': ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK', 
                          'SBIN', 'BHARTIARTL', 'LT', 'WIPRO', 'MARUTI']
            })
            sample_df.to_csv(input_csv, index=False)
            logger.info(f"Created sample {input_csv}")
        
        input_df = pd.read_csv(input_csv)
        if 'Symbol' not in input_df.columns:
            raise ValueError("Input CSV must have 'Symbol' column")
        
        symbols = input_df['Symbol'].unique().tolist()
        logger.info(f"🔍 Scanning {len(symbols)} symbols on MONTHLY timeframe...")
        logger.info("📊 Capturing ALL data + crossovers in last 2 bars")
        
        results = []
        failed = []
        
        for i, symbol in enumerate(symbols, 1):
            logger.info(f"Progress: {i}/{len(symbols)} - {symbol}")
            
            result = self.analyze_symbol(symbol)
            if result:
                results.append(result)
            else:
                failed.append(symbol)
            
            time.sleep(CONFIG["DELAY_BETWEEN_SYMBOLS"])
        
        if failed:
            logger.warning(f"⚠️ Failed to fetch data for {len(failed)} symbols: {', '.join(failed)}")
        
        if not results:
            logger.warning("No results - all symbols failed to fetch data")
            return pd.DataFrame()
        
        # Create DataFrame - NO FILTERING, return all data
        results_df = pd.DataFrame(results)
        
        # Sort by opportunity score (but show all)
        results_df = results_df.sort_values('opportunity_score', ascending=False)
        
        logger.info(f"✅ Successfully processed {len(results)} / {len(symbols)} symbols")
        
        return results_df
    
    def save_results(self, results_df: pd.DataFrame) -> str:
        """Save results to CSV"""
        if results_df.empty:
            logger.warning("No results to save")
            return ""
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_csv = CONFIG["OUTPUT_CSV"].replace('{timestamp}', timestamp)
        
        results_df.to_csv(output_csv, index=False)
        logger.info(f"✅ Results saved to {output_csv}")
        
        # Print summary
        self._print_summary(results_df)
        
        return output_csv
    
    def _print_summary(self, df: pd.DataFrame):
        print("\n" + "="*100)
        print("MONTHLY TRIX SCAN SUMMARY")
        print("="*100)
        print(f"Total symbols analyzed: {len(df)}")
        print(f"Strong signals: {len(df[df['signal_strength'] == 'Strong'])}")
        print(f"Crossovers in last 2 bars: {df['crossover_any_last2'].sum()}")
        print(f"  - Latest bar: {df['crossover_latest_bar'].sum()}")
        print(f"  - Previous bar: {df['crossover_prev_bar'].sum()}")
        print(f"Crossunders in last 2 bars: {df['crossunder_any_last2'].sum()}")
        print(f"  - Latest bar: {df['crossunder_latest_bar'].sum()}")
        print(f"  - Previous bar: {df['crossunder_prev_bar'].sum()}")
        print(f"Near zero line: {df['near_zero_line'].sum()}")
        print(f"Average opportunity score: {df['opportunity_score'].mean():.1f}")
        
        # Show crossover opportunities
        crossover_df = df[df['crossover_any_last2'] == True]
        if len(crossover_df) > 0:
            print("\n" + "-"*100)
            print(f"🎯 BULLISH CROSSOVERS IN LAST 2 BARS ({len(crossover_df)} symbols)")
            print("-"*100)
            
            for idx, row in crossover_df.head(10).iterrows():
                print(f"\n{row['symbol']} - Score: {row['opportunity_score']} | {row['crossover_at_bar']} bar")
                print(f"  Month: {row['month']} | Price: ₹{row['close_price']}")
                print(f"  TRIX: {row['trix']:.4f} | Signal: {row['signal']:.4f} | Near Zero: {row['near_zero_line']}")
                print(f"  📝 {row['note']}")
        
        # Show crossunder opportunities
        crossunder_df = df[df['crossunder_any_last2'] == True]
        if len(crossunder_df) > 0:
            print("\n" + "-"*100)
            print(f"⚠️  BEARISH CROSSUNDERS IN LAST 2 BARS ({len(crossunder_df)} symbols)")
            print("-"*100)
            
            for idx, row in crossunder_df.head(5).iterrows():
                print(f"\n{row['symbol']} - Score: {row['opportunity_score']} | {row['crossunder_at_bar']} bar")
                print(f"  Month: {row['month']} | Price: ₹{row['close_price']}")
                print(f"  TRIX: {row['trix']:.4f} | Signal: {row['signal']:.4f}")
        
        # Show top opportunities overall
        print("\n" + "-"*100)
        print("TOP 5 OPPORTUNITIES BY SCORE (ALL DATA)")
        print("-"*100)
        
        for idx, row in df.head(5).iterrows():
            print(f"\n{row['symbol']} - Score: {row['opportunity_score']} | Strength: {row['signal_strength']}")
            print(f"  Month: {row['month']} | Price: ₹{row['close_price']}")
            print(f"  TRIX: {row['trix']:.4f} | Signal: {row['signal']:.4f} | Histogram: {row['histogram']:.4f}")
            print(f"  Crossover(last2): {row['crossover_any_last2']} | Crossunder(last2): {row['crossunder_any_last2']}")
            print(f"  Volume: {row['volume_ratio']:.2f}x | 3M Price Change: {row['price_change_3m_pct']:.2f}%")
            print(f"  📝 {row['note']}")
        
        print("\n" + "="*100 + "\n")


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """Main function"""
    try:
        scanner = TRIXMonthlyScanner()
        results_df = scanner.scan()
        
        if not results_df.empty:
            output_file = scanner.save_results(results_df)
            logger.info(f"\n🎉 Scan complete! All symbol data saved to: {output_file}")
            logger.info(f"📊 Total records: {len(results_df)}")
            logger.info(f"🎯 Crossovers in last 2 bars: {results_df['crossover_any_last2'].sum()}")
            logger.info(f"⚠️  Crossunders in last 2 bars: {results_df['crossunder_any_last2'].sum()}")
        else:
            logger.warning("⚠️ No data could be fetched for any symbols")
            logger.info("Check if symbols are valid NSE symbols and API credentials are correct")
    
    except KeyboardInterrupt:
        logger.info("\n⚠️ Scan interrupted by user")
    except Exception as e:
        logger.error(f"❌ Scanner failed: {e}", exc_info=True)


if __name__ == "__main__":
    main()