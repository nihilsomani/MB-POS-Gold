"""
Example Usage of Weekly→Daily Scanner
Demonstrates how to use the scanner with different configurations and scenarios
"""

import pandas as pd
import logging
from datetime import datetime
from weekly_daily_scanner import WeeklyDailyScanner
from config import config

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def example_basic_scan():
    """Basic example of running the scanner"""
    print("=" * 60)
    print("BASIC SCANNER EXAMPLE")
    print("=" * 60)
    
    # Initialize scanner
    scanner = WeeklyDailyScanner()
    
    # Example symbols (replace with your universe)
    symbols = [
        'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR',
        'ICICIBANK', 'KOTAKBANK', 'SBIN', 'BHARTIARTL', 'ITC',
        'ASIANPAINT', 'MARUTI', 'AXISBANK', 'BAJFINANCE', 'WIPRO'
    ]
    
    # Run full scan
    results = scanner.run_full_scan(symbols, account_capital=100000)
    
    if results['success']:
        print(f"✅ Scan completed successfully!")
        print(f"📊 Processed {results['processed_symbols']} out of {results['total_symbols']} symbols")
        
        # Get top candidates
        top_candidates = scanner.get_top_candidates(min_confidence=0.6, top_n=5)
        if not top_candidates.empty:
            print("\n🏆 Top 5 Candidates:")
            print(top_candidates[['symbol', 'label', 'confidence_score', 'recommendation']].to_string(index=False))
        
        # Export results
        output_file = scanner.export_results()
        print(f"\n💾 Results exported to: {output_file}")
        
    else:
        print(f"❌ Scan failed: {results['error']}")

def example_quick_scan():
    """Example of running a quick scan"""
    print("\n" + "=" * 60)
    print("QUICK SCAN EXAMPLE")
    print("=" * 60)
    
    scanner = WeeklyDailyScanner()
    
    # Larger universe for quick scan
    symbols = [
        'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR',
        'ICICIBANK', 'KOTAKBANK', 'SBIN', 'BHARTIARTL', 'ITC',
        'ASIANPAINT', 'MARUTI', 'AXISBANK', 'BAJFINANCE', 'WIPRO',
        'ULTRACEMCO', 'NESTLEIND', 'POWERGRID', 'NTPC', 'COALINDIA'
    ]
    
    # Run quick scan
    quick_results = scanner.run_quick_scan(symbols, min_confidence=0.5)
    
    if not quick_results.empty:
        print(f"✅ Quick scan completed! Found {len(quick_results)} candidates")
        print("\n📈 Quick Scan Results:")
        print(quick_results.to_string(index=False))
    else:
        print("❌ No candidates found in quick scan")

def example_custom_configuration():
    """Example with custom configuration"""
    print("\n" + "=" * 60)
    print("CUSTOM CONFIGURATION EXAMPLE")
    print("=" * 60)
    
    # Create custom configuration
    from config import ScannerConfig
    
    custom_config = ScannerConfig(
        # More aggressive breakout detection
        BREAKOUT_BUFFER=0.005,  # 0.5% instead of 1%
        WEEKLY_VOL_SPIKE=1.5,   # Lower volume requirement
        
        # Different MA periods
        MA_SHORT_WEEKS=8,
        MA_LONG_WEEKS=24,
        
        # More conservative risk management
        RISK_PERCENT=0.005,     # 0.5% risk per trade
        MAX_POSITION_PERCENT=0.05,  # 5% max position
        
        # Different scoring weights
        SCORING_WEIGHTS={
            'trend_strength': 0.30,
            'range_breakout': 0.25,
            'volume_confirmation': 0.25,
            'relative_strength': 0.15,
            'atr_volatility': 0.05
        }
    )
    
    # Initialize scanner with custom config
    scanner = WeeklyDailyScanner(custom_config)
    
    symbols = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR']
    
    results = scanner.run_full_scan(symbols, account_capital=50000)
    
    if results['success']:
        print("✅ Custom configuration scan completed!")
        
        # Show configuration used
        print(f"\n⚙️ Configuration used:")
        print(f"   MA Short: {custom_config.MA_SHORT_WEEKS} weeks")
        print(f"   MA Long: {custom_config.MA_LONG_WEEKS} weeks")
        print(f"   Risk per trade: {custom_config.RISK_PERCENT*100}%")
        print(f"   Max position: {custom_config.MAX_POSITION_PERCENT*100}%")
        
        # Get results
        top_candidates = scanner.get_top_candidates(min_confidence=0.5, top_n=3)
        if not top_candidates.empty:
            print("\n🏆 Top Candidates with Custom Config:")
            print(top_candidates[['symbol', 'confidence_score', 'risk_reward_ratio']].to_string(index=False))

def example_symbol_analysis():
    """Example of detailed symbol analysis"""
    print("\n" + "=" * 60)
    print("DETAILED SYMBOL ANALYSIS EXAMPLE")
    print("=" * 60)
    
    scanner = WeeklyDailyScanner()
    
    # Run scan on a few symbols
    symbols = ['RELIANCE', 'TCS', 'HDFCBANK']
    results = scanner.run_full_scan(symbols, account_capital=100000)
    
    if results['success']:
        # Get detailed analysis for a specific symbol
        symbol = 'RELIANCE'
        analysis = scanner.get_symbol_analysis(symbol)
        
        if analysis:
            print(f"🔍 Detailed Analysis for {symbol}:")
            print(f"   Stage: {analysis['stage_analysis']['latest_stage']}")
            print(f"   Confidence: {analysis['scoring_analysis']['overall_confidence']:.3f}")
            print(f"   Confidence Level: {analysis['scoring_analysis']['confidence_level']}")
            
            # Show signal breakdown
            signal_scores = analysis['scoring_analysis']['signal_scores']
            print(f"\n📊 Signal Scores:")
            for signal, score in signal_scores.items():
                print(f"   {signal}: {score:.3f}")
            
            # Show trade setup if available
            if analysis['trade_setup']:
                trade_summary = analysis['trade_setup']['trade_summary']
                print(f"\n💰 Trade Setup:")
                print(f"   Entry: ₹{trade_summary['entry_price']:.2f}")
                print(f"   Stop: ₹{trade_summary['stop_price']:.2f}")
                print(f"   Target: ₹{trade_summary['target_price']:.2f}")
                print(f"   Position Size: {trade_summary['position_size']} shares")
                print(f"   Risk-Reward: {trade_summary['risk_reward_ratio']:.1f}:1")
            
            # Show confirmation status
            if analysis['confirmation_analysis']:
                confirmation = analysis['confirmation_analysis']['confirmation']
                print(f"\n✅ Confirmation Status:")
                print(f"   Confirmed: {confirmation['confirmed']}")
                if confirmation['confirmed']:
                    print(f"   Confirmation Date: {confirmation['confirmation_date']}")
                    print(f"   Confirmation Price: ₹{confirmation['confirmation_price']:.2f}")

def example_filtering_and_export():
    """Example of filtering results and exporting"""
    print("\n" + "=" * 60)
    print("FILTERING AND EXPORT EXAMPLE")
    print("=" * 60)
    
    scanner = WeeklyDailyScanner()
    
    symbols = [
        'RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'HINDUNILVR',
        'ICICIBANK', 'KOTAKBANK', 'SBIN', 'BHARTIARTL', 'ITC'
    ]
    
    results = scanner.run_full_scan(symbols, account_capital=100000)
    
    if results['success']:
        # Get all results
        all_results = scanner.csv_output.create_scanner_output(scanner.scanner_results)
        
        # Filter for different criteria
        print("🔍 Filtering Results:")
        
        # High confidence candidates
        high_confidence = scanner.csv_output.filter_by_criteria(
            all_results, min_confidence=0.7
        )
        print(f"   High confidence (≥0.7): {len(high_confidence)} candidates")
        
        # Only confirmed breakouts
        confirmed_breakouts = scanner.csv_output.filter_by_criteria(
            all_results, confirmed_only=True
        )
        print(f"   Confirmed breakouts: {len(confirmed_breakouts)} candidates")
        
        # Good risk-reward ratio
        good_rr = scanner.csv_output.filter_by_criteria(
            all_results, min_risk_reward=2.0
        )
        print(f"   Good risk-reward (≥2:1): {len(good_rr)} candidates")
        
        # Export filtered results
        if not high_confidence.empty:
            high_conf_file = scanner.csv_output.save_scanner_output(
                high_confidence, 
                f"high_confidence_candidates_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            )
            print(f"   High confidence results saved to: {high_conf_file}")

def example_validation_and_troubleshooting():
    """Example of configuration validation and troubleshooting"""
    print("\n" + "=" * 60)
    print("VALIDATION AND TROUBLESHOOTING EXAMPLE")
    print("=" * 60)
    
    scanner = WeeklyDailyScanner()
    
    # Validate configuration
    validation = scanner.validate_configuration()
    
    print("🔧 Configuration Validation:")
    print(f"   Valid: {validation['valid']}")
    
    if validation['issues']:
        print("   ❌ Issues:")
        for issue in validation['issues']:
            print(f"      - {issue}")
    
    if validation['warnings']:
        print("   ⚠️ Warnings:")
        for warning in validation['warnings']:
            print(f"      - {warning}")
    
    if validation['valid']:
        print("   ✅ Configuration is valid!")
    else:
        print("   ❌ Configuration has issues that need to be fixed")

def main():
    """Run all examples"""
    print("🚀 Weekly→Daily Scanner Examples")
    print("=" * 60)
    
    try:
        # Run examples
        example_basic_scan()
        example_quick_scan()
        example_custom_configuration()
        example_symbol_analysis()
        example_filtering_and_export()
        example_validation_and_troubleshooting()
        
        print("\n" + "=" * 60)
        print("✅ All examples completed successfully!")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Error running examples: {e}")
        logger.error(f"Example execution failed: {e}")

if __name__ == "__main__":
    main()
