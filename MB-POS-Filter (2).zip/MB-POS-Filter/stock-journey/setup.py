"""
Quick Setup Script for Weekly→Daily Scanner
Run this to set up your environment and test the scanner
"""

import os
import sys
from pathlib import Path

def create_env_file():
    """Create .env file from template"""
    env_file = Path('.env')
    env_example = Path('env_example.txt')
    
    if env_file.exists():
        print("✅ .env file already exists")
        return True
    
    if env_example.exists():
        # Copy example to .env
        with open(env_example, 'r') as f:
            content = f.read()
        
        with open(env_file, 'w') as f:
            f.write(content)
        
        print("✅ Created .env file from template")
        print("⚠️  Please edit .env file with your Kite Connect credentials")
        return True
    else:
        print("❌ env_example.txt not found")
        return False

def check_credentials():
    """Check if credentials are set"""
    from dotenv import load_dotenv
    load_dotenv()
    
    api_key = os.getenv('KITE_API_KEY', '')
    access_token = os.getenv('KITE_ACCESS_TOKEN', '')
    
    if api_key and access_token:
        print("✅ Kite Connect credentials found")
        return True
    else:
        print("⚠️  Kite Connect credentials not set")
        print("   Please edit .env file with your credentials:")
        print("   KITE_API_KEY=your_api_key_here")
        print("   KITE_ACCESS_TOKEN=your_access_token_here")
        return False

def run_test():
    """Run installation test"""
    print("\n🔍 Running installation test...")
    try:
        # Import and run the test directly
        import test_installation
        return test_installation.main()
    except Exception as e:
        print(f"❌ Installation test failed: {e}")
        return False

def main():
    """Main setup function"""
    print("🚀 Weekly→Daily Scanner Setup")
    print("=" * 50)
    
    # Step 1: Create .env file
    print("\n📝 Step 1: Setting up environment file...")
    if not create_env_file():
        return False
    
    # Step 2: Check credentials
    print("\n🔑 Step 2: Checking credentials...")
    credentials_ok = check_credentials()
    
    # Step 3: Run test
    print("\n🧪 Step 3: Running installation test...")
    test_ok = run_test()
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Setup Summary:")
    print(f"   Environment file: {'✅' if create_env_file() else '❌'}")
    print(f"   Credentials: {'✅' if credentials_ok else '⚠️'}")
    print(f"   Installation test: {'✅' if test_ok else '❌'}")
    
    if test_ok:
        print("\n🎉 Setup complete! You're ready to start scanning.")
        print("\nNext steps:")
        if not credentials_ok:
            print("1. Edit .env file with your Kite Connect credentials")
        print("2. Run: python example_usage.py")
        print("3. Start scanning your universe!")
    else:
        print("\n⚠️  Setup incomplete. Please fix the issues above.")
    
    return test_ok

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
