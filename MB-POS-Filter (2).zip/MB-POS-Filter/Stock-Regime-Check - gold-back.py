import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
import logging
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

class StockRegimeAnalyzer:
    """
    Stock Regime Framework - Analyzes market regimes using multiple technical layers
    """
    
    def __init__(self, api_key: str, access_token: str):
        """
        Initialize with Kite Connect credentials
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Regime thresholds
        self.UPTREND_THRESHOLD = 3
        self.DOWNTREND_THRESHOLD = -3
        self.BREAKOUT_EMERGING_THRESHOLD = 2
        self.STRONG_CONVICTION = 2.5
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def fetch_data(self, symbol: str, days: int = 365) -> pd.DataFrame:
        """
        Fetch OHLCV data from Kite Connect
        """
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            # Get instrument token
            instrument_token = self._get_instrument_token(symbol)
            
            # Fetch weekly data
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=start_date,
                to_date=end_date,
                interval="week"
            )
            
            if not data:
                self.logger.warning(f"No data returned for {symbol}")
                return pd.DataFrame()
            
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            
            return df[['open', 'high', 'low', 'close', 'volume']]
            
        except ValueError as e:
            self.logger.error(f"Symbol not found: {symbol} - {e}")
            return pd.DataFrame()
        except Exception as e:
            self.logger.error(f"Error fetching data for {symbol}: {e}")
            return pd.DataFrame()
    
    def _get_instrument_token(self, symbol: str) -> int:
        """
        Get instrument token for symbol with proper NSE format handling
        """
        try:
            instruments = self.kite.instruments("NSE")
            
            # Try exact match first
            for instrument in instruments:
                if instrument['tradingsymbol'] == symbol:
                    return instrument['instrument_token']
            
            # Try common symbol variations
            symbol_variations = {
                "NIFTY50": "NIFTY 50",
                "HDFC": "HDFCBANK",
                "NIFTY": "NIFTY 50",
                "BANKNIFTY": "NIFTY BANK",
                "FINNIFTY": "NIFTY FIN SERVICE"
            }
            
            if symbol in symbol_variations:
                corrected_symbol = symbol_variations[symbol]
                for instrument in instruments:
                    if instrument['tradingsymbol'] == corrected_symbol:
                        return instrument['instrument_token']
            
            # If still not found, try case-insensitive search
            for instrument in instruments:
                if instrument['tradingsymbol'].upper() == symbol.upper():
                    return instrument['instrument_token']
            
            raise ValueError(f"Symbol {symbol} not found in NSE instruments")
            
        except Exception as e:
            self.logger.error(f"Error looking up symbol {symbol}: {e}")
            raise ValueError(f"Symbol {symbol} not found")
    
    def calculate_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate all technical indicators for the analysis
        """
        if df.empty:
            return df
        
        # Moving Averages
        df['MA_8'] = df['close'].rolling(window=8).mean()
        df['MA_21'] = df['close'].rolling(window=21).mean()
        df['MA_34'] = df['close'].rolling(window=34).mean()
        
        # VWAP (Volume Weighted Average Price)
        df['VWAP'] = (df['close'] * df['volume']).cumsum() / df['volume'].cumsum()
        
        # RSI
        df['RSI'] = self._calculate_rsi(df['close'])
        
        # Rate of Change
        df['ROC'] = df['close'].pct_change(periods=5) * 100
        
        # On Balance Volume
        df['OBV'] = self._calculate_obv(df['close'], df['volume'])
        
        # Average True Range
        df['ATR'] = self._calculate_atr(df)
        df['ATR_percentile'] = df['ATR'].rolling(window=20).apply(
            lambda x: (x.iloc[-1] - x.min()) / (x.max() - x.min()) * 100
        )
        
        # Bollinger Bands
        bb_upper, bb_lower, bb_middle = self._calculate_bollinger_bands(df['close'])
        df['BB_upper'] = bb_upper
        df['BB_lower'] = bb_lower
        df['BB_middle'] = bb_middle
        df['BB_squeeze'] = (bb_upper - bb_lower) / bb_middle < 0.1  # Squeeze condition
        
        # 52-week high/low
        df['52W_high'] = df['high'].rolling(window=52).max()
        df['52W_low'] = df['low'].rolling(window=52).min()
        df['price_vs_52W'] = (df['close'] - df['52W_low']) / (df['52W_high'] - df['52W_low'])
        
        return df
    
    def _calculate_rsi(self, prices: pd.Series, window: int = 14) -> pd.Series:
        """Calculate RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))
    
    def _calculate_obv(self, prices: pd.Series, volumes: pd.Series) -> pd.Series:
        """Calculate On Balance Volume"""
        obv = pd.Series(index=prices.index, dtype=float)
        obv.iloc[0] = volumes.iloc[0]
        
        for i in range(1, len(prices)):
            if prices.iloc[i] > prices.iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] + volumes.iloc[i]
            elif prices.iloc[i] < prices.iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] - volumes.iloc[i]
            else:
                obv.iloc[i] = obv.iloc[i-1]
        
        return obv
    
    def _calculate_atr(self, df: pd.DataFrame, window: int = 14) -> pd.Series:
        """Calculate Average True Range"""
        high_low = df['high'] - df['low']
        high_close_prev = np.abs(df['high'] - df['close'].shift())
        low_close_prev = np.abs(df['low'] - df['close'].shift())
        
        true_range = pd.concat([high_low, high_close_prev, low_close_prev], axis=1).max(axis=1)
        return true_range.rolling(window=window).mean()
    
    def _calculate_bollinger_bands(self, prices: pd.Series, window: int = 20, num_std: float = 2):
        """Calculate Bollinger Bands"""
        rolling_mean = prices.rolling(window=window).mean()
        rolling_std = prices.rolling(window=window).std()
        
        upper_band = rolling_mean + (rolling_std * num_std)
        lower_band = rolling_mean - (rolling_std * num_std)
        
        return upper_band, lower_band, rolling_mean
    
    def analyze_trend_layer(self, df: pd.DataFrame) -> Dict[str, int]:
        """
        Core Technical Layer Analysis
        Returns signals: +1 bullish, -1 bearish, 0 neutral
        """
        if len(df) < 34:  # Need enough data for MA34
            return {'trend_score': 0, 'momentum_score': 0, 'consolidation_score': 0}
        
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        
        signals = {}
        
        # Trend Analysis
        trend_signals = []
        
        # MA Slope and Position
        if latest['MA_8'] > prev['MA_8']:
            trend_signals.append(1)
        elif latest['MA_8'] < prev['MA_8']:
            trend_signals.append(-1)
        else:
            trend_signals.append(0)
        
        # MA Crossovers
        if latest['close'] > latest['MA_8'] > latest['MA_21'] > latest['MA_34']:
            trend_signals.append(1)
        elif latest['close'] < latest['MA_8'] < latest['MA_21'] < latest['MA_34']:
            trend_signals.append(-1)
        else:
            trend_signals.append(0)
        
        # Price vs VWAP
        if latest['close'] > latest['VWAP']:
            trend_signals.append(1)
        elif latest['close'] < latest['VWAP']:
            trend_signals.append(-1)
        else:
            trend_signals.append(0)
        
        signals['trend_score'] = sum(trend_signals)
        
        # Momentum Analysis
        momentum_signals = []
        
        # RSI
        if latest['RSI'] > 60:
            momentum_signals.append(1)
        elif latest['RSI'] < 40:
            momentum_signals.append(-1)
        else:
            momentum_signals.append(0)
        
        # ROC
        if latest['ROC'] > 2:
            momentum_signals.append(1)
        elif latest['ROC'] < -2:
            momentum_signals.append(-1)
        else:
            momentum_signals.append(0)
        
        # 52-week position
        if latest['price_vs_52W'] > 0.8:
            momentum_signals.append(1)
        elif latest['price_vs_52W'] < 0.2:
            momentum_signals.append(-1)
        else:
            momentum_signals.append(0)
        
        signals['momentum_score'] = sum(momentum_signals)
        
        # Consolidation Analysis
        consolidation_signals = []
        
        # ATR percentile (low volatility = consolidation)
        if latest['ATR_percentile'] < 20:
            consolidation_signals.append(1)  # Consolidating
        elif latest['ATR_percentile'] > 80:
            consolidation_signals.append(-1)  # High volatility, trending
        else:
            consolidation_signals.append(0)
        
        # Bollinger Band Squeeze
        if latest['BB_squeeze']:
            consolidation_signals.append(1)
        else:
            consolidation_signals.append(0)
        
        signals['consolidation_score'] = sum(consolidation_signals)
        
        return signals
    
    def analyze_relative_strength(self, stock_df: pd.DataFrame, benchmark_symbol: str = "NIFTY 50") -> int:
        """
        Relative Strength Analysis vs Benchmark
        """
        try:
            benchmark_df = self.fetch_data(benchmark_symbol)
            
            if benchmark_df.empty or stock_df.empty:
                return 0
            
            # Align dates
            common_dates = stock_df.index.intersection(benchmark_df.index)
            if len(common_dates) < 10:
                return 0
            
            stock_aligned = stock_df.loc[common_dates]
            benchmark_aligned = benchmark_df.loc[common_dates]
            
            # Calculate relative strength
            stock_returns = stock_aligned['close'].pct_change(periods=5).fillna(0)
            benchmark_returns = benchmark_aligned['close'].pct_change(periods=5).fillna(0)
            
            relative_strength = (stock_returns - benchmark_returns).rolling(window=10).mean().iloc[-1]
            
            if relative_strength > 0.02:  # Outperforming by 2%
                return 1
            elif relative_strength < -0.02:  # Underperforming by 2%
                return -1
            else:
                return 0
                
        except Exception as e:
            self.logger.error(f"Error in relative strength analysis: {e}")
            return 0
    
    def calculate_regime_score(self, symbol: str) -> Dict:
        """
        Calculate overall regime score and classification
        """
        # Fetch data
        df = self.fetch_data(symbol)
        
        if df.empty:
            return {
                'symbol': symbol,
                'regime': 'NO_DATA',
                'score': 0,
                'conviction': 'Low',
                'factors': []
            }
        
        # Calculate indicators
        df = self.calculate_technical_indicators(df)
        
        # Get technical signals
        tech_signals = self.analyze_trend_layer(df)
        
        # Get relative strength
        relative_score = self.analyze_relative_strength(df)
        
        # Get breakout context analysis
        breakout_context = self.analyze_breakout_context(df)
        
        # Calculate weighted score (updated weights to include breakout context)
        total_score = (
            tech_signals['trend_score'] * 0.3 +      # Reduced from 0.4
            tech_signals['momentum_score'] * 0.25 +  # Reduced from 0.3
            tech_signals['consolidation_score'] * 0.1 +
            relative_score * 0.15 +                  # Reduced from 0.2
            breakout_context['breakout_score'] * 0.2  # New: 20% weight for breakout context
        )
        
        # Determine regime
        if total_score >= self.UPTREND_THRESHOLD:
            regime = 'UPTREND'
        elif total_score <= self.DOWNTREND_THRESHOLD:
            regime = 'DOWNTREND'
        elif total_score >= self.BREAKOUT_EMERGING_THRESHOLD and breakout_context['breakout_score'] >= 3:
            regime = 'BREAKOUT_EMERGING'
        else:
            regime = 'CONSOLIDATION'
        
        # Determine conviction
        if abs(total_score) >= self.STRONG_CONVICTION:
            conviction = 'High'
        elif abs(total_score) >= 1.5:
            conviction = 'Medium'
        else:
            conviction = 'Low'
        
        # Build supporting factors
        factors = self._build_supporting_factors(df, tech_signals, relative_score)
        
        # Add breakout context factors
        factors.extend(breakout_context['breakout_factors'])
        
        return {
            'symbol': symbol,
            'regime': regime,
            'score': round(total_score, 2),
            'conviction': conviction,
            'factors': factors,
            'technical_breakdown': tech_signals,
            'relative_strength': relative_score,
            'breakout_context': breakout_context
        }
    
    def _build_supporting_factors(self, df: pd.DataFrame, tech_signals: Dict, relative_score: int) -> List[str]:
        """
        Build list of supporting factors for transparency
        """
        if df.empty:
            return []
        
        factors = []
        latest = df.iloc[-1]
        
        # Trend factors
        if latest['close'] > latest['MA_21']:
            factors.append("Price above 21-week MA")
        if latest['close'] > latest['VWAP']:
            factors.append("Price above VWAP")
        
        # Momentum factors
        if latest['RSI'] > 60:
            factors.append("RSI in bullish zone (>60)")
        elif latest['RSI'] < 40:
            factors.append("RSI in bearish zone (<40)")
        
        if latest['price_vs_52W'] > 0.8:
            factors.append("Near 52-week high")
        elif latest['price_vs_52W'] < 0.2:
            factors.append("Near 52-week low")
        
        # Consolidation factors
        if latest['BB_squeeze']:
            factors.append("Bollinger Band squeeze detected")
        
        if latest['ATR_percentile'] < 20:
            factors.append("Low volatility regime")
        
        # Relative strength
        if relative_score > 0:
            factors.append("Outperforming benchmark")
        elif relative_score < 0:
            factors.append("Underperforming benchmark")
        
        return factors
    
    def detect_range_expansion(self, df: pd.DataFrame) -> bool:
        """
        Detect 20%+ range expansion vs previous 20-week range
        """
        if len(df) < 40:  # Need at least 40 weeks of data
            return False
        
        # Recent 20-week range
        recent_high = df['high'].tail(20).max()
        recent_low = df['low'].tail(20).min()
        recent_range = recent_high - recent_low
        
        # Previous 20-week range
        prev_high = df['high'].iloc[-40:-20].max()
        prev_low = df['low'].iloc[-40:-20].min()
        prev_range = prev_high - prev_low
        
        if prev_range == 0:
            return False
        
        expansion_ratio = (recent_range - prev_range) / prev_range
        return expansion_ratio >= 0.20  # 20%+ expansion
    
    def detect_volume_confirmation(self, df: pd.DataFrame) -> bool:
        """
        Detect 30%+ volume increase during recent moves
        """
        if len(df) < 10:
            return False
        
        # Recent 5-week average volume
        recent_volume = df['volume'].tail(5).mean()
        
        # Previous 10-week average volume
        prev_volume = df['volume'].iloc[-15:-5].mean()
        
        if prev_volume == 0:
            return False
        
        volume_increase = (recent_volume - prev_volume) / prev_volume
        return volume_increase >= 0.30  # 30%+ volume increase
    
    def detect_ma_divergence(self, df: pd.DataFrame) -> bool:
        """
        Detect when MAs shift from convergence to divergence
        """
        if len(df) < 34:
            return False
        
        # Calculate MA spread
        recent_spread = abs(df['MA_8'].iloc[-1] - df['MA_21'].iloc[-1])
        prev_spread = abs(df['MA_8'].iloc[-10] - df['MA_21'].iloc[-10])
        
        # Check if MAs are diverging (spread increasing)
        return recent_spread > prev_spread * 1.2  # 20%+ divergence
    
    def detect_consolidation_breakthrough(self, df: pd.DataFrame) -> bool:
        """
        Detect 2%+ break above/below previous consolidation range
        """
        if len(df) < 20:
            return False
        
        # Define consolidation range (previous 20 weeks)
        consolidation_high = df['high'].iloc[-20:-1].max()
        consolidation_low = df['low'].iloc[-20:-1].min()
        consolidation_mid = (consolidation_high + consolidation_low) / 2
        
        current_price = df['close'].iloc[-1]
        
        # Check for 2%+ break above or below consolidation range
        break_above = current_price > consolidation_high * 1.02
        break_below = current_price < consolidation_low * 0.98
        
        return break_above or break_below
    
    def detect_higher_highs_pattern(self, df: pd.DataFrame) -> bool:
        """
        Confirm if stock is making progressive higher highs after consolidation
        """
        if len(df) < 15:
            return False
        
        # Look for higher highs in recent 10 weeks
        recent_highs = df['high'].tail(10)
        
        # Check if we have at least 2 higher highs
        higher_highs = 0
        for i in range(1, len(recent_highs)):
            if recent_highs.iloc[i] > recent_highs.iloc[i-1]:
                higher_highs += 1
        
        return higher_highs >= 2
    
    def analyze_breakout_context(self, df: pd.DataFrame) -> Dict:
        """
        Comprehensive breakout context analysis
        """
        if df.empty:
            return {'breakout_score': 0, 'breakout_factors': []}
        
        factors = []
        score = 0
        
        # Range expansion (weight: 3)
        if self.detect_range_expansion(df):
            factors.append("🚀 Range expansion detected (20%+ vs previous range)")
            score += 3
        
        # Volume confirmation (weight: 2)
        if self.detect_volume_confirmation(df):
            factors.append("⚡ Volume surge confirmed (30%+ increase)")
            score += 2
        
        # MA divergence (weight: 2)
        if self.detect_ma_divergence(df):
            factors.append("📈 Moving average divergence detected")
            score += 2
        
        # Consolidation breakthrough (weight: 4)
        if self.detect_consolidation_breakthrough(df):
            factors.append("💥 Consolidation range breakthrough (2%+ break)")
            score += 4
        
        # Higher highs pattern (weight: 2)
        if self.detect_higher_highs_pattern(df):
            factors.append("⬆️ Higher highs pattern confirmed")
            score += 2
        
        return {
            'breakout_score': score,
            'breakout_factors': factors
        }
    
    def detect_breakout_candidates(self, df_results: pd.DataFrame) -> List[str]:
        """
        Detect breakout candidates based on new BREAKOUT_EMERGING regime and advanced criteria
        """
        breakout_candidates = []
        
        for _, row in df_results.iterrows():
            # Primary: BREAKOUT_EMERGING regime
            if row['regime'] == 'BREAKOUT_EMERGING':
                breakout_candidates.append(row['symbol'])
            
            # Secondary: High-scoring consolidation with breakout signals
            elif row['regime'] == 'CONSOLIDATION' and row['score'] > 1.5:
                factors = row['factors']
                breakout_signals = [
                    '🚀 Range expansion detected',
                    '⚡ Volume surge confirmed',
                    '💥 Consolidation range breakthrough',
                    '⬆️ Higher highs pattern confirmed'
                ]
                
                if any(signal in str(factors) for signal in breakout_signals):
                    breakout_candidates.append(row['symbol'])
        
        return breakout_candidates
    
    def generate_market_summary(self, df_results: pd.DataFrame) -> Dict:
        """
        Generate overall market sentiment and distribution analysis
        """
        # Basic statistics
        total_stocks = len(df_results)
        avg_score = df_results['score'].mean()
        
        # Regime distribution
        regime_dist = df_results['regime'].value_counts().to_dict()
        
        # Conviction distribution
        conviction_dist = df_results['conviction'].value_counts().to_dict()
        
        # Top and bottom performers
        top_performers = df_results.nlargest(3, 'score')['symbol'].tolist()
        bottom_performers = df_results.nsmallest(3, 'score')['symbol'].tolist()
        
        # Breakout candidates
        breakout_candidates = self.detect_breakout_candidates(df_results)
        
        # Market sentiment
        if avg_score > 1:
            sentiment = "Bullish Consolidation"
        elif avg_score < -1:
            sentiment = "Bearish Consolidation"
        else:
            sentiment = "Neutral Consolidation"
        
        return {
            'total_stocks': total_stocks,
            'avg_score': round(avg_score, 2),
            'sentiment': sentiment,
            'regime_distribution': regime_dist,
            'conviction_distribution': conviction_dist,
            'top_performers': top_performers,
            'bottom_performers': bottom_performers,
            'breakout_candidates': breakout_candidates
        }
    
    def add_regime_ranking(self, df_results: pd.DataFrame) -> pd.DataFrame:
        """
        Add ranking within each regime
        """
        df_results['regime_rank'] = 0
        
        for regime in df_results['regime'].unique():
            regime_mask = df_results['regime'] == regime
            regime_data = df_results[regime_mask].copy()
            regime_data = regime_data.sort_values('score', ascending=False)
            regime_data['regime_rank'] = range(1, len(regime_data) + 1)
            df_results.loc[regime_mask, 'regime_rank'] = regime_data['regime_rank']
        
        return df_results
    
    def scan_multiple_stocks(self, symbols: List[str]) -> pd.DataFrame:
        """
        Scan multiple stocks and return regime analysis
        """
        results = []
        
        for symbol in symbols:
            self.logger.info(f"Analyzing {symbol}...")
            result = self.calculate_regime_score(symbol)
            results.append(result)
        
        # Convert to DataFrame
        df_results = pd.DataFrame(results)
        
        # Add regime ranking
        df_results = self.add_regime_ranking(df_results)
        
        # Sort by conviction and score
        df_results['abs_score'] = df_results['score'].abs()
        df_results = df_results.sort_values(['conviction', 'abs_score'], 
                                          ascending=[False, False])
        
        return df_results.drop('abs_score', axis=1)

# Usage Example
def main():
    """
    Example usage of the Stock Regime Framework
    """
    # Initialize (replace with your actual API credentials)
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "GwgL1EBcfdAS2YyJrESWbSNbBbUeNNi7"
    
    analyzer = StockRegimeAnalyzer(API_KEY, ACCESS_TOKEN)
    
    # Define your stock universe (using correct NSE symbols)
    stock_symbols = [
        "M&MFIN","MAITHANALL","MAHABANK","PNB","CIEINDIA","IOC","KOTAKBANK","SBIN","CENTRALBK","MTARTECH","SBCL","SCHAEFFLER","HAPPYFORGE","JSWINFRA","LT","KNRCON","BALKRISIND","KIRLOSIND","NETWEB","AVANTEL","CENTUM","SUBROS","PARAGMILK","ABCAPITAL","JMFINANCIL","LUMAXTECH","ASKAUTOLTD","TI","FEDFINA","GABRIEL","HLEGLAS","PROTEAN","TIMETECHNO","WELCORP","WELSPUNLIV"
    ]
    
    # Run the scan
    print("Starting Stock Regime Analysis...")
    results = analyzer.scan_multiple_stocks(stock_symbols)
    
    # Generate market summary
    market_summary = analyzer.generate_market_summary(results)
    
    # Display market summary
    print("\n" + "="*80)
    print("MARKET SUMMARY")
    print("="*80)
    print(f"Total Stocks Analyzed: {market_summary['total_stocks']}")
    print(f"Market Sentiment: {market_summary['sentiment']} (Avg Score: {market_summary['avg_score']})")
    print(f"Regime Distribution: {market_summary['regime_distribution']}")
    print(f"Top Performers: {', '.join(market_summary['top_performers'])}")
    print(f"Bottom Performers: {', '.join(market_summary['bottom_performers'])}")
    if market_summary['breakout_candidates']:
        print(f"⚡ Breakout Candidates: {', '.join(market_summary['breakout_candidates'])}")
    print("="*80)
    
    # Display detailed results
    print("\nDETAILED STOCK ANALYSIS")
    print("="*80)
    
    for _, row in results.iterrows():
        rank_info = f" (Rank #{int(row['regime_rank'])} in {row['regime']})" if 'regime_rank' in row else ""
        print(f"\nSymbol: {row['symbol']}{rank_info}")
        print(f"Regime: {row['regime']} (Score: {row['score']})")
        print(f"Conviction: {row['conviction']}")
        print("Supporting Factors:")
        for factor in row['factors']:
            print(f"  • {factor}")
        print("-" * 40)
    
    # Trading insights
    print("\n" + "="*80)
    print("🎯 TRADING OPPORTUNITIES")
    print("="*80)
    
    # Breakout candidates analysis
    if market_summary['breakout_candidates']:
        print("🚀 BREAKOUT CANDIDATES:")
        for symbol in market_summary['breakout_candidates']:
            stock_data = results[results['symbol'] == symbol].iloc[0]
            print(f"  • {symbol}: {stock_data['regime']} (Score: {stock_data['score']})")
            print(f"    Key factors: {', '.join(stock_data['factors'][:3])}")
    
    # Bearish candidates
    bearish_stocks = results[results['score'] < -0.5]
    if not bearish_stocks.empty:
        print("\n⚠️  AVOID/SHORT CANDIDATES:")
        for _, row in bearish_stocks.iterrows():
            print(f"  • {row['symbol']}: {row['regime']} (Score: {row['score']})")
            print(f"    Key factors: {', '.join(row['factors'][:3])}")
    
    # Market context
    print(f"\n📊 MARKET CONTEXT:")
    print(f"  • Market appears to be in a 'coiling' phase with low volatility")
    print(f"  • {len(market_summary['breakout_candidates'])} stocks showing breakout potential")
    print(f"  • Relative strength clearly differentiating winners from losers")
    print(f"  • Average conviction: {market_summary['conviction_distribution']}")
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results.to_csv(f"regime_analysis_{timestamp}.csv", index=False)
    
    # Save market summary
    summary_df = pd.DataFrame([market_summary])
    summary_df.to_csv(f"market_summary_{timestamp}.csv", index=False)
    
    print(f"\nResults saved to CSV files.")

if __name__ == "__main__":
    main()