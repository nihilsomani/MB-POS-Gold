"""
Simple SAR-Renko Backtester
============================

Backtests PSAR + Renko strategy on last 3 years of data.

Since we don't have historical breadth, we'll use Nifty 500 position 
relative to its 200-MA as a proxy.

Usage:
    python simple_backtest.py --symbols RELIANCE TCS INFY --years 3
    python simple_backtest.py --sample 20  # Test on 20 random stocks
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import logging
import argparse
import time
from typing import List, Dict, Optional
from dataclasses import dataclass

# API Configuration
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "IPu3YFNqPkAlRsmQ6R7whtIhJSJsLsKf"

# Strategy Parameters
PSAR_START = 0.02
PSAR_STEP = 0.02
PSAR_MAX = 0.2
RENKO_ATR_MULTIPLIER = 1.5
MIN_BRICKS = 2

# ADX Filter (NEW!)
USE_ADX_FILTER = True  # Set to False to disable
MIN_ADX = 30  # Minimum trend strength (30 = strong trend, 25 = moderate)

# Risk Parameters
INITIAL_CAPITAL = 1000000
RISK_PER_TRADE = 0.02  # 2%
COMMISSION = 0.0005  # 0.05%
SLIPPAGE = 0.0005  # 0.05%

# Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class Trade:
    symbol: str
    entry_date: datetime
    exit_date: datetime
    entry_price: float
    exit_price: float
    side: str
    pnl: float
    pnl_pct: float
    exit_reason: str
    days_held: int
    breadth_at_entry: float

class SimplePSAR:
    """Simplified PSAR calculator"""
    
    @staticmethod
    def calculate(df: pd.DataFrame, start=0.02, step=0.02, max_af=0.2) -> pd.DataFrame:
        high = df['high'].values
        low = df['low'].values
        close = df['close'].values
        
        n = len(close)
        psar = np.zeros(n)
        trend = np.zeros(n, dtype=int)
        af = np.zeros(n)
        
        psar[0] = close[0]
        trend[0] = 1
        af[0] = start
        ep = high[0]
        
        for i in range(1, n):
            psar[i] = psar[i-1] + af[i-1] * (ep - psar[i-1])
            
            if trend[i-1] == 1:
                psar[i] = min(psar[i], low[i-1], low[i-2] if i > 1 else low[i-1])
                
                if low[i] < psar[i]:
                    trend[i] = -1
                    psar[i] = ep
                    ep = low[i]
                    af[i] = start
                else:
                    trend[i] = 1
                    if high[i] > ep:
                        ep = high[i]
                        af[i] = min(af[i-1] + step, max_af)
                    else:
                        af[i] = af[i-1]
            else:
                psar[i] = max(psar[i], high[i-1], high[i-2] if i > 1 else high[i-1])
                
                if high[i] > psar[i]:
                    trend[i] = 1
                    psar[i] = ep
                    ep = high[i]
                    af[i] = start
                else:
                    trend[i] = -1
                    if low[i] < ep:
                        ep = low[i]
                        af[i] = min(af[i-1] + step, max_af)
                    else:
                        af[i] = af[i-1]
        
        df['psar'] = psar
        df['psar_trend'] = trend
        return df

class SimpleADX:
    """Simplified ADX calculator"""
    
    @staticmethod
    def calculate(df: pd.DataFrame, period=14) -> pd.DataFrame:
        """Calculate ADX (Average Directional Index)"""
        high = df['high']
        low = df['low']
        close = df['close']
        
        # True Range
        tr1 = high - low
        tr2 = abs(high - close.shift(1))
        tr3 = abs(low - close.shift(1))
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        
        # Directional Movement
        up_move = high - high.shift(1)
        down_move = low.shift(1) - low
        
        plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0)
        minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0)
        
        plus_dm = pd.Series(plus_dm, index=df.index)
        minus_dm = pd.Series(minus_dm, index=df.index)
        
        # Smooth
        atr_smooth = tr.ewm(alpha=1/period, adjust=False).mean()
        plus_di = 100 * (plus_dm.ewm(alpha=1/period, adjust=False).mean() / atr_smooth)
        minus_di = 100 * (minus_dm.ewm(alpha=1/period, adjust=False).mean() / atr_smooth)
        
        # Calculate DX
        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        
        # ADX
        adx = dx.ewm(alpha=1/period, adjust=False).mean()
        
        df['adx'] = adx
        return df

class SimpleRenko:
    """Simplified Renko calculator"""
    
    @staticmethod
    def calculate(df: pd.DataFrame, atr_mult=1.5) -> pd.DataFrame:
        # Calculate ATR
        high = df['high']
        low = df['low']
        close = df['close']
        
        tr1 = high - low
        tr2 = abs(high - close.shift(1))
        tr3 = abs(low - close.shift(1))
        tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = tr.rolling(window=14).mean()
        
        brick_size = atr * atr_mult
        
        # Build bricks
        prices = close.values
        brick_dirs = np.zeros(len(prices), dtype=int)
        brick_prices = np.zeros(len(prices))
        
        current_brick = prices[0]
        last_dir = 0
        
        for i in range(len(prices)):
            if pd.isna(brick_size.iloc[i]):
                brick_dirs[i] = 0
                brick_prices[i] = current_brick
                continue
                
            bs = brick_size.iloc[i]
            price = prices[i]
            move = price - current_brick
            
            if move >= bs:
                num_bricks = int(move / bs)
                current_brick += num_bricks * bs
                brick_dirs[i] = 1
                last_dir = 1
            elif move <= -bs:
                num_bricks = int(abs(move) / bs)
                current_brick -= num_bricks * bs
                brick_dirs[i] = -1
                last_dir = -1
            else:
                brick_dirs[i] = 0
            
            brick_prices[i] = current_brick
        
        df['renko_dir'] = brick_dirs
        df['renko_price'] = brick_prices
        
        # Count consecutive
        consecutive = np.zeros(len(brick_dirs), dtype=int)
        count = 0
        last_d = 0
        
        for i, d in enumerate(brick_dirs):
            if d == 0:
                consecutive[i] = count
            elif d == last_d and d != 0:
                count += 1
                consecutive[i] = count
            else:
                count = 1 if d != 0 else 0
                consecutive[i] = count
                last_d = d if d != 0 else last_d
        
        df['renko_consecutive'] = consecutive
        return df

class SimpleBacktester:
    """Simple backtest engine"""
    
    def __init__(self, kite: KiteConnect):
        self.kite = kite
        self.instrument_map = {}
        self._load_instruments()
        
    def _load_instruments(self):
        logger.info("Loading instruments...")
        instruments = self.kite.instruments("NSE")
        for inst in instruments:
            if inst['exchange'] == 'NSE' and inst['instrument_type'] == 'EQ':
                self.instrument_map[inst['tradingsymbol']] = inst['instrument_token']
        logger.info(f"Loaded {len(self.instrument_map)} instruments")
    
    def fetch_historical(self, symbol: str, years: int = 3) -> Optional[pd.DataFrame]:
        """Fetch historical data"""
        try:
            if symbol not in self.instrument_map:
                logger.warning(f"{symbol} not found")
                return None
            
            token = self.instrument_map[symbol]
            to_date = datetime.now()
            from_date = to_date - timedelta(days=years*365)
            
            data = self.kite.historical_data(
                token,
                from_date.strftime('%Y-%m-%d'),
                to_date.strftime('%Y-%m-%d'),
                'day'
            )
            
            df = pd.DataFrame(data)
            df['symbol'] = symbol
            
            logger.info(f"{symbol}: {len(df)} bars from {df['date'].min()} to {df['date'].max()}")
            return df
            
        except Exception as e:
            logger.error(f"Failed to fetch {symbol}: {e}")
            return None
    
    def calculate_nifty_breadth_proxy(self, df: pd.DataFrame) -> pd.Series:
        """
        Use Nifty 500 position relative to 200-MA as breadth proxy
        
        Logic:
        Nifty > 200-MA = 60% breadth
        Nifty < 200-MA = 40% breadth
        """
        # For simplicity, use the stock's own 200-MA position
        # In production, fetch actual Nifty data
        ma_200 = df['close'].rolling(window=200).mean()
        
        breadth = np.where(df['close'] > ma_200, 60, 40)
        return pd.Series(breadth, index=df.index)
    
    def backtest_symbol(self, symbol: str, years: int = 3) -> Dict:
        """Backtest single symbol"""
        logger.info(f"\n{'='*60}")
        logger.info(f"Backtesting {symbol}")
        logger.info(f"{'='*60}")
        
        # Fetch data
        df = self.fetch_historical(symbol, years)
        if df is None or len(df) < 250:
            return None
        
        # Calculate indicators
        df = SimplePSAR.calculate(df, PSAR_START, PSAR_STEP, PSAR_MAX)
        df = SimpleRenko.calculate(df, RENKO_ATR_MULTIPLIER)
        df = SimpleADX.calculate(df)  # Add ADX calculation
        df['breadth_proxy'] = self.calculate_nifty_breadth_proxy(df)
        
        # Identify signals
        df['psar_reversal'] = (df['psar_trend'] != df['psar_trend'].shift(1)).astype(int)
        
        # Long signals (NOW WITH ADX FILTER!)
        long_conditions = (
            (df['psar_trend'] == 1) & 
            (df['psar_reversal'] == 1) &
            (df['renko_consecutive'] >= MIN_BRICKS) &
            (df['renko_dir'] == 1) &
            (df['breadth_proxy'] >= 50)
        )
        
        # Add ADX filter if enabled
        if USE_ADX_FILTER:
            long_conditions = long_conditions & (df['adx'] >= MIN_ADX)
        
        df['long_signal'] = long_conditions
        
        # Short signals (NOW WITH ADX FILTER!)
        short_conditions = (
            (df['psar_trend'] == -1) &
            (df['psar_reversal'] == 1) &
            (df['renko_consecutive'] >= MIN_BRICKS) &
            (df['renko_dir'] == -1) &
            (df['breadth_proxy'] <= 50)
        )
        
        # Add ADX filter if enabled
        if USE_ADX_FILTER:
            short_conditions = short_conditions & (df['adx'] >= MIN_ADX)
        
        df['short_signal'] = short_conditions
        
        # Simulate trades
        trades = []
        position = None
        
        for i in range(len(df)):
            row = df.iloc[i]
            
            # Check for exits first
            if position:
                # PSAR stop hit
                if position['side'] == 'LONG' and row['low'] <= position['stop']:
                    exit_price = position['stop'] * (1 - SLIPPAGE)
                    pnl = (exit_price - position['entry_price']) * position['qty']
                    pnl -= (position['entry_price'] + exit_price) * position['qty'] * COMMISSION
                    
                    trades.append(Trade(
                        symbol=symbol,
                        entry_date=position['entry_date'],
                        exit_date=row['date'],
                        entry_price=position['entry_price'],
                        exit_price=exit_price,
                        side='LONG',
                        pnl=pnl,
                        pnl_pct=(pnl / (position['entry_price'] * position['qty'])) * 100,
                        exit_reason='stop_loss',
                        days_held=(row['date'] - position['entry_date']).days,
                        breadth_at_entry=position['breadth']
                    ))
                    position = None
                    
                elif position['side'] == 'SHORT' and row['high'] >= position['stop']:
                    exit_price = position['stop'] * (1 + SLIPPAGE)
                    pnl = (position['entry_price'] - exit_price) * position['qty']
                    pnl -= (position['entry_price'] + exit_price) * position['qty'] * COMMISSION
                    
                    trades.append(Trade(
                        symbol=symbol,
                        entry_date=position['entry_date'],
                        exit_date=row['date'],
                        entry_price=position['entry_price'],
                        exit_price=exit_price,
                        side='SHORT',
                        pnl=pnl,
                        pnl_pct=(pnl / (position['entry_price'] * position['qty'])) * 100,
                        exit_reason='stop_loss',
                        days_held=(row['date'] - position['entry_date']).days,
                        breadth_at_entry=position['breadth']
                    ))
                    position = None
                
                # Signal exit (PSAR reversal)
                elif position and ((position['side'] == 'LONG' and row['psar_trend'] == -1) or 
                                  (position['side'] == 'SHORT' and row['psar_trend'] == 1)):
                    exit_price = row['close'] * (1 - SLIPPAGE if position['side'] == 'LONG' else 1 + SLIPPAGE)
                    
                    if position['side'] == 'LONG':
                        pnl = (exit_price - position['entry_price']) * position['qty']
                    else:
                        pnl = (position['entry_price'] - exit_price) * position['qty']
                    
                    pnl -= (position['entry_price'] + exit_price) * position['qty'] * COMMISSION
                    
                    trades.append(Trade(
                        symbol=symbol,
                        entry_date=position['entry_date'],
                        exit_date=row['date'],
                        entry_price=position['entry_price'],
                        exit_price=exit_price,
                        side=position['side'],
                        pnl=pnl,
                        pnl_pct=(pnl / (position['entry_price'] * position['qty'])) * 100,
                        exit_reason='signal_exit',
                        days_held=(row['date'] - position['entry_date']).days,
                        breadth_at_entry=position['breadth']
                    ))
                    position = None
            
            # Check for entries
            if position is None:
                if row['long_signal']:
                    entry_price = row['close'] * (1 + SLIPPAGE)
                    stop = row['psar']
                    risk_amt = INITIAL_CAPITAL * RISK_PER_TRADE
                    qty = int(risk_amt / abs(entry_price - stop))
                    
                    if qty > 0:
                        position = {
                            'side': 'LONG',
                            'entry_date': row['date'],
                            'entry_price': entry_price,
                            'stop': stop,
                            'qty': qty,
                            'breadth': row['breadth_proxy']
                        }
                        logger.debug(f"  LONG {symbol} @ {entry_price:.2f}, stop {stop:.2f}")
                
                elif row['short_signal']:
                    entry_price = row['close'] * (1 - SLIPPAGE)
                    stop = row['psar']
                    risk_amt = INITIAL_CAPITAL * RISK_PER_TRADE
                    qty = int(risk_amt / abs(entry_price - stop))
                    
                    if qty > 0:
                        position = {
                            'side': 'SHORT',
                            'entry_date': row['date'],
                            'entry_price': entry_price,
                            'stop': stop,
                            'qty': qty,
                            'breadth': row['breadth_proxy']
                        }
                        logger.debug(f"  SHORT {symbol} @ {entry_price:.2f}, stop {stop:.2f}")
        
        return {
            'symbol': symbol,
            'trades': trades,
            'total_trades': len(trades),
            'data_points': len(df)
        }
    
    def analyze_results(self, all_trades: List[Trade]) -> Dict:
        """Analyze backtest results"""
        if not all_trades:
            return {'error': 'No trades'}
        
        total_trades = len(all_trades)
        winners = [t for t in all_trades if t.pnl > 0]
        losers = [t for t in all_trades if t.pnl <= 0]
        
        win_rate = len(winners) / total_trades * 100 if total_trades > 0 else 0
        
        avg_win = np.mean([t.pnl for t in winners]) if winners else 0
        avg_loss = np.mean([t.pnl for t in losers]) if losers else 0
        
        avg_win_pct = np.mean([t.pnl_pct for t in winners]) if winners else 0
        avg_loss_pct = np.mean([t.pnl_pct for t in losers]) if losers else 0
        
        gross_profit = sum([t.pnl for t in winners])
        gross_loss = abs(sum([t.pnl for t in losers]))
        
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0
        
        avg_hold = np.mean([t.days_held for t in all_trades])
        
        # Calculate expectancy
        expectancy = (win_rate/100 * avg_win) + ((1 - win_rate/100) * avg_loss)
        
        return {
            'total_trades': total_trades,
            'winners': len(winners),
            'losers': len(losers),
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'avg_win_pct': avg_win_pct,
            'avg_loss_pct': avg_loss_pct,
            'gross_profit': gross_profit,
            'gross_loss': gross_loss,
            'net_profit': gross_profit - gross_loss,
            'profit_factor': profit_factor,
            'avg_hold_days': avg_hold,
            'expectancy': expectancy,
            'trades_per_year': total_trades / 3,  # Assuming 3 years
        }

def main():
    parser = argparse.ArgumentParser(description='Simple SAR-Renko Backtest')
    parser.add_argument('--symbols', nargs='+', help='Specific symbols')
    parser.add_argument('--sample', type=int, help='Sample N random stocks')
    parser.add_argument('--years', type=int, default=3, help='Years of history')
    
    args = parser.parse_args()
    
    # Initialize
    kite = KiteConnect(api_key=API_KEY)
    kite.set_access_token(ACCESS_TOKEN)
    
    backtester = SimpleBacktester(kite)
    
    # Determine symbols
    if args.symbols:
        symbols = args.symbols
    elif args.sample:
        # Load from stock universe CSV (can be Nifty 50, Nifty 500, etc.)
        df_universe = pd.read_csv('data/Nifty50stocks.csv')
        symbols = df_universe['Symbol'].sample(n=min(args.sample, len(df_universe))).tolist()
    else:
        # Default test symbols
        symbols = ['RELIANCE', 'TCS', 'INFY', 'HDFCBANK', 'ICICIBANK', 
                  'BHARTIARTL', 'SBIN', 'LT', 'KOTAKBANK', 'AXISBANK']
    
    logger.info(f"\n{'='*60}")
    logger.info(f"BACKTESTING {len(symbols)} SYMBOLS")
    logger.info(f"Period: Last {args.years} years")
    logger.info(f"ADX Filter: {'ENABLED' if USE_ADX_FILTER else 'DISABLED'} (min ADX: {MIN_ADX if USE_ADX_FILTER else 'N/A'})")
    logger.info(f"{'='*60}\n")
    
    # Backtest each symbol
    all_trades = []
    symbols_tested = 0
    
    for symbol in symbols:
        result = backtester.backtest_symbol(symbol, args.years)
        
        if result and result['trades']:
            all_trades.extend(result['trades'])
            symbols_tested += 1
            logger.info(f"  {symbol}: {len(result['trades'])} trades")
        
        time.sleep(0.35)  # Rate limiting
    
    # Analyze results
    if all_trades:
        metrics = backtester.analyze_results(all_trades)
        
        print("\n" + "="*60)
        print("BACKTEST RESULTS")
        print("="*60)
        print(f"Symbols Tested: {symbols_tested}")
        print(f"Total Trades: {metrics['total_trades']}")
        print(f"Trades per Symbol: {metrics['total_trades']/symbols_tested:.1f}")
        print(f"Trades per Year: {metrics['trades_per_year']:.1f}")
        print()
        print(f"Win Rate: {metrics['win_rate']:.2f}%")
        print(f"Winners: {metrics['winners']}")
        print(f"Losers: {metrics['losers']}")
        print()
        print(f"Average Win: ₹{metrics['avg_win']:,.0f} ({metrics['avg_win_pct']:+.2f}%)")
        print(f"Average Loss: ₹{metrics['avg_loss']:,.0f} ({metrics['avg_loss_pct']:+.2f}%)")
        print()
        print(f"Gross Profit: ₹{metrics['gross_profit']:,.0f}")
        print(f"Gross Loss: ₹{metrics['gross_loss']:,.0f}")
        print(f"Net Profit: ₹{metrics['net_profit']:,.0f}")
        print()
        print(f"Profit Factor: {metrics['profit_factor']:.2f}")
        print(f"Expectancy: ₹{metrics['expectancy']:,.0f} per trade")
        print(f"Avg Hold Days: {metrics['avg_hold_days']:.1f}")
        print("="*60)
        
        # Save trades to CSV
        df_trades = pd.DataFrame([{
            'symbol': t.symbol,
            'entry_date': t.entry_date,
            'exit_date': t.exit_date,
            'entry_price': t.entry_price,
            'exit_price': t.exit_price,
            'side': t.side,
            'pnl': t.pnl,
            'pnl_pct': t.pnl_pct,
            'exit_reason': t.exit_reason,
            'days_held': t.days_held,
            'breadth': t.breadth_at_entry
        } for t in all_trades])
        
        output_file = f'backtest_results_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        df_trades.to_csv(output_file, index=False)
        logger.info(f"\nTrades saved to: {output_file}")
        
        return metrics
    else:
        logger.warning("No trades found!")
        return None

if __name__ == "__main__":
    main()

