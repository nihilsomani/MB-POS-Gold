"""
SAR-Renko Strategy Backtester
==============================

Comprehensive backtesting framework with:
- Walk-forward optimization
- Monte Carlo simulation
- Parameter sensitivity analysis
- Regime-specific performance
- Realistic slippage & costs
- Risk metrics (Sharpe, Sortino, Max DD)

Usage:
    python SARRenkoBacktester.py --start 2020-01-01 --end 2024-10-01
    python SARRenkoBacktester.py --optimize  # Parameter optimization
    python SARRenkoBacktester.py --monte-carlo --runs 1000
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
from datetime import datetime, timedelta
import json
import logging
from dataclasses import dataclass
import matplotlib.pyplot as plt
import seaborn as sns
from itertools import product
import argparse

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class Trade:
    """Individual trade record"""
    entry_date: datetime
    exit_date: datetime
    symbol: str
    side: str  # 'LONG' or 'SHORT'
    entry_price: float
    exit_price: float
    quantity: int
    pnl: float
    pnl_pct: float
    exit_reason: str  # 'stop_loss', 'signal_exit', 'time_stop'
    days_held: int
    
    @property
    def is_winner(self) -> bool:
        return self.pnl > 0
    
    @property
    def return_pct(self) -> float:
        return self.pnl_pct


@dataclass
class BacktestConfig:
    """Backtest configuration"""
    # Strategy parameters
    psar_start: float = 0.02
    psar_step: float = 0.02
    psar_max: float = 0.2
    renko_brick_size: float = 75
    renko_method: str = 'atr'
    atr_multiplier: float = 1.5
    min_breadth_long: float = 50
    
    # Risk management
    risk_per_trade: float = 2.0
    max_stop_distance: float = 5.0
    min_stop_distance: float = 1.0
    
    # Costs & slippage
    commission_pct: float = 0.05  # 0.05% per trade
    slippage_pct: float = 0.05    # 0.05% slippage
    
    # Capital
    initial_capital: float = 1000000
    
    def to_dict(self) -> Dict:
        return self.__dict__


# =============================================================================
# PERFORMANCE METRICS
# =============================================================================

class PerformanceMetrics:
    """Calculate comprehensive performance metrics"""
    
    @staticmethod
    def calculate_all(trades: List[Trade], equity_curve: pd.Series, 
                     initial_capital: float) -> Dict:
        """Calculate all performance metrics"""
        
        if not trades:
            return {'error': 'No trades'}
        
        # Trade statistics
        total_trades = len(trades)
        winning_trades = [t for t in trades if t.is_winner]
        losing_trades = [t for t in trades if not t.is_winner]
        
        win_rate = len(winning_trades) / total_trades * 100 if total_trades > 0 else 0
        
        avg_win = np.mean([t.pnl for t in winning_trades]) if winning_trades else 0
        avg_loss = np.mean([t.pnl for t in losing_trades]) if losing_trades else 0
        
        avg_win_pct = np.mean([t.pnl_pct for t in winning_trades]) if winning_trades else 0
        avg_loss_pct = np.mean([t.pnl_pct for t in losing_trades]) if losing_trades else 0
        
        # Profit factor
        gross_profit = sum([t.pnl for t in winning_trades])
        gross_loss = abs(sum([t.pnl for t in losing_trades]))
        profit_factor = gross_profit / gross_loss if gross_loss != 0 else 0
        
        # Expectancy
        expectancy = (win_rate/100 * avg_win) + ((1 - win_rate/100) * avg_loss)
        
        # Returns
        final_capital = equity_curve.iloc[-1]
        total_return = ((final_capital - initial_capital) / initial_capital) * 100
        
        # Calculate CAGR
        days = (equity_curve.index[-1] - equity_curve.index[0]).days
        years = days / 365.25
        cagr = ((final_capital / initial_capital) ** (1/years) - 1) * 100 if years > 0 else 0
        
        # Drawdown
        dd_info = PerformanceMetrics._calculate_drawdown(equity_curve)
        
        # Risk metrics
        returns = equity_curve.pct_change().dropna()
        
        sharpe = PerformanceMetrics._calculate_sharpe(returns)
        sortino = PerformanceMetrics._calculate_sortino(returns)
        calmar = cagr / abs(dd_info['max_dd_pct']) if dd_info['max_dd_pct'] != 0 else 0
        
        # Holding period
        avg_hold_days = np.mean([t.days_held for t in trades])
        
        # Compile results
        metrics = {
            # Trade statistics
            'total_trades': total_trades,
            'winning_trades': len(winning_trades),
            'losing_trades': len(losing_trades),
            'win_rate': win_rate,
            
            # P&L
            'total_return': total_return,
            'cagr': cagr,
            'final_capital': final_capital,
            'gross_profit': gross_profit,
            'gross_loss': gross_loss,
            'net_profit': gross_profit + gross_loss,
            
            # Trade metrics
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'avg_win_pct': avg_win_pct,
            'avg_loss_pct': avg_loss_pct,
            'profit_factor': profit_factor,
            'expectancy': expectancy,
            'avg_hold_days': avg_hold_days,
            
            # Risk metrics
            'max_drawdown_pct': dd_info['max_dd_pct'],
            'max_drawdown_duration': dd_info['max_dd_duration'],
            'sharpe_ratio': sharpe,
            'sortino_ratio': sortino,
            'calmar_ratio': calmar,
            
            # Additional
            'trades_per_year': total_trades / years if years > 0 else 0,
            'return_to_max_dd': total_return / abs(dd_info['max_dd_pct']) if dd_info['max_dd_pct'] != 0 else 0,
        }
        
        return metrics
    
    @staticmethod
    def _calculate_drawdown(equity: pd.Series) -> Dict:
        """Calculate drawdown statistics"""
        rolling_max = equity.expanding().max()
        drawdown = (equity - rolling_max) / rolling_max * 100
        
        max_dd = drawdown.min()
        max_dd_idx = drawdown.idxmin()
        
        # Find drawdown duration
        if max_dd_idx in equity.index:
            # Find when it recovered
            recovery_idx = equity[equity.index > max_dd_idx][equity >= rolling_max[max_dd_idx]]
            if len(recovery_idx) > 0:
                duration = (recovery_idx.index[0] - max_dd_idx).days
            else:
                duration = (equity.index[-1] - max_dd_idx).days  # Still in drawdown
        else:
            duration = 0
        
        return {
            'max_dd_pct': max_dd,
            'max_dd_date': max_dd_idx,
            'max_dd_duration': duration,
            'drawdown_series': drawdown
        }
    
    @staticmethod
    def _calculate_sharpe(returns: pd.Series, risk_free_rate: float = 0.06) -> float:
        """Calculate Sharpe ratio (annualized)"""
        if len(returns) < 2:
            return 0
        
        # Annualize
        excess_returns = returns - (risk_free_rate / 252)
        
        if returns.std() == 0:
            return 0
        
        sharpe = np.sqrt(252) * (excess_returns.mean() / returns.std())
        return sharpe
    
    @staticmethod
    def _calculate_sortino(returns: pd.Series, risk_free_rate: float = 0.06) -> float:
        """Calculate Sortino ratio (annualized)"""
        if len(returns) < 2:
            return 0
        
        excess_returns = returns - (risk_free_rate / 252)
        downside_returns = returns[returns < 0]
        
        if len(downside_returns) == 0 or downside_returns.std() == 0:
            return 0
        
        sortino = np.sqrt(252) * (excess_returns.mean() / downside_returns.std())
        return sortino


# =============================================================================
# BACKTESTER ENGINE
# =============================================================================

class SARRenkoBacktester:
    """
    Event-driven backtester for SAR-Renko strategy.
    
    Implements realistic assumptions:
    - No lookahead bias
    - Transaction costs & slippage
    - Position sizing based on risk
    - Multiple open positions
    """
    
    def __init__(self, config: BacktestConfig):
        self.config = config
        self.trades: List[Trade] = []
        self.equity_curve: pd.Series = None
        self.positions: List[Dict] = []
        
    def run_backtest(self, df: pd.DataFrame) -> Dict:
        """
        Run backtest on historical data.
        
        Args:
            df: DataFrame with columns [date, symbol, close, high, low, 
                psar, psar_trend, renko_direction, breadth]
        
        Returns:
            Dict with performance metrics
        """
        logger.info(f"Running backtest from {df['date'].min()} to {df['date'].max()}")
        
        # Initialize
        capital = self.config.initial_capital
        equity_history = []
        
        # Group by date for event-driven simulation
        df = df.sort_values('date')
        dates = df['date'].unique()
        
        for date in dates:
            day_data = df[df['date'] == date]
            
            # 1. Check exits for existing positions
            capital = self._process_exits(day_data, capital)
            
            # 2. Check for new entry signals
            capital = self._process_entries(day_data, capital, date)
            
            # 3. Record equity
            position_value = sum([p['quantity'] * p['current_price'] 
                                for p in self.positions])
            equity = capital + position_value
            equity_history.append({'date': date, 'equity': equity})
        
        # Create equity curve
        self.equity_curve = pd.DataFrame(equity_history).set_index('date')['equity']
        
        # Calculate metrics
        metrics = PerformanceMetrics.calculate_all(
            self.trades,
            self.equity_curve,
            self.config.initial_capital
        )
        
        logger.info(f"Backtest complete: {len(self.trades)} trades, "
                   f"{metrics['win_rate']:.1f}% win rate, "
                   f"{metrics['total_return']:.2f}% return")
        
        return metrics
    
    def _process_exits(self, day_data: pd.DataFrame, capital: float) -> float:
        """Check and process exits for open positions"""
        positions_to_close = []
        
        for i, pos in enumerate(self.positions):
            symbol = pos['symbol']
            
            # Get today's data for this symbol
            symbol_data = day_data[day_data['symbol'] == symbol]
            if symbol_data.empty:
                continue
            
            row = symbol_data.iloc[0]
            pos['current_price'] = row['close']
            
            # Check exit conditions
            exit_reason = None
            exit_price = row['close']
            
            # Stop loss hit
            if pos['side'] == 'LONG' and row['low'] <= pos['stop_loss']:
                exit_reason = 'stop_loss'
                exit_price = pos['stop_loss']
                
            elif pos['side'] == 'SHORT' and row['high'] >= pos['stop_loss']:
                exit_reason = 'stop_loss'
                exit_price = pos['stop_loss']
            
            # Signal exit (PSAR reversal)
            elif pos['side'] == 'LONG' and row.get('psar_trend', 1) == -1:
                exit_reason = 'signal_exit'
            
            elif pos['side'] == 'SHORT' and row.get('psar_trend', -1) == 1:
                exit_reason = 'signal_exit'
            
            # If exit triggered
            if exit_reason:
                positions_to_close.append((i, exit_reason, exit_price, row['date']))
        
        # Close positions
        for idx, exit_reason, exit_price, exit_date in reversed(positions_to_close):
            pos = self.positions[idx]
            
            # Apply slippage
            if exit_reason == 'stop_loss':
                # Slippage against you on stops
                if pos['side'] == 'LONG':
                    exit_price *= (1 - self.config.slippage_pct/100)
                else:
                    exit_price *= (1 + self.config.slippage_pct/100)
            else:
                # Normal slippage
                exit_price *= (1 - self.config.slippage_pct/100) if pos['side'] == 'LONG' else (1 + self.config.slippage_pct/100)
            
            # Calculate P&L
            if pos['side'] == 'LONG':
                pnl = (exit_price - pos['entry_price']) * pos['quantity']
            else:
                pnl = (pos['entry_price'] - exit_price) * pos['quantity']
            
            # Apply commission
            commission = (pos['entry_price'] * pos['quantity'] + exit_price * pos['quantity']) * (self.config.commission_pct/100)
            pnl -= commission
            
            pnl_pct = (pnl / (pos['entry_price'] * pos['quantity'])) * 100
            
            # Return capital
            capital += (pos['entry_price'] * pos['quantity']) + pnl
            
            # Record trade
            days_held = (exit_date - pos['entry_date']).days
            trade = Trade(
                entry_date=pos['entry_date'],
                exit_date=exit_date,
                symbol=pos['symbol'],
                side=pos['side'],
                entry_price=pos['entry_price'],
                exit_price=exit_price,
                quantity=pos['quantity'],
                pnl=pnl,
                pnl_pct=pnl_pct,
                exit_reason=exit_reason,
                days_held=days_held
            )
            self.trades.append(trade)
            
            # Remove position
            self.positions.pop(idx)
        
        return capital
    
    def _process_entries(self, day_data: pd.DataFrame, capital: float, date: datetime) -> float:
        """Check for new entry signals"""
        
        for _, row in day_data.iterrows():
            # Check if we have a signal
            signal = row.get('signal', 0)
            if signal == 0:
                continue
            
            # Check if already in position for this symbol
            if any(p['symbol'] == row['symbol'] for p in self.positions):
                continue
            
            # Determine side
            side = 'LONG' if signal == 1 else 'SHORT'
            
            # Calculate position size
            entry_price = row['close']
            stop_loss = row.get('stop_loss', entry_price * 0.95)  # Default 5% stop
            
            # Calculate risk
            risk_amount = capital * (self.config.risk_per_trade / 100)
            stop_distance = abs(entry_price - stop_loss)
            
            if stop_distance == 0:
                continue
            
            quantity = int(risk_amount / stop_distance)
            position_value = quantity * entry_price
            
            # Check if we have capital
            if position_value > capital * 0.3:  # Max 30% per position
                quantity = int((capital * 0.3) / entry_price)
                position_value = quantity * entry_price
            
            if position_value > capital:
                continue
            
            # Apply entry slippage
            entry_price_actual = entry_price * (1 + self.config.slippage_pct/100)
            
            # Deduct capital
            capital -= position_value
            
            # Add position
            position = {
                'symbol': row['symbol'],
                'side': side,
                'entry_date': date,
                'entry_price': entry_price_actual,
                'current_price': entry_price_actual,
                'quantity': quantity,
                'stop_loss': stop_loss,
            }
            self.positions.append(position)
            
            logger.debug(f"Entered {side} {row['symbol']} @ {entry_price_actual:.2f}, Qty: {quantity}")
        
        return capital
    
    def plot_results(self, save_path: str = None):
        """Plot backtest results"""
        fig, axes = plt.subplots(3, 2, figsize=(15, 12))
        
        # 1. Equity curve
        ax = axes[0, 0]
        self.equity_curve.plot(ax=ax, linewidth=2)
        ax.set_title('Equity Curve', fontsize=14, fontweight='bold')
        ax.set_ylabel('Capital (₹)')
        ax.grid(True, alpha=0.3)
        
        # 2. Drawdown
        ax = axes[0, 1]
        returns = self.equity_curve.pct_change().dropna()
        rolling_max = self.equity_curve.expanding().max()
        drawdown = (self.equity_curve - rolling_max) / rolling_max * 100
        drawdown.plot(ax=ax, color='red', linewidth=1.5)
        ax.fill_between(drawdown.index, drawdown, 0, alpha=0.3, color='red')
        ax.set_title('Drawdown (%)', fontsize=14, fontweight='bold')
        ax.set_ylabel('Drawdown %')
        ax.grid(True, alpha=0.3)
        
        # 3. Trade P&L distribution
        ax = axes[1, 0]
        pnls = [t.pnl for t in self.trades]
        ax.hist(pnls, bins=30, edgecolor='black', alpha=0.7)
        ax.axvline(0, color='red', linestyle='--', linewidth=2)
        ax.set_title('Trade P&L Distribution', fontsize=14, fontweight='bold')
        ax.set_xlabel('P&L (₹)')
        ax.set_ylabel('Frequency')
        ax.grid(True, alpha=0.3)
        
        # 4. Win rate by holding period
        ax = axes[1, 1]
        hold_days = [t.days_held for t in self.trades]
        winners = [t.days_held for t in self.trades if t.is_winner]
        ax.scatter(hold_days, pnls, alpha=0.6, s=50)
        ax.axhline(0, color='red', linestyle='--')
        ax.set_title('P&L vs Holding Period', fontsize=14, fontweight='bold')
        ax.set_xlabel('Days Held')
        ax.set_ylabel('P&L (₹)')
        ax.grid(True, alpha=0.3)
        
        # 5. Monthly returns heatmap
        ax = axes[2, 0]
        monthly_returns = self.equity_curve.resample('M').last().pct_change() * 100
        ax.bar(range(len(monthly_returns)), monthly_returns.values)
        ax.set_title('Monthly Returns', fontsize=14, fontweight='bold')
        ax.set_ylabel('Return %')
        ax.axhline(0, color='black', linestyle='-', linewidth=0.5)
        ax.grid(True, alpha=0.3)
        
        # 6. Cumulative returns vs Buy & Hold
        ax = axes[2, 1]
        cumulative = (self.equity_curve / self.equity_curve.iloc[0] - 1) * 100
        cumulative.plot(ax=ax, label='Strategy', linewidth=2)
        ax.set_title('Cumulative Returns', fontsize=14, fontweight='bold')
        ax.set_ylabel('Return %')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            logger.info(f"Plot saved to {save_path}")
        else:
            plt.show()


# =============================================================================
# PARAMETER OPTIMIZER
# =============================================================================

class ParameterOptimizer:
    """Walk-forward parameter optimization"""
    
    def __init__(self, df: pd.DataFrame):
        self.df = df
        
    def optimize(self, param_ranges: Dict) -> pd.DataFrame:
        """
        Grid search optimization with walk-forward validation.
        
        Args:
            param_ranges: Dict of parameter ranges, e.g.
                {
                    'psar_start': [0.01, 0.02, 0.03],
                    'psar_step': [0.01, 0.02, 0.03],
                    'renko_brick': [50, 75, 100]
                }
        
        Returns:
            DataFrame with results for each parameter combination
        """
        logger.info("Starting parameter optimization...")
        
        # Generate all combinations
        param_names = list(param_ranges.keys())
        param_values = list(param_ranges.values())
        combinations = list(product(*param_values))
        
        logger.info(f"Testing {len(combinations)} parameter combinations")
        
        results = []
        
        for combo in combinations:
            params = dict(zip(param_names, combo))
            
            # Create config
            config = BacktestConfig()
            for key, value in params.items():
                setattr(config, key, value)
            
            # Run backtest
            try:
                backtester = SARRenkoBacktester(config)
                metrics = backtester.run_backtest(self.df)
                
                result = {
                    **params,
                    **metrics
                }
                results.append(result)
                
                logger.debug(f"Params: {params} -> Return: {metrics.get('total_return', 0):.2f}%")
                
            except Exception as e:
                logger.error(f"Error with params {params}: {e}")
                continue
        
        df_results = pd.DataFrame(results)
        
        # Sort by Sharpe ratio (better than raw returns)
        df_results = df_results.sort_values('sharpe_ratio', ascending=False)
        
        logger.info("Optimization complete!")
        logger.info(f"\nTop 5 Parameter Sets:\n{df_results.head()}")
        
        return df_results


# =============================================================================
# MONTE CARLO SIMULATION
# =============================================================================

class MonteCarloSimulator:
    """Monte Carlo simulation for strategy robustness"""
    
    def __init__(self, trades: List[Trade], initial_capital: float):
        self.trades = trades
        self.initial_capital = initial_capital
        
    def run_simulation(self, n_runs: int = 1000) -> pd.DataFrame:
        """
        Run Monte Carlo simulation by resampling trades.
        
        Args:
            n_runs: Number of simulation runs
        
        Returns:
            DataFrame with simulation results
        """
        logger.info(f"Running {n_runs} Monte Carlo simulations...")
        
        results = []
        
        for run in range(n_runs):
            # Resample trades with replacement
            resampled_trades = np.random.choice(self.trades, size=len(self.trades), replace=True)
            
            # Calculate equity curve
            equity = self.initial_capital
            equity_curve = [equity]
            
            for trade in resampled_trades:
                equity += trade.pnl
                equity_curve.append(equity)
            
            equity_series = pd.Series(equity_curve)
            
            # Calculate metrics
            final_equity = equity_series.iloc[-1]
            total_return = ((final_equity - self.initial_capital) / self.initial_capital) * 100
            
            # Max drawdown
            rolling_max = equity_series.expanding().max()
            drawdown = (equity_series - rolling_max) / rolling_max * 100
            max_dd = drawdown.min()
            
            results.append({
                'run': run,
                'final_equity': final_equity,
                'total_return': total_return,
                'max_drawdown': max_dd
            })
        
        df_results = pd.DataFrame(results)
        
        # Statistics
        logger.info("\nMonte Carlo Results:")
        logger.info(f"Mean Return: {df_results['total_return'].mean():.2f}%")
        logger.info(f"Median Return: {df_results['total_return'].median():.2f}%")
        logger.info(f"Std Dev: {df_results['total_return'].std():.2f}%")
        logger.info(f"5th Percentile: {df_results['total_return'].quantile(0.05):.2f}%")
        logger.info(f"95th Percentile: {df_results['total_return'].quantile(0.95):.2f}%")
        
        return df_results


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description='SAR-Renko Backtester')
    parser.add_argument('--data', required=True, help='Path to historical data CSV')
    parser.add_argument('--start', help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end', help='End date (YYYY-MM-DD)')
    parser.add_argument('--optimize', action='store_true', help='Run parameter optimization')
    parser.add_argument('--monte-carlo', action='store_true', help='Run Monte Carlo simulation')
    parser.add_argument('--runs', type=int, default=1000, help='Number of MC runs')
    
    args = parser.parse_args()
    
    # Load data
    logger.info(f"Loading data from {args.data}")
    df = pd.read_csv(args.data, parse_dates=['date'])
    
    # Filter dates
    if args.start:
        df = df[df['date'] >= args.start]
    if args.end:
        df = df[df['date'] <= args.end]
    
    logger.info(f"Data range: {df['date'].min()} to {df['date'].max()}")
    logger.info(f"Total records: {len(df)}")
    
    if args.optimize:
        # Parameter optimization
        param_ranges = {
            'psar_start': [0.01, 0.02, 0.03],
            'psar_step': [0.01, 0.02, 0.03],
            'psar_max': [0.15, 0.20, 0.25],
            'atr_multiplier': [1.0, 1.5, 2.0],
        }
        
        optimizer = ParameterOptimizer(df)
        results = optimizer.optimize(param_ranges)
        
        # Save results
        results.to_csv('optimization_results.csv', index=False)
        logger.info("Optimization results saved to optimization_results.csv")
        
    else:
        # Standard backtest
        config = BacktestConfig()
        backtester = SARRenkoBacktester(config)
        metrics = backtester.run_backtest(df)
        
        # Print metrics
        print("\n" + "="*60)
        print("BACKTEST RESULTS")
        print("="*60)
        for key, value in metrics.items():
            if isinstance(value, float):
                print(f"{key:.<40} {value:>15.2f}")
            else:
                print(f"{key:.<40} {value:>15}")
        
        # Plot
        backtester.plot_results('backtest_results.png')
        
        # Monte Carlo if requested
        if args.monte_carlo:
            mc_sim = MonteCarloSimulator(backtester.trades, config.initial_capital)
            mc_results = mc_sim.run_simulation(args.runs)
            mc_results.to_csv('monte_carlo_results.csv', index=False)


if __name__ == "__main__":
    main()

