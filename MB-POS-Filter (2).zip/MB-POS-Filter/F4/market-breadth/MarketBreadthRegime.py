"""
Market Breadth Regime Scanner
==============================

Comprehensive multi-dimensional market regime analyzer.

Key Features:
1. Simple breadth (% stocks above MA across 10/20/50/100/200-day timeframes)
2. Market cap-weighted breadth (institutional money flow perspective)
3. Sector-normalized breadth (anti-concentration bias for balanced view)
4. Multi-timeframe regime detection (identifies trend alignment)
5. Volume-weighted breadth (money flow confirmation)
6. **Health Score (0-100)** - Composite market strength indicator
7. **Regime Classification** - STRONG_BULL, BULL, NEUTRAL, BEAR, STRONG_BEAR

Output:
- JSON: Latest breadth metrics for programmatic access
- CSV: Historical tracking for trend analysis
- Cache: Daily snapshots for quick reference

Usage:
    python MarketBreadthRegime.py
    python MarketBreadthRegime.py --sample 10  # Test on 10 stocks

Best For: Weekly regime assessment, long-term positioning, portfolio heat decisions

Author: Market Analysis Framework
Version: 1.0.0
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import json
import logging
import argparse
import time
from typing import Dict, List, Tuple, Optional
from ratelimit import limits, sleep_and_retry
import os

# =============================================================================
# CONFIGURATION
# =============================================================================

# API Configuration (same as your other scanners)
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "IPu3YFNqPkAlRsmQ6R7whtIhJSJsLsKf"

# Data Configuration
INPUT_CSV = "../../../data/Nifty50stocks.csv"  # Stock universe (can be Nifty 50, Nifty 500, etc.)
OUTPUT_JSON = "output/regime_breadth.json"
OUTPUT_CSV = "output/regime_breadth_history.csv"
CACHE_DIR = "cache"

# Scanner Configuration
LOOKBACK_DAYS = 365  # Request ~365 calendar days to get 200+ trading days
API_CALL_DELAY = 0.35  # Rate limiting
MA_PERIODS = [10, 20, 50, 100, 200]  # Multiple timeframes

# Logging
LOG_FILE = "regime_breadth.log"
LOG_LEVEL = logging.INFO

# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level=LOG_LEVEL,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOG_FILE),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# =============================================================================
# MARKET BREADTH CALCULATOR
# =============================================================================

class MarketBreadthCalculator:
    """
    Comprehensive market breadth analysis using multiple methodologies
    """
    
    def __init__(self, kite: KiteConnect):
        self.kite = kite
        self.instrument_map = self._load_instruments()
        
    def _load_instruments(self) -> Dict[str, int]:
        """Load instrument tokens"""
        logger.info("Loading NSE instruments...")
        try:
            instruments = self.kite.instruments("NSE")
            instrument_map = {}
            
            for inst in instruments:
                if inst['exchange'] == 'NSE' and inst['instrument_type'] == 'EQ':
                    instrument_map[inst['tradingsymbol']] = inst['instrument_token']
            
            logger.info(f"Loaded {len(instrument_map)} instruments")
            return instrument_map
            
        except Exception as e:
            logger.error(f"Failed to load instruments: {e}")
            return {}
    
    @sleep_and_retry
    @limits(calls=3, period=1)
    def _fetch_data(self, symbol: str, days: int) -> Optional[pd.DataFrame]:
        """Fetch historical data with rate limiting"""
        try:
            if symbol not in self.instrument_map:
                return None
            
            instrument_token = self.instrument_map[symbol]
            to_date = datetime.now()
            from_date = to_date - timedelta(days=days)
            
            data = self.kite.historical_data(
                instrument_token,
                from_date.strftime('%Y-%m-%d'),
                to_date.strftime('%Y-%m-%d'),
                'day'
            )
            
            df = pd.DataFrame(data)
            return df
            
        except Exception as e:
            logger.debug(f"Failed to fetch {symbol}: {e}")
            return None
    
    def calculate_comprehensive_breadth(self, universe_df: pd.DataFrame, 
                                       sample_size: Optional[int] = None) -> Dict:
        """
        Calculate all breadth metrics
        
        Args:
            universe_df: DataFrame with Symbol column (market_cap_crores and Sector optional)
            sample_size: Optional limit for testing (None = use all)
            
        Returns:
            Dict with all breadth metrics
        """
        logger.info("="*60)
        logger.info("STARTING MARKET BREADTH CALCULATION")
        logger.info("="*60)
        
        # Sample if requested
        if sample_size:
            universe_df = universe_df.sample(n=min(sample_size, len(universe_df)))
            logger.info(f"Sampling {len(universe_df)} stocks for testing")
        
        # Fetch data for all stocks
        stocks_data = []
        total = len(universe_df)
        failed_no_data = 0
        failed_insufficient = 0
        failed_error = 0
        
        logger.info(f"Fetching data for {total} stocks...")
        
        for idx, row in universe_df.iterrows():
            symbol = row['Symbol']
            
            if (idx + 1) % 50 == 0:
                logger.info(f"Progress: {idx+1}/{total} ({(idx+1)/total*100:.1f}%)")
            
            # Fetch historical data
            df = self._fetch_data(symbol, LOOKBACK_DAYS)
            
            if df is None:
                failed_no_data += 1
                logger.debug(f"{symbol}: No data returned from API")
                continue
            
            if len(df) < max(MA_PERIODS):
                failed_insufficient += 1
                logger.debug(f"{symbol}: Insufficient data ({len(df)} bars, need {max(MA_PERIODS)})")
                continue
            
            try:
                # Calculate MAs for multiple timeframes
                ma_values = {}
                for period in MA_PERIODS:
                    ma_values[f'ma_{period}'] = df['close'].rolling(window=period).mean().iloc[-1]
                
                # Get latest values
                latest = df.iloc[-1]
                prev = df.iloc[-2] if len(df) > 1 else latest
                
                # Calculate ATR for volatility
                high = df['high']
                low = df['low']
                close = df['close']
                
                tr1 = high - low
                tr2 = abs(high - close.shift(1))
                tr3 = abs(low - close.shift(1))
                tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
                atr = tr.rolling(window=14).mean().iloc[-1]
                
                # Build stock data
                stock_info = {
                    'symbol': symbol,
                    'sector': row.get('Sector', 'Unknown'),
                    'market_cap': row.get('market_cap_crores', 1.0),  # Default to 1.0 if not present (equal weight)
                    'close': latest['close'],
                    'prev_close': prev['close'],
                    'volume': latest['volume'],
                    'atr': atr,
                    **ma_values  # Add all MA values
                }
                
                stocks_data.append(stock_info)
                
            except Exception as e:
                failed_error += 1
                logger.warning(f"{symbol}: Error processing data - {e}")
                continue
            
            time.sleep(API_CALL_DELAY)
        
        logger.info(f"Successfully fetched data for {len(stocks_data)} stocks")
        logger.info(f"Failed - No data: {failed_no_data}")
        logger.info(f"Failed - Insufficient bars: {failed_insufficient}")
        logger.info(f"Failed - Processing error: {failed_error}")
        
        if len(stocks_data) == 0:
            logger.error("No data fetched! Cannot calculate breadth.")
            logger.error("Check: Are symbols in CSV matching NSE symbols?")
            logger.error("Try: python MarketBreadthScanner.py --sample 5  # Test with 5 stocks")
            return None
        
        # Calculate all breadth metrics
        total_mcap = sum(s['market_cap'] for s in stocks_data)
        has_mcap = any(s['market_cap'] != 1.0 for s in stocks_data)
        
        results = {
            'timestamp': datetime.now().isoformat(),
            'date': datetime.now().strftime('%Y-%m-%d'),
            'stocks_analyzed': len(stocks_data),
            'total_market_cap': total_mcap if has_mcap else None,
        }
        
        # 1. Simple Breadth (multiple timeframes)
        logger.info("\n" + "="*60)
        logger.info("1. SIMPLE BREADTH (% stocks above MA)")
        logger.info("="*60)
        
        for period in MA_PERIODS:
            above_ma = sum(1 for s in stocks_data if s['close'] > s[f'ma_{period}'])
            pct = (above_ma / len(stocks_data)) * 100
            results[f'simple_breadth_{period}d'] = round(pct, 2)
            logger.info(f"  {period}-day MA: {pct:.2f}% ({above_ma}/{len(stocks_data)} stocks)")
        
        # 2. Market Cap Weighted Breadth (uses equal weight if market_cap not provided)
        logger.info("\n" + "="*60)
        logger.info("2. MARKET CAP WEIGHTED BREADTH")
        has_mcap = any(s['market_cap'] != 1.0 for s in stocks_data)
        if not has_mcap:
            logger.info("  (Using equal weighting - no market cap data provided)")
        logger.info("="*60)
        
        for period in MA_PERIODS:
            bullish_mcap = sum(s['market_cap'] for s in stocks_data if s['close'] > s[f'ma_{period}'])
            total_mcap = sum(s['market_cap'] for s in stocks_data)
            pct = (bullish_mcap / total_mcap) * 100 if total_mcap > 0 else 50
            results[f'weighted_breadth_{period}d'] = round(pct, 2)
            if has_mcap:
                logger.info(f"  {period}-day MA: {pct:.2f}% (₹{bullish_mcap/1000:.0f}k cr bullish)")
            else:
                logger.info(f"  {period}-day MA: {pct:.2f}%")
        
        # 3. Breadth Momentum Score (distance from MA)
        logger.info("\n" + "="*60)
        logger.info("3. BREADTH MOMENTUM (avg distance from MA)")
        logger.info("="*60)
        
        for period in [50, 200]:  # Only key timeframes
            distances = []
            for s in stocks_data:
                dist = ((s['close'] - s[f'ma_{period}']) / s[f'ma_{period}']) * 100
                dist = max(-20, min(20, dist))  # Cap at ±20%
                distances.append(dist)
            
            avg_dist = np.mean(distances)
            momentum_score = 50 + (avg_dist * 2.5)  # Scale to 0-100
            results[f'momentum_score_{period}d'] = round(momentum_score, 2)
            logger.info(f"  {period}-day MA: {momentum_score:.2f} (avg dist: {avg_dist:+.2f}%)")
        
        # 4. Sector-Normalized Breadth
        logger.info("\n" + "="*60)
        logger.info("4. SECTOR-NORMALIZED BREADTH")
        logger.info("="*60)
        
        period = 50  # Use 50-day for sector analysis
        sectors = {}
        for s in stocks_data:
            sector = s['sector']
            if sector not in sectors:
                sectors[sector] = {'above': 0, 'total': 0}
            
            sectors[sector]['total'] += 1
            if s['close'] > s[f'ma_{period}']:
                sectors[sector]['above'] += 1
        
        sector_breadths = []
        sectors_bullish = 0
        
        for sector, data in sectors.items():
            sector_breadth = (data['above'] / data['total']) * 100
            sector_breadths.append(sector_breadth)
            
            if sector_breadth > 60:
                sectors_bullish += 1
            
            logger.info(f"  {sector:30s}: {sector_breadth:5.1f}% ({data['above']}/{data['total']})")
        
        normalized_breadth = np.mean(sector_breadths)
        results['sector_normalized_breadth'] = round(normalized_breadth, 2)
        results['sectors_bullish'] = sectors_bullish
        results['total_sectors'] = len(sectors)
        
        logger.info(f"\n  Average: {normalized_breadth:.2f}%")
        logger.info(f"  Sectors in uptrend: {sectors_bullish}/{len(sectors)}")
        
        # 5. Volume-Weighted Breadth
        logger.info("\n" + "="*60)
        logger.info("5. VOLUME-WEIGHTED BREADTH")
        logger.info("="*60)
        
        period = 50
        bullish_volume = sum(s['volume'] for s in stocks_data if s['close'] > s[f'ma_{period}'])
        total_volume = sum(s['volume'] for s in stocks_data)
        volume_weighted = (bullish_volume / total_volume) * 100 if total_volume > 0 else 50
        results['volume_weighted_breadth'] = round(volume_weighted, 2)
        logger.info(f"  50-day MA: {volume_weighted:.2f}%")
        
        # 6. Advance/Decline Ratio
        logger.info("\n" + "="*60)
        logger.info("6. ADVANCE/DECLINE METRICS")
        logger.info("="*60)
        
        advances = sum(1 for s in stocks_data if s['close'] > s['prev_close'])
        declines = sum(1 for s in stocks_data if s['close'] < s['prev_close'])
        unchanged = len(stocks_data) - advances - declines
        
        ad_ratio = advances / declines if declines > 0 else 999
        ad_pct = (advances / len(stocks_data)) * 100
        
        results['advances'] = advances
        results['declines'] = declines
        results['unchanged'] = unchanged
        results['advance_decline_ratio'] = round(ad_ratio, 2)
        results['advance_pct'] = round(ad_pct, 2)
        
        logger.info(f"  Advances: {advances}")
        logger.info(f"  Declines: {declines}")
        logger.info(f"  Unchanged: {unchanged}")
        logger.info(f"  A/D Ratio: {ad_ratio:.2f}")
        logger.info(f"  Advance %: {ad_pct:.1f}%")
        
        # 7. Composite Market Health Score
        logger.info("\n" + "="*60)
        logger.info("7. COMPOSITE MARKET HEALTH SCORE")
        logger.info("="*60)
        
        # Weighted composite (0-100 scale)
        health_score = (
            results['simple_breadth_50d'] * 0.25 +
            results['weighted_breadth_50d'] * 0.30 +
            results['momentum_score_50d'] * 0.20 +
            results['sector_normalized_breadth'] * 0.15 +
            results['volume_weighted_breadth'] * 0.10
        )
        
        # Regime classification
        if health_score > 70:
            regime = "STRONG_BULL"
            trade_recommendation = "AGGRESSIVE_LONG"
        elif health_score > 60:
            regime = "BULL"
            trade_recommendation = "LONG"
        elif health_score > 55:
            regime = "WEAK_BULL"
            trade_recommendation = "SELECTIVE_LONG"
        elif health_score > 45:
            regime = "NEUTRAL"
            trade_recommendation = "WAIT"
        elif health_score > 40:
            regime = "WEAK_BEAR"
            trade_recommendation = "SELECTIVE_SHORT"
        elif health_score > 30:
            regime = "BEAR"
            trade_recommendation = "SHORT"
        else:
            regime = "STRONG_BEAR"
            trade_recommendation = "AGGRESSIVE_SHORT"
        
        results['health_score'] = round(health_score, 2)
        results['regime'] = regime
        results['trade_recommendation'] = trade_recommendation
        
        logger.info(f"  Health Score: {health_score:.2f}/100")
        logger.info(f"  Regime: {regime}")
        logger.info(f"  Recommendation: {trade_recommendation}")
        
        # 8. Multi-Timeframe Regime Analysis
        logger.info("\n" + "="*60)
        logger.info("8. MULTI-TIMEFRAME REGIME ANALYSIS")
        logger.info("="*60)
        
        # Short-term (10-day)
        short_term = "BULLISH" if results['weighted_breadth_10d'] > 55 else "BEARISH"
        # Medium-term (50-day)
        medium_term = "BULLISH" if results['weighted_breadth_50d'] > 55 else "BEARISH"
        # Long-term (200-day)
        long_term = "BULLISH" if results['weighted_breadth_200d'] > 50 else "BEARISH"
        
        # Trend alignment
        if short_term == medium_term == long_term == "BULLISH":
            alignment = "FULLY_ALIGNED_BULLISH"
            confidence = 95
        elif short_term == medium_term == long_term == "BEARISH":
            alignment = "FULLY_ALIGNED_BEARISH"
            confidence = 95
        elif short_term == medium_term:
            alignment = "SHORT_MEDIUM_ALIGNED"
            confidence = 75
        elif medium_term == long_term:
            alignment = "MEDIUM_LONG_ALIGNED"
            confidence = 75
        else:
            alignment = "DIVERGENT"
            confidence = 40
        
        results['timeframe_alignment'] = alignment
        results['trend_confidence'] = confidence
        
        logger.info(f"  Short-term (10d):  {short_term}")
        logger.info(f"  Medium-term (50d): {medium_term}")
        logger.info(f"  Long-term (200d):  {long_term}")
        logger.info(f"  Alignment: {alignment}")
        logger.info(f"  Confidence: {confidence}%")
        
        return results
    
    def save_results(self, results: Dict):
        """Save results to JSON and CSV"""
        if results is None:
            logger.error("No results to save")
            return
        
        # Ensure output directories exist
        os.makedirs('output', exist_ok=True)
        os.makedirs('cache/breadth', exist_ok=True)
        
        # Save JSON (for programmatic access)
        with open(OUTPUT_JSON, 'w') as f:
            json.dump(results, f, indent=2)
        logger.info(f"\nSaved results to: {OUTPUT_JSON}")
        
        # Save CSV (for Excel/spreadsheet tracking)
        df = pd.DataFrame([results])
        
        # Append to historical log if exists
        history_file = OUTPUT_CSV
        if os.path.exists(history_file):
            df_history = pd.read_csv(history_file)
            df = pd.concat([df_history, df], ignore_index=True)
        
        df.to_csv(history_file, index=False)
        logger.info(f"Saved to history: {history_file}")
        
        # Also save to cache for quick access
        cache_file = f'cache/regime_{datetime.now().strftime("%Y%m%d")}.json'
        with open(cache_file, 'w') as f:
            json.dump(results, f, indent=2)
        logger.info(f"Cached to: {cache_file}")
    
    def print_summary(self, results: Dict):
        """Print executive summary"""
        if results is None:
            return
        
        print("\n" + "="*60)
        print("MARKET BREADTH SUMMARY")
        print("="*60)
        print(f"Date: {results['date']}")
        print(f"Stocks Analyzed: {results['stocks_analyzed']}")
        if results['total_market_cap']:
            print(f"Total Market Cap: ₹{results['total_market_cap']/1000:.0f}k crores")
        print()
        print(f"🎯 MARKET HEALTH SCORE: {results['health_score']:.1f}/100")
        print(f"📊 REGIME: {results['regime']}")
        print(f"💡 RECOMMENDATION: {results['trade_recommendation']}")
        print()
        print("KEY METRICS:")
        print(f"  Simple Breadth (50d):    {results['simple_breadth_50d']:.1f}%")
        print(f"  Weighted Breadth (50d):  {results['weighted_breadth_50d']:.1f}%")
        print(f"  Momentum Score:          {results['momentum_score_50d']:.1f}")
        print(f"  Sector Normalized:       {results['sector_normalized_breadth']:.1f}%")
        print(f"  Advance/Decline:         {results['advance_pct']:.1f}%")
        print()
        print("TIMEFRAME ANALYSIS:")
        print(f"  Short-term (10d):  {results['weighted_breadth_10d']:.1f}%")
        print(f"  Medium-term (50d): {results['weighted_breadth_50d']:.1f}%")
        print(f"  Long-term (200d):  {results['weighted_breadth_200d']:.1f}%")
        print(f"  Alignment: {results['timeframe_alignment']}")
        print(f"  Confidence: {results['trend_confidence']}%")
        print("="*60)


# =============================================================================
# MAIN
# =============================================================================

def main():
    parser = argparse.ArgumentParser(description='Market Breadth Regime Scanner')
    parser.add_argument('--sample', type=int, help='Sample size for testing (default: use all stocks)')
    parser.add_argument('--ma', type=int, default=50, help='MA period for simple calculations')
    parser.add_argument('--no-cache', action='store_true', help='Force fresh calculation (ignore cache)')
    
    args = parser.parse_args()
    
    try:
        # Initialize Kite
        logger.info("Connecting to Kite...")
        kite = KiteConnect(api_key=API_KEY)
        kite.set_access_token(ACCESS_TOKEN)
        
        # Verify connection
        profile = kite.profile()
        logger.info(f"Connected as: {profile.get('user_id')}")
        
        # Load universe
        logger.info(f"\nLoading stock universe from {INPUT_CSV}...")
        universe_df = pd.read_csv(INPUT_CSV)
        logger.info(f"Loaded {len(universe_df)} stocks")
        
        # Initialize calculator
        calculator = MarketBreadthCalculator(kite)
        
        # Calculate breadth
        results = calculator.calculate_comprehensive_breadth(
            universe_df,
            sample_size=args.sample
        )
        
        # Save results
        calculator.save_results(results)
        
        # Print summary
        calculator.print_summary(results)
        
    except KeyboardInterrupt:
        logger.info("\nScan interrupted by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)


if __name__ == "__main__":
    main()

