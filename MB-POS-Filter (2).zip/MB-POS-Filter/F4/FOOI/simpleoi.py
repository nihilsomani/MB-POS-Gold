from kiteconnect import KiteConnect

def main():
    # ---- Inputs ----
    symbol = input("Enter symbol (e.g., RELIANCE, HINDALCO): ").upper()
    api_key = input("Enter your API KEY: ").strip()
    access_token = input("Enter your ACCESS TOKEN: ").strip()

    kite = KiteConnect(api_key=api_key)
    kite.set_access_token(access_token)

    print("\nFetching instrument list...")
    instruments = kite.instruments("NFO")

    # ---------------------- FUTURES ----------------------
    futures = [
        inst for inst in instruments
        if inst["segment"] == "NFO-FUT" and inst["tradingsymbol"].startswith(symbol)
    ]

    if not futures:
        print("No futures found.")
        return

    futures = sorted(futures, key=lambda x: x["expiry"])
    current_month = futures[0]
    next_month = futures[1] if len(futures) > 1 else None

    # Fetch quotes for futures
    fut_tokens = [current_month["instrument_token"]]
    if next_month:
        fut_tokens.append(next_month["instrument_token"])

    fut_quotes = kite.quote(fut_tokens)

    # Helper to print future info
    def print_future(name, inst):
        q = fut_quotes[str(inst["instrument_token"])]
        print(f"\n{name} FUTURE")
        print("-------------------------")
        print("Contract:", inst["tradingsymbol"])
        print("Expiry  :", inst["expiry"])
        print("LTP     :", q["last_price"])
        print("OI      :", q["oi"])

    print_future("CURRENT MONTH", current_month)
    if next_month:
        print_future("NEXT MONTH", next_month)

    # ---------------------- OPTIONS ----------------------
    print("\nFetching ALL strike options (current expiry)...")

    # Filter index or stock options
    options = [
        inst for inst in instruments
        if inst["segment"] == "NFO-OPT"
        and inst["name"] == symbol
        and inst["expiry"] == current_month["expiry"]  # same expiry as current-month future
    ]

    if not options:
        print("No option chain found for this symbol.")
        return

    # Collect all tokens for OI fetch
    option_tokens = [opt["instrument_token"] for opt in options]
    option_quotes = kite.quote(option_tokens)

    cumulative_call_oi = 0
    cumulative_put_oi = 0

    for opt in options:
        q = option_quotes[str(opt["instrument_token"])]
        if opt["instrument_type"] == "CE":
            cumulative_call_oi += q["oi"]
        elif opt["instrument_type"] == "PE":
            cumulative_put_oi += q["oi"]

    print("\n---------------------- OPTION CHAIN SUMMARY ----------------------")
    print("Expiry:", current_month["expiry"])
    print("Cumulative CALL OI :", cumulative_call_oi)
    print("Cumulative PUT OI  :", cumulative_put_oi)
    print("PCR (Put/Call)     :", round(cumulative_put_oi / cumulative_call_oi, 2))
    print("------------------------------------------------------------------")

if __name__ == "__main__":
    main()
