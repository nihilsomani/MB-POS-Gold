#!/usr/bin/env python3
"""
F&O Professional Trading Desk Engine
====================================
Institutional-grade options analytics for directional and non-directional trading strategies
Author: Pro Desk Analytics Team
Version: 2.0 Production
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

warnings.filterwarnings('ignore')

# =====================================
# CONFIGURATION & CONSTANTS
# =====================================

class SignalStrength(Enum):
    """Signal strength classification"""
    VERY_STRONG = "VERY_STRONG"
    STRONG = "STRONG"
    MODERATE = "MODERATE"
    WEAK = "WEAK"
    NEUTRAL = "NEUTRAL"

class TradeType(Enum):
    """Trade type classification"""
    DIRECTIONAL_BULL = "DIRECTIONAL_BULL"
    DIRECTIONAL_BEAR = "DIRECTIONAL_BEAR"
    NON_DIRECTIONAL = "NON_DIRECTIONAL"
    CALENDAR_SPREAD = "CALENDAR_SPREAD"
    RATIO_SPREAD = "RATIO_SPREAD"

@dataclass
class TradingSignal:
    """Trading signal data structure"""
    timestamp: datetime
    symbol: str
    signal_type: TradeType
    strength: SignalStrength
    entry_level: float
    target_levels: List[float]
    stop_loss: float
    confidence: float
    rationale: str
    risk_reward: float
    holding_period: str

# =====================================
# CORE ANALYTICS ENGINE
# =====================================

class FOProDeskEngine:
    """
    Professional F&O Trading Desk Analytics Engine
    Combines multiple analytical frameworks for institutional-grade signals
    """
    
    def __init__(self, daily_data_path: str, screener_data_path: str):
        """Initialize the Pro Desk Engine with data paths"""
        self.daily_data_path = daily_data_path
        self.screener_data_path = screener_data_path
        self.daily_data = None
        self.screener_data = None
        self.analytics_results = {}
        self.trading_signals = []
        
    def load_and_prepare_data(self) -> bool:
        """Load and prepare all data sources"""
        try:
            # Load daily trend master data
            self.daily_data = pd.read_csv(self.daily_data_path)
            self.daily_data['date'] = pd.to_datetime(self.daily_data['date'])
            
            # Load screener snapshot data
            self.screener_data = pd.read_csv(self.screener_data_path)
            
            # Data validation
            if self.daily_data.empty or self.screener_data.empty:
                raise ValueError("Data files are empty")
                
            print("✓ Data loaded successfully")
            print(f"  - Daily records: {len(self.daily_data)}")
            print(f"  - Screener instruments: {len(self.screener_data)}")
            
            return True
            
        except Exception as e:
            print(f"✗ Error loading data: {str(e)}")
            return False
    
    def calculate_derived_metrics(self, symbol: str) -> Dict:
        """Calculate advanced derived metrics not directly available in data"""
        
        metrics = {}
        
        # Filter data for symbol
        symbol_data = self.daily_data[self.daily_data['symbol'] == symbol].copy()
        current_month = symbol_data[symbol_data['contract_type'] == 'current'].copy()
        next_month = symbol_data[symbol_data['contract_type'] == 'next'].copy()
        spot_data = symbol_data[symbol_data['contract_type'] == 'spot'].copy()
        
        # Get screener data for symbol
        screener_row = self.screener_data[self.screener_data['Instrument'] == symbol]
        
        if current_month.empty or screener_row.empty:
            return metrics
        
        # ===== 1. OI ANALYTICS =====
        
        # OI Velocity (Rate of change acceleration)
        if len(current_month) >= 2:
            current_oi = current_month['oi'].values
            oi_velocity = np.diff(current_oi) / current_oi[:-1] * 100 if len(current_oi) > 1 else 0
            metrics['oi_velocity_current'] = oi_velocity[-1] if len(oi_velocity) > 0 else 0
            
            # OI Acceleration (2nd derivative)
            if len(oi_velocity) > 1:
                metrics['oi_acceleration'] = oi_velocity[-1] - oi_velocity[-2]
            else:
                metrics['oi_acceleration'] = 0
        
        # Next month OI analysis
        if not next_month.empty and len(next_month) >= 2:
            next_oi = next_month['oi'].values
            oi_velocity_next = np.diff(next_oi) / next_oi[:-1] * 100 if len(next_oi) > 1 else 0
            metrics['oi_velocity_next'] = oi_velocity_next[-1] if len(oi_velocity_next) > 0 else 0
            
            # Rollover strength
            metrics['rollover_strength'] = (
                next_month['oi'].iloc[-1] / current_month['oi'].iloc[-1]
                if current_month['oi'].iloc[-1] > 0 else 0
            )
        
        # ===== 2. BASIS & FUTURES ANALYSIS =====
        
        if not spot_data.empty:
            current_spot = spot_data['close'].iloc[-1]
            current_future = current_month['close'].iloc[-1]
            
            # Basis calculation
            metrics['current_basis'] = current_future - current_spot
            metrics['basis_percentage'] = (metrics['current_basis'] / current_spot) * 100
            
            # Basis trend (if we have history)
            if len(spot_data) >= 2 and len(current_month) >= 2:
                prev_basis = current_month['close'].iloc[-2] - spot_data['close'].iloc[-2]
                metrics['basis_momentum'] = metrics['current_basis'] - prev_basis
            
            # Calendar spread
            if not next_month.empty:
                next_future = next_month['close'].iloc[-1]
                metrics['calendar_spread'] = next_future - current_future
                metrics['calendar_spread_pct'] = (metrics['calendar_spread'] / current_future) * 100
        
        # ===== 3. PCR ANALYTICS =====
        
        if 'options_pcr' in current_month.columns:
            current_pcr = current_month['options_pcr'].iloc[-1]
            metrics['current_pcr'] = current_pcr
            
            # PCR momentum
            if len(current_month) >= 2:
                prev_pcr = current_month['options_pcr'].iloc[-2]
                metrics['pcr_change'] = current_pcr - prev_pcr
                metrics['pcr_momentum'] = ((current_pcr - prev_pcr) / prev_pcr) * 100
            
            # PCR divergence from mean
            pcr_mean = current_month['options_pcr'].mean()
            pcr_std = current_month['options_pcr'].std()
            metrics['pcr_zscore'] = (current_pcr - pcr_mean) / pcr_std if pcr_std > 0 else 0
        
        # ===== 4. IV ANALYTICS =====
        
        if not screener_row.empty:
            metrics['current_iv'] = screener_row['ATMIV'].values[0]
            metrics['iv_percentile'] = screener_row['IVPercentile'].values[0]
            metrics['iv_change'] = screener_row['ATMIVChange'].values[0]
            
            # IV premium/discount analysis
            if metrics['iv_percentile'] > 75:
                metrics['iv_regime'] = "ELEVATED"
            elif metrics['iv_percentile'] < 25:
                metrics['iv_regime'] = "COMPRESSED"
            else:
                metrics['iv_regime'] = "NORMAL"
        
        # ===== 5. PRICE ACTION METRICS =====
        
        if not current_month.empty:
            # Price momentum
            metrics['price_return'] = current_month['price_return_pct'].iloc[-1]
            
            # Range analysis
            metrics['daily_range_pct'] = current_month['daily_range_pct'].iloc[-1]
            
            # Support/Resistance from max pain
            if not screener_row.empty:
                max_pain = screener_row['MaxPain'].values[0]
                current_price = current_month['close'].iloc[-1]
                metrics['distance_from_maxpain'] = ((current_price - max_pain) / max_pain) * 100
                metrics['max_pain_level'] = max_pain
        
        # ===== 6. VOLUME ANALYTICS =====
        
        if 'volume' in current_month.columns:
            current_volume = current_month['volume'].iloc[-1]
            avg_volume = current_month['volume'].mean()
            metrics['volume_ratio'] = current_volume / avg_volume if avg_volume > 0 else 1
            
            # Volume-OI divergence
            if len(current_month) >= 2:
                volume_change = ((current_volume - current_month['volume'].iloc[-2]) / 
                               current_month['volume'].iloc[-2] * 100)
                oi_change = current_month['oi_change_pct'].iloc[-1]
                metrics['volume_oi_divergence'] = volume_change - oi_change
        
        # ===== 7. OPTIONS FLOW ANALYSIS =====
        
        call_oi = current_month['options_call_oi'].iloc[-1] if 'options_call_oi' in current_month.columns else 0
        put_oi = current_month['options_put_oi'].iloc[-1] if 'options_put_oi' in current_month.columns else 0
        
        if call_oi > 0 and put_oi > 0:
            # Call-Put OI Ratio
            metrics['call_put_ratio'] = call_oi / put_oi
            
            # OI Skew
            total_oi = call_oi + put_oi
            metrics['oi_skew'] = (call_oi - put_oi) / total_oi * 100
            
            # Net OI positioning
            if len(current_month) >= 2:
                prev_call_oi = current_month['options_call_oi'].iloc[-2]
                prev_put_oi = current_month['options_put_oi'].iloc[-2]
                
                call_change = call_oi - prev_call_oi
                put_change = put_oi - prev_put_oi
                
                metrics['net_oi_flow'] = call_change - put_change
                metrics['flow_sentiment'] = "BULLISH" if metrics['net_oi_flow'] > 0 else "BEARISH"
        
        return metrics
    
    def detect_patterns(self, symbol: str, metrics: Dict) -> List[Dict]:
        """Detect advanced trading patterns from metrics"""
        
        patterns = []
        
        # ===== PATTERN 1: INSTITUTIONAL ACCUMULATION =====
        if (metrics.get('oi_velocity_next', 0) > 50 and 
            metrics.get('rollover_strength', 0) > 0.1 and
            metrics.get('iv_percentile', 0) < 60):
            
            patterns.append({
                'name': 'INSTITUTIONAL_ACCUMULATION',
                'confidence': min(95, metrics.get('oi_velocity_next', 0)),
                'direction': 'BULLISH',
                'timeframe': '2-4 weeks',
                'description': f"Heavy accumulation in next month contracts ({metrics.get('oi_velocity_next', 0):.1f}% OI surge)"
            })
        
        # ===== PATTERN 2: SQUEEZE BREAKOUT SETUP =====
        if (abs(metrics.get('pcr_zscore', 0)) > 2 and 
            metrics.get('daily_range_pct', 100) < 1.5 and
            metrics.get('iv_percentile', 0) < 40):
            
            direction = "BULLISH" if metrics.get('pcr_zscore', 0) < -2 else "BEARISH"
            patterns.append({
                'name': 'SQUEEZE_BREAKOUT',
                'confidence': 85,
                'direction': direction,
                'timeframe': '1-3 days',
                'description': f"Volatility compression with PCR at extreme (Z-score: {metrics.get('pcr_zscore', 0):.2f})"
            })
        
        # ===== PATTERN 3: MAX PAIN REVERSION =====
        distance = abs(metrics.get('distance_from_maxpain', 0))
        if distance > 3:
            patterns.append({
                'name': 'MAX_PAIN_REVERSION',
                'confidence': 70 + min(20, distance * 2),
                'direction': 'MEAN_REVERSION',
                'timeframe': '3-5 days',
                'description': f"Price {distance:.1f}% away from max pain magnet"
            })
        
        # ===== PATTERN 4: CALENDAR SPREAD OPPORTUNITY =====
        if (metrics.get('calendar_spread_pct', 0) > 0.5 and 
            metrics.get('iv_regime') != "ELEVATED"):
            
            patterns.append({
                'name': 'CALENDAR_SPREAD',
                'confidence': 75,
                'direction': 'NEUTRAL',
                'timeframe': '2-3 weeks',
                'description': f"Favorable calendar spread setup ({metrics.get('calendar_spread_pct', 0):.2f}% premium)"
            })
        
        # ===== PATTERN 5: VOLUME-OI DIVERGENCE =====
        vol_oi_div = metrics.get('volume_oi_divergence', 0)
        if abs(vol_oi_div) > 50:
            patterns.append({
                'name': 'VOLUME_OI_DIVERGENCE',
                'confidence': 65,
                'direction': 'BULLISH' if vol_oi_div > 0 else 'BEARISH',
                'timeframe': '1-2 days',
                'description': f"Volume-OI divergence detected ({vol_oi_div:.1f}%)"
            })
        
        # ===== PATTERN 6: BASIS MOMENTUM SHIFT =====
        if abs(metrics.get('basis_momentum', 0)) > 10:
            patterns.append({
                'name': 'BASIS_MOMENTUM_SHIFT',
                'confidence': 70,
                'direction': 'BULLISH' if metrics.get('basis_momentum', 0) > 0 else 'BEARISH',
                'timeframe': '3-5 days',
                'description': f"Strong basis momentum shift ({metrics.get('basis_momentum', 0):.1f} points)"
            })
        
        return patterns
    
    def generate_trading_signals(self, symbol: str, metrics: Dict, patterns: List[Dict]) -> List[TradingSignal]:
        """Generate specific trading signals with entry, exit, and risk parameters"""
        
        signals = []
        current_price = self.daily_data[
            (self.daily_data['symbol'] == symbol) & 
            (self.daily_data['contract_type'] == 'current')
        ]['close'].iloc[-1]
        
        # ===== DIRECTIONAL SIGNALS =====
        
        # Bull signal conditions
        bull_score = 0
        bull_factors = []
        
        if metrics.get('pcr_zscore', 0) < -1.5:
            bull_score += 25
            bull_factors.append("PCR oversold")
        if metrics.get('oi_velocity_next', 0) > 30:
            bull_score += 30
            bull_factors.append("Next month accumulation")
        if metrics.get('basis_momentum', 0) > 5:
            bull_score += 20
            bull_factors.append("Positive basis momentum")
        if metrics.get('net_oi_flow', 0) > 0:
            bull_score += 15
            bull_factors.append("Bullish OI flow")
        if metrics.get('distance_from_maxpain', 0) < -2:
            bull_score += 10
            bull_factors.append("Below max pain support")
        
        # Generate bull signal if score is high enough
        if bull_score >= 60:
            entry = current_price
            stop_loss = current_price * 0.98  # 2% stop
            target1 = current_price * 1.02  # 2% target
            target2 = current_price * 1.035  # 3.5% target
            target3 = current_price * 1.05  # 5% target
            
            signal_strength = (SignalStrength.VERY_STRONG if bull_score >= 85 else
                             SignalStrength.STRONG if bull_score >= 70 else
                             SignalStrength.MODERATE)
            
            signals.append(TradingSignal(
                timestamp=datetime.now(),
                symbol=symbol,
                signal_type=TradeType.DIRECTIONAL_BULL,
                strength=signal_strength,
                entry_level=entry,
                target_levels=[target1, target2, target3],
                stop_loss=stop_loss,
                confidence=bull_score,
                rationale=f"Bullish setup: {', '.join(bull_factors)}",
                risk_reward=(target2 - entry) / (entry - stop_loss),
                holding_period="1-5 days"
            ))
        
        # Bear signal conditions
        bear_score = 0
        bear_factors = []
        
        if metrics.get('pcr_zscore', 0) > 1.5:
            bear_score += 25
            bear_factors.append("PCR overbought")
        if metrics.get('oi_velocity_current', 0) < -20:
            bear_score += 25
            bear_factors.append("OI unwinding")
        if metrics.get('basis_momentum', 0) < -5:
            bear_score += 20
            bear_factors.append("Negative basis momentum")
        if metrics.get('net_oi_flow', 0) < 0:
            bear_score += 15
            bear_factors.append("Bearish OI flow")
        if metrics.get('distance_from_maxpain', 0) > 2:
            bear_score += 15
            bear_factors.append("Above max pain resistance")
        
        # Generate bear signal if score is high enough
        if bear_score >= 60:
            entry = current_price
            stop_loss = current_price * 1.02  # 2% stop
            target1 = current_price * 0.98  # 2% target
            target2 = current_price * 0.965  # 3.5% target
            target3 = current_price * 0.95  # 5% target
            
            signal_strength = (SignalStrength.VERY_STRONG if bear_score >= 85 else
                             SignalStrength.STRONG if bear_score >= 70 else
                             SignalStrength.MODERATE)
            
            signals.append(TradingSignal(
                timestamp=datetime.now(),
                symbol=symbol,
                signal_type=TradeType.DIRECTIONAL_BEAR,
                strength=signal_strength,
                entry_level=entry,
                target_levels=[target1, target2, target3],
                stop_loss=stop_loss,
                confidence=bear_score,
                rationale=f"Bearish setup: {', '.join(bear_factors)}",
                risk_reward=(entry - target2) / (stop_loss - entry),
                holding_period="1-5 days"
            ))
        
        # ===== NON-DIRECTIONAL SIGNALS =====
        
        strangle_score = 0
        strangle_factors = []
        
        if metrics.get('iv_percentile', 0) > 50:
            strangle_score += 30
            strangle_factors.append(f"IV at {metrics.get('iv_percentile', 0)}th percentile")
        if abs(metrics.get('distance_from_maxpain', 0)) < 1.5:
            strangle_score += 25
            strangle_factors.append("Near max pain equilibrium")
        if metrics.get('daily_range_pct', 0) > 2:
            strangle_score += 20
            strangle_factors.append("Elevated daily range")
        if 0.5 < metrics.get('current_pcr', 1) < 0.8:
            strangle_score += 15
            strangle_factors.append("Balanced PCR")
        if metrics.get('rollover_strength', 0) < 0.05:
            strangle_score += 10
            strangle_factors.append("Low rollover activity")
        
        # Generate strangle signal
        if strangle_score >= 50:
            call_strike = current_price * 1.03  # 3% OTM call
            put_strike = current_price * 0.97   # 3% OTM put
            
            signal_strength = (SignalStrength.STRONG if strangle_score >= 70 else
                             SignalStrength.MODERATE)
            
            signals.append(TradingSignal(
                timestamp=datetime.now(),
                symbol=symbol,
                signal_type=TradeType.NON_DIRECTIONAL,
                strength=signal_strength,
                entry_level=current_price,
                target_levels=[call_strike, put_strike],  # Strike levels
                stop_loss=current_price * 1.05,  # Adjustment trigger
                confidence=strangle_score,
                rationale=f"Short strangle setup: {', '.join(strangle_factors)}",
                risk_reward=1.5,  # Typical for credit strategies
                holding_period="2-4 weeks"
            ))
        
        # ===== CALENDAR SPREAD SIGNAL =====
        
        if (metrics.get('calendar_spread_pct', 0) > 0.3 and 
            metrics.get('iv_percentile', 0) < 60):
            
            signals.append(TradingSignal(
                timestamp=datetime.now(),
                symbol=symbol,
                signal_type=TradeType.CALENDAR_SPREAD,
                strength=SignalStrength.MODERATE,
                entry_level=current_price,
                target_levels=[current_price * 1.02],
                stop_loss=current_price * 0.98,
                confidence=65,
                rationale=f"Calendar spread: {metrics.get('calendar_spread_pct', 0):.2f}% premium with IV at {metrics.get('iv_percentile', 0)}%",
                risk_reward=2.0,
                holding_period="2-3 weeks"
            ))
        
        return signals
    
    def calculate_risk_metrics(self, symbol: str, metrics: Dict) -> Dict:
        """Calculate comprehensive risk metrics for position sizing and management"""
        
        risk_metrics = {}
        
        # Historical volatility estimation
        if 'daily_range_pct' in metrics:
            # Annualized volatility approximation
            daily_vol = metrics['daily_range_pct'] / 2.5  # Rough approximation
            risk_metrics['estimated_volatility'] = daily_vol * np.sqrt(252)
        
        # Value at Risk (simplified)
        current_price = self.daily_data[
            (self.daily_data['symbol'] == symbol) & 
            (self.daily_data['contract_type'] == 'current')
        ]['close'].iloc[-1]
        
        risk_metrics['var_95_1day'] = current_price * 0.02  # 2% VaR
        risk_metrics['var_95_5day'] = current_price * 0.045  # 4.5% VaR
        
        # Options Greeks approximation
        if metrics.get('current_iv'):
            iv = metrics['current_iv'] / 100
            # Simplified ATM Greeks
            risk_metrics['atm_delta'] = 0.5
            risk_metrics['atm_gamma'] = 1 / (current_price * iv * np.sqrt(30/365))
            risk_metrics['atm_theta'] = -(current_price * iv) / (2 * np.sqrt(365))
            risk_metrics['atm_vega'] = current_price * np.sqrt(30/365) * 0.4
        
        # Position sizing recommendations
        if metrics.get('iv_percentile', 0) > 75:
            risk_metrics['recommended_position_size'] = "REDUCED (50-70% of normal)"
            risk_metrics['position_size_multiplier'] = 0.6
        elif metrics.get('iv_percentile', 0) < 25:
            risk_metrics['recommended_position_size'] = "INCREASED (120-130% of normal)"
            risk_metrics['position_size_multiplier'] = 1.25
        else:
            risk_metrics['recommended_position_size'] = "NORMAL (100%)"
            risk_metrics['position_size_multiplier'] = 1.0
        
        # Risk score (0-100)
        risk_score = 50  # Base score
        
        # Adjust based on various factors
        if metrics.get('iv_percentile', 0) > 80:
            risk_score += 20
        if abs(metrics.get('pcr_zscore', 0)) > 2:
            risk_score += 15
        if metrics.get('volume_ratio', 1) > 2:
            risk_score += 10
        if abs(metrics.get('distance_from_maxpain', 0)) > 5:
            risk_score += 10
        
        risk_metrics['overall_risk_score'] = min(100, risk_score)
        risk_metrics['risk_level'] = ("HIGH" if risk_score > 70 else
                                      "MODERATE" if risk_score > 40 else
                                      "LOW")
        
        return risk_metrics
    
    def generate_comprehensive_report(self, symbol: str) -> str:
        """Generate comprehensive trading desk report for a symbol"""
        
        # Calculate all analytics
        metrics = self.calculate_derived_metrics(symbol)
        patterns = self.detect_patterns(symbol, metrics)
        signals = self.generate_trading_signals(symbol, metrics, patterns)
        risk_metrics = self.calculate_risk_metrics(symbol, metrics)
        
        # Store results
        self.analytics_results[symbol] = {
            'metrics': metrics,
            'patterns': patterns,
            'signals': signals,
            'risk_metrics': risk_metrics
        }
        
        # Generate report
        report = []
        report.append("=" * 80)
        report.append(f"F&O PRO DESK ANALYTICS REPORT - {symbol}")
        report.append("=" * 80)
        report.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append("")
        
        # SECTION 1: MARKET OVERVIEW
        report.append("【 MARKET OVERVIEW 】")
        report.append("-" * 40)
        
        current_data = self.daily_data[
            (self.daily_data['symbol'] == symbol) & 
            (self.daily_data['contract_type'] == 'current')
        ].iloc[-1]
        
        report.append(f"Current Price: {current_data['close']:.2f}")
        report.append(f"Day Change: {metrics.get('price_return', 0):.2f}%")
        report.append(f"Daily Range: {metrics.get('daily_range_pct', 0):.2f}%")
        report.append(f"Volume Ratio: {metrics.get('volume_ratio', 1):.2f}x")
        report.append("")
        
        # SECTION 2: OPTIONS ANALYTICS
        report.append("【 OPTIONS ANALYTICS 】")
        report.append("-" * 40)
        report.append(f"PCR: {metrics.get('current_pcr', 0):.3f} (Z-score: {metrics.get('pcr_zscore', 0):.2f})")
        report.append(f"PCR Momentum: {metrics.get('pcr_momentum', 0):.2f}%")
        report.append(f"IV Percentile: {metrics.get('iv_percentile', 0):.0f}%")
        report.append(f"IV Regime: {metrics.get('iv_regime', 'NORMAL')}")
        report.append(f"Max Pain: {metrics.get('max_pain_level', 0):.0f} (Distance: {metrics.get('distance_from_maxpain', 0):.2f}%)")
        report.append("")
        
        # SECTION 3: FUTURES & BASIS
        report.append("【 FUTURES & BASIS ANALYSIS 】")
        report.append("-" * 40)
        report.append(f"Current Month Basis: {metrics.get('current_basis', 0):.2f} ({metrics.get('basis_percentage', 0):.3f}%)")
        report.append(f"Calendar Spread: {metrics.get('calendar_spread', 0):.2f} ({metrics.get('calendar_spread_pct', 0):.3f}%)")
        report.append(f"Rollover Strength: {metrics.get('rollover_strength', 0):.3f}")
        report.append(f"Basis Momentum: {metrics.get('basis_momentum', 0):.2f}")
        report.append("")
        
        # SECTION 4: OI FLOW ANALYSIS
        report.append("【 OPEN INTEREST FLOW 】")
        report.append("-" * 40)
        report.append(f"Current Month OI Velocity: {metrics.get('oi_velocity_current', 0):.2f}%")
        report.append(f"Next Month OI Velocity: {metrics.get('oi_velocity_next', 0):.2f}%")
        report.append(f"OI Acceleration: {metrics.get('oi_acceleration', 0):.2f}%")
        report.append(f"Net OI Flow: {metrics.get('net_oi_flow', 0):.0f} ({metrics.get('flow_sentiment', 'NEUTRAL')})")
        report.append(f"Volume-OI Divergence: {metrics.get('volume_oi_divergence', 0):.2f}%")
        report.append("")
        
        # SECTION 5: PATTERN DETECTION
        report.append("【 PATTERN RECOGNITION 】")
        report.append("-" * 40)
        
        if patterns:
            for pattern in patterns[:3]:  # Top 3 patterns
                report.append(f"◆ {pattern['name']} (Confidence: {pattern['confidence']:.0f}%)")
                report.append(f"  Direction: {pattern['direction']} | Timeframe: {pattern['timeframe']}")
                report.append(f"  {pattern['description']}")
                report.append("")
        else:
            report.append("No significant patterns detected")
            report.append("")
        
        # SECTION 6: TRADING SIGNALS
        report.append("【 TRADING SIGNALS 】")
        report.append("-" * 40)
        
        if signals:
            for i, signal in enumerate(signals[:3], 1):  # Top 3 signals
                report.append(f"Signal #{i}: {signal.signal_type.value} [{signal.strength.value}]")
                report.append(f"  Entry: {signal.entry_level:.2f}")
                report.append(f"  Targets: {', '.join([f'{t:.2f}' for t in signal.target_levels])}")
                report.append(f"  Stop Loss: {signal.stop_loss:.2f}")
                report.append(f"  Risk/Reward: {signal.risk_reward:.2f}")
                report.append(f"  Confidence: {signal.confidence:.0f}%")
                report.append(f"  Holding Period: {signal.holding_period}")
                report.append(f"  Rationale: {signal.rationale}")
                report.append("")
        else:
            report.append("No actionable signals at current levels")
            report.append("")
        
        # SECTION 7: RISK METRICS
        report.append("【 RISK MANAGEMENT 】")
        report.append("-" * 40)
        report.append(f"Risk Score: {risk_metrics['overall_risk_score']:.0f}/100 ({risk_metrics['risk_level']})")
        report.append(f"1-Day VaR (95%): {risk_metrics['var_95_1day']:.2f}")
        report.append(f"5-Day VaR (95%): {risk_metrics['var_95_5day']:.2f}")
        report.append(f"Position Sizing: {risk_metrics['recommended_position_size']}")
        
        if 'atm_gamma' in risk_metrics:
            report.append(f"\nGreeks (ATM Approximation):")
            report.append(f"  Delta: {risk_metrics['atm_delta']:.3f}")
            report.append(f"  Gamma: {risk_metrics['atm_gamma']:.6f}")
            report.append(f"  Theta: {risk_metrics['atm_theta']:.4f}")
            report.append(f"  Vega: {risk_metrics['atm_vega']:.4f}")
        report.append("")
        
        # SECTION 8: EXECUTION RECOMMENDATIONS
        report.append("【 EXECUTION RECOMMENDATIONS 】")
        report.append("-" * 40)
        
        # Directional recommendation
        if any(s.signal_type in [TradeType.DIRECTIONAL_BULL, TradeType.DIRECTIONAL_BEAR] for s in signals):
            dir_signal = next(s for s in signals if s.signal_type in [TradeType.DIRECTIONAL_BULL, TradeType.DIRECTIONAL_BEAR])
            report.append(f"DIRECTIONAL: {dir_signal.signal_type.value.replace('DIRECTIONAL_', '')}")
            report.append(f"  Strategy: Buy {dir_signal.signal_type.value.split('_')[1].lower()} options")
            report.append(f"  Strike Selection: ATM to 2% OTM")
            report.append(f"  Position Size: {risk_metrics['position_size_multiplier']:.1f}x normal")
        
        # Non-directional recommendation
        if any(s.signal_type == TradeType.NON_DIRECTIONAL for s in signals):
            report.append(f"\nNON-DIRECTIONAL: Short Strangle")
            report.append(f"  Call Strike: {current_data['close'] * 1.03:.0f}")
            report.append(f"  Put Strike: {current_data['close'] * 0.97:.0f}")
            report.append(f"  Delta Neutral: Adjust ratio based on PCR")
        
        # Calendar spread recommendation
        if metrics.get('calendar_spread_pct', 0) > 0.3:
            report.append(f"\nCALENDAR SPREAD: Favorable")
            report.append(f"  Buy: Next month ATM")
            report.append(f"  Sell: Current month ATM")
            report.append(f"  Premium Capture: {metrics.get('calendar_spread_pct', 0):.2f}%")
        
        report.append("")
        report.append("=" * 80)
        report.append("END OF REPORT - TRADE RESPONSIBLY")
        report.append("=" * 80)
        
        return "\n".join(report)
    
    def export_signals_to_json(self, output_path: str = "trading_signals.json") -> None:
        """Export all signals to JSON for system integration"""
        import json
        
        export_data = {
            'timestamp': datetime.now().isoformat(),
            'signals': []
        }
        
        for symbol, results in self.analytics_results.items():
            for signal in results['signals']:
                export_data['signals'].append({
                    'symbol': symbol,
                    'signal_type': signal.signal_type.value,
                    'strength': signal.strength.value,
                    'entry': signal.entry_level,
                    'targets': signal.target_levels,
                    'stop_loss': signal.stop_loss,
                    'confidence': signal.confidence,
                    'risk_reward': signal.risk_reward,
                    'holding_period': signal.holding_period,
                    'rationale': signal.rationale
                })
        
        with open(output_path, 'w') as f:
            json.dump(export_data, f, indent=2)
        
        print(f"✓ Signals exported to {output_path}")
    
    def run_complete_analysis(self) -> None:
        """Run complete analysis pipeline"""
        
        # Load data
        if not self.load_and_prepare_data():
            return
        
        print("\n" + "=" * 80)
        print("INITIATING F&O PRO DESK ANALYSIS ENGINE")
        print("=" * 80)
        
        # Get unique symbols
        symbols = self.daily_data['symbol'].unique()
        
        # Analyze each symbol
        for symbol in symbols:
            print(f"\n▶ Analyzing {symbol}...")
            
            try:
                # Generate comprehensive report
                report = self.generate_comprehensive_report(symbol)
                
                # Print report
                print(report)
                
                # Save report to file
                report_filename = f"report_{symbol}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                with open(report_filename, 'w') as f:
                    f.write(report)
                
                print(f"✓ Report saved to {report_filename}")
                
            except Exception as e:
                print(f"✗ Error analyzing {symbol}: {str(e)}")
                continue
        
        # Export all signals
        self.export_signals_to_json()
        
        print("\n" + "=" * 80)
        print("ANALYSIS COMPLETE - HAPPY TRADING!")
        print("=" * 80)


# =====================================
# MAIN EXECUTION
# =====================================

def main():
    """Main execution function"""
    
    # Initialize engine with your data files
    engine = FOProDeskEngine(
        daily_data_path='data/daily_trend_master.csv',
        screener_data_path='data/options_screener_2025-11-17-07-52-49.csv'
    )
    
    # Run complete analysis
    engine.run_complete_analysis()
    
    # Print summary statistics
    print("\n📊 ANALYSIS SUMMARY:")
    print(f"Total symbols analyzed: {len(engine.analytics_results)}")
    
    total_signals = sum(len(results['signals']) for results in engine.analytics_results.values())
    print(f"Total trading signals generated: {total_signals}")
    
    # Count signals by type
    signal_types = {}
    for results in engine.analytics_results.values():
        for signal in results['signals']:
            signal_type = signal.signal_type.value
            signal_types[signal_type] = signal_types.get(signal_type, 0) + 1
    
    print("\n📈 SIGNALS BY TYPE:")
    for stype, count in signal_types.items():
        print(f"  {stype}: {count}")
    
    # High confidence signals
    high_confidence_signals = []
    for symbol, results in engine.analytics_results.items():
        for signal in results['signals']:
            if signal.confidence >= 70:
                high_confidence_signals.append((symbol, signal))
    
    if high_confidence_signals:
        print(f"\n⚡ HIGH CONFIDENCE SIGNALS (≥70%):")
        for symbol, signal in high_confidence_signals[:5]:  # Top 5
            print(f"  {symbol}: {signal.signal_type.value} [{signal.confidence:.0f}%]")


if __name__ == "__main__":
    main()