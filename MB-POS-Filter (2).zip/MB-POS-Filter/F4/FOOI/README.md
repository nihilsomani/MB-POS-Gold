# FOOI Runbook

## Overview
- **Purpose**: Execute the full non-directional (3–5 week straddles) and directional (1–3 day momentum) pipeline using the specialist scanners and the command center.
- **Philosophy**: Specialists own signal logic; the command center orchestrates and enforces risk. Never re-implement strategy rules in multiple places.
- **Artifacts**: CSV reports with timestamps, console logs, and diagnostics.

## Prerequisites
- Activate the same Python environment used previously (packages: `pandas`, `numpy`, `kiteconnect`, etc.).
- Ensure Kite API credentials are valid and exported (`KITE_API_KEY`, `KITE_ACCESS_TOKEN`) when running the live data scripts.
- Place the latest options screener CSV (real ATM IV data) inside `C:\nihil\finance_ai_ws\`.

## Daily Sequence

### 1. Generate trend context (OITrendScanner)
```
cd C:\nihil\finance_ai_ws\MB-POS-Filter\F4\FOOI
python OITrendScanner.py
```
- **Output**: `trend_results_adaptive_v10_nuance_*.csv`
- **Watch for**: Console logs confirming detected market regime and number of symbols.
- **Fail fast**: Rate-limit or token errors ⇒ fix Kite session before proceeding.

### 2. Build Greeks/IV snapshot (delta_strangle_scanner)
```
python delta_strangle_scanner_kite_sd.py
```
- **Output**: `kite_equal_delta_strangles_*.csv`
- **Watch for**: Successful Kite connection, IV data age warning, and summary of strangle candidates.
- **Non-directional guardrails**: Script already flags risk metrics (gamma, Vega, theta). Use the generated CSV for diagnostics only.

### 3. Run specialist scanners
```
python greeks_powered_scanner.py
python Claude-OI-Snapshot-Analysis.py
```
- **Greeks scanner output**:
  - `greeks_directional_*.csv` (directional scores)
  - `greeks_straddles_*.csv` (short straddle scores)
- **Claude output**:
  - Command-line report + `fno_analysis_results.csv`
  - `fno_straddle_results.csv`
- **Watch for**: Symbols that pass hard filters (IV rank, risk score, DTE). Anything missing likely failed the specialist thresholds.

### 4. (Optional) Diagnostics
```
python ComprehensiveInsightScanner.py <trend_csv> --options <options_screener.csv> --greeks <kite_equal_delta_strangles_*.csv>
```
- Use only to review IV/event/gamma warnings. Treat all flags as informational.

### 5. Command center (authoritative decisions)
```
python options_command_center.py
```
- **Output**:
  - Console report with:
    - High conviction straddles (3–5 week horizon)
    - Directional bursts (1–3 day horizon)
    - Expert consensus badges
    - Trade profile tags (e.g., `NON_DIRECTIONAL_CONSENSUS`, `DIRECTIONAL_SPECIALIST_ONLY`)
    - Exit rules (profit/stop/time/Greek triggers)
  - CSV: `options_command_center_results_*.csv`
- **Decision flow**:
  - **Non-directional**: Trade only entries labeled `SELL STRADDLE` or `STRONG SELL STRADDLE` with `DTE 15–30`, `Claude` consensus, and positive theta. Follow implied exit rules (close at 70% credit, 2× stop, 7 DTE, gamma >0.01).
  - **Directional**: Enter high-score momentum trades (≥50) on futures/near-week options. Hold 1–3 days, exit on 3% move or OI reversal.
- **Portfolio checks**: Ensure command center’s summary (net delta, gamma, margin) stays within limits (delta < ₹5L, gamma <0.05, margin <70%).

## Review Checklist
- Confirm every script produced timestamps for today.
- Scan command center’s `🚫 EXPERT VETOES` section; do not override Claude vetoes.
- For open positions, refresh Greeks daily using the latest CSVs and exit when any rule triggers.

## Troubleshooting Tips
- **Missing CSVs**: Re-run the upstream scanner (e.g., no `greeks_straddles_*.csv` means `delta_strangle_scanner` or `greeks_powered_scanner` failed).
- **IV data stale warning**: Replace the options screener CSV with the latest export.
- **Kite authentication failures**: Renew access token before retrying any live-data script.
- **Command center fallback notice**: If it prints “No expert results found”, specialist CSVs were not generated—fix before trading.

## Quick Reference
- Non-directional filters: `DTE 15–30`, `IV percentile ≥55`, `theta/day > 5% credit`, `gamma < 0.08`.
- Directional filters: strong 7-day OI & price alignment, supportive PCR, DTE ≤7 for weekly plays.
- Always execute in the order above; the command center needs the fresh specialist outputs to operate.
