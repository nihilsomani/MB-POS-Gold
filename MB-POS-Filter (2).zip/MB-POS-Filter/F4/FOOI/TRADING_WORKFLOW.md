# Professional FNO Trading Workflow

## Daily Workflow (Production)

### Step 1: Generate Base Data (9:30 AM - Market Open)
```bash
# Run OI Trend Scanner (7-day trends)
python OITrendScanner.py
→ Output: trend_results_adaptive_v10_nuance_*.csv

# Run Delta Scanner (Greeks calculations)
python delta_strangle_scanner_kite_sd.py
→ Output: kite_equal_delta_strangles_*.csv
```

### Step 2: Run Specialist Scanners (9:45 AM)
```bash
# Greeks-powered analysis (straddles + directional)
python greeks_powered_scanner.py
→ Output: greeks_straddles_*.csv
→ Output: greeks_directional_*.csv

# Claude-OI analysis (optional but recommended)
python Claude-OI-Snapshot-Analysis.py
→ Output: claude_oi_results_*.csv (if configured)
```

### Step 3: Run Command Center (10:00 AM)
```bash
# Unified analysis with risk management
python options_command_center.py
→ Output: Unified recommendations
→ Output: Portfolio Greeks analysis
→ Output: Exit rules for each trade
```

---

## What Each Scanner Does

### OITrendScanner.py
**Role:** OI momentum & rollover intelligence  
**Output:** 7-day OI/price trends, rollover quality  
**Use:** Detect institutional flow, filter rollover noise

### delta_strangle_scanner_kite_sd.py  
**Role:** Raw Greeks calculator  
**Output:** Delta, gamma, theta, vega for all strikes  
**Use:** Foundation data for all other scanners

### greeks_powered_scanner.py
**Role:** EXPERT on straddle strategy selection  
**Filters:**
- IV Rank ≥ 40%
- Risk Score < 7
- DTE 7-35 days
- Score ≥ 60

**Scoring:** 0-150 points (comprehensive Greeks analysis)  
**Trust:** Use their recommendations directly

### Claude-OI-Snapshot-Analysis.py
**Role:** EXPERT on OI neutrality & event risk  
**Filters:**
- OI+Price neutrality detection
- Event calendar blocking
- IV spike warnings
- Range quality analysis

**Scoring:** 0-100 points  
**Trust:** Their VETO overrides all others (safety first)

### options_command_center.py
**Role:** ORCHESTRATOR + Risk Manager  
**Does NOT:** Reimplement strategy logic  
**Does:** 
- Combine expert opinions
- Filter rollover noise
- Calculate portfolio Greeks
- Generate exit rules
- Check risk limits

---

## Critical Features (Professional Grade)

### 1. Expert Veto System
```
If Claude-OI blocks (event risk, IV spike):
  → DON'T TRADE (even if Greeks loves it)
  → Example: POLICYBZR (event on Oct 29)
```

### 2. Rollover Noise Filtering
```
If DTE ≤ 5 AND OI >15% AND RQI <30:
  → This is rollover, not directional
  → Filter out false directional signals
  → Example: KOTAKBANK -19.6% OI (rollover week)
```

### 3. Portfolio Greeks Limits
```
MAX_NET_GAMMA = 0.05      (stop adding positions)
MAX_NET_DELTA = ₹5L       (rebalance if exceeded)
MAX_MARGIN_UTIL = 70%     (don't overleverage)
```

### 4. Exit Rules (Auto-Generated)
```
For SELL Straddle:
  ✅ Profit: 70% of credit
  🛑 Stop: 2x credit loss
  ⏰ Time: Close at 7 DTE (gamma risk)
  📊 Greeks: Close if gamma >0.01
```

---

## Risk Management Checklist

### Before Entering Trade:
- ✅ Expert recommends (score ≥ 60)
- ✅ No Claude-OI veto (event risk checked)
- ✅ Not rollover noise (context verified)
- ✅ Liquidity OK (OI ≥ 50K)
- ✅ Portfolio Greeks within limits
- ✅ Margin utilization < 70%

### After Entering Trade:
- 📊 Monitor delta daily (rehedge if >0.2)
- ⏰ Check DTE (exit straddles at 7 DTE)
- 📈 Watch IV changes (vega P&L)
- 🎯 Set alerts for exit rules

### Daily Monitoring:
- Portfolio theta (is it collecting?)
- Portfolio gamma (is risk increasing?)
- Portfolio delta (still neutral?)
- Individual position Greeks (any drifting?)

---

## Example Output Interpretation

### HIGH CONVICTION Trade:
```
Symbol: CIPLA | Score: 101 | STRONG SELL STRADDLE | HIGH
👥 Greeks: 152/150 ✅
📊 OI: +2.6% (neutral) ✅  
💰 Credit: ₹28 | Theta: ₹1.7/day
🎯 EXIT RULES:
   ✅ Profit Target: ₹20 (70%)
   🛑 Stop Loss: ₹56 (2x credit)
   ⏰ Time Exit: 7 DTE
   📊 Greek Exit: Gamma >0.01
```

**Action:** TRADE (all systems go)

### VETOED Trade:
```
Symbol: POLICYBZR | Greeks: 163/150 | Claude: BLOCKED
🚫 EVENT RISK: Oct 29
🚫 IV SPIKE: +37.4% rising
```

**Action:** DON'T TRADE (expert veto)

### ROLLOVER NOISE:
```
Symbol: KOTAKBANK | OI: -19.6% (DTE: 4)
ℹ️ Rollover noise, not directional
✅ Use straddle strategy instead (score: 99)
```

**Action:** SELL STRADDLE (not directional)

---

## Portfolio Greeks Interpretation

### Healthy Portfolio:
```
Net Delta: 0.05 ✅ (near zero)
Net Gamma: 0.023 ✅ (low risk)
Net Vega: -₹12K (short vol)
Net Theta: +₹35/day ✅ (collecting)
Margin: 45% ✅ (room to add)
```

### Risky Portfolio:
```
Net Delta: 0.85 🚨 (directional bias!)
Net Gamma: 0.078 🚨 (exceeds 0.05 limit!)
Net Theta: +₹80/day (high collection but...)
Margin: 85% 🚨 (overleveraged!)

→ REDUCE POSITIONS
→ HEDGE DELTA
→ DON'T ADD MORE
```

---

## Key Metrics to Watch

### For Straddle Portfolio:
1. **Daily Theta**: Should collect ₹20-50/day for ₹1Cr portfolio
2. **Gamma Risk**: 1% move should cost <₹20K
3. **Delta Drift**: Should stay within ±0.3
4. **Vega Exposure**: Short vol in high IV, long vol in low IV
5. **Time to Break-even**: Should be <20 days

### Red Flags:
- 🚨 Delta >0.5 (rehedge immediately)
- 🚨 Gamma >0.05 (reduce positions)
- 🚨 Margin >70% (free up capital)
- 🚨 Theta negative (you're paying, not collecting)
- 🚨 Any stock >3% of portfolio (concentration risk)

---

## Professional Best Practices

### Position Management:
1. **Enter:** At signal generation (score ≥60)
2. **Monitor:** Daily Greeks, every 2 hours on volatile days
3. **Adjust:** Rehedge delta if >0.2, reduce if gamma >limit
4. **Exit:** Follow rules (don't hope/pray)
5. **Review:** End of day P&L attribution (theta vs gamma vs vega)

### Risk Controls:
1. **Never:** Override expert veto (Claude blocks = DON'T TRADE)
2. **Always:** Check rollover context (DTE <5 = verify noise)
3. **Respect:** Portfolio limits (gamma, margin, delta)
4. **Diversify:** Max 3% per position, 15% per sector
5. **Hedge:** Keep net delta near zero for straddle portfolio

### Psychological Discipline:
1. **Trust the system** (expert scores > gut feel)
2. **Follow exit rules** (no "let me wait one more day")
3. **Accept vetoes** (Claude blocks = there's a reason)
4. **Respect limits** (portfolio Greeks = hard stops)
5. **Review daily** (what worked, what didn't, why)

---

## System Architecture Summary

```
LAYER 1: DATA COLLECTION
├─ OITrendScanner (OI momentum)
├─ delta_strangle_scanner (Greeks calculation)
└─ Market data (IV, PCR, VIX)

LAYER 2: SPECIALIST ANALYSIS
├─ greeks_powered_scanner (Greeks expert)
└─ Claude-OI-Snapshot (OI/event expert)

LAYER 3: ORCHESTRATION (options_command_center)
├─ Import expert results ✅
├─ Apply vetoes (Claude blocks) ✅
├─ Filter noise (rollover) ✅
├─ Calculate portfolio Greeks ✅
├─ Generate exit rules ✅
└─ Check risk limits ✅

LAYER 4: EXECUTION (Manual/API)
├─ Enter trades (with alerts set)
├─ Monitor Greeks (delta, gamma)
└─ Exit per rules (disciplined)
```

---

## Continuous Improvement

### What to Log:
- Entry score vs actual P&L
- Exit rule effectiveness (which triggered most)
- Veto accuracy (were Claude blocks correct?)
- Rollover filter accuracy (did it save losses?)
- Portfolio Greek ranges (what's optimal)

### What to Tune (Based on Results):
- Expert weights (60/40 Greeks/Claude or different?)
- Risk limits (is 0.05 gamma too tight/loose?)
- Exit thresholds (70% profit or 80%?)
- Score minimums (60 or 65 for entry?)

**DON'T tune:** Individual expert thresholds (respect their domain expertise)

---

*Remember: Discipline beats prediction. Follow the system, respect the limits, trust the experts.*

