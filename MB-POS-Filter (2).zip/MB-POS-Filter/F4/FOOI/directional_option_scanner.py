"""
Scanner to classify F&O symbols into directional and non-directional option trades.

It combines enriched future/oi statistics from the trend results export with the
option surface snapshot to derive actionable signals for directional calls/puts,
short straddles, and long straddles using rule-based criteria.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import pandas as pd


# ---------------------------- Utility helpers ---------------------------- #

def _coerce_float(value: pd.Series, default: float = 0.0) -> pd.Series:
    """Convert a pandas Series to float, filling invalid entries."""
    return pd.to_numeric(value, errors="coerce").fillna(default)


def _safe_lower(value: Optional[str]) -> str:
    return (value or "").strip().lower()


def _normalize_symbol(series: pd.Series) -> pd.Series:
    return series.astype(str).str.strip().str.upper()


def _json_ready(mapping: Dict[str, Any]) -> Dict[str, Any]:
    """Convert numpy/pandas scalar values into native Python types for JSON serialization."""
    ready: Dict[str, Any] = {}
    for key, value in mapping.items():
        if value is None or isinstance(value, (bool, int, float, str)):
            ready[key] = value
        elif hasattr(value, "item"):
            ready[key] = value.item()
        else:
            ready[key] = value
    return ready


# Human-readable labels for short straddle condition diagnostics.
SHORT_STRADDLE_CONDITION_LABELS = {
    "iv_rich": "IV percentile meets richness threshold",
    "neutral_price": "Price action statistically neutral",
    "neutral_oi": "Open interest positioning neutral",
    "balanced_pcr": "PCR within acceptable balance band",
    "writer_balance": "Writers balanced across calls & puts",
    "vol_compression": "Forward volatility <= current (2% buffer)",
    "tame_intraday": "Average intraday range <= 3%",
    "stable_oi": "Today's OI vs daily avg within tolerance",
    "sufficient_history": "Sufficient analysis history",
}


# ---------------------------- Criteria rules ----------------------------- #

def _directional_bearish(row: pd.Series) -> Optional[str]:
    """
    Identify strong short build-up suited for buying protective puts.

    Triggers when:
      - Price drops materially with rising open interest;
      - Call writers dominate (high concentration, low PCR);
      - Price remains close to recent lows, signaling fragile structure.
    """
    price_drop = row["current_price_change_percent"] <= -0.75
    oi_rise = row["current_oi_change_percent"] >= 0.75
    call_dominance = row["writer_call_oi_concentration_pct"] >= 25
    low_pcr = row["writer_pcr_oi"] > 0 and row["writer_pcr_oi"] <= 0.70
    dominant_side_is_call = "call" in _safe_lower(row.get("writer_dominant_side"))
    close_to_low = 0 < row["current_fut_latest_close_vs_series_low_pct"] <= 6

    if all([price_drop, oi_rise, call_dominance, low_pcr, dominant_side_is_call, close_to_low]):
        return (
            "Bearish Put Buy: price slide with rising OI and dominant call writers; "
            "structure vulnerable near series lows."
        )
    return None


def _directional_bullish(row: pd.Series) -> Optional[str]:
    """
    Identify long build-up suited for buying calls.

    Requirements mirror the bearish setup but for put writer dominance.
    """
    price_rise = row["current_price_change_percent"] >= 0.75
    oi_rise = row["current_oi_change_percent"] >= 0.75
    put_dominance = row["writer_put_oi_concentration_pct"] >= 25
    high_pcr = row["writer_pcr_oi"] >= 1.10
    dominant_side_is_put = "put" in _safe_lower(row.get("writer_dominant_side"))
    term_structure_supportive = row["term_structure_slope_percent"] >= 0

    if all([price_rise, oi_rise, put_dominance, high_pcr, dominant_side_is_put, term_structure_supportive]):
        return (
            "Bullish Call Buy: price + OI expansion with put-writer support and "
            "upward-sloping term structure."
        )
    return None


def _short_straddle_conditions(
    row: pd.Series,
) -> tuple[Dict[str, bool], Dict[str, float | bool | None]]:
    pcr = row["PCR"]
    iv_percentile = row["IVPercentile"]
    iv_is_finite = math.isfinite(iv_percentile) if isinstance(iv_percentile, (int, float)) else False
    base_tolerance = 0.22
    extra_tolerance = max(0.0, (iv_percentile - 50.0) * 0.004) if iv_is_finite else 0.0
    tolerance = base_tolerance + extra_tolerance
    pcr_check = math.isfinite(pcr) and (
        abs(pcr - 1.0) <= tolerance
        or 0.70 <= pcr <= 1.35
    )

    curr_price_z = row["current_price_zscore"]
    curr_oi_z = row["current_oi_zscore"]
    neutral_price = math.isfinite(curr_price_z) and abs(curr_price_z) <= 0.55
    neutral_oi = math.isfinite(curr_oi_z) and abs(curr_oi_z) <= 0.55

    curr_realized = row["current_realized_vol_annualized"]
    next_realized = row["next_realized_vol_annualized"]
    curr_range = row["current_avg_daily_range_pct"]
    next_range = row["next_avg_daily_range_pct"]

    ann_vol_signal = (
        math.isfinite(curr_realized)
        and math.isfinite(next_realized)
        and curr_realized > 0
        and next_realized <= curr_realized * 0.98
    )
    range_signal = (
        math.isfinite(curr_range)
        and math.isfinite(next_range)
        and curr_range > 0
        and next_range <= curr_range * 0.98
    )

    tame_intraday = math.isfinite(curr_range) and curr_range <= 3
    todays_vs_avg = row["todays_oi_vs_daily_avg_percent"]
    stable_oi = math.isfinite(todays_vs_avg) and abs(todays_vs_avg) <= 500

    call_conc = row["writer_call_oi_concentration_pct"]
    put_conc = row["writer_put_oi_concentration_pct"]
    call_strength = row["writer_call_writer_strength_percent"]
    put_strength = row["writer_put_writer_strength_percent"]
    writer_balance = (
        (
            call_conc >= 18
            and put_conc >= 15
            and call_strength >= 22
            and put_strength >= 20
        )
        or (
            (call_strength + put_strength) / 2 >= 30
            and (ann_vol_signal or range_signal)
        )
    )

    iv_rich = iv_is_finite and (
        iv_percentile >= 60
        or (iv_percentile >= 55 and (ann_vol_signal or range_signal))
    )

    checks: Dict[str, bool] = {
        "iv_rich": iv_rich,
        "neutral_price": neutral_price,
        "neutral_oi": neutral_oi,
        "balanced_pcr": pcr_check,
        "writer_balance": writer_balance,
        "vol_compression": ann_vol_signal or range_signal,
        "tame_intraday": tame_intraday,
        "stable_oi": stable_oi,
    }
    checks_meta: Dict[str, float | bool | None] = {
        "pcr_value": pcr if math.isfinite(pcr) else None,
        "pcr_tolerance": tolerance,
        "iv_percentile": iv_percentile if iv_is_finite else None,
        "ann_vol_signal": ann_vol_signal,
        "range_signal": range_signal,
        "vol_compression": ann_vol_signal or range_signal,
        "ann_vol_ratio": (next_realized / curr_realized) if ann_vol_signal and curr_realized else None,
        "range_ratio": (next_range / curr_range) if range_signal and curr_range else None,
    }
    return checks, checks_meta


def _non_directional_short(row: pd.Series) -> tuple[Optional[str], Dict[str, bool], Dict[str, float | bool | None]]:
    """
    Flag candidates for short straddle/strangle when implied volatility is rich but
    underlying realized/forward volatility is muted and positioning is balanced.
    """
    checks, meta = _short_straddle_conditions(row)
    sufficient_history = row["analysis_trading_days"] >= 5
    checks_with_history = checks.copy()
    checks_with_history["sufficient_history"] = sufficient_history

    if all(checks_with_history.values()):
        return (
            "Short Straddle: price/oi neutral, IV rich, realized/forward vol muted, "
            "writers active on both sides with contained participation spikes.",
            checks_with_history,
            meta,
        )
    return None, checks_with_history, meta


def _non_directional_long(row: pd.Series) -> Optional[str]:
    """
    Flag candidates for long straddle/strangle when directional conviction is low
    but volatility expansion is expected.
    """
    neutral_price = abs(row["current_price_zscore"]) <= 0.5
    neutral_oi = abs(row["current_oi_zscore"]) <= 0.5
    iv_discount = row["IVPercentile"] <= 30
    balanced_flows = 0.85 <= row["PCR"] <= 1.15
    vol_pickup = (
        row["next_realized_vol_annualized"] >= row["current_realized_vol_annualized"] * 1.05
    ) and (
        row["next_avg_daily_range_pct"] >= row["current_avg_daily_range_pct"]
    )
    sufficient_history = row["analysis_trading_days"] >= 5

    if all([neutral_price, neutral_oi, iv_discount, balanced_flows, vol_pickup, sufficient_history]):
        return (
            "Long Straddle: price/oi neutral, IV discounted, flows balanced, "
            "forward volatility projected higher."
        )
    return None


# ---------------------------- Core scanning ------------------------------ #

def evaluate_signals(merged_df: pd.DataFrame) -> pd.DataFrame:
    """Apply rule-set to each row and return actionable recommendations."""
    decisions: List[str] = []
    rationales: List[str] = []
    short_pass_flags: List[bool] = []
    short_failed_checks: List[str] = []
    short_checks_serialized: List[str] = []
    short_meta_serialized: List[str] = []
    short_met_labels: List[str] = []

    for _, row in merged_df.iterrows():
        rationale = _directional_bearish(row)
        decision = "Bearish Put Buy" if rationale else None

        if not decision:
            rationale = _directional_bullish(row)
            decision = "Bullish Call Buy" if rationale else None

        if not decision:
            short_rationale, short_checks, short_meta = _non_directional_short(row)
            rationale = short_rationale
            if rationale:
                decision = "Short Straddle"
            failed = [name for name, passed in short_checks.items() if not passed]
            short_pass_flags.append(bool(short_rationale))
            short_failed_checks.append(", ".join(failed) if failed else "")
            short_checks_serialized.append(json.dumps(_json_ready(short_checks), sort_keys=True))
            short_meta_serialized.append(json.dumps(_json_ready(short_meta), sort_keys=True))
            met_labels = [
                SHORT_STRADDLE_CONDITION_LABELS.get(cond, cond).strip()
                for cond, passed in short_checks.items()
                if passed
            ]
            short_met_labels.append("; ".join(met_labels))
        else:
            short_pass_flags.append(None)
            short_failed_checks.append("not_evaluated")
            short_checks_serialized.append(json.dumps({}, sort_keys=True))
            short_meta_serialized.append(json.dumps({}, sort_keys=True))
            short_met_labels.append("")

        if not decision:
            rationale = _non_directional_long(row)
            decision = "Long Straddle" if rationale else None

        decisions.append(decision or "No Trade")
        rationales.append(rationale or "No qualifying setup based on current thresholds.")

    output = merged_df[["symbol", "timestamp", "detected_market_regime", "combined_sentiment", "confidence_percent"]].copy()
    output["trade_signal"] = decisions
    output["rationale"] = rationales
    output["atm_iv_percentile"] = merged_df["IVPercentile"]
    output["pcr"] = merged_df["PCR"]
    output["term_structure_slope_percent"] = merged_df["term_structure_slope_percent"]
    output["writer_dominant_side"] = merged_df["writer_dominant_side"]
    output["current_price_change_percent"] = merged_df["current_price_change_percent"]
    output["current_oi_change_percent"] = merged_df["current_oi_change_percent"]
    output["writer_pcr_oi"] = merged_df["writer_pcr_oi"]
    output["short_straddle_pass"] = short_pass_flags
    output["short_straddle_failed_checks"] = short_failed_checks
    output["short_straddle_checks"] = short_checks_serialized
    output["short_straddle_meta"] = short_meta_serialized
    output["short_straddle_met_conditions"] = short_met_labels
    return output


def load_inputs(trend_results_path: Path, options_snapshot_path: Path) -> pd.DataFrame:
    """Load and merge the two CSV exports."""
    trend_df = pd.read_csv(trend_results_path)
    options_df = pd.read_csv(options_snapshot_path)

    if "symbol" not in trend_df or "Instrument" not in options_df:
        raise ValueError("Missing required columns: 'symbol' in trend data or 'Instrument' in options snapshot.")

    trend_df["symbol"] = _normalize_symbol(trend_df["symbol"])
    options_df["Instrument"] = _normalize_symbol(options_df["Instrument"])

    numeric_columns: Iterable[str] = [
        "current_price_change_percent",
        "current_oi_change_percent",
        "current_price_zscore",
        "current_oi_zscore",
        "current_fut_latest_close_vs_series_low_pct",
        "writer_call_oi_concentration_pct",
        "writer_put_oi_concentration_pct",
        "writer_pcr_oi",
        "writer_call_writer_strength_percent",
        "writer_put_writer_strength_percent",
        "term_structure_slope_percent",
        "current_realized_vol_annualized",
        "next_realized_vol_annualized",
        "current_avg_daily_range_pct",
        "next_avg_daily_range_pct",
        "analysis_trading_days",
        "todays_oi_vs_daily_avg_percent",
    ]
    for column in numeric_columns:
        if column in trend_df:
            trend_df[column] = _coerce_float(trend_df[column])

    options_numeric = ["IVPercentile", "PCR"]
    for column in options_numeric:
        if column in options_df:
            options_df[column] = _coerce_float(options_df[column])

    merged = trend_df.merge(
        options_df,
        left_on="symbol",
        right_on="Instrument",
        how="left",
        suffixes=("", "_options"),
    )

    if merged["Instrument"].isna().any():
        missing = merged.loc[merged["Instrument"].isna(), "symbol"].unique()
        if len(missing):
            print(
                f"WARNING: Missing options snapshot data for symbols: {', '.join(missing)}",
                file=sys.stderr,
            )

    return merged


def parse_args(argv: Optional[Iterable[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Directional vs non-directional option scanner")
    parser.add_argument(
        "--trend-csv",
        required=True,
        type=Path,
        help="Path to trend_results_adaptive_v10 CSV export.",
    )
    parser.add_argument(
        "--options-csv",
        required=True,
        type=Path,
        help="Path to options_screener CSV export.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Optional path to write the scanner results as CSV.",
    )
    return parser.parse_args(argv)


def main(argv: Optional[Iterable[str]] = None) -> int:
    args = parse_args(argv)
    if not args.trend_csv.exists():
        print(f"ERROR: Trend CSV not found at {args.trend_csv}", file=sys.stderr)
        return 1
    if not args.options_csv.exists():
        print(f"ERROR: Options CSV not found at {args.options_csv}", file=sys.stderr)
        return 1

    merged_df = load_inputs(args.trend_csv, args.options_csv)
    results = evaluate_signals(merged_df)

    if args.output:
        results.to_csv(args.output, index=False)
        print(f"Wrote {len(results)} rows to {args.output}")
    else:
        pd.set_option("display.max_columns", None)
        print(results.to_string(index=False))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())


