import os
import time
from datetime import datetime, timedelta, date
from pathlib import Path
from typing import List, Dict, Optional

import numpy as np
import pandas as pd

from OITrendScanner import TrendScanner, logger  # Reuse existing fetch utilities

MASTER_DATA_PATH = Path("data/daily_trend_master.csv")
DEFAULT_HISTORY_DAYS = 100   # initial seed window if no master file exists yet (≈70+ trading days)
API_DELAY_SECONDS = 0.5      # delay between API calls to respect rate limits (500ms)


class DailyMasterStore:
    """Handles persistence of raw day-level snapshots."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> pd.DataFrame:
        if not self.path.exists():
            return pd.DataFrame()
        try:
            df = pd.read_csv(self.path, parse_dates=['date'])
            df['date'] = df['date'].dt.date
            return df
        except Exception as exc:
            logger.error(f"Failed to read master daily file {self.path}: {exc}")
            return pd.DataFrame()

    def append_rows(self, rows: List[Dict]):
        if not rows:
            logger.info("No new daily rows to append.")
            return

        new_df = pd.DataFrame(rows)
        new_df['date'] = pd.to_datetime(new_df['date']).dt.date

        if self.path.exists():
            existing_df = self.load()
            combined = pd.concat([existing_df, new_df], ignore_index=True)
            combined.drop_duplicates(subset=['symbol', 'contract_type', 'date'], keep='last', inplace=True)
        else:
            combined = new_df.drop_duplicates(subset=['symbol', 'contract_type', 'date'], keep='last')

        combined.sort_values(['symbol', 'contract_type', 'date'], inplace=True)
        combined.to_csv(self.path, index=False)
        logger.info(f"Master daily file updated -> {self.path} ({len(combined)} rows).")


class OTTrendScannerV2:
    """
    Captures raw per-day futures/oi fields to build a longitudinal master sheet.
    First run seeds DEFAULT_HISTORY_DAYS; subsequent runs append only new sessions.
    """

    def __init__(self, api_key: str, access_token: str,
                 symbols_csv: str = "data/FNOStock.csv",
                 master_path: Path = MASTER_DATA_PATH):
        self.base_scanner = TrendScanner(api_key=api_key,
                                         access_token=access_token,
                                         input_csv=symbols_csv,
                                         max_workers=1)  # sequential fetching for clarity
        self.store = DailyMasterStore(master_path)

    def _is_market_open(self) -> bool:
        """Check if market is currently open (9:15 AM - 3:30 PM IST)"""
        now = datetime.now(self.base_scanner.ist_timezone)
        current_time = now.time()
        
        market_open = datetime.strptime('09:15', '%H:%M').time()
        market_close = datetime.strptime('15:30', '%H:%M').time()
        
        is_open = market_open <= current_time <= market_close
        if is_open:
            logger.info(f"Market is currently OPEN (current time: {current_time.strftime('%H:%M:%S')} IST)")
        else:
            logger.info(f"Market is CLOSED (current time: {current_time.strftime('%H:%M:%S')} IST)")
        return is_open

    def _determine_fetch_window(self, existing_df: pd.DataFrame) -> (date, date):
        today = datetime.now(self.base_scanner.ist_timezone).date()
        is_market_open = self._is_market_open()
        
        # If market is open, don't fetch today (will get intraday data, not EOD settlement)
        # Instead, fetch up to yesterday or last available date
        if is_market_open:
            logger.warning("Market is OPEN - skipping today's data to avoid intraday values. Will fetch EOD data after market close.")
            if existing_df.empty or 'date' not in existing_df.columns:
                # First run during market hours - fetch up to yesterday
                start = today - timedelta(days=DEFAULT_HISTORY_DAYS + 1)
                end = today - timedelta(days=1)
                logger.debug(f"First run during market hours: fetching from {start} to {end} (excluding today)")
                return start, end
            else:
                # Incremental update during market hours - fetch up to yesterday
                last_date = max(existing_df['date'])
                yesterday = today - timedelta(days=1)
                if last_date >= yesterday:
                    # Already have yesterday's data - nothing to fetch
                    logger.debug(f"Already have yesterday's data. Skipping today (market open).")
                    return yesterday, yesterday  # Return same date to skip (start > end will be handled)
                else:
                    # Fetch up to yesterday
                    start = last_date
                    end = yesterday
                    logger.debug(f"Incremental update during market hours: fetching from {start} to {end} (excluding today)")
                    return start, end
        
        # Market is closed - safe to fetch today (will get EOD data)
        if existing_df.empty or 'date' not in existing_df.columns:
            start = today - timedelta(days=DEFAULT_HISTORY_DAYS)
            logger.debug(f"First run: fetching from {start} to {today} (full history)")
            return start, today

        last_date = max(existing_df['date'])
        if last_date >= today:
            # Data exists for today, but we may need to re-fetch with calculations
            # Check if today's data has NaN calculations - if so, we need to re-fetch with previous day
            today_rows = existing_df[existing_df['date'] == today]
            if not today_rows.empty and 'price_return_pct' in today_rows.columns:
                has_nan_calc = today_rows['price_return_pct'].isna().any()
                if has_nan_calc:
                    logger.debug(f"Today's data has NaN calculations - will re-fetch with previous day for calculations")
                    # Fetch from yesterday to today to enable calculations
                    return today - timedelta(days=1), today
            logger.debug(f"Already up to date: last_date={last_date}, today={today}")
            return today, today
        # For incremental updates, fetch one extra day (yesterday) to enable pct_change/diff calculations
        # This ensures price_return_pct, oi_change, oi_change_pct are calculated correctly for today
        start = last_date  # Include last_date so we can calculate changes for new days
        logger.debug(f"Incremental update: last_date={last_date}, start={start}, end={today}")
        return start, today

    def _build_rows_for_contract(self, symbol: str, contract_label: str,
                                 contract_info: Optional[Dict],
                                 start_date: date, end_date: date) -> List[Dict]:
        if not contract_info:
            return []

        token = contract_info.get('instrument_token')
        expiry = contract_info.get('expiry')
        if token is None or expiry is None:
            return []

        df = self.base_scanner.get_historical_data(
            token,
            start_date,
            end_date,
            interval="day",
            cap_outliers_flag=True,
            contract_type="future"
        )
        time.sleep(API_DELAY_SECONDS)  # Respect API rate limits
        
        # FALLBACK: For the most recent date (end_date), ALWAYS try quote() API to get accurate current/latest data
        # This is especially important when historical_data() has delays, incorrect data, or missing recent dates
        # quote() API is more accurate for current/latest values (like simpleoi.py uses)
        # We use quote() for today or yesterday to ensure we get the most accurate EOD/latest values
        today = datetime.now(self.base_scanner.ist_timezone).date()
        use_quote_for_end_date = (end_date >= today - timedelta(days=1))  # For today or yesterday
        
        if use_quote_for_end_date:
            # Try quote() API to get accurate data for the most recent date
            # This ensures we get accurate EOD/latest values (like simpleoi.py)
            logger.debug(f"{symbol} {contract_label}: Attempting quote() API fallback for {end_date} (end_date >= today-1)")
            try:
                tradingsymbol = contract_info.get('tradingsymbol', '')
                quote_key = f"NFO:{tradingsymbol}" if tradingsymbol else None
                
                # Try multiple methods to get quote data (like simpleoi.py uses token directly)
                quote_data = None
                
                # Method 1: Try with tradingsymbol (NFO:SYMBOL format)
                if tradingsymbol:
                    quote_key = f"NFO:{tradingsymbol}"
                    logger.debug(f"{symbol} {contract_label}: Trying quote() API with key: {quote_key}")
                    quotes = self.base_scanner.kite.quote([quote_key])
                    quote_data = quotes.get(quote_key) if quotes else None
                
                # Method 2: Fallback to token directly (like simpleoi.py does)
                if not quote_data:
                    logger.debug(f"{symbol} {contract_label}: Trying quote() API with token: {token}")
                    quotes = self.base_scanner.kite.quote([token])
                    # Try both string and int key (simpleoi.py uses str(token))
                    quote_data = quotes.get(str(token)) if quotes else None
                    if not quote_data and quotes:
                        quote_data = quotes.get(token) if quotes else None
                
                if not quote_data:
                    logger.warning(f"{symbol} {contract_label}: Quote API returned no data. Available keys: {list(quotes.keys()) if quotes else 'None'}")
                
                if quote_data and 'last_price' in quote_data:
                    logger.debug(f"{symbol} {contract_label}: Got quote data - last_price={quote_data.get('last_price')}, oi={quote_data.get('oi')}")
                    # Create a row from quote data for end_date
                    quote_row = {
                        'date': pd.to_datetime(end_date),
                        'open': quote_data.get('ohlc', {}).get('open'),
                        'high': quote_data.get('ohlc', {}).get('high'),
                        'low': quote_data.get('ohlc', {}).get('low'),
                        'close': quote_data.get('ohlc', {}).get('close') or quote_data.get('last_price'),
                        'volume': quote_data.get('volume', 0),
                        'oi': quote_data.get('oi', 0),
                    }
                    
                    if not df.empty:
                        # ALWAYS replace end_date data with quote data (more accurate for recent dates)
                        # Check if end_date already exists in df - if so, replace it with quote data
                        df_dates = df['date'].dt.date.values
                        if end_date in df_dates:
                            # Replace existing row with quote data (more accurate)
                            df = df[df['date'].dt.date != end_date]
                            quote_df = pd.DataFrame([quote_row])
                            df = pd.concat([df, quote_df], ignore_index=True)
                            logger.info(f"{symbol} {contract_label}: Replaced {end_date} data with quote() API - Close={quote_row['close']}, OI={quote_row['oi']:,.0f} (was using historical_data)")
                        else:
                            # Append quote data
                            quote_df = pd.DataFrame([quote_row])
                            df = pd.concat([df, quote_df], ignore_index=True)
                            logger.info(f"{symbol} {contract_label}: Added {end_date} data from quote() API - Close={quote_row['close']}, OI={quote_row['oi']:,.0f}")
                    else:
                        # Only quote data available
                        df = pd.DataFrame([quote_row])
                        logger.info(f"{symbol} {contract_label}: Using quote() API for {end_date} (historical_data() had no data) - Close={quote_row['close']}, OI={quote_row['oi']:,.0f}")
                    time.sleep(API_DELAY_SECONDS)  # Respect rate limits
            except Exception as e:
                logger.debug(f"{symbol} {contract_label}: Quote API fallback failed: {e}")
        
        if df.empty:
            logger.debug(f"{symbol} {contract_label}: No data returned from API for {start_date} to {end_date}")
            return []

        df = df[df['date'].dt.weekday < 5].copy()
        df.sort_values('date', inplace=True)
        
        logger.debug(f"{symbol} {contract_label}: Fetched {len(df)} trading days from {df['date'].min().date() if not df.empty else 'N/A'} to {df['date'].max().date() if not df.empty else 'N/A'}")

        df['close'] = pd.to_numeric(df['close'], errors='coerce')
        df['open'] = pd.to_numeric(df['open'], errors='coerce')
        df['high'] = pd.to_numeric(df['high'], errors='coerce')
        df['low'] = pd.to_numeric(df['low'], errors='coerce')
        df['volume'] = pd.to_numeric(df['volume'], errors='coerce')
        df['oi'] = pd.to_numeric(df.get('oi'), errors='coerce')

        df['price_return_pct'] = df['close'].pct_change() * 100
        df['oi_change'] = df['oi'].diff()
        df['oi_change_pct'] = df['oi'].pct_change() * 100
        df['daily_range_pct'] = ((df['high'] - df['low']) / df['close'].replace(0, pd.NA)) * 100
        
        # Debug: Check if calculations worked (should have non-NaN values for rows after first)
        if len(df) > 1:
            calc_check = df.iloc[-1]  # Last row (should be today)
            has_price_return = not pd.isna(calc_check.get('price_return_pct'))
            has_oi_change = not pd.isna(calc_check.get('oi_change'))
            has_oi_change_pct = not pd.isna(calc_check.get('oi_change_pct'))
            if not (has_price_return and has_oi_change and has_oi_change_pct):
                logger.warning(f"{symbol} {contract_label}: Calculations may have failed - price_return_pct={has_price_return}, "
                             f"oi_change={has_oi_change}, oi_change_pct={has_oi_change_pct} for date {calc_check.get('date')}")
            else:
                logger.debug(f"{symbol} {contract_label}: Calculations OK - price_return_pct={calc_check.get('price_return_pct'):.4f}%, "
                           f"oi_change={calc_check.get('oi_change'):.0f}, oi_change_pct={calc_check.get('oi_change_pct'):.4f}%")
        elif len(df) == 1:
            logger.warning(f"{symbol} {contract_label}: Only 1 row fetched - calculations will be NaN (expected for first day)")

        rows = []
        for _, row in df.iterrows():
            rows.append({
                'date': row['date'].date(),
                'symbol': symbol,
                'contract_type': contract_label,
                'expiry': pd.to_datetime(expiry).date(),
                'open': row['open'],
                'high': row['high'],
                'low': row['low'],
                'close': row['close'],
                'volume': row['volume'],
                'oi': row['oi'],
                'price_return_pct': row['price_return_pct'],
                'oi_change': row['oi_change'],
                'oi_change_pct': row['oi_change_pct'],
                'daily_range_pct': row['daily_range_pct'],
                'instrument_token': token
            })
        return rows

    def _build_rows_for_spot(self, symbol: str, start_date: date, end_date: date) -> List[Dict]:
        try:
            # NSE instrument cache is already populated by TrendScanner, no API call needed
            nse_row = self.base_scanner.nse_instrument_cache[
                self.base_scanner.nse_instrument_cache['tradingsymbol'] == symbol.upper()
            ]
            if nse_row.empty:
                return []
            token = nse_row['instrument_token'].iloc[0]
        except Exception:
            return []

        df = self.base_scanner.get_historical_data(
            token,
            start_date,
            end_date,
            interval="day",
            cap_outliers_flag=True,
            contract_type="index"  # fetch without OI
        )
        time.sleep(API_DELAY_SECONDS)  # Respect API rate limits
        if df.empty:
            logger.debug(f"{symbol} spot: No data returned from API for {start_date} to {end_date}")
            return []

        df = df[df['date'].dt.weekday < 5].copy()
        df.sort_values('date', inplace=True)
        
        logger.debug(f"{symbol} spot: Fetched {len(df)} trading days from {df['date'].min().date() if not df.empty else 'N/A'} to {df['date'].max().date() if not df.empty else 'N/A'}")

        df['close'] = pd.to_numeric(df.get('close'), errors='coerce')
        df['open'] = pd.to_numeric(df.get('open'), errors='coerce')
        df['high'] = pd.to_numeric(df.get('high'), errors='coerce')
        df['low'] = pd.to_numeric(df.get('low'), errors='coerce')

        df['price_return_pct'] = df['close'].pct_change() * 100
        df['daily_range_pct'] = ((df['high'] - df['low']) / df['close'].replace(0, pd.NA)) * 100
        
        # Debug: Check if calculations worked (spot doesn't have OI, so only check price_return_pct)
        if len(df) > 1:
            calc_check = df.iloc[-1]  # Last row (should be today)
            has_price_return = not pd.isna(calc_check.get('price_return_pct'))
            if not has_price_return:
                logger.warning(f"{symbol} spot: Calculation may have failed - price_return_pct is NaN for date {calc_check.get('date')}")
            else:
                logger.debug(f"{symbol} spot: Calculation OK - price_return_pct={calc_check.get('price_return_pct'):.4f}%")
        elif len(df) == 1:
            logger.warning(f"{symbol} spot: Only 1 row fetched - price_return_pct will be NaN (expected for first day)")

        rows: List[Dict] = []
        for _, row in df.iterrows():
            rows.append({
                'date': row['date'].date(),
                'symbol': symbol,
                'contract_type': 'spot',
                'expiry': None,
                'open': row.get('open'),
                'high': row.get('high'),
                'low': row.get('low'),
                'close': row.get('close'),
                'volume': None,
                'oi': None,
                'price_return_pct': row.get('price_return_pct'),
                'oi_change': None,
                'oi_change_pct': None,
                'daily_range_pct': row.get('daily_range_pct'),
                'instrument_token': token
            })
        return rows

    def _get_options_oi_snapshot(self, symbol: str, target_date: date) -> Dict:
        """
        Fetch options OI snapshot for a given symbol and date.
        Returns aggregated options OI metrics: total call OI, put OI, PCR, etc.
        
        Note: Options OI is live data, so we fetch current snapshot and associate it with target_date.
        For historical dates, this will only work if we're fetching on that date.
        """
        try:
            # Get current month expiry date (approximate - use futures chain to get expiry)
            futures = self.base_scanner.get_futures_chain(symbol)
            current_fut = futures.get('current')
            
            if not current_fut or 'expiry' not in current_fut:
                return {
                    'options_call_oi': None,
                    'options_put_oi': None,
                    'options_total_oi': None,
                    'options_pcr': None,
                    'options_call_oi_change_pct': None,
                    'options_put_oi_change_pct': None,
                }
            
            # Use current month futures expiry as proxy for options expiry
            current_expiry = pd.to_datetime(current_fut['expiry']).date()
            
            # Fetch options chain for current month expiry
            option_chain = self.base_scanner.get_option_chain(symbol, [current_expiry])
            time.sleep(API_DELAY_SECONDS)  # Respect API rate limits
            
            if option_chain.empty or 'oi' not in option_chain.columns:
                return {
                    'options_call_oi': None,
                    'options_put_oi': None,
                    'options_total_oi': None,
                    'options_pcr': None,
                    'options_call_oi_change_pct': None,
                    'options_put_oi_change_pct': None,
                }
            
            # Separate calls and puts
            calls = option_chain[option_chain['instrument_type'] == 'CE'].copy()
            puts = option_chain[option_chain['instrument_type'] == 'PE'].copy()
            
            # Aggregate OI
            total_call_oi = float(calls['oi'].sum(skipna=True)) if not calls.empty else 0.0
            total_put_oi = float(puts['oi'].sum(skipna=True)) if not puts.empty else 0.0
            total_oi = total_call_oi + total_put_oi
            
            # Calculate PCR (Put-Call Ratio)
            pcr = (total_put_oi / total_call_oi) if total_call_oi > 0 else (float('inf') if total_put_oi > 0 else 1.0)
            
            return {
                'options_call_oi': total_call_oi if total_call_oi > 0 else None,
                'options_put_oi': total_put_oi if total_put_oi > 0 else None,
                'options_total_oi': total_oi if total_oi > 0 else None,
                'options_pcr': float(pcr) if not np.isinf(pcr) else None,
                'options_call_oi_change_pct': None,  # Will be calculated from historical data
                'options_put_oi_change_pct': None,  # Will be calculated from historical data
            }
        except Exception as e:
            logger.warning(f"Error fetching options OI for {symbol} on {target_date}: {e}")
            return {
                'options_call_oi': None,
                'options_put_oi': None,
                'options_total_oi': None,
                'options_pcr': None,
                'options_call_oi_change_pct': None,
                'options_put_oi_change_pct': None,
            }

    def capture_daily_snapshots(self):
        existing = self.store.load()
        start_date, end_date = self._determine_fetch_window(existing)
        if start_date > end_date:
            logger.info("Master sheet already up to date. Nothing to fetch.")
            return

        # For incremental updates, we need to fetch one extra day (previous day) to enable
        # pct_change() and diff() calculations. But we only want to store new days.
        # Determine the last existing date to know what's "new"
        last_existing_date = max(existing['date']) if not existing.empty and 'date' in existing.columns else None
        
        # Fetch one day before start_date to enable calculations (if doing incremental update)
        # BUT: If start_date is already yesterday (today - 1), don't subtract again
        # This happens when _determine_fetch_window already adjusted for NaN calculations
        today = datetime.now(self.base_scanner.ist_timezone).date()
        fetch_start = start_date
        if last_existing_date is not None:
            if start_date < end_date:
                # Incremental update: Check if start_date is already yesterday
                # If start_date == today - 1, it's already set correctly by _determine_fetch_window
                # Only subtract if start_date is further back (e.g., last_date from master file)
                if start_date < today - timedelta(days=1):
                    # start_date is older than yesterday, subtract one more day
                    fetch_start = start_date - timedelta(days=1)
                    logger.debug(f"Fetching extra day for calculations: fetch_start={fetch_start} (one day before start_date={start_date})")
                else:
                    # start_date is already yesterday (today - 1), use it as-is
                    logger.debug(f"Using start_date as fetch_start: {fetch_start} (already includes previous day for calculations)")
            elif start_date == end_date and start_date == today:
                # Re-fetching today: fetch one day before to enable calculations
                fetch_start = start_date - timedelta(days=1)
                logger.debug(f"Re-fetching today with calculations: fetch_start={fetch_start} (one day before start_date={start_date})")
        
        # Determine if we're re-fetching today due to NaN calculations
        is_refetch_today_nan = (start_date == today - timedelta(days=1) and 
                               end_date == today and 
                               last_existing_date is not None and 
                               last_existing_date >= today)
        store_from_date = today if is_refetch_today_nan else start_date
        logger.info(f"Building daily snapshots from {fetch_start} to {end_date} (will store new days from {store_from_date}).")
        if last_existing_date:
            logger.debug(f"Last existing date in master: {last_existing_date}, will filter to keep only dates > {last_existing_date}")
        
        # Ensure NSE instrument cache is populated once at startup (cached, no repeated API calls)
        # This is handled by TrendScanner initialization, but we access it to ensure it's loaded
        _ = self.base_scanner.nse_instrument_cache
        
        symbols = self.base_scanner.read_symbols()
        all_rows: List[Dict] = []

        for symbol in symbols:
            symbol = symbol.strip().upper()
            futures = self.base_scanner.get_futures_chain(symbol)
            time.sleep(API_DELAY_SECONDS)  # Respect API rate limits after futures chain lookup
            
            # Fetch options OI snapshot for today (or most recent date in range)
            # Note: Options OI is live data, so we fetch current snapshot
            today = datetime.now(self.base_scanner.ist_timezone).date()
            target_date = min(today, end_date) if end_date <= today else end_date
            options_snapshot = self._get_options_oi_snapshot(symbol, target_date)
            
            # Calculate options OI change from previous day if available
            if not existing.empty and 'options_call_oi' in existing.columns:
                prev_row = existing[
                    (existing['symbol'] == symbol) & 
                    (existing['date'] < target_date) &
                    (existing['options_call_oi'].notna())
                ].sort_values('date', ascending=False)
                
                if not prev_row.empty:
                    prev_call_oi = prev_row.iloc[0].get('options_call_oi')
                    prev_put_oi = prev_row.iloc[0].get('options_put_oi')
                    curr_call_oi = options_snapshot.get('options_call_oi')
                    curr_put_oi = options_snapshot.get('options_put_oi')
                    
                    if prev_call_oi and curr_call_oi and prev_call_oi > 0:
                        options_snapshot['options_call_oi_change_pct'] = ((curr_call_oi - prev_call_oi) / prev_call_oi) * 100.0
                    if prev_put_oi and curr_put_oi and prev_put_oi > 0:
                        options_snapshot['options_put_oi_change_pct'] = ((curr_put_oi - prev_put_oi) / prev_put_oi) * 100.0
            
            # Fetch with one extra day (previous day) to enable pct_change/diff calculations
            # But we'll filter to only keep new days when appending
            current_rows = self._build_rows_for_contract(symbol, "current",
                                                         futures.get('current'),
                                                         fetch_start, end_date)
            next_rows = self._build_rows_for_contract(symbol, "next",
                                                      futures.get('next'),
                                                      fetch_start, end_date)
            spot_rows = self._build_rows_for_spot(symbol, fetch_start, end_date)
            
            # Filter to only keep new days (dates > last_existing_date) to avoid re-storing existing data
            # EXCEPT: If we're re-fetching today because it has NaN calculations, allow re-storing today
            # This ensures we only append new days, but calculations work correctly because
            # we fetched one extra day (previous day) to enable pct_change/diff calculations
            all_symbol_rows = current_rows + next_rows + spot_rows
            rows_before_filter = len(all_symbol_rows)
            
            # Check if we're re-fetching today due to NaN calculations
            # This happens when start_date is yesterday (today - 1) and end_date is today
            # AND last_existing_date is today (data exists but has NaN)
            is_refetch_today = (start_date == today - timedelta(days=1) and 
                              end_date == today and 
                              last_existing_date is not None and 
                              last_existing_date >= today)
            
            if last_existing_date is not None:
                if is_refetch_today:
                    # Re-fetching today: keep today's rows (will overwrite existing NaN data)
                    all_symbol_rows = [row for row in all_symbol_rows if row.get('date') == today]
                    rows_after_filter = len(all_symbol_rows)
                    logger.debug(f"{symbol}: Re-fetching today - keeping {rows_after_filter} rows for {today} (will overwrite existing NaN data)")
                else:
                    # Only keep rows for dates after the last existing date (new days only)
                    all_symbol_rows = [row for row in all_symbol_rows if row.get('date') > last_existing_date]
                    rows_after_filter = len(all_symbol_rows)
                    if rows_before_filter > rows_after_filter:
                        logger.debug(f"{symbol}: Filtered {rows_before_filter} rows to {rows_after_filter} new rows (removed dates <= {last_existing_date})")
            else:
                # First run: keep all rows
                all_symbol_rows = [row for row in all_symbol_rows if row.get('date') >= start_date]
                logger.debug(f"{symbol}: First run - keeping {len(all_symbol_rows)} rows from {start_date} onwards")
            
            # Debug: Verify calculations are present for new rows
            if all_symbol_rows:
                sample_row = all_symbol_rows[0]
                sample_date = sample_row.get('date')
                has_calc = not pd.isna(sample_row.get('price_return_pct'))
                if not has_calc and sample_date > last_existing_date if last_existing_date else True:
                    logger.warning(f"{symbol}: New row for {sample_date} has NaN price_return_pct - calculation may have failed")
            
            # Add options OI to rows
            # Note: Options OI is live data - we can only fetch current snapshot
            # We store it for today's date, and over time (running daily) we'll build historical data
            for row in all_symbol_rows:
                row_date = row.get('date')
                # Add options data if this row's date matches target_date (today or most recent date in range)
                # This ensures we store options OI for the date we're processing
                if row_date == target_date:
                    row.update(options_snapshot)
                else:
                    # For other dates: check if we have historical options OI data in master file
                    # (This will be populated as we run the scanner daily over time)
                    if not existing.empty and 'options_call_oi' in existing.columns:
                        hist_row = existing[
                            (existing['symbol'] == symbol) &
                            (existing['date'] == row_date) &
                            (existing['options_call_oi'].notna())
                        ]
                        if not hist_row.empty:
                            # Use historical options OI data from master file
                            hist_data = hist_row.iloc[0]
                            row.update({
                                'options_call_oi': hist_data.get('options_call_oi'),
                                'options_put_oi': hist_data.get('options_put_oi'),
                                'options_total_oi': hist_data.get('options_total_oi'),
                                'options_pcr': hist_data.get('options_pcr'),
                                'options_call_oi_change_pct': None,  # Will be calculated in pattern engine
                                'options_put_oi_change_pct': None,  # Will be calculated in pattern engine
                            })
                        else:
                            # No historical data available yet (will populate as we run daily)
                            row.update({
                                'options_call_oi': None,
                                'options_put_oi': None,
                                'options_total_oi': None,
                                'options_pcr': None,
                                'options_call_oi_change_pct': None,
                                'options_put_oi_change_pct': None,
                            })
                    else:
                        # No historical data structure yet
                        row.update({
                            'options_call_oi': None,
                            'options_put_oi': None,
                            'options_total_oi': None,
                            'options_pcr': None,
                            'options_call_oi_change_pct': None,
                            'options_put_oi_change_pct': None,
                        })
            
            all_rows.extend(all_symbol_rows)
            pcr_val = options_snapshot.get('options_pcr')
            pcr_str = f"{pcr_val:.2f}" if pcr_val is not None else "N/A"
            call_chg = options_snapshot.get('options_call_oi_change_pct')
            put_chg = options_snapshot.get('options_put_oi_change_pct')
            call_chg_str = f"{call_chg:+.2f}%" if call_chg is not None else "N/A"
            put_chg_str = f"{put_chg:+.2f}%" if put_chg is not None else "N/A"
            logger.info(f"{symbol}: appended {len(all_symbol_rows)} new daily rows (fetched {len(current_rows) + len(next_rows) + len(spot_rows)} total). "
                       f"Options OI: Call={options_snapshot.get('options_call_oi', 'N/A')} ({call_chg_str}), "
                       f"Put={options_snapshot.get('options_put_oi', 'N/A')} ({put_chg_str}), "
                       f"PCR={pcr_str}")

        # Summary log
        if all_rows:
            dates_in_new_rows = set(row.get('date') for row in all_rows)
            calc_success_count = sum(1 for row in all_rows if not pd.isna(row.get('price_return_pct')))
            calc_fail_count = len(all_rows) - calc_success_count
            logger.info(f"Summary: Appending {len(all_rows)} new rows for dates {min(dates_in_new_rows)} to {max(dates_in_new_rows)}. "
                       f"Calculations: {calc_success_count} successful, {calc_fail_count} failed (NaN)")
            if calc_fail_count > 0:
                logger.warning(f"WARNING: {calc_fail_count} rows have NaN calculations - check if fetch window includes previous day")
        else:
            logger.info("No new rows to append (all data already exists)")

        self.store.append_rows(all_rows)


def main():
    api_key = "3bi2yh8g830vq3y6"
    access_token = "xsiAN33KkQSJJozp8wA5srbD4yRg32iV"

    if "YOUR_API_KEY" in api_key or "YOUR_ACCESS_TOKEN" in access_token:
        print("Please set KITE_API_KEY and KITE_ACCESS_TOKEN env vars for OTTrendScannerV2.")
        return

    scanner = OTTrendScannerV2(api_key=api_key, access_token=access_token)
    scanner.capture_daily_snapshots()


if __name__ == "__main__":
    main()

