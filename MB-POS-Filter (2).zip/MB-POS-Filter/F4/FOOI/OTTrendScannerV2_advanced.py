"""
OTTrendScannerV2 Advanced - Strike-Specific OI Tracking
-------------------------------------------------------

Enhanced version of OTTrendScannerV2 that adds strike-specific options OI tracking:
  • OTM/ATM/ITM OI classification for calls and puts
  • Detailed strike-level OI data for advanced pattern detection
  • Compatible with pro_desk_pattern_engine_advanced.py

Reuses base OTTrendScannerV2 functionality and adds:
  - Strike classification (OTM/ATM/ITM based on current price)
  - Strike-specific OI aggregation
  - Enhanced master file with 6 new columns (otm_call_oi, atm_call_oi, itm_call_oi, otm_put_oi, atm_put_oi, itm_put_oi)

Key Features:
  • All features from base scanner (futures, spot, aggregate options OI)
  • Strike-specific OI tracking for advanced patterns
  • Can run alongside base scanner (separate master file or same file)
  • Backward compatible (adds new columns, doesn't break existing)
"""

import os
import time
from datetime import datetime, timedelta, date
from pathlib import Path
from typing import List, Dict, Optional

import numpy as np
import pandas as pd

# Import base scanner
from OTTrendScannerV2 import (
    DailyMasterStore,
    OTTrendScannerV2 as BaseOTTrendScannerV2,
    MASTER_DATA_PATH,
    DEFAULT_HISTORY_DAYS,
    API_DELAY_SECONDS,
    logger,
)

# Advanced scanner uses separate master file by default
MASTER_DATA_PATH_ADVANCED = Path("data/daily_trend_master_advanced.csv")

# Strike classification thresholds (same as advanced pattern engine)
OTM_THRESHOLD_PCT = 0.02  # 2% OTM threshold
ATM_THRESHOLD_PCT = 0.01  # 1% ATM threshold (within 1% of current price)
ITM_THRESHOLD_PCT = 0.02  # 2% ITM threshold


def _classify_strike_oi(option_chain: pd.DataFrame, current_price: float) -> Dict[str, float]:
    """
    Classify options OI by strike level (OTM/ATM/ITM).
    
    Args:
        option_chain: DataFrame with columns: 'strike' (or 'strike_price'), 'oi', 'instrument_type' (CE/PE)
        current_price: Current spot/futures price
    
    Returns:
        Dict with: otm_call_oi, atm_call_oi, itm_call_oi, otm_put_oi, atm_put_oi, itm_put_oi
    """
    if option_chain.empty:
        return {
            'otm_call_oi': 0.0,
            'atm_call_oi': 0.0,
            'itm_call_oi': 0.0,
            'otm_put_oi': 0.0,
            'atm_put_oi': 0.0,
            'itm_put_oi': 0.0,
        }
    
    # Check for strike column (could be 'strike', 'strike_price', or need to parse from tradingsymbol)
    strike_col = None
    for col in ['strike', 'strike_price']:
        if col in option_chain.columns:
            strike_col = col
            break
    
    # If no strike column, try to extract from tradingsymbol (format: SYMBOLDDMMMYYSTRIKEPE/CE)
    if strike_col is None and 'tradingsymbol' in option_chain.columns:
        def extract_strike(ts):
            """Extract strike from tradingsymbol (e.g., 'NIFTY25NOV24500CE' -> 24500)"""
            try:
                # Remove symbol prefix and expiry, then extract numeric strike before CE/PE
                # Format: SYMBOL + DDMMMYY + STRIKE + CE/PE
                # Example: NIFTY25NOV24500CE -> 24500
                ts_str = str(ts).upper()
                # Find last occurrence of CE or PE
                for suffix in ['CE', 'PE']:
                    if ts_str.endswith(suffix):
                        # Extract number before CE/PE
                        remaining = ts_str[:-len(suffix)]
                        # Extract trailing digits (strike)
                        import re
                        match = re.search(r'(\d+)$', remaining)
                        if match:
                            return float(match.group(1))
                return None
            except:
                return None
        
        option_chain['strike'] = option_chain['tradingsymbol'].apply(extract_strike)
        strike_col = 'strike'
    
    if strike_col is None or strike_col not in option_chain.columns:
        logger.warning(f"No strike column found in option chain. Available columns: {option_chain.columns.tolist()}")
        return {
            'otm_call_oi': 0.0,
            'atm_call_oi': 0.0,
            'itm_call_oi': 0.0,
            'otm_put_oi': 0.0,
            'atm_put_oi': 0.0,
            'itm_put_oi': 0.0,
        }
    
    if 'oi' not in option_chain.columns:
        logger.warning(f"No 'oi' column found in option chain")
        return {
            'otm_call_oi': 0.0,
            'atm_call_oi': 0.0,
            'itm_call_oi': 0.0,
            'otm_put_oi': 0.0,
            'atm_put_oi': 0.0,
            'itm_put_oi': 0.0,
        }
    
    # Separate calls and puts
    calls = option_chain[option_chain['instrument_type'] == 'CE'].copy()
    puts = option_chain[option_chain['instrument_type'] == 'PE'].copy()
    
    # Classify calls
    if not calls.empty:
        calls_strike = pd.to_numeric(calls[strike_col], errors='coerce')
        calls_oi = pd.to_numeric(calls['oi'], errors='coerce').fillna(0)
        
        # OTM calls: strike > current_price * (1 + OTM_THRESHOLD_PCT)
        otm_calls_mask = calls_strike > current_price * (1 + OTM_THRESHOLD_PCT)
        otm_call_oi = float(calls_oi[otm_calls_mask].sum())
        
        # ATM calls: within ATM_THRESHOLD_PCT of current price
        atm_calls_mask = (
            (calls_strike >= current_price * (1 - ATM_THRESHOLD_PCT)) &
            (calls_strike <= current_price * (1 + ATM_THRESHOLD_PCT))
        )
        atm_call_oi = float(calls_oi[atm_calls_mask].sum())
        
        # ITM calls: strike < current_price * (1 - ITM_THRESHOLD_PCT)
        itm_calls_mask = calls_strike < current_price * (1 - ITM_THRESHOLD_PCT)
        itm_call_oi = float(calls_oi[itm_calls_mask].sum())
    else:
        otm_call_oi = atm_call_oi = itm_call_oi = 0.0
    
    # Classify puts
    if not puts.empty:
        puts_strike = pd.to_numeric(puts[strike_col], errors='coerce')
        puts_oi = pd.to_numeric(puts['oi'], errors='coerce').fillna(0)
        
        # OTM puts: strike < current_price * (1 - OTM_THRESHOLD_PCT)
        otm_puts_mask = puts_strike < current_price * (1 - OTM_THRESHOLD_PCT)
        otm_put_oi = float(puts_oi[otm_puts_mask].sum())
        
        # ATM puts: within ATM_THRESHOLD_PCT of current price
        atm_puts_mask = (
            (puts_strike >= current_price * (1 - ATM_THRESHOLD_PCT)) &
            (puts_strike <= current_price * (1 + ATM_THRESHOLD_PCT))
        )
        atm_put_oi = float(puts_oi[atm_puts_mask].sum())
        
        # ITM puts: strike > current_price * (1 + ITM_THRESHOLD_PCT)
        itm_puts_mask = puts_strike > current_price * (1 + ITM_THRESHOLD_PCT)
        itm_put_oi = float(puts_oi[itm_puts_mask].sum())
    else:
        otm_put_oi = atm_put_oi = itm_put_oi = 0.0
    
    return {
        'otm_call_oi': otm_call_oi,
        'atm_call_oi': atm_call_oi,
        'itm_call_oi': itm_call_oi,
        'otm_put_oi': otm_put_oi,
        'atm_put_oi': atm_put_oi,
        'itm_put_oi': itm_put_oi,
    }


class OTTrendScannerV2Advanced(BaseOTTrendScannerV2):
    """
    Advanced version of OTTrendScannerV2 with strike-specific OI tracking.
    
    Inherits all functionality from base scanner and adds:
    - Strike-specific OI classification (OTM/ATM/ITM)
    - Enhanced options OI snapshot with strike-level data
    """
    
    def __init__(self, api_key: str, access_token: str,
                 symbols_csv: str = "data/FNOStock.csv",
                 master_path: Path = None):
        """
        Initialize advanced scanner.
        
        Args:
            master_path: Optional. If None, uses advanced master file (daily_trend_master_advanced.csv).
                        If specified, can use custom file for advanced data.
        """
        # Initialize base scanner with advanced master file by default
        super().__init__(api_key, access_token, symbols_csv, master_path or MASTER_DATA_PATH_ADVANCED)
    
    def _get_options_oi_snapshot_advanced(self, symbol: str, target_date: date, current_price_hint: Optional[float] = None, futures_chain_hint: Optional[Dict] = None) -> Dict:
        """
        Enhanced options OI snapshot with strike-specific classification.
        
        Returns all fields from base scanner PLUS:
        - otm_call_oi, atm_call_oi, itm_call_oi
        - otm_put_oi, atm_put_oi, itm_put_oi
        
        Args:
            current_price_hint: Optional current price to avoid re-fetching
            futures_chain_hint: Optional futures chain dict to avoid re-fetching (uses cached instrument_cache)
        """
        # Get base snapshot (aggregate OI) - this uses cached instrument_cache
        base_snapshot = self._get_options_oi_snapshot(symbol, target_date)
        
        # If base snapshot failed, return empty strike-specific data
        if not base_snapshot or base_snapshot.get('options_call_oi') is None:
            return {
                **base_snapshot,
                'otm_call_oi': None,
                'atm_call_oi': None,
                'itm_call_oi': None,
                'otm_put_oi': None,
                'atm_put_oi': None,
                'itm_put_oi': None,
            }
        
        try:
            # Get futures chain - use hint if provided (avoids redundant cache lookup)
            # Note: get_futures_chain uses cached instrument_cache, so it's fast, but we can still optimize
            if futures_chain_hint:
                futures = futures_chain_hint
            else:
                futures = self.base_scanner.get_futures_chain(symbol)  # Uses cached instrument_cache
            current_fut = futures.get('current')
            
            # Get current price - try multiple methods
            # First, use the price hint if provided (from futures data we already fetched)
            current_price = float(current_price_hint) if current_price_hint and current_price_hint > 0 else None
            
            # If price hint not provided, try fallback methods (but avoid if we already have it)
            if not current_price and current_fut:
                # Method 1: Try to get quote for futures contract (live price) - only if really needed
                # Note: This is a live API call, so we skip it if we have price_hint
                # Only use if price_hint is None and we need live price
                try:
                    fut_token = current_fut.get('instrument_token')
                    if fut_token:
                        # Fetch quote for futures contract (live API call - only if necessary)
                        quote_key = f"NFO:{current_fut.get('tradingsymbol', '')}"
                        quotes = self.base_scanner.kite.quote([quote_key])
                        time.sleep(API_DELAY_SECONDS)  # Respect rate limits
                        if quotes and isinstance(quotes, dict) and quote_key in quotes:
                            quote_data = quotes[quote_key]
                            if quote_data and 'last_price' in quote_data:
                                current_price = float(quote_data['last_price'])
                except Exception as e:
                    logger.debug(f"Could not get quote for {symbol} futures: {e}")
                
                # Method 2: Try to get from historical futures data (for today or recent date)
                # Note: This would re-fetch data, so we skip if price_hint is provided
                # Only use as last resort
                if not current_price:
                    try:
                        # For today, try fetching yesterday to today to get today's close
                        if target_date == datetime.now(self.base_scanner.ist_timezone).date():
                            fetch_start = target_date - timedelta(days=1)
                        else:
                            fetch_start = target_date
                        
                        fut_data = self._build_rows_for_contract(
                            symbol, 'current', current_fut, fetch_start, target_date
                        )
                        if fut_data and len(fut_data) > 0:
                            # Get the row for target_date
                            for row in fut_data:
                                if row.get('date') == target_date:
                                    current_price = float(row.get('close', 0)) or None
                                    break
                            # If not found, use the last row (most recent)
                            if not current_price and len(fut_data) > 0:
                                current_price = float(fut_data[-1].get('close', 0)) or None
                    except Exception as e:
                        logger.debug(f"Could not get historical futures data for {symbol}: {e}")
            
            # Method 3: Try to get from existing master file (if data already exists)
            if not current_price:
                try:
                    existing = self.store.load()
                    if not existing.empty:
                        existing_row = existing[
                            (existing['symbol'] == symbol) &
                            (existing['contract_type'] == 'current') &
                            (existing['date'] == target_date)
                        ]
                        if not existing_row.empty and 'close' in existing_row.columns:
                            current_price = float(existing_row['close'].iloc[0])
                except Exception as e:
                    logger.debug(f"Could not get price from existing master file for {symbol}: {e}")
            
            # Method 4: Fallback to spot price if futures price not available
            if not current_price:
                try:
                    # Get spot token
                    spot_token = None
                    if hasattr(self.base_scanner, 'nse_instrument_cache') and not self.base_scanner.nse_instrument_cache.empty:
                        spot_row = self.base_scanner.nse_instrument_cache[
                            self.base_scanner.nse_instrument_cache['tradingsymbol'] == symbol.upper()
                        ]
                        if not spot_row.empty:
                            spot_token = spot_row.iloc[0].get('instrument_token')
                    
                    if spot_token:
                        spot_data = self.base_scanner.get_historical_data(
                            spot_token,
                            target_date,
                            target_date,
                            interval='day',
                            contract_type='spot'
                        )
                        if spot_data and not spot_data.empty and 'close' in spot_data.columns:
                            current_price = float(spot_data['close'].iloc[-1])
                except Exception as e:
                    logger.debug(f"Could not get spot price for {symbol}: {e}")
            
            if not current_price or current_price <= 0:
                logger.warning(f"Could not determine current price for {symbol} on {target_date}")
                return {
                    **base_snapshot,
                    'otm_call_oi': None,
                    'atm_call_oi': None,
                    'itm_call_oi': None,
                    'otm_put_oi': None,
                    'atm_put_oi': None,
                    'itm_put_oi': None,
                }
            
            # Get current month expiry
            current_expiry = pd.to_datetime(current_fut['expiry']).date()
            
            # Fetch full options chain
            option_chain = self.base_scanner.get_option_chain(symbol, [current_expiry])
            time.sleep(API_DELAY_SECONDS)  # Respect API rate limits
            
            if option_chain.empty:
                logger.warning(f"Empty option chain for {symbol} on {target_date}")
                return {
                    **base_snapshot,
                    'otm_call_oi': None,
                    'atm_call_oi': None,
                    'itm_call_oi': None,
                    'otm_put_oi': None,
                    'atm_put_oi': None,
                    'itm_put_oi': None,
                }
            
            # Classify strikes
            strike_oi = _classify_strike_oi(option_chain, current_price)
            
            return {
                **base_snapshot,
                'otm_call_oi': strike_oi['otm_call_oi'] if strike_oi['otm_call_oi'] > 0 else None,
                'atm_call_oi': strike_oi['atm_call_oi'] if strike_oi['atm_call_oi'] > 0 else None,
                'itm_call_oi': strike_oi['itm_call_oi'] if strike_oi['itm_call_oi'] > 0 else None,
                'otm_put_oi': strike_oi['otm_put_oi'] if strike_oi['otm_put_oi'] > 0 else None,
                'atm_put_oi': strike_oi['atm_put_oi'] if strike_oi['atm_put_oi'] > 0 else None,
                'itm_put_oi': strike_oi['itm_put_oi'] if strike_oi['itm_put_oi'] > 0 else None,
            }
            
        except Exception as e:
            logger.error(f"Error getting strike-specific OI for {symbol} on {target_date}: {e}")
            return {
                **base_snapshot,
                'otm_call_oi': None,
                'atm_call_oi': None,
                'itm_call_oi': None,
                'otm_put_oi': None,
                'atm_put_oi': None,
                'itm_put_oi': None,
            }
    
    def capture_daily_snapshots(self):
        """
        Enhanced capture that includes strike-specific OI data.
        
        Overrides base method to use advanced snapshot function.
        """
        existing = self.store.load()
        
        # Check if we need to update existing rows with strike-specific data
        today = datetime.now(self.base_scanner.ist_timezone).date()
        is_market_closed = not self._is_market_open()
        
        needs_strike_update = False
        needs_eod_update = False
        eod_update_date = None  # Initialize to avoid scope issues
        
        # IMPORTANT: Check for EOD update BEFORE calling _determine_fetch_window
        # because we need to override the fetch window if EOD update is needed
        if not existing.empty:
            # Check if today's rows exist but don't have strike-specific data
            if 'otm_call_oi' in existing.columns:
                today_rows = existing[
                    (existing['date'] == today) &
                    (existing['otm_call_oi'].isna())
                ]
                needs_strike_update = not today_rows.empty
            
            # Check if we need to re-fetch data with EOD values
            # This happens if:
            # 1. Market is now closed (so EOD data is available)
            # 2. Today's OR yesterday's data exists in master file (was captured during market hours)
            # 3. We should re-fetch to get EOD settlement prices instead of intraday prices
            if is_market_closed and 'date' in existing.columns:
                yesterday = today - timedelta(days=1)
                today_rows_exist = existing[existing['date'] == today]
                yesterday_rows_exist = existing[existing['date'] == yesterday]
                
                # Check if today's data exists (needs EOD update)
                if not today_rows_exist.empty:
                    needs_eod_update = True
                    eod_update_date = today
                    logger.info(f"Market is closed and today's data exists. Will re-fetch today ({today}) to get EOD settlement data instead of intraday data.")
                # Check if yesterday's data exists and today's doesn't (yesterday was captured during market hours)
                elif not yesterday_rows_exist.empty:
                    needs_eod_update = True
                    eod_update_date = yesterday
                    logger.info(f"Market is closed and yesterday's data exists (today's data not yet captured). Will re-fetch yesterday ({yesterday}) to get EOD settlement data instead of intraday data.")
        
        # Now call _determine_fetch_window, but we'll override if EOD update is needed
        start_date, end_date = self._determine_fetch_window(existing)
        
        logger.debug(f"After _determine_fetch_window: start_date={start_date}, end_date={end_date}, needs_eod_update={needs_eod_update}, needs_strike_update={needs_strike_update}")
        
        if start_date > end_date and not needs_strike_update and not needs_eod_update:
            logger.info("Master sheet already up to date. Nothing to fetch.")
            return
        
        # If we need to update strike-specific data for existing rows, force fetch today
        if needs_strike_update and start_date > end_date:
            start_date = today
            end_date = today
            logger.info(f"Updating existing rows with strike-specific OI for {today}")
        
        # If we need to update with EOD data, force fetch the date that needs updating
        if needs_eod_update:
            # eod_update_date is set in the check above (today or yesterday)
            if eod_update_date:
                start_date = eod_update_date
                end_date = eod_update_date
                logger.info(f"Re-fetching {eod_update_date} to update with EOD settlement data")
            else:
                # Fallback to today if eod_update_date not set
                start_date = today
                end_date = today
                logger.info(f"Re-fetching today ({today}) to update with EOD settlement data")

        # For incremental updates, we need to fetch one extra day (previous day) to enable
        # pct_change() and diff() calculations. But we only want to store new days.
        last_existing_date = max(existing['date']) if not existing.empty and 'date' in existing.columns else None
        
        # Fetch one day before start_date to enable calculations (if doing incremental update)
        today = datetime.now(self.base_scanner.ist_timezone).date()
        fetch_start = start_date
        if last_existing_date is not None:
            if start_date < end_date:
                if start_date < today - timedelta(days=1):
                    fetch_start = start_date - timedelta(days=1)
                    logger.debug(f"Fetching extra day for calculations: fetch_start={fetch_start}")
                else:
                    logger.debug(f"Using start_date as fetch_start: {fetch_start}")
            elif start_date == end_date:
                # For EOD update or single date fetch, need previous day for calculations
                fetch_start = start_date - timedelta(days=1)
                if needs_eod_update:
                    logger.debug(f"Re-fetching {start_date} for EOD update with calculations: fetch_start={fetch_start}")
                else:
                    logger.debug(f"Re-fetching today with calculations: fetch_start={fetch_start}")
        
        is_refetch_today_nan = (start_date == today - timedelta(days=1) and 
                               end_date == today and 
                               last_existing_date is not None and 
                               last_existing_date >= today)
        # If we're updating EOD data, we want to store today's data (will overwrite existing)
        store_from_date = today if (is_refetch_today_nan or needs_eod_update) else start_date
        logger.info(f"Building daily snapshots from {fetch_start} to {end_date} (will store new days from {store_from_date}).")
        if last_existing_date:
            logger.debug(f"Last existing date in master: {last_existing_date}, will filter to keep only dates > {last_existing_date}")
        
        # Ensure NSE instrument cache is populated
        _ = self.base_scanner.nse_instrument_cache
        
        symbols = self.base_scanner.read_symbols()
        all_rows: List[Dict] = []

        for symbol in symbols:
            symbol = symbol.strip().upper()
            # Get futures chain once (uses cached instrument_cache - no API call)
            futures = self.base_scanner.get_futures_chain(symbol)
            time.sleep(API_DELAY_SECONDS)
            
            # Fetch futures and spot data first (we'll use the close price from futures)
            current_rows = self._build_rows_for_contract(symbol, "current",
                                                         futures.get('current'),
                                                         fetch_start, end_date)
            next_rows = self._build_rows_for_contract(symbol, "next",
                                                      futures.get('next'),
                                                      fetch_start, end_date)
            spot_rows = self._build_rows_for_spot(symbol, fetch_start, end_date)
            
            # Get current price from futures data we just fetched (more reliable)
            today = datetime.now(self.base_scanner.ist_timezone).date()
            target_date = min(today, end_date) if end_date <= today else end_date
            current_price_from_futures = None
            if current_rows:
                # Find the row for target_date
                for row in current_rows:
                    if row.get('date') == target_date:
                        current_price_from_futures = row.get('close')
                        break
                # If not found, use the most recent row
                if not current_price_from_futures and len(current_rows) > 0:
                    current_price_from_futures = current_rows[-1].get('close')
            
            # Fetch enhanced options OI snapshot with strike-specific data
            # Pass both current price and futures chain to avoid redundant calls
            # Note: get_futures_chain uses cached instrument_cache, but we pass it to avoid re-lookup
            options_snapshot = self._get_options_oi_snapshot_advanced(
                symbol, target_date, 
                current_price_hint=current_price_from_futures,
                futures_chain_hint=futures  # Pass to avoid redundant cache lookup
            )
            
            # Calculate options OI change from previous day if available
            if not existing.empty and 'options_call_oi' in existing.columns:
                prev_row = existing[
                    (existing['symbol'] == symbol) & 
                    (existing['date'] < target_date) &
                    (existing['options_call_oi'].notna())
                ].sort_values('date', ascending=False)
                
                if not prev_row.empty:
                    prev_call_oi = prev_row.iloc[0].get('options_call_oi')
                    prev_put_oi = prev_row.iloc[0].get('options_put_oi')
                    curr_call_oi = options_snapshot.get('options_call_oi')
                    curr_put_oi = options_snapshot.get('options_put_oi')
                    
                    if prev_call_oi and curr_call_oi and prev_call_oi > 0:
                        options_snapshot['options_call_oi_change_pct'] = ((curr_call_oi - prev_call_oi) / prev_call_oi) * 100.0
                    if prev_put_oi and curr_put_oi and prev_put_oi > 0:
                        options_snapshot['options_put_oi_change_pct'] = ((curr_put_oi - prev_put_oi) / prev_put_oi) * 100.0
            
            # Futures and spot data already fetched above (for current price determination)
            
            # Filter to only keep new days
            all_symbol_rows = current_rows + next_rows + spot_rows
            rows_before_filter = len(all_symbol_rows)
            
            if last_existing_date is not None:
                if is_refetch_today_nan or needs_eod_update:
                    # Re-fetching for EOD update: keep rows for the date being updated (today or yesterday)
                    eod_target_date = eod_update_date if (needs_eod_update and eod_update_date) else today
                    all_symbol_rows = [row for row in all_symbol_rows if row.get('date') == eod_target_date]
                    rows_after_filter = len(all_symbol_rows)
                    if needs_eod_update:
                        logger.debug(f"{symbol}: Re-fetching {eod_target_date} for EOD data - keeping {rows_after_filter} rows")
                    else:
                        logger.debug(f"{symbol}: Re-fetching today - keeping {rows_after_filter} rows for {today}")
                else:
                    all_symbol_rows = [row for row in all_symbol_rows if row.get('date') > last_existing_date]
                    rows_after_filter = len(all_symbol_rows)
                    if rows_before_filter > rows_after_filter:
                        logger.debug(f"{symbol}: Filtered {rows_before_filter} rows to {rows_after_filter} new rows")
            else:
                all_symbol_rows = [row for row in all_symbol_rows if row.get('date') >= start_date]
                logger.debug(f"{symbol}: First run - keeping {len(all_symbol_rows)} rows from {start_date} onwards")
            
            # IMPORTANT: Update existing rows for target_date (today or yesterday for EOD update) with strike-specific data
            # This must happen BEFORE we add strike-specific OI to new rows, so we can update existing rows
            # even if no new rows are being added (e.g., market hasn't opened yet but we want to update existing data)
            eod_target_date = eod_update_date if (needs_eod_update and eod_update_date) else today
            if target_date == today or (needs_eod_update and target_date == eod_target_date):
                if not existing.empty:
                    # Check if rows exist in existing file for the target date
                    target_rows_mask = (
                        (existing['symbol'] == symbol) &
                        (existing['date'] == target_date)
                    )
                    if target_rows_mask.any():
                        # Create update rows with strike-specific data
                        existing_today_rows = existing[target_rows_mask].copy()
                        for idx, existing_row in existing_today_rows.iterrows():
                            # Create update row with strike-specific data
                            update_row = existing_row.to_dict()
                            # Convert Series to dict properly if needed
                            if hasattr(update_row, 'to_dict'):
                                update_row = update_row.to_dict()
                            # Update with strike-specific OI
                            update_row.update({
                                'otm_call_oi': options_snapshot.get('otm_call_oi'),
                                'atm_call_oi': options_snapshot.get('atm_call_oi'),
                                'itm_call_oi': options_snapshot.get('itm_call_oi'),
                                'otm_put_oi': options_snapshot.get('otm_put_oi'),
                                'atm_put_oi': options_snapshot.get('atm_put_oi'),
                                'itm_put_oi': options_snapshot.get('itm_put_oi'),
                            })
                            # Also update aggregate options OI if available
                            if options_snapshot.get('options_call_oi') is not None:
                                update_row.update({
                                    'options_call_oi': options_snapshot.get('options_call_oi'),
                                    'options_put_oi': options_snapshot.get('options_put_oi'),
                                    'options_total_oi': options_snapshot.get('options_total_oi'),
                                    'options_pcr': options_snapshot.get('options_pcr'),
                                    'options_call_oi_change_pct': options_snapshot.get('options_call_oi_change_pct'),
                                    'options_put_oi_change_pct': options_snapshot.get('options_put_oi_change_pct'),
                                })
                            # Add to all_symbol_rows so it gets saved (will overwrite existing due to deduplication)
                            all_symbol_rows.append(update_row)
                        logger.info(f"{symbol}: Updating {len(existing_today_rows)} existing rows for {target_date} with strike-specific OI")
                else:
                    # No existing file, but we have strike-specific OI for today
                    # This means we should create new rows with strike-specific OI
                    # But if all_symbol_rows is empty (market hasn't opened), we can't create rows yet
                    # So we'll just log that strike-specific OI was calculated but no rows to update
                    if len(all_symbol_rows) == 0:
                        logger.debug(f"{symbol}: Strike-specific OI calculated for {target_date}, but no rows to update (market may not have opened yet)")
            
            # Add strike-specific options OI to NEW rows (rows that don't exist yet)
            # IMPORTANT: Strike-specific OI is only available for the most recent date (target_date)
            # because it requires live options chain data. For historical dates, we try to get from existing file.
            for row in all_symbol_rows:
                row_date = row.get('date')
                if row_date == target_date:
                    # Add strike-specific data for target_date (today or most recent date)
                    # Only if not already updated above (check if already has strike-specific OI)
                    if row.get('otm_call_oi') is None:
                        row.update({
                            'otm_call_oi': options_snapshot.get('otm_call_oi'),
                            'atm_call_oi': options_snapshot.get('atm_call_oi'),
                            'itm_call_oi': options_snapshot.get('itm_call_oi'),
                            'otm_put_oi': options_snapshot.get('otm_put_oi'),
                            'atm_put_oi': options_snapshot.get('atm_put_oi'),
                            'itm_put_oi': options_snapshot.get('itm_put_oi'),
                        })
                    # Also add aggregate options OI (from base snapshot) if not already set
                    if row.get('options_call_oi') is None:
                        row.update({
                            'options_call_oi': options_snapshot.get('options_call_oi'),
                            'options_put_oi': options_snapshot.get('options_put_oi'),
                            'options_total_oi': options_snapshot.get('options_total_oi'),
                            'options_pcr': options_snapshot.get('options_pcr'),
                            'options_call_oi_change_pct': options_snapshot.get('options_call_oi_change_pct'),
                            'options_put_oi_change_pct': options_snapshot.get('options_put_oi_change_pct'),
                        })
                else:
                    # For historical dates: try to get from existing master file
                    if not existing.empty and 'otm_call_oi' in existing.columns:
                        hist_row = existing[
                            (existing['symbol'] == symbol) &
                            (existing['date'] == row_date) &
                            (existing['otm_call_oi'].notna())
                        ]
                        if not hist_row.empty:
                            hist_data = hist_row.iloc[0]
                            row.update({
                                'otm_call_oi': hist_data.get('otm_call_oi'),
                                'atm_call_oi': hist_data.get('atm_call_oi'),
                                'itm_call_oi': hist_data.get('itm_call_oi'),
                                'otm_put_oi': hist_data.get('otm_put_oi'),
                                'atm_put_oi': hist_data.get('atm_put_oi'),
                                'itm_put_oi': hist_data.get('itm_put_oi'),
                            })
                        else:
                            # Historical date exists but no strike-specific OI in existing file
                            # This is expected for dates before we started tracking strike-specific OI
                            row.update({
                                'otm_call_oi': None,
                                'atm_call_oi': None,
                                'itm_call_oi': None,
                                'otm_put_oi': None,
                                'atm_put_oi': None,
                                'itm_put_oi': None,
                            })
                    else:
                        # No historical strike-specific data yet (first run or existing file doesn't have these columns)
                        row.update({
                            'otm_call_oi': None,
                            'atm_call_oi': None,
                            'itm_call_oi': None,
                            'otm_put_oi': None,
                            'atm_put_oi': None,
                            'itm_put_oi': None,
                        })
            
            all_rows.extend(all_symbol_rows)
            
            # Log strike-specific OI
            otm_call = options_snapshot.get('otm_call_oi', 'N/A')
            otm_put = options_snapshot.get('otm_put_oi', 'N/A')
            logger.info(f"{symbol}: appended {len(all_symbol_rows)} new daily rows. "
                       f"Strike OI: OTM Call={otm_call}, OTM Put={otm_put}, "
                       f"Total Call={options_snapshot.get('options_call_oi', 'N/A')}, "
                       f"Total Put={options_snapshot.get('options_put_oi', 'N/A')}")

        # Summary log
        if all_rows:
            dates_in_new_rows = set(row.get('date') for row in all_rows)
            logger.info(f"Summary: Appending {len(all_rows)} new rows for dates {min(dates_in_new_rows)} to {max(dates_in_new_rows)}.")
        else:
            logger.info("No new rows to append (all data already exists)")

        self.store.append_rows(all_rows)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python OTTrendScannerV2_advanced.py <api_key> <access_token> [master_path]")
        sys.exit(1)
    
    api_key = sys.argv[1]
    access_token = sys.argv[2]
    master_path = Path(sys.argv[3]) if len(sys.argv) > 3 else None
    
    scanner = OTTrendScannerV2Advanced(api_key, access_token, master_path=master_path)
    scanner.capture_daily_snapshots()
    print("Advanced scanner completed. Strike-specific OI data added to master file.")

