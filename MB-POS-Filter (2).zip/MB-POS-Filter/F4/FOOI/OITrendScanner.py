import kiteconnect
from kiteconnect import KiteConnect
import pandas as pd
from datetime import datetime, timedelta, date, time as dt_time
import time
import logging
import pytz
import traceback
from threading import Lock
import numpy as np
import math
from concurrent.futures import ThreadPoolExecutor, as_completed

# --- Constants for New Features ---
MIN_FUT_AVG_VOLUME = 50000
MIN_FUT_AVG_OI = 100000
MIN_OPTION_OI = 50
MIN_OPTION_VOLUME = 20
STALE_SPOT_PRICE_THRESHOLD_SECONDS = 300
OUTLIER_STD_DEV_THRESHOLD = 3

# --- Constants for Baseline Z-Score Calculations ---
BASELINE_DAYS_FOR_INDEX_ZSCORE = 90
MIN_INDEX_BASELINE_TRADING_DAYS_FOR_ZSCORE = 40

BASELINE_DAYS_FOR_FUTURES_ZSCORE = 40
MIN_FUT_BASELINE_TRADING_DAYS_FOR_ZSCORE = 20

# --- Constants for Dynamic Regime Detection ---
NIFTY_50_SYMBOL = "NIFTY 50"
INDIA_VIX_SYMBOL = "INDIA VIX"
REGIME_DETECTION_DAYS = 100
EMA_SHORT_PERIOD = 20
EMA_LONG_PERIOD = 50
VIX_LOW_THRESHOLD = 15
VIX_HIGH_THRESHOLD = 22

# --- Constants for Sentiment Determination ---
Z_THRESH_OI = 0.75 # From v9
Z_THRESH_PRICE = 0.75 # From v9
OI_PCT_THRESH_POS = 5.0
OI_PCT_THRESH_NEG = -5.0
PRICE_PCT_THRESH_POS = 0.75
PRICE_PCT_THRESH_NEG = -0.75

# --- Constants for Dynamic Z-Threshold Scaling ---
# Reference daily realized vol in percent to scale z-thresholds around
# Example: if a symbol's daily std of returns is 2.0% (vs ref 1.0%), threshold multiplier ~2.0 (clamped)
DYN_Z_REF_DAILY_RETURN_PCT = 1.0
DYN_Z_MULT_MIN = 0.7
DYN_Z_MULT_MAX = 1.6

# --- Constants for Term Structure Adjustment ---
TERM_STRONG_BACKWARD_THRESH = -1.0
TERM_MODERATE_BACKWARD_THRESH = -0.5
TERM_MILD_BACKWARD_THRESH = 0.0
TERM_MILD_CONTANGO_THRESH = 0.0
TERM_MODERATE_CONTANGO_THRESH = 0.5
TERM_STRONG_CONTANGO_THRESH = 1.0

TERM_ADJ_BULLISH_STRONG_BACKWARD = -8.0
TERM_ADJ_BULLISH_MODERATE_BACKWARD = -4.0
TERM_ADJ_BULLISH_MILD_BACKWARD = -2.0
TERM_ADJ_BULLISH_MILD_CONTANGO = 2.0
TERM_ADJ_BULLISH_MODERATE_CONTANGO = 4.0
TERM_ADJ_BULLISH_STRONG_CONTANGO = 8.0

TERM_ADJ_BEARISH_STRONG_CONTANGO = -8.0
TERM_ADJ_BEARISH_MODERATE_CONTANGO = -4.0
TERM_ADJ_BEARISH_MILD_CONTANGO = -2.0
TERM_ADJ_BEARISH_MILD_BACKWARD = 2.0
TERM_ADJ_BEARISH_MODERATE_BACKWARD = 4.0
TERM_ADJ_BEARISH_STRONG_BACKWARD = 8.0

# --- Constants for Price-to-OI Ratio ---
PRICE_OI_RATIO_LOW_THRESH = 0.02
PRICE_OI_RATIO_HIGH_THRESH = 0.05
PRICE_OI_RATIO_PENALTY = -7.0
PRICE_OI_RATIO_BONUS = 3.0
MIN_OI_CHANGE_FOR_RATIO = 100.0

# --- Seller Engine Structural Thresholds ---
SELLER_MAX_WALL_DISTANCE_PCT = 5.0
SELLER_MIN_WALL_DISTANCE_PCT = 3.0
SELLER_MIN_OI_CONCENTRATION_PCT = 55.0
SELLER_MIN_IV_PERCENTILE = 45.0
SELLER_MIN_CARRY_SCORE = 0.6
SELLER_MIN_RQI_FOR_CARRY = 6.0
SELLER_MIN_ROLLOVER_FOR_CARRY = 55.0
SELLER_MIN_TERM_SLOPE_FOR_CARRY = 0.05
SELLER_MAX_ROLL_COST_PCT = 0.5
SELLER_MIN_HHI = 0.35
SELLER_MIN_WALL_STRENGTH_SCORE = 60.0
SELLER_RELAXED_OI_CONCENTRATION_PCT = 35.0
SELLER_RELAXED_IV_PERCENTILE = 30.0
SELLER_RELAXED_CARRY_SCORE = 0.5
SELLER_RELAXED_WALL_DISTANCE_PCT = 4.0
SELLER_RELAXED_REALIZED_VOL_MAX = 1.0
SELLER_RELAXED_PCR_MIN = 0.75
SELLER_RELAXED_PCR_MAX = 1.30
SELLER_RELAXED_HHI = 0.25
SELLER_RELAXED_WALL_STRENGTH_SCORE = 45.0

# --- Constants for Z-Score Divergence ---
ZSCORE_DIVERGENCE_PRICE_THRESH = 0.5
ZSCORE_DIVERGENCE_OI_THRESH = 1.5
ZSCORE_DIVERGENCE_PENALTY = -5.0

# --- Constants for Bullish Confidence Cap ---
BULLISH_CONFIDENCE_CAP = 60.0
BULLISH_CAP_PCR_THRESH = 0.6

# --- Constants for Bearish Institutional Rollover Detection ---
BIR_PRICE_CHANGE_MAX_THRESH = 3.0
BIR_OI_CHANGE_MIN_THRESH = 150.0
BIR_TERM_STRUCTURE_MAX_THRESH = 0.0
BIR_RQI_MIN_THRESH = 6.0
BIR_CONFIDENCE_PENALTY = -20.0

# --- Constants from v9 Enhancements ---
DISQUALIFY_LONG_RQI_THRESH = 4.0
DISQUALIFY_LONG_ROLL_PCT_THRESH = 40.0

# --- ENHANCEMENT V10: New Constants ---
INST_BREAK_PRICE_Z_THRESH = 0.9
INST_BREAK_CALL_WRITER_PCT_THRESH = 60.0
INST_BREAK_SPOT_PRICE_ABOVE_MAX_CALL_STRIKE = True
INST_BREAK_BONUS = 20.0

ROLL_SKEW_THRESH = 50.0
ROLL_SKEW_BULLISH_BONUS = 10.0

TRUST_RQI_THRESH = 6.5
TRUST_ROLL_PCT_THRESH = 70.0
TRUST_TERM_SLOPE_THRESH = 0.25

# --- Trend Trust Relaxed Floors & Scoring ---
TREND_TRUST_RQI_FLOOR = 5.5
TREND_TRUST_ROLL_PCT_FLOOR = 35.0
TREND_TRUST_TERM_SLOPE_FLOOR = 0.10
TREND_TRUST_BASE_REQUIRED_SCORE = 50.0
TREND_TRUST_REQUIRED_SCORE_MIN = 40.0
TREND_TRUST_REQUIRED_SCORE_MAX = 65.0
TREND_TRUST_STRICT_RQI = 6.5
TREND_TRUST_STRICT_ROLL = 70.0
TREND_TRUST_STRICT_TERM = 0.25

DEFAULT_RISK_FREE_RATE = 0.065
MAX_OPTION_SPREAD_PERCENT = 2.5
MAX_STRADDLE_SPREAD_PERCENT = 3.0

# --- NUANCE COLUMNS: Price Journey ---
SERIES_LOW_LOOKBACK_DAYS = 120 # Lookback days to find the series low for a contract


logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
    handlers=[
        logging.FileHandler("trend_scanner_regime_adaptive_v10_nuance.log"), # Log file name updated
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("OITrendScannerV10Nuance") # Logger name updated

class TokenBucketRateLimiter:
    def __init__(self, capacity, rate_per_second):
        self.capacity = capacity
        self.rate_per_second = rate_per_second
        self.tokens = capacity
        self.last_refill = time.time()
        self.lock = Lock()

    def _refill(self):
        now = time.time()
        elapsed = now - self.last_refill
        new_tokens = elapsed * self.rate_per_second
        self.tokens = min(self.capacity, self.tokens + new_tokens)
        self.last_refill = now

    def acquire(self):
        with self.lock:
            self._refill()
            if self.tokens >= 1:
                self.tokens -= 1
                return True
            return False

    def wait(self, max_retries=5, base_delay=1):
        for attempt in range(max_retries):
            if self.acquire():
                return True
            delay = base_delay * (2 ** attempt)
            logger.debug(f"Rate limit hit, waiting {delay:.2f}s (attempt {attempt + 1}/{max_retries})")
            time.sleep(delay)
        logger.error("Rate limit exceeded after max retries")
        return False


class TrendScanner:
    def __init__(self, api_key, access_token, input_csv="data/FNOStock.csv", max_workers=4):
        self.api_key = api_key
        self.access_token = access_token
        self.kite = KiteConnect(api_key=self.api_key)
        self.kite.set_access_token(self.access_token)
        self.exchange = "NFO"
        self.input_csv = input_csv
        self.results = []
        self.rate_limiter = TokenBucketRateLimiter(capacity=10, rate_per_second=3)
        self.ist_timezone = pytz.timezone("Asia/Kolkata")
        self.detected_market_regime = "NeutralUndetermined"
        self.nifty_token = None
        self.vix_token = None
        self.max_workers = max(1, int(max_workers)) if max_workers is not None else 1

        logger.info(f"Initializing TrendScanner V10 (with Price Journey Nuance Columns) | Parallel workers: {self.max_workers}")
        logger.debug("Fetching NSE instruments for cache")
        if not self.rate_limiter.wait():
            logger.critical("Rate limit exceeded (NSE instruments startup). Halting.")
            raise Exception("Rate limit exceeded during critical startup phase (NSE instruments).")
        try:
            self.nse_instrument_cache = pd.DataFrame(self.kite.instruments(exchange="NSE"))
            if self.nse_instrument_cache.empty:
                 logger.critical("NSE instrument cache is empty after fetching. Cannot proceed.")
                 raise ValueError("NSE instrument cache is empty.")
            logger.debug(f"NSE instruments cached: {len(self.nse_instrument_cache)} rows")

            nifty_row = self.nse_instrument_cache[self.nse_instrument_cache['tradingsymbol'] == NIFTY_50_SYMBOL]
            if not nifty_row.empty:
                self.nifty_token = nifty_row['instrument_token'].iloc[0]
                logger.info(f"Found NIFTY 50 token: {self.nifty_token}")
            else:
                logger.error(f"{NIFTY_50_SYMBOL} token not found in NSE instruments. Regime detection will be limited.")

            vix_row = self.nse_instrument_cache[self.nse_instrument_cache['tradingsymbol'] == INDIA_VIX_SYMBOL]
            if not vix_row.empty:
                self.vix_token = vix_row['instrument_token'].iloc[0]
                logger.info(f"Found INDIA VIX token: {self.vix_token}")
            else:
                logger.error(f"{INDIA_VIX_SYMBOL} token not found in NSE instruments. Regime detection will be limited.")

        except (kiteconnect.exceptions.TokenException, kiteconnect.exceptions.NetworkException) as e_api:
            logger.critical(f"API error fetching NSE instruments: {e_api}. Check API key/token and network.")
            raise
        except Exception as e:
            logger.critical(f"Generic error fetching NSE instruments: {traceback.format_exc()}")
            self.nse_instrument_cache = pd.DataFrame()
            raise

        logger.debug("Fetching NFO instruments for cache")
        if not self.rate_limiter.wait():
            logger.critical("Rate limit exceeded (NFO instruments startup). Halting.")
            raise Exception("Rate limit exceeded during critical startup phase (NFO instruments).")
        try:
            nfo_instruments_list = self.kite.instruments(exchange="NFO")
            self.instrument_cache = pd.DataFrame(nfo_instruments_list)
            if self.instrument_cache.empty:
                 logger.warning("NFO instrument cache is empty after fetching. Futures/Options analysis will fail.")
            else:
                logger.debug(f"NFO instruments fetched: {len(self.instrument_cache)} rows")
                self.instrument_cache['expiry'] = pd.to_datetime(self.instrument_cache['expiry'], errors='coerce')
        except (kiteconnect.exceptions.TokenException, kiteconnect.exceptions.NetworkException) as e_api:
            logger.critical(f"API error fetching NFO instruments: {e_api}. Check API key/token and network.")
            raise
        except Exception as e:
            logger.critical(f"Generic error fetching NFO instruments: {traceback.format_exc()}")
            self.instrument_cache = pd.DataFrame()
            raise

        self.detect_market_regime()
        logger.info(f"TrendScanner V10 (Nuance) initialized. Detected Market Regime: {self.detected_market_regime}")

    def _calculate_ema(self, prices_series, period):
        if not isinstance(prices_series, pd.Series):
             prices_series = pd.Series(prices_series)
        if len(prices_series) < period:
            return pd.Series([np.nan] * len(prices_series), index=prices_series.index)
        return prices_series.ewm(span=period, adjust=False, min_periods=period).mean()

    def _norm_cdf(self, x):
        return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))

    def _norm_pdf(self, x):
        return (1.0 / math.sqrt(2.0 * math.pi)) * math.exp(-0.5 * x * x)

    def _bs_d1_d2(self, spot, strike, time_years, rate, vol):
        if spot <= 0 or strike <= 0 or time_years <= 0 or vol <= 0:
            return None, None
        sqrt_t = math.sqrt(time_years)
        vol_sqrt_t = vol * sqrt_t
        if vol_sqrt_t == 0:
            return None, None
        d1 = (math.log(spot / strike) + (rate + 0.5 * vol * vol) * time_years) / vol_sqrt_t
        d2 = d1 - vol_sqrt_t
        return d1, d2

    def _black_scholes_price(self, spot, strike, time_years, rate, vol, option_type):
        d1, d2 = self._bs_d1_d2(spot, strike, time_years, rate, vol)
        if d1 is None:
            return None
        if option_type == 'CE':
            return spot * self._norm_cdf(d1) - strike * math.exp(-rate * time_years) * self._norm_cdf(d2)
        else:
            return strike * math.exp(-rate * time_years) * self._norm_cdf(-d2) - spot * self._norm_cdf(-d1)

    def _implied_volatility(self, spot, strike, time_years, rate, option_price, option_type, tol=1e-4, max_iter=100):
        if option_price is None or option_price <= 0 or spot <= 0 or strike <= 0 or time_years <= 0:
            return None

        intrinsic = max(0.0, spot - strike) if option_type == 'CE' else max(0.0, strike - spot)
        if option_price < intrinsic - 1e-4:
            return None

        lower, upper = 1e-4, 5.0
        price_lower = self._black_scholes_price(spot, strike, time_years, rate, lower, option_type)
        price_upper = self._black_scholes_price(spot, strike, time_years, rate, upper, option_type)
        if price_lower is None or price_upper is None:
            return None

        if option_price > price_upper:
            upper = max(upper, 10.0)
            price_upper = self._black_scholes_price(spot, strike, time_years, rate, upper, option_type)
            if price_upper is None or option_price > price_upper:
                return None

        for _ in range(max_iter):
            mid = 0.5 * (lower + upper)
            price_mid = self._black_scholes_price(spot, strike, time_years, rate, mid, option_type)
            if price_mid is None:
                return None
            diff = price_mid - option_price
            if abs(diff) < tol:
                return max(mid, 1e-6)
            if diff > 0:
                upper = mid
            else:
                lower = mid
        return max(0.5 * (lower + upper), 1e-6)

    def _calculate_option_greeks(self, spot, strike, option_price, time_years, option_type, rate=DEFAULT_RISK_FREE_RATE):
        try:
            if spot is None or strike is None or option_price is None:
                return {}
            spot = float(spot)
            strike = float(strike)
            option_price = float(option_price)
            if spot <= 0 or strike <= 0 or option_price <= 0 or time_years <= 0:
                return {}

            implied_vol = self._implied_volatility(spot, strike, time_years, rate, option_price, option_type)
            if implied_vol is None or implied_vol <= 0:
                return {}

            d1, d2 = self._bs_d1_d2(spot, strike, time_years, rate, implied_vol)
            if d1 is None:
                return {}

            n_d1 = self._norm_pdf(d1)
            sqrt_t = math.sqrt(time_years)

            if option_type == 'CE':
                delta = self._norm_cdf(d1)
                theta = (-spot * n_d1 * implied_vol / (2 * sqrt_t)) - rate * strike * math.exp(-rate * time_years) * self._norm_cdf(d2)
            else:
                delta = self._norm_cdf(d1) - 1
                theta = (-spot * n_d1 * implied_vol / (2 * sqrt_t)) + rate * strike * math.exp(-rate * time_years) * self._norm_cdf(-d2)

            gamma = n_d1 / (spot * implied_vol * sqrt_t)
            vega = spot * n_d1 * sqrt_t

            return {
                'iv': implied_vol * 100.0,
                'delta': delta,
                'gamma': gamma,
                'theta': theta / 365.0,
                'vega': vega / 100.0
            }
        except Exception as exc:
            logger.debug(f"Option greeks calculation failed: {exc}")
            return {}

    def detect_market_regime(self):
        logger.info("Attempting to detect market regime...")
        if self.nifty_token is None:
            logger.warning("NIFTY 50 token not available. Defaulting regime to NeutralUndetermined.")
            self.detected_market_regime = "NeutralUndetermined"
            return self.detected_market_regime

        current_date_obj = datetime.now(self.ist_timezone).date()
        from_date_obj = current_date_obj - timedelta(days=REGIME_DETECTION_DAYS + EMA_LONG_PERIOD + 20)

        nifty_df = self.get_historical_data(self.nifty_token, from_date_obj, current_date_obj, interval="day", contract_type="index")

        if nifty_df.empty or len(nifty_df) < EMA_LONG_PERIOD:
            logger.warning(f"Insufficient Nifty data ({len(nifty_df)} days) for regime detection. Defaulting to NeutralUndetermined.")
            self.detected_market_regime = "NeutralUndetermined"
            return self.detected_market_regime

        nifty_df['ema_short'] = self._calculate_ema(nifty_df['close'], EMA_SHORT_PERIOD)
        nifty_df['ema_long'] = self._calculate_ema(nifty_df['close'], EMA_LONG_PERIOD)

        nifty_df.dropna(subset=['ema_short', 'ema_long'], inplace=True)
        if nifty_df.empty:
            logger.warning("Nifty data became empty after EMA calculation and NaN drop. Defaulting to NeutralUndetermined.")
            self.detected_market_regime = "NeutralUndetermined"
            return self.detected_market_regime

        latest_nifty = nifty_df.iloc[-1]
        nifty_close = latest_nifty['close']
        nifty_ema_short = latest_nifty['ema_short']
        nifty_ema_long = latest_nifty['ema_long']

        latest_vix_close = VIX_LOW_THRESHOLD
        if self.vix_token:
            vix_from_date = current_date_obj - timedelta(days=10)
            vix_df = self.get_historical_data(self.vix_token, vix_from_date, current_date_obj, interval="day", contract_type="index")
            if not vix_df.empty and 'close' in vix_df.columns and not vix_df['close'].empty:
                latest_vix_close = vix_df['close'].iloc[-1]
            else:
                logger.warning("Insufficient or malformed VIX data. Using default VIX assumption (low).")
        else:
            logger.warning("INDIA VIX token not available. Using default VIX assumption (low).")

        logger.info(f"Regime Detection Data: Nifty Close={nifty_close:.2f}, EMA{EMA_SHORT_PERIOD}={nifty_ema_short:.2f}, EMA{EMA_LONG_PERIOD}={nifty_ema_long:.2f}, VIX Close={latest_vix_close:.2f}")

        regime = "NeutralUndetermined"
        if pd.isna(nifty_ema_short) or pd.isna(nifty_ema_long) or pd.isna(nifty_close):
            logger.warning("NaN values in Nifty EMAs or close. Defaulting regime to NeutralUndetermined.")
            self.detected_market_regime = "NeutralUndetermined"
            return self.detected_market_regime

        is_uptrend = nifty_close > nifty_ema_short and nifty_ema_short > nifty_ema_long
        is_downtrend = nifty_close < nifty_ema_short and nifty_ema_short < nifty_ema_long

        if is_uptrend:
            if latest_vix_close < VIX_LOW_THRESHOLD: regime = "BullishCalm"
            elif latest_vix_close < VIX_HIGH_THRESHOLD: regime = "BullishModerateVol"
            else: regime = "BullishHighVol"
        elif is_downtrend:
            if latest_vix_close < VIX_LOW_THRESHOLD: regime = "BearishCalm"
            elif latest_vix_close < VIX_HIGH_THRESHOLD: regime = "BearishModerateVol"
            else: regime = "BearishHighVol"
        else:
            if latest_vix_close < VIX_LOW_THRESHOLD: regime = "SidewaysLowVol"
            elif latest_vix_close < VIX_HIGH_THRESHOLD: regime = "SidewaysModerateVol"
            else: regime = "SidewaysHighVol"

        self.detected_market_regime = regime
        logger.info(f"Detected Market Regime: {self.detected_market_regime}")
        return self.detected_market_regime

    def read_symbols(self):
        try:
            df = pd.read_csv(self.input_csv)
            if 'Symbol' not in df.columns:
                raise ValueError("CSV must contain 'Symbol' column")
            symbols = df['Symbol'].unique().tolist()
            logger.debug(f"Read {len(symbols)} unique symbols from {self.input_csv}: {symbols}")
            return symbols
        except FileNotFoundError:
            logger.error(f"Input CSV file not found at '{self.input_csv}'. Please create it or check the path.")
            return []
        except Exception as e:
            logger.error(f"Error reading CSV '{self.input_csv}': {traceback.format_exc()}")
            return []

    def _cap_outliers(self, series, column_name="value"):
        if series.empty or series.isnull().all():
            return series
        series_numeric = pd.to_numeric(series, errors='coerce')
        if series_numeric.isnull().all():
            return series

        mean = series_numeric.mean()
        std = series_numeric.std()

        if pd.isna(mean) or pd.isna(std) or std == 0:
            return series

        upper_bound = mean + OUTLIER_STD_DEV_THRESHOLD * std
        lower_bound = mean - OUTLIER_STD_DEV_THRESHOLD * std

        capped_series = series.clip(lower=lower_bound, upper=upper_bound)

        num_capped_upper = (series_numeric > upper_bound).sum()
        num_capped_lower = (series_numeric < lower_bound).sum()
        if num_capped_upper > 0:
            logger.debug(f"Capped {num_capped_upper} upper outliers for {column_name} (limit: {upper_bound:.2f})")
        if num_capped_lower > 0:
            logger.debug(f"Capped {num_capped_lower} lower outliers for {column_name} (limit: {lower_bound:.2f})")
        return capped_series

    def get_historical_data(self, instrument_token, from_date_obj, to_date_obj, interval="day", cap_outliers_flag=False, contract_type="future"):
        if not self.rate_limiter.wait():
            logger.error(f"Rate limit exceeded for historical data token {instrument_token}")
            return pd.DataFrame()
        try:
            from_date_str = from_date_obj.strftime('%Y-%m-%d')
            to_date_str = to_date_obj.strftime('%Y-%m-%d')
            logger.debug(f"Fetching {interval} data for token {instrument_token} ({contract_type}) from {from_date_str} to {to_date_str}")

            fetch_oi = True
            if contract_type == "index":
                fetch_oi = False

            data = self.kite.historical_data(instrument_token, from_date_str, to_date_str, interval, oi=fetch_oi, continuous=False)
            df = pd.DataFrame(data)

            if not df.empty:
                df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
                # Ensure 'close' column is numeric before capping
                if 'close' in df.columns:
                    df['close'] = pd.to_numeric(df['close'], errors='coerce')
                if 'oi' in df.columns and fetch_oi:
                     df['oi'] = pd.to_numeric(df['oi'], errors='coerce')

                if cap_outliers_flag:
                    if 'close' in df.columns:
                        df['close'] = self._cap_outliers(df['close'], f"token {instrument_token} close price")
                    if 'oi' in df.columns and fetch_oi:
                        df['oi'] = self._cap_outliers(df['oi'], f"token {instrument_token} OI")
            else:
                logger.debug(f"No historical data for token {instrument_token} in range {from_date_str} to {to_date_str}.")
            return df
        except kiteconnect.exceptions.InputException as e:
            logger.warning(f"Input error (e.g. no data/invalid date range) for historical data {instrument_token} ({from_date_str} to {to_date_str}): {e}")
        except kiteconnect.exceptions.TokenException as e:
            logger.critical(f"Token error fetching historical data for {instrument_token}: {e}. Halting.")
            raise
        except kiteconnect.exceptions.NetworkException as e:
            logger.error(f"Network/API error fetching historical data for {instrument_token}: {e}")
        except Exception as e:
            logger.error(f"Generic error fetching historical data for {instrument_token}: {traceback.format_exc()}")
        return pd.DataFrame()

    def get_futures_chain(self, symbol):
        if self.instrument_cache.empty:
            logger.warning(f"Instrument cache is empty. Cannot get futures chain for {symbol}")
            return {'current': None, 'next': None}

        futures_df = self.instrument_cache[
            (self.instrument_cache['name'] == symbol.upper()) &
            (self.instrument_cache['instrument_type'] == 'FUT')
        ].copy()

        if futures_df.empty:
            logger.debug(f"No futures data found for underlying {symbol} using 'name' filter.")
            return {'current': None, 'next': None}

        if not pd.api.types.is_datetime64_any_dtype(futures_df['expiry']):
            futures_df['expiry'] = pd.to_datetime(futures_df['expiry'], errors='coerce')
            futures_df.dropna(subset=['expiry'], inplace=True)

        futures_df.sort_values('expiry', inplace=True)
        now_date = datetime.now(self.ist_timezone).date()

        active_futures = futures_df[futures_df['expiry'].dt.date >= now_date]

        if active_futures.empty:
            logger.debug(f"No active futures contracts found for {symbol} on or after {now_date}")
            return {'current': None, 'next': None}

        current_contract_series = active_futures.iloc[0] if not active_futures.empty else None
        current_contract = current_contract_series.to_dict() if current_contract_series is not None else None

        next_contract = None
        if current_contract and len(active_futures) > 1:
            current_expiry_date = pd.Timestamp(current_contract['expiry']).date()
            for i in range(1, len(active_futures)):
                candidate_contract_series = active_futures.iloc[i]
                candidate_expiry_date = pd.Timestamp(candidate_contract_series['expiry']).date()
                if candidate_expiry_date.year > current_expiry_date.year or \
                   (candidate_expiry_date.year == current_expiry_date.year and candidate_expiry_date.month > current_expiry_date.month):
                    next_contract = candidate_contract_series.to_dict()
                    break

        if current_contract: logger.debug(f"Current contract for {symbol}: {current_contract['tradingsymbol']}")
        if next_contract: logger.debug(f"Next contract for {symbol}: {next_contract['tradingsymbol']}")
        else: logger.debug(f"Next month contract not found or not applicable for {symbol}")
        return {'current': current_contract, 'next': next_contract}

    def get_option_chain(self, symbol, expiry_dates_param):
        if self.instrument_cache.empty:
            logger.warning(f"Instrument cache is empty for options of {symbol}")
            return pd.DataFrame()
        try:
            if not expiry_dates_param or not all(isinstance(d, date) for d in expiry_dates_param):
                logger.error(f"Invalid expiry_dates_param for {symbol}: {expiry_dates_param}. Must be list of date objects.")
                return pd.DataFrame()

            target_expiry_dates = list(set(expiry_dates_param))
            logger.debug(f"Fetching options for {symbol} with target expiries: {target_expiry_dates}")

            if 'expiry' not in self.instrument_cache.columns or \
               not pd.api.types.is_datetime64_any_dtype(self.instrument_cache['expiry']):
                logger.error("Instrument cache 'expiry' column is not in datetime format or missing.")
                return pd.DataFrame()

            option_chain_df = self.instrument_cache[
                (self.instrument_cache['name'] == symbol.upper()) &
                (self.instrument_cache['instrument_type'].isin(['CE', 'PE'])) &
                (self.instrument_cache['expiry'].dt.date.isin(target_expiry_dates))
            ].copy()

            if option_chain_df.empty:
                logger.debug(f"No options for {symbol} with expiries {target_expiry_dates} using name filter.")
                return pd.DataFrame()

            tradingsymbols = option_chain_df['tradingsymbol'].tolist()
            batch_size = 400
            live_data = {}
            for i in range(0, len(tradingsymbols), batch_size):
                batch = tradingsymbols[i:i + batch_size]
                if not self.rate_limiter.wait():
                    logger.error(f"Rate limit for option quotes {symbol}. Skipping remaining.")
                    break
                try:
                    nfo_batch = [f"NFO:{ts}" for ts in batch]
                    quotes = self.kite.quote(nfo_batch)
                    if quotes and isinstance(quotes, dict):
                        live_data.update({k.split('NFO:')[1]: v for k, v in quotes.items() if v and 'NFO:' in k and k.split('NFO:')[1] in batch})
                    else: logger.warning(f"Empty/invalid quotes for batch {symbol}: {batch}")
                except Exception as qe: logger.error(f"Error fetching quotes for batch {symbol} {batch}: {qe}")

            option_chain_df['last_price'] = option_chain_df['tradingsymbol'].map(lambda x: live_data.get(x, {}).get('last_price', 0))
            option_chain_df['volume'] = option_chain_df['tradingsymbol'].map(lambda x: live_data.get(x, {}).get('volume', 0))
            option_chain_df['oi'] = option_chain_df['tradingsymbol'].map(lambda x: live_data.get(x, {}).get('oi', 0))
            return option_chain_df

        except Exception as e:
            logger.error(f"Error processing option chain for {symbol}: {traceback.format_exc()}")
        return pd.DataFrame()

    def filter_strikes(self, option_chain_df, spot_price):
        if spot_price is None or spot_price <= 0:
            logger.warning(f"Invalid spot price ({spot_price}), skipping strike filtering.")
            return pd.DataFrame()
        if option_chain_df.empty:
            logger.debug("Empty option chain to filter_strikes.")
            return pd.DataFrame()
        try:
            chain_to_filter = option_chain_df.copy()
            if 'strike' not in chain_to_filter.columns:
                logger.warning("'strike' column missing in option chain for filtering.")
                return pd.DataFrame()

            chain_to_filter['strike'] = pd.to_numeric(chain_to_filter['strike'], errors='coerce')
            chain_to_filter.dropna(subset=['strike'], inplace=True)
            if chain_to_filter.empty:
                logger.debug("Option chain empty after strike conversion/NaN drop.")
                return pd.DataFrame()

            chain_to_filter.sort_values('strike', inplace=True)

            atm_strike_candidates = chain_to_filter.iloc[(chain_to_filter['strike'] - spot_price).abs().argsort()]
            if atm_strike_candidates.empty:
                logger.warning(f"Could not determine ATM strike for spot {spot_price:.2f}.")
                return pd.DataFrame()
            atm_strike = atm_strike_candidates['strike'].iloc[0]

            unique_strikes = sorted(chain_to_filter['strike'].unique())
            strike_step = spot_price * 0.01
            if len(unique_strikes) > 1:
                strike_steps_arr = np.diff(unique_strikes)
                positive_strike_steps = strike_steps_arr[strike_steps_arr > 0]
                if len(positive_strike_steps) > 0:
                    mode_res = pd.Series(positive_strike_steps).mode()
                    if not mode_res.empty:
                        strike_step = mode_res.iloc[0]
                    else:
                        strike_step = np.median(positive_strike_steps)

            strike_step = max(1.0, float(strike_step))

            num_strikes_away = 5  # ±5 strikes around ATM (wider context for OI analysis)
            lower_bound_strikes = atm_strike - (num_strikes_away * strike_step)
            upper_bound_strikes = atm_strike + (num_strikes_away * strike_step)

            lower_bound_percentage = spot_price * 0.88  # ±12% from spot (captures full breakeven range)
            upper_bound_percentage = spot_price * 1.12

            final_lower_bound = min(lower_bound_strikes, lower_bound_percentage)
            final_upper_bound = max(upper_bound_strikes, upper_bound_percentage)

            final_lower_bound = min(final_lower_bound, atm_strike)
            final_upper_bound = max(final_upper_bound, atm_strike)

            filtered_chain = chain_to_filter[(chain_to_filter['strike'] >= final_lower_bound) & (chain_to_filter['strike'] <= final_upper_bound)]
            logger.debug(f"Filtered {len(filtered_chain)} strikes for spot {spot_price:.2f} (ATM: {atm_strike}, Step: {strike_step:.2f}, Range: {final_lower_bound:.2f}-{final_upper_bound:.2f})")
            return filtered_chain
        except Exception as e:
            logger.error(f"Error filtering strikes: {traceback.format_exc()}")
        return pd.DataFrame()

    def get_spot_price(self, symbol):
        if not self.rate_limiter.wait():
            logger.error(f"Rate limit for spot price {symbol}")
            return None
        try:
            instrument = f"NSE:{symbol.upper()}"
            logger.debug(f"Fetching spot price for {instrument}")
            quote_response = self.kite.quote([instrument])

            if quote_response and instrument in quote_response and quote_response[instrument].get('last_price') is not None:
                quote_data = quote_response[instrument]
                spot_price = quote_data['last_price']

                last_trade_time_from_quote = quote_data.get('timestamp')
                last_trade_time = None

                if last_trade_time_from_quote:
                    if isinstance(last_trade_time_from_quote, datetime):
                        if last_trade_time_from_quote.tzinfo is None:
                            last_trade_time = self.ist_timezone.localize(last_trade_time_from_quote)
                        else:
                            last_trade_time = last_trade_time_from_quote.astimezone(self.ist_timezone)
                    elif isinstance(last_trade_time_from_quote, (int, float)):
                        try:
                            last_trade_time = datetime.fromtimestamp(last_trade_time_from_quote, tz=pytz.utc).astimezone(self.ist_timezone)
                        except Exception as e_ts:
                            logger.warning(f"Could not convert epoch {last_trade_time_from_quote} to datetime for {symbol}: {e_ts}")
                    elif isinstance(last_trade_time_from_quote, str):
                        try:
                            dt_obj = pd.to_datetime(last_trade_time_from_quote)
                            if dt_obj.tzinfo is None: last_trade_time = self.ist_timezone.localize(dt_obj)
                            else: last_trade_time = dt_obj.astimezone(self.ist_timezone)
                        except Exception as e_str_ts:
                             logger.warning(f"Spot price timestamp for {symbol} (str) '{last_trade_time_from_quote}' couldn't be parsed: {e_str_ts}")
                    else:
                        logger.warning(f"Spot price timestamp for {symbol} is in an unexpected format: {type(last_trade_time_from_quote)}")

                    if last_trade_time and (datetime.now(self.ist_timezone) - last_trade_time).total_seconds() > STALE_SPOT_PRICE_THRESHOLD_SECONDS:
                        logger.warning(f"Spot price for {symbol} ({spot_price}) might be stale. Last trade: {last_trade_time.strftime('%Y-%m-%d %H:%M:%S %Z')}")
                else:
                    logger.warning(f"No timestamp found in quote for {symbol}. Spot price ({spot_price}) might be stale.")

                logger.debug(f"Spot price for {symbol}: {spot_price}")
                return spot_price
            else:
                err_msg = quote_response.get(instrument) if quote_response and instrument in quote_response else 'Instrument not in response or no response.'
                logger.error(f"Could not get valid spot price for {instrument}. Response: {err_msg}")
                return None
        except (kiteconnect.exceptions.TokenException, kiteconnect.exceptions.NetworkException) as e_api:
            logger.critical(f"API error fetching spot for {symbol}: {e_api}.")
            if isinstance(e_api, kiteconnect.exceptions.TokenException):
                raise
        except Exception as e:
            logger.error(f"Generic error fetching spot for {symbol}: {traceback.format_exc()}")
        return None

    def _determine_sentiment(self, oi_change_percent, price_change_percent, oi_z_score=None, price_z_score=None,
                             oi_z_threshold=None, price_z_threshold=None):
        oi_thresh = oi_z_threshold if oi_z_threshold is not None else Z_THRESH_OI
        px_thresh = price_z_threshold if price_z_threshold is not None else Z_THRESH_PRICE

        significant_oi_increase = (oi_z_score is not None and oi_z_score > oi_thresh) or \
                                  (oi_change_percent is not None and oi_change_percent > OI_PCT_THRESH_POS)
        significant_oi_decrease = (oi_z_score is not None and oi_z_score < -oi_thresh) or \
                                  (oi_change_percent is not None and oi_change_percent < OI_PCT_THRESH_NEG)

        significant_price_increase = (price_z_score is not None and price_z_score > px_thresh) or \
                                     (price_change_percent is not None and price_change_percent > PRICE_PCT_THRESH_POS)
        significant_price_decrease = (price_z_score is not None and price_z_score < -px_thresh) or \
                                     (price_change_percent is not None and price_change_percent < PRICE_PCT_THRESH_NEG)

        sentiment = "Neutral"
        if significant_oi_increase and significant_price_increase: sentiment = "Long Buildup"
        elif significant_oi_decrease and significant_price_increase: sentiment = "Short Covering"
        elif significant_oi_increase and significant_price_decrease: sentiment = "Short Buildup"
        elif significant_oi_decrease and significant_price_decrease: sentiment = "Long Unwinding"

        oi_log = f"{oi_change_percent:.2f}" if oi_change_percent is not None else "N/A"
        px_log = f"{price_change_percent:.2f}" if price_change_percent is not None else "N/A"
        oi_z_log = f"{oi_z_score:.2f}" if oi_z_score is not None else "N/A"
        px_z_log = f"{price_z_score:.2f}" if price_z_score is not None else "N/A"
        logger.info(f"Sentiment: {sentiment} (OI%{oi_log} Z:{oi_z_log}, Px%{px_log} Z:{px_z_log})")
        return sentiment

    def _get_sentiment_strength(self, sentiment):
        if sentiment and "Buildup" in sentiment: strength = 1.5
        elif sentiment and ("Covering" in sentiment or "Unwinding" in sentiment): strength = 0.8
        else: strength = 0.0
        return strength

    def _combine_trends_simplified(self, oi_change_pct, price_change_pct,
                                   oi_zscore, price_zscore, pcr_oi):
        """Use only 3 proven factors: OI+Price alignment, Z-score strength, PCR signal."""
        try:
            # Factor 1: OI + Price alignment (40% weight)
            oi_pos = OI_PCT_THRESH_POS
            oi_neg = OI_PCT_THRESH_NEG
            px_pos = PRICE_PCT_THRESH_POS
            px_neg = PRICE_PCT_THRESH_NEG

            if oi_change_pct is None: oi_change_pct = 0.0
            if price_change_pct is None: price_change_pct = 0.0

            if oi_change_pct > oi_pos and price_change_pct > px_pos:
                oi_price_score = 8.0  # Bullish
            elif oi_change_pct > oi_pos and price_change_pct < px_neg:
                oi_price_score = 2.0  # Short buildup
            elif oi_change_pct < oi_neg and price_change_pct > px_pos:
                oi_price_score = 8.0  # Short covering
            elif oi_change_pct < oi_neg and price_change_pct < px_neg:
                oi_price_score = 2.0  # Long unwinding
            else:
                oi_price_score = 5.0

            # Factor 2: Z-score strength (30% weight)
            abs_oi_z = abs(oi_zscore) if oi_zscore is not None else 0.0
            abs_px_z = abs(price_zscore) if price_zscore is not None else 0.0
            zscore_avg = (abs_oi_z + abs_px_z) / 2.0
            zscore_score = min(10.0, zscore_avg * 2.5)

            # Factor 3: PCR signal (30% weight)
            pcr_score = 5.0
            if pcr_oi is not None:
                if pcr_oi > 1.3:
                    pcr_score = 8.0  # Bullish
                elif pcr_oi < 0.7:
                    pcr_score = 2.0  # Bearish

            confidence = (oi_price_score * 0.4 + zscore_score * 0.3 + pcr_score * 0.3) * 10.0

            if oi_price_score > 6.5 or (price_change_pct > px_pos and (pcr_oi is not None and pcr_oi > 1.2)):
                sentiment = "Bullish"
            elif oi_price_score < 3.5 or (price_change_pct < px_neg and (pcr_oi is not None and pcr_oi < 0.8)):
                sentiment = "Bearish"
            else:
                sentiment = "Neutral"

            return sentiment, round(confidence, 1)
        except Exception:
            # On any calculation issue, return neutral with low confidence
            return "Neutral", 0.0

    def _combine_trends_refined(self, symbol, sent_curr, strength_curr, oi_curr_z, price_curr_z,
                                sent_next, strength_next, oi_next_z, price_next_z,
                                effective_days_to_expiry,
                                rqi_val, writer_analysis, detected_market_regime,
                                is_next_month_focused_trade,
                                term_structure_slope_val,
                                price_oi_ratio_primary,
                                primary_oi_change_percent,
                                primary_price_zscore,
                                primary_oi_zscore,
                                spot_price_val, 
                                roll_skew_val): 
        # Simplified replacement: map available inputs to the 3-factor combiner
        try:
            # Prefer primary leg metrics where available
            oi_change_pct = primary_oi_change_percent

            # Derive a proxy for price_change_pct from price z-score if actual percent isn't passed
            price_change_pct = 0.0
            if primary_price_zscore is not None:
                if primary_price_zscore > Z_THRESH_PRICE:
                    price_change_pct = PRICE_PCT_THRESH_POS + 0.01
                elif primary_price_zscore < -Z_THRESH_PRICE:
                    price_change_pct = PRICE_PCT_THRESH_NEG - 0.01

            # Choose z-scores from primary leg
            oi_zscore = primary_oi_zscore
            price_zscore = primary_price_zscore

            # PCR from writer analysis (fallback neutral 1.0)
            pcr_oi = 1.0
            if isinstance(writer_analysis, dict):
                pcr_oi = writer_analysis.get("pcr_oi", 1.0)

            sentiment, confidence = self._combine_trends_simplified(
                oi_change_pct, price_change_pct, oi_zscore, price_zscore, pcr_oi
            )

            logger.info(f"{symbol} - Combined (simplified): {sentiment}, Confidence: {confidence:.1f}%")
            return sentiment, confidence
        except Exception:
            logger.error(f"{symbol} - Error in simplified combine. Reverting to Neutral.")
            return "Neutral", 0.0

    def _compute_trend_trust_meta(self, rqi_val, rollover_pct_val, term_structure_slope_val,
                                  effective_days_to_expiry, detected_market_regime):
        def _normalize_metric(value, floor, target):
            if value is None:
                return 0.0
            if target <= floor:
                return 0.0
            if value <= floor:
                return 0.0
            if value >= target:
                return 1.0
            return (value - floor) / (target - floor)

        rqi_score = _normalize_metric(rqi_val, TREND_TRUST_RQI_FLOOR, TRUST_RQI_THRESH)
        roll_score = _normalize_metric(rollover_pct_val, TREND_TRUST_ROLL_PCT_FLOOR, TRUST_ROLL_PCT_THRESH)
        term_score = _normalize_metric(term_structure_slope_val, TREND_TRUST_TERM_SLOPE_FLOOR, TRUST_TERM_SLOPE_THRESH)

        if effective_days_to_expiry is not None:
            if effective_days_to_expiry >= 16:
                days_bucket = "early"
                rqi_weight, roll_weight, term_weight = 0.45, 0.25, 0.30
            elif 6 <= effective_days_to_expiry <= 15:
                days_bucket = "mid"
                rqi_weight, roll_weight, term_weight = 0.40, 0.35, 0.25
            else:
                days_bucket = "late"
                rqi_weight, roll_weight, term_weight = 0.35, 0.40, 0.25
        else:
            days_bucket = "unknown"
            rqi_weight, roll_weight, term_weight = 0.40, 0.35, 0.25

        trend_trust_score = (rqi_score * rqi_weight + roll_score * roll_weight + term_score * term_weight) * 100.0

        trend_trust_required_score = TREND_TRUST_BASE_REQUIRED_SCORE
        if detected_market_regime:
            if "HighVol" in detected_market_regime:
                trend_trust_required_score += 5.0
            elif "ModerateVol" in detected_market_regime:
                trend_trust_required_score += 2.0
            elif detected_market_regime == "SidewaysLowVol":
                trend_trust_required_score -= 5.0
        if effective_days_to_expiry is not None:
            if effective_days_to_expiry > 10:
                trend_trust_required_score -= 5.0
            elif effective_days_to_expiry <= 5:
                trend_trust_required_score += 5.0
        trend_trust_required_score = max(
            TREND_TRUST_REQUIRED_SCORE_MIN,
            min(TREND_TRUST_REQUIRED_SCORE_MAX, trend_trust_required_score)
        )

        trend_trust_meta = {
            'score': trend_trust_score,
            'required_score': trend_trust_required_score,
            'rqi_score': rqi_score,
            'roll_score': roll_score,
            'term_score': term_score,
            'weights': {'rqi': rqi_weight, 'roll': roll_weight, 'term': term_weight},
            'floors_breached': {
                'rqi': (rqi_val is None) or (rqi_val < TREND_TRUST_RQI_FLOOR),
                'roll': (rollover_pct_val is None) or (rollover_pct_val < TREND_TRUST_ROLL_PCT_FLOOR),
                'term': (term_structure_slope_val is None) or (term_structure_slope_val < TREND_TRUST_TERM_SLOPE_FLOOR)
            },
            'effective_days_to_expiry': effective_days_to_expiry,
            'days_bucket': days_bucket
        }
        return trend_trust_meta

    def _select_directional_option(self, filtered_options_df, spot_price, direction):
        if filtered_options_df is None or filtered_options_df.empty or spot_price is None or spot_price <= 0:
            return None

        liquidity_col = 'oi'
        if liquidity_col not in filtered_options_df.columns or filtered_options_df[liquidity_col].sum(skipna=True) == 0:
            liquidity_col = 'volume'
            if liquidity_col not in filtered_options_df.columns or filtered_options_df[liquidity_col].sum(skipna=True) == 0:
                return None

        option_df = filtered_options_df.copy()
        option_df['strike'] = pd.to_numeric(option_df['strike'], errors='coerce')
        option_df.dropna(subset=['strike'], inplace=True)
        if option_df.empty:
            return None

        selected_option_row = None
        if direction == "Bullish":
            calls_df = option_df[option_df['instrument_type'] == 'CE']
            if not calls_df.empty:
                otm_calls = calls_df[(calls_df['strike'] >= spot_price) & (calls_df['strike'] <= spot_price * 1.05)].sort_values(by='strike', ascending=True)
                if not otm_calls.empty:
                    selected_option_row = otm_calls.loc[otm_calls[liquidity_col].idxmax()]
                else:
                    any_otm_calls = calls_df[calls_df['strike'] > spot_price].sort_values(by='strike', ascending=True)
                    if not any_otm_calls.empty:
                        selected_option_row = any_otm_calls.loc[any_otm_calls[liquidity_col].idxmax()]
                    else:
                        itm_calls = calls_df[calls_df['strike'] < spot_price].sort_values(by='strike', ascending=False)
                        if not itm_calls.empty:
                            selected_option_row = itm_calls.loc[itm_calls[liquidity_col].idxmax()]
        elif direction == "Bearish":
            puts_df = option_df[option_df['instrument_type'] == 'PE']
            if not puts_df.empty:
                otm_puts = puts_df[(puts_df['strike'] <= spot_price) & (puts_df['strike'] >= spot_price * 0.95)].sort_values(by='strike', ascending=False)
                if not otm_puts.empty:
                    selected_option_row = otm_puts.loc[otm_puts[liquidity_col].idxmax()]
                else:
                    any_otm_puts = puts_df[puts_df['strike'] < spot_price].sort_values(by='strike', ascending=False)
                    if not any_otm_puts.empty:
                        selected_option_row = any_otm_puts.loc[any_otm_puts[liquidity_col].idxmax()]
                    else:
                        itm_puts = puts_df[puts_df['strike'] > spot_price].sort_values(by='strike', ascending=True)
                        if not itm_puts.empty:
                            selected_option_row = itm_puts.loc[itm_puts[liquidity_col].idxmax()]

        if selected_option_row is None:
            return None

        option_details = {
            'selected_option_symbol': selected_option_row.get('tradingsymbol'),
            'selected_option_strike': selected_option_row.get('strike'),
            'selected_option_type': selected_option_row.get('instrument_type'),
            'selected_option_oi': selected_option_row.get('oi', 0),
            'selected_option_volume': selected_option_row.get('volume', 0),
            'selected_option_premium': selected_option_row.get('last_price')
        }
        return option_details

    def _evaluate_directional_engine(self, symbol, combined_sentiment, base_confidence,
                                     filtered_options_df, spot_price, institutional_breakout,
                                     recommended_holding_period, todays_oi_vs_daily_avg_percent,
                                     todays_net_oi_percent_change, current_realized_vol_daily_pct,
                                     todays_oi_vs_monthly_percent):
        decision = {
            'action': "Skip - No directional bias",
            'confidence': 0.0,
            'context': combined_sentiment,
            'holding_period': recommended_holding_period or "1-3 days",
            'notes': None,
            'option_details': {}
        }

        bullish_set = {"Bullish", "Long Buildup", "Short Covering"}
        bearish_set = {"Bearish", "Short Buildup", "Long Unwinding"}
        direction = None
        if combined_sentiment in bullish_set:
            direction = "Bullish"
        elif combined_sentiment in bearish_set:
            direction = "Bearish"

        if direction is None:
            return decision

        adjusted_conf = base_confidence
        notes = []
        if institutional_breakout:
            adjusted_conf = min(100.0, adjusted_conf + 15.0)
            notes.append("Institutional breakout thrust")
        if todays_oi_vs_daily_avg_percent is not None and todays_oi_vs_daily_avg_percent > 130.0:
            adjusted_conf = min(100.0, adjusted_conf + 7.0)
            notes.append("Intraday OI thrust >130% of daily avg")
        if todays_net_oi_percent_change is not None:
            if direction == "Bullish" and todays_net_oi_percent_change < -5.0:
                adjusted_conf = max(0.0, adjusted_conf - 10.0)
                notes.append("Net OI drop contradicts bullish bias")
            if direction == "Bearish" and todays_net_oi_percent_change > 5.0:
                adjusted_conf = max(0.0, adjusted_conf - 10.0)
                notes.append("Net OI rise contradicts bearish bias")
        if current_realized_vol_daily_pct is not None and current_realized_vol_daily_pct > 2.5:
            adjusted_conf = max(0.0, adjusted_conf - 5.0)
            notes.append("High day-to-day volatility ( >2.5%)")
        if todays_oi_vs_monthly_percent is not None and todays_oi_vs_monthly_percent > 150.0:
            adjusted_conf = min(100.0, adjusted_conf + 5.0)
            notes.append("OI surge vs monthly avg")

        if adjusted_conf < 55.0:
            decision['notes'] = "; ".join(notes) if notes else "Insufficient directional conviction"
            return decision

        option_details = self._select_directional_option(filtered_options_df, spot_price, direction)
        if option_details is None or option_details.get('selected_option_symbol') is None:
            decision['notes'] = "No suitable option contract for directional play"
            return decision

        option_oi = option_details.get('selected_option_oi', 0) or 0
        option_vol = option_details.get('selected_option_volume', 0) or 0
        if option_oi < MIN_OPTION_OI or option_vol < MIN_OPTION_VOLUME:
            adjusted_conf = max(0.0, adjusted_conf - 15.0)
            notes.append("Low option liquidity")
            if adjusted_conf < 55.0:
                decision['notes'] = "; ".join(notes)
                return decision

        action_type = "CALL" if direction == "Bullish" else "PUT"
        decision.update({
            'action': f"BUY {action_type} {option_details['selected_option_symbol']}",
            'confidence': round(adjusted_conf, 1),
            'context': combined_sentiment,
            'holding_period': recommended_holding_period or ("2-3 days" if institutional_breakout else "1-3 days"),
            'notes': "; ".join(notes) if notes else "Momentum-aligned directional setup",
            'option_details': option_details
        })
        return decision

    def _calculate_wall_distance_pct(self, spot_price, wall_strike):
        try:
            if spot_price is None or wall_strike is None or spot_price <= 0 or wall_strike <= 0:
                return None
            return abs(float(spot_price) - float(wall_strike)) / float(spot_price) * 100.0
        except (ValueError, TypeError):
            return None

    def _estimate_iv_percentile(self, avg_iv, realized_vol_annualized):
        if avg_iv is None or realized_vol_annualized is None or realized_vol_annualized <= 0:
            return None
        try:
            ratio = float(avg_iv) / float(realized_vol_annualized)
            # Map ratio range [0.8, 2.0] to percentile [0, 100]
            lower_bound = 0.8
            upper_bound = 2.0
            percentile = (ratio - lower_bound) / (upper_bound - lower_bound) * 100.0
            return max(0.0, min(100.0, percentile))
        except (ValueError, TypeError):
            return None

    def _calculate_carry_score(self, rqi_val, rollover_pct_val, term_structure_slope_val, roll_cost_pct):
        components = []

        def _normalize(value, lower, upper):
            if value is None:
                return None
            try:
                value = float(value)
                if value <= lower:
                    return 0.0
                if value >= upper:
                    return 1.0
                return (value - lower) / (upper - lower)
            except (ValueError, TypeError):
                return None

        rqi_component = _normalize(rqi_val, SELLER_MIN_RQI_FOR_CARRY, 10.0)
        if rqi_component is not None:
            components.append(rqi_component)

        roll_component = _normalize(rollover_pct_val, SELLER_MIN_ROLLOVER_FOR_CARRY, 90.0)
        if roll_component is not None:
            components.append(roll_component)

        term_component = _normalize(term_structure_slope_val, SELLER_MIN_TERM_SLOPE_FOR_CARRY, SELLER_MIN_TERM_SLOPE_FOR_CARRY + 0.5)
        if term_component is not None:
            components.append(term_component)

        if roll_cost_pct is not None:
            try:
                roll_cost_pct = float(roll_cost_pct)
                if roll_cost_pct <= SELLER_MAX_ROLL_COST_PCT:
                    components.append(1.0)
                else:
                    penalty = max(0.0, 1.0 - ((roll_cost_pct - SELLER_MAX_ROLL_COST_PCT) / SELLER_MAX_ROLL_COST_PCT))
                    components.append(penalty)
            except (ValueError, TypeError):
                pass

        if not components:
            return None
        return sum(components) / len(components)

    def _calculate_hhi(self, oi_values):
        try:
            filtered = [float(v) for v in oi_values if v is not None and float(v) > 0]
            total = sum(filtered)
            if total <= 0:
                return 0.0
            shares = [(v / total) for v in filtered]
            return round(sum(s * s for s in shares), 4)
        except Exception:
            return 0.0

    def _calculate_wall_strength_score(self, concentration_pct, wall_distance_pct, second_ratio):
        try:
            if concentration_pct is None or wall_distance_pct is None:
                return 0.0
            conc_score = min(1.0, max(0.0, concentration_pct) / 80.0)  # 80%+ => max score
            distance_score = max(0.0, 1.0 - ((wall_distance_pct or SELLER_MAX_WALL_DISTANCE_PCT) / SELLER_MAX_WALL_DISTANCE_PCT))
            dispersion_score = max(0.0, 1.0 - (second_ratio or 0.0))
            raw = 0.5 * conc_score + 0.3 * distance_score + 0.2 * dispersion_score
            return round(raw * 100.0, 1)
        except Exception:
            return 0.0

    def _evaluate_seller_engine(self, atm_strike, straddle_entry_ok, straddle_viability_tag,
                                straddle_confidence, straddle_rationale_str,
                                straddle_entry_blockers_str, straddle_entry_notes_str,
                                straddle_position_adjustment, straddle_profit_target_note,
                                writer_analysis, trend_trust_meta, structural_inputs):
        decision = {
            'action': "Skip",
            'strategy': None,
            'confidence': 0.0,
            'notes': straddle_rationale_str,
            'blockers': straddle_entry_blockers_str,
            'position_adjustment': straddle_position_adjustment,
            'profit_target': straddle_profit_target_note,
            'writer_context': writer_analysis.get("dominant_side") if isinstance(writer_analysis, dict) else None,
            'trend_trust_score': trend_trust_meta.get('score') if trend_trust_meta else None,
            'walls_ok': None,
            'writer_concentration_ok': None,
            'iv_percentile': structural_inputs.get('iv_percentile') if structural_inputs else None,
            'carry_score': structural_inputs.get('carry_score') if structural_inputs else None,
            'structural_blockers': None
        }

        structural_blockers = []
        walls_ok = structural_inputs.get('walls_ok') if structural_inputs else False
        concentration_ok = structural_inputs.get('concentration_ok') if structural_inputs else False
        iv_percentile = structural_inputs.get('iv_percentile') if structural_inputs else None
        carry_score = structural_inputs.get('carry_score') if structural_inputs else None

        iv_ok = None
        if structural_inputs and structural_inputs.get('iv_ok') is not None:
            iv_ok = bool(structural_inputs.get('iv_ok'))
        else:
            iv_ok = iv_percentile is not None and iv_percentile >= SELLER_MIN_IV_PERCENTILE

        carry_ok = None
        if structural_inputs and structural_inputs.get('carry_ok') is not None:
            carry_ok = bool(structural_inputs.get('carry_ok'))
        else:
            carry_ok = carry_score is not None and carry_score >= SELLER_MIN_CARRY_SCORE

        hhi_ok = structural_inputs.get('hhi_ok') if structural_inputs else False
        wall_strength_ok = structural_inputs.get('wall_strength_ok') if structural_inputs else False

        decision['walls_ok'] = walls_ok
        decision['writer_concentration_ok'] = concentration_ok
        decision['iv_percentile'] = iv_percentile
        decision['carry_score'] = carry_score
        decision['writer_hhi_ok'] = hhi_ok
        decision['writer_wall_strength_ok'] = wall_strength_ok

        if not walls_ok:
            structural_blockers.append(f"Walls farther than {SELLER_MAX_WALL_DISTANCE_PCT:.1f}% from spot")
        if not concentration_ok:
            structural_blockers.append(f"OI concentration < {SELLER_MIN_OI_CONCENTRATION_PCT:.0f}%")
        if not iv_ok:
            structural_blockers.append(f"IV percentile < {SELLER_MIN_IV_PERCENTILE:.0f}")
        if not carry_ok:
            structural_blockers.append("Carry/Roll quality weak")
        if not hhi_ok:
            structural_blockers.append(f"OI HHI < {SELLER_MIN_HHI:.2f}")
        if not wall_strength_ok:
            structural_blockers.append(f"Wall strength < {SELLER_MIN_WALL_STRENGTH_SCORE:.0f}")

        if structural_blockers:
            decision['notes'] = straddle_rationale_str or "Seller criteria not met"
            blockers_str = "; ".join(structural_blockers)
            decision['blockers'] = blockers_str
            decision['structural_blockers'] = blockers_str
            return decision

        if straddle_entry_ok == "Eligible" and straddle_confidence is not None:
            decision.update({
                'action': f"SELL STRADDLE ATM {atm_strike}" if atm_strike is not None else "SELL STRADDLE",
                'strategy': straddle_viability_tag or "Neutral",
                'confidence': round(straddle_confidence, 1),
                'notes': straddle_rationale_str or straddle_entry_notes_str,
                'blockers': None
            })
        else:
            reason = straddle_entry_blockers_str or straddle_entry_notes_str or "Seller criteria not met"
            decision['notes'] = reason

        relaxed_used = structural_inputs.get('relaxed_rules_used') if structural_inputs else None
        if relaxed_used:
            relax_msg = f"Relaxed structural criteria applied ({', '.join(relaxed_used)})"
            if decision['notes']:
                decision['notes'] = f"{decision['notes']} | {relax_msg}"
            else:
                decision['notes'] = relax_msg

        return decision

    def analyze_writer_strength(self, filtered_options_df, spot_price):
        if filtered_options_df is None or filtered_options_df.empty:
            return {"call_writer_strength_percent": 0.0, "put_writer_strength_percent": 0.0,
                    "dominant_side": "Neutral (No Options Data)", "pcr_oi": 1.0,
                    "max_call_oi_strike": None, "max_put_oi_strike": None}

        calls = filtered_options_df[filtered_options_df['instrument_type'] == 'CE']
        puts = filtered_options_df[filtered_options_df['instrument_type'] == 'PE']

        total_call_oi = calls['oi'].sum(skipna=True) if not calls.empty and 'oi' in calls.columns else 0
        total_put_oi = puts['oi'].sum(skipna=True) if not puts.empty and 'oi' in puts.columns else 0

        max_call_strike_info, max_put_strike_info = None, None
        max_call_oi_value, max_put_oi_value = 0, 0
        
        if not calls.empty and total_call_oi > 0 and 'strike' in calls.columns:
             max_call_strike_info = calls.loc[calls['oi'].idxmax()]
             max_call_oi_value = max_call_strike_info['oi']
        if not puts.empty and total_put_oi > 0 and 'strike' in puts.columns:
             max_put_strike_info = puts.loc[puts['oi'].idxmax()]
             max_put_oi_value = max_put_strike_info['oi']

        # Calculate OI concentration percentages
        call_concentration_pct = (max_call_oi_value / total_call_oi * 100) if total_call_oi > 0 else 0
        put_concentration_pct = (max_put_oi_value / total_put_oi * 100) if total_put_oi > 0 else 0

        call_hhi = self._calculate_hhi(calls['oi'].tolist()) if not calls.empty and 'oi' in calls.columns else 0.0
        put_hhi = self._calculate_hhi(puts['oi'].tolist()) if not puts.empty and 'oi' in puts.columns else 0.0

        # Find second highest OI strikes for spread detection
        calls_by_oi = calls.sort_values('oi', ascending=False) if not calls.empty else pd.DataFrame()
        puts_by_oi = puts.sort_values('oi', ascending=False) if not puts.empty else pd.DataFrame()

        second_call_strike = calls_by_oi.iloc[1]['strike'] if len(calls_by_oi) > 1 else None
        second_call_oi_ratio = (calls_by_oi.iloc[1]['oi'] / max_call_oi_value) if len(calls_by_oi) > 1 and max_call_oi_value > 0 else 0

        second_put_strike = puts_by_oi.iloc[1]['strike'] if len(puts_by_oi) > 1 else None
        second_put_oi_ratio = (puts_by_oi.iloc[1]['oi'] / max_put_oi_value) if len(puts_by_oi) > 1 and max_put_oi_value > 0 else 0

        total_oi = total_call_oi + total_put_oi
        call_strength_percent = (total_call_oi / total_oi * 100) if total_oi > 0 else 0.0
        put_strength_percent = (total_put_oi / total_oi * 100) if total_oi > 0 else 0.0

        pcr_oi = total_put_oi / total_call_oi if total_call_oi > 0 else float('inf') if total_put_oi > 0 else 1.0

        max_call_strike_val = max_call_strike_info['strike'] if max_call_strike_info is not None else None
        max_put_strike_val = max_put_strike_info['strike'] if max_put_strike_info is not None else None
        call_wall_distance_pct = self._calculate_wall_distance_pct(spot_price, max_call_strike_val)
        put_wall_distance_pct = self._calculate_wall_distance_pct(spot_price, max_put_strike_val)
        call_wall_strength = self._calculate_wall_strength_score(call_concentration_pct, call_wall_distance_pct, second_call_oi_ratio)
        put_wall_strength = self._calculate_wall_strength_score(put_concentration_pct, put_wall_distance_pct, second_put_oi_ratio)

        if pcr_oi > 1.3: dominant_side = "Strong Put Writer Support (Bullish)"
        elif pcr_oi >= 1.0 and pcr_oi <= 1.3 : dominant_side = "Moderate Put Writer Support (Mildly Bullish)"
        elif pcr_oi < 0.7: dominant_side = "Strong Call Writer Resistance (Bearish)"
        elif pcr_oi < 1.0 and pcr_oi >= 0.7: dominant_side = "Moderate Call Writer Resistance (Mildly Bearish)"
        else: dominant_side = "Neutral / Balanced Writers"

        if total_oi == 0 : dominant_side = "Neutral (No OI)"

        logger.info(f"Writer Analysis: PCR(OI)={pcr_oi:.2f}, Dominant={dominant_side}, TotalCallOI={total_call_oi}, TotalPutOI={total_put_oi}, MaxCallOI={int(max_call_oi_value)}, MaxPutOI={int(max_put_oi_value)}, CallConc={call_concentration_pct:.1f}%, PutConc={put_concentration_pct:.1f}%")
        return {
            "call_writer_strength_percent": round(call_strength_percent,2),
            "put_writer_strength_percent": round(put_strength_percent,2),
            "dominant_side": dominant_side, "pcr_oi": round(pcr_oi,2),
            "max_call_oi_strike": max_call_strike_val,
            "max_put_oi_strike": max_put_strike_val,
            # Phase 1: OI Spatial Metrics
            "max_call_oi_value": int(max_call_oi_value),
            "max_put_oi_value": int(max_put_oi_value),
            "call_oi_concentration_pct": round(call_concentration_pct, 1),
            "put_oi_concentration_pct": round(put_concentration_pct, 1),
            "second_call_strike": second_call_strike,
            "second_call_oi_ratio": round(second_call_oi_ratio, 2),
            "second_put_strike": second_put_strike,
            "second_put_oi_ratio": round(second_put_oi_ratio, 2),
            "call_oi_hhi": round(call_hhi, 4),
            "put_oi_hhi": round(put_hhi, 4),
            "call_wall_distance_pct": round(call_wall_distance_pct, 2) if call_wall_distance_pct is not None else None,
            "put_wall_distance_pct": round(put_wall_distance_pct, 2) if put_wall_distance_pct is not None else None,
            "call_wall_strength_score": call_wall_strength,
            "put_wall_strength_score": put_wall_strength
        }

    def calculate_rollover(self, current_oi_latest, next_oi_latest):
        try:
            current_oi = float(current_oi_latest) if current_oi_latest is not None else 0.0
            next_oi = float(next_oi_latest) if next_oi_latest is not None else 0.0
            current_oi = max(0, current_oi); next_oi = max(0, next_oi)
            total_series_oi = current_oi + next_oi
            if total_series_oi == 0: return 0.0
            return (next_oi / total_series_oi) * 100
        except (ValueError, TypeError) as e:
            logger.error(f"Error calculating rollover: {e}. Inputs: current={current_oi_latest}, next={next_oi_latest}")
            return 0.0

    def calculate_term_structure_slope(self, prices):
        if not prices or len(prices) < 2 or prices[0] is None or prices[1] is None: return []
        try:
            price0, price1 = float(prices[0]), float(prices[1])
            if price0 == 0: return []
            return [((price1 - price0) / price0) * 100]
        except (ValueError, TypeError) as e:
            logger.error(f"Error calculating term structure: {e}. Prices: {prices}")
            return []

    def calculate_rollover_quality_index(self, current_oi_change_percent, next_oi_change_percent,
                                         next_price_change_percent, current_avg_volume, next_avg_volume):
        try:
            next_oi_chg_perc = float(next_oi_change_percent) if next_oi_change_percent is not None else 0.0
            next_price_chg_perc = float(next_price_change_percent) if next_price_change_percent is not None else 0.0
            curr_vol = float(current_avg_volume) if current_avg_volume is not None and current_avg_volume > 0 else 1.0
            next_vol = float(next_avg_volume) if next_avg_volume is not None and next_avg_volume >= 0 else 0.0

            price_action_score = 0.0
            if next_oi_chg_perc > 2.0:
                if next_price_chg_perc > 0.2: price_action_score = 10
                elif next_price_chg_perc >= -0.2: price_action_score = 7
                else: price_action_score = 4
            elif next_oi_chg_perc < -2.0:
                if next_price_chg_perc < -0.2: price_action_score = 2
                elif next_price_chg_perc <= 0.2: price_action_score = 1
                else: price_action_score = 0
            else:
                if abs(next_price_chg_perc) < 0.2: price_action_score = 5
                elif next_price_chg_perc > 0.2 : price_action_score = 6
                else: price_action_score = 3

            volume_ratio = next_vol / curr_vol if curr_vol > 0 else 0.0
            volume_score = min(10, volume_ratio * 10)
            if next_vol == 0 and curr_vol > 0 : volume_score = 0

            rqi = max(0.0, min(10.0, (0.7 * price_action_score) + (0.3 * volume_score)))
            logger.debug(f"RQI Calc: next_oi_chg%={next_oi_chg_perc:.1f}, next_px_chg%={next_price_chg_perc:.1f}, curr_vol={curr_vol:.0f}, next_vol={next_vol:.0f} -> PxScore={price_action_score:.1f}, VolScore={volume_score:.1f} => RQI={rqi:.1f}")
            return round(rqi, 1)
        except (ValueError, TypeError) as e:
            logger.error(f"Error calculating RQI: {e}")
            return 0.0

    def calculate_roll_cost(self, current_price, next_price, spot_price):
        try:
            if not all(p is not None and isinstance(p, (int, float)) for p in [current_price, next_price, spot_price]):
                return None, None
            if spot_price == 0:
                return (next_price - current_price) if current_price is not None and next_price is not None else None, None

            roll_cost_points = next_price - current_price
            roll_cost_percent = (roll_cost_points / spot_price) * 100
            return roll_cost_points, roll_cost_percent
        except (ValueError, TypeError) as e:
            logger.error(f"Error calculating roll cost: {e}")
            return None, None

    def _get_baseline_stats(self, instrument_token, end_date_obj, contract_type="future"):
        if contract_type == "future":
            baseline_days_config = BASELINE_DAYS_FOR_FUTURES_ZSCORE
            min_trading_days_config = MIN_FUT_BASELINE_TRADING_DAYS_FOR_ZSCORE
            fetch_buffer_days = 45
        else: 
            baseline_days_config = BASELINE_DAYS_FOR_INDEX_ZSCORE
            min_trading_days_config = MIN_INDEX_BASELINE_TRADING_DAYS_FOR_ZSCORE
            fetch_buffer_days = 75

        from_date_baseline = end_date_obj - timedelta(days=baseline_days_config + fetch_buffer_days)
        to_date_baseline = end_date_obj - timedelta(days=1)

        df_baseline_raw = self.get_historical_data(instrument_token, from_date_baseline, to_date_baseline,
                                                 interval="day", cap_outliers_flag=True, contract_type=contract_type)

        if df_baseline_raw is None or df_baseline_raw.empty:
            logger.warning(f"No raw baseline data returned for Z-score for token {instrument_token} ({contract_type}).")
            return None
        if len(df_baseline_raw) < min_trading_days_config :
             logger.warning(f"Insufficient raw baseline data for Z-score for token {instrument_token} ({contract_type}) (fetched {len(df_baseline_raw)}, needed >{min_trading_days_config} raw days).")
             return None

        df_baseline = df_baseline_raw[df_baseline_raw['date'].dt.weekday < 5].copy()
        if len(df_baseline) < min_trading_days_config:
            logger.warning(f"Insufficient baseline trading days for Z-score for token {instrument_token} ({contract_type}) ({len(df_baseline)}, needed {min_trading_days_config} trading days).")
            return None

        if contract_type == "future" and 'oi' in df_baseline.columns:
            df_baseline['oi'] = pd.to_numeric(df_baseline['oi'], errors='coerce')
            df_baseline['oi_change'] = df_baseline['oi'].diff()
        else:
            df_baseline['oi_change'] = np.nan

        df_baseline['close'] = pd.to_numeric(df_baseline['close'], errors='coerce')
        df_baseline['price_change_pct'] = df_baseline['close'].pct_change() * 100

        df_baseline.dropna(subset=['price_change_pct'], inplace=True)
        if contract_type == "future":
             df_baseline.dropna(subset=['oi_change'], inplace=True)

        if df_baseline.empty or len(df_baseline) < (min_trading_days_config - 5):
            logger.warning(f"Not enough data for baseline stats after diff/dropna for {instrument_token} ({contract_type}) ({len(df_baseline)} days).")
            return None

        stats = {
            'mean_oi_change': df_baseline['oi_change'].mean() if 'oi_change' in df_baseline and df_baseline['oi_change'].notna().any() else np.nan,
            'std_oi_change': df_baseline['oi_change'].std() if 'oi_change' in df_baseline and df_baseline['oi_change'].notna().any() else np.nan,
            'mean_price_change_pct': df_baseline['price_change_pct'].mean() if df_baseline['price_change_pct'].notna().any() else np.nan,
            'std_price_change_pct': df_baseline['price_change_pct'].std() if df_baseline['price_change_pct'].notna().any() else np.nan
        }

        if contract_type == "future":
            if pd.isna(stats['mean_oi_change']):
                stats['mean_oi_change'] = None
                stats['std_oi_change'] = None
            elif pd.isna(stats['std_oi_change']) or stats['std_oi_change'] < 1e-6: stats['std_oi_change'] = 1e-6

        if pd.isna(stats['mean_price_change_pct']):
             stats['mean_price_change_pct'] = None
             stats['std_price_change_pct'] = None
        elif pd.isna(stats['std_price_change_pct']) or stats['std_price_change_pct'] < 1e-6: stats['std_price_change_pct'] = 1e-6

        logger.debug(f"Baseline stats for token {instrument_token} ({contract_type}, from {len(df_baseline)} days): {stats}")
        return stats

    def _compute_dynamic_z_thresholds(self, baseline_stats):
        try:
            if not baseline_stats:
                return Z_THRESH_OI, Z_THRESH_PRICE

            std_price_change_pct = baseline_stats.get('std_price_change_pct')
            std_oi_change = baseline_stats.get('std_oi_change')

            # Price z-threshold scaling based on realized daily return std (percent)
            price_std = None
            if std_price_change_pct is not None and not pd.isna(std_price_change_pct) and std_price_change_pct > 0:
                price_std = float(std_price_change_pct)

            # OI scaling based on OI change std; fallback to price vol if OI missing
            oi_std = None
            if std_oi_change is not None and not pd.isna(std_oi_change) and std_oi_change > 0:
                oi_std = float(std_oi_change)

            def clamp(val, lo, hi):
                return max(lo, min(hi, val))

            # Compute multipliers; if price_std unknown, keep baseline
            price_mult = clamp((price_std / DYN_Z_REF_DAILY_RETURN_PCT) if price_std else 1.0, DYN_Z_MULT_MIN, DYN_Z_MULT_MAX)

            # For OI, if oi_std unavailable, proxy with price multiplier
            oi_mult = price_mult if oi_std is None else clamp(1.0, DYN_Z_MULT_MIN, DYN_Z_MULT_MAX)

            # Apply scaling to base thresholds
            dyn_oi_thresh = Z_THRESH_OI * oi_mult
            dyn_price_thresh = Z_THRESH_PRICE * price_mult

            return dyn_oi_thresh, dyn_price_thresh
        except Exception:
            logger.debug("Falling back to static Z thresholds due to dynamic scaling error.")
            return Z_THRESH_OI, Z_THRESH_PRICE

    def _calculate_z_score(self, value, mean, std):
        if value is None or mean is None or std is None: return None
        if abs(std) < 1e-9 : return 0.0 # Avoid division by zero or very small std
        try:
            return (float(value) - float(mean)) / float(std)
        except (ValueError, TypeError):
            logger.warning(f"Could not calculate Z-score for value={value}, mean={mean}, std={std}")
            return None

    def analyze_trend_advanced(self, symbol, trading_days=7):
        try:
            current_time_obj = datetime.now(self.ist_timezone)
            logger.info(f"Starting ADVANCED analysis for {symbol} at {current_time_obj.strftime('%Y-%m-%d %H:%M:%S')} with Market Regime: {self.detected_market_regime}")

            spot_price_val = self.get_spot_price(symbol)
            if spot_price_val is None:
                logger.warning(f"Could not get spot price for {symbol}. Skipping analysis.")
                return None

            futures = self.get_futures_chain(symbol)
            current_fut = futures.get('current')
            next_fut = futures.get('next')
            if not current_fut:
                logger.warning(f"No current future contract found for {symbol}. Skipping.")
                return None

            # Liquidity Check (remains the same)
            min_liquidity_check_days = 20
            liquidity_fetch_calendar_days = int(min_liquidity_check_days * 1.8) + 30
            temp_end_date_obj = current_time_obj.date()
            temp_start_date_obj = temp_end_date_obj - timedelta(days=liquidity_fetch_calendar_days)
            current_fut_temp_data = self.get_historical_data(current_fut['instrument_token'], temp_start_date_obj, temp_end_date_obj,
                                                             interval="day", cap_outliers_flag=False, contract_type="future")
            if not current_fut_temp_data.empty and 'volume' in current_fut_temp_data and 'oi' in current_fut_temp_data and len(current_fut_temp_data) >= min_liquidity_check_days :
                current_fut_temp_data['volume'] = pd.to_numeric(current_fut_temp_data['volume'], errors='coerce')
                current_fut_temp_data['oi'] = pd.to_numeric(current_fut_temp_data['oi'], errors='coerce')
                avg_vol = current_fut_temp_data['volume'].dropna().tail(min_liquidity_check_days).mean()
                avg_oi = current_fut_temp_data['oi'].dropna().tail(min_liquidity_check_days).mean()
                if pd.isna(avg_vol) or pd.isna(avg_oi) or avg_vol < MIN_FUT_AVG_VOLUME or avg_oi < MIN_FUT_AVG_OI:
                    logger.info(f"{symbol} current future ({current_fut['tradingsymbol']}) fails liquidity (AvgVol: {avg_vol:.0f}, AvgOI: {avg_oi:.0f}). Skipping.")
                    return None
            else:
                logger.warning(f"Could not get sufficient temp data for liquidity check of {current_fut['tradingsymbol']}. Skipping.")
                return None

            baseline_end_date = current_time_obj.date()
            current_fut_baseline_stats = self._get_baseline_stats(current_fut['instrument_token'], baseline_end_date, contract_type="future")
            next_fut_baseline_stats = self._get_baseline_stats(next_fut['instrument_token'], baseline_end_date, contract_type="future") if next_fut else None

            analysis_period_calendar_days = int(trading_days * 1.8) + 20
            analysis_fetch_start_date = baseline_end_date - timedelta(days=analysis_period_calendar_days)
            analysis_fetch_end_date = baseline_end_date

            current_data_raw_df = self.get_historical_data(current_fut['instrument_token'], analysis_fetch_start_date, analysis_fetch_end_date,
                                                           interval="day", cap_outliers_flag=True, contract_type="future")
            current_hist_df = current_data_raw_df[current_data_raw_df['date'].dt.weekday < 5].tail(trading_days).copy() if not current_data_raw_df.empty else pd.DataFrame()

            next_hist_df = pd.DataFrame() # Initialize next_hist_df
            if next_fut:
                next_data_raw_df = self.get_historical_data(next_fut['instrument_token'], analysis_fetch_start_date, analysis_fetch_end_date,
                                                            interval="day", cap_outliers_flag=True, contract_type="future")
                next_hist_df = next_data_raw_df[next_data_raw_df['date'].dt.weekday < 5].tail(trading_days).copy() if not next_data_raw_df.empty else pd.DataFrame()


            if current_hist_df.empty or len(current_hist_df) < trading_days:
                logger.warning(f"Insufficient analysis data for {symbol} current fut ({len(current_hist_df)}/{trading_days} days).")
                return None
            
            if 'oi' not in current_hist_df.columns: # Should ideally not happen if data is fetched correctly
                logger.warning(f"'oi' column missing in current_hist_df for {symbol}. Cannot calculate OI metrics.")
                # Depending on strictness, you might return None or try to proceed without OI specific metrics
                current_hist_df['oi'] = np.nan # Add a NaN column to prevent further errors, though results will be impacted
            else:
                current_hist_df['oi'] = pd.to_numeric(current_hist_df['oi'], errors='coerce')


            analysis_start_date_actual = current_hist_df['date'].iloc[0].date()
            analysis_end_date_actual = current_hist_df['date'].iloc[-1].date()

            # Current month calculations (over analysis window `trading_days`)
            current_hist_df['open'] = pd.to_numeric(current_hist_df['open'], errors='coerce')
            current_hist_df['close'] = pd.to_numeric(current_hist_df['close'], errors='coerce')
            current_hist_df['volume'] = pd.to_numeric(current_hist_df['volume'], errors='coerce')
            current_hist_df['high'] = pd.to_numeric(current_hist_df['high'], errors='coerce')
            current_hist_df['low'] = pd.to_numeric(current_hist_df['low'], errors='coerce')
            
            current_oi_initial = current_hist_df['oi'].iloc[0] if pd.notna(current_hist_df['oi'].iloc[0]) else None
            current_oi_final = current_hist_df['oi'].iloc[-1] if pd.notna(current_hist_df['oi'].iloc[-1]) else None
            
            current_oi_period_change = (current_oi_final - current_oi_initial) if current_oi_final is not None and current_oi_initial is not None else 0.0
            current_oi_change_pct = (current_oi_period_change / current_oi_initial * 100) if current_oi_initial is not None and current_oi_initial != 0 else 0.0
            
            current_price_initial = current_hist_df['open'].iloc[0] if pd.notna(current_hist_df['open'].iloc[0]) else None
            current_price_final = current_hist_df['close'].iloc[-1] if pd.notna(current_hist_df['close'].iloc[-1]) else None
            current_price_period_change_pct = ((current_price_final - current_price_initial) / current_price_initial * 100) if current_price_initial is not None and current_price_initial != 0 and current_price_final is not None else 0.0
            
            # REALIZED VOLATILITY CALCULATION (for straddle strategy)
            # Calculate daily returns and volatility metrics
            current_hist_df['daily_return_pct'] = current_hist_df['close'].pct_change() * 100
            current_hist_df['daily_range_pct'] = ((current_hist_df['high'] - current_hist_df['low']) / current_hist_df['close']) * 100
            
            # Realized volatility (std dev of daily returns) - annualized
            daily_returns = current_hist_df['daily_return_pct'].dropna()
            if len(daily_returns) >= 3:
                current_realized_vol_daily_pct = daily_returns.std()  # Daily std dev
                current_realized_vol_annualized = current_realized_vol_daily_pct * np.sqrt(252)  # Annualized
                current_avg_abs_daily_move_pct = daily_returns.abs().mean()  # Average absolute daily move
                current_avg_daily_range_pct = current_hist_df['daily_range_pct'].dropna().mean()  # Avg high-low range
                current_max_single_day_move_pct = daily_returns.abs().max()  # Largest single-day move
                
                # HISTORICAL MAX MOVE DETECTION (breakeven breach risk)
                # Calculate max upswing and max drawdown over the window
                close_prices = current_hist_df['close'].dropna()
                if len(close_prices) >= 2:
                    current_max_upswing_pct = ((close_prices.max() / close_prices.min()) - 1) * 100
                    current_max_drawdown_pct = ((close_prices.min() / close_prices.max()) - 1) * 100
                    current_max_excursion_pct = max(current_max_upswing_pct, abs(current_max_drawdown_pct))
                else:
                    current_max_upswing_pct = None
                    current_max_drawdown_pct = None
                    current_max_excursion_pct = None
            else:
                current_realized_vol_daily_pct = None
                current_realized_vol_annualized = None
                current_avg_abs_daily_move_pct = None
                current_avg_daily_range_pct = None
                current_max_single_day_move_pct = None
                current_max_upswing_pct = None
                current_max_drawdown_pct = None
                current_max_excursion_pct = None
            
            current_oi_z, current_price_z = None, None
            avg_daily_oi_change_in_analysis_window = current_oi_period_change / len(current_hist_df) if len(current_hist_df) > 0 and current_oi_period_change is not None else 0.0

            if current_fut_baseline_stats:
                current_oi_z = self._calculate_z_score(avg_daily_oi_change_in_analysis_window, current_fut_baseline_stats.get('mean_oi_change'), current_fut_baseline_stats.get('std_oi_change'))
                avg_daily_price_change_pct = current_price_period_change_pct / len(current_hist_df) if len(current_hist_df) > 0 and current_price_period_change_pct is not None else 0.0
                current_price_z = self._calculate_z_score(avg_daily_price_change_pct, current_fut_baseline_stats.get('mean_price_change_pct'), current_fut_baseline_stats.get('std_price_change_pct'))
            
            current_latest_price = current_price_final
            current_latest_oi = current_oi_final
            current_avg_volume = current_hist_df['volume'].dropna().mean() if not current_hist_df['volume'].dropna().empty else 0.0

            # --- Existing OI Metrics (Calculated for current future) ---
            daily_avg_oi_change_val = avg_daily_oi_change_in_analysis_window
            daily_avg_oi_percent_change_val = (current_oi_change_pct / len(current_hist_df)) \
                if len(current_hist_df) > 0 and current_oi_change_pct is not None else None

            current_month_monthly_oi_change_val = None
            current_monthly_oi_percent_change_val = None
            num_trading_days_in_month_so_far = 0
            avg_daily_change_from_monthly_trend_val = None

            month_start_date_obj = analysis_fetch_end_date.replace(day=1)
            current_fut_monthly_data_df_raw = self.get_historical_data(
                current_fut['instrument_token'],
                month_start_date_obj,
                analysis_fetch_end_date, 
                interval="day",
                cap_outliers_flag=True, 
                contract_type="future"
            )

            if not current_fut_monthly_data_df_raw.empty and 'oi' in current_fut_monthly_data_df_raw.columns:
                current_fut_monthly_data_df = current_fut_monthly_data_df_raw[
                    current_fut_monthly_data_df_raw['date'].dt.weekday < 5
                ].copy()
                current_fut_monthly_data_df['oi'] = pd.to_numeric(current_fut_monthly_data_df['oi'], errors='coerce')

                if not current_fut_monthly_data_df.empty and len(current_fut_monthly_data_df) >= 1:
                    num_trading_days_in_month_so_far = len(current_fut_monthly_data_df)
                    oi_at_month_start = current_fut_monthly_data_df['oi'].iloc[0]
                    oi_at_month_end = current_fut_monthly_data_df['oi'].iloc[-1]

                    if pd.notna(oi_at_month_start) and pd.notna(oi_at_month_end):
                        current_month_monthly_oi_change_val = oi_at_month_end - oi_at_month_start
                        if pd.notna(oi_at_month_start) and oi_at_month_start != 0:
                            current_monthly_oi_percent_change_val = (current_month_monthly_oi_change_val / oi_at_month_start) * 100
                        
                        if num_trading_days_in_month_so_far > 0 :
                             avg_daily_change_from_monthly_trend_val = current_month_monthly_oi_change_val / num_trading_days_in_month_so_far


            todays_net_oi_change_val = None
            todays_net_oi_percent_change_val = None
            if len(current_hist_df) >= 2: 
                oi_today_in_window = current_hist_df['oi'].iloc[-1]
                oi_yesterday_in_window = current_hist_df['oi'].iloc[-2]
                if pd.notna(oi_today_in_window) and pd.notna(oi_yesterday_in_window):
                    todays_net_oi_change_val = oi_today_in_window - oi_yesterday_in_window
                    if pd.notna(oi_yesterday_in_window) and oi_yesterday_in_window != 0:
                        todays_net_oi_percent_change_val = (todays_net_oi_change_val / oi_yesterday_in_window) * 100
            elif len(current_hist_df) == 1 and pd.notna(current_hist_df['oi'].iloc[0]) and current_data_raw_df is not None and len(current_data_raw_df[current_data_raw_df['date'].dt.weekday < 5]) > 1:
                all_trading_days_df = current_data_raw_df[current_data_raw_df['date'].dt.weekday < 5].copy()
                all_trading_days_df['oi'] = pd.to_numeric(all_trading_days_df['oi'], errors='coerce') # Ensure numeric for calculation
                if len(all_trading_days_df) >=2:
                    oi_today_in_window = all_trading_days_df['oi'].iloc[-1] 
                    oi_yesterday_overall = all_trading_days_df['oi'].iloc[-2]
                    if pd.notna(oi_today_in_window) and pd.notna(oi_yesterday_overall):
                        todays_net_oi_change_val = oi_today_in_window - oi_yesterday_overall
                        if pd.notna(oi_yesterday_overall) and oi_yesterday_overall !=0:
                             todays_net_oi_percent_change_val = (todays_net_oi_change_val / oi_yesterday_overall) * 100


            todays_oi_vs_daily_avg_percent_val = None
            if pd.notna(todays_net_oi_change_val) and pd.notna(daily_avg_oi_change_val) and daily_avg_oi_change_val != 0:
                todays_oi_vs_daily_avg_percent_val = (todays_net_oi_change_val / daily_avg_oi_change_val) * 100

            todays_oi_vs_monthly_avg_percent_val = None
            if pd.notna(todays_net_oi_change_val) and pd.notna(avg_daily_change_from_monthly_trend_val) and avg_daily_change_from_monthly_trend_val != 0:
                todays_oi_vs_monthly_avg_percent_val = (todays_net_oi_change_val / avg_daily_change_from_monthly_trend_val) * 100
            
            # --- NUANCE COLUMNS: PRICE JOURNEY (Current Future) ---
            current_fut_series_lowest_close_val = None
            current_fut_is_low_protected_val = None
            current_fut_latest_close_vs_series_low_pct_val = None
            
            series_low_from_date = analysis_fetch_end_date - timedelta(days=SERIES_LOW_LOOKBACK_DAYS)

            if current_fut:
                logger.debug(f"Fetching series low data for current future {current_fut['tradingsymbol']} from {series_low_from_date} to {analysis_fetch_end_date}")
                current_fut_series_data_df = self.get_historical_data(
                    current_fut['instrument_token'],
                    series_low_from_date,
                    analysis_fetch_end_date,
                    interval="day",
                    cap_outliers_flag=False, 
                    contract_type="future"
                )
                if not current_fut_series_data_df.empty and 'close' in current_fut_series_data_df.columns and current_fut_series_data_df['close'].notna().any():
                    current_fut_series_data_df['close'] = pd.to_numeric(current_fut_series_data_df['close'], errors='coerce') # Ensure numeric
                    current_fut_series_lowest_close_val = current_fut_series_data_df['close'].min()
                    
                    if pd.notna(current_latest_price) and pd.notna(current_fut_series_lowest_close_val):
                        if current_latest_price > current_fut_series_lowest_close_val:
                            current_fut_is_low_protected_val = "Yes"
                        elif current_latest_price < current_fut_series_lowest_close_val:
                            current_fut_is_low_protected_val = "No"
                        else:
                            current_fut_is_low_protected_val = "At Low"
                        
                        if current_fut_series_lowest_close_val != 0: # Avoid division by zero
                            current_fut_latest_close_vs_series_low_pct_val = \
                                ((current_latest_price - current_fut_series_lowest_close_val) / abs(current_fut_series_lowest_close_val)) * 100
                else:
                    logger.debug(f"No series data or close prices for current future {current_fut['tradingsymbol']} to determine series low.")

            # --- MOVED NEXT MONTH CALCULATIONS (MAIN BLOCK) HERE ---
            next_oi_change_pct_for_sentiment, next_price_change_pct_for_sentiment = 0.0, 0.0
            next_oi_z_for_sentiment, next_price_z_for_sentiment = None, None
            # Initialize next_latest_price, next_latest_oi, next_avg_volume
            next_latest_price, next_latest_oi, next_avg_volume = None, None, 0.0
            # Initialize next month volatility metrics
            next_realized_vol_daily_pct = None
            next_realized_vol_annualized = None
            next_avg_abs_daily_move_pct = None
            next_avg_daily_range_pct = None
            next_max_single_day_move_pct = None
            next_max_upswing_pct = None
            next_max_drawdown_pct = None
            next_max_excursion_pct = None

            if next_fut and not next_hist_df.empty and len(next_hist_df) == trading_days:
                if 'oi' not in next_hist_df.columns: # Safety check for next_hist_df
                    logger.warning(f"'oi' column missing in next_hist_df for {symbol}.")
                    next_hist_df['oi'] = np.nan
                else:
                    next_hist_df['oi'] = pd.to_numeric(next_hist_df['oi'], errors='coerce')

                next_hist_df['open'] = pd.to_numeric(next_hist_df['open'], errors='coerce')
                next_hist_df['close'] = pd.to_numeric(next_hist_df['close'], errors='coerce')
                next_hist_df['volume'] = pd.to_numeric(next_hist_df['volume'], errors='coerce')
                next_hist_df['high'] = pd.to_numeric(next_hist_df['high'], errors='coerce')
                next_hist_df['low'] = pd.to_numeric(next_hist_df['low'], errors='coerce')

                next_oi_initial = next_hist_df['oi'].iloc[0] if pd.notna(next_hist_df['oi'].iloc[0]) else None
                next_oi_final = next_hist_df['oi'].iloc[-1] if pd.notna(next_hist_df['oi'].iloc[-1]) else None
                next_oi_period_change = (next_oi_final - next_oi_initial) if next_oi_final is not None and next_oi_initial is not None else 0.0
                next_oi_change_pct_for_sentiment = (next_oi_period_change / next_oi_initial * 100) if next_oi_initial is not None and next_oi_initial != 0 else 0.0
                
                next_price_initial = next_hist_df['open'].iloc[0] if pd.notna(next_hist_df['open'].iloc[0]) else None
                _next_price_final_temp = next_hist_df['close'].iloc[-1] if pd.notna(next_hist_df['close'].iloc[-1]) else None
                next_latest_price = _next_price_final_temp # << THIS IS WHERE next_latest_price GETS ITS VALUE
                
                next_price_change_pct_for_sentiment = ((_next_price_final_temp - next_price_initial) / next_price_initial * 100) if next_price_initial is not None and next_price_initial != 0 and _next_price_final_temp is not None else 0.0
                
                # REALIZED VOLATILITY CALCULATION FOR NEXT MONTH (for straddle strategy)
                next_hist_df['daily_return_pct'] = next_hist_df['close'].pct_change() * 100
                next_hist_df['daily_range_pct'] = ((next_hist_df['high'] - next_hist_df['low']) / next_hist_df['close']) * 100
                
                # Realized volatility metrics for next month
                next_daily_returns = next_hist_df['daily_return_pct'].dropna()
                if len(next_daily_returns) >= 3:
                    next_realized_vol_daily_pct = next_daily_returns.std()
                    next_realized_vol_annualized = next_realized_vol_daily_pct * np.sqrt(252)
                    next_avg_abs_daily_move_pct = next_daily_returns.abs().mean()
                    next_avg_daily_range_pct = next_hist_df['daily_range_pct'].dropna().mean()
                    next_max_single_day_move_pct = next_daily_returns.abs().max()
                    
                    # HISTORICAL MAX MOVE DETECTION FOR NEXT MONTH
                    next_close_prices = next_hist_df['close'].dropna()
                    if len(next_close_prices) >= 2:
                        next_max_upswing_pct = ((next_close_prices.max() / next_close_prices.min()) - 1) * 100
                        next_max_drawdown_pct = ((next_close_prices.min() / next_close_prices.max()) - 1) * 100
                        next_max_excursion_pct = max(next_max_upswing_pct, abs(next_max_drawdown_pct))
                
                if next_fut_baseline_stats:
                    avg_daily_next_oi_change = next_oi_period_change / len(next_hist_df) if len(next_hist_df) > 0 and next_oi_period_change is not None else 0.0
                    next_oi_z_for_sentiment = self._calculate_z_score(avg_daily_next_oi_change, next_fut_baseline_stats.get('mean_oi_change'), next_fut_baseline_stats.get('std_oi_change'))
                    avg_daily_next_price_change_pct = next_price_change_pct_for_sentiment / len(next_hist_df) if len(next_hist_df) > 0 and next_price_change_pct_for_sentiment is not None else 0.0
                    next_price_z_for_sentiment = self._calculate_z_score(avg_daily_next_price_change_pct, next_fut_baseline_stats.get('mean_price_change_pct'), next_fut_baseline_stats.get('std_price_change_pct'))
                
                next_latest_oi = next_oi_final
                next_avg_volume = next_hist_df['volume'].dropna().mean() if not next_hist_df['volume'].dropna().empty else 0.0
            # --- END OF MOVED NEXT MONTH CALCULATIONS (MAIN BLOCK) ---

            # --- NUANCE COLUMNS: PRICE JOURNEY (Next Future) ---
            # Initialize these before use
            next_fut_series_lowest_close_val = None
            next_fut_is_low_protected_val = None
            next_fut_latest_close_vs_series_low_pct_val = None

            if next_fut: # Check if next_fut itself exists
                # next_latest_price is now populated (or None if next_hist_df was invalid)
                logger.debug(f"Fetching series low data for next future {next_fut['tradingsymbol']} from {series_low_from_date} to {analysis_fetch_end_date}")
                next_fut_series_data_df = self.get_historical_data(
                    next_fut['instrument_token'],
                    series_low_from_date,
                    analysis_fetch_end_date,
                    interval="day",
                    cap_outliers_flag=False, 
                    contract_type="future"
                )
                if not next_fut_series_data_df.empty and 'close' in next_fut_series_data_df.columns and next_fut_series_data_df['close'].notna().any():
                    next_fut_series_data_df['close'] = pd.to_numeric(next_fut_series_data_df['close'], errors='coerce') # Ensure numeric
                    next_fut_series_lowest_close_val = next_fut_series_data_df['close'].min()
                    
                    if pd.notna(next_latest_price) and pd.notna(next_fut_series_lowest_close_val):
                        if next_latest_price > next_fut_series_lowest_close_val:
                            next_fut_is_low_protected_val = "Yes"
                        elif next_latest_price < next_fut_series_lowest_close_val:
                            next_fut_is_low_protected_val = "No"
                        else:
                            next_fut_is_low_protected_val = "At Low"

                        if next_fut_series_lowest_close_val != 0: # Avoid division by zero
                            next_fut_latest_close_vs_series_low_pct_val = \
                                ((next_latest_price - next_fut_series_lowest_close_val) / abs(next_fut_series_lowest_close_val)) * 100
                else:
                    logger.debug(f"No series data or close prices for next future {next_fut['tradingsymbol']} to determine series low.")
            # --- END OF NUANCE COLUMNS: PRICE JOURNEY (Next Future) ---

            # Rollover calculations and sentiment determination
            roll_cost_pts, roll_cost_pct = self.calculate_roll_cost(current_latest_price, next_latest_price, spot_price_val)
            term_structure = self.calculate_term_structure_slope([current_latest_price, next_latest_price])
            term_structure_slope_val = term_structure[0] if term_structure else None
            rqi_val = self.calculate_rollover_quality_index(current_oi_change_pct, next_oi_change_pct_for_sentiment, next_price_change_pct_for_sentiment, current_avg_volume, next_avg_volume)
            rollover_pct_val = self.calculate_rollover(current_latest_oi, next_latest_oi)

            roll_skew_val = None
            if all(v is not None for v in [next_oi_change_pct_for_sentiment, current_oi_change_pct, next_price_change_pct_for_sentiment, current_price_period_change_pct]):
                roll_skew_val = (next_oi_change_pct_for_sentiment - current_oi_change_pct) + \
                                (next_price_change_pct_for_sentiment - current_price_period_change_pct)
                logger.debug(f"{symbol} - Roll Skew calculated: {roll_skew_val:.2f}")

            # Compute dynamic thresholds from current contract realized vol
            curr_dyn_oi_thresh, curr_dyn_px_thresh = self._compute_dynamic_z_thresholds(current_fut_baseline_stats)
            sent_curr = self._determine_sentiment(
                current_oi_change_pct, current_price_period_change_pct,
                current_oi_z, current_price_z,
                oi_z_threshold=curr_dyn_oi_thresh, price_z_threshold=curr_dyn_px_thresh
            )
            strength_curr = self._get_sentiment_strength(sent_curr)
            # Next contract dynamic thresholds, if next baseline exists
            next_dyn_oi_thresh, next_dyn_px_thresh = (self._compute_dynamic_z_thresholds(next_fut_baseline_stats)
                                                     if next_fut_baseline_stats else (None, None))
            sent_next = self._determine_sentiment(
                next_oi_change_pct_for_sentiment, next_price_change_pct_for_sentiment,
                next_oi_z_for_sentiment, next_price_z_for_sentiment,
                oi_z_threshold=next_dyn_oi_thresh, price_z_threshold=next_dyn_px_thresh
            ) if (next_fut and not next_hist_df.empty and len(next_hist_df) == trading_days) else "Neutral"
            strength_next = self._get_sentiment_strength(sent_next)

            # Expiry related logic
            current_fut_expiry_date = pd.Timestamp(current_fut['expiry']).date()
            days_to_current_expiry = (current_fut_expiry_date - current_time_obj.date()).days
            action_option_expiry_date_obj, is_next_month_focused_trade = current_fut_expiry_date, False
            if days_to_current_expiry <= 5 and next_fut:
                next_fut_expiry_date_obj = pd.Timestamp(next_fut['expiry']).date()
                if next_fut_expiry_date_obj > current_fut_expiry_date:
                    action_option_expiry_date_obj = next_fut_expiry_date_obj
                    is_next_month_focused_trade = True
                    logger.info(f"Trade focus shifted to next month expiry {action_option_expiry_date_obj} for {symbol}.")
            effective_days_to_expiry_for_penalty = (pd.Timestamp(action_option_expiry_date_obj).date() - current_time_obj.date()).days

            # Option chain analysis
            option_chain_df = self.get_option_chain(symbol, [action_option_expiry_date_obj])
            filtered_options = self.filter_strikes(option_chain_df, spot_price_val)
            writer_analysis = self.analyze_writer_strength(filtered_options, spot_price_val)
            time_to_expiry_years = None
            try:
                expiry_naive = datetime.combine(action_option_expiry_date_obj, dt_time(hour=15, minute=30))
                if expiry_naive.tzinfo is None:
                    expiry_dt = self.ist_timezone.localize(expiry_naive)
                else:
                    expiry_dt = expiry_naive.astimezone(self.ist_timezone)
                seconds_to_expiry = (expiry_dt - current_time_obj).total_seconds()
                if seconds_to_expiry > 0:
                    time_to_expiry_years = seconds_to_expiry / (365.0 * 24 * 60 * 60)
            except Exception as time_exc:
                logger.debug(f"Time to expiry calculation failed for {symbol}: {time_exc}")

            atm_strike_val = None
            filtered_options_numeric = None
            if filtered_options is not None and not filtered_options.empty and 'strike' in filtered_options.columns:
                filtered_options_numeric = filtered_options.copy()
                filtered_options_numeric['strike'] = pd.to_numeric(filtered_options_numeric['strike'], errors='coerce')
                filtered_options_numeric.dropna(subset=['strike'], inplace=True)
                filtered_options_numeric['last_price'] = pd.to_numeric(filtered_options_numeric.get('last_price', np.nan), errors='coerce')
                filtered_options_numeric['oi'] = pd.to_numeric(filtered_options_numeric.get('oi', np.nan), errors='coerce')
                filtered_options_numeric['volume'] = pd.to_numeric(filtered_options_numeric.get('volume', np.nan), errors='coerce')
                if not filtered_options_numeric.empty:
                    atm_strike_candidates = filtered_options_numeric.iloc[(filtered_options_numeric['strike'] - spot_price_val).abs().argsort()]
                    if not atm_strike_candidates.empty:
                        atm_strike_val = atm_strike_candidates['strike'].iloc[0]

            # Primary metrics for combined sentiment
            primary_oi_change_percent_val = next_oi_change_pct_for_sentiment if is_next_month_focused_trade else current_oi_change_pct
            primary_price_change_percent_val = next_price_change_pct_for_sentiment if is_next_month_focused_trade else current_price_period_change_pct # This var itself is not directly used in _combine_trends_refined anymore for inst break
            price_oi_ratio_primary_val = (primary_price_change_percent_val / (primary_oi_change_percent_val + 1e-6)) if primary_oi_change_percent_val is not None and primary_price_change_percent_val is not None and abs(primary_oi_change_percent_val) > 1e-6 else None
            primary_price_zscore_val = next_price_z_for_sentiment if is_next_month_focused_trade else current_price_z
            primary_oi_zscore_val = next_oi_z_for_sentiment if is_next_month_focused_trade else current_oi_z

            combined_sentiment, confidence = self._combine_trends_refined(
                symbol, sent_curr, strength_curr, current_oi_z, current_price_z,
                sent_next, strength_next, next_oi_z_for_sentiment, next_price_z_for_sentiment,
                effective_days_to_expiry_for_penalty,
                rqi_val, writer_analysis, self.detected_market_regime,
                is_next_month_focused_trade,
                term_structure_slope_val,
                price_oi_ratio_primary_val,
                primary_oi_change_percent_val,
                primary_price_zscore_val, 
                primary_oi_zscore_val,
                spot_price_val, 
                roll_skew_val 
            )

            confidence_adjustments = []
            recommended_holding_period = None

            def _log_confidence_adjustment(delta, reason):
                confidence_adjustments.append(f"{delta:+.0f} -> {reason}")

            adjusted_confidence = confidence

            if (current_fut_is_low_protected_val == "Yes" and
                current_fut_latest_close_vs_series_low_pct_val is not None and
                current_fut_latest_close_vs_series_low_pct_val > 10.0 and
                current_avg_volume is not None and current_avg_volume >= MIN_FUT_AVG_VOLUME):
                boost = 18.0
                adjusted_confidence = min(100.0, adjusted_confidence + boost)
                _log_confidence_adjustment(boost, "Price floor protected (series low support)")

            if (current_fut_is_low_protected_val == "No" and
                current_oi_change_pct is not None and current_oi_change_pct < 0 and
                combined_sentiment == "Bullish"):
                penalty = -30.0
                adjusted_confidence = max(0.0, adjusted_confidence + penalty)
                _log_confidence_adjustment(penalty, "Price journey warning (floor broken with OI drop)")

            if (todays_oi_vs_daily_avg_percent_val is not None and
                todays_oi_vs_daily_avg_percent_val > 150.0 and
                current_price_period_change_pct is not None and current_price_period_change_pct > 0):
                boost = 20.0
                adjusted_confidence = min(100.0, adjusted_confidence + boost)
                _log_confidence_adjustment(boost, "Intraday OI thrust vs daily avg")
                recommended_holding_period = "2-3 days (momentum thrust)"

            if (todays_oi_vs_monthly_avg_percent_val is not None and
                todays_oi_vs_monthly_avg_percent_val < -80.0 and
                (current_fut_is_low_protected_val == "Yes" or
                 (current_price_z is not None and current_price_z > -0.3))):
                boost = 10.0
                adjusted_confidence = min(100.0, adjusted_confidence + boost)
                _log_confidence_adjustment(boost, "Contrarian OI flush near support")
                if recommended_holding_period is None:
                    recommended_holding_period = "3-4 days (contrarian bounce)"

            institutional_breakout = False
            max_call_strike = writer_analysis.get("max_call_oi_strike") if isinstance(writer_analysis, dict) else None
            call_writer_strength_pct = writer_analysis.get("call_writer_strength_percent") if isinstance(writer_analysis, dict) else None
            try:
                max_call_strike_val = float(max_call_strike) if max_call_strike is not None else None
            except (TypeError, ValueError):
                max_call_strike_val = None
            try:
                call_writer_strength_pct_val = float(call_writer_strength_pct) if call_writer_strength_pct is not None else None
            except (TypeError, ValueError):
                call_writer_strength_pct_val = None
            writer_trap_confidence_applied = False
            if (spot_price_val is not None and max_call_strike_val is not None and
                spot_price_val > max_call_strike_val * 1.02 and
                call_writer_strength_pct_val is not None and call_writer_strength_pct_val > 45.0):
                writer_trap_confidence_applied = True
                previous_confidence = adjusted_confidence
                adjusted_confidence = max(adjusted_confidence, 70.0)
                if adjusted_confidence != previous_confidence:
                    _log_confidence_adjustment(adjusted_confidence - previous_confidence, "Writer trap override (spot > max call OI strike)")

            if (primary_price_zscore_val is not None and primary_price_zscore_val > INST_BREAK_PRICE_Z_THRESH and
                call_writer_strength_pct_val is not None and call_writer_strength_pct_val > INST_BREAK_CALL_WRITER_PCT_THRESH and
                max_call_strike_val is not None and spot_price_val is not None and spot_price_val > max_call_strike_val and
                (rqi_val is None or rqi_val >= 5.0) and
                (rollover_pct_val is None or rollover_pct_val >= 40.0)):
                institutional_breakout = True
                previous_confidence = adjusted_confidence
                adjusted_confidence = max(85.0, min(100.0, adjusted_confidence + INST_BREAK_BONUS))
                if adjusted_confidence != previous_confidence:
                    _log_confidence_adjustment(adjusted_confidence - previous_confidence, "Institutional breakout trap detected")
                combined_sentiment = "Bullish"
                if recommended_holding_period is None:
                    recommended_holding_period = "2-4 days (institutional breakout)"

            confidence = adjusted_confidence

            trend_trust_meta = self._compute_trend_trust_meta(
                rqi_val, rollover_pct_val, term_structure_slope_val,
                effective_days_to_expiry_for_penalty, self.detected_market_regime
            )

            directional_decision = self._evaluate_directional_engine(
                symbol,
                combined_sentiment,
                confidence,
                filtered_options,
                spot_price_val,
                institutional_breakout,
                recommended_holding_period,
                todays_oi_vs_daily_avg_percent_val,
                todays_net_oi_percent_change_val,
                current_realized_vol_daily_pct,
                todays_oi_vs_monthly_avg_percent_val
            )

            option_greeks = {}
            directional_option_details = directional_decision.get('option_details', {}) or {}
            if (
                directional_option_details.get('selected_option_symbol') and
                directional_option_details.get('selected_option_premium') is not None and
                directional_option_details.get('selected_option_strike') is not None and
                directional_option_details.get('selected_option_type') in ('CE', 'PE') and
                spot_price_val is not None and
                time_to_expiry_years is not None and time_to_expiry_years > 0
            ):
                try:
                    strike_val = float(directional_option_details.get('selected_option_strike'))
                    premium_val = float(directional_option_details.get('selected_option_premium'))
                    if strike_val > 0 and premium_val > 0:
                        option_greeks = self._calculate_option_greeks(
                            spot_price_val,
                            strike_val,
                            premium_val,
                            time_to_expiry_years,
                            directional_option_details.get('selected_option_type'),
                            rate=DEFAULT_RISK_FREE_RATE
                        )
                except Exception as opt_exc:
                    logger.debug(f"Option greeks computation skipped for {symbol}: {opt_exc}")

            atm_call_symbol = None
            atm_call_strike = None
            atm_call_last_price = None
            atm_call_oi = None
            atm_call_greeks = {}

            atm_put_symbol = None
            atm_put_strike = None
            atm_put_last_price = None
            atm_put_oi = None
            atm_put_greeks = {}

            if filtered_options_numeric is not None and not filtered_options_numeric.empty and time_to_expiry_years and time_to_expiry_years > 0:
                if atm_strike_val is None:
                    try:
                        atm_strike_val = float(filtered_options_numeric.iloc[(filtered_options_numeric['strike'] - spot_price_val).abs().argsort()].iloc[0]['strike'])
                    except Exception:
                        atm_strike_val = None

                if atm_strike_val is not None:
                    calls_numeric = filtered_options_numeric[filtered_options_numeric['instrument_type'] == 'CE']
                    if not calls_numeric.empty:
                        call_idx = (calls_numeric['strike'] - atm_strike_val).abs().idxmin()
                        call_row = calls_numeric.loc[call_idx]
                        atm_call_symbol = call_row.get('tradingsymbol')
                        atm_call_strike = call_row.get('strike')
                        atm_call_last_price = call_row.get('last_price')
                        atm_call_oi = call_row.get('oi')
                        if (spot_price_val is not None and atm_call_strike and atm_call_last_price and
                                atm_call_last_price > 0):
                            atm_call_greeks = self._calculate_option_greeks(
                                spot_price_val,
                                float(atm_call_strike),
                                float(atm_call_last_price),
                                time_to_expiry_years,
                                'CE',
                                rate=DEFAULT_RISK_FREE_RATE
                            )

                    puts_numeric = filtered_options_numeric[filtered_options_numeric['instrument_type'] == 'PE']
                    if not puts_numeric.empty:
                        put_idx = (puts_numeric['strike'] - atm_strike_val).abs().idxmin()
                        put_row = puts_numeric.loc[put_idx]
                        atm_put_symbol = put_row.get('tradingsymbol')
                        atm_put_strike = put_row.get('strike')
                        atm_put_last_price = put_row.get('last_price')
                        atm_put_oi = put_row.get('oi')
                        if (spot_price_val is not None and atm_put_strike and atm_put_last_price and
                                atm_put_last_price > 0):
                            atm_put_greeks = self._calculate_option_greeks(
                                spot_price_val,
                                float(atm_put_strike),
                                float(atm_put_last_price),
                                time_to_expiry_years,
                                'PE',
                                rate=DEFAULT_RISK_FREE_RATE
                            )

            avg_atm_iv = None
            iv_values = []
            if atm_call_greeks.get('iv') is not None:
                iv_values.append(atm_call_greeks.get('iv'))
            if atm_put_greeks.get('iv') is not None:
                iv_values.append(atm_put_greeks.get('iv'))
            if iv_values:
                avg_atm_iv = float(np.nanmean(iv_values))

            realized_for_iv_percentile = current_realized_vol_annualized or next_realized_vol_annualized
            seller_iv_percentile = self._estimate_iv_percentile(avg_atm_iv, realized_for_iv_percentile)

            def _to_float(value):
                try:
                    return float(value)
                except (TypeError, ValueError):
                    return None

            call_conc_val = _to_float(writer_analysis.get("call_oi_concentration_pct") if isinstance(writer_analysis, dict) else None)
            put_conc_val = _to_float(writer_analysis.get("put_oi_concentration_pct") if isinstance(writer_analysis, dict) else None)
            call_wall_strike = _to_float(writer_analysis.get("max_call_oi_strike") if isinstance(writer_analysis, dict) else None)
            put_wall_strike = _to_float(writer_analysis.get("max_put_oi_strike") if isinstance(writer_analysis, dict) else None)
            call_hhi_val = _to_float(writer_analysis.get("call_oi_hhi") if isinstance(writer_analysis, dict) else None)
            put_hhi_val = _to_float(writer_analysis.get("put_oi_hhi") if isinstance(writer_analysis, dict) else None)
            call_wall_strength_val = _to_float(writer_analysis.get("call_wall_strength_score") if isinstance(writer_analysis, dict) else None)
            put_wall_strength_val = _to_float(writer_analysis.get("put_wall_strength_score") if isinstance(writer_analysis, dict) else None)

            call_wall_distance_pct = _to_float(writer_analysis.get("call_wall_distance_pct") if isinstance(writer_analysis, dict) else None)
            if call_wall_distance_pct is None:
                call_wall_distance_pct = self._calculate_wall_distance_pct(spot_price_val, call_wall_strike)
            put_wall_distance_pct = _to_float(writer_analysis.get("put_wall_distance_pct") if isinstance(writer_analysis, dict) else None)
            if put_wall_distance_pct is None:
                put_wall_distance_pct = self._calculate_wall_distance_pct(spot_price_val, put_wall_strike)

            seller_walls_ok = (
                call_wall_distance_pct is not None and put_wall_distance_pct is not None and
                call_wall_distance_pct <= SELLER_MAX_WALL_DISTANCE_PCT and
                put_wall_distance_pct <= SELLER_MAX_WALL_DISTANCE_PCT
            )
            seller_concentration_ok = (
                call_conc_val is not None and put_conc_val is not None and
                min(call_conc_val, put_conc_val) >= SELLER_MIN_OI_CONCENTRATION_PCT
            )
            seller_hhi_ok = (
                call_hhi_val is not None and put_hhi_val is not None and
                min(call_hhi_val, put_hhi_val) >= SELLER_MIN_HHI
            )
            seller_wall_strength_ok = (
                call_wall_strength_val is not None and put_wall_strength_val is not None and
                min(call_wall_strength_val, put_wall_strength_val) >= SELLER_MIN_WALL_STRENGTH_SCORE
            )

            seller_carry_score = self._calculate_carry_score(
                rqi_val, rollover_pct_val, term_structure_slope_val, roll_cost_pct
            )
            seller_iv_ok = seller_iv_percentile is not None and seller_iv_percentile >= SELLER_MIN_IV_PERCENTILE
            seller_carry_ok = seller_carry_score is not None and seller_carry_score >= SELLER_MIN_CARRY_SCORE

            relax_notes = []
            writer_pcr_val = None
            try:
                writer_pcr_val = float(writer_analysis.get("pcr_oi")) if isinstance(writer_analysis, dict) and writer_analysis.get("pcr_oi") is not None else None
            except (TypeError, ValueError):
                writer_pcr_val = None

            relax_context_ok = (
                call_wall_distance_pct is not None and call_wall_distance_pct <= SELLER_RELAXED_WALL_DISTANCE_PCT and
                put_wall_distance_pct is not None and put_wall_distance_pct <= SELLER_RELAXED_WALL_DISTANCE_PCT and
                current_realized_vol_daily_pct is not None and current_realized_vol_daily_pct <= SELLER_RELAXED_REALIZED_VOL_MAX and
                writer_pcr_val is not None and SELLER_RELAXED_PCR_MIN <= writer_pcr_val <= SELLER_RELAXED_PCR_MAX
            )

            if not seller_concentration_ok and relax_context_ok:
                if call_conc_val is not None and put_conc_val is not None and \
                        call_conc_val >= SELLER_RELAXED_OI_CONCENTRATION_PCT and \
                        put_conc_val >= SELLER_RELAXED_OI_CONCENTRATION_PCT:
                    seller_concentration_ok = True
                    relax_notes.append("concentration")

            if not seller_hhi_ok and relax_context_ok:
                if call_hhi_val is not None and put_hhi_val is not None and \
                        call_hhi_val >= SELLER_RELAXED_HHI and \
                        put_hhi_val >= SELLER_RELAXED_HHI:
                    seller_hhi_ok = True
                    relax_notes.append("hhi")

            if not seller_wall_strength_ok and relax_context_ok:
                if call_wall_strength_val is not None and put_wall_strength_val is not None and \
                        call_wall_strength_val >= SELLER_RELAXED_WALL_STRENGTH_SCORE and \
                        put_wall_strength_val >= SELLER_RELAXED_WALL_STRENGTH_SCORE:
                    seller_wall_strength_ok = True
                    relax_notes.append("wall_strength")

            if not seller_iv_ok and relax_context_ok and seller_iv_percentile is not None and seller_iv_percentile >= SELLER_RELAXED_IV_PERCENTILE:
                seller_iv_ok = True
                relax_notes.append("iv_percentile")

            if not seller_carry_ok and relax_context_ok and seller_carry_score is not None and seller_carry_score >= SELLER_RELAXED_CARRY_SCORE:
                seller_carry_ok = True
                relax_notes.append("carry")

            seller_structural_inputs = {
                'walls_ok': seller_walls_ok,
                'concentration_ok': seller_concentration_ok,
                'call_wall_distance_pct': call_wall_distance_pct,
                'put_wall_distance_pct': put_wall_distance_pct,
                'iv_percentile': seller_iv_percentile,
                'carry_score': seller_carry_score,
                'iv_ok': seller_iv_ok,
                'carry_ok': seller_carry_ok,
                'hhi_ok': seller_hhi_ok,
                'wall_strength_ok': seller_wall_strength_ok,
                'call_hhi': call_hhi_val,
                'put_hhi': put_hhi_val,
                'call_wall_strength': call_wall_strength_val,
                'put_wall_strength': put_wall_strength_val,
                'relaxed_rules_used': relax_notes,
                'relax_context_ok': relax_context_ok,
                'relaxed_concentration_threshold': SELLER_RELAXED_OI_CONCENTRATION_PCT,
                'relaxed_iv_percentile': SELLER_RELAXED_IV_PERCENTILE,
                'relaxed_carry_score': SELLER_RELAXED_CARRY_SCORE,
                'relaxed_hhi': SELLER_RELAXED_HHI,
                'relaxed_wall_strength_score': SELLER_RELAXED_WALL_STRENGTH_SCORE
            }

            straddle_confidence = None
            straddle_rationale = []
            straddle_viability_tag = None
            straddle_entry_ok = None
            straddle_entry_blockers = []
            straddle_entry_notes = []
            straddle_position_adjustment = None
            straddle_profit_target_note = "Target premium decay ~40-50% over ~3 weeks (exit before expiry)"

            def _add_straddle_note(delta, note):
                if delta is not None:
                    straddle_rationale.append(f"{delta:+.0f} -> {note}")
                else:
                    straddle_rationale.append(note)

            if current_realized_vol_daily_pct is not None or current_max_excursion_pct is not None:
                base_conf = 55.0
                if (current_realized_vol_daily_pct is not None and current_realized_vol_daily_pct < 1.2 and
                    current_max_excursion_pct is not None and current_max_excursion_pct < 6.0):
                    base_conf = 78.0
                    _add_straddle_note(None, "Low realized vol & contained excursions")
                elif ((current_realized_vol_daily_pct is not None and current_realized_vol_daily_pct > 2.5) or
                      (current_max_excursion_pct is not None and current_max_excursion_pct > 12.0)):
                    base_conf = 30.0
                    _add_straddle_note(None, "High realized vol or large excursions")

                if current_avg_daily_range_pct is not None and current_avg_daily_range_pct < 1.5:
                    base_conf += 7.0
                    _add_straddle_note(7.0, "Tight intraday ranges")

                call_oi_conc = writer_analysis.get("call_oi_concentration_pct") if isinstance(writer_analysis, dict) else None
                put_oi_conc = writer_analysis.get("put_oi_concentration_pct") if isinstance(writer_analysis, dict) else None
                max_put_strike = writer_analysis.get("max_put_oi_strike") if isinstance(writer_analysis, dict) else None
                try:
                    call_oi_conc_val = float(call_oi_conc) if call_oi_conc is not None else None
                except (TypeError, ValueError):
                    call_oi_conc_val = None
                try:
                    put_oi_conc_val = float(put_oi_conc) if put_oi_conc is not None else None
                except (TypeError, ValueError):
                    put_oi_conc_val = None
                try:
                    max_put_strike_val = float(max_put_strike) if max_put_strike is not None else None
                except (TypeError, ValueError):
                    max_put_strike_val = None

                if (call_oi_conc_val is not None and call_oi_conc_val > 35.0 and
                    put_oi_conc_val is not None and put_oi_conc_val > 35.0 and
                    max_call_strike_val is not None and max_put_strike_val is not None and
                    spot_price_val is not None and max_call_strike_val != max_put_strike_val):
                    midpoint = (max_call_strike_val + max_put_strike_val) / 2.0
                    half_range = abs(max_call_strike_val - max_put_strike_val) / 2.0
                    if half_range > 0 and abs(spot_price_val - midpoint) <= half_range * 0.3:
                        base_conf += 8.0
                        _add_straddle_note(8.0, "OI barriers above/below spot")

                second_call_ratio = writer_analysis.get("second_call_oi_ratio") if isinstance(writer_analysis, dict) else None
                second_put_ratio = writer_analysis.get("second_put_oi_ratio") if isinstance(writer_analysis, dict) else None
                try:
                    second_call_ratio_val = float(second_call_ratio) if second_call_ratio is not None else None
                except (TypeError, ValueError):
                    second_call_ratio_val = None
                try:
                    second_put_ratio_val = float(second_put_ratio) if second_put_ratio is not None else None
                except (TypeError, ValueError):
                    second_put_ratio_val = None
                if (second_call_ratio_val is not None and second_call_ratio_val > 0.75 and
                    second_put_ratio_val is not None and second_put_ratio_val > 0.75):
                    base_conf -= 12.0
                    _add_straddle_note(-12.0, "Dispersed OI (breakout risk)")

                pcr_val = writer_analysis.get("pcr_oi") if isinstance(writer_analysis, dict) else None
                try:
                    pcr_float = float(pcr_val) if pcr_val is not None else None
                except (TypeError, ValueError):
                    pcr_float = None
                if pcr_float is not None:
                    if 0.85 <= pcr_float <= 1.20 and (current_realized_vol_daily_pct is None or current_realized_vol_daily_pct < 2.0):
                        base_conf += 10.0
                        _add_straddle_note(10.0, "Balanced PCR with low vol")
                    elif pcr_float > 1.45 or pcr_float < 0.6:
                        base_conf -= 18.0
                        _add_straddle_note(-18.0, "Directional PCR bias")

                straddle_confidence = max(0.0, min(100.0, base_conf))
                if straddle_confidence >= 70.0:
                    straddle_viability_tag = "Favorable"
                elif straddle_confidence >= 50.0:
                    straddle_viability_tag = "Moderate"
                else:
                    straddle_viability_tag = "Avoid"

                straddle_entry_conditions_met = True

                if current_realized_vol_daily_pct is not None:
                    if current_realized_vol_daily_pct >= 1.8:
                        straddle_entry_conditions_met = False
                        straddle_entry_blockers.append("Realized vol >= 1.8%")
                else:
                    straddle_entry_notes.append("Realized vol unavailable")

                if current_max_excursion_pct is not None:
                    if current_max_excursion_pct >= 10.0:
                        straddle_entry_conditions_met = False
                        straddle_entry_blockers.append("Current excursion >= 10%")
                else:
                    straddle_entry_notes.append("Excursion data unavailable")

                if pcr_float is not None:
                    if not (0.80 <= pcr_float <= 1.25):
                        straddle_entry_conditions_met = False
                        straddle_entry_blockers.append("PCR outside 0.80-1.25")
                else:
                    straddle_entry_notes.append("PCR data unavailable")

                if call_oi_conc_val is not None and put_oi_conc_val is not None:
                    if not (call_oi_conc_val > 30.0 and put_oi_conc_val > 30.0):
                        straddle_entry_conditions_met = False
                        straddle_entry_blockers.append("OI barriers < 30% concentration")
                else:
                    straddle_entry_notes.append("OI concentration metrics unavailable")

                atm_proximity_ok = False
                if (atm_strike_val is not None and max_call_strike_val is not None and max_put_strike_val is not None):
                    try:
                        atm_diff_call = abs(atm_strike_val - max_call_strike_val) / max_call_strike_val * 100.0
                        atm_diff_put = abs(atm_strike_val - max_put_strike_val) / max_put_strike_val * 100.0
                        if atm_diff_call <= 3.0 and atm_diff_put <= 3.0:
                            atm_proximity_ok = True
                        else:
                            straddle_entry_conditions_met = False
                            straddle_entry_blockers.append("ATM not within 3% of max OI strikes")
                    except Exception:
                        straddle_entry_conditions_met = False
                        straddle_entry_blockers.append("ATM proximity check failed")
                else:
                    straddle_entry_notes.append("ATM or max OI strikes unavailable")

                if straddle_entry_conditions_met:
                    straddle_entry_ok = "Eligible"
                    straddle_entry_notes.append("All directional-neutral entry conditions satisfied")
                else:
                    straddle_entry_ok = "Blocked"

                if next_max_excursion_pct is not None and next_max_excursion_pct > 10.0:
                    straddle_position_adjustment = "Reduce size 50% (next-month excursion > 10%)"
                if todays_net_oi_percent_change_val is not None and todays_net_oi_percent_change_val > 15.0:
                    straddle_entry_ok = "Blocked"
                    straddle_entry_blockers.append("Todays OI change > 15% (abnormal activity)")

            straddle_rationale_str = "; ".join(straddle_rationale) if straddle_rationale else None
            straddle_entry_blockers_str = "; ".join(straddle_entry_blockers) if straddle_entry_blockers else None
            straddle_entry_notes_str = "; ".join(straddle_entry_notes) if straddle_entry_notes else None

            seller_decision = self._evaluate_seller_engine(
                atm_strike_val,
                straddle_entry_ok,
                straddle_viability_tag,
                straddle_confidence,
                straddle_rationale_str,
                straddle_entry_blockers_str,
                straddle_entry_notes_str,
                straddle_position_adjustment,
                straddle_profit_target_note,
                writer_analysis,
                trend_trust_meta,
                seller_structural_inputs
            )

            dir_option_details = directional_option_details
            result = {
                'timestamp': current_time_obj.strftime('%Y-%m-%d %H:%M:%S'), 'symbol': symbol,
                'detected_market_regime': self.detected_market_regime,
                'spot_price': spot_price_val,
                'combined_sentiment': combined_sentiment, 'confidence_percent': confidence,
                'action': directional_decision.get('action'),
                'dir_action': directional_decision.get('action'),
                'dir_confidence': directional_decision.get('confidence'),
                'dir_context': directional_decision.get('context'),
                'dir_holding_period': directional_decision.get('holding_period'),
                'dir_notes': directional_decision.get('notes'),
                'dir_option_symbol': dir_option_details.get('selected_option_symbol'),
                'dir_option_strike': round(dir_option_details.get('selected_option_strike'), 2) if dir_option_details.get('selected_option_strike') is not None else None,
                'dir_option_type': dir_option_details.get('selected_option_type'),
                'dir_option_oi': round(dir_option_details.get('selected_option_oi'), 0) if dir_option_details.get('selected_option_oi') is not None else None,
                'dir_option_volume': round(dir_option_details.get('selected_option_volume'), 0) if dir_option_details.get('selected_option_volume') is not None else None,
                'dir_option_premium': round(dir_option_details.get('selected_option_premium'), 2) if dir_option_details.get('selected_option_premium') is not None else None,
                'dir_option_iv': round(option_greeks.get('iv'), 2) if option_greeks.get('iv') is not None else None,
                'dir_option_delta': round(option_greeks.get('delta'), 4) if option_greeks.get('delta') is not None else None,
                'dir_option_gamma': round(option_greeks.get('gamma'), 6) if option_greeks.get('gamma') is not None else None,
                'dir_option_theta': round(option_greeks.get('theta'), 4) if option_greeks.get('theta') is not None else None,
                'dir_option_vega': round(option_greeks.get('vega'), 4) if option_greeks.get('vega') is not None else None,
                'seller_action': seller_decision.get('action'),
                'seller_strategy': seller_decision.get('strategy'),
                'seller_confidence': seller_decision.get('confidence'),
                'seller_notes': seller_decision.get('notes'),
                'seller_blockers': seller_decision.get('blockers'),
                'seller_position_adjustment': seller_decision.get('position_adjustment'),
                'seller_profit_target': seller_decision.get('profit_target'),
                'seller_writer_context': seller_decision.get('writer_context'),
                'seller_trend_trust_score': seller_decision.get('trend_trust_score'),
                'seller_call_wall_distance_pct': round(call_wall_distance_pct, 2) if call_wall_distance_pct is not None else None,
                'seller_put_wall_distance_pct': round(put_wall_distance_pct, 2) if put_wall_distance_pct is not None else None,
                'seller_walls_within_range': seller_decision.get('walls_ok'),
                'seller_writer_concentration_ok': seller_decision.get('writer_concentration_ok'),
                'seller_iv_percentile': round(seller_decision.get('iv_percentile'), 1) if seller_decision.get('iv_percentile') is not None else None,
                'seller_carry_score': round(seller_decision.get('carry_score'), 2) if seller_decision.get('carry_score') is not None else None,
                'seller_structural_blockers': seller_decision.get('structural_blockers'),
                'current_month_fut': current_fut['tradingsymbol'],
                'current_fut_price': current_latest_price,
                'current_fut_oi': round(current_latest_oi, 0) if current_latest_oi is not None else None,
                'current_fut_avg_volume': round(current_avg_volume, 0) if current_avg_volume is not None else None,
                'current_oi_change_percent': round(current_oi_change_pct,2) if current_oi_change_pct is not None else None,
                'current_price_change_percent': round(current_price_period_change_pct,2) if current_price_period_change_pct is not None else None,
                'current_oi_zscore': f"{current_oi_z:.2f}" if current_oi_z is not None else None,
                'current_price_zscore': f"{current_price_z:.2f}" if current_price_z is not None else None,
                
                # Realized Volatility Metrics (for straddle strategy)
                'current_realized_vol_daily_pct': round(current_realized_vol_daily_pct, 2) if current_realized_vol_daily_pct is not None else None,
                'current_realized_vol_annualized': round(current_realized_vol_annualized, 2) if current_realized_vol_annualized is not None else None,
                'current_avg_abs_daily_move_pct': round(current_avg_abs_daily_move_pct, 2) if current_avg_abs_daily_move_pct is not None else None,
                'current_avg_daily_range_pct': round(current_avg_daily_range_pct, 2) if current_avg_daily_range_pct is not None else None,
                'current_max_single_day_move_pct': round(current_max_single_day_move_pct, 2) if current_max_single_day_move_pct is not None else None,
                'current_max_upswing_pct': round(current_max_upswing_pct, 2) if current_max_upswing_pct is not None else None,
                'current_max_drawdown_pct': round(current_max_drawdown_pct, 2) if current_max_drawdown_pct is not None else None,
                'current_max_excursion_pct': round(current_max_excursion_pct, 2) if current_max_excursion_pct is not None else None,
                
                'daily_avg_oi_change': round(daily_avg_oi_change_val, 0) if daily_avg_oi_change_val is not None else None,
                'daily_avg_oi_percent_change': round(daily_avg_oi_percent_change_val, 2) if daily_avg_oi_percent_change_val is not None else None,
                'current_month_monthly_oi_change': round(current_month_monthly_oi_change_val, 0) if current_month_monthly_oi_change_val is not None else None,
                'current_monthly_oi_percent_change': round(current_monthly_oi_percent_change_val, 2) if current_monthly_oi_percent_change_val is not None else None,
                'todays_net_oi_change': round(todays_net_oi_change_val, 0) if todays_net_oi_change_val is not None else None,
                'todays_net_oi_percent_change': round(todays_net_oi_percent_change_val, 2) if todays_net_oi_percent_change_val is not None else None,
                'todays_oi_vs_daily_avg_percent': round(todays_oi_vs_daily_avg_percent_val, 2) if todays_oi_vs_daily_avg_percent_val is not None else None,
                'todays_oi_vs_monthly_percent': round(todays_oi_vs_monthly_avg_percent_val, 2) if todays_oi_vs_monthly_avg_percent_val is not None else None,
                
                'current_fut_series_lowest_close': round(current_fut_series_lowest_close_val, 2) if pd.notna(current_fut_series_lowest_close_val) else None,
                'current_fut_is_low_protected': current_fut_is_low_protected_val,
                'current_fut_latest_close_vs_series_low_pct': round(current_fut_latest_close_vs_series_low_pct_val, 2) if pd.notna(current_fut_latest_close_vs_series_low_pct_val) else None,
                'next_fut_series_lowest_close': round(next_fut_series_lowest_close_val, 2) if pd.notna(next_fut_series_lowest_close_val) else None,
                'next_fut_is_low_protected': next_fut_is_low_protected_val,
                'next_fut_latest_close_vs_series_low_pct': round(next_fut_latest_close_vs_series_low_pct_val, 2) if pd.notna(next_fut_latest_close_vs_series_low_pct_val) else None,

                'days_to_current_expiry': days_to_current_expiry,
                'current_fut_expiry': current_fut_expiry_date.strftime('%Y-%m-%d'),
                'next_month_fut': next_fut['tradingsymbol'] if next_fut else None,
                'next_fut_price': next_latest_price,
                'next_fut_oi': round(next_latest_oi, 0) if next_latest_oi is not None else None,
                'next_fut_avg_volume': round(next_avg_volume, 0) if next_avg_volume is not None else None,
                'next_oi_change_percent': round(next_oi_change_pct_for_sentiment,2) if next_oi_change_pct_for_sentiment is not None else None,
                'next_price_change_percent': round(next_price_change_pct_for_sentiment,2) if next_price_change_pct_for_sentiment is not None else None,
                'next_oi_zscore': f"{next_oi_z_for_sentiment:.2f}" if next_oi_z_for_sentiment is not None else None,
                'next_price_zscore': f"{next_price_z_for_sentiment:.2f}" if next_price_z_for_sentiment is not None else None,
                
                # Realized Volatility Metrics for Next Month
                'next_realized_vol_daily_pct': round(next_realized_vol_daily_pct, 2) if next_realized_vol_daily_pct is not None else None,
                'next_realized_vol_annualized': round(next_realized_vol_annualized, 2) if next_realized_vol_annualized is not None else None,
                'next_avg_abs_daily_move_pct': round(next_avg_abs_daily_move_pct, 2) if next_avg_abs_daily_move_pct is not None else None,
                'next_avg_daily_range_pct': round(next_avg_daily_range_pct, 2) if next_avg_daily_range_pct is not None else None,
                'next_max_single_day_move_pct': round(next_max_single_day_move_pct, 2) if next_max_single_day_move_pct is not None else None,
                'next_max_upswing_pct': round(next_max_upswing_pct, 2) if next_max_upswing_pct is not None else None,
                'next_max_drawdown_pct': round(next_max_drawdown_pct, 2) if next_max_drawdown_pct is not None else None,
                'next_max_excursion_pct': round(next_max_excursion_pct, 2) if next_max_excursion_pct is not None else None,
                
                'rollover_percent': round(rollover_pct_val,2) if rollover_pct_val is not None else None,
                'rollover_quality_index': rqi_val if rqi_val is not None else None,
                'roll_cost_points': roll_cost_pts if roll_cost_pts is not None else None,
                'roll_cost_percent_of_spot': round(roll_cost_pct,2) if roll_cost_pct is not None else None,
                'term_structure_slope_percent': round(term_structure_slope_val,2) if term_structure_slope_val is not None else None,
                'price_oi_ratio_primary': round(price_oi_ratio_primary_val, 4) if price_oi_ratio_primary_val is not None else None,
                'roll_skew': round(roll_skew_val, 2) if roll_skew_val is not None else None, 
                'sentiment_current': sent_curr, 'sentiment_next': sent_next,
                'analysis_start_date': analysis_start_date_actual.strftime('%Y-%m-%d'),
                'analysis_end_date': analysis_end_date_actual.strftime('%Y-%m-%d'),
                'analysis_trading_days': len(current_hist_df),
                'trade_option_expiry': action_option_expiry_date_obj.strftime('%Y-%m-%d'),
                
                # ATM strike reference
                'atm_strike': round(atm_strike_val, 2) if atm_strike_val is not None else None,
                
                'atm_call_symbol': atm_call_symbol,
                'atm_call_strike': round(atm_call_strike, 2) if atm_call_strike is not None else None,
                'atm_call_last_price': round(atm_call_last_price, 2) if atm_call_last_price is not None else None,
                'atm_call_oi': round(atm_call_oi, 0) if atm_call_oi is not None else None,
                'atm_call_implied_vol': round(atm_call_greeks.get('iv'), 2) if atm_call_greeks.get('iv') is not None else None,
                'atm_call_delta': round(atm_call_greeks.get('delta'), 4) if atm_call_greeks.get('delta') is not None else None,
                'atm_call_gamma': round(atm_call_greeks.get('gamma'), 6) if atm_call_greeks.get('gamma') is not None else None,
                'atm_call_theta': round(atm_call_greeks.get('theta'), 4) if atm_call_greeks.get('theta') is not None else None,
                'atm_call_vega': round(atm_call_greeks.get('vega'), 4) if atm_call_greeks.get('vega') is not None else None,
                'atm_put_symbol': atm_put_symbol,
                'atm_put_strike': round(atm_put_strike, 2) if atm_put_strike is not None else None,
                'atm_put_last_price': round(atm_put_last_price, 2) if atm_put_last_price is not None else None,
                'atm_put_oi': round(atm_put_oi, 0) if atm_put_oi is not None else None,
                'atm_put_implied_vol': round(atm_put_greeks.get('iv'), 2) if atm_put_greeks.get('iv') is not None else None,
                'atm_put_delta': round(atm_put_greeks.get('delta'), 4) if atm_put_greeks.get('delta') is not None else None,
                'atm_put_gamma': round(atm_put_greeks.get('gamma'), 6) if atm_put_greeks.get('gamma') is not None else None,
                'atm_put_theta': round(atm_put_greeks.get('theta'), 4) if atm_put_greeks.get('theta') is not None else None,
                'atm_put_vega': round(atm_put_greeks.get('vega'), 4) if atm_put_greeks.get('vega') is not None else None,

                'confidence_adjustments': "; ".join(confidence_adjustments) if confidence_adjustments else None,
                'recommended_holding_period': recommended_holding_period,
                'institutional_breakout_triggered': institutional_breakout,
                'writer_trap_confidence_applied': writer_trap_confidence_applied,
                'straddle_confidence_percent': round(straddle_confidence, 1) if straddle_confidence is not None else None,
                'straddle_viability': straddle_viability_tag,
                'straddle_rationale': straddle_rationale_str,
                'straddle_entry_status': straddle_entry_ok,
                'straddle_entry_blockers': straddle_entry_blockers_str,
                'straddle_entry_notes': straddle_entry_notes_str,
                'straddle_position_adjustment': straddle_position_adjustment,
                'straddle_profit_target_note': straddle_profit_target_note,

                # Trend trust diagnostics
                'trend_trust_score': round(trend_trust_meta.get('score'), 1) if trend_trust_meta and trend_trust_meta.get('score') is not None else None,
                'trend_trust_required_score': round(trend_trust_meta.get('required_score'), 1) if trend_trust_meta and trend_trust_meta.get('required_score') is not None else None,
                'trend_trust_rqi_score': round(trend_trust_meta.get('rqi_score'), 2) if trend_trust_meta and trend_trust_meta.get('rqi_score') is not None else None,
                'trend_trust_roll_score': round(trend_trust_meta.get('roll_score'), 2) if trend_trust_meta and trend_trust_meta.get('roll_score') is not None else None,
                'trend_trust_term_score': round(trend_trust_meta.get('term_score'), 2) if trend_trust_meta and trend_trust_meta.get('term_score') is not None else None,
                'trend_trust_rqi_floor_breached': trend_trust_meta.get('floors_breached', {}).get('rqi') if trend_trust_meta else None,
                'trend_trust_roll_floor_breached': trend_trust_meta.get('floors_breached', {}).get('roll') if trend_trust_meta else None,
                'trend_trust_term_floor_breached': trend_trust_meta.get('floors_breached', {}).get('term') if trend_trust_meta else None
            }
            result.update({f"writer_{k.replace(' ', '_')}": v for k,v in writer_analysis.items()})
            logger.info(
                f"ADVANCED Analysis COMPLETE for {symbol} - DirAction: {directional_decision.get('action')} "
                f"| SellerAction: {seller_decision.get('action')}"
            )
            return result
        except Exception as e:
            logger.error(f"Major error in ADVANCED analysis for {symbol}: {traceback.format_exc()}")
            return None
    def _analyze_symbol_worker(self, symbol_name, trading_days):
        """
        Wrapper to execute analyze_trend_advanced so we can safely run it inside ThreadPoolExecutor
        and propagate token exceptions if they occur.
        """
        return self.analyze_trend_advanced(symbol_name, trading_days=trading_days)

    def run_trend_scan(self, trading_days=7):
        logger.info(f"Starting trend scan at {datetime.now(self.ist_timezone).strftime('%Y-%m-%d %H:%M:%S')} under detected regime: {self.detected_market_regime}")

        symbols = self.read_symbols()
        if not symbols:
            logger.error("No symbols to process. Exiting scan.")
            return

        self.results = []
        processed_symbols_in_run = set()
        future_to_symbol = {}
        logger.info(f"Sequential processing kills speed; spawning ThreadPoolExecutor with {self.max_workers} workers for up to 5-10x throughput.")
        try:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                for symbol_name in symbols:
                    symbol_name = str(symbol_name).strip().upper()
                    if not symbol_name:
                        continue
                    if symbol_name in processed_symbols_in_run:
                        logger.info(f"Skipping duplicate symbol in input list: {symbol_name}")
                        continue
                    processed_symbols_in_run.add(symbol_name)
                    future = executor.submit(self._analyze_symbol_worker, symbol_name, trading_days)
                    future_to_symbol[future] = symbol_name

                try:
                    for completed_future in as_completed(future_to_symbol):
                        symbol_name = future_to_symbol[completed_future]
                        try:
                            analysis_result = completed_future.result()
                            if analysis_result is not None:
                                self.results.append(analysis_result)
                            else:
                                logger.warning(f"No analysis result for {symbol_name} from advanced analysis.")
                        except kiteconnect.exceptions.TokenException as te:
                            logger.critical(f"TokenException encountered for {symbol_name}. Halting further processing. {te}")
                            for pending_future in future_to_symbol:
                                if pending_future is not completed_future:
                                    pending_future.cancel()
                            if self.results:
                                self.save_results()
                            raise
                        except Exception:
                            logger.error(f"CRITICAL Error processing {symbol_name}: {traceback.format_exc()}")
                except KeyboardInterrupt:
                    logger.warning("Trend scan interrupted by user. Cancelling outstanding symbol analyses...")
                    for pending_future in future_to_symbol:
                        pending_future.cancel()
                    raise
        except KeyboardInterrupt:
            if self.results:
                self.save_results()
                logger.info("Partial trend-scan results saved after manual interruption.")
            else:
                logger.info("Trend scan interrupted before any results were produced.")
            return

        if self.results: self.save_results()
        else: logger.info("No results generated in this run to save.")

    def save_results(self):
        if not self.results:
            logger.info("No results to save.")
            return
        valid_results = [r for r in self.results if isinstance(r, dict)]
        if not valid_results:
            logger.info("No valid dictionary results to save.")
            return

        df = pd.DataFrame(valid_results)
        if 'timestamp' in df.columns:
             try:
                df['timestamp'] = pd.to_datetime(df['timestamp'], errors='coerce').dt.strftime('%Y-%m-%d %H:%M:%S')
             except AttributeError:
                logger.debug("Timestamp column already string or unconvertible, skipping strftime.")
             except Exception as e:
                logger.error(f"Error formatting 'timestamp' column: {e}")

        run_ts_str = datetime.now(self.ist_timezone).strftime('%Y%m%d_%H%M%S')
        output_file = f"trend_results_adaptive_v10_nuance_{run_ts_str}.csv" 
        try:
            core_cols = [
                'timestamp', 'symbol', 'detected_market_regime', 'spot_price',
                'combined_sentiment', 'confidence_percent', 'action',
                'dir_action', 'dir_confidence', 'dir_context', 'dir_holding_period', 'dir_notes',
                'seller_action', 'seller_strategy', 'seller_confidence', 'seller_notes',
                'seller_blockers', 'seller_position_adjustment', 'seller_profit_target',
                'trade_option_expiry'
            ]
            fut_cols = ['current_month_fut', 'current_fut_price', 'current_fut_oi', 'current_fut_avg_volume', 'current_oi_change_percent', 'current_price_change_percent', 'current_oi_zscore', 'current_price_zscore', 'days_to_current_expiry', 'current_fut_expiry']
            
            oi_detail_cols = [
                'daily_avg_oi_change', 'daily_avg_oi_percent_change', 
                'current_month_monthly_oi_change', 'current_monthly_oi_percent_change',
                'todays_net_oi_change', 'todays_net_oi_percent_change',
                'todays_oi_vs_daily_avg_percent', 'todays_oi_vs_monthly_percent'
            ]
            
            # --- NEW NUANCE PRICE JOURNEY COLUMN LIST ---
            price_journey_nuance_cols = [
                'current_fut_series_lowest_close', 'current_fut_is_low_protected', 'current_fut_latest_close_vs_series_low_pct',
                'next_fut_series_lowest_close', 'next_fut_is_low_protected', 'next_fut_latest_close_vs_series_low_pct'
            ]
            # --- END OF NEW NUANCE PRICE JOURNEY COLUMN LIST ---

            next_fut_cols = ['next_month_fut', 'next_fut_price', 'next_fut_oi', 'next_fut_avg_volume', 'next_oi_change_percent', 'next_price_change_percent', 'next_oi_zscore', 'next_price_zscore']
            roll_cols = ['rollover_percent', 'rollover_quality_index', 'roll_cost_points', 'roll_cost_percent_of_spot', 'term_structure_slope_percent', 'price_oi_ratio_primary', 'roll_skew']
            
            # --- NEW OPTION DETAILS COLUMNS ---
            option_cols = [
                'dir_option_symbol', 'dir_option_strike', 'dir_option_type',
                'dir_option_premium', 'dir_option_oi', 'dir_option_volume',
                'dir_option_iv', 'dir_option_delta', 'dir_option_gamma',
                'dir_option_theta', 'dir_option_vega',
                'atm_strike',
                'atm_call_symbol', 'atm_call_strike', 'atm_call_last_price', 'atm_call_oi',
                'atm_call_implied_vol', 'atm_call_delta', 'atm_call_gamma', 'atm_call_theta', 'atm_call_vega',
                'atm_put_symbol', 'atm_put_strike', 'atm_put_last_price', 'atm_put_oi',
                'atm_put_implied_vol', 'atm_put_delta', 'atm_put_gamma', 'atm_put_theta', 'atm_put_vega',
            ]
            # --- END OF NEW OPTION DETAILS COLUMNS ---

            trade_notes_cols = [
                'seller_writer_context',
                'seller_trend_trust_score',
                'confidence_adjustments',
                'recommended_holding_period',
                'institutional_breakout_triggered',
                'writer_trap_confidence_applied',
                'straddle_confidence_percent',
                'straddle_viability',
                'straddle_rationale',
                'straddle_entry_status',
                'straddle_entry_blockers',
                'straddle_entry_notes',
                'straddle_position_adjustment',
                'straddle_profit_target_note'
            ]

            seller_structural_cols = [
                'seller_call_wall_distance_pct',
                'seller_put_wall_distance_pct',
                'seller_walls_within_range',
                'seller_writer_concentration_ok',
                'seller_iv_percentile',
                'seller_carry_score',
                'seller_structural_blockers'
            ]

            trend_trust_cols = [
                'trend_trust_score', 'trend_trust_required_score',
                'trend_trust_rqi_score', 'trend_trust_roll_score', 'trend_trust_term_score',
                'trend_trust_rqi_floor_breached', 'trend_trust_roll_floor_breached', 'trend_trust_term_floor_breached'
            ]
            
            writer_cols = sorted([col for col in df.columns if col.startswith('writer_')])
            analysis_info_cols = ['analysis_start_date', 'analysis_end_date', 'analysis_trading_days']

            ordered_cols = []
            for col_list in [core_cols, fut_cols, oi_detail_cols, price_journey_nuance_cols, next_fut_cols, roll_cols, option_cols, seller_structural_cols, trade_notes_cols, trend_trust_cols, writer_cols, analysis_info_cols]:
                for col in col_list:
                    if col in df.columns and col not in ordered_cols:
                        ordered_cols.append(col)
            remaining_cols = sorted([col for col in df.columns if col not in ordered_cols])
            final_column_order = ordered_cols + remaining_cols

            df = df[final_column_order]

            df.to_csv(output_file, index=False, float_format='%.2f')
            logger.info(f"Trend results saved to {output_file} with {len(df)} rows.")
        except Exception as e:
            logger.error(f"Error saving results to {output_file}: {traceback.format_exc()}")

def main():
    API_KEY = "3bi2yh8g830vq3y6" # Replace with your actual API key
    ACCESS_TOKEN = "xsiAN33KkQSJJozp8wA5srbD4yRg32iV" # Replace with your actual access token

    TRADING_DAYS_FOR_SCAN_ANALYSIS =  1
    MAX_PARALLEL_ANALYSES = 3
    logger.info(f"Script will use an analysis window of {TRADING_DAYS_FOR_SCAN_ANALYSIS} trading days.")

    if API_KEY == "YOUR_API_KEY" or ACCESS_TOKEN == "YOUR_ACCESS_TOKEN":
        logger.error("API_KEY or ACCESS_TOKEN not set. Update in main().")
        print("ERROR: API_KEY or ACCESS_TOKEN not set. Please update them in the script.")
        return

    input_csv_file = "data/FNOStock.csv"
    import os
    data_dir = "data"
    if not os.path.exists(data_dir):
        try:
            os.makedirs(data_dir)
            logger.info(f"Created directory: {data_dir}")
        except Exception as e_dir:
            logger.error(f"Could not create directory {data_dir}: {e_dir}")
            return

    if not os.path.exists(input_csv_file):
        logger.warning(f"Input CSV not found: {input_csv_file}. Creating a dummy file with a few symbols.")
        try:
            with open(input_csv_file, 'w') as f:
                f.write("Symbol\nRELIANCE\nINFY\nSBIN\nTCS\nICICIBANK\nAXISBANK\nAARTIIND\nABB\nABCAPITAL\nCDSL\nICICIPRULI\nADANIENT\nCUMMINSIND\nPRESTIGE\n")
            logger.info(f"Created dummy input CSV: {input_csv_file}.")
        except Exception as e_csv:
            logger.error(f"Could not create dummy CSV {input_csv_file}: {e_csv}")
            return

    try:
        actual_api_key = API_KEY 
        actual_access_token = ACCESS_TOKEN
        
        if actual_api_key == "YOUR_API_KEY" or actual_access_token == "YOUR_ACCESS_TOKEN":
            logger.error("Critical: API_KEY or ACCESS_TOKEN placeholders detected in main execution block. Exiting.")
            print("ERROR: Please replace YOUR_API_KEY and YOUR_ACCESS_TOKEN with actual credentials.")
            return
            
        scanner = TrendScanner(
            api_key=actual_api_key,
            access_token=actual_access_token,
            input_csv=input_csv_file,
            max_workers=MAX_PARALLEL_ANALYSES
        )
        scanner.run_trend_scan(trading_days=TRADING_DAYS_FOR_SCAN_ANALYSIS)
    except kiteconnect.exceptions.TokenException as te:
        logger.critical(f"Kite Connect Token Exception: {te}. Please check your API key and access token. It might be expired or invalid.")
        print(f"A critical Kite Connect Token error occurred: {te}. Ensure your access token is valid and not expired.")
    except kiteconnect.exceptions.NetworkException as ne:
        logger.critical(f"Kite Connect Network Exception: {ne}. Check your internet connection and Kite API status.")
        print(f"A Kite Connect Network error occurred: {ne}. Please check your internet connection.")
    except ValueError as ve:
        logger.critical(f"ValueError during initialization or processing: {ve}")
        print(f"A critical ValueError occurred: {ve}")
    except Exception as e:
        logger.critical(f"Unhandled exception in main: {traceback.format_exc()}")
        print(f"A critical error occurred: {e}")

if __name__ == "__main__":
    main()