"""Quick check to see actual data in cache"""
import os
import pickle
import pandas as pd

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
cache_dir = os.path.join(SCRIPT_DIR, "MB_Breakout_Cache", "historical")

if not os.path.exists(cache_dir):
    print("No cache found!")
else:
    files = [f for f in os.listdir(cache_dir) if f.endswith('.pkl')]
    print(f"Total cache files: {len(files)}\n")
    
    print("Checking first 5 files:\n")
    for i, f in enumerate(files[:5]):
        symbol = f.split('_')[0]
        path = os.path.join(cache_dir, f)
        
        try:
            with open(path, 'rb') as file:
                data = pickle.load(file)
            
            if data:
                df = pd.DataFrame(data)
                print(f"{i+1}. {symbol}: {len(data)} rows in raw data, {len(df)} after DataFrame")
                
                # Show date range
                if 'date' in df.columns:
                    df['date'] = pd.to_datetime(df['date'])
                    print(f"   Date range: {df['date'].min()} to {df['date'].max()}")
                else:
                    print(f"   Columns: {df.columns.tolist()}")
            else:
                print(f"{i+1}. {symbol}: EMPTY")
                
        except Exception as e:
            print(f"{i+1}. {symbol}: ERROR - {e}")
        
        print()

