"""
Momentum Breakout Scanner - DIAGNOSTIC MODE
Shows stocks that almost passed and which conditions they failed
"""

import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import pandas_ta as ta
from datetime import datetime, timedelta
import logging
import os
import pickle
import time
from typing import Optional, List, Dict, Tuple
from dataclasses import dataclass

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# API Credentials
API_KEY = "3bi2yh8g830vq3y6"
ACCESS_TOKEN = "7uCdOd1Je1xRzfajiTYrlts6bgH4CV46"

# Configuration
@dataclass
class ScannerConfig:
    lookback_days: int = 60
    near_high_threshold: float = 0.95
    weekly_days: int = 5
    weekly_gain_threshold: float = 0.10
    min_avg_turnover: float = 5e7
    turnover_lookback: int = 20
    atr_period: int = 14
    min_atr_percent: float = 2.0
    max_atr_percent: float = 15.0
    total_lookback_days: int = 180  # Match main scanner - fetches ~125 trading days
    api_delay_seconds: float = 0.35
    min_required_trading_days: int = 60  # Minimum 60 trading days needed for analysis

config = ScannerConfig()

# Caching
# Get script directory to create cache relative to script location, not working directory
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.join(SCRIPT_DIR, "MB_Breakout_Cache")
INSTRUMENTS_CACHE_FILE = os.path.join(CACHE_DIR, "nse_instruments.pkl")
HISTORICAL_CACHE_DIR = os.path.join(CACHE_DIR, "historical")
os.makedirs(HISTORICAL_CACHE_DIR, exist_ok=True)
os.makedirs(CACHE_DIR, exist_ok=True)

UNIVERSE_CSV = os.path.join(SCRIPT_DIR, "..", "..", "..", "data", "29oct2025_sector_marketcap_freefloat_20251101_150338.csv")

@dataclass
class DiagnosticResult:
    """Detailed diagnostic for each stock"""
    symbol: str
    price: float
    
    # Condition 1: Near 3M high
    dist_from_high_pct: float
    passed_high: bool
    
    # Condition 2: Weekly gain
    weekly_return_pct: float
    passed_weekly: bool
    
    # Condition 3: Liquidity
    avg_turnover_cr: float
    passed_liquidity: bool
    
    # Condition 4: ATR
    atr_percent: float
    passed_atr: bool
    
    # Summary
    conditions_passed: int
    total_conditions: int = 4
    
    def __repr__(self):
        return f"{self.symbol}: {self.conditions_passed}/4 passed"

# Helper functions from main scanner
def load_nse_instruments(kite_instance):
    if os.path.exists(INSTRUMENTS_CACHE_FILE):
        try:
            with open(INSTRUMENTS_CACHE_FILE, "rb") as f:
                return pickle.load(f)
        except:
            pass
    instruments = kite_instance.instruments(exchange="NSE")
    with open(INSTRUMENTS_CACHE_FILE, "wb") as f:
        pickle.dump(instruments, f)
    return instruments

def load_universe_symbols():
    df = pd.read_csv(UNIVERSE_CSV)
    return df['Symbol'].unique().tolist()

def get_historical_data_cached(kite_instance, symbol, token, from_date, to_date, interval="day"):
    from_date_str = from_date.strftime('%Y%m%d')
    to_date_str = to_date.strftime('%Y%m%d')
    cache_file = os.path.join(HISTORICAL_CACHE_DIR, f"{symbol}_{token}_{from_date_str}_{to_date_str}_{interval}.pkl")
    
    if os.path.exists(cache_file):
        try:
            with open(cache_file, "rb") as f:
                return pickle.load(f)
        except:
            pass
    
    time.sleep(config.api_delay_seconds)
    try:
        data = kite_instance.historical_data(token, from_date, to_date, interval)
        if data:
            with open(cache_file, "wb") as f:
                pickle.dump(data, f)
        return data
    except Exception as e:
        logger.error(f"Error fetching {symbol}: {e}")
        return []

def calculate_atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    return ta.atr(high=df['high'], low=df['low'], close=df['close'], length=period)

def diagnose_stock(df: pd.DataFrame, symbol: str, debug: bool = False) -> Optional[DiagnosticResult]:
    """Diagnose a single stock and return which conditions it passes/fails"""
    try:
        if df is None:
            return None
        
        if debug:
            logger.info(f"{symbol}: Has {len(df)} trading days after processing")
            
        if len(df) < config.min_required_trading_days:
            if debug:
                logger.info(f"{symbol}: TOO SHORT - need {config.min_required_trading_days}, have {len(df)}")
            return None
        
        df = df.sort_index()
        latest = df.iloc[-1]
        current_close = latest['close']
        
        # Check each condition
        conditions_passed = 0
        
        # 1. Near 3M high
        lookback_df = df.iloc[-config.lookback_days:]
        three_month_high = lookback_df['high'].max()
        dist_from_high_pct = ((three_month_high - current_close) / three_month_high) * 100
        passed_high = dist_from_high_pct <= (100 - config.near_high_threshold * 100)
        if passed_high:
            conditions_passed += 1
        
        # 2. Weekly gain
        weekly_start_price = df.iloc[-(config.weekly_days + 1)]['close']
        weekly_return_pct = ((current_close - weekly_start_price) / weekly_start_price) * 100
        passed_weekly = weekly_return_pct >= (config.weekly_gain_threshold * 100)
        if passed_weekly:
            conditions_passed += 1
        
        # 3. Liquidity
        turnover_df = df.iloc[-config.turnover_lookback:]
        avg_turnover = (turnover_df['close'] * turnover_df['volume']).mean()
        avg_turnover_cr = avg_turnover / 1e7
        passed_liquidity = avg_turnover >= config.min_avg_turnover
        if passed_liquidity:
            conditions_passed += 1
        
        # 4. ATR
        atr_series = calculate_atr(df, period=config.atr_period)
        if atr_series is None or pd.isna(atr_series.iloc[-1]):
            atr_percent = 0
            passed_atr = False
        else:
            atr_value = atr_series.iloc[-1]
            atr_percent = (atr_value / current_close) * 100
            passed_atr = (config.min_atr_percent <= atr_percent <= config.max_atr_percent)
            if passed_atr:
                conditions_passed += 1
        
        return DiagnosticResult(
            symbol=symbol,
            price=current_close,
            dist_from_high_pct=dist_from_high_pct,
            passed_high=passed_high,
            weekly_return_pct=weekly_return_pct,
            passed_weekly=passed_weekly,
            avg_turnover_cr=avg_turnover_cr,
            passed_liquidity=passed_liquidity,
            atr_percent=atr_percent,
            passed_atr=passed_atr,
            conditions_passed=conditions_passed
        )
    except Exception as e:
        logger.debug(f"Error diagnosing {symbol}: {e}")
        return None

def run_diagnostic():
    """Run diagnostic scan"""
    print("\n" + "="*80)
    print("MOMENTUM BREAKOUT SCANNER - DIAGNOSTIC MODE")
    print("="*80 + "\n")
    
    # Initialize Kite
    kite = KiteConnect(api_key=API_KEY)
    kite.set_access_token(ACCESS_TOKEN)
    
    end_date = datetime.now().date()
    start_date = end_date - timedelta(days=config.total_lookback_days)
    
    # Load instruments
    instruments = load_nse_instruments(kite)
    instruments_df = pd.DataFrame(instruments)
    equity_instruments = instruments_df[
        (instruments_df["segment"] == "NSE") &
        (instruments_df["instrument_type"] == "EQ")
    ].copy()
    
    custom_symbols = load_universe_symbols()
    equity_instruments = equity_instruments[equity_instruments["tradingsymbol"].isin(custom_symbols)]
    instrument_map = equity_instruments.set_index('instrument_token')['tradingsymbol'].to_dict()
    
    print(f"Scanning {len(instrument_map)} stocks from universe...\n")
    
    # Scan all stocks
    results = []
    scanned = 0
    skipped_no_data = 0
    skipped_too_short = 0
    skipped_error = 0
    
    for token, symbol in instrument_map.items():
        scanned += 1
        if scanned % 50 == 0:
            print(f"Progress: {scanned}/{len(instrument_map)}... ({len(results)} analyzed so far)")
        
        data_list = get_historical_data_cached(kite, symbol, token, start_date, end_date)
        if not data_list:
            skipped_no_data += 1
            continue
        
        df = pd.DataFrame(data_list)
        try:
            df['date'] = pd.to_datetime(df['date']).dt.tz_localize(None)
            df.set_index('date', inplace=True)
            
            for col in ['open', 'high', 'low', 'close', 'volume']:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors='coerce')
            
            df.dropna(subset=['open', 'high', 'low', 'close'], inplace=True)
            
            if df.empty:
                skipped_too_short += 1
                continue
            
            if len(df) < config.min_required_trading_days:
                skipped_too_short += 1
                # Debug first few
                if scanned <= 3:
                    logger.info(f"DEBUG {symbol}: {len(df)} days < {config.min_required_trading_days} required")
                continue
                
            result = diagnose_stock(df, symbol, debug=(scanned <= 3))
            if result:
                results.append(result)
        except Exception as e:
            skipped_error += 1
            if len(results) == 0 and scanned <= 5:  # Debug first few
                logger.error(f"Error processing {symbol}: {e}")
            continue
    
    print(f"\nData quality summary:")
    print(f"  Total scanned: {scanned}")
    print(f"  Successfully analyzed: {len(results)}")
    print(f"  Skipped (no data): {skipped_no_data}")
    print(f"  Skipped (too short): {skipped_too_short}")
    print(f"  Skipped (errors): {skipped_error}")
    
    # Analyze results
    print("\n" + "="*80)
    print("DIAGNOSTIC SUMMARY")
    print("="*80 + "\n")
    
    # Count by conditions passed
    by_conditions = {}
    for r in results:
        count = r.conditions_passed
        if count not in by_conditions:
            by_conditions[count] = []
        by_conditions[count].append(r)
    
    print(f"Total stocks analyzed: {len(results)}")
    print(f"\nBreakdown by conditions passed:")
    for i in range(4, -1, -1):
        count = len(by_conditions.get(i, []))
        pct = (count / len(results) * 100) if results else 0
        print(f"  {i}/4 conditions: {count:4d} stocks ({pct:5.1f}%)")
    
    # Show stocks that passed 3/4 (close calls)
    near_misses = by_conditions.get(3, [])
    if near_misses:
        print(f"\n{'='*80}")
        print(f"STOCKS THAT PASSED 3/4 CONDITIONS (Near-misses)")
        print(f"{'='*80}\n")
        
        # Sort by distance from high (closest first)
        near_misses.sort(key=lambda x: x.dist_from_high_pct)
        
        print(f"{'Symbol':<12} {'Price':>8} | {'3M High':^8} | {'Weekly':^8} | {'Liquidity':^10} | {'ATR':^8} | Failed Condition")
        print("-" * 80)
        
        for r in near_misses[:20]:  # Show top 20
            failed = []
            if not r.passed_high:
                failed.append(f"3M High ({r.dist_from_high_pct:.1f}% away)")
            if not r.passed_weekly:
                failed.append(f"Weekly ({r.weekly_return_pct:+.1f}%)")
            if not r.passed_liquidity:
                failed.append(f"Liquidity (₹{r.avg_turnover_cr:.1f}cr)")
            if not r.passed_atr:
                failed.append(f"ATR ({r.atr_percent:.1f}%)")
            
            print(f"{r.symbol:<12} ₹{r.price:>7.2f} | "
                  f"{'✓' if r.passed_high else '✗':^8} | "
                  f"{'✓' if r.passed_weekly else '✗':^8} | "
                  f"{'✓' if r.passed_liquidity else '✗':^10} | "
                  f"{'✓' if r.passed_atr else '✗':^8} | "
                  f"{', '.join(failed)}")
    
    # Condition failure analysis
    print(f"\n{'='*80}")
    print(f"CONDITION FAILURE ANALYSIS")
    print(f"{'='*80}\n")
    
    total = len(results)
    
    if total == 0:
        print("⚠️  ERROR: Zero stocks could be analyzed!")
        print("\nPossible causes:")
        print("  1. Data processing issue - check if historical data is being loaded correctly")
        print("  2. All stocks have insufficient data (<150 days)")
        print("  3. Data format issue in cached files")
        print("\nRecommended fixes:")
        print("  1. Delete cache and re-run: rmdir /s MB_Breakout_Cache")
        print("  2. Check if universe CSV has valid symbols")
        print("  3. Verify Kite API is returning data")
        return
    
    high_fails = sum(1 for r in results if not r.passed_high)
    weekly_fails = sum(1 for r in results if not r.passed_weekly)
    liquidity_fails = sum(1 for r in results if not r.passed_liquidity)
    atr_fails = sum(1 for r in results if not r.passed_atr)
    
    print(f"Condition failures:")
    print(f"  1. Near 3M High:    {high_fails:4d}/{total} ({high_fails/total*100:5.1f}%) - Require within 5% of 60-day high")
    print(f"  2. Weekly Gain:     {weekly_fails:4d}/{total} ({weekly_fails/total*100:5.1f}%) - Require +10% in past week")
    print(f"  3. Liquidity:       {liquidity_fails:4d}/{total} ({liquidity_fails/total*100:5.1f}%) - Require ₹5cr avg turnover")
    print(f"  4. ATR %:           {atr_fails:4d}/{total} ({atr_fails/total*100:5.1f}%) - Require 2-15% ATR")
    
    # Suggestions
    print(f"\n{'='*80}")
    print(f"RECOMMENDATIONS")
    print(f"{'='*80}\n")
    
    if weekly_fails > total * 0.7:
        print("⚠️  WEEKLY GAIN is the main blocker (>70% failure rate)")
        print("   → Market may be consolidating. Consider:")
        print("     - Lower weekly threshold to 7%: python run_momentum_breakout.py --preset aggressive")
        print("     - Wait for stronger market momentum")
        print()
    
    if high_fails > total * 0.7:
        print("⚠️  NEAR 3M HIGH is the main blocker (>70% failure rate)")
        print("   → Stocks not at highs. Consider:")
        print("     - Expand range to 10%: python run_momentum_breakout.py --preset aggressive")
        print("     - Wait for more stocks to break out")
        print()
    
    if liquidity_fails > total * 0.5:
        print("⚠️  LIQUIDITY is blocking many stocks (>50% failure rate)")
        print("   → Consider:")
        print("     - Lower to ₹2cr: python run_momentum_breakout.py --preset aggressive")
        print("     - Use larger cap stocks: python run_momentum_breakout.py --preset liquid")
        print()
    
    if near_misses:
        print("✅ GOOD NEWS: Found stocks that passed 3/4 conditions!")
        print("   → Monitor these stocks - they may trigger soon")
        print("   → Set price alerts on the near-misses above")
        print()
    
    perfect_count = len(by_conditions.get(4, []))
    if perfect_count == 0:
        print("💡 TIP: No perfect matches today. This is normal in:")
        print("   - Sideways/consolidating markets")
        print("   - After strong rallies (stocks need to digest gains)")
        print("   - During corrections")
        print()
        print("   Try running with aggressive preset or wait for stronger momentum.")
    
    print("\n" + "="*80)
    print("Diagnostic complete!")
    print("="*80 + "\n")

if __name__ == "__main__":
    run_diagnostic()

