# Momentum Breakout Scanner - Complete Documentation Index

## 📋 Overview

This directory contains a **Momentum Breakout Scanner** implementation based on the **Stan Weinstein / Shake Pryzby Stage Analysis** methodology. The scanner identifies stocks in early-stage breakout phases with strong momentum, high liquidity, and healthy volatility.

**Created:** November 3, 2025  
**Methodology:** Stage Analysis / Momentum Breakout  
**Target Market:** NSE (India)

---

## 📁 Files in This Package

### Core Scanner Files

| File | Purpose | Lines |
|------|---------|-------|
| `momentum_breakout_scanner.py` | Main scanner implementation | ~750 |
| `run_momentum_breakout.py` | Preset-based runner script | ~150 |
| `test_momentum_setup.py` | Setup validation utility | ~300 |

### Documentation

| File | Content | Audience |
|------|---------|----------|
| `MOMENTUM_BREAKOUT_README.md` | Complete methodology & usage docs | All users |
| `QUICKSTART_MOMENTUM.md` | 5-minute quick start guide | New users |
| `MOMENTUM_SCANNER_INDEX.md` | This file - navigation hub | All users |

### Supporting Files

| File | Purpose |
|------|---------|
| `requirements_momentum_scanner.txt` | Python dependencies |
| `MB_Breakout_Cache/` | Cache directory (auto-created) |
| `momentum_breakout_signals_*.xlsx` | Output files (generated) |

---

## 🚀 Quick Navigation

### I'm new here - where do I start?
👉 **[QUICKSTART_MOMENTUM.md](QUICKSTART_MOMENTUM.md)** - Get running in 5 minutes

### I want to understand the methodology
👉 **[MOMENTUM_BREAKOUT_README.md](MOMENTUM_BREAKOUT_README.md)** - Complete documentation

### I want to validate my setup
👉 Run `python test_momentum_setup.py`

### I'm ready to scan
👉 Run `python run_momentum_breakout.py --preset default`

### I need help with trading the signals
👉 **[QUICKSTART_MOMENTUM.md](QUICKSTART_MOMENTUM.md)** → Section: "Quick Trading Guide"

### I want to customize the scanner
👉 **[MOMENTUM_BREAKOUT_README.md](MOMENTUM_BREAKOUT_README.md)** → Section: "Customization"

---

## 📖 Documentation Guide

### 1. Quick Start (5 minutes)
**File:** `QUICKSTART_MOMENTUM.md`

**What you'll learn:**
- Installation steps
- Basic configuration
- Running your first scan
- Reading the output
- Entry/exit guidelines

**Best for:**
- New users
- Getting started quickly
- Quick reference

---

### 2. Complete Documentation (30 minutes)
**File:** `MOMENTUM_BREAKOUT_README.md`

**What you'll learn:**
- Detailed methodology explanation
- Each scan condition explained
- Scoring system breakdown
- Customization options
- Performance optimization
- Backtesting notes

**Best for:**
- Understanding the logic
- Advanced customization
- Performance tuning
- Research and development

---

### 3. Code Documentation
**File:** `momentum_breakout_scanner.py`

**What you'll find:**
- Inline code comments
- Function docstrings
- Configuration parameters
- Data structures

**Best for:**
- Developers
- Creating custom variations
- Integration with other systems

---

## 🎯 Common Use Cases

### Use Case 1: Daily Momentum Scan
**Goal:** Find fresh breakout opportunities every day

**Steps:**
1. Run scanner daily after market close
2. Use default preset
3. Focus on Score ≥75 signals
4. Create watchlist for next day

**Command:**
```bash
python run_momentum_breakout.py --preset default
```

---

### Use Case 2: High-Quality Signals Only
**Goal:** Find the absolute best setups

**Steps:**
1. Use conservative preset
2. Filter for Score ≥80
3. Require RS Rating ≥60
4. Verify manually before trading

**Command:**
```bash
python run_momentum_breakout.py --preset conservative
```

---

### Use Case 3: Active Trading
**Goal:** Find many opportunities for active management

**Steps:**
1. Use aggressive preset
2. Accept Score ≥60
3. Monitor more positions
4. Tighter stop losses

**Command:**
```bash
python run_momentum_breakout.py --preset aggressive
```

---

### Use Case 4: Large-Cap Focus
**Goal:** Trade only highly liquid blue chips

**Steps:**
1. Use liquid preset
2. Focus on Score ≥70
3. Larger position sizes possible
4. Easy execution

**Command:**
```bash
python run_momentum_breakout.py --preset liquid
```

---

### Use Case 5: Explosive Momentum
**Goal:** Catch parabolic moves

**Steps:**
1. Use momentum preset
2. Look for Weekly Gain ≥20%
3. Strong volume confirmation needed
4. Wider stops, let winners run

**Command:**
```bash
python run_momentum_breakout.py --preset momentum
```

---

## 🔧 Troubleshooting Guide

### Problem: Scanner won't run

**Solution Path:**
1. Run `python test_momentum_setup.py`
2. Check which tests failed
3. Fix issues (usually missing packages or API creds)
4. Re-run validation
5. Try scanner again

---

### Problem: No signals found

**Possible Causes:**
- Market conditions (bear market)
- Universe too small
- Filters too strict
- Trading holiday

**Solutions:**
- Try aggressive preset
- Expand universe
- Check market regime
- Verify date is trading day

---

### Problem: Too many signals

**Possible Causes:**
- Strong bull market
- Aggressive preset
- Filters too loose

**Solutions:**
- Use conservative preset
- Raise quality bar (Score ≥80)
- Add RS filter (RS ≥60)
- Reduce universe to large-caps

---

### Problem: Slow performance

**Possible Causes:**
- First run (fetching data)
- Large universe
- Slow internet
- Cache not working

**Solutions:**
- First run always slow (15-30 min)
- Verify cache directory exists
- Reduce universe size
- Check `MB_Breakout_Cache/` folder

---

## 📊 Understanding the Scan Logic

### Core Conditions (All Must Be True)

```
1. Price near 3-month high
   close >= 0.95 × max(high, 60 days)
   
2. Strong weekly momentum
   (close / close[-5]) - 1 >= 0.10
   
3. Sufficient liquidity
   avg(close × volume, 20 days) >= ₹5 crore
   
4. Healthy volatility
   2% <= ATR(14) / close × 100 <= 15%
```

### Additional Metrics (For Scoring)

```
- Volume ratio vs average
- Above 50-day MA
- Above 200-day MA
- Relative strength vs NIFTY 50
```

### Composite Score Calculation

```
Score = Proximity(25) + Momentum(25) + Liquidity(15) 
      + ATR(10) + Volume(10) + MAs(10) + RS(15)
      
Max theoretical: 100+ (with bonuses)
Normalized: 0-100
```

---

## 🎓 Learning Resources

### Books
- **Stan Weinstein** - *Secrets for Profiting in Bull and Bear Markets*
- **Mark Minervini** - *Think & Trade Like a Champion*
- **David Ryan** - *How to Make Money in Stocks* (IBD methodology)

### Online
- **Shake Pryzby** on Twitter/X (modern Stage Analysis)
- **IBD MarketSmith** - RS Rating methodology
- **Stage Analysis Forum** - Community discussions

### Related Scanners in This Project
- `timeless_market_scanner.py` - Contraction → Expansion
- `MBI.py` - Market breadth indicators
- `AKMarketCheck.py` - Market regime analysis

---

## 🔄 Preset Comparison Table

| Feature | Conservative | Default | Momentum | Aggressive | Liquid |
|---------|--------------|---------|----------|------------|--------|
| **Proximity to High** | 98% (2% away) | 95% (5% away) | 95% (5% away) | 90% (10% away) | 95% (5% away) |
| **Weekly Gain** | 15% | 10% | 20% | 7% | 10% |
| **Min Turnover** | ₹10cr | ₹5cr | ₹5cr | ₹2cr | ₹50cr |
| **ATR Range** | 3-10% | 2-15% | 2-15% | 1.5-20% | 2-15% |
| **Expected Signals** | Few | Moderate | Moderate | Many | Few |
| **Signal Quality** | Very High | High | High | Mixed | Very High |
| **Best For** | Capital preservation | Balanced approach | Explosive moves | Active trading | Large accounts |

---

## 📈 Performance Expectations

### Signal Frequency (500-stock universe)

| Market Condition | Conservative | Default | Aggressive |
|------------------|--------------|---------|------------|
| Strong Bull | 5-15 | 10-30 | 20-50 |
| Mild Bull | 2-8 | 5-15 | 10-30 |
| Sideways | 1-3 | 2-8 | 5-15 |
| Bear Market | 0-1 | 0-3 | 1-8 |

### Typical Win Rates (Estimated)

| Score Range | Win Rate* | Avg Gain | Avg Loss |
|-------------|-----------|----------|----------|
| 80-100 | 65-75% | +25% | -6% |
| 70-79 | 55-65% | +20% | -7% |
| 60-69 | 45-55% | +15% | -8% |
| <60 | 35-45% | +12% | -9% |

*With proper risk management and stop losses

---

## 🛠️ Advanced Customization

### Scenario: I want more signals in sideways markets

**Edit `momentum_breakout_scanner.py`:**
```python
class ScannerConfig:
    near_high_threshold: float = 0.90  # Expand to 10% from high
    weekly_gain_threshold: float = 0.07  # Lower to 7%
```

---

### Scenario: I only want blue-chip stocks

**Edit `momentum_breakout_scanner.py`:**
```python
class ScannerConfig:
    min_avg_turnover: float = 50e7  # Raise to ₹50 crore
```

**Or:** Use liquid preset
```bash
python run_momentum_breakout.py --preset liquid
```

---

### Scenario: I want to add a filter

**In `scan_stock_for_breakout()` function, add:**
```python
# Example: Require positive 3-month return
three_month_return = (current_close / df.iloc[-60]['close'] - 1) * 100
if three_month_return < 0:
    return None  # Skip stocks in downtrends
```

---

## 📞 Support & Contribution

### Questions?
- Check documentation files
- Review code comments
- Examine other scanners in `F4/scan/`

### Found a bug?
- Check if it's a configuration issue
- Review error messages
- Verify API credentials and data

### Want to enhance?
- Fork the scanner
- Add new filters
- Create custom presets
- Share improvements

---

## 📝 Version History

### v1.0 (November 3, 2025)
- Initial implementation
- Core Weinstein/Pryzby logic
- Composite scoring system
- Five presets (conservative, default, momentum, aggressive, liquid)
- Excel output with formatting
- Caching system
- Relative strength rating
- Volume confirmation
- MA alignment checks

---

## ⚖️ Disclaimer

This scanner is a **technical analysis tool** and does not provide financial advice.

**Important points:**
- Past performance ≠ future results
- All trading involves risk
- Use proper risk management
- This tool finds setups, not guarantees
- Always do your own research
- Consider your risk tolerance
- Consult a financial advisor if needed

**The scanner identifies opportunities. Success depends on:**
- Your risk management
- Entry/exit discipline
- Position sizing
- Market conditions
- Emotional control
- Trading experience

---

## 🎯 Final Checklist

Before trading signals from this scanner:

- [ ] I understand the methodology
- [ ] I've validated my setup (`test_momentum_setup.py`)
- [ ] I have API credentials configured
- [ ] I understand the scoring system
- [ ] I know how to size positions
- [ ] I have stop loss rules
- [ ] I understand market regime impact
- [ ] I've read the trading guidelines
- [ ] I have risk management plan
- [ ] I'm using appropriate preset for my style

---

## 📚 Quick Reference Card

### Commands
```bash
# Validate setup
python test_momentum_setup.py

# Run with default settings
python run_momentum_breakout.py --preset default

# Run with conservative filters
python run_momentum_breakout.py --preset conservative

# Run with aggressive filters
python run_momentum_breakout.py --preset aggressive

# Run for momentum focus
python run_momentum_breakout.py --preset momentum

# Run for liquid stocks
python run_momentum_breakout.py --preset liquid
```

### Score Interpretation
- **80-100**: Exceptional - top priority
- **70-79**: Very good - strong candidate
- **60-69**: Good - worth considering
- **50-59**: Marginal - careful
- **<50**: Weak - avoid

### Trading Guidelines
- **Entry**: On confirmation, not immediately
- **Stop**: 1.5-2× ATR or 6-8%
- **Position Size**: 1-2% account risk
- **Target**: 15-25% (short), 50-100% (swing)
- **Max Positions**: 3-5 at once

---

**Ready to start? → [QUICKSTART_MOMENTUM.md](QUICKSTART_MOMENTUM.md)**

**Need details? → [MOMENTUM_BREAKOUT_README.md](MOMENTUM_BREAKOUT_README.md)**

**Happy trading! 🚀📈**

