"""
Timeless Market Strategy - Contraction → Expansion in Uptrend
Implements the 4 enduring principles of market behavior:
1. Trend Continuation > Reversal
2. Momentum Precedes Price
3. Trends End in Climax
4. Range Expansion ↔ Contraction Cycle
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import logging
from dataclasses import dataclass

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@dataclass
class Signal:
    """Represents a trading signal"""
    symbol: str
    date: datetime
    entry_price: float
    stop_loss: float
    target: float
    risk_reward: float
    quality_score: float
    signals: Dict
    notes: str


class TimelessMarketStrategy:
    """
    Systematic trading system based on 4 enduring market principles.
    Detects: Contraction → Expansion in Uptrend setups
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize strategy with configuration.
        
        Config parameters:
        - ema_short: Short EMA period (default: 21)
        - ema_long: Long EMA period (default: 55)
        - roc_period: Rate of Change period (default: 10)
        - bb_period: Bollinger Band period (default: 20)
        - bb_std: Bollinger Band standard deviations (default: 2.0)
        - bb_width_lookback: Lookback for BB width percentile (default: 100)
        - bb_width_percentile: Maximum BB width percentile for contraction (default: 20)
        - atr_period: ATR period (default: 14)
        - atr_percentile_lookback: Lookback for ATR percentile (default: 100)
        - atr_percentile_max: Maximum ATR percentile for contraction (default: 25)
        - volume_multiplier: Volume expansion multiplier (default: 1.5)
        - volume_lookback: Volume average lookback (default: 10)
        - stop_atr_multiplier: Stop loss ATR multiplier (default: 1.5)
        - use_ema_trailing: Whether to use EMA trailing stop (default: True)
        """
        self.config = config or {}
        
        # EMA settings
        self.ema_short = self.config.get('ema_short', 21)
        self.ema_long = self.config.get('ema_long', 55)
        
        # Momentum settings
        self.roc_period = self.config.get('roc_period', 10)
        self.rsi_period = self.config.get('rsi_period', 14)
        
        # Bollinger Bands settings
        self.bb_period = self.config.get('bb_period', 20)
        self.bb_std = self.config.get('bb_std', 2.0)
        self.bb_width_lookback = self.config.get('bb_width_lookback', 100)
        self.bb_width_percentile = self.config.get('bb_width_percentile', 20)
        
        # ATR settings
        self.atr_period = self.config.get('atr_period', 14)
        self.atr_percentile_lookback = self.config.get('atr_percentile_lookback', 100)
        self.atr_percentile_max = self.config.get('atr_percentile_max', 25)
        
        # Volume settings
        self.volume_multiplier = self.config.get('volume_multiplier', 1.5)
        self.volume_lookback = self.config.get('volume_lookback', 10)
        
        # Stop loss settings
        self.stop_atr_multiplier = self.config.get('stop_atr_multiplier', 1.8)
        self.use_ema_trailing = self.config.get('use_ema_trailing', True)
        
        # Breakout settings
        self.breakout_lookback = self.config.get('breakout_lookback', 10)
        
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate all required technical indicators.
        
        Principle 1: Trend (EMA alignment)
        Principle 2: Momentum (ROC, RSI, Volume)
        Principle 3: Climax detection (Volume spikes, volatility)
        Principle 4: Contraction/Expansion (BB width, ATR)
        """
        if df.empty or len(df) < max(self.bb_width_lookback, self.atr_percentile_lookback, self.ema_long):
            logger.debug(f"Insufficient data: {len(df)} rows")
            return df
        
        df = df.copy()
        
        # Ensure required columns exist
        required_cols = ['open', 'high', 'low', 'close', 'volume']
        if not all(col in df.columns for col in required_cols):
            logger.error(f"Missing required columns. Available: {df.columns.tolist()}")
            return df
        
        # Convert to numeric
        for col in required_cols:
            df[col] = pd.to_numeric(df[col], errors='coerce')
        
        df.dropna(subset=required_cols, inplace=True)
        
        if df.empty:
            return df
        
        # ============================================
        # PRINCIPLE 1: TREND CONTINUATION
        # ============================================
        
        # Exponential Moving Averages
        df[f'ema_{self.ema_short}'] = df['close'].ewm(span=self.ema_short, adjust=False).mean()
        df[f'ema_{self.ema_long}'] = df['close'].ewm(span=self.ema_long, adjust=False).mean()
        
        # Trend structure (Higher Highs / Higher Lows)
        df['hh'] = (df['high'] > df['high'].shift(1)) & (df['high'].shift(1) > df['high'].shift(2))
        df['hl'] = (df['low'] > df['low'].shift(1)) & (df['low'].shift(1) > df['low'].shift(2))
        df['trend_structure'] = np.where(df['hh'] | df['hl'], 1, 0)
        
        # Trend alignment
        df['trend_aligned'] = (df[f'ema_{self.ema_short}'] > df[f'ema_{self.ema_long}']) & \
                              (df['close'] > df[f'ema_{self.ema_short}'])
        
        # ============================================
        # PRINCIPLE 2: MOMENTUM PRECEDES PRICE
        # ============================================
        
        # Rate of Change (ROC)
        df['roc'] = ((df['close'] - df['close'].shift(self.roc_period)) / 
                     df['close'].shift(self.roc_period)) * 100
        
        # RSI Calculation
        delta = df['close'].diff()
        gain = delta.where(delta > 0, 0)
        loss = -delta.where(delta < 0, 0)
        
        avg_gain = gain.rolling(window=self.rsi_period, min_periods=1).mean()
        avg_loss = loss.rolling(window=self.rsi_period, min_periods=1).mean()
        
        rs = avg_gain / (avg_loss + 1e-10)  # Avoid division by zero
        df['rsi'] = 100 - (100 / (1 + rs))
        df['rsi_slope'] = df['rsi'].diff(3)  # 3-period slope
        
        # Volume analysis
        df['volume_sma'] = df['volume'].rolling(window=self.volume_lookback, min_periods=1).mean()
        df['volume_ratio'] = df['volume'] / (df['volume_sma'] + 1e-10)
        df['volume_surge'] = df['volume_ratio'] > self.volume_multiplier
        
        # Recent momentum (last few days)
        df['momentum_positive'] = (df['roc'] > 0) & (df['rsi_slope'] > 0)
        
        # ============================================
        # PRINCIPLE 3: CLIMAX DETECTION (for exits)
        # ============================================
        
        # ATR calculation
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift(1))
        low_close = np.abs(df['low'] - df['close'].shift(1))
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        df['atr'] = true_range.rolling(window=self.atr_period, min_periods=1).mean()
        
        # Volatility spike (climax)
        df['atr_ma'] = df['atr'].rolling(window=20, min_periods=1).mean()
        df['volatility_spike'] = df['atr'] > df['atr_ma'] * 1.5
        
        # Volume climax
        df['volume_climax'] = df['volume'] > df['volume_sma'] * 2.5
        
        # Parabolic extension (price too far from mean)
        df['price_to_ema_ratio'] = (df['close'] - df[f'ema_{self.ema_short}']) / df[f'ema_{self.ema_short}']
        df['parabolic_extension'] = df['price_to_ema_ratio'] > 0.15  # 15% above EMA
        
        # Divergence (momentum vs price - simplified)
        df['price_change'] = df['close'].pct_change(5)
        df['momentum_change'] = df['rsi'].diff(5)
        df['divergence'] = (df['price_change'] > 0) & (df['momentum_change'] < 0)
        
        # ============================================
        # PRINCIPLE 4: RANGE CONTRACTION/EXPANSION
        # ============================================
        
        # Bollinger Bands
        df['bb_middle'] = df['close'].rolling(window=self.bb_period, min_periods=1).mean()
        df['bb_std'] = df['close'].rolling(window=self.bb_period, min_periods=1).std()
        df['bb_upper'] = df['bb_middle'] + (df['bb_std'] * self.bb_std)
        df['bb_lower'] = df['bb_middle'] - (df['bb_std'] * self.bb_std)
        df['bb_width'] = (df['bb_upper'] - df['bb_lower']) / df['bb_middle']
        
        # BB Width percentile (contraction detection)
        df['bb_width_pct'] = df['bb_width'].rolling(
            window=self.bb_width_lookback, min_periods=10
        ).apply(lambda x: (x.iloc[-1] / x.max() * 100) if x.max() > 0 else 100, raw=False)
        
        # Simplified: Use rolling percentile
        if len(df) >= self.bb_width_lookback:
            df['bb_width_percentile'] = df['bb_width'].rolling(
                window=self.bb_width_lookback, min_periods=10
            ).rank(pct=True) * 100
        
        # ATR Percentile (alternative contraction measure)
        if len(df) >= self.atr_percentile_lookback:
            df['atr_percentile'] = df['atr'].rolling(
                window=self.atr_percentile_lookback, min_periods=10
            ).rank(pct=True) * 100
        else:
            df['atr_percentile'] = 50  # Default if insufficient data
        
        # Contraction signal
        df['contraction'] = (
            (df['bb_width_percentile'] < self.bb_width_percentile) |
            (df['atr_percentile'] < self.atr_percentile_max)
        )
        
        # Expansion signal (breakout from contraction)
        df['expansion_breakout'] = (
            df['contraction'].shift(1) &  # Was in contraction
            (df['close'] > df['close'].rolling(window=self.breakout_lookback).max().shift(1)) &  # Breaks high
            df['volume_surge']  # With volume
        )
        
        # Follow-through confirmation (prevents entering at the high)
        # Requires: breakout yesterday + higher close today + higher volume today
        df['follow_through'] = (
            df['expansion_breakout'].shift(1) &  # Breakout happened yesterday
            (df['close'] > df['close'].shift(1)) &  # Close higher today
            (df['volume'] > df['volume'].shift(1))  # Volume higher today
        )
        
        return df
    
    def calculate_dynamic_stop(self, entry_price: float, atr_value: float, ema_value: float, df: pd.DataFrame) -> float:
        """
        Calculate dynamic stop loss based on volatility regime.
        
        Uses ATR z-score to determine volatility regime and applies appropriate
        stop multiplier. Combines ATR-based and EMA-based stops for better protection.
        """
        # Get recent volatility profile (last 60 days)
        if len(df) < 60:
            recent_atr = df['atr']
        else:
            recent_atr = df['atr'].tail(60)
        
        atr_mean = recent_atr.mean()
        atr_std = recent_atr.std()
        
        # Classify volatility regime using z-score
        if atr_std > 0:
            current_atr_zscore = (atr_value - atr_mean) / atr_std
        else:
            current_atr_zscore = 0
        
        if current_atr_zscore > 1.5:  # High volatility
            stop_multiplier = 2.5  # Wider stops
        elif current_atr_zscore > 0.5:  # Above average volatility
            stop_multiplier = 2.0
        else:  # Normal/low volatility
            stop_multiplier = 1.5
        
        # Calculate ATR-based stop
        atr_stop = entry_price - (atr_value * stop_multiplier)
        
        # Calculate EMA-based stop (support level)
        ema_stop = ema_value * 0.97  # 3% below EMA for breathing room
        
        # Use the WIDER stop (gives trades more room to breathe)
        # This prevents premature exits on normal volatility
        calculated_stop = min(atr_stop, ema_stop)
        
        # Apply percentage caps based on price level
        if entry_price < 100:  # Low-priced stocks
            max_stop_pct = 0.12  # Allow 12% max
            min_stop_pct = 0.05  # Minimum 5%
        elif entry_price < 500:  # Mid-priced
            max_stop_pct = 0.10  # Allow 10% max
            min_stop_pct = 0.04  # Minimum 4%
        else:  # High-priced
            max_stop_pct = 0.08  # Allow 8% max
            min_stop_pct = 0.03  # Minimum 3%
        
        max_stop_price = entry_price * (1 - max_stop_pct)
        min_stop_price = entry_price * (1 - min_stop_pct)
        
        # Ensure stop is within reasonable range
        final_stop = max(max_stop_price, min(calculated_stop, min_stop_price))
        
        # Final safety: ensure stop is always below entry
        final_stop = min(final_stop, entry_price * 0.97)
        
        return final_stop
    
    def _check_resistance_clear(self, df: pd.DataFrame, current_price: float, lookback: int = 100) -> bool:
        """
        Check if there's significant overhead resistance/supply.
        
        This prevents entries that will hit prior resistance levels where sellers
        accumulated, which often leads to reversals and stop-loss hits.
        
        Returns:
            True if resistance is clear (safe to enter)
            False if significant resistance detected (skip entry)
        """
        if len(df) < 20:
            return True  # Insufficient data, don't filter
        
        # Look back to find swing highs (resistance levels)
        lookback_period = min(lookback, len(df))
        recent_data = df.tail(lookback_period)
        
        # Find swing highs: peaks that are higher than surrounding bars
        # Use rolling max to identify local peaks
        highs = recent_data['high'].copy()
        
        # Identify swing highs: bars where high is the max in a 5-bar window
        swing_highs = []
        for i in range(5, len(highs) - 5):
            if highs.iloc[i] == highs.iloc[i-5:i+6].max():
                swing_highs.append(highs.iloc[i])
        
        if not swing_highs:
            return True  # No swing highs found
        
        # Check if current price is approaching any resistance
        for resistance in swing_highs:
            # Calculate distance to resistance
            distance_pct = (resistance - current_price) / current_price * 100
            
            # If resistance is within 1-5% above current price, it's a concern
            if 1.0 <= distance_pct <= 5.0:
                # Strong resistance nearby - skip entry
                return False
            
            # If we're right at resistance (within 1%), also skip
            if abs(distance_pct) < 1.0:
                return False
        
        # Also check if current price just broke above a recent resistance
        # In that case, ensure it's a clean break (at least 2% above)
        max_recent_high = recent_data['high'].tail(60).max()
        if current_price > max_recent_high * 0.98 and current_price < max_recent_high * 1.02:
            # Too close to recent high - might face resistance
            return False
        
        return True  # No significant resistance detected
    
    def detect_signals(self, df: pd.DataFrame, symbol: str = "UNKNOWN", market_data: pd.DataFrame = None) -> List[Signal]:
        """
        Simplified 5-Filter Entry System
        
        The 5 Filters:
        1. Uptrend → Price above 20 EMA above 50 EMA
        2. Momentum → Price within 5% of recent 20-day high
        3. Contraction → Current ATR below its 30-day average (compressed volatility)
        4. Clear Overhead → No major resistance in last 60 days (price at/near highs)
        5. Expansion Trigger → Price breaks 5-day high + Volume 20% above average
        
        Entry: When ALL 5 conditions are TRUE
        """
        if df.empty:
            return []
        
        # Only calculate indicators if they don't exist (allows pre-calculated indicators)
        if f'ema_{self.ema_short}' not in df.columns:
            df = self.calculate_indicators(df)
        
        # Verify indicators were calculated successfully
        if df.empty or len(df) < 60 or f'ema_{self.ema_short}' not in df.columns:
            if len(df) > 0:
                logger.debug(f"{symbol}: Insufficient data or missing indicators ({len(df)} rows)")
            return []
        
        signals = []
        
        # Get the latest row (most recent data)
        latest = df.iloc[-1]
        
        # ============================================
        # THE 5 FILTERS + MARKET REGIME
        # ============================================
        
        # FILTER 0: Market Regime (CRITICAL - prevents bear market losses)
        # Check if overall market (Nifty 500) is bullish
        if market_data is not None and not market_data.empty:
            # Get market data up to current date (use .copy() to avoid SettingWithCopyWarning)
            market_filtered = market_data[market_data.index <= df.index[-1]].copy()
            
            if len(market_filtered) >= 55:
                # Calculate EMAs for market index
                market_filtered['ema21'] = market_filtered['close'].ewm(span=21, adjust=False).mean()
                market_filtered['ema55'] = market_filtered['close'].ewm(span=55, adjust=False).mean()
                
                market_latest = market_filtered.iloc[-1]
                
                # Market must be in uptrend: Price > EMA21 > EMA55
                # Simple alignment check - no slope check (was filtering good trades)
                market_regime_ok = (
                    market_latest['close'] > market_latest['ema21'] and
                    market_latest['ema21'] > market_latest['ema55']
                )
                
                if not market_regime_ok:
                    return signals  # Skip trading when market is bearish
        
        # FILTER 1: Uptrend (Price > EMA21 > EMA55)
        uptrend = (
            latest['close'] > latest[f'ema_{self.ema_short}'] and
            latest[f'ema_{self.ema_short}'] > latest[f'ema_{self.ema_long}']
        )
        
        if not uptrend:
            return signals
        
        # FILTER 2: Momentum (Price within 10% of recent 20-day high)
        high_20 = df['high'].tail(20).max()
        distance_from_high = (high_20 - latest['close']) / latest['close'] * 100
        momentum_strong = distance_from_high <= 10.0  # Within 10% of highs (relaxed)
        
        if not momentum_strong:
            return signals
        
        # FILTER 3: Contraction (Current ATR < 30-day ATR average)
        # This ensures we're entering during relatively low volatility
        atr_30_avg = df['atr'].tail(30).mean()
        contraction = latest['atr'] < atr_30_avg * 1.1  # Allow 10% above average (relaxed)
        
        if not contraction:
            return signals
        
        # FILTER 4: Clear Overhead (No major resistance in last 60 days)
        # Price should be reasonably close to highs - allows more opportunities
        high_60 = df['high'].tail(60).max()
        distance_from_high_60 = (high_60 - latest['close']) / latest['close'] * 100
        clear_overhead = distance_from_high_60 <= 20.0  # Within 20% of 60-day highs (relaxed further)
        
        if not clear_overhead:
            return signals
        
        # FILTER 5: Expansion Trigger (5-day breakout + Volume surge)
        # Get the high of the previous 5 days (excluding today)
        if len(df) >= 6:
            high_5_prev = df['high'].iloc[-6:-1].max()  # Last 5 days, excluding today
        else:
            high_5_prev = df['high'].iloc[:-1].max()
        
        breakout = latest['close'] > high_5_prev
        
        # Volume 20% above average
        volume_20_avg = df['volume'].tail(20).mean()
        volume_surge = latest['volume'] > volume_20_avg * 1.2
        
        expansion_trigger = breakout and volume_surge
        
        if not expansion_trigger:
            return signals
        
        # ============================================
        # ALL 5 FILTERS PASSED - GENERATE SIGNAL
        # ============================================
        if uptrend and momentum_strong and contraction and clear_overhead and expansion_trigger:
            # Calculate entry and stop
            entry_price = latest['close']
            atr_value = latest['atr']
            
            # ASYMMETRIC RISK/REWARD: Tight stops + Wide targets
            
            # STOP: 1.5× ATR below entry (tighter protection)
            stop_distance = atr_value * 1.5
            stop_loss = entry_price - stop_distance
            
            # Calculate stop percentage
            stop_pct = (stop_distance / entry_price) * 100
            
            # Cap at 5% max (tighter than previous 8%)
            # This ensures: Risk ≤ 5% per trade
            if stop_pct > 5.0:
                stop_pct = 5.0
                stop_loss = entry_price * 0.95
            elif stop_pct < 3.0:
                # Minimum 3% stop (not too tight)
                stop_pct = 3.0
                stop_loss = entry_price * 0.97
            
            # TARGET: 3× ATR from entry (wider - let winners run)
            # This ensures: Reward ≥ 9-12% typically
            target = entry_price + (atr_value * 3)
            
            # Risk/Reward ratio should be at least 1:2 (5% risk, 10%+ reward)
            risk_amount = entry_price - stop_loss
            reward_amount = target - entry_price
            
            # Calculate quality score for tracking
            quality_score = self._calculate_quality_score(latest, df)
            
            # Signal metadata
            signal_dict = {
                'uptrend': uptrend,
                'momentum_strong': momentum_strong,
                'contraction': contraction,
                'clear_overhead': clear_overhead,
                'expansion_trigger': expansion_trigger,
                'distance_from_high_20': distance_from_high,
                'distance_from_high_60': distance_from_high_60,
                'atr_vs_avg': (latest['atr'] / atr_30_avg) * 100 if atr_30_avg > 0 else 100
            }
            
            notes = f"5-Day BO + Vol Surge | 20D-High: {distance_from_high:.1f}% | ATR/Avg: {signal_dict['atr_vs_avg']:.0f}%"
            
            signal = Signal(
                symbol=symbol,
                date=df.index[-1] if isinstance(df.index, pd.DatetimeIndex) else datetime.now(),
                entry_price=entry_price,
                stop_loss=stop_loss,
                target=target,
                risk_reward=(target - entry_price) / (entry_price - stop_loss) if (entry_price - stop_loss) > 0 else 0,
                quality_score=quality_score,
                signals=signal_dict,
                notes=notes
            )
            
            signals.append(signal)
        
        return signals
    
    def _calculate_quality_score(self, row: pd.Series, df: pd.DataFrame) -> float:
        """
        Enhanced quality score (0-100) with market regime awareness.
        Higher is better.
        """
        score = 0.0
        
        # === TREND STRENGTH (0-25 points) ===
        if row['trend_aligned']:
            score += 10
        
        # Trend strength - how far above EMA50
        ema_separation = (row[f'ema_{self.ema_short}'] - row[f'ema_{self.ema_long}']) / row[f'ema_{self.ema_long}']
        if ema_separation > 0.05:  # 5% separation
            score += 10
        elif ema_separation > 0.02:  # 2% separation
            score += 5
        
        # Recent trend consistency (last 5 days all up)
        if len(df) >= 5:
            recent_closes = df['close'].tail(5)
            all_up = all(recent_closes.iloc[i] > recent_closes.iloc[i-1] for i in range(1, 5))
            if all_up:
                score += 5
        
        # === MOMENTUM STRENGTH (0-25 points) ===
        # ROC scoring
        roc_score = min(row['roc'], 15) / 15 * 10  # Cap at 15% ROC = 10 points
        score += roc_score
        
        # RSI sweet spot (bullish but not overbought)
        if 55 < row['rsi'] < 70:
            score += 10  # Ideal zone
        elif 50 < row['rsi'] < 75:
            score += 5  # Good zone
        elif row['rsi'] > 75:
            score -= 5  # Overbought - penalty
        
        # RSI slope (momentum improving)
        if row['rsi_slope'] > 2:  # Strongly improving
            score += 5
        elif row['rsi_slope'] > 0:
            score += 2
        
        # === VOLUME STRENGTH (0-20 points) ===
        vol_ratio = row['volume_ratio']
        if vol_ratio > 2.5:
            score += 20  # Exceptional volume
        elif vol_ratio > 2.0:
            score += 15
        elif vol_ratio > 1.5:
            score += 10
        elif vol_ratio > 1.2:
            score += 5
        else:
            score -= 5  # Below average volume - penalty
        
        # === CONTRACTION QUALITY (0-20 points) ===
        bb_pct = row.get('bb_width_percentile', 50)
        atr_pct = row.get('atr_percentile', 50)
        
        # Tighter contraction = better setup
        if bb_pct < 15:
            score += 12
        elif bb_pct < 25:
            score += 8
        elif bb_pct < 35:
            score += 4
        
        if atr_pct < 20:
            score += 8
        elif atr_pct < 30:
            score += 4
        
        # === RISK/REWARD CONTEXT (0-10 points) ===
        # Price position in BB (breakout above middle preferred)
        if 'bb_middle' in row and 'bb_upper' in row:
            bb_range = row['bb_upper'] - row['bb_middle']
            if bb_range > 0:  # Avoid division by zero
                bb_position = (row['close'] - row['bb_middle']) / bb_range
                if 0.3 < bb_position < 0.7:  # Mid-range breakout (best)
                    score += 10
                elif bb_position > 0.7:  # Near upper band (risky)
                    score += 3
        
        # === PENALTIES ===
        # Penalize if high ATR percentile during entry (entering volatile period)
        if atr_pct > 75:
            score -= 10  # Entering during high volatility = risky
        
        # === MARKET REGIME BONUS ===
        # Check if broader market is supportive (using EMA50 slope as proxy)
        if len(df) >= 10:
            ema_slope = (row[f'ema_{self.ema_long}'] - df[f'ema_{self.ema_long}'].iloc[-10]) / df[f'ema_{self.ema_long}'].iloc[-10] * 100
            if ema_slope > 2:  # Strong uptrend
                score += 5
            elif ema_slope < -2:  # Downtrend
                score -= 10  # Big penalty
        
        # Cap at 100 and floor at 0
        return max(0, min(score, 100.0))
    
    def check_exit(self, df: pd.DataFrame, entry_price: float, entry_date: datetime) -> Tuple[bool, str]:
        """
        Check if exit conditions are met (Principle 3: Climax).
        Returns: (should_exit, reason)
        """
        if df.empty or len(df) < 2:
            return False, "Insufficient data"
        
        # Only calculate indicators if they don't exist (allows pre-calculated indicators)
        if f'ema_{self.ema_short}' not in df.columns:
            df = self.calculate_indicators(df)
        
        latest = df.iloc[-1]
        
        # Climax conditions
        exit_reasons = []
        
        # 1. Volume climax - ONLY exit if profitable AND extreme volume
        # Climax = exhaustion at TOP of move, not panic selling at bottom
        if latest['volume_climax']:
            # Check if we're in profit
            pct_gain = (latest['close'] - entry_price) / entry_price * 100
            
            # Calculate if volume is VERY extreme (>3x average)
            if len(df) >= 20:
                volume_avg_20 = df['volume'].tail(20).mean()
                volume_extreme = latest['volume'] > volume_avg_20 * 3.0
            else:
                volume_extreme = False
            
            # BOTH conditions must be TRUE (AND, not OR):
            # 1. Up at least 3% (profitable) AND
            # 2. Volume is extreme (>3x average)
            if pct_gain >= 3.0 and volume_extreme:
                exit_reasons.append("Volume climax")
        
        # 2. Volatility spike + Volume climax (strong signal) - also require profit
        if latest['volatility_spike'] and latest['volume_climax']:
            pct_gain = (latest['close'] - entry_price) / entry_price * 100
            if pct_gain >= 3.0:  # Only exit if profitable
                exit_reasons.append("Volatility spike")
        
        # 3. Parabolic extension (high win rate - good exit) - require profit
        if latest['parabolic_extension']:
            pct_gain = (latest['close'] - entry_price) / entry_price * 100
            if pct_gain >= 2.0:  # Only exit if at least +2% (parabolic means overextended upward)
                exit_reasons.append("Parabolic extension")
        
        # 4. Divergence - Make it stricter (only strong divergence)
        if latest['divergence'] and latest['rsi'] > 75:  # Only if RSI is very high
            # Check if price is actually falling
            price_change_5d = (latest['close'] - df['close'].iloc[-6]) / df['close'].iloc[-6] * 100 if len(df) >= 6 else 0
            if price_change_5d < 0:  # Price actually falling
                exit_reasons.append("Momentum divergence")
        
        # 5. EMA trailing stop - DISABLED (was causing 4.5% win rate)
        # Price can fluctuate around EMA without trend ending
        # Let other exit conditions (volume climax, parabolic) handle exits
        # Uncomment below to re-enable with stricter conditions:
        # price_below_ema = latest['close'] < latest[f'ema_{self.ema_short}']
        # ema_drop_pct = (latest[f'ema_{self.ema_short}'] - latest['close']) / latest[f'ema_{self.ema_short}'] * 100
        # # Only exit if price is significantly below EMA AND in profit
        # if price_below_ema and ema_drop_pct > 3.0 and latest['close'] > entry_price * 1.02:
        #     exit_reasons.append("EMA trailing stop")
        
        if exit_reasons:
            return True, " | ".join(exit_reasons)
        
        return False, "Hold"


if __name__ == "__main__":
    # Example usage
    strategy = TimelessMarketStrategy()
    
    # Create sample data
    dates = pd.date_range(start='2023-01-01', periods=200, freq='D')
    np.random.seed(42)
    
    # Simulate uptrend with contraction and expansion
    prices = 100 + np.cumsum(np.random.randn(200) * 0.5 + 0.1)
    volumes = 1000000 + np.random.randn(200) * 100000
    
    sample_df = pd.DataFrame({
        'open': prices * (1 + np.random.randn(200) * 0.001),
        'high': prices * (1 + abs(np.random.randn(200)) * 0.005),
        'low': prices * (1 - abs(np.random.randn(200)) * 0.005),
        'close': prices,
        'volume': volumes
    }, index=dates)
    
    # Detect signals
    signals = strategy.detect_signals(sample_df, symbol="TEST")
    
    if signals:
        for signal in signals:
            print(f"\nSignal detected for {signal.symbol}:")
            print(f"  Date: {signal.date}")
            print(f"  Entry: {signal.entry_price:.2f}")
            print(f"  Stop: {signal.stop_loss:.2f}")
            print(f"  Target: {signal.target:.2f}")
            print(f"  R:R: {signal.risk_reward:.2f}")
            print(f"  Quality: {signal.quality_score:.1f}")
            print(f"  Notes: {signal.notes}")
    else:
        print("No signals detected in sample data.")

