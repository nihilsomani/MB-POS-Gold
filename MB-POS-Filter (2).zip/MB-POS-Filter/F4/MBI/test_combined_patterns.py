"""
Test Combined Crash Patterns
=============================
Tests combinations of warning signals to find highest reliability.
"""

import pandas as pd
import numpy as np

print("\n" + "="*80)
print("COMBINED PATTERN TESTING")
print("="*80 + "\n")

# Load data
df = pd.read_excel("../../../MBI_EM_Backtest_Results/backtest_results.xlsx")
df['date'] = pd.to_datetime(df['date'])

print(f"Testing on {len(df)} days of data\n")

# Test different combinations
patterns = []

# Pattern 1: EM > 60% AND declining
em_60_declining = df[(df['EM'] > 60) & (df['em_trend'] == 'declining')].copy()
crashes_1 = 0
for idx in em_60_declining.index:
    date = df.loc[idx, 'date']
    future = df[(df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=5))]
    if len(future) > 0 and (future['EM_chng_3d'] <= -10).any():
        crashes_1 += 1

reliability_1 = (crashes_1 / len(em_60_declining) * 100) if len(em_60_declining) > 0 else 0
patterns.append(('EM >60% + declining', len(em_60_declining), crashes_1, reliability_1))

# Pattern 2: EM > 60% AND declining AND Broad Rally
em_60_decl_broad = df[(df['EM'] > 60) & (df['em_trend'] == 'declining') & (df['market_type'] == 'Broad Rally')].copy()
crashes_2 = 0
for idx in em_60_decl_broad.index:
    date = df.loc[idx, 'date']
    future = df[(df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=5))]
    if len(future) > 0 and (future['EM_chng_3d'] <= -10).any():
        crashes_2 += 1

reliability_2 = (crashes_2 / len(em_60_decl_broad) * 100) if len(em_60_decl_broad) > 0 else 0
patterns.append(('EM >60% + declining + Broad Rally', len(em_60_decl_broad), crashes_2, reliability_2))

# Pattern 3: EM > 70%
em_70 = df[df['EM'] > 70].copy()
crashes_3 = 0
for idx in em_70.index:
    date = df.loc[idx, 'date']
    future = df[(df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=5))]
    if len(future) > 0 and (future['EM_chng_3d'] <= -10).any():
        crashes_3 += 1

reliability_3 = (crashes_3 / len(em_70) * 100) if len(em_70) > 0 else 0
patterns.append(('EM >70% (higher threshold)', len(em_70), crashes_3, reliability_3))

# Pattern 4: EM > 70% AND declining
em_70_declining = df[(df['EM'] > 70) & (df['em_trend'] == 'declining')].copy()
crashes_4 = 0
for idx in em_70_declining.index:
    date = df.loc[idx, 'date']
    future = df[(df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=5))]
    if len(future) > 0 and (future['EM_chng_3d'] <= -10).any():
        crashes_4 += 1

reliability_4 = (crashes_4 / len(em_70_declining) * 100) if len(em_70_declining) > 0 else 0
patterns.append(('EM >70% + declining', len(em_70_declining), crashes_4, reliability_4))

# Pattern 5: EM > 65% AND EM_chng_3d < -3
em_65_drop = df[(df['EM'] > 65) & (df['EM_chng_3d'] < -3)].copy()
crashes_5 = 0
for idx in em_65_drop.index:
    date = df.loc[idx, 'date']
    future = df[(df['date'] > date) & (df['date'] <= date + pd.Timedelta(days=5))]
    if len(future) > 0 and (future['EM_chng_3d'] <= -10).any():
        crashes_5 += 1

reliability_5 = (crashes_5 / len(em_65_drop) * 100) if len(em_65_drop) > 0 else 0
patterns.append(('EM >65% + EM_chng_3d < -3', len(em_65_drop), crashes_5, reliability_5))

# Print results
print("Pattern Testing Results:")
print("-" * 80)
print(f"{'Pattern':<40} {'Events':>8} {'Crashes':>8} {'Reliability':>12}")
print("-" * 80)

for pattern, events, crashes, reliability in sorted(patterns, key=lambda x: x[3], reverse=True):
    status = "[IMPLEMENT!]" if reliability >= 60 else "[SKIP]" if reliability < 40 else "[MAYBE]"
    print(f"{pattern:<40} {events:>8} {crashes:>8} {reliability:>11.1f}% {status}")

print("\n" + "="*80)
print("RECOMMENDATION")
print("="*80 + "\n")

best_pattern = max(patterns, key=lambda x: x[3])
print(f"Best Pattern: {best_pattern[0]}")
print(f"Reliability: {best_pattern[3]:.1f}%")
print(f"Events: {best_pattern[1]}")
print(f"Crashes detected: {best_pattern[2]}")
print()

if best_pattern[3] >= 60:
    print("[IMPLEMENT] This pattern is reliable enough for production")
elif best_pattern[3] >= 50:
    print("[CONSIDER] Moderate reliability - use with caution")
else:
    print("[SKIP] No pattern reliable enough - keep current crash detection")

print()

