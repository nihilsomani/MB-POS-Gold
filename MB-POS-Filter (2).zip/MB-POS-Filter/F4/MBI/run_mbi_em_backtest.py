"""
Quick Runner for MBI EM Backtester
===================================
Simplified interface to run backtests with specific date ranges.

Usage Examples:
    # Full backtest (2022-2025)
    python run_mbi_em_backtest.py
    
    # Specific date range
    python run_mbi_em_backtest.py --start 2024-01-01 --end 2024-12-31
    
    # October 2025 only (fast test)
    python run_mbi_em_backtest.py --start 2025-10-01 --end 2025-10-31
    
    # Last 6 months
    python run_mbi_em_backtest.py --months 6
"""

import argparse
from datetime import datetime, timedelta
import logging
from MBIEMBacktester import MBIEMBacktester

# =============================================================================
# CONFIGURATION
# =============================================================================

# Import from config.py (UPDATE CREDENTIALS THERE!)
try:
    from config import (API_KEY, ACCESS_TOKEN, UNIVERSE_CSV,
                       DEFAULT_BACKTEST_START, DEFAULT_BACKTEST_END)
    DEFAULT_START = DEFAULT_BACKTEST_START
    DEFAULT_END = DEFAULT_BACKTEST_END
except ImportError:
    # Fallback to defaults
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "7uCdOd1Je1xRzfajiTYrlts6bgH4CV46"
    UNIVERSE_CSV = "data/nifty500.csv"
    DEFAULT_START = "2023-01-01"
    DEFAULT_END = "2025-11-03"
    print("⚠️ config.py not found. Using default credentials and dates.")

# =============================================================================
# PREDEFINED SCENARIOS
# =============================================================================

QUICK_TESTS = {
    'october': {
        'start': '2025-10-01',
        'end': '2025-10-31',
        'description': 'October 2025 - Euphoria analysis'
    },
    'last_month': {
        'start': (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d'),
        'end': datetime.now().strftime('%Y-%m-%d'),
        'description': 'Last 30 days'
    },
    'last_quarter': {
        'start': (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d'),
        'end': datetime.now().strftime('%Y-%m-%d'),
        'description': 'Last quarter (90 days)'
    },
    'ytd': {
        'start': '2025-01-01',
        'end': datetime.now().strftime('%Y-%m-%d'),
        'description': 'Year to date 2025'
    },
    '2024': {
        'start': '2024-01-01',
        'end': '2024-12-31',
        'description': 'Full year 2024'
    },
    'full': {
        'start': '2022-01-01',
        'end': '2025-11-03',
        'description': 'Full backtest (2022-2025)'
    }
}

# =============================================================================
# MAIN
# =============================================================================

def main():
    """Run MBI EM backtester"""
    parser = argparse.ArgumentParser(
        description='MBI EM System Backtester',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run_mbi_em_backtest.py --quick october
  python run_mbi_em_backtest.py --start 2024-01-01 --end 2024-12-31
  python run_mbi_em_backtest.py --months 6
        """
    )
    
    parser.add_argument('--start', type=str, help='Start date (YYYY-MM-DD)')
    parser.add_argument('--end', type=str, help='End date (YYYY-MM-DD)')
    parser.add_argument('--months', type=int, help='Backtest last N months from today')
    parser.add_argument('--quick', type=str, choices=list(QUICK_TESTS.keys()),
                       help='Run predefined quick test')
    parser.add_argument('--universe', type=str, default=UNIVERSE_CSV,
                       help='Path to universe CSV')
    
    args = parser.parse_args()
    
    # Determine date range
    if args.quick:
        quick_test = QUICK_TESTS[args.quick]
        start_date_str = quick_test['start']
        end_date_str = quick_test['end']
        print(f"\n[TEST] Running Quick Test: {args.quick}")
        print(f"   {quick_test['description']}")
    elif args.months:
        end_date_str = datetime.now().strftime('%Y-%m-%d')
        start_date_str = (datetime.now() - timedelta(days=args.months*30)).strftime('%Y-%m-%d')
        print(f"\n[TEST] Running Backtest: Last {args.months} months")
    elif args.start and args.end:
        start_date_str = args.start
        end_date_str = args.end
        print(f"\n[TEST] Running Backtest: Custom range")
    else:
        start_date_str = DEFAULT_START
        end_date_str = DEFAULT_END
        print(f"\n[TEST] Running Backtest: Default period")
    
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
    end_date = datetime.strptime(end_date_str, '%Y-%m-%d')
    
    print(f"   Period: {start_date_str} to {end_date_str}")
    print(f"   Universe: {args.universe}")
    print()
    
    # Initialize backtester
    print("="*80)
    print("MBI EM SYSTEM BACKTESTER")
    print("="*80)
    print()
    
    backtester = MBIEMBacktester(
        api_key=API_KEY,
        access_token=ACCESS_TOKEN,
        universe_csv=args.universe
    )
    
    # Run backtest
    try:
        results = backtester.run_backtest(start_date, end_date)
        
        # Export to Excel
        print("\n[EXCEL] Generating Excel export...")
        excel_file = backtester.export_to_excel(results)
        if excel_file:
            print(f"   Excel saved: {excel_file}")
        else:
            print("   Warning: Excel export failed (see logs)")

        
        # Display key results
        print("\n" + "="*80)
        print("BACKTEST RESULTS SUMMARY")
        print("="*80)
        
        # Regime distribution
        if results.get('regime_stats'):
            print("\n--- Regime Distribution ---")
            for regime, stats in results['regime_stats'].items():
                pct = (stats['count'] / results['backtest_period']['days']) * 100
                print(f"{regime:20s}: {stats['count']:4d} days ({pct:5.1f}%)")
        
        # Signal quality
        if results.get('signal_quality'):
            sq_10d = results['signal_quality'].get('10d', {})
            print("\n--- Signal Quality (10-day forward) ---")
            print(f"Overall Accuracy:        {sq_10d.get('accuracy', 0):6.1%}")
            print(f"False Positive Rate:     {sq_10d.get('false_positive_rate', 0):6.1%}  (EM>18 but market fell)")
            print(f"False Negative Rate:     {sq_10d.get('false_negative_rate', 0):6.1%}  (EM<12 but market rallied)")
            print(f"Bullish Signals (EM>18): {sq_10d.get('bullish_signals', 0):4d}  (avg return: {sq_10d.get('avg_return_bullish', 0):+.2f}%)")
            print(f"Bearish Signals (EM<12): {sq_10d.get('bearish_signals', 0):4d}  (avg return: {sq_10d.get('avg_return_bearish', 0):+.2f}%)")
        
        # Regime performance
        if results.get('regime_stats'):
            print("\n--- Average 10-Day Forward Returns by Regime ---")
            for regime, stats in results['regime_stats'].items():
                avg_ret = stats.get('avg_return_10d', 0)
                pos_rate = stats.get('positive_pct_10d', 0)
                print(f"{regime:20s}: {avg_ret:+6.2f}%  ({pos_rate:5.1f}% positive)")
        
        # Trading simulation
        if results.get('trading_results'):
            tr = results['trading_results']
            print("\n--- Trading Simulation (EM-based Market Timing) ---")
            print(f"Initial Capital:  Rs.{tr['initial_capital']:10,.0f}")
            print(f"Final Capital:    Rs.{tr['final_capital']:10,.0f}")
            print(f"Total Return:     {tr['total_return']:9.2f}%")
            print(f"Number of Trades: {tr['num_trades']:10d}")
            print(f"Win Rate:         {tr['win_rate']:9.1f}%")
        
        print("\n" + "="*80)
        print(f"[OK] Complete results saved to: MBI_EM_Backtest_Results/")
        print("="*80)
        print("\nGenerated files:")
        print("  - backtest_results.xlsx        [EXCEL] (Excel with daily EM values) [IMPORTANT]")
        print("  - backtest_report.txt          (Full text report)")
        print("  - em_timeline.png              (EM over time)")
        print("  - returns_by_regime.png        (Box plot of returns)")
        print("  - threshold_sensitivity.png    (Optimal threshold analysis)")
        print("  - equity_curve.png             (Trading equity curve)")
        print()
        
    except Exception as e:
        logging.error(f"Backtest failed: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()

