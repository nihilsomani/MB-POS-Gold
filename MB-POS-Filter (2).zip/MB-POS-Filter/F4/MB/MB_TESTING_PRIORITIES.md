# MultiBeggar Strategy - Testing Priorities

## Phase 1: Scanner Validation (1-2 days)

### Goal
Ensure backtester matches live scanner behavior

### Tests
1. **Default Config Match**
   ```bash
   python run_mb_backtest.py --scenario default
   ```
   - Compare signals to recent scanner output
   - Verify monthly filter logic (TRIX, KC, SMA3 cross)
   - Verify weekly filter logic (RSI, Volume, Fractals)

2. **Entry Signal Count**
   - Track how many signals per month
   - Expected: 5-20 signals/month from 2500 stocks
   - Too many (>30): Filters too loose
   - Too few (<3): Filters too strict

3. **Signal Quality Check**
   - Win rate should be >50% for valid strategy
   - If <40%: Scanner catching false breakouts

---

## Phase 2: Exit Strategy Optimization (2-3 days)

### Priority: HIGH
Exit strategy has HUGE impact on long-term holds

### Tests

#### Test 1: Exit Strategy Comparison
```bash
python run_mb_backtest.py --compare default aggressive conservative trend_rider
```

**What to look for:**
- **Trailing Stop (12-20%)**: Lower DD, lower CAGR
- **TRIX Deterioration**: Higher CAGR, higher DD (let winners run)
- **Fractal Break**: Balanced (exit on reversal patterns)
- **Hybrid**: Best of all worlds?

**Expected Winner:** Hybrid (combines trailing stop + TRIX + fractal)

#### Test 2: Trailing Stop Sweep
```bash
python run_mb_backtest.py --sensitivity trailing_stop_pct --param-values 0.08 0.10 0.12 0.15 0.18 0.20 0.25
```

**Hypothesis:**
- Tighter stops (<12%): More trades, lower CAGR, lower DD
- Wider stops (>20%): Fewer trades, higher CAGR, higher DD
- **Sweet spot:** 15-18% (balance risk/reward)

#### Test 3: Hold Period Limits
Test minimum and maximum hold periods

**Configurations to test:**
| Min Hold (weeks) | Max Hold (weeks) | Strategy Type |
|------------------|------------------|---------------|
| 2 | 26 | Swing trading |
| 4 | 39 | Short-term position |
| 8 | 52 | Medium-term hold |
| 12 | 104 | Multibagger approach |

**Expected:** Longer holds = higher CAGR (let winners run), but higher DD

---

## Phase 3: Entry Filter Optimization (3-5 days)

### Priority: MEDIUM-HIGH
Better entries = better exits

### Tests

#### Test 1: TRIX Threshold Sweep
```bash
python run_mb_backtest.py --sensitivity trix_threshold --param-values 0.5 1.0 1.5 2.0 2.5 3.0
```

**Hypothesis:**
- Lower threshold (0.5): More signals, mixed quality
- Higher threshold (2.5): Fewer signals, higher quality
- **Scanner default:** 1.5 (balanced)

**Look for:**
- Win rate vs number of trades trade-off
- CAGR plateau (diminishing returns)

#### Test 2: KC Distance Threshold
```bash
python run_mb_backtest.py --sensitivity kc_distance_threshold --param-values 0.0 0.5 1.0 1.5 2.0
```

**Hypothesis:**
- 0% distance: Enter on exact cross (whipsaws likely)
- 1%+ distance: Confirm breakout (fewer whipsaws)
- **Trade-off:** Miss early entries vs reduce false signals

#### Test 3: Weekly RSI Threshold
```bash
python run_mb_backtest.py --sensitivity rsi_threshold --param-values 60 65 70 75 80
```

**Hypothesis:**
- RSI < 65: Enter early (more signals, more losers)
- RSI < 75: Enter on strength (fewer signals, higher win rate)
- **Scanner default:** 70

#### Test 4: Entry Conditions Required
```bash
python run_mb_backtest.py --sensitivity entry_conditions_required --param-values 3 4 5 6
```

**Hypothesis:**
- 3/6 conditions: Aggressive (more signals, lower win rate)
- 5/6 conditions: Conservative (fewer signals, higher win rate)
- **Scanner default:** 4/6

**Critical Test:** Does requiring ALL conditions kill signal count?

---

## Phase 4: Position Sizing Tests (2-3 days)

### Priority: MEDIUM
Right sizing prevents ruin, maximizes returns

### Tests

#### Test 1: Equal Weight vs Conviction-Based
```python
# Edit MBBacktester.py
POSITION_SIZING_METHOD = 'equal_weight'  # vs 'conviction_based'
```

**Hypothesis:**
- Equal weight: Stable, predictable
- Conviction-based: Bigger positions on 5/6 or 6/6 condition stocks
- **Expected:** Conviction-based has higher CAGR, higher volatility

#### Test 2: Conviction Multiplier
```bash
python run_mb_backtest.py --sensitivity conviction_multiplier --param-values 1.0 1.2 1.5 1.8 2.0 2.5
```

**Hypothesis:**
- 1.0x: No boost (equal weight)
- 2.0x: Double position on high conviction
- **Risk:** Over-concentration if wrong

#### Test 3: Portfolio Size
Test 5, 8, 10, 12, 15 positions

**Hypothesis:**
- Fewer positions (5): Higher concentration, higher returns, higher DD
- More positions (15): Lower concentration, lower returns, lower DD
- **Sweet spot:** 8-10 positions

---

## Phase 5: Robustness Validation (3-5 days)

### Priority: CRITICAL
Prevent overfitting, validate real-world viability

### Tests

#### Test 1: Out-of-Sample Validation
```python
# Edit MBBacktester.py
RUN_OUT_OF_SAMPLE = True
TRAIN_START = "2022-01-01"
TRAIN_END = "2024-01-01"  # Train on 2 years
TEST_START = "2024-01-01"
TEST_END = "2025-10-23"    # Test on recent 21 months
```

**Success Criteria:**
- OOS CAGR within 50% of in-sample (e.g., if IS = 40%, OOS = 20%+)
- OOS Sharpe within 30% of in-sample
- OOS Max DD not 2x worse than in-sample

**Red Flags:**
- OOS CAGR < 10%: Strategy doesn't generalize
- OOS Max DD > 40%: Risk of ruin
- OOS Win Rate < 40%: Filters failing in new data

#### Test 2: Rolling Window Validation
Split backtest into 6-month windows, test stability

**Goal:** Consistent performance across different market regimes

#### Test 3: Monte Carlo Randomization
```python
# Edit MBBacktester.py
RUN_MONTE_CARLO = True
MONTE_CARLO_RUNS = 100
```

**Goal:** 
- Test 100 random parameter combinations
- Find parameter ranges that consistently work
- Identify if any "golden config" is just luck

#### Test 4: Benchmark Comparison
Compare to:
- **Buy & Hold Nifty 500**: Passive baseline
- **Random Entry/Exit**: Pure luck baseline
- **RRG Strategy**: Active rotation baseline

**Success Criteria:** 
- Beat Nifty 500 by 2x+ (risk-adjusted)
- Beat random by 3x+ (prove it's not luck)

---

## Phase 6: Practical Considerations (2-3 days)

### Priority: HIGH (Real Money!)

### Tests

#### Test 1: Transaction Cost Sensitivity
Current: 1% per round-trip

**Test scenarios:**
- 0.5% (ideal execution)
- 1.0% (realistic)
- 1.5% (poor execution, high slippage)
- 2.0% (worst case)

**Expected:** CAGR drops 5-10% with each 0.5% increase in costs

#### Test 2: Entry Delay Testing
```python
# Test delayed entries (can't execute same-day)
ENTRY_DELAY_DAYS = [0, 1, 3, 5, 7]
```

**Hypothesis:**
- 0-day delay: Unrealistic (can't scan & execute instantly)
- 3-day delay: Realistic (scan weekend, enter Monday)
- 7-day delay: Test signal decay

**Critical:** Does signal quality degrade after 5+ days?

#### Test 3: Partial Fill Scenarios
What if you can only get 60% of target position?

**Test:**
- Scale position sizes to 60%, 70%, 80% of target
- Impact on returns?

---

## Execution Timeline (2-3 weeks)

### Week 1: Foundation
- **Day 1-2:** Scanner validation (Phase 1)
- **Day 3-5:** Exit strategy tests (Phase 2)

### Week 2: Optimization
- **Day 6-8:** Entry filter tests (Phase 3)
- **Day 9-10:** Position sizing (Phase 4)

### Week 3: Validation
- **Day 11-13:** Out-of-sample validation (Phase 5)
- **Day 14-15:** Practical tests (Phase 6)
- **Day 16:** Final analysis & decision

---

## Expected Outcomes

### Best Case
- **CAGR:** 35-50% (in-sample), 25-35% (OOS)
- **Max DD:** 15-25%
- **Sharpe:** 1.5-2.5
- **Win Rate:** 55-65%

### Realistic Case
- **CAGR:** 25-35% (in-sample), 18-25% (OOS)
- **Max DD:** 20-30%
- **Sharpe:** 1.0-1.5
- **Win Rate:** 50-60%

### Worst Case (Strategy Doesn't Work)
- **CAGR:** <15% (OOS)
- **Max DD:** >35%
- **Sharpe:** <0.8
- **Win Rate:** <45%

**If worst case:** Re-evaluate scanner logic, consider different strategy

---

## Red Flags to Watch

1. **Too Few Trades (<20 total)**
   - Not enough data to validate
   - Increase signal frequency

2. **Win Rate <45%**
   - Catching false breakouts
   - Tighten entry filters

3. **Max DD >35%**
   - Stops too wide or not working
   - Tighten trailing stops

4. **OOS Performance Collapse**
   - Overfitting to historical data
   - Simplify strategy, fewer parameters

5. **Parameter Sensitivity Too High**
   - Small changes = huge CAGR swings
   - Strategy not robust, too fragile

---

## Success Criteria

### Minimum Viable Strategy
- ✅ CAGR >20% (OOS)
- ✅ Max DD <30%
- ✅ Sharpe >1.0
- ✅ Win Rate >50%
- ✅ At least 30 trades (statistical significance)

### Production-Ready Strategy
- ✅ CAGR >30% (in-sample), >20% (OOS)
- ✅ Max DD <25%
- ✅ Sharpe >1.5
- ✅ Win Rate >55%
- ✅ Stable across market regimes
- ✅ Beats Nifty 500 by 2x (risk-adjusted)

---

## Next Steps After Testing

1. **If strategy validates:**
   - Paper trade for 2-3 months
   - Start with small capital (10-20% of target)
   - Scale up if live results match backtest

2. **If strategy fails:**
   - Analyze failure modes (are filters too loose/tight?)
   - Test alternative strategies (mean reversion, trend following)
   - Consider combining with RRG or other systems

3. **Documentation:**
   - Record all test results
   - Document optimal parameters
   - Create trading playbook (entry/exit rules)

---

**Remember:** The goal is not to find THE BEST backtest, but to find a ROBUST strategy that works across different market conditions with realistic assumptions.

Good luck! 🚀

