"""
Sector MBI-RRG Scanner
======================

Blends the MBI Equity Momentum (EM) pipeline with the RRG sector universe.
For each sector, we:
    1. Fetch historical OHLCV for all member symbols
    2. Detect pocket pivots and track follow-through
    3. Compute sector-level EM series and trend deltas
    4. Classify the latest regime with the V3 classifier
Optionally, results can be exported to CSV / Excel.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import pandas as pd

# ---------------------------------------------------------------------------
# Configure import paths for shared MBI modules
# ---------------------------------------------------------------------------

FILE_ROOT = Path(__file__).resolve()
REPO_ROOT = FILE_ROOT.parents[3]
MBI_ROOT = REPO_ROOT / "MB-POS-Filter" / "F4" / "MBI"

for path in (REPO_ROOT, MBI_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import config as mbi_config  # type: ignore
from em_calculator import EMCalculator  # type: ignore
from followthrough_tracker import FollowThroughTracker  # type: ignore
from mbi_em_dashboard import MBIEMDashboard  # type: ignore
from pocket_pivot_detector import PocketPivotSignal  # type: ignore
from pocket_pivot_detector_optimized import (  # type: ignore
    OptimizedPocketPivotDetector,
)
from regime_classifier_v3 import TrendBasedRegimeClassifierV3  # type: ignore

DEFAULT_SECTOR_CSV = REPO_ROOT / "data" / "29oct2025_sector_marketcap_freefloat_20251101_150338.csv"
DEFAULT_CACHE_DIR = Path("MB-POS-Filter/F4/MBI-RRG/cache")
OUTPUT_DIR = Path("MB-POS-Filter/F4/MBI-RRG/output")

logger = logging.getLogger("sector_mbi_rrg_scanner")


# ---------------------------------------------------------------------------
# Utility Data Classes
# ---------------------------------------------------------------------------

@dataclass
class SectorResult:
    sector: str
    level_4: Optional[str]
    symbol_count: int
    latest_date: datetime
    em: float
    em_chng_1d: Optional[float]
    em_chng_3d: Optional[float]
    em_chng_5d: Optional[float]
    em_trend: str
    ppd_count_window: int
    ppd_success_window: int
    index_close: float
    index_pct_change_5d: Optional[float]
    index_trend: str
    regime: str
    market_type: str
    position_size: float
    trading_action: str
    confidence: float
    successful_symbols: List[str]

    def to_dict(self) -> Dict[str, object]:
        return {
            "sector": self.sector,
            "level_4": self.level_4,
            "symbol_count": self.symbol_count,
            "date": self.latest_date.strftime("%Y-%m-%d"),
            "EM": round(self.em, 2),
            "EM_chng_1d": None if self.em_chng_1d is None else round(self.em_chng_1d, 2),
            "EM_chng_3d": None if self.em_chng_3d is None else round(self.em_chng_3d, 2),
            "EM_chng_5d": None if self.em_chng_5d is None else round(self.em_chng_5d, 2),
            "EM_trend": self.em_trend,
            "PPDs_lookback": self.ppd_count_window,
            "PPD_success": self.ppd_success_window,
            "sector_index": round(self.index_close, 2),
            "index_pct_change_5d": None
            if self.index_pct_change_5d is None
            else round(self.index_pct_change_5d, 2),
            "index_trend": self.index_trend,
            "regime": self.regime,
            "market_type": self.market_type,
            "position_size": round(self.position_size * 100, 0),
            "trading_action": self.trading_action,
            "confidence": round(self.confidence, 2),
            "follow_through_symbols": ", ".join(sorted(set(self.successful_symbols))),
        }


# ---------------------------------------------------------------------------
# Sector Universe Loader
# ---------------------------------------------------------------------------


class SectorUniverse:
    """
    Loads sector membership from CSV and provides symbol -> sector mappings.
    Expected columns in the CSV:
        Symbol, Sector_Level_3, Sector_Level_4
    """

    def __init__(
        self,
        csv_path: Path,
        sector_column: str = "Sector_Level_4",
        symbol_column: str = "Symbol",
    ):
        if not csv_path.exists():
            raise FileNotFoundError(f"Sector CSV not found: {csv_path}")

        self.df = pd.read_csv(csv_path)
        self.df.columns = [col.strip() for col in self.df.columns]

        alias_map = {
            sector_column: ["Level_4", "Sector_Level4", "Sector_Level_4", "Sector", "Sector Level 4"],
            symbol_column: ["symbol", "SYMBOL"],
        }

        lower_to_actual = {col.lower(): col for col in self.df.columns}
        for target, aliases in alias_map.items():
            if target in self.df.columns:
                continue
            found = False
            for alias in aliases:
                actual = lower_to_actual.get(alias.lower())
                if actual:
                    self.df.rename(columns={actual: target}, inplace=True)
                    found = True
                    break
            if not found:
                raise ValueError(f"Sector CSV missing required column '{target}'")

        self.sector_column = sector_column
        self.symbol_column = symbol_column

        # Normalise symbols (strip spaces, uppercase)
        self.df[self.symbol_column] = (
            self.df[self.symbol_column].astype(str).str.strip().str.upper()
        )

    def symbols_by_sector(self, min_members: int = 5) -> Dict[str, List[str]]:
        grouped = (
            self.df.groupby(self.sector_column)[self.symbol_column]
            .apply(lambda s: sorted(set(s.dropna().tolist())))
            .to_dict()
        )

        filtered = {k: v for k, v in grouped.items() if len(v) >= min_members}
        logger.info(
            "Loaded %d sectors with ≥ %d members from %s",
            len(filtered),
            min_members,
            self.sector_column,
        )
        return filtered

    def sector_level4_map(self) -> Dict[str, Optional[str]]:
        return {
            sector: sector
            for sector in self.df[self.sector_column].dropna().unique().tolist()
        }

    def symbols_set(self, sectors: Optional[Iterable[str]] = None) -> List[str]:
        if sectors is None:
            symbols = self.df[self.symbol_column].dropna().unique().tolist()
        else:
            mask = self.df[self.sector_column].isin(list(sectors))
            symbols = self.df.loc[mask, self.symbol_column].dropna().unique().tolist()
        return sorted(set(symbols))


# ---------------------------------------------------------------------------
# Core Scanner
# ---------------------------------------------------------------------------


class SectorMBIRRGScanner:
    def __init__(
        self,
        sector_csv: Path = DEFAULT_SECTOR_CSV,
        cache_dir: Path = DEFAULT_CACHE_DIR,
        analysis_days: int = mbi_config.ANALYSIS_DAYS,
        lookback_days: int = mbi_config.LOOKBACK_DAYS,
        ppd_lookback: int = 10,
        min_ppd_sample: int = 5,
    ):
        self.sector_universe = SectorUniverse(sector_csv)
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.analysis_days = analysis_days
        self.lookback_days = lookback_days
        self.ppd_lookback = ppd_lookback
        self.min_ppd_sample = min_ppd_sample

        # Reuse MBI dashboard loaders to benefit from caching and token management
        self.dashboard = MBIEMDashboard(
            api_key=mbi_config.API_KEY,
            access_token=mbi_config.ACCESS_TOKEN,
            universe_csv=None,  # We will supply symbols manually
            analysis_days=analysis_days,
            lookback_days=lookback_days,
            require_index_data=False,
        )

        self.detector = OptimizedPocketPivotDetector(
            cache_dir=str(self.cache_dir / "ppd_cache")
        )
        self.follow_tracker = FollowThroughTracker()
        self.em_calculator = EMCalculator(
            lookback_days=self.ppd_lookback, min_sample_size=self.min_ppd_sample
        )
        self.regime_classifier = TrendBasedRegimeClassifierV3()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run(
        self,
        sectors: Optional[Sequence[str]] = None,
        min_members: int = 5,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
    ) -> pd.DataFrame:
        """
        Execute the sector scan and return a DataFrame of SectorResult rows.
        """
        sector_symbols = self.sector_universe.symbols_by_sector(min_members)
        if sectors:
            requested = set(sectors)
            sector_symbols = {
                k: sector_symbols[k] for k in sector_symbols if k in requested
            }
            if not sector_symbols:
                raise ValueError("No sectors matched the requested filter.")

        all_symbols = sorted({sym for members in sector_symbols.values() for sym in members})

        if not all_symbols:
            raise ValueError("No symbols available for analysis.")

        instruments_df = self.dashboard.load_instruments()

        end_dt = end_date or datetime.utcnow().date()
        if isinstance(end_dt, datetime):
            end_dt = end_dt.date()
        if start_date:
            start_dt = start_date.date() if isinstance(start_date, datetime) else start_date
        else:
            start_dt = end_dt - timedelta(days=self.analysis_days)

        warmup_buffer = timedelta(days=self.lookback_days + self.ppd_lookback)
        fetch_start = datetime.combine(start_dt, datetime.min.time()) - warmup_buffer
        fetch_end = datetime.combine(end_dt, datetime.max.time())

        stock_data = self.dashboard.prefetch_all_data(
            symbols=all_symbols,
            instruments_df=instruments_df,
            start_date=fetch_start,
            end_date=fetch_end,
        )

        if not stock_data:
            raise RuntimeError("No historical data fetched for sector symbols.")

        ppd_cache = self.detector.detect_bulk(stock_data, fetch_start, fetch_end)

        sector_level4 = self.sector_universe.sector_level4_map()
        sector_ppds = self._build_sector_ppds(ppd_cache, stock_data, sector_symbols)

        results: List[SectorResult] = []
        for sector, ppds in sector_ppds.items():
            try:
                summary = self._analyze_sector(
                    sector=sector,
                    level4=sector_level4.get(sector),
                    ppds=ppds,
                    stock_data=stock_data,
                    members=sector_symbols.get(sector, []),
                    latest_date=end_dt,
                )
                if summary:
                    results.append(summary)
            except Exception as exc:
                logger.exception("Failed to analyse sector %s: %s", sector, exc)

        df = pd.DataFrame([r.to_dict() for r in results]).sort_values(
            ["EM", "EM_chng_3d"], ascending=[False, False]
        )
        return df.reset_index(drop=True)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_sector_ppds(
        self,
        ppd_cache: Dict[datetime.date, List[str]],
        stock_data: Dict[str, pd.DataFrame],
        sector_symbols: Dict[str, List[str]],
    ) -> Dict[str, List[PocketPivotSignal]]:
        symbol_to_sector = {
            symbol: sector
            for sector, members in sector_symbols.items()
            for symbol in members
        }

        sector_ppds: Dict[str, List[PocketPivotSignal]] = defaultdict(list)

        for ppd_date, symbols in ppd_cache.items():
            for symbol in symbols:
                sector = symbol_to_sector.get(symbol)
                if sector is None:
                    continue
                if symbol not in stock_data:
                    continue

                df = stock_data[symbol]
                dt = datetime.combine(ppd_date, datetime.min.time())
                if dt not in df.index:
                    continue

                row = df.loc[dt]
                try:
                    ppd = PocketPivotSignal(
                        symbol=symbol,
                        date=dt,
                        open_price=float(row["open"]),
                        close_price=float(row["close"]),
                        high_price=float(row["high"]),
                        low_price=float(row["low"]),
                        volume=int(row["volume"]),
                        percent_gain=float(
                            ((row["close"] - row["open"]) / row["open"]) * 100
                        ),
                        volume_vs_avg=1.5,  # placeholder: detector already screened for threshold
                        volume_percentile=75.0,
                        volume_vs_red_days=1.0,
                    )
                except KeyError:
                    continue

                score = self.follow_tracker.track_follow_through(ppd, df)
                ppd.follow_through_score = score
                ppd.is_success = self.follow_tracker.evaluate_success(score)

                sector_ppds[sector].append(ppd)

        return sector_ppds

    def _sector_index_series(
        self, members: List[str], stock_data: Dict[str, pd.DataFrame]
    ) -> pd.Series:
        closes = []
        for symbol in members:
            df = stock_data.get(symbol)
            if df is None or df.empty:
                continue
            closes.append(df["close"])

        if not closes:
            return pd.Series(dtype=float)

        combined = pd.concat(closes, axis=1, join="inner")
        combined.columns = members[: combined.shape[1]]
        sector_index = combined.mean(axis=1)
        return sector_index.sort_index()

    def _analyze_sector(
        self,
        sector: str,
        level4: Optional[str],
        ppds: List[PocketPivotSignal],
        stock_data: Dict[str, pd.DataFrame],
        members: List[str],
        latest_date: datetime.date,
    ) -> Optional[SectorResult]:
        if not members:
            return None

        sector_index = self._sector_index_series(members, stock_data)
        if sector_index.empty:
            return None

        latest_ts = sector_index.index.max()
        latest_close = float(sector_index.loc[latest_ts])

        trend_dates = self._recent_trading_days(sector_index, latest_date, window=6)
        if not trend_dates:
            return None

        ppds = sorted(ppds, key=lambda p: p.date)

        em_series = []
        for dt in trend_dates:
            em_score, meta = self._compute_em_for_date(dt, ppds)
            em_series.append(
                {
                    "date": dt,
                    "em": em_score,
                    "ppd_count": meta.get("ppd_count", 0),
                    "success_count": meta.get("success_count", 0),
                    "valid": meta.get("valid", False),
                    "success_symbols": meta.get("success_symbols", []),
                }
            )

        em_df = pd.DataFrame(em_series).set_index("date").sort_index()
        if em_df.empty:
            return None

        latest_row = em_df.iloc[-1]
        em_value = float(latest_row["em"])
        ppd_count = int(latest_row["ppd_count"])
        success_count = int(latest_row["success_count"])
        success_symbols = latest_row.get("success_symbols", [])
        if isinstance(success_symbols, float) and pd.isna(success_symbols):
            success_symbols = []
        elif isinstance(success_symbols, str):
            success_symbols = [success_symbols]
        elif success_symbols is None:
            success_symbols = []

        em_chng_1d = self._delta(em_df, days=1)
        em_chng_3d = self._delta(em_df, days=3)
        em_chng_5d = self._delta(em_df, days=5)
        em_trend = self._infer_em_trend(em_chng_1d, em_value)

        idx_pct_change_5d = self._pct_change(sector_index, days=5)
        index_trend = self._infer_index_trend(idx_pct_change_5d)

        # Classification should rely primarily on sector internals; ignore index conditioning.
        regime = self.regime_classifier.classify(
            em_score=em_value,
            em_change_1d=em_chng_1d,
            em_change_3d=em_chng_3d,
            em_change_5d=em_chng_5d,
            index_trend="unknown",
            index_pct_change_5d=0.0,
        )

        return SectorResult(
            sector=sector,
            level_4=level4,
            symbol_count=len(members),
            latest_date=trend_dates[-1],
            em=em_value,
            em_chng_1d=em_chng_1d,
            em_chng_3d=em_chng_3d,
            em_chng_5d=em_chng_5d,
            em_trend=em_trend,
            ppd_count_window=ppd_count,
            ppd_success_window=success_count,
            index_close=latest_close,
            index_pct_change_5d=idx_pct_change_5d,
            index_trend=index_trend,
            regime=regime.regime.value,
            market_type=regime.market_type.value,
            position_size=regime.position_size,
            trading_action=regime.trading_action,
            confidence=regime.confidence,
            successful_symbols=list(success_symbols),
        )

    # ------------------------------------------------------------------
    # Helper computations
    # ------------------------------------------------------------------

    def _compute_em_for_date(
        self, current_date: datetime, ppds: List[PocketPivotSignal]
    ) -> Tuple[float, Dict[str, object]]:
        start_window = current_date - timedelta(days=self.ppd_lookback)
        relevant = [
            p
            for p in ppds
            if start_window <= p.date <= current_date and p.is_success is not None
        ]
        if len(relevant) < self.min_ppd_sample:
            return 0.0, {
                "valid": False,
                "ppd_count": len(relevant),
                "success_count": sum(1 for p in relevant if p.is_success),
                "success_symbols": sorted({p.symbol for p in relevant if p.is_success}),
            }

        success_count = sum(1 for p in relevant if p.is_success)
        success_symbols = sorted({p.symbol for p in relevant if p.is_success})
        em_score = (success_count / len(relevant)) * 100
        return em_score, {
            "valid": True,
            "ppd_count": len(relevant),
            "success_count": success_count,
            "success_symbols": success_symbols,
        }

    def _recent_trading_days(
        self, sector_index: pd.Series, latest_date: datetime.date, window: int = 6
    ) -> List[datetime]:
        dates = [idx for idx in sector_index.index if idx.date() <= latest_date]
        dates_sorted = sorted(dates)
        return dates_sorted[-window:] if len(dates_sorted) >= window else dates_sorted

    def _delta(self, em_df: pd.DataFrame, days: int) -> Optional[float]:
        if len(em_df) <= days:
            return None
        latest = em_df.iloc[-1]["em"]
        target = em_df.iloc[-(days + 1)]["em"]
        return float(latest - target)

    def _pct_change(self, series: pd.Series, days: int) -> Optional[float]:
        if series.empty or len(series) <= days:
            return None
        latest = series.iloc[-1]
        past = series.iloc[-(days + 1)]
        if past == 0:
            return None
        return float(((latest - past) / past) * 100)

    def _infer_em_trend(self, delta_1d: Optional[float], em_value: float) -> str:
        if delta_1d is None:
            return "unknown"
        if delta_1d <= -10 or em_value < 35:
            return "crashing"
        if delta_1d <= -3:
            return "declining"
        if delta_1d >= 3:
            return "rising"
        return "stable"

    def _infer_index_trend(self, pct_change_5d: Optional[float]) -> str:
        if pct_change_5d is None:
            return "unknown"
        if pct_change_5d >= 1.0:
            return "rising"
        if pct_change_5d <= -1.0:
            return "falling"
        return "flat"


# ---------------------------------------------------------------------------
# CLI Interface
# ---------------------------------------------------------------------------


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Sector MBI-RRG Scanner")
    parser.add_argument(
        "--sector-csv",
        type=Path,
        default=DEFAULT_SECTOR_CSV,
        help="Path to sector membership CSV",
    )
    parser.add_argument(
        "--days",
        type=int,
        default=mbi_config.ANALYSIS_DAYS,
        help="Number of analysis days to fetch per symbol",
    )
    parser.add_argument(
        "--min-members",
        type=int,
        default=5,
        help="Minimum number of tickers required per sector",
    )
    parser.add_argument(
        "--sectors",
        type=str,
        nargs="*",
        help="Optional list of Sector_Level_4 names to analyse",
    )
    parser.add_argument(
        "--export",
        type=str,
        choices=["csv", "excel", "none"],
        default="csv",
        help="Export format for summary table",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=OUTPUT_DIR,
        help="Directory for exports",
    )
    return parser.parse_args()


def main() -> None:
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
    )

    args = parse_args()

    scanner = SectorMBIRRGScanner(
        sector_csv=args.sector_csv,
        analysis_days=args.days,
    )
    df = scanner.run(sectors=args.sectors, min_members=args.min_members)

    print("\n=== Sector MBI-RRG Summary ===\n")
    display_cols = [
        "sector",
        "level_4",
        "symbol_count",
        "date",
        "EM",
        "EM_chng_1d",
        "EM_chng_3d",
        "EM_chng_5d",
        "EM_trend",
        "index_trend",
        "index_pct_change_5d",
        "regime",
        "market_type",
        "position_size",
        "trading_action",
        "follow_through_symbols",
    ]
    print(df[display_cols].to_string(index=False))

    if args.export != "none":
        args.output_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = args.output_dir / f"sector_mbi_rrg_{timestamp}"

        if args.export == "csv":
            filepath = filename.with_suffix(".csv")
            df.to_csv(filepath, index=False)
        else:
            filepath = filename.with_suffix(".xlsx")
            df.to_excel(filepath, index=False, engine="openpyxl")

        print(f"\n[OK] Exported summary to {filepath}")


if __name__ == "__main__":
    main()

