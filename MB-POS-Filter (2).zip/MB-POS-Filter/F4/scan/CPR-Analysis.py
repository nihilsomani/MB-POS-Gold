import pandas as pd

# Load your CPR data
df = pd.read_csv("cpr_scan_20251112_2031.csv")

# Ensure correct datatypes
df['date'] = pd.to_datetime(df['date'])
df['virgin'] = df['virgin'].astype(bool)

# Split daily & weekly
daily = df[df['timeframe'] == 'day'].copy()
weekly = df[df['timeframe'] == 'week'].copy()

# Merge weekly data into each daily row based on nearest past weekly CPR
merged = pd.merge_asof(
    daily.sort_values('date'),
    weekly.sort_values('date'),
    by='symbol',
    on='date',
    suffixes=('_day', '_week'),
    direction='backward'
)

# Filter criteria:
# 1️⃣ Both daily & weekly are virgin
# 2️⃣ Both width profiles are 'ultra_narrow' or 'narrow'
# 3️⃣ Optionally skip if either touched (already engaged)
cond = (
    (merged['virgin_day'] == True) &
    (merged['virgin_week'] == True) &
    (merged['width_profile_day'].isin(['ultra_narrow', 'narrow'])) &
    (merged['width_profile_week'].isin(['ultra_narrow', 'narrow']))
)

candidates = merged[cond].copy()

# Label the setup
candidates['setup_type'] = 'MultiTF_Virgin_Compression'
candidates['notes'] = (
    'Both daily and weekly CPRs are virgin & compressed '
    '=> high-probability 1–5 day directional play'
)

# Optional: Select final output columns (match your structure)
final_cols = [
    'symbol', 'timeframe_day', 'date', 'pivot_day', 'tc_day', 'bc_day',
    'width_day', 'width_pct_day', 'width_profile_day', 'bias_day',
    'virgin_day', 'virgin_type_day', 'virgin_role_day',
    'width_profile_week', 'virgin_week', 'virgin_role_week',
    'setup_type', 'notes', 'action_plan_day', 'context_day'
]
output = candidates[final_cols].reset_index(drop=True)

# Save for next scan
output.to_csv("multi_tf_breakout_candidates.csv", index=False)

print("✅ Multi-timeframe virgin compression setups saved as 'multi_tf_breakout_candidates.csv'")
print(output[['symbol','date','setup_type','width_profile_day','width_profile_week','bias_day']])
