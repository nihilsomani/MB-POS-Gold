import pandas as pd
import numpy as np
import requests
import json # REVIEWER NOTE: Added for composite score explanation
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
import pickle
import os
from kiteconnect import KiteConnect
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ath_scanner.log'),
        logging.StreamHandler()
    ]
)

class ATHVolumeScanner:
    def __init__(self, api_key: str, access_token: str, universe_csv_path: str):
        """
        Initialize the ATH Volume Scanner with enhanced features
        
        Args:
            api_key: Kite Connect API key
            access_token: Kite Connect access token
            universe_csv_path: Path to the CSV file containing the stock universe. 
                               The CSV must have a column named 'Symbol'.
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.instruments = {}
        self.cache_file = 'instruments_cache.pkl'
        self.results = []
        self.api_requests_per_second = 3 
        self.rate_limiter = threading.Semaphore(self.api_requests_per_second)
        
        # Enhanced strategy parameters
        self.ath_proximity_threshold = 0.12  # 8% from ATH
        self.min_market_cap = 1000  # Crores (Placeholder for future integration)
        self.min_volume = 60000  # Minimum average volume
        self.lookback_period = 55  # 1 year for ATH calculation
        self.min_price = 50  # Minimum stock price
        self.max_price = 10000  # Maximum stock price
        
        # Nifty 500 symbols for quality filtering
        self.universe_csv_path = universe_csv_path
        self.quality_universe = self.get_quality_universe()
        
        logging.info("Enhanced ATH Volume Scanner initialized")    

    def get_quality_universe(self) -> List[str]:
        """
        Reads the stock symbol universe from the 'Symbol' column of a given CSV file.
        """
        logging.info(f"Loading stock universe from: {self.universe_csv_path}")
        try:
            df = pd.read_csv(self.universe_csv_path)
            
            if 'Symbol' not in df.columns:
                logging.error("The provided CSV file must contain a 'Symbol' column.")
                raise ValueError("The provided CSV file must contain a 'Symbol' column.")
            
            symbols = df['Symbol'].dropna().str.strip().tolist()
            logging.info(f"Successfully loaded {len(symbols)} symbols into the universe.")
            return symbols
            
        except FileNotFoundError:
            logging.error(f"Error: The universe CSV file was not found at '{self.universe_csv_path}'")
            raise
        except Exception as e:
            logging.error(f"An error occurred while reading the universe CSV file: {e}")
            raise

    def fetch_and_cache_instruments(self) -> Dict:
        """
        Fetch NSE instruments and cache them for performance
        """
        cache_age_hours = 24
        
        if os.path.exists(self.cache_file):
            cache_stat = os.stat(self.cache_file)
            cache_age = (time.time() - cache_stat.st_mtime) / 3600
            
            if cache_age < cache_age_hours:
                logging.info("Loading instruments from cache")
                with open(self.cache_file, 'rb') as f:
                    return pickle.load(f)
        
        logging.info("Fetching fresh instruments data from Kite")
        try:
            instruments_list = self.kite.instruments("NSE")
            instruments = {}
            for instrument in instruments_list:
                if (instrument['segment'] == 'NSE' and 
                    instrument['instrument_type'] == 'EQ' and
                    instrument['tradingsymbol'] in self.quality_universe):
                    
                    symbol = instrument['tradingsymbol']
                    instruments[symbol] = {
                        'instrument_token': instrument['instrument_token'],
                        'name': instrument['name'],
                        'lot_size': instrument['lot_size'],
                        'tick_size': instrument['tick_size']
                    }
            
            with open(self.cache_file, 'wb') as f:
                pickle.dump(instruments, f)
            
            logging.info(f"Cached {len(instruments)} quality NSE instruments")
            return instruments
            
        except Exception as e:
            logging.error(f"Error fetching instruments: {e}")
            raise
    
    def get_historical_data(self, instrument_token: int, days: int = 252) -> pd.DataFrame:
        """
        Fetch historical data with retry mechanism
        """
        max_retries = 3
        retry_delay = 1
        
        for attempt in range(max_retries):
            try:
                with self.rate_limiter:
                    to_date = datetime.now()
                    from_date = to_date - timedelta(days=days + 50)
                    
                    data = self.kite.historical_data(
                        instrument_token=instrument_token,
                        from_date=from_date,
                        to_date=to_date,
                        interval='day'
                    )
                    time.sleep(1 / self.api_requests_per_second + 0.02)

                    if not data:
                        return pd.DataFrame()
                    
                    df = pd.DataFrame(data)
                    df['date'] = pd.to_datetime(df['date'])
                    df.set_index('date', inplace=True)
                    df.sort_index(inplace=True)
                    
                    return df.tail(days)
                    
            except Exception as e:
                if attempt < max_retries - 1:
                    logging.warning(f"Attempt {attempt + 1} failed for token {instrument_token}: {e}")
                    time.sleep(retry_delay * (2 ** attempt))
                else:
                    logging.error(f"All attempts failed for token {instrument_token}: {e}")
                    return pd.DataFrame()
    
    def calculate_technical_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate technical indicators with error handling
        """
        if df.empty or len(df) < 50:
            return df
        
        try:
            df['ema_21'] = df['close'].ewm(span=21, adjust=False).mean()
            df['ema_50'] = df['close'].ewm(span=50, adjust=False).mean()
            df['ema_200'] = df['close'].ewm(span=200, adjust=False).mean()
            df['sma_20'] = df['close'].rolling(window=20).mean()
            
            def calculate_rsi(prices, window=14):
                delta = prices.diff()
                gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
                loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
                rs = gain / (loss + 1e-10)
                return 100 - (100 / (1 + rs))
            
            df['rsi'] = calculate_rsi(df['close'])
            
            exp1 = df['close'].ewm(span=12, adjust=False).mean()
            exp2 = df['close'].ewm(span=26, adjust=False).mean()
            df['macd'] = exp1 - exp2
            df['macd_signal'] = df['macd'].ewm(span=9, adjust=False).mean()
            df['macd_histogram'] = df['macd'] - df['macd_signal']
            
            df['bb_middle'] = df['sma_20']
            df['bb_std'] = df['close'].rolling(window=20).std()
            df['bb_upper'] = df['bb_middle'] + (df['bb_std'] * 2)
            df['bb_lower'] = df['bb_middle'] - (df['bb_std'] * 2)
            
            df['high_low'] = df['high'] - df['low']
            df['high_close'] = np.abs(df['high'] - df['close'].shift())
            df['low_close'] = np.abs(df['low'] - df['close'].shift())
            df['true_range'] = df[['high_low', 'high_close', 'low_close']].max(axis=1)
            df['atr'] = df['true_range'].rolling(window=14).mean()
            
            df['volume_roc'] = df['volume'].pct_change(periods=5) * 100
            
            df['close_in_range'] = (df['close'] - df['low']) / (df['high'] - df['low'] + 1e-10)
            
            df.drop(['high_low', 'high_close', 'low_close', 'true_range'], axis=1, inplace=True)
            
        except Exception as e:
            logging.error(f"Error calculating technical indicators: {e}")
        
        return df

    # REVIEWER NOTE: Enhancement 1 - Improved Smart Money Divergence Detection
    def calculate_flow_divergence(self, df: pd.DataFrame) -> str:
        if len(df) < 30:
            return 'NEUTRAL'

        try:
            # Get recent data for analysis
            recent_20 = df.tail(20)
            recent_10 = df.tail(10)
            recent_5 = df.tail(5)

            # Trend and anomaly context
            recent_closes = recent_20['close']
            if len(recent_closes) >= 2:
                price_indices = np.arange(len(recent_closes))
                price_slope = np.polyfit(price_indices, recent_closes.values, 1)[0]
            else:
                price_slope = 0.0
            trend_up = price_slope > 0
            trend_down = price_slope < 0

            df['volume_ma_60'] = df['volume'].rolling(60).mean()
            df['volume_std_60'] = df['volume'].rolling(60).std()
            df['volume_zscore'] = (df['volume'] - df['volume_ma_60']) / (df['volume_std_60'] + 1e-10)
            current_volume_z = df['volume_zscore'].iloc[-1] if 'volume_zscore' in df.columns else 0.0

            # Calculate moving averages
            df['volume_ma_20'] = df['volume'].rolling(20).mean()
            current_volume = df['volume'].iloc[-1]
            avg_volume_20 = df['volume_ma_20'].iloc[-1]
            volume_ratio_20 = current_volume / avg_volume_20

            # Price performance metrics
            current_price = df['close'].iloc[-1]
            price_change_5d = ((current_price - df['close'].iloc[-6]) / df['close'].iloc[-6]) * 100 if len(df) >= 6 else 0
            price_change_10d = ((current_price - df['close'].iloc[-11]) / df['close'].iloc[-11]) * 100 if len(df) >= 11 else 0

            # VWAP & close-in-range
            if 'vwap' not in df.columns:
                df['vwap'] = (df['volume'] * (df['high'] + df['low'] + df['close']) / 3).cumsum() / df['volume'].cumsum()

            current_vwap = df['vwap'].iloc[-1]
            close_in_range = df['close_in_range'].iloc[-1] if 'close_in_range' in df.columns else 0.5

            # 🟢 Guard: Avoid false distribution if price & volume are rising
            if (price_change_5d > 0 and volume_ratio_20 > 1.0 and current_price > current_vwap
                    and current_volume_z > -0.5 and trend_up):
                return 'MOMENTUM'

            # 1. Momentum
            if (price_change_5d > 5.0 and 
                price_change_10d > 8.0 and 
                volume_ratio_20 > 1.3 and 
                current_price > current_vwap and
                current_volume_z > 0.5 and trend_up):
                return 'MOMENTUM'

            # 2. Follow-through
            if (price_change_5d > 1.0 and 
                volume_ratio_20 < 0.8 and 
                current_price > current_vwap and 
                close_in_range > 0.6 and trend_up):
                
                recent_high = recent_10['high'].max()
                distance_from_recent_high = ((recent_high - current_price) / recent_high) * 100

                if distance_from_recent_high < 5:
                    price_change_20d = ((current_price - df['close'].iloc[-21]) / df['close'].iloc[-21]) * 100 if len(df) >= 21 else 0
                    if price_change_20d > 10:
                        return 'FOLLOW_THROUGH'

            # 3. Profit booking
            if (price_change_5d > 3.0 and 
                volume_ratio_20 > 1.8 and 
                close_in_range < 0.5 and
                current_volume_z > 1.0):

                recent_volume_avg = recent_5['volume'].mean()
                prev_volume_avg = df['volume'].iloc[-10:-5].mean()
                volume_acceleration = recent_volume_avg / prev_volume_avg

                if volume_acceleration > 1.5:
                    return 'PROFIT_BOOKING'

            # 4. Enhanced distribution (run only if price is falling)
            if price_change_5d < -1.0 and volume_ratio_20 < 1.0 and trend_down:
                high_volume_threshold = avg_volume_20 * 1.5
                high_volume_days = recent_20[recent_20['volume'] > high_volume_threshold]

                if len(high_volume_days) > 0:
                    recent_high = recent_20['high'].max()
                    peak_volume_days = high_volume_days[high_volume_days['high'] >= recent_high * 0.98]

                    if len(peak_volume_days) > 0:
                        peak_avg_volume = peak_volume_days['volume'].mean()
                        current_volume_ratio = current_volume / peak_avg_volume

                        if (current_volume_ratio < 0.5 and
                            current_price < current_vwap and
                            current_volume_z < -0.5):
                            return 'DISTRIBUTION'

            # 5. Accumulation
            accumulation_score = 0
            for i in range(-10, 0):
                if i + len(df) < 0:
                    continue
                daily_volume = df['volume'].iloc[i]
                daily_close = df['close'].iloc[i]
                daily_open = df['open'].iloc[i] if 'open' in df.columns else daily_close
                daily_low = df['low'].iloc[i]
                daily_high = df['high'].iloc[i]
                daily_volume_ratio = daily_volume / avg_volume_20

                if (daily_volume_ratio > 1.1 and 
                    daily_close >= daily_open * 0.995 and 
                    (daily_close - daily_low) / (daily_high - daily_low + 1e-10) > 0.6):
                    accumulation_score += 1

            if accumulation_score >= 5:
                return 'ACCUMULATION'

            # 6. Absorption
            if (-1.0 <= price_change_5d <= 2.0 and 
                volume_ratio_20 < 0.7 and 
                current_price >= current_vwap * 0.99 and
                -0.5 <= current_volume_z <= 0.5):

                prev_5_volume_avg = df['volume'].iloc[-10:-5].mean()
                if prev_5_volume_avg > avg_volume_20 * 1.2:
                    return 'ABSORPTION'

            # 7. Default regime
            first_half = recent_20.iloc[:10]
            second_half = recent_20.iloc[10:]
            price_change = second_half['close'].mean() - first_half['close'].mean()
            volume_change = second_half['volume'].mean() - first_half['volume'].mean()

            volume_threshold = avg_volume_20 * 0.2
            price_threshold = current_price * 0.01

            if price_change > price_threshold and volume_change > volume_threshold and trend_up:
                return 'MOMENTUM'
            elif price_change > price_threshold and volume_change < -volume_threshold and trend_up:
                if current_price > current_vwap and close_in_range > 0.5:
                    return 'FOLLOW_THROUGH'
                else:
                    return 'PROFIT_BOOKING'
            elif price_change < -price_threshold and volume_change > volume_threshold and trend_down:
                return 'DISTRIBUTION'
            elif abs(price_change) <= price_threshold and volume_change > volume_threshold and abs(price_slope) < current_price * 0.0005:
                return 'ACCUMULATION'
            else:
                return 'NEUTRAL'

        except Exception as e:
            logging.error(f"Error in enhanced flow divergence calculation: {e}")
            return 'NEUTRAL'

    def calculate_distribution_score(self, df: pd.DataFrame) -> Dict:
        """
        NEW method to provide detailed distribution analysis scoring.
        Returns specific metrics that help quantify distribution strength.
        """
        if len(df) < 20:
            return {
                'distribution_score': 0,
                'peak_volume_ratio': 0,
                'volume_decline_severity': 0,
                'price_volume_divergence': 0,
                'distribution_days': 0
            }
        
        try:
            recent_20 = df.tail(20)
            current_volume = df['volume'].iloc[-1]
            avg_volume_20 = df['volume'].rolling(20).mean().iloc[-1]
            
            # Find peak volume day in recent period
            peak_volume_day = recent_20.loc[recent_20['volume'].idxmax()]
            peak_volume = peak_volume_day['volume']
            peak_price = peak_volume_day['high']
            
            # Calculate metrics
            peak_volume_ratio = peak_volume / avg_volume_20
            volume_decline_severity = ((peak_volume - current_volume) / peak_volume) * 100
            
            # Price-Volume divergence: High volume at high prices, low volume at current prices
            current_price = df['close'].iloc[-1]
            price_from_peak = ((peak_price - current_price) / peak_price) * 100
            
            # If volume declined more than price, it's bearish divergence
            price_volume_divergence = volume_decline_severity - price_from_peak
            
            # Count distribution-like days (high volume near peaks)
            distribution_days = 0
            recent_high = recent_20['high'].max()
            for _, row in recent_20.iterrows():
                if (row['volume'] > avg_volume_20 * 1.3 and 
                    row['high'] >= recent_high * 0.95):
                    distribution_days += 1
            
            # Calculate overall distribution score (0-100)
            distribution_score = 0
            
            if peak_volume_ratio > 2.0:  # Significant volume spike
                distribution_score += 25
            elif peak_volume_ratio > 1.5:
                distribution_score += 15
            
            if volume_decline_severity > 60:  # Volume dropped >60% from peak
                distribution_score += 30
            elif volume_decline_severity > 40:
                distribution_score += 20
            
            if price_volume_divergence > 20:  # Volume declined much more than price
                distribution_score += 25
            elif price_volume_divergence > 10:
                distribution_score += 15
            
            if distribution_days >= 2:  # Multiple high-volume days near peaks
                distribution_score += 20
            elif distribution_days >= 1:
                distribution_score += 10
            
            return {
                'distribution_score': min(distribution_score, 100),
                'peak_volume_ratio': round(peak_volume_ratio, 2),
                'volume_decline_severity': round(volume_decline_severity, 2),
                'price_volume_divergence': round(price_volume_divergence, 2),
                'distribution_days': distribution_days
            }
            
        except Exception as e:
            logging.error(f"Error calculating distribution score: {e}")
            return {
                'distribution_score': 0,
                'peak_volume_ratio': 0,
                'volume_decline_severity': 0,
                'price_volume_divergence': 0,
                'distribution_days': 0
            }


    def calculate_institutional_flow(self, df: pd.DataFrame) -> Dict:
        """
        Enhanced institutional flow analysis.
        """
        if df.empty or len(df) < 30:
            return {
                'institutional_score': 0, 'smart_money_flow': 'NEUTRAL',
                'accumulation_days': 0, 'bullish_conviction_days': 0,
                'mfi_current': 50.0, 'flow_divergence': 'NEUTRAL',
                'vwap_volume_ratio': 0.0, 'institutional_quality_days_cluster': 0
            }
        
        try:
            df['vwap'] = (df['volume'] * (df['high'] + df['low'] + df['close']) / 3).cumsum() / df['volume'].cumsum()
            
            typical_price = (df['high'] + df['low'] + df['close']) / 3
            money_flow = typical_price * df['volume']
            positive_flow = money_flow.where(typical_price > typical_price.shift(), 0)
            negative_flow = money_flow.where(typical_price < typical_price.shift(), 0)
            pos_flow_sum = positive_flow.rolling(14).sum()
            neg_flow_sum = negative_flow.rolling(14).sum()
            money_flow_ratio = pos_flow_sum / (neg_flow_sum + 1e-10)
            df['mfi'] = 100 - (100 / (1 + money_flow_ratio))
            df['mfi'] = pd.to_numeric(df['mfi'], errors='coerce').fillna(50.0)
            
            df['price_change'] = df['close'].pct_change()
            df['volume_spike'] = df['volume'] / df['volume'].rolling(20).mean()
            
            bullish_conviction_condition = (
                (df['price_change'] > 0.02) &
                (df['close_in_range'] > 0.8) &
                (df['volume_spike'] > 1.2)
            )
            accumulation_condition = (
                (df['volume_spike'] > 1.5) &
                (df['price_change'].abs() < 0.02) &
                (df['close'] > df['vwap']) &
                (~bullish_conviction_condition)
            )
            
            accumulation_days = int(accumulation_condition.sum())
            bullish_conviction_days = int(bullish_conviction_condition.sum())
            
            # REVIEWER NOTE: This now calls the enhanced divergence logic
            flow_divergence = self.calculate_flow_divergence(df)
            
            inst_score = 0
            above_vwap_volume = df[df['close'] > df['vwap']]['volume'].sum()
            total_volume = df['volume'].sum()
            vwap_ratio = float(above_vwap_volume / total_volume) if total_volume > 0 else 0.0
            
            if vwap_ratio > 0.6: inst_score += 30
            elif vwap_ratio > 0.5: inst_score += 20
            
            if accumulation_days >= 5: inst_score += 25
            elif accumulation_days >= 3: inst_score += 15
            elif accumulation_days >= 1: inst_score += 8
            
            if bullish_conviction_days >= 2: inst_score += 15
            elif bullish_conviction_days == 1: inst_score += 8
            
            current_mfi = float(df['mfi'].iloc[-1])
            if 40 <= current_mfi <= 80: inst_score += 25
            
            if flow_divergence == 'ACCUMULATION': inst_score += 20
            elif flow_divergence == 'MOMENTUM': inst_score += 15
            
            df['institutional_quality_day'] = accumulation_condition | bullish_conviction_condition
            institutional_days_in_last_10 = int(df['institutional_quality_day'].tail(10).sum())
            if institutional_days_in_last_10 >= 3: inst_score += 10
            
            smart_money_flow = 'BULLISH' if inst_score >= 60 else 'BEARISH' if inst_score <= 30 else 'NEUTRAL'
            
            return {
                'institutional_score': int(min(inst_score, 100)), 'smart_money_flow': smart_money_flow,
                'accumulation_days': accumulation_days, 'bullish_conviction_days': bullish_conviction_days,
                'mfi_current': round(current_mfi, 2), 'flow_divergence': flow_divergence,
                'vwap_volume_ratio': round(vwap_ratio, 4), 'institutional_quality_days_cluster': institutional_days_in_last_10
            }
        except Exception as e:
            logging.error(f"Error calculating institutional flow: {e}")
            return {
                'institutional_score': 0, 'smart_money_flow': 'NEUTRAL',
                'accumulation_days': 0, 'bullish_conviction_days': 0,
                'mfi_current': 50.0, 'flow_divergence': 'NEUTRAL',
                'vwap_volume_ratio': 0.0, 'institutional_quality_days_cluster': 0
            }
    
    # REVIEWER NOTE: Enhancement 4 - Breakout Candle Logic Enhancement
    def calculate_ath_metrics(self, df: pd.DataFrame) -> Dict:
        """
        Calculate All-Time High related metrics with enhanced analysis.
        MODIFIED to include a more robust breakout candle detection.
        """
        if df.empty:
            return {}
        
        try:
            current_price = df['close'].iloc[-1]
            ath_price = df['high'].max()
            ath_date = df['high'].idxmax()
            ath_distance_pct = ((ath_price - current_price) / ath_price) * 100
            days_since_ath = (df.index[-1] - ath_date).days
            
            recent_252_days = df.tail(252)
            high_52w = recent_252_days['high'].max()
            high_52w_distance = ((high_52w - current_price) / high_52w) * 100
            
            price_changes = {
                '1d': ((current_price - df['close'].iloc[-2]) / df['close'].iloc[-2]) * 100 if len(df) >= 2 else 0,
                '5d': ((current_price - df['close'].iloc[-6]) / df['close'].iloc[-6]) * 100 if len(df) >= 6 else 0,
                '20d': ((current_price - df['close'].iloc[-21]) / df['close'].iloc[-21]) * 100 if len(df) >= 21 else 0
            }
            
            breakout_strength = 0
            if ath_distance_pct <= 2: breakout_strength = 100
            elif ath_distance_pct <= 5: breakout_strength = 80
            elif ath_distance_pct <= 10: breakout_strength = 60

            coiled_setup_found = False
            if len(df) >= 10:
                recent_10_days = df.tail(10)
                is_coiled_proximity = (recent_10_days['close'] >= ath_price * 0.97).all()
                if len(recent_10_days) >= 5:
                    std_dev_last_5 = (recent_10_days['high'] - recent_10_days['low']).tail(5).std()
                    std_dev_prev_5 = (df['high'] - df['low']).iloc[-10:-5].std()
                    if std_dev_last_5 < std_dev_prev_5 * 0.8:
                        coiled_setup_found = is_coiled_proximity
            
            # Original breakout logic (from coil)
            breakout_from_coil = False
            if coiled_setup_found and len(df) >= 2:
                prev_10_day_high = df['high'].iloc[-11:-1].max()
                current_volume_ratio = df['volume'].iloc[-1] / df['volume'].rolling(20).mean().iloc[-1]
                if current_price > prev_10_day_high and current_volume_ratio > 1.5:
                    breakout_from_coil = True
            
            # New direct breakout condition
            is_breakout_day = False
            close_in_range_today = df['close_in_range'].iloc[-1]
            volume_ratio_20_today = df['volume'].iloc[-1] / df['volume'].rolling(20).mean().iloc[-1]
            if (current_price >= high_52w) and close_in_range_today > 0.8 and volume_ratio_20_today > 1.5:
                is_breakout_day = True
            
            breakout_candle_found = breakout_from_coil or is_breakout_day

            # Breakout quality metrics
            range_series = (df['high'] - df['low'])
            avg_range_20 = range_series.rolling(20).mean().iloc[-1] if len(range_series) >= 20 else range_series.mean()
            current_range = range_series.iloc[-1]
            range_expansion_ratio = current_range / (avg_range_20 + 1e-10) if avg_range_20 else 0

            volume_window = df['volume'].tail(60)
            if not volume_window.empty:
                volume_percentile_60 = float(volume_window.rank(pct=True).iloc[-1] * 100)
            else:
                volume_percentile_60 = 0.0

            breakout_quality_score = 0
            if breakout_candle_found:
                breakout_quality_score += 40
            if range_expansion_ratio >= 1.5:
                breakout_quality_score += 30
            elif range_expansion_ratio >= 1.2:
                breakout_quality_score += 20
            if volume_percentile_60 >= 90:
                breakout_quality_score += 30
            elif volume_percentile_60 >= 75:
                breakout_quality_score += 20
            breakout_quality_score = min(breakout_quality_score, 100)
            
            return {
                'current_price': round(current_price, 2), 'ath_price': round(ath_price, 2),
                'ath_distance_pct': round(ath_distance_pct, 2), 'days_since_ath': days_since_ath,
                'high_52w': round(high_52w, 2), 'high_52w_distance_pct': round(high_52w_distance, 2),
                'price_change_1d': round(price_changes['1d'], 2), 'price_change_5d': round(price_changes['5d'], 2),
                'price_change_20d': round(price_changes['20d'], 2), 'breakout_strength': breakout_strength,
                'is_near_ath': ath_distance_pct <= (self.ath_proximity_threshold * 100),
                'is_new_ath': current_price >= ath_price, 'coiled_setup_found': coiled_setup_found,
                'breakout_candle_found': breakout_candle_found,
                'range_expansion_ratio': round(range_expansion_ratio, 2),
                'volume_percentile_60': round(volume_percentile_60, 1),
                'breakout_quality_score': breakout_quality_score
            }
        except Exception as e:
            logging.error(f"Error calculating ATH metrics: {e}")
            return {}

    # REVIEWER NOTE: Enhancement 2 - Use Weighted Moving Average (WMA) for Volume Trend
    # Updated volume metrics method to include distribution analysis
    def calculate_volume_metrics_enhanced_v2(self, df: pd.DataFrame) -> Dict:
        """
        Updated volume analysis with enhanced flow divergence.
        """
        if df.empty or len(df) < 20:
            return {}
        
        try:
            # Existing volume metrics
            current_volume = df['volume'].iloc[-1]
            vol_ma_20 = df['volume'].rolling(window=20).mean().iloc[-1]
            vol_ma_50 = df['volume'].rolling(window=50).mean().iloc[-1] if len(df) >= 50 else vol_ma_20
            
            volume_ratio_20 = current_volume / vol_ma_20 if vol_ma_20 > 0 else 0
            volume_ratio_50 = current_volume / vol_ma_50 if vol_ma_50 > 0 else 0
            volume_momentum = df['volume_roc'].iloc[-1] if 'volume_roc' in df.columns else 0
            
            # Enhanced volume trend with WMA
            weights = np.arange(1, 11)
            volume_wma_10 = df['volume'].tail(10).rolling(window=10).apply(
                lambda x: np.dot(x, weights) / weights.sum(), raw=True
            ).iloc[-1]
            volume_trend = 'UP' if current_volume > volume_wma_10 and vol_ma_20 > self.min_volume else 'DOWN'
            
            # Use enhanced flow divergence
            flow_divergence = self.calculate_flow_divergence(df)  # This now uses the enhanced version
            
            # Adjust quality score based on new classifications
            quality_score = 0
            if volume_ratio_20 > 1.5: quality_score += 30
            elif volume_ratio_20 > 1.0: quality_score += 10
            if volume_trend == 'UP': quality_score += 20
            if volume_momentum > 0: quality_score += 20
            
            # Enhanced scoring based on flow divergence
            flow_score_map = {
                'MOMENTUM': 25,
                'FOLLOW_THROUGH': 20,
                'ACCUMULATION': 15,
                'ABSORPTION': 10,
                'NEUTRAL': 0,
                'PROFIT_BOOKING': -10,
                'DISTRIBUTION': -20
            }
            quality_score += flow_score_map.get(flow_divergence, 0)
            
            distribution_metrics = self.calculate_distribution_score(df)
            institutional_metrics = self.calculate_institutional_flow(df)
            
            return {
                'current_volume': int(current_volume),
                'avg_volume_20': int(vol_ma_20),
                'avg_volume_50': int(vol_ma_50),
                'volume_ratio_20': round(volume_ratio_20, 2),
                'volume_ratio_50': round(volume_ratio_50, 2),
                'volume_momentum': round(volume_momentum, 2),
                'volume_trend': volume_trend,
                'volume_quality_score': max(min(quality_score, 100), 0),
                'flow_divergence': flow_divergence,
                **distribution_metrics,
                **institutional_metrics
            }
            
        except Exception as e:
            logging.error(f"Error calculating enhanced volume metrics v2: {e}")
            return {}
    def get_nifty_historical_data(self, days: int = 252) -> pd.DataFrame:
        nifty_token = 256265 # NIFTY 50 index token
        try:
            nifty_df = self.get_historical_data(nifty_token, days)
            if not nifty_df.empty:
                return nifty_df
        except Exception as e:
            logging.warning(f"Could not fetch real Nifty 50 data: {e}. Relative strength will be zero.")
        return pd.DataFrame()

    def calculate_relative_strength(self, df: pd.DataFrame, nifty_df: pd.DataFrame) -> Dict:
        """
        Calculates relative strength against Nifty 50.
        """
        if df.empty or nifty_df.empty or len(df) < 10 or len(nifty_df) < 10:
            return {'relative_strength_10d': 0, 'outperformance_score': 0, 'consistent_outperformance_bonus': 0}

        try:
            combined_df = pd.merge(df[['close']], nifty_df[['close']], left_index=True, right_index=True, suffixes=('_stock', '_nifty'))
            if len(combined_df) < 10: return {'relative_strength_10d': 0, 'outperformance_score': 0, 'consistent_outperformance_bonus': 0}

            recent_10_days = combined_df.tail(10)
            stock_returns = recent_10_days['close_stock'].pct_change().dropna()
            nifty_returns = recent_10_days['close_nifty'].pct_change().dropna()

            cumulative_stock_return = (1 + stock_returns).prod() - 1
            cumulative_nifty_return = (1 + nifty_returns).prod() - 1
            relative_strength_10d = (cumulative_stock_return - cumulative_nifty_return) * 100

            outperformance_days = (stock_returns > nifty_returns).sum()
            outperformance_score = (outperformance_days / len(stock_returns)) * 100 if len(stock_returns) > 0 else 0

            consistent_outperformance_bonus = ((nifty_returns <= 0) & (stock_returns > nifty_returns)).sum()

            return {
                'relative_strength_10d': round(relative_strength_10d, 2),
                'outperformance_score': round(outperformance_score, 2),
                'consistent_outperformance_bonus': consistent_outperformance_bonus
            }
        except Exception as e:
            logging.error(f"Error calculating relative strength: {e}")
            return {'relative_strength_10d': 0, 'outperformance_score': 0, 'consistent_outperformance_bonus': 0}

    # REVIEWER NOTE: Enhancement 3 - Highlight RSI-MACD Alignment
    def calculate_momentum_bias(self, df: pd.DataFrame) -> str:
        """
        NEW method to determine momentum bias based on RSI and MACD alignment.
        """
        if df.empty or 'rsi' not in df.columns or 'macd_histogram' not in df.columns:
            return 'NEUTRAL'
        
        last_row = df.iloc[-1]
        rsi = last_row.get('rsi', 50)
        macd_hist = last_row.get('macd_histogram', 0)
        
        if rsi > 60 and macd_hist > 0:
            return 'BULLISH'
        elif rsi < 40 and macd_hist < 0:
            return 'BEARISH'
        else:
            return 'NEUTRAL'

    # REVIEWER NOTE: Enhancement 5 - Add Composite Scoring Explanation
    def calculate_opportunity_score(self, symbol: str, ath_metrics: Dict, 
                                  volume_metrics: Dict, df: pd.DataFrame,
                                  relative_strength_metrics: Dict, momentum_bias: str) -> Tuple[float, Dict]:
        """
        Enhanced opportunity scoring with institutional bias, relative strength, and coiled setup.
        MODIFIED to return a tuple of (total_score, score_components).
        """
        scores = { "ath_proximity": 0.0, "institutional": 0.0, "volume": 0.0, "technical": 0.0,
                   "momentum": 0.0, "relative_strength": 0.0, "bonus": 0.0 }
        
        try:
            # ATH Proximity (20 points)
            if ath_metrics.get('is_new_ath', False): scores['ath_proximity'] = 20
            elif ath_metrics.get('is_near_ath', False):
                dist = ath_metrics.get('ath_distance_pct', 100)
                if dist <= 1: scores['ath_proximity'] = 18
                elif dist <= 3: scores['ath_proximity'] = 15
                else: scores['ath_proximity'] = 10
            
            # Institutional Score (25 points)
            scores['institutional'] = (volume_metrics.get('institutional_score', 0) / 100) * 25
            
            # Volume Quality (15 points)
            vol_ratio = volume_metrics.get('volume_ratio_20', 0)
            if vol_ratio >= 2.0: scores['volume'] = 15
            elif vol_ratio >= 1.5: scores['volume'] = 10
            elif vol_ratio >= 1.2: scores['volume'] = 7
            
            # Technical Strength (15 points)
            if not df.empty:
                data = df.iloc[-1]
                if (data.get('close', 0) > data.get('ema_21', 0) and data.get('ema_21', 0) > data.get('ema_50', 0)):
                    scores['technical'] += 8
                # Use momentum_bias for RSI/MACD alignment score
                if momentum_bias == 'BULLISH': scores['technical'] += 7
                elif momentum_bias == 'NEUTRAL': scores['technical'] += 3
            
            # Momentum Score (10 points)
            price_change_5d = ath_metrics.get('price_change_5d', 0)
            if price_change_5d > 5: scores['momentum'] = 10
            elif price_change_5d > 2: scores['momentum'] = 7
            
            # Relative Strength (10 points)
            rs_score = relative_strength_metrics.get('outperformance_score', 0)
            scores['relative_strength'] = (rs_score / 100) * 10
            
            # Bonus Points (up to 10)
            if relative_strength_metrics.get('consistent_outperformance_bonus', 0) >= 2: scores['bonus'] += 5
            if ath_metrics.get('coiled_setup_found', False):
                scores['bonus'] += 3
                if ath_metrics.get('breakout_candle_found', False): scores['bonus'] += 2

            breakout_quality = ath_metrics.get('breakout_quality_score', 0)
            if breakout_quality >= 80:
                scores['bonus'] += 3
            elif breakout_quality >= 60:
                scores['bonus'] += 2
            elif breakout_quality >= 40:
                scores['bonus'] += 1

            scores['bonus'] = min(scores['bonus'], 10)

            total_score = sum(scores.values())
            return min(total_score, 100), {k: round(v, 1) for k, v in scores.items()}
            
        except Exception as e:
            logging.error(f"Error calculating opportunity score for {symbol}: {e}")
            return 0.0, {}
    
    def scan_symbol(self, symbol: str, instrument_data: Dict, nifty_df: pd.DataFrame) -> Optional[Dict]:
        """
        Scan individual symbol with all enhancements integrated.
        """
        try:
            df = self.get_historical_data(instrument_data['instrument_token'], self.lookback_period)
            
            if df.empty or len(df) < 50: return None
            
            current_price = float(df['close'].iloc[-1])
            if not (self.min_price <= current_price <= self.max_price): return None
            
            df = self.calculate_technical_indicators(df)
            
            # REVIEWER NOTE: Call new/updated methods
            ath_metrics = self.calculate_ath_metrics(df)
            volume_metrics = self.calculate_volume_metrics_enhanced_v2(df)
            relative_strength_metrics = self.calculate_relative_strength(df, nifty_df)
            momentum_bias = self.calculate_momentum_bias(df)

            if not ath_metrics.get('is_near_ath', False) and not ath_metrics.get('coiled_setup_found', False):
                return None
            
            # REVIEWER NOTE: Unpack tuple from enhanced scoring function
            opportunity_score, score_components = self.calculate_opportunity_score(
                symbol, ath_metrics, volume_metrics, df, relative_strength_metrics, momentum_bias
            )
            
            if opportunity_score < 50: return None
            
            result = {
                'symbol': str(symbol),
                'name': str(instrument_data['name']),
                'opportunity_score': round(opportunity_score, 1),
                'score_components': json.dumps(score_components), # Add score breakdown to results
                'momentum_bias': momentum_bias, # Add momentum bias to results
                **ath_metrics,
                **volume_metrics,
                **relative_strength_metrics,
                'scan_timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
            return result
            
        except Exception as e:
            logging.error(f"Error scanning {symbol}: {e}")
            return None

    def run_scan(self, max_workers: int = 5) -> pd.DataFrame:
        """
        Run parallel scan for better performance
        """
        logging.info("Starting Enhanced ATH Volume Strategy scan")
        self.instruments = self.fetch_and_cache_instruments()
        nifty_df = self.get_nifty_historical_data(self.lookback_period + 50)
        
        symbols_to_scan = [s for s in self.quality_universe if s in self.instruments]
        results = []
        total = len(symbols_to_scan)
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_symbol = { executor.submit(self.scan_symbol, s, self.instruments[s], nifty_df): s for s in symbols_to_scan }
            
            for i, future in enumerate(as_completed(future_to_symbol)):
                symbol = future_to_symbol[future]
                try:
                    result = future.result()
                    if result:
                        results.append(result)
                        logging.info(f"--> {symbol}: Score {result['opportunity_score']:.1f}")
                    if (i + 1) % 20 == 0:
                        logging.info(f"Progress: {i + 1}/{total} symbols scanned")
                except Exception as e:
                    logging.error(f"Error processing {symbol}: {e}")
        
        if not results:
            return pd.DataFrame()
        
        df_results = pd.DataFrame(results).sort_values('opportunity_score', ascending=False).reset_index(drop=True)
        df_results['rank'] = range(1, len(df_results) + 1)
        logging.info(f"Scan completed. Found {len(df_results)} high-quality opportunities")
        return df_results
    
    def generate_report(self, df: pd.DataFrame) -> str:
        """
        Generate detailed analysis report
        """
        if df.empty: return "No opportunities found."
        
        report = [
            "=" * 80, "ENHANCED ATH VOLUME SCANNER REPORT", "=" * 80,
            f"Scan Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Total Opportunities: {len(df)}\n",
            "SUMMARY STATISTICS:",
            f"Average Opportunity Score: {df['opportunity_score'].mean():.1f}",
            f"Stocks with Score >80: {len(df[df['opportunity_score'] > 80])}\n",
            "INSTITUTIONAL INSIGHTS:",
            f"Strong Institutional Activity (Score >70): {len(df[df.get('institutional_score', 0) > 70])}",
            f"Smart Money Bullish: {len(df[df.get('smart_money_flow', '') == 'BULLISH'])}",
            f"Accumulation Pattern: {len(df[df.get('flow_divergence', '') == 'ACCUMULATION'])}",
            f"Stocks with Coiled Setup: {len(df[df.get('coiled_setup_found', False) == True])}\n",
            "TOP 10 OPPORTUNITIES:", "-" * 80
        ]
        
        for _, row in df.head(10).iterrows():
            report.append(f"{row['rank']:2d}. {row['symbol']:<12s} | "
                         f"Score: {row['opportunity_score']:5.1f} | "
                         f"Price: ₹{row['current_price']:<7.2f} | "
                         f"ATH Dist: {row['ath_distance_pct']:5.1f}% | "
                         f"Inst: {row.get('institutional_score', 0):3.0f} | "
                         f"RS_10d: {row.get('relative_strength_10d', 0):5.1f}")
        
        return "\n".join(report)
    
    def save_results(self, df: pd.DataFrame, filename: str = None) -> str:
        """
        Save results with enhanced formatting and new columns.
        """
        if filename is None:
            filename = f'enhanced_ath_scan_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        
        # REVIEWER NOTE: Added 'score_components' and 'momentum_bias' to export
        export_columns = [
            'rank', 'symbol', 'name', 'opportunity_score', 'score_components', 'momentum_bias',
            'current_price', 'ath_price', 'ath_distance_pct', 'days_since_ath',
            'is_new_ath', 'coiled_setup_found', 'breakout_candle_found',
            'price_change_5d', 'price_change_20d',
            'institutional_score', 'smart_money_flow', 'flow_divergence',
            'accumulation_days', 'bullish_conviction_days',
            'current_volume', 'avg_volume_20', 'volume_ratio_20', 'volume_trend',
            'relative_strength_10d', 'outperformance_score',
            'scan_timestamp'
        ]
        
        available_columns = [col for col in export_columns if col in df.columns]
        df[available_columns].to_csv(filename, index=False)
        logging.info(f"Results saved to {filename}")
        return filename

if __name__ == "__main__":
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "EN4Yh7vkUb6JOzIvhhcOXstq2UlEgm84"
    UNIVERSE_CSV_PATH = "data\\MCAP25To50.csv"

    try:
        if "YOUR_API_KEY" in API_KEY or "path/to/your" in UNIVERSE_CSV_PATH:
             print("Please update API_KEY, ACCESS_TOKEN, and UNIVERSE_CSV_PATH variables in the script.")
        else:
            scanner = ATHVolumeScanner(
                api_key=API_KEY, 
                access_token=ACCESS_TOKEN, 
                universe_csv_path=UNIVERSE_CSV_PATH
            )
            results_df = scanner.run_scan(max_workers=5)
            
            if not results_df.empty:
                report = scanner.generate_report(results_df)
                print(report)
                filename = scanner.save_results(results_df)
                print(f"\nDetailed results saved to: {filename}")
            else:
                print("No high-quality opportunities found based on the symbols in your file.")
            
    except Exception as e:
        logging.critical(f"Scanner execution failed: {e}", exc_info=True)
        print(f"An error occurred. Check the 'ath_scanner.log' for details.")