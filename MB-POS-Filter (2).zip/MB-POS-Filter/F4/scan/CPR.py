"""
CPR & Virgin CPR Scanner using Kite Connect
Scans for Central Pivot Range and Virgin CPR across Intraday, Daily, and Weekly timeframes

Requirements:
pip install kiteconnect pandas numpy
"""

from kiteconnect import KiteConnect
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, time as dtime
import logging
import time
import json
from pathlib import Path
from typing import List, Optional, Iterable, Dict, Any, Tuple
import argparse
import sys

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class RateLimiter:
    """Simple rate limiter to throttle API calls."""

    def __init__(self, calls_per_second: float = 3.0):
        self.calls_per_second = calls_per_second
        self.min_interval = 1.0 / calls_per_second if calls_per_second > 0 else 0
        self.last_call = 0.0

    def wait(self):
        if self.min_interval <= 0:
            return
        elapsed = time.time() - self.last_call
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_call = time.time()


class InstrumentCache:
    """Local cache for NSE instruments with JSON persistence."""

    def __init__(self, cache_file: str = 'nse_instruments_cache.json'):
        self.cache_file = Path(cache_file)
        self._store: Dict[str, List[Dict[str, Any]]] = {}
        self.load_cache()

    def load_cache(self):
        if self.cache_file.exists():
            try:
                with open(self.cache_file, 'r') as f:
                    raw = json.load(f)
                self._store = {symbol.upper(): entries for symbol, entries in raw.items()}
                total = sum(len(v) for v in self._store.values())
                logger.info(f"Loaded {total} instruments from cache")
            except Exception as exc:
                logger.warning(f"Failed to load instrument cache: {exc}")
                self._store = {}
        else:
            logger.info("Instrument cache file not found; will fetch from Kite when needed")

    def save_cache(self, instruments_list: List[dict]):
        store: Dict[str, List[dict]] = {}
        for inst in instruments_list:
            symbol = inst.get('tradingsymbol')
            if not symbol:
                continue
            key = symbol.upper()
            store.setdefault(key, []).append({
                'tradingsymbol': symbol,
                'exchange': inst.get('exchange'),
                'instrument_token': inst.get('instrument_token'),
                'name': inst.get('name')
            })
        try:
            with open(self.cache_file, 'w') as f:
                json.dump(store, f)
            logger.info(f"Saved {sum(len(v) for v in store.values())} instruments to cache")
            self._store = store
        except Exception as exc:
            logger.error(f"Unable to persist instrument cache: {exc}")

    def get(self, symbol: str, exchange_preference: Optional[Iterable[str]] = None) -> Optional[dict]:
        if not symbol:
            return None
        entries = self._store.get(symbol.upper())
        if not entries:
            return None
        if exchange_preference:
            if isinstance(exchange_preference, str):
                exchange_preference = [exchange_preference]
            for exchange in exchange_preference:
                for entry in entries:
                    if entry.get('exchange') == exchange:
                        return entry
        return entries[0]

    @property
    def is_empty(self) -> bool:
        return not self._store


class CPRScanner:
    """
    CPR Scanner to identify Central Pivot Range and Virgin CPR levels
    """
    
    def __init__(
        self,
        api_key,
        access_token,
        instrument_cache_path: str = 'nse_instruments_cache.json',
        calls_per_second: float = 3.0,
        exchanges: Optional[List[str]] = None
    ):
        """
        Initialize KiteConnect
        
        Args:
            api_key: Your Kite Connect API key
            access_token: Your access token after login
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.rate_limiter = RateLimiter(calls_per_second=calls_per_second)
        self.instrument_cache = InstrumentCache(cache_file=instrument_cache_path)
        self.default_exchanges = exchanges or ['NSE', 'INDICES']
        
    def calculate_cpr(self, high, low, close):
        pivot = (high + low + close) / 3
        bc = (high + low) / 2
        tc = (pivot - bc) + pivot
        return {
            'pivot': round(pivot, 2),
            'tc': round(tc, 2),
            'bc': round(bc, 2),
            'width': round(tc - bc, 2),
            'width_pct': round(((tc - bc) / pivot) * 100, 4)
        }
    
    def evaluate_virgin_status(
        self,
        session_high,
        session_low,
        cpr_levels,
        session_close: Optional[float] = None,
        session_open: Optional[float] = None,
        prev_close: Optional[float] = None
    ):
        if session_high is None or session_low is None:
            return {
                'is_virgin': False,
                'type': 'missing_data',
                'reason': 'Session high/low unavailable',
                'distance': None,
                'touch_type': 'missing_data',
                'gap_type': None,
                'gap_size': None,
                'gap_magnitude_pct': None
            }

        tc = cpr_levels['tc']
        bc = cpr_levels['bc']
        band_low = min(tc, bc)
        band_high = max(tc, bc)
        width = band_high - band_low if band_high != band_low else None

        gap_type = None
        gap_size = None
        gap_magnitude_pct = None
        if session_open is not None and prev_close is not None:
            gap_size = session_open - prev_close
            pivot = cpr_levels.get('pivot')
            if pivot:
                gap_magnitude_pct = round(abs(gap_size) / pivot * 100, 3)

        def compute_close_distance_pct(close_value: Optional[float]) -> Optional[float]:
            if close_value is None or width in (None, 0):
                return None
            if band_low <= close_value <= band_high:
                return 0.0
            if close_value > band_high:
                return round(((close_value - band_high) / width) * 100, 3)
            return round(((band_low - close_value) / width) * 100, 3)

        close_distance_pct = compute_close_distance_pct(session_close)

        # Virgin above the band
        if session_low > band_high:
            if gap_size is not None and prev_close is not None and session_open is not None:
                if prev_close <= band_high and session_open >= band_high and session_open > prev_close:
                    gap_type = 'gap_up_cross'
                    return {
                        'is_virgin': False,
                        'type': 'gap_cross',
                        'touch_type': 'gap_cross',
                        'virgin_side': None,
                        'distance': 0.0,
                        'potential': None,
                        'penetration_pct': 0.0,
                        'close_distance_pct': close_distance_pct,
                        'touch_severity': 'gap',
                        'gap_type': gap_type,
                        'gap_size': round(gap_size, 2),
                        'gap_magnitude_pct': gap_magnitude_pct
                    }
            distance = round(session_low - band_high, 2)
            return {
                'is_virgin': True,
                'type': 'above',
                'touch_type': 'virgin',
                'virgin_side': 'above',
                'distance': distance,
                'potential': 'support',
                'penetration_pct': 0.0,
                'close_distance_pct': close_distance_pct,
                'touch_severity': 'none',
                'gap_type': gap_type,
                'gap_size': round(gap_size, 2) if gap_size is not None else None,
                'gap_magnitude_pct': gap_magnitude_pct
            }

        # Virgin below the band
        if session_high < band_low:
            if gap_size is not None and prev_close is not None and session_open is not None:
                if prev_close >= band_low and session_open <= band_low and session_open < prev_close:
                    gap_type = 'gap_down_cross'
                    return {
                        'is_virgin': False,
                        'type': 'gap_cross',
                        'touch_type': 'gap_cross',
                        'virgin_side': None,
                        'distance': 0.0,
                        'potential': None,
                        'penetration_pct': 0.0,
                        'close_distance_pct': close_distance_pct,
                        'touch_severity': 'gap',
                        'gap_type': gap_type,
                        'gap_size': round(gap_size, 2),
                        'gap_magnitude_pct': gap_magnitude_pct
                    }
            distance = round(band_low - session_high, 2)
            return {
                'is_virgin': True,
                'type': 'below',
                'touch_type': 'virgin',
                'virgin_side': 'below',
                'distance': distance,
                'potential': 'resistance',
                'penetration_pct': 0.0,
                'close_distance_pct': close_distance_pct,
                'touch_severity': 'none',
                'gap_type': gap_type,
                'gap_size': round(gap_size, 2) if gap_size is not None else None,
                'gap_magnitude_pct': gap_magnitude_pct
            }

        # Touched inside the band
        penetration_pct = None
        touch_severity = 'unknown'
        if width not in (None, 0):
            overlap_low = max(session_low, band_low)
            overlap_high = min(session_high, band_high)
            penetration_points = max(0.0, overlap_high - overlap_low)
            penetration_pct = round((penetration_points / width) * 100, 3) if penetration_points > 0 else 0.0
            if penetration_pct == 0:
                touch_severity = 'glancing'
            elif penetration_pct <= 25:
                touch_severity = 'glancing'
            elif penetration_pct <= 75:
                touch_severity = 'moderate'
            else:
                touch_severity = 'deep'

        touch_type = 'wick_touch'
        if session_close is not None and band_low <= session_close <= band_high:
            touch_type = 'body_touch'

        return {
            'is_virgin': False,
            'type': touch_type,
            'touch_type': touch_type,
            'virgin_side': None,
            'distance': 0.0,
            'potential': None,
            'penetration_pct': penetration_pct,
            'close_distance_pct': close_distance_pct,
            'touch_severity': touch_severity,
            'gap_type': gap_type,
            'gap_size': round(gap_size, 2) if gap_size is not None else None,
            'gap_magnitude_pct': gap_magnitude_pct
        }

    @staticmethod
    def _normalize_ohlc_df(df):
        if df is None or df.empty:
            return None
        normalized = df.copy()
        normalized['date'] = pd.to_datetime(normalized['date'])
        normalized = normalized.sort_values('date').reset_index(drop=True)
        return normalized

    @staticmethod
    def _resample_weekly(daily_df):
        if daily_df is None or daily_df.empty:
            return None
        resampled = daily_df.copy()
        resampled['date'] = pd.to_datetime(resampled['date'])
        resampled.set_index('date', inplace=True)
        agg_map = {'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last'}
        if 'volume' in resampled.columns:
            agg_map['volume'] = 'sum'
        weekly = resampled.resample('W-FRI', label='right', closed='right').agg(agg_map)
        weekly = weekly.dropna(subset=['high', 'low', 'close']).reset_index()
        weekly = weekly.rename(columns={'date': 'date'})
        columns = ['date', 'open', 'high', 'low', 'close']
        if 'volume' in weekly.columns:
            columns.append('volume')
        return weekly[columns]

    @staticmethod
    def _build_intraday_session_map(intraday_df):
        if intraday_df is None or intraday_df.empty:
            return {}
        intraday = intraday_df.copy()
        intraday['date'] = pd.to_datetime(intraday['date'])
        intraday['session_date'] = intraday['date'].dt.date

        session_map = {}
        grouped = intraday.groupby('session_date')
        for session_date, group in grouped:
            session_map[session_date] = {
                'high': group['high'].max(),
                'low': group['low'].min(),
                'close': group['close'].iloc[-1] if 'close' in group else None,
                'volume': group['volume'].sum() if 'volume' in group else None,
                'candle_count': len(group)
            }

        return session_map

    def ensure_instrument_cache(self, exchanges: Optional[List[str]] = None, force_refresh: bool = False):
        exchanges = exchanges or self.default_exchanges
        if not force_refresh and not self.instrument_cache.is_empty:
            return
        self.refresh_instrument_cache(exchanges)

    def refresh_instrument_cache(self, exchanges: Optional[List[str]] = None):
        exchanges = exchanges or self.default_exchanges
        all_instruments: List[dict] = []
        for exchange in exchanges:
            try:
                logger.info(f"Fetching instruments for exchange {exchange}")
                self.rate_limiter.wait()
                instruments = self.kite.instruments(exchange)
                all_instruments.extend(instruments)
                logger.info(f"Fetched {len(instruments)} instruments from {exchange}")
            except Exception as exc:
                logger.warning(f"Failed to fetch instruments for {exchange}: {exc}")
        if all_instruments:
            self.instrument_cache.save_cache(all_instruments)
        else:
            logger.error("Unable to refresh instrument cache; no data fetched from Kite.")

    def get_instrument_token(
        self,
        symbol: str,
        exchange_preference: Optional[List[str]] = None,
        force_refresh: bool = True
    ) -> Optional[int]:
        if not symbol:
            return None
        symbol_key = symbol.strip().upper()
        entry = self.instrument_cache.get(symbol_key, exchange_preference)
        if entry:
            return entry.get('instrument_token')
        logger.info(f"Symbol {symbol_key} not in cache, refreshing instrument list")
        if force_refresh:
            self.refresh_instrument_cache()
            entry = self.instrument_cache.get(symbol_key, exchange_preference)
            if entry:
                return entry.get('instrument_token')
        return None

    def load_symbols_from_csv(self, csv_path: str, symbol_column: str = 'symbol') -> List[str]:
        try:
            df = pd.read_csv(csv_path)
        except Exception as exc:
            logger.error(f"Failed to read CSV at {csv_path}: {exc}")
            return []
        if symbol_column not in df.columns:
            logger.error(f"Column '{symbol_column}' not found in {csv_path}")
            return []
        symbols = (
            df[symbol_column]
            .dropna()
            .astype(str)
            .map(lambda x: x.strip().upper())
        )
        unique_symbols = [sym for sym in symbols.unique() if sym]
        logger.info(f"Loaded {len(unique_symbols)} symbols from {csv_path}")
        return unique_symbols

    def _classify_cpr_width(self, width_pct: Optional[float], thresholds: Optional[Dict[str, float]] = None) -> str:
        if width_pct is None:
            return 'unknown'
        default_thresholds = {'ultra': 0.25, 'narrow': 0.45, 'wide': 0.8}
        if thresholds:
            default_thresholds.update({k: v for k, v in thresholds.items() if v is not None})
        ultra_thr = default_thresholds['ultra']
        narrow_thr = default_thresholds['narrow']
        wide_thr = default_thresholds['wide']
        if width_pct <= ultra_thr:
            return 'ultra_narrow'
        if width_pct <= narrow_thr:
            return 'narrow'
        if width_pct >= wide_thr:
            return 'wide'
        return 'balanced'

    @staticmethod
    def _parse_range_text(range_text: Optional[str]) -> Tuple[Optional[float], Optional[float]]:
        if not isinstance(range_text, str):
            return None, None
        try:
            clean = range_text.replace('–', '-').replace('—', '-')
            parts = [p.strip() for p in clean.split('-')]
            if len(parts) != 2:
                return None, None
            low = float(parts[0])
            high = float(parts[1])
            if low > high:
                low, high = high, low
            return low, high
        except Exception:
            return None, None

    def _derive_action_plan(self, record: Dict[str, Any], thresholds: Optional[Dict[str, float]] = None) -> Dict[str, str]:
        virgin = record.get('virgin', {})
        cpr = record.get('cpr', {})
        width_pct = cpr.get('width_pct')
        width_profile = self._classify_cpr_width(width_pct, thresholds)
        action = "Data insufficient"
        context: List[str] = []
        distance = virgin.get('distance')
        if width_pct is not None:
            context.append(f"Width {width_pct}% ({width_profile.replace('_', ' ')})")
        if distance is not None and distance > 0:
            context.append(f"Gap from CPR {distance}")
        if virgin.get('is_virgin'):
            v_type = virgin.get('type')
            potential = virgin.get('potential', '').lower()
            if v_type == 'above':
                action = (
                    f"Plan long on controlled pullback towards TC {cpr.get('tc')} "
                    f"while CPR acts as {potential or 'support'}."
                )
            elif v_type == 'below':
                action = (
                    f"Plan short on rejection near BC {cpr.get('bc')} "
                    f"with CPR acting as {potential or 'resistance'}."
                )
            else:
                action = "Virgin CPR detected but direction unclear; wait for price reaction."
        else:
            v_type = virgin.get('type')
            reason = virgin.get('reason')
            if v_type == 'touched':
                action = "CPR already engaged; switch to breakout/mean-reversion scans."
            elif v_type == 'missing_data':
                action = "Cannot evaluate session; rerun after ensuring full intraday feed."
            else:
                action = "No actionable CPR edge detected."
            if reason:
                context.append(reason)
        if width_profile in ('ultra_narrow', 'narrow'):
            bias = 'breakout_watch'
            context.append("Expect expansion; favor trend trades post-breakout")
        elif width_profile == 'wide':
            bias = 'range_bias'
            context.append("Expect chop; fade extremes with confirmation")
        else:
            bias = 'balanced'
        return {
            'action_plan': action,
            'context': '; '.join(context),
            'width_profile': width_profile,
            'bias': bias
        }

    def results_to_dataframe(self, results: Dict[str, Dict[str, Dict[str, Any]]]) -> pd.DataFrame:
        rows: List[dict] = []
        for symbol, tf_data in results.items():
            for timeframe, payload in tf_data.items():
                thresholds = payload.get('width_thresholds') if isinstance(payload, dict) else None
                history_count = payload.get('width_history_count') if isinstance(payload, dict) else None
                for item in payload.get('all_cprs', []):
                    virgin = item.get('virgin', {})
                    cpr = item.get('cpr', {})
                    action_info = self._derive_action_plan(item, thresholds)
                    multi_tf_status = self._determine_multi_tf_status(results, symbol, timeframe, item)
                    record = {
                        'symbol': symbol,
                        'timeframe': timeframe,
                        'date': item.get('date'),
                        'pivot': cpr.get('pivot'),
                        'tc': cpr.get('tc'),
                        'bc': cpr.get('bc'),
                        'width': cpr.get('width'),
                        'width_pct': cpr.get('width_pct'),
                        'width_profile': action_info['width_profile'],
                        'bias': action_info['bias'],
                        'virgin': virgin.get('is_virgin'),
                        'virgin_type': virgin.get('type'),
                        'virgin_role': virgin.get('potential'),
                        'virgin_distance': virgin.get('distance'),
                        'next_period_label': item.get('next_period_label'),
                        'next_period_low': item.get('next_period_low'),
                        'next_period_high': item.get('next_period_high'),
                        'next_period_close': item.get('next_period_close'),
                        'next_period_volume': item.get('next_period_volume'),
                        'avg_volume_lookback': item.get('avg_volume_lookback'),
                        'volume_ratio': item.get('volume_ratio'),
                        'action_plan': action_info['action_plan'],
                        'context': action_info['context'],
                        'width_threshold_ultra': thresholds.get('ultra') if thresholds else None,
                        'width_threshold_narrow': thresholds.get('narrow') if thresholds else None,
                        'width_threshold_wide': thresholds.get('wide') if thresholds else None,
                        'width_history_count': history_count,
                        'touch_type': virgin.get('touch_type'),
                        'touch_severity': virgin.get('touch_severity'),
                        'penetration_pct': virgin.get('penetration_pct'),
                        'close_distance_pct': virgin.get('close_distance_pct'),
                        'virgin_side': virgin.get('virgin_side'),
                        'multi_tf_status': multi_tf_status,
                        'gap_type': virgin.get('gap_type'),
                        'gap_size': virgin.get('gap_size'),
                        'gap_magnitude_pct': virgin.get('gap_magnitude_pct')
                    }
                    rows.append(record)
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values(['symbol', 'timeframe', 'date'])
        return df

    def export_results_to_csv(
        self,
        results: Dict[str, Dict[str, Dict[str, Any]]],
        output_path: Optional[str] = None
    ) -> Optional[Path]:
        df = self.results_to_dataframe(results)
        if df.empty:
            logger.warning("No data to export to CSV.")
            return None
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M")
            output_path = f"reports/cpr_scan_{timestamp}.csv"
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False)
        logger.info(f"Exported CPR scan report to {output_path}")
        return output_path

    def generate_signal_dataframe(
        self,
        results: Dict[str, Dict[str, Dict[str, Any]]],
        allowed_width_profiles: Optional[List[str]] = None,
        risk_reward: float = 2.0,
        buffer_pct: float = 0.0015,
        buffer_fraction_of_width: float = 0.35,
        stale_threshold_pct: float = 0.75,
        min_volume_ratio: Optional[float] = None,
        top_candidate_config: Optional[Dict[str, Any]] = None,
        secondary_candidate_config: Optional[Dict[str, Any]] = None
    ) -> pd.DataFrame:
        base_df = self.results_to_dataframe(results)
        if base_df.empty:
            return pd.DataFrame()
        width_filters = set(allowed_width_profiles or ['ultra_narrow', 'narrow'])
        signal_rows: List[dict] = []
        default_top_cfg = {
            'required_signal_strength': ['primary'],
            'allowed_signal_strength': None,
            'max_penetration_pct': 25.0,
            'max_entry_gap_pct': 0.75,
            'required_multi_tf': ['aligned'],
            'disallow_volume_status': ['weak'],
            'disallow_gap_types': ['gap_cross'],
            'max_age_days': 3
        }
        if top_candidate_config:
            default_top_cfg.update(top_candidate_config)
        required_strength = default_top_cfg.get('required_signal_strength')
        allowed_strength = default_top_cfg.get('allowed_signal_strength')
        max_penetration_pct = default_top_cfg.get('max_penetration_pct')
        max_entry_gap_pct = default_top_cfg.get('max_entry_gap_pct')
        required_multi_tf = default_top_cfg.get('required_multi_tf')
        disallow_volume_status = default_top_cfg.get('disallow_volume_status') or []
        disallow_gap_types = default_top_cfg.get('disallow_gap_types') or []
        max_age_days = default_top_cfg.get('max_age_days')

        default_secondary_cfg = {
            'allowed_signal_strength': ['primary', 'soft'],
            'max_penetration_pct': 60.0,
            'max_entry_gap_pct': 1.5,
            'max_age_days': 7,
            'allowed_failure_reasons': ['signal_strength', 'entry_gap', 'penetration', 'age', 'multi_tf'],
            'max_failure_count': 2,
            'required_multi_tf': ['aligned', 'weakened']
        }
        if secondary_candidate_config:
            default_secondary_cfg.update(secondary_candidate_config)
        secondary_allowed_strength = default_secondary_cfg.get('allowed_signal_strength') or []
        secondary_max_pen = default_secondary_cfg.get('max_penetration_pct')
        secondary_max_gap = default_secondary_cfg.get('max_entry_gap_pct')
        secondary_max_age = default_secondary_cfg.get('max_age_days')
        secondary_allowed_reasons = set(default_secondary_cfg.get('allowed_failure_reasons') or [])
        secondary_max_failures = default_secondary_cfg.get('max_failure_count', 2)
        secondary_required_multi_tf = default_secondary_cfg.get('required_multi_tf')

        for row in base_df.itertuples():
            if not getattr(row, 'virgin', False):
                continue
            width_profile = getattr(row, 'width_profile', None)
            if width_profile not in width_filters:
                continue
            virgin_type = getattr(row, 'virgin_type', None)
            if virgin_type not in ('above', 'below'):
                continue
            tc = getattr(row, 'tc', None)
            bc = getattr(row, 'bc', None)
            if tc is None or bc is None:
                continue
            cpr_upper = max(tc, bc)
            cpr_lower = min(tc, bc)
            zone_width = abs(cpr_upper - cpr_lower)
            direction = 'long' if virgin_type == 'above' else 'short'
            entry_level = cpr_upper if direction == 'long' else cpr_lower
            base_stop = cpr_lower if direction == 'long' else cpr_upper
            buffer_from_zone = zone_width * buffer_fraction_of_width
            buffer_from_price = entry_level * buffer_pct
            buffer = max(buffer_from_zone, buffer_from_price, 0.05)
            if direction == 'long':
                stop_loss = base_stop - buffer
                if stop_loss <= 0 or stop_loss >= entry_level:
                    stop_loss = base_stop * (1 - buffer_pct)
                risk = entry_level - stop_loss
                if risk <= 0:
                    continue
                target = entry_level + risk_reward * risk
            else:
                stop_loss = base_stop + buffer
                if stop_loss <= entry_level:
                    stop_loss = base_stop * (1 + buffer_pct)
                risk = stop_loss - entry_level
                if risk <= 0:
                    continue
                target = entry_level - risk_reward * risk
            current_price = getattr(row, 'next_period_close', None)
            if current_price is not None:
                current_price = round(current_price, 2)
            if current_price is None:
                price_position = 'unknown'
            elif current_price > row.tc:
                price_position = 'above_tc'
            elif current_price < row.bc:
                price_position = 'below_bc'
            else:
                price_position = 'between_tc_bc'
            entry_gap_pct = None
            signal_status = 'fresh'
            if current_price is not None:
                entry_gap_pct = round(abs(current_price - entry_level) / entry_level * 100, 3)
                if entry_gap_pct > stale_threshold_pct:
                    signal_status = 'stale'
            signal_age_days = None
            if isinstance(row.date, pd.Timestamp):
                now_ts = datetime.now(row.date.tzinfo) if row.date.tzinfo else datetime.now()
                signal_age_days = (now_ts - row.date).days
            elif isinstance(row.date, datetime):
                now_ts = datetime.now(row.date.tzinfo) if row.date.tzinfo else datetime.now()
                signal_age_days = (now_ts - row.date).days
            volume_ratio = getattr(row, 'volume_ratio', None)
            avg_volume = getattr(row, 'avg_volume_lookback', None)
            volume_status = 'unknown'
            if volume_ratio is not None:
                volume_status = 'strong' if volume_ratio >= 1 else 'normal' if volume_ratio >= 0.8 else 'weak'
                if min_volume_ratio is not None and volume_ratio < min_volume_ratio:
                    continue
            elif min_volume_ratio is not None:
                continue
            touch_type = getattr(row, 'touch_type', None)
            multi_tf_status = getattr(row, 'multi_tf_status', None)
            gap_type = getattr(row, 'gap_type', None)
            signal_strength = 'primary'
            if touch_type == 'wick_touch':
                signal_strength = 'soft'
            elif touch_type == 'body_touch':
                signal_strength = 'invalid'
            if gap_type in ('gap_cross', 'gap_up_cross', 'gap_down_cross'):
                signal_strength = 'invalid_gap'
            if multi_tf_status == 'weakened' and signal_strength != 'invalid':
                signal_strength = 'weakened' if signal_strength == 'primary' else f"{signal_strength}_weakened"
            disqualify_reasons = []
            if required_strength and signal_strength not in required_strength:
                disqualify_reasons.append('signal_strength')
            if allowed_strength is not None and signal_strength not in allowed_strength:
                disqualify_reasons.append('signal_strength_allowed')
            if disallow_volume_status and volume_status in disallow_volume_status:
                disqualify_reasons.append('volume')
            if disallow_gap_types and gap_type in disallow_gap_types:
                disqualify_reasons.append('gap')
            if required_multi_tf and multi_tf_status not in (required_multi_tf or []):
                disqualify_reasons.append('multi_tf')
            penetration_val = getattr(row, 'penetration_pct', None)
            if max_penetration_pct is not None and penetration_val is not None and penetration_val > max_penetration_pct:
                disqualify_reasons.append('penetration')
            if max_entry_gap_pct is not None and entry_gap_pct is not None and entry_gap_pct > max_entry_gap_pct:
                disqualify_reasons.append('entry_gap')
            if max_age_days is not None and signal_age_days is not None and signal_age_days > max_age_days:
                disqualify_reasons.append('age')
            if signal_strength in ('invalid', 'invalid_gap', 'soft_weakened', 'weakened') and required_strength:
                if 'signal_strength' not in disqualify_reasons:
                    disqualify_reasons.append('signal_strength')
            is_top_candidate = len(disqualify_reasons) == 0

            is_secondary_candidate = False
            if not is_top_candidate:
                reasons_for_secondary = [r.split(':', 1)[0] for r in disqualify_reasons]
                if all(reason in secondary_allowed_reasons for reason in reasons_for_secondary) and len(disqualify_reasons) <= secondary_max_failures:
                    cond_strength = (signal_strength in secondary_allowed_strength)
                    cond_pen = True if secondary_max_pen is None or penetration_val is None else penetration_val <= secondary_max_pen
                    cond_gap = True if secondary_max_gap is None or entry_gap_pct is None else entry_gap_pct <= secondary_max_gap
                    cond_age = True if secondary_max_age is None or signal_age_days is None else signal_age_days <= secondary_max_age
                    cond_multi_tf = True if not secondary_required_multi_tf else multi_tf_status in secondary_required_multi_tf
                    if cond_strength and cond_pen and cond_gap and cond_age and cond_multi_tf:
                        is_secondary_candidate = True
            signal_rows.append({
                'symbol': row.symbol,
                'timeframe': row.timeframe,
                'signal_date': row.date,
                'direction': direction,
                'entry': round(entry_level, 2),
                'stop_loss': round(stop_loss, 2),
                'target': round(target, 2),
                'risk_per_unit': round(risk, 2),
                'risk_reward': risk_reward,
                'width_profile': width_profile,
                'virgin_distance': getattr(row, 'virgin_distance', None),
                'context': getattr(row, 'context', ''),
                'action_plan': getattr(row, 'action_plan', ''),
                'next_period_label': getattr(row, 'next_period_label', None),
                'next_period_low': getattr(row, 'next_period_low', None),
                'next_period_high': getattr(row, 'next_period_high', None),
                'current_price': current_price,
                'price_position': price_position,
                'entry_gap_pct': entry_gap_pct,
                'signal_status': signal_status,
                'volume_ratio': volume_ratio,
                'avg_volume': avg_volume,
                'volume_status': volume_status,
                'touch_type': touch_type,
                'touch_severity': getattr(row, 'touch_severity', None),
                'penetration_pct': getattr(row, 'penetration_pct', None),
                'close_distance_pct': getattr(row, 'close_distance_pct', None),
                'virgin_side': getattr(row, 'virgin_side', None),
                'multi_tf_status': multi_tf_status,
                'signal_strength': signal_strength,
                'gap_type': gap_type,
                'gap_size': getattr(row, 'gap_size', None),
                'gap_magnitude_pct': getattr(row, 'gap_magnitude_pct', None),
                'signal_age_days': signal_age_days,
                'is_top_candidate': is_top_candidate,
                'is_second_tier_candidate': is_secondary_candidate,
                'disqualify_reasons': ';'.join(disqualify_reasons)
            })
        if not signal_rows:
            return pd.DataFrame()
        signals_df = pd.DataFrame(signal_rows)
        signals_df['signal_date'] = pd.to_datetime(signals_df['signal_date'])
        signals_df = signals_df.sort_values(['signal_date', 'symbol', 'timeframe'])
        return signals_df

    def export_signals_to_csv(
        self,
        results: Dict[str, Dict[str, Dict[str, Any]]],
        output_path: Optional[str] = None,
        **kwargs
    ) -> Optional[Path]:
        df = self.generate_signal_dataframe(results, **kwargs)
        if df.empty:
            logger.warning("No high-potential signals found for CSV export.")
            return None
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M")
            output_path = f"reports/cpr_signals_{timestamp}.csv"
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False)
        logger.info(f"Exported CPR signals to {output_path}")
        return output_path

    def generate_short_straddle_candidates(
        self,
        results: Dict[str, Dict[str, Dict[str, Any]]],
        width_pct_bounds: Tuple[float, float] = (0.2, 0.9),
        allowed_bias: Optional[List[str]] = None,
        max_virgin_distance: float = 2.5,
        buffer_multiplier: float = 1.6,
        min_buffer_pct: float = 0.6,
        target_profit_pct: float = 40.0,
        max_hold_days: int = 35,
        top_straddle_config: Optional[Dict[str, Any]] = None,
        secondary_straddle_config: Optional[Dict[str, Any]] = None
    ) -> pd.DataFrame:
        base_df = self.results_to_dataframe(results)
        if base_df.empty:
            return pd.DataFrame()
        weekly = base_df[base_df['timeframe'].str.lower() == 'week'].copy()
        if weekly.empty:
            return weekly
        width_min, width_max = width_pct_bounds
        weekly['width_pct_abs'] = weekly['width_pct'].abs()
        weekly = weekly[
            weekly['width_pct_abs'].between(width_min, width_max) &
            (~weekly['virgin'])
        ]
        if allowed_bias:
            bias_filters = {b.lower() for b in allowed_bias}
            weekly = weekly[weekly['bias'].str.lower().isin(bias_filters)]
        else:
            weekly = weekly[weekly['bias'].str.lower().isin(['balanced', 'range_bias'])]
        weekly = weekly[weekly['virgin_distance'].fillna(0) <= max_virgin_distance]
        if weekly.empty:
            return weekly
        weekly['range_low'] = weekly['next_period_low']
        weekly['range_high'] = weekly['next_period_high']
        weekly['width_points'] = (weekly['tc'] - weekly['bc']).abs()

        def _compute_buffers(row):
            width_points = row['width_points']
            base_buffer = width_points * buffer_multiplier
            min_buffer = abs(row['pivot']) * (min_buffer_pct / 100.0)
            buffer_points = max(base_buffer, min_buffer, 0.5)
            upper_defense = row['tc'] + buffer_points
            lower_defense = row['bc'] - buffer_points
            return round(buffer_points, 2), round(upper_defense, 2), round(lower_defense, 2)

        weekly[['buffer_points', 'upper_defense', 'lower_defense']] = weekly.apply(
            lambda r: pd.Series(_compute_buffers(r)), axis=1
        )
        weekly['suggested_call_strike'] = weekly['pivot'].round(2)
        weekly['suggested_put_strike'] = weekly['pivot'].round(2)
        weekly['target_profit_pct'] = target_profit_pct
        weekly['max_hold_days'] = max_hold_days
        weekly['management_notes'] = (
            "Delta hedge optional; exit on weekly close outside defense or after hold window."
        )

        cfg = {
            'allowed_touch_types': ['virgin'],
            'max_width_pct_abs': 1.0,
            'disallow_volume_status': ['weak'],
            'disallow_multi_tf': ['weakened'],
            'disallow_gap_types': ['gap_cross', 'gap_up_cross', 'gap_down_cross'],
            'min_buffer_points': 0.1,
            'require_defense_order': True,
            'require_range': True,
            'max_penetration_pct': 25.0,
            'min_close_distance_pct': 0.1,
            'max_age_days': 14
        }
        if top_straddle_config:
            cfg.update(top_straddle_config)

        nested_secondary_cfg = None
        if isinstance(top_straddle_config, dict) and 'secondary' in top_straddle_config:
            nested_secondary_cfg = top_straddle_config.get('secondary')
 
        allowed_touch_types = cfg.get('allowed_touch_types')
        max_width_pct_abs = cfg.get('max_width_pct_abs')
        disallow_volume_status = cfg.get('disallow_volume_status') or []
        disallow_multi_tf = cfg.get('disallow_multi_tf') or []
        disallow_gap_types = cfg.get('disallow_gap_types') or []
        min_buffer_points = cfg.get('min_buffer_points')
        require_defense_order = cfg.get('require_defense_order', True)
        require_range = cfg.get('require_range', True)
        max_penetration_pct = cfg.get('max_penetration_pct')
        min_close_distance_pct = cfg.get('min_close_distance_pct')
        max_age_days = cfg.get('max_age_days')

        secondary_cfg = {
            'allowed_touch_types': ['virgin', 'wick_touch'],
            'max_width_pct_abs': 1.2,
            'disallow_volume_status': ['weak'],
            'disallow_multi_tf': ['weakened'],
            'disallow_gap_types': ['gap_cross', 'gap_up_cross', 'gap_down_cross'],
            'min_buffer_points': 0.05,
            'require_defense_order': True,
            'require_range': True,
            'max_penetration_pct': 60.0,
            'min_close_distance_pct': 0.05,
            'max_age_days': 28,
            'allowed_failure_reasons': ['touch_type', 'penetration', 'close_distance', 'age', 'width'],
            'max_failure_count': 2
        }
        if nested_secondary_cfg:
            secondary_cfg.update(nested_secondary_cfg)
        if secondary_straddle_config:
            secondary_cfg.update(secondary_straddle_config)

        def evaluate_row(row: pd.Series) -> Tuple[bool, List[str]]:
            reasons: List[str] = []
            touch_type = row.get('touch_type')
            if allowed_touch_types and touch_type not in allowed_touch_types:
                reasons.append('touch_type')
            width_abs = row.get('width_pct_abs')
            if max_width_pct_abs is not None and width_abs is not None and width_abs > max_width_pct_abs:
                reasons.append('width')
            volume_status = row.get('volume_status') or row.get('volume_status', 'unknown')
            if volume_status in disallow_volume_status:
                reasons.append('volume')
            multi_tf = row.get('multi_tf_status')
            if multi_tf in disallow_multi_tf:
                reasons.append('multi_tf')
            gap_type = row.get('gap_type')
            if gap_type in disallow_gap_types:
                reasons.append('gap')
            buffer_pts = row.get('buffer_points')
            if min_buffer_points is not None and (buffer_pts is None or buffer_pts < min_buffer_points):
                reasons.append('buffer')
            if require_defense_order:
                upper = row.get('upper_defense')
                lower = row.get('lower_defense')
                if upper is None or lower is None or lower >= upper:
                    reasons.append('defense_order')
            if require_range:
                rng_low = row.get('range_low')
                rng_high = row.get('range_high')
                if rng_low is None or rng_high is None or rng_low >= rng_high:
                    reasons.append('range')
            penetration_val = row.get('penetration_pct')
            if max_penetration_pct is not None and penetration_val is not None and penetration_val > max_penetration_pct:
                reasons.append('penetration')
            close_dist = row.get('close_distance_pct')
            if min_close_distance_pct is not None and (close_dist is None or close_dist < min_close_distance_pct):
                reasons.append('close_distance')
            age_days = row.get('candidate_age_days')
            if max_age_days is not None and age_days is not None and age_days > max_age_days:
                reasons.append('age')
            return len(reasons) == 0, reasons

        if 'volume_status' not in weekly.columns:
            weekly['volume_status'] = 'unknown'
        else:
            weekly['volume_status'] = weekly['volume_status'].fillna('unknown')
        weekly['candidate_age_days'] = weekly['date'].apply(
            lambda d: ((datetime.now(d.tzinfo) if isinstance(d, pd.Timestamp) and d.tzinfo else datetime.now()) - d).days
            if isinstance(d, (pd.Timestamp, datetime)) else None
        )
        evaluation = weekly.apply(lambda row: evaluate_row(row), axis=1)
        weekly['is_top_straddle'] = evaluation.apply(lambda x: x[0])
        weekly['straddle_disqualify_reasons'] = evaluation.apply(lambda x: ';'.join(x[1]))

        def evaluate_secondary(row: pd.Series) -> bool:
            if row['is_top_straddle']:
                return False
            reasons = row['straddle_disqualify_reasons'].split(';') if row['straddle_disqualify_reasons'] else []
            reasons = [r for r in reasons if r]
            if not reasons:
                return False
            if len(reasons) > secondary_cfg.get('max_failure_count', 2):
                return False
            if not all(reason in (secondary_cfg.get('allowed_failure_reasons') or []) for reason in reasons):
                return False
            touch_type = row.get('touch_type')
            if secondary_cfg.get('allowed_touch_types') and touch_type not in secondary_cfg.get('allowed_touch_types'):
                return False
            width_abs = row.get('width_pct_abs')
            if secondary_cfg.get('max_width_pct_abs') is not None and width_abs is not None and width_abs > secondary_cfg.get('max_width_pct_abs'):
                return False
            penetration_val = row.get('penetration_pct')
            if secondary_cfg.get('max_penetration_pct') is not None and penetration_val is not None and penetration_val > secondary_cfg.get('max_penetration_pct'):
                return False
            close_dist = row.get('close_distance_pct')
            if secondary_cfg.get('min_close_distance_pct') is not None and (close_dist is None or close_dist < secondary_cfg.get('min_close_distance_pct')):
                return False
            age_days = row.get('candidate_age_days')
            if secondary_cfg.get('max_age_days') is not None and age_days is not None and age_days > secondary_cfg.get('max_age_days'):
                return False
            multi_tf = row.get('multi_tf_status')
            if secondary_cfg.get('disallow_multi_tf') and multi_tf in secondary_cfg.get('disallow_multi_tf'):
                return False
            gap_type = row.get('gap_type')
            if secondary_cfg.get('disallow_gap_types') and gap_type in secondary_cfg.get('disallow_gap_types'):
                return False
            return True

        weekly['is_second_tier_straddle'] = weekly.apply(evaluate_secondary, axis=1)

        columns = [
            'symbol',
            'date',
            'pivot',
            'tc',
            'bc',
            'width_pct',
            'width_pct_abs',
            'bias',
            'range_low',
            'range_high',
            'suggested_call_strike',
            'suggested_put_strike',
            'upper_defense',
            'lower_defense',
            'buffer_points',
            'target_profit_pct',
            'max_hold_days',
            'management_notes',
            'context',
            'touch_type',
            'touch_severity',
            'penetration_pct',
            'volume_ratio',
            'volume_status',
            'multi_tf_status',
            'gap_type',
            'gap_size',
            'gap_magnitude_pct',
            'candidate_age_days',
            'is_top_straddle',
            'is_second_tier_straddle',
            'straddle_disqualify_reasons'
        ]
        weekly = weekly[columns].sort_values(['date', 'symbol'], ascending=[False, True])
        return weekly

    def export_short_straddle_candidates(
        self,
        results: Dict[str, Dict[str, Dict[str, Any]]],
        output_path: Optional[Path] = None,
        **kwargs
    ) -> Optional[Path]:
        df = self.generate_short_straddle_candidates(results, **kwargs)
        if df.empty:
            logger.warning("No short straddle candidates identified.")
            return None
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M")
            output_path = f"reports/cpr_short_straddles_{timestamp}.csv"
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False)
        logger.info(f"Exported short straddle candidates to {output_path}")
        return output_path

    def export_analysis_workbook(
        self,
        results: Dict[str, Dict[str, Dict[str, Any]]],
        output_path: Optional[str] = None,
        include_signals: bool = True,
        include_straddles: bool = True,
        signal_kwargs: Optional[Dict[str, Any]] = None,
        straddle_kwargs: Optional[Dict[str, Any]] = None
    ) -> Optional[Path]:
        base_df = self.results_to_dataframe(results)
        signals_df = self.generate_signal_dataframe(results, **(signal_kwargs or {})) if include_signals else pd.DataFrame()
        straddle_df = self.generate_short_straddle_candidates(results, **(straddle_kwargs or {})) if include_straddles else pd.DataFrame()
        if base_df.empty and signals_df.empty and straddle_df.empty:
            logger.warning("No data available to write analysis workbook.")
            return None
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M")
            output_path = f"reports/cpr_analysis_{timestamp}.xlsx"
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
            if not base_df.empty:
                base_df.to_excel(writer, sheet_name="cpr_overview", index=False)
            if include_signals and not signals_df.empty:
                signals_df.to_excel(writer, sheet_name="directional_signals", index=False)
            if include_straddles and not straddle_df.empty:
                straddle_df.to_excel(writer, sheet_name="short_straddles", index=False)
        logger.info(f"Exported CPR analysis workbook to {output_path}")
        return output_path

    @staticmethod
    def _determine_multi_tf_status(results: Dict[str, Dict[str, Dict[str, Any]]], symbol: str, timeframe: str, item: Dict[str, Any]) -> str:
        if timeframe != 'day':
            return 'na'
        weekly_payload = results.get(symbol, {}).get('week')
        if not weekly_payload:
            return 'unknown'
        weekly_rows = weekly_payload.get('all_cprs', [])
        if not weekly_rows:
            return 'unknown'
        target_date = item.get('date')
        try:
            target_ts = pd.to_datetime(target_date) if target_date is not None else None
        except Exception:
            target_ts = None
        candidate = None
        for weekly_item in reversed(weekly_rows):
            candidate_date = weekly_item.get('date')
            try:
                candidate_ts = pd.to_datetime(candidate_date) if candidate_date is not None else None
            except Exception:
                candidate_ts = None
            if target_ts is None or candidate_ts is None:
                continue
            if candidate_ts <= target_ts:
                candidate = weekly_item
                break
        if candidate is None:
            candidate = weekly_rows[-1]
        weekly_virgin = candidate.get('virgin', {}) if isinstance(candidate, dict) else {}
        if weekly_virgin.get('is_virgin'):
            return 'aligned'
        return 'weakened'
    
    def get_historical_data(self, symbol, from_date, to_date, interval):
        try:
            token = self.get_instrument_token(symbol)
            if not token:
                logger.error(f"Symbol {symbol} not found in instrument cache")
                return None
            self.rate_limiter.wait()
            data = self.kite.historical_data(
                instrument_token=token,
                from_date=from_date,
                to_date=to_date,
                interval=interval
            )
            return pd.DataFrame(data)
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {str(e)}")
            return None
    
    def scan_cpr(self, symbol, timeframe='day', lookback_days=10, intraday_interval='15minute'):
        to_date = datetime.now()
        base_df = None
        session_lookup = None
        label_next_period = 'next_period'
        if timeframe == 'minute':
            daily_from = to_date - timedelta(days=lookback_days + 15)
            daily_df = self._normalize_ohlc_df(
                self.get_historical_data(symbol, daily_from, to_date, 'day')
            )
            if daily_df is None or len(daily_df) < 2:
                return None
            daily_df = daily_df.tail(lookback_days + 2)
            base_df = daily_df.reset_index(drop=True)
            first_session_date = pd.to_datetime(base_df.iloc[1]['date'])
            intraday_from = first_session_date.to_pydatetime() - timedelta(days=1)
            intraday_df = self.get_historical_data(symbol, intraday_from, to_date, intraday_interval)
            session_lookup = self._build_intraday_session_map(self._normalize_ohlc_df(intraday_df))
            label_next_period = 'next_session'
        elif timeframe == 'day':
            from_date = to_date - timedelta(days=lookback_days * 2)
            base_df = self._normalize_ohlc_df(
                self.get_historical_data(symbol, from_date, to_date, 'day')
            )
            label_next_period = 'next_day'
        elif timeframe == 'week':
            from_date = to_date - timedelta(days=lookback_days * 14)
            daily_df = self._normalize_ohlc_df(
                self.get_historical_data(symbol, from_date, to_date, 'day')
            )
            weekly_df = self._resample_weekly(daily_df)
            base_df = self._normalize_ohlc_df(weekly_df)
            label_next_period = 'next_week'
        else:
            logger.error(f"Invalid timeframe: {timeframe}")
            return None
        if base_df is None or len(base_df) < 2:
            logger.warning(f"Insufficient data for {symbol} on timeframe {timeframe}")
            return None
        results = []
        base_df = base_df.reset_index(drop=True)

        for i in range(len(base_df) - 1):
            prev_data = base_df.iloc[i]
            cpr = self.calculate_cpr(prev_data['high'], prev_data['low'], prev_data['close'])
            next_data = base_df.iloc[i + 1]

            session_high = next_data['high']
            session_low = next_data['low']
            session_close = next_data.get('close') if isinstance(next_data, pd.Series) else None
            session_volume = next_data.get('volume') if isinstance(next_data, pd.Series) and 'volume' in next_data else None
            session_open = next_data.get('open') if isinstance(next_data, pd.Series) else None

            avg_volume = None
            if 'volume' in base_df.columns:
                start_idx = max(0, i - 19)
                window = base_df.iloc[start_idx:i + 1]
                window_vols = window['volume'].dropna()
                if not window_vols.empty:
                    avg_volume = float(window_vols.mean())

            if timeframe == 'minute':
                session_date = pd.to_datetime(next_data['date']).date()
                intraday_session = session_lookup.get(session_date)
                if intraday_session:
                    session_high = intraday_session['high']
                    session_low = intraday_session['low']
                    session_close = intraday_session.get('close')
                    session_volume = intraday_session.get('volume')
                    session_open = None
                else:
                    session_high = None
                    session_low = None
                    session_close = None
                    session_volume = None

            if session_volume is not None and pd.notna(session_volume):
                session_volume = float(session_volume)
            else:
                session_volume = None
            if avg_volume is not None and pd.notna(avg_volume):
                avg_volume = float(avg_volume)
            else:
                avg_volume = None

            volume_ratio = None
            if session_volume is not None and avg_volume not in (None, 0):
                volume_ratio = float(session_volume / avg_volume) if avg_volume else None

            virgin_status = self.evaluate_virgin_status(
                session_high,
                session_low,
                cpr,
                session_close=session_close,
                session_open=session_open,
                prev_close=prev_data['close'] if 'close' in prev_data else None
            )
            results.append({
                'date': prev_data['date'],
                'timeframe': timeframe,
                'symbol': symbol,
                'cpr': cpr,
                'virgin': virgin_status,
                'next_period_high': round(session_high, 2) if session_high is not None else None,
                'next_period_low': round(session_low, 2) if session_low is not None else None,
                'next_period_close': round(session_close, 2) if session_close is not None else None,
                'next_period_open': round(session_open, 2) if session_open is not None else None,
                'next_period_volume': session_volume,
                'avg_volume_lookback': avg_volume,
                'volume_ratio': volume_ratio,
                'prev_close': round(prev_data['close'], 2) if 'close' in prev_data else None,
                'next_period_label': label_next_period
            })
        
        return results
    
    def scan_multiple_symbols(
        self,
        symbols: Optional[List[str]] = None,
        timeframes: Optional[List[str]] = None,
        csv_path: Optional[str] = None,
        symbol_column: str = 'symbol'
    ):
        if timeframes is None:
            timeframes = ['day', 'week']
        collected_symbols: List[str] = []
        if symbols:
            collected_symbols.extend([str(sym).strip().upper() for sym in symbols if str(sym).strip()])
        if csv_path:
            collected_symbols.extend(self.load_symbols_from_csv(csv_path, symbol_column=symbol_column))
        deduped_symbols = list(dict.fromkeys(collected_symbols))
        if not deduped_symbols:
            logger.error("No symbols provided for scanning.")
            return {}
        self.ensure_instrument_cache()
        all_results: Dict[str, Dict[str, Any]] = {}
        for symbol in deduped_symbols:
            logger.info(f"Scanning {symbol}...")
            all_results[symbol] = {}
            for tf in timeframes:
                logger.info(f"  Timeframe: {tf}")
                results = self.scan_cpr(symbol, timeframe=tf)
                
                if results:
                    width_history = [r['cpr'].get('width_pct') for r in results if r['cpr'].get('width_pct') is not None]
                    thresholds = None
                    if len(width_history) >= 30:
                        thresholds = {
                            'ultra': float(np.percentile(width_history, 10)),
                            'narrow': float(np.percentile(width_history, 25)),
                            'wide': float(np.percentile(width_history, 75))
                        }
                    else:
                        thresholds = {
                            'ultra': 0.25,
                            'narrow': 0.45,
                            'wide': 0.8
                        }
                    # Filter only Virgin CPRs for reporting
                    virgin_cprs = [r for r in results if r['virgin']['is_virgin']]
                    all_results[symbol][tf] = {
                        'all_cprs': results,
                        'virgin_cprs': virgin_cprs,
                        'virgin_count': len(virgin_cprs),
                        'width_thresholds': thresholds,
                        'width_history_count': len(width_history)
                    }
        
        return all_results
    
    def print_report(self, results):
        print("\n" + "=" * 80)
        print("CPR & VIRGIN CPR SCANNER REPORT")
        print("=" * 80)
        for symbol, timeframe_data in results.items():
            print(f"\n{'=' * 80}")
            print(f"SYMBOL: {symbol}")
            print(f"{'=' * 80}")
            for tf, data in timeframe_data.items():
                print(f"\n  Timeframe: {tf.upper()}")
                print(f"  Total Virgin CPRs found: {data['virgin_count']}")
                print(f"  {'-' * 76}")
                if data['virgin_count'] > 0:
                    for vcpr in data['virgin_cprs'][-3:]:
                        print(f"\n  Date: {vcpr['date']}")
                        print(f"  CPR Levels -> TC: {vcpr['cpr']['tc']} | Pivot: {vcpr['cpr']['pivot']} | BC: {vcpr['cpr']['bc']}")
                        print(f"  CPR Width: {vcpr['cpr']['width']} ({vcpr['cpr']['width_pct']}%)")
                        v_type = vcpr['virgin']['type']
                        print(f"  Virgin Type: {v_type.upper() if v_type else 'UNKNOWN'}")
                        potential = vcpr['virgin'].get('potential')
                        if potential:
                            print(f"  Potential Role: {potential.upper()}")
                        distance = vcpr['virgin'].get('distance')
                        if distance is not None:
                            print(f"  Distance from CPR: {distance} points")
                        reason = vcpr['virgin'].get('reason')
                        if reason:
                            print(f"  Notes: {reason}")
                        touch_detail = vcpr['virgin'].get('touch_type')
                        if touch_detail and touch_detail not in ('virgin', 'missing_data'):
                            severity = vcpr['virgin'].get('touch_severity')
                            penetration = vcpr['virgin'].get('penetration_pct')
                            print(f"  Touch Detail: {touch_detail.upper()} | Severity: {severity or 'N/A'} | Penetration: {penetration if penetration is not None else 'N/A'}%")
                        if vcpr['next_period_high'] is not None:
                            low = vcpr['next_period_low']
                            high = vcpr['next_period_high']
                            label = vcpr.get('next_period_label', 'next period').replace('_', ' ')
                            print(f"  {label.title()} Range: {low} - {high}")
                else:
                    print("  No Virgin CPRs found in recent history")
        print(f"\n{'=' * 80}\n")
    
    def get_current_cpr_levels(self, symbol, timeframe='day'):
        to_date = datetime.now()
        if timeframe == 'day':
            from_date = to_date - timedelta(days=5)
            data_df = self._normalize_ohlc_df(
                self.get_historical_data(symbol, from_date, to_date, 'day')
            )
        elif timeframe == 'week':
            from_date = to_date - timedelta(days=150)
            daily_df = self._normalize_ohlc_df(
                self.get_historical_data(symbol, from_date, to_date, 'day')
            )
            data_df = self._normalize_ohlc_df(self._resample_weekly(daily_df))
        else:
            return None
        if data_df is None or len(data_df) < 1:
            return None
        prev_data = data_df.iloc[-2] if len(data_df) > 1 else data_df.iloc[-1]
        cpr = self.calculate_cpr(prev_data['high'], prev_data['low'], prev_data['close'])
        return {
            'symbol': symbol,
            'timeframe': timeframe,
            'date': prev_data['date'],
            'cpr_levels': cpr
        }

    def export_intraday_opportunities(
        self,
        symbols: List[str],
        intraday_interval: str = '15minute',
        max_entry_gap_pct: float = 0.75,
        min_bars: int = 4,
        risk_reward: float = 2.0,
        output_path: Optional[Path] = None
    ) -> Optional[Path]:
        df = self.generate_intraday_opportunities(
            symbols,
            intraday_interval=intraday_interval,
            max_entry_gap_pct=max_entry_gap_pct,
            min_bars=min_bars,
            risk_reward=risk_reward
        )
        if df.empty:
            logger.warning("No intraday CPR opportunities identified.")
            return None
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M")
            output_path = f"reports/cpr_intraday_{timestamp}.csv"
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(output_path, index=False)
        logger.info(f"Exported intraday CPR opportunities to {output_path}")
        return output_path

    def generate_intraday_opportunities(
        self,
        symbols: List[str],
        intraday_interval: str = '15minute',
        max_entry_gap_pct: float = 0.75,
        min_bars: int = 4,
        risk_reward: float = 2.0
    ) -> pd.DataFrame:
        rows: List[dict] = []
        now = datetime.now()
        today_date = now.date()
        start_of_day = datetime.combine(today_date, dtime.min)
        for symbol in symbols:
            try:
                daily_from = now - timedelta(days=10)
                daily_df = self._normalize_ohlc_df(
                    self.get_historical_data(symbol, daily_from, now, 'day')
                )
                if daily_df is None or len(daily_df) < 2:
                    continue
                daily_df['date'] = pd.to_datetime(daily_df['date'])
                last_daily = daily_df.iloc[-1]
                last_daily_date = last_daily['date'].date()
                if last_daily_date == today_date and len(daily_df) >= 2:
                    prev_daily = daily_df.iloc[-2]
                else:
                    prev_daily = last_daily
                cpr = self.calculate_cpr(prev_daily['high'], prev_daily['low'], prev_daily['close'])
                prev_close = prev_daily['close']
 
                intraday_df = self._normalize_ohlc_df(
                    self.get_historical_data(symbol, start_of_day, now, intraday_interval)
                )
                if intraday_df is None or len(intraday_df) < min_bars:
                    continue
                session_high = intraday_df['high'].max()
                session_low = intraday_df['low'].min()
                session_open = intraday_df.iloc[0]['open']
                latest = intraday_df.iloc[-1]
                last_close = latest['close']
 
                status = self.evaluate_virgin_status(
                    session_high,
                    session_low,
                    cpr,
                    session_close=last_close,
                    session_open=session_open,
                    prev_close=prev_close
                )
                if not status.get('is_virgin', False):
                    continue
                side = status.get('virgin_side')
                if side not in ('above', 'below'):
                    continue
                cpr_upper = max(cpr['tc'], cpr['bc'])
                cpr_lower = min(cpr['tc'], cpr['bc'])
                if side == 'above':
                    entry = cpr_upper
                    stop = cpr_lower
                    direction = 'long'
                else:
                    entry = cpr_lower
                    stop = cpr_upper
                    direction = 'short'
                risk_per_unit = abs(entry - stop)
                if risk_per_unit <= 0:
                    continue
                target = entry + risk_reward * risk_per_unit if direction == 'long' else entry - risk_reward * risk_per_unit
                entry_gap_pct = abs(last_close - entry) / entry * 100
                if max_entry_gap_pct is not None and entry_gap_pct > max_entry_gap_pct:
                    continue
 
                rows.append({
                    'symbol': symbol,
                    'direction': direction,
                    'entry': round(entry, 2),
                    'stop_loss': round(stop, 2),
                    'target': round(target, 2),
                    'risk_per_unit': round(risk_per_unit, 2),
                    'risk_reward': risk_reward,
                    'width_profile': self._classify_cpr_width(cpr.get('width_pct')),
                    'virgin_status': status.get('touch_type'),
                    'virgin_side': side,
                    'distance': status.get('distance'),
                    'penetration_pct': status.get('penetration_pct'),
                    'gap_type': status.get('gap_type'),
                    'gap_size': status.get('gap_size'),
                    'gap_magnitude_pct': status.get('gap_magnitude_pct'),
                    'session_high': round(session_high, 2),
                    'session_low': round(session_low, 2),
                    'session_open': round(session_open, 2),
                    'latest_close': round(last_close, 2),
                    'entry_gap_pct': round(entry_gap_pct, 3),
                    'intraday_bars': len(intraday_df),
                    'signal_time': latest['date'],
                    'holding_plan': 'EOD_or_Next_Day',
                    'volume_total': intraday_df['volume'].sum() if 'volume' in intraday_df else None
                })
            except Exception as exc:
                logger.warning(f"Failed to compute intraday opportunity for {symbol}: {exc}")
        if not rows:
            return pd.DataFrame()
        df = pd.DataFrame(rows)
        df['signal_time'] = pd.to_datetime(df['signal_time'])
        df = df.sort_values(['signal_time', 'symbol'])
        return df


# Example usage
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="CPR & Virgin CPR Scanner")
    parser.add_argument('--symbols', nargs='*', help='Override default symbol list')
    parser.add_argument('--csv-path', default="data/sector_marketcap_great8000.csv", help='Optional CSV path for symbols')
    parser.add_argument('--symbol-column', default='Symbol', help='Column name in CSV for symbols')
    parser.add_argument('--timeframes', nargs='*', default=['day', 'week'], help='Timeframes to scan')
    parser.add_argument('--intraday', action='store_true', help='Generate intraday CPR opportunities')
    parser.add_argument('--intraday-only', action='store_true', help='Only generate intraday opportunities')
    parser.add_argument('--intraday-interval', default='15minute', help='Intraday interval for live checks')
    parser.add_argument('--intraday-max-gap', type=float, default=0.75, help='Max entry gap pct for intraday candidates')
    parser.add_argument('--intraday-min-bars', type=int, default=4, help='Minimum intraday bars required')
    parser.add_argument('--intraday-output', default=None, help='Custom path for intraday CSV output')
    parser.add_argument('--intraday-symbols', nargs='*', help='Symbols to use specifically for intraday scan')
    parser.add_argument('--min-volume-ratio', type=float, default=0.8, help='Minimum volume ratio for directional signals')
    args = parser.parse_args()

    # IMPORTANT: Replace with your actual credentials
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "DjCrYzyLSl4CW7W5gNWGEUvfvY7BmnUa"

    scanner = CPRScanner(API_KEY, ACCESS_TOKEN)

    symbols = args.symbols if args.symbols else ['NIFTY 50', 'BANKNIFTY']
    csv_path = args.csv_path
    symbol_column = args.symbol_column
    timeframes = args.timeframes or ['day', 'week']

    top_candidate_config = {
        'required_signal_strength': ['primary'],
        'max_penetration_pct': 25.0,
        'max_entry_gap_pct': 0.75,
        'required_multi_tf': ['aligned'],
        'disallow_volume_status': ['weak'],
        'disallow_gap_types': ['gap_cross', 'gap_up_cross', 'gap_down_cross'],
        'max_age_days': 3
    }
    secondary_candidate_config = {
        'allowed_signal_strength': ['primary', 'soft'],
        'max_penetration_pct': 60.0,
        'max_entry_gap_pct': 1.5,
        'max_age_days': 7,
        'allowed_failure_reasons': ['signal_strength', 'entry_gap', 'penetration', 'age', 'multi_tf'],
        'max_failure_count': 2,
        'required_multi_tf': ['aligned', 'weakened']
    }
    top_straddle_config = {
        'allowed_touch_types': ['virgin', 'wick_touch'],
        'max_width_pct_abs': 1.0,
        'disallow_volume_status': ['weak'],
        'disallow_multi_tf': ['weakened'],
        'disallow_gap_types': ['gap_cross', 'gap_up_cross', 'gap_down_cross'],
        'min_buffer_points': 0.1,
        'require_defense_order': True,
        'require_range': True,
        'max_penetration_pct': 25.0,
        'min_close_distance_pct': 0.1,
        'max_age_days': 14
    }
    secondary_straddle_config = {
        'allowed_touch_types': ['virgin', 'wick_touch'],
        'max_width_pct_abs': 1.2,
        'max_penetration_pct': 60.0,
        'min_close_distance_pct': 0.05,
        'max_age_days': 28,
        'allowed_failure_reasons': ['touch_type', 'penetration', 'close_distance', 'age', 'width'],
        'max_failure_count': 2
    }

    run_intraday = args.intraday or args.intraday_only
    intraday_symbols = args.intraday_symbols if args.intraday_symbols else symbols

    results = {}
    if not args.intraday_only:
        print("Starting CPR Scanner...")
        results = scanner.scan_multiple_symbols(
            symbols=symbols,
            timeframes=timeframes,
            csv_path=csv_path if csv_path and Path(csv_path).exists() else None,
            symbol_column=symbol_column
        )

        scanner.print_report(results)

        export_path = scanner.export_results_to_csv(results)
        if export_path:
            print(f"\nCSV report saved to: {export_path}")

        signals_path = scanner.export_signals_to_csv(
            results,
            min_volume_ratio=args.min_volume_ratio,
            top_candidate_config=top_candidate_config,
            secondary_candidate_config=secondary_candidate_config
        )
        if signals_path:
            print(f"Signal CSV saved to: {signals_path}")

        straddle_path = scanner.export_short_straddle_candidates(
            results,
            top_straddle_config=top_straddle_config,
            secondary_straddle_config=secondary_straddle_config
        )
        if straddle_path:
            print(f"Short straddle CSV saved to: {straddle_path}")

        analysis_path = scanner.export_analysis_workbook(
            results,
            signal_kwargs={
                'min_volume_ratio': args.min_volume_ratio,
                'top_candidate_config': top_candidate_config,
                'secondary_candidate_config': secondary_candidate_config
            },
            straddle_kwargs={
                'top_straddle_config': top_straddle_config,
                'secondary_straddle_config': secondary_straddle_config
            }
        )
        if analysis_path:
            print(f"Analysis workbook saved to: {analysis_path}")

        print("\nCURRENT CPR LEVELS FOR TODAY:")
        print("=" * 80)
        for symbol in symbols:
            current_cpr = scanner.get_current_cpr_levels(symbol, timeframe='day')
            if current_cpr:
                print(f"\n{symbol}:")
                print(f"  TC: {current_cpr['cpr_levels']['tc']}")
                print(f"  Pivot: {current_cpr['cpr_levels']['pivot']}")
                print(f"  BC: {current_cpr['cpr_levels']['bc']}")
                print(f"  Width: {current_cpr['cpr_levels']['width']} ({current_cpr['cpr_levels']['width_pct']}%)")

    if run_intraday:
        intraday_path = scanner.export_intraday_opportunities(
            intraday_symbols,
            intraday_interval=args.intraday_interval,
            max_entry_gap_pct=args.intraday_max_gap,
            min_bars=args.intraday_min_bars,
            output_path=args.intraday_output
        )
        if intraday_path:
            print(f"Intraday opportunities saved to: {intraday_path}")

    if args.intraday_only and not run_intraday:
        print("No intraday output generated; use --intraday flag.")