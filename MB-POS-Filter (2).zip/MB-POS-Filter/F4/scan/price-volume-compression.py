"""
Squeeze/Compression Pattern Scanner for NSE Stocks
Uses Kite Connect API with rate limiting and intelligent caching
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
import time
import json
import os
from typing import Dict, List, Tuple
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class SqueezeScanner:
    """
    Advanced scanner for detecting compression/squeeze patterns in stocks
    """
    
    def __init__(self, api_key: str, access_token: str, debug: bool = False):
        """
        Initialize scanner with Kite Connect credentials
        
        Args:
            api_key: Kite Connect API key
            access_token: Access token for session
            debug: Enable debug logging
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Set logging level
        if debug:
            logger.setLevel(logging.DEBUG)
        
        # Rate limiting parameters
        self.requests_per_second = 3  # Kite allows 3 requests/sec for historical data
        self.last_request_time = 0
        
        # Cache for instruments
        self.instruments_cache = None
        self.cache_file = 'nse_instruments_cache.json'
        self.cache_expiry_hours = 24
        
    def _rate_limit(self):
        """Implement rate limiting to respect API limits"""
        current_time = time.time()
        time_since_last_request = current_time - self.last_request_time
        min_interval = 1.0 / self.requests_per_second
        
        if time_since_last_request < min_interval:
            sleep_time = min_interval - time_since_last_request
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def _load_instruments_cache(self) -> bool:
        """Load NSE instruments from cache if valid"""
        try:
            if os.path.exists(self.cache_file):
                cache_time = datetime.fromtimestamp(os.path.getmtime(self.cache_file))
                if datetime.now() - cache_time < timedelta(hours=self.cache_expiry_hours):
                    with open(self.cache_file, 'r') as f:
                        self.instruments_cache = json.load(f)
                    logger.info(f"Loaded {len(self.instruments_cache)} instruments from cache")
                    return True
        except Exception as e:
            logger.warning(f"Cache load failed: {e}")
        return False
    
    def _save_instruments_cache(self):
        """Save instruments to cache"""
        try:
            with open(self.cache_file, 'w') as f:
                json.dump(self.instruments_cache, f)
            logger.info("Instruments cache saved")
        except Exception as e:
            logger.error(f"Cache save failed: {e}")
    
    def load_instruments(self):
        """Load NSE instruments with caching"""
        if self._load_instruments_cache():
            return
        
        logger.info("Fetching instruments from Kite Connect...")
        instruments = self.kite.instruments("NSE")
        
        # Create lookup dictionary
        self.instruments_cache = {}
        for inst in instruments:
            if inst['segment'] == 'NSE' and inst['instrument_type'] == 'EQ':
                self.instruments_cache[inst['tradingsymbol']] = {
                    'instrument_token': inst['instrument_token'],
                    'name': inst['name'],
                    'exchange': inst['exchange']
                }
        
        self._save_instruments_cache()
        logger.info(f"Loaded {len(self.instruments_cache)} NSE equity instruments")
    
    def get_historical_data(self, symbol: str, days: int = 45) -> pd.DataFrame:
        """
        Fetch historical data for a symbol
        
        Args:
            symbol: Trading symbol
            days: Number of days of historical data
            
        Returns:
            DataFrame with OHLCV data
        """
        if symbol not in self.instruments_cache:
            logger.warning(f"  ⚠️ Symbol {symbol} not found in instruments cache")
            # Try to find similar symbols
            similar = [s for s in self.instruments_cache.keys() if symbol.upper() in s.upper()]
            if similar:
                logger.info(f"  💡 Similar symbols found: {', '.join(similar[:5])}")
            return None
        
        instrument_token = self.instruments_cache[symbol]['instrument_token']
        to_date = datetime.now()
        from_date = to_date - timedelta(days=days)
        
        self._rate_limit()
        
        try:
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval='day'
            )
            
            if not data:
                logger.debug(f"  ⚠️ API returned empty data for {symbol}")
                return None
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date'])
                df = df.sort_values('date')
            return df
            
        except Exception as e:
            logger.error(f"  ❌ API error for {symbol}: {e}")
            return None
    
    def calculate_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate technical indicators"""
        if df is None or df.empty:
            return None
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # Bollinger Bands
        df['sma_20'] = df['close'].rolling(window=20).mean()
        df['std_20'] = df['close'].rolling(window=20).std()
        df['bb_upper'] = df['sma_20'] + (df['std_20'] * 2)
        df['bb_lower'] = df['sma_20'] - (df['std_20'] * 2)
        df['bb_width'] = ((df['bb_upper'] - df['bb_lower']) / df['sma_20']) * 100
        
        # ATR for volatility
        df['tr'] = np.maximum(
            df['high'] - df['low'],
            np.maximum(
                abs(df['high'] - df['close'].shift(1)),
                abs(df['low'] - df['close'].shift(1))
            )
        )
        df['atr'] = df['tr'].rolling(window=14).mean()
        
        # Volume moving average
        df['volume_ma_20'] = df['volume'].rolling(window=20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_ma_20']
        
        # ADX calculation
        df['plus_dm'] = np.where(
            (df['high'] - df['high'].shift(1)) > (df['low'].shift(1) - df['low']),
            np.maximum(df['high'] - df['high'].shift(1), 0),
            0
        )
        df['minus_dm'] = np.where(
            (df['low'].shift(1) - df['low']) > (df['high'] - df['high'].shift(1)),
            np.maximum(df['low'].shift(1) - df['low'], 0),
            0
        )
        
        df['plus_di'] = 100 * (df['plus_dm'].rolling(window=14).mean() / df['atr'])
        df['minus_di'] = 100 * (df['minus_dm'].rolling(window=14).mean() / df['atr'])
        df['dx'] = 100 * abs(df['plus_di'] - df['minus_di']) / (df['plus_di'] + df['minus_di'])
        df['adx'] = df['dx'].rolling(window=14).mean()
        
        return df
    
    def analyze_squeeze(self, df: pd.DataFrame, symbol: str) -> Dict:
        """
        Analyze if stock is in a squeeze/compression pattern
        
        Returns:
            Dictionary with analysis results
        """
        if df is None or len(df) < 20:
            logger.debug(f"  ⚠️ Insufficient data for analysis: {len(df) if df is not None else 0} rows")
            return None
        
        try:
            # Get last N days for analysis
            recent_5 = df.tail(5)
            recent_10 = df.tail(10)
            recent_20 = df.tail(20)
            last_row = df.iloc[-1]
            
            # Check for NaN values in critical columns
            critical_cols = ['close', 'high', 'low', 'volume', 'rsi', 'bb_width', 'adx']
            if last_row[critical_cols].isna().any():
                logger.debug(f"  ⚠️ NaN values in critical columns for {symbol}")
                return None
            
            # Calculate metrics
            range_5d = ((recent_5['high'].max() - recent_5['low'].min()) / recent_5['close'].mean()) * 100
            range_10d = ((recent_10['high'].max() - recent_10['low'].min()) / recent_10['close'].mean()) * 100
            
            # Volume analysis
            avg_volume_5d = recent_5['volume'].mean()
            avg_volume_20d = recent_20['volume'].mean()
            volume_dryup_ratio = (avg_volume_5d / avg_volume_20d) * 100 if avg_volume_20d > 0 else 100
            
            # Volume trend (declining?)
            volume_values = recent_5['volume'].values
            volume_declining = False
            if len(volume_values) >= 2:
                volume_declining = all(volume_values[i] <= volume_values[i-1] * 1.2 
                                      for i in range(1, len(volume_values)))
            
            # Bollinger Band squeeze
            bb_width_current = last_row['bb_width']
            bb_width_20d_avg = recent_20['bb_width'].mean()
            bb_squeeze = bb_width_current < bb_width_20d_avg * 0.8
            bb_width_min_20d = recent_20['bb_width'].min()
            is_narrowest_bb = abs(bb_width_current - bb_width_min_20d) < 0.01
            
            # RSI in neutral zone
            rsi_value = float(last_row['rsi'])
            rsi_neutral = 45 <= rsi_value <= 55
            
            # ADX (contraction)
            adx_value = float(last_row['adx'])
            adx_low = adx_value < 20
            
            # Check for large down days
            recent_5_copy = recent_5.copy()
            recent_5_copy['daily_change_pct'] = ((recent_5_copy['close'] - recent_5_copy['open']) / recent_5_copy['open']) * 100
            max_down_day = recent_5_copy['daily_change_pct'].min()
            no_major_down = max_down_day > -3
            
            # Price pattern - higher lows or flat support
            lows_5d = recent_5['low'].values
            higher_lows = False
            if len(lows_5d) >= 2:
                higher_lows = all(lows_5d[i] >= lows_5d[i-1] * 0.98 for i in range(1, len(lows_5d)))
            
            # Consolidation duration
            consolidation_days = 0
            threshold = range_10d / 100 * float(last_row['close'])
            for i in range(len(df) - 1, max(len(df) - 25, 0), -1):
                if abs(df.iloc[i]['close'] - last_row['close']) <= threshold:
                    consolidation_days += 1
                else:
                    break
            
            # Distance from recent high/low
            recent_high_20d = recent_20['high'].max()
            recent_low_20d = recent_20['low'].min()
            distance_from_high = ((recent_high_20d - last_row['close']) / recent_high_20d) * 100
            distance_from_low = ((last_row['close'] - recent_low_20d) / recent_low_20d) * 100
            
            # Scoring system (0-100)
            score = 0
            notes = []
            
            # Range compression (25 points max)
            if range_5d < 3:
                score += 15
                notes.append("🔥 Extreme 5d compression (<3%)")
            elif range_5d < 5:
                score += 12
                notes.append("✓ Strong 5d compression (<5%)")
            elif range_5d < 8:
                score += 8
                notes.append("~ Moderate 5d compression (<8%)")
            
            if range_10d < 8:
                score += 10
                notes.append("✓ 10d range tight (<8%)")
            elif range_10d < 10:
                score += 6
            
            # Volume dry-up (20 points max)
            if volume_dryup_ratio < 40:
                score += 15
                notes.append("🔥 Severe volume dry-up (<40%)")
            elif volume_dryup_ratio < 60:
                score += 12
                notes.append("✓ Strong volume dry-up (<60%)")
            elif volume_dryup_ratio < 80:
                score += 6
                notes.append("~ Volume declining (<80%)")
            
            if volume_declining:
                score += 5
                notes.append("✓ Declining volume trend")
            
            # Bollinger squeeze (15 points max)
            if is_narrowest_bb:
                score += 10
                notes.append("🔥 BB at 20d narrowest point")
            elif bb_squeeze:
                score += 7
                notes.append("✓ BB squeeze active")
            
            # RSI neutral (10 points max)
            if rsi_neutral:
                score += 10
                notes.append("✓ RSI neutral zone (45-55)")
            elif 40 <= rsi_value <= 60:
                score += 5
                notes.append("~ RSI near neutral (40-60)")
            
            # ADX low (10 points max)
            if adx_value < 15:
                score += 10
                notes.append("✓ ADX very low (<15) - no trend")
            elif adx_low:
                score += 6
                notes.append("~ ADX low (<20)")
            
            # No major down day (10 points)
            if no_major_down:
                score += 10
                notes.append("✓ No panic selling last 5d")
            else:
                notes.append(f"⚠ Large down day: {max_down_day:.1f}%")
            
            # Price pattern (10 points)
            if higher_lows:
                score += 10
                notes.append("✓ Higher lows pattern (accumulation)")
            
            # Consolidation duration (bonus/penalty)
            if 5 <= consolidation_days <= 15:
                score += 5
                notes.append(f"✓ Ideal consolidation: {consolidation_days}d")
            elif consolidation_days > 20:
                notes.append(f"⚠ Long consolidation: {consolidation_days}d")
            
            # Context scoring
            if 10 < distance_from_high < 30:
                notes.append(f"📍 Pullback setup: {distance_from_high:.1f}% from 20d high")
            elif distance_from_high > 30:
                notes.append(f"📍 Oversold: {distance_from_high:.1f}% from 20d high")
            
            # Final verdict
            if score >= 75:
                verdict = "🚀 PRIME SETUP"
            elif score >= 60:
                verdict = "✅ STRONG SETUP"
            elif score >= 45:
                verdict = "⚡ MODERATE SETUP"
            elif score >= 30:
                verdict = "👀 WATCH"
            else:
                verdict = "❌ NO SETUP"
            
            notes.insert(0, verdict)
            
            return {
                'symbol': symbol,
                'date': last_row['date'].strftime('%Y-%m-%d'),
                'close': round(float(last_row['close']), 2),
                'range_5d_pct': round(float(range_5d), 2),
                'range_10d_pct': round(float(range_10d), 2),
                'volume_dryup_pct': round(float(volume_dryup_ratio), 1),
                'volume_5d_avg': int(avg_volume_5d),
                'volume_20d_avg': int(avg_volume_20d),
                'bb_width': round(float(bb_width_current), 2),
                'bb_width_20d_avg': round(float(bb_width_20d_avg), 2),
                'bb_narrowest': bool(is_narrowest_bb),
                'rsi': round(float(rsi_value), 1),
                'adx': round(float(adx_value), 1),
                'consolidation_days': int(consolidation_days),
                'dist_from_20d_high_pct': round(float(distance_from_high), 1),
                'dist_from_20d_low_pct': round(float(distance_from_low), 1),
                'max_down_day_5d_pct': round(float(max_down_day), 1),
                'higher_lows': bool(higher_lows),
                'score': int(score),
                'verdict': verdict,
                'notes': ' | '.join(notes)
            }
        except Exception as e:
            logger.error(f"  ❌ Error in analyze_squeeze for {symbol}: {e}")
            if logger.level == logging.DEBUG:
                import traceback
                logger.debug(traceback.format_exc())
            return None
    
    def scan_symbols(self, input_csv: str, output_csv: str):
        """
        Scan all symbols from input CSV and generate output
        
        Args:
            input_csv: Path to CSV with 'symbol' column
            output_csv: Path for output CSV
        """
        logger.info("Starting squeeze scanner...")
        
        # Load instruments
        self.load_instruments()
        
        if not self.instruments_cache:
            logger.error("❌ Failed to load instruments cache")
            return
        
        logger.info(f"✓ Loaded {len(self.instruments_cache)} instruments from NSE")
        
        # Read input symbols
        try:
            input_df = pd.read_csv(input_csv)
            if 'Symbol' not in input_df.columns:
                logger.error("Input CSV must have 'Symbol' column")
                return
            symbols = input_df['Symbol'].tolist()
            
            # Clean symbols - remove whitespace and convert to uppercase
            symbols = [str(s).strip().upper() for s in symbols if pd.notna(s)]
            
        except Exception as e:
            logger.error(f"Error reading input CSV: {e}")
            return
        
        logger.info(f"Scanning {len(symbols)} symbols...")
        
        # Quick validation - check how many symbols are in cache
        found_symbols = [s for s in symbols if s in self.instruments_cache]
        missing_symbols = [s for s in symbols if s not in self.instruments_cache]
        
        logger.info(f"  ✓ Found in cache: {len(found_symbols)}/{len(symbols)}")
        if missing_symbols and len(missing_symbols) <= 10:
            logger.warning(f"  ⚠️ Missing symbols: {', '.join(missing_symbols)}")
        elif missing_symbols:
            logger.warning(f"  ⚠️ Missing {len(missing_symbols)} symbols (too many to list)")
        
        results = []
        failed_count = 0
        no_data_count = 0
        success_count = 0
        
        for i, symbol in enumerate(symbols, 1):
            if i % 50 == 0:  # Progress update every 50 symbols
                logger.info(f"Progress: {i}/{len(symbols)} - Success: {success_count}, No data: {no_data_count}, Errors: {failed_count}")
            
            logger.debug(f"Processing {i}/{len(symbols)}: {symbol}")
            
            try:
                df = self.get_historical_data(symbol, days=45)
                
                if df is None:
                    no_data_count += 1
                    continue
                    
                if df.empty:
                    no_data_count += 1
                    logger.debug(f"  ⚠️ Empty dataframe for {symbol}")
                    continue
                
                if len(df) < 20:
                    no_data_count += 1
                    logger.debug(f"  ⚠️ Insufficient data for {symbol}: only {len(df)} rows")
                    continue
                
                logger.debug(f"  ✓ Fetched {len(df)} rows for {symbol}")
                
                df = self.calculate_indicators(df)
                analysis = self.analyze_squeeze(df, symbol)
                
                if analysis:
                    results.append(analysis)
                    success_count += 1
                    if analysis['score'] >= 60:
                        logger.info(f"  🎯 {symbol}: Score {analysis['score']}")
                else:
                    logger.debug(f"  ⚠️ Analysis returned None for {symbol}")
                    
            except Exception as e:
                failed_count += 1
                logger.error(f"  ❌ Error processing {symbol}: {e}")
                if logger.level == logging.DEBUG:
                    import traceback
                    logger.debug(traceback.format_exc())
                continue
        
        # Create output DataFrame
        if results:
            output_df = pd.DataFrame(results)
            
            # Sort by score descending
            output_df = output_df.sort_values('score', ascending=False)
            
            # Save to CSV
            output_df.to_csv(output_csv, index=False)
            logger.info(f"✅ Results saved to {output_csv}")
            logger.info(f"\n📊 SCAN SUMMARY:")
            logger.info(f"  Total symbols processed: {len(symbols)}")
            logger.info(f"  ✓ Successful analysis: {success_count}")
            logger.info(f"  ⚠️ No data available: {no_data_count}")
            logger.info(f"  ❌ Errors encountered: {failed_count}")
            
            # Summary stats
            prime_setups = len(output_df[output_df['score'] >= 75])
            strong_setups = len(output_df[output_df['score'] >= 60])
            moderate_setups = len(output_df[output_df['score'] >= 45])
            
            logger.info(f"\n🎯 SETUP QUALITY BREAKDOWN:")
            logger.info(f"  🚀 Prime setups (score ≥75): {prime_setups}")
            logger.info(f"  ✅ Strong setups (score ≥60): {strong_setups}")
            logger.info(f"  ⚡ Moderate setups (score ≥45): {moderate_setups}")
            
            if prime_setups > 0:
                logger.info("\n🔥 TOP 10 OPPORTUNITIES:")
                for idx, (_, row) in enumerate(output_df[output_df['score'] >= 75].head(10).iterrows(), 1):
                    logger.info(f"  {idx}. {row['symbol']:12s} Score: {row['score']:3.0f} | Close: ₹{row['close']:7.2f} | {row['verdict']}")
                    logger.info(f"      Range: {row['range_5d_pct']:.1f}% (5d), Vol Dry: {row['volume_dryup_pct']:.0f}%, RSI: {row['rsi']:.0f}")
            elif strong_setups > 0:
                logger.info("\n✅ TOP 10 STRONG SETUPS:")
                for idx, (_, row) in enumerate(output_df.head(10).iterrows(), 1):
                    logger.info(f"  {idx}. {row['symbol']:12s} Score: {row['score']:3.0f} | Close: ₹{row['close']:7.2f} | {row['verdict']}")
        else:
            logger.warning("❌ No results generated")
            logger.warning(f"\n📊 FAILURE ANALYSIS:")
            logger.warning(f"  Total symbols: {len(symbols)}")
            logger.warning(f"  No data: {no_data_count}")
            logger.warning(f"  Errors: {failed_count}")
            logger.warning(f"\nPossible issues:")
            logger.warning(f"  1. Check if symbols in input.csv match NSE trading symbols")
            logger.warning(f"  2. Verify Kite Connect access token is valid")
            logger.warning(f"  3. Check if historical data is available for these symbols")
            logger.warning(f"  4. Enable DEBUG logging: logger.setLevel(logging.DEBUG)")
            
            # Sample a few symbols to test
            if len(symbols) > 0:
                logger.warning(f"\n🔍 Testing first symbol: {symbols[0]}")
                test_df = self.get_historical_data(symbols[0], days=35)
                if test_df is not None:
                    logger.warning(f"  Data fetched: {len(test_df)} rows")
                    logger.warning(f"  Date range: {test_df['date'].min()} to {test_df['date'].max()}")
                else:
                    logger.warning(f"  ❌ No data returned for {symbols[0]}")
                    logger.warning(f"  Check if '{symbols[0]}' exists in NSE instruments cache")


def main():
    """
    Main execution function
    
    Setup:
    1. Get API key from https://kite.trade/
    2. Generate access token using login flow
    3. Create input.csv with 'symbol' column
    """
    
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "m4wusZxFGJff3P7P6c3rQzEe2o6Awpn6"
    INPUT_CSV = "data\\Stage2Shortlist.csv"
    OUTPUT_CSV = f"squeeze_scan_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    DEBUG_MODE = True  # Set to True for detailed logging
    
    # Validate configuration
    if API_KEY == "your_api_key_here" or ACCESS_TOKEN == "your_access_token_here":
        logger.error("Please configure API_KEY and ACCESS_TOKEN")
        logger.info("\nSetup Instructions:")
        logger.info("1. Sign up at https://kite.trade/")
        logger.info("2. Create an app to get API key")
        logger.info("3. Complete login flow to get access token")
        logger.info("4. Update API_KEY and ACCESS_TOKEN in the script")
        return
    
    # Check if input file exists
    if not os.path.exists(INPUT_CSV):
        logger.error(f"Input file '{INPUT_CSV}' not found")
        logger.info("Create input.csv with a 'symbol' column containing NSE trading symbols")
        return
    
    # Initialize scanner
    scanner = SqueezeScanner(api_key=API_KEY, access_token=ACCESS_TOKEN, debug=DEBUG_MODE)
    
    # Run scan
    scanner.scan_symbols(INPUT_CSV, OUTPUT_CSV)


if __name__ == "__main__":
    main()