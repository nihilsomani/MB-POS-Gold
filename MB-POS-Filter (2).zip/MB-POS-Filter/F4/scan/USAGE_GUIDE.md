# AKMarketCheck.py - Usage Guide

## Quick Start

### Basic Usage (Single Symbol Analysis)

```python
python AKMarketCheck.py
```

Follow the prompts to:
1. Enter your Kite Connect API key
2. Provide access token or complete OAuth flow
3. Select symbol (NIFTY 50, BANK NIFTY, or custom)
4. View comprehensive analysis report

---

## Scanner Mode (Batch Processing)

### Prepare Input CSV

Create a CSV file with symbols:

```csv
Symbol
RELIANCE
TCS
INFY
HDFCBANK
ICICIBANK
```

### Run Scanner

```python
python AKMarketCheck.py
# Select option 2 (Scanner Mode)
# Enter: input.csv
# Enter: output_results.csv
# Enter: 180 (days of historical data)
```

### Programmatic Usage

```python
from AKMarketCheck import run_scanner, config

# Configure settings
config.scanner_parallel_workers = 3  # Parallel threads
config.scanner_timeout_seconds = 60  # Per-symbol timeout

# Run scanner
results = run_scanner(
    api_key="your_api_key",
    access_token="your_access_token",
    input_file="data/symbols.csv",
    days=180,
    output_file="results.csv"
)

# Analyze results
if results is not None:
    buy_signals = results[results['Signal'] == 'Buy']
    high_confidence = results[results['Confidence'] >= 7]
    print(f"Found {len(buy_signals)} buy signals")
    print(f"High confidence signals: {len(high_confidence)}")
```

---

## Configuration Options

### Adjust Performance Settings

```python
from AKMarketCheck import config

# For faster processing (more API calls, might hit rate limits)
config.scanner_parallel_workers = 10
config.rate_limit_delay = 0.3

# For safer processing (slower but respects rate limits)
config.scanner_parallel_workers = 1
config.rate_limit_delay = 1.0

# Increase cache duration (fewer API calls)
config.instruments_cache_duration = 7200  # 2 hours
```

### Adjust Analysis Parameters

```python
# Gann Theory settings
config.gann_tolerance_pct = 0.015  # 1.5% tolerance
config.gann_lookback_period = 30   # Look back 30 days

# Elliott Wave settings
config.elliott_min_strength = 3    # Higher = stricter patterns
config.elliott_peak_windows = [5, 10, 20, 30]  # Multi-timeframe

# Fibonacci tolerance
config.fibonacci_tolerance = 0.15  # Wider acceptance range
```

### Adjust Scoring Weights

```python
# Emphasize Elliott Wave over Lunar cycles
config.lunar_weight = 0.5
config.gann_weight = 1.0
config.elliott_weight = 2.0
```

---

## Logging and Debugging

### Check Logs

All operations are logged to `market_analyzer.log`:

```bash
# View recent logs
tail -f market_analyzer.log

# Search for errors
grep ERROR market_analyzer.log

# Filter by symbol
grep "RELIANCE" market_analyzer.log
```

### Adjust Log Level

```python
import logging

# Set to DEBUG for verbose output
logging.getLogger().setLevel(logging.DEBUG)

# Set to WARNING for minimal output
logging.getLogger().setLevel(logging.WARNING)
```

---

## Token Mapping (Performance Optimization)

### Create Token Mapping File

```python
from AKMarketCheck import create_token_mapping_file

symbols = ["RELIANCE", "TCS", "INFY", "HDFCBANK"]

mapping = create_token_mapping_file(
    api_key="your_api_key",
    access_token="your_access_token",
    symbols_list=symbols,
    output_file="my_tokens.json"
)
```

### Load Existing Mapping

```python
from AKMarketCheck import load_token_mapping

mapping = load_token_mapping("my_tokens.json")
print(f"Loaded {len(mapping)} symbols")
```

**Benefit:** Scanner uses cached tokens instead of API lookups (95% fewer API calls).

---

## Advanced Usage

### Custom Analysis Pipeline

```python
from AKMarketCheck import IntegratedMarketAnalyzer, config

# Initialize analyzer
analyzer = IntegratedMarketAnalyzer(
    api_key="your_api_key",
    access_token="your_access_token",
    symbol="RELIANCE",
    instrument_token=738561  # RELIANCE token
)

# Fetch data
if analyzer.fetch_market_data(days=365):
    
    # Get signals
    signals = analyzer.generate_combined_signals()
    
    if signals:
        sig = signals[0]
        print(f"Signal: {sig['Signal']}")
        print(f"Confidence: {sig['Strength']}/10")
        print(f"Lunar Phase: {sig['Lunar_Phase']}")
        
        # Access components
        if sig['Components']['elliott_pattern']:
            print("Elliott Wave pattern detected!")
        
        gann_signals = sig['Components']['gann_signals']
        print(f"Gann signals: {len(gann_signals)}")
```

### Access Individual Analyzers

```python
# Lunar analysis only
lunar_analyzer = analyzer.lunar_analyzer
phase = lunar_analyzer.get_lunar_phase(datetime.now())
strength = lunar_analyzer.get_lunar_influence_strength(datetime.now())

# Gann analysis only
gann_analyzer = analyzer.gann_analyzer
square_levels = gann_analyzer.find_gann_squares(current_price=2500)
gann_signals = gann_analyzer.get_gann_signals(current_price=2500)

# Elliott Wave analysis only
elliott_analyzer = analyzer.elliott_analyzer
pattern = elliott_analyzer.detect_wave_pattern()
if pattern:
    print(f"Pattern strength: {pattern['pattern_strength']}/10")
    print(f"Wave type: {pattern['wave_type']}")
```

---

## Output Interpretation

### Signal Confidence Levels

| Confidence | Interpretation | Action |
|-----------|----------------|--------|
| 8-10 | Very High | Strong signal, consider entry |
| 6-8 | High | Good signal, validate with other factors |
| 4-6 | Medium | Weak signal, wait for confirmation |
| 0-4 | Low | No clear direction, avoid trading |

### Signal Types

- **Buy**: Bullish signal detected
- **Sell**: Bearish signal detected
- **Hold**: No clear signal or conflicting indicators
- **ERROR**: Analysis failed (check logs)

### Quality Score (0-3)

Number of analysis methods confirming the signal:
- **3**: All three methods agree (Lunar + Gann + Elliott)
- **2**: Two methods agree
- **1**: Only one method triggered
- **0**: Weak or no confirmation

---

## Common Issues and Solutions

### Issue: API Rate Limit Exceeded

**Solution:**
```python
config.scanner_parallel_workers = 1  # Disable parallel processing
config.rate_limit_delay = 1.0        # Increase delay between calls
```

### Issue: NSE Instrument Fallback Fails

**Solution:**
- NSE has changed their API endpoints
- Use Kite Connect instruments instead
- Check if you have valid access token
- Verify symbol spelling (use NSE format)

### Issue: Slow Scanner Performance

**Solution:**
```python
# Enable parallel processing (if API limits allow)
config.scanner_parallel_workers = 5

# Use token mapping file
create_token_mapping_file(...)  # Create once
# Scanner will auto-load cached tokens
```

### Issue: Division by Zero Errors (Should Not Occur)

If you see these errors, it means safe_divide() isn't being used:
- Report as bug
- Check if custom modifications were made
- Verify you're using the latest version

---

## Best Practices

### 1. Token Management

- Create token mapping file for large scans
- Cache tokens to reduce API calls
- Refresh mapping periodically (weekly)

### 2. Rate Limiting

- Start with `scanner_parallel_workers = 1`
- Gradually increase if no errors
- Monitor API usage dashboard

### 3. Data Quality

- Use at least 180 days of historical data
- Verify symbols are actively traded
- Check for corporate actions (splits, bonuses)

### 4. Signal Validation

- Don't rely on a single signal
- Look for high Quality Score (2-3)
- Validate with volume and price action
- Check fundamental factors

### 5. Risk Management

- Always use stop losses
- Position size based on confidence level
- Diversify signals across sectors
- Review signals during market hours

---

## Example Workflows

### Workflow 1: Daily Market Scan

```bash
# 1. Update token mapping (weekly)
python -c "from AKMarketCheck import create_token_mapping_file; ..."

# 2. Run daily scan
python AKMarketCheck.py
# Select Scanner Mode
# Use: daily_scan.csv (your watchlist)

# 3. Filter results
python -c "
import pandas as pd
df = pd.read_csv('scanner_output.csv')
buy_signals = df[(df['Signal'] == 'Buy') & (df['Confidence'] >= 7)]
buy_signals.to_csv('buy_candidates.csv')
"

# 4. Review buy_candidates.csv manually
```

### Workflow 2: Deep Analysis of Single Stock

```python
from AKMarketCheck import IntegratedMarketAnalyzer

analyzer = IntegratedMarketAnalyzer(
    api_key=API_KEY,
    access_token=ACCESS_TOKEN,
    symbol="RELIANCE",
    instrument_token=738561
)

if analyzer.fetch_market_data(days=365):
    # Generate comprehensive report
    analyzer.create_comprehensive_report()
    
    # Export data for further analysis
    from AKMarketCheck import export_data
    export_data(analyzer)
```

### Workflow 3: Backtesting (Manual)

```python
# Analyze historical signals
from datetime import datetime, timedelta
import pandas as pd

results = []
for days_ago in range(0, 365, 7):  # Weekly signals for 1 year
    date = datetime.now() - timedelta(days=days_ago)
    # Fetch data up to that date
    # Generate signals
    # Record results

# Analyze win rate
df = pd.DataFrame(results)
win_rate = len(df[df['Profitable'] == True]) / len(df)
print(f"Win rate: {win_rate:.2%}")
```

---

## Environment Setup

### Requirements

```bash
pip install pandas numpy kiteconnect matplotlib
```

### Environment Variables (Optional)

```bash
export KITE_API_KEY="your_api_key"
export KITE_ACCESS_TOKEN="your_access_token"
```

Then modify code to read from environment:

```python
import os
api_key = os.getenv('KITE_API_KEY')
access_token = os.getenv('KITE_ACCESS_TOKEN')
```

---

## Support and Troubleshooting

### Check Logs First

```bash
tail -100 market_analyzer.log
```

### Common Log Messages

- `INFO: Fetched X instruments` - Normal operation
- `WARNING: Using cached instruments` - Using cache (expected)
- `ERROR: Error fetching historical data` - Check token/symbol
- `DEBUG: ...` - Detailed trace (only in DEBUG mode)

### Getting Help

1. Check `IMPROVEMENTS_SUMMARY.md` for recent changes
2. Review `market_analyzer.log` for errors
3. Verify Kite Connect subscription is active
4. Test with NIFTY 50 (known working symbol)

---

**Last Updated:** 2025-10-31  
**Version:** Enhanced/Robust  
**Support:** Check logs and documentation

