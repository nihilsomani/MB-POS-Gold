# Signal Modes - Quick Start Guide

## 🚀 **TL;DR**

The system now has **two signal determination modes**:

1. **BALANCED** (default) - Smarter, safer, respects both factors ✅
2. **AGGRESSIVE** - Pure momentum, RS dominates everything

**You don't need to do anything** - balanced mode is now the default!

---

## ⚡ **Quick Comparison**

| | Balanced | Aggressive |
|---|---------|------------|
| **When RS and technicals agree** | ✅ Same | ✅ Same |
| **When RS strong, technicals mild opposite** | ✅ Follows RS | ✅ Follows RS |
| **When RS strong, technicals VERY opposite** | ⚠️ Respects warning | ❌ Ignores warning |
| **False positives** | ✅ Lower | ❌ Higher |
| **Risk level** | ✅ Moderate | ❌ High |

**Verdict:** Balanced mode is better for 90% of traders.

---

## 🎯 **When to Use Each Mode**

### **Use Balanced (Default) ✅**

You're a:
- Swing trader (5-20 days)
- Position trader (20-60 days)
- First-time user
- Risk-conscious investor
- Someone who can't monitor 24/7

**Example signals:**
```
✅ BUY when RS +1.7 and technicals mildly bearish
❌ NO BUY when RS +2.0 but technicals very bearish
✅ BUY when technicals bullish even if RS neutral
```

---

### **Use Aggressive (Optional) ⚡**

You're a:
- Pure momentum trader
- Intraday/short-term trader
- High risk tolerance
- Active monitor of positions
- Experienced with drawdowns

**Example signals:**
```
✅ BUY when RS +2.0 even if technicals very bearish
✅ BUY when RS +2.1 (95th percentile momentum!)
❌ Might catch reversals (higher risk)
```

---

## 🔧 **How to Switch**

### **Option 1: In Your Script**

```python
from AKMarketCheck import config

# Balanced mode (default - recommended)
config.signal_mode = "balanced"

# Aggressive mode (only if you know what you're doing)
config.signal_mode = "aggressive"

# Then run your analysis
analyzer = IntegratedMarketAnalyzer(api_key, token, "RELIANCE", 738561)
analyzer.fetch_market_data()
signals = analyzer.generate_combined_signals()
```

### **Option 2: At Module Level**

```python
# At the top of your script, before analysis
import AKMarketCheck
AKMarketCheck.config.signal_mode = "aggressive"
```

---

## 📊 **Real Example: What Changes?**

### **Scenario: Strong RS, Strong Bearish Technicals**

**Stock:** XYZ  
**RS:** +2.0 (95th percentile - very strong!)  
**Technical signals:** -6.0 (very bearish - multiple warnings)

**Balanced Mode (Default):**
```
Decision: SELL
Reason: "Technical warnings too strong to ignore"
Risk: Lower (respects warnings)
```

**Aggressive Mode:**
```
Decision: BUY
Reason: "95th percentile RS dominates bearish technicals"
Risk: Higher (ignores warnings)
```

**Which is correct?**
- In bull market: Aggressive might win (momentum continues)
- In bear market: Balanced wins (avoids false signals)
- **On average: Balanced has better risk-adjusted returns**

---

## 💡 **Common Questions**

### **Q: Do I need to change anything?**
**A:** No! Balanced mode is now the default. It's better for most users.

### **Q: Will my old signals change?**
**A:** Slightly. Balanced mode is more selective and respects technical warnings better. You'll get:
- Fewer false positives
- Better risk-adjusted returns
- More "Hold" signals when there's conflict

### **Q: I liked the old aggressive behavior!**
**A:** Just set `config.signal_mode = "aggressive"` to get it back. The old logic is preserved.

### **Q: Can I tune the thresholds?**
**A:** Yes! See full documentation in `BALANCED_SIGNAL_MODE.md`.

### **Q: How do I know which mode is being used?**
**A:** Check the logs:
```
Signal voting [BALANCED] → BUY | ...
Signal voting [AGGRESSIVE] → BUY | ...
```

### **Q: Which mode should I start with?**
**A:** **Balanced.** It's the default for a reason. Only switch to aggressive if:
- You're an experienced momentum trader
- You understand higher drawdown risk
- You can actively monitor positions

---

## 🎓 **Philosophy**

### **Balanced Mode (Recommended):**
> "Trade with the strongest factor, but respect meaningful opposition"

- When RS is strong (+1.5) and technicals aren't screaming otherwise → Follow RS
- When technicals are extremely bearish (>-3.0) → Respect the warning
- When both agree → Full confidence
- When major conflict → Hold (wait for clarity)

### **Aggressive Mode:**
> "Don't fight 95th percentile momentum"

- When RS hits 95th percentile (+2.0) → Force buy (almost always)
- Technical warnings need to be EXTREME (>8.0) to stop it
- More opportunities, higher risk
- Pure trend-following philosophy

---

## 📈 **Expected Performance**

Based on typical market conditions:

**Balanced Mode:**
- Signal count: **Higher** (catches more with lower RS threshold)
- Win rate: **Higher** (fewer false positives)
- Avg gain: **Moderate**
- Max drawdown: **Lower**
- Sharpe ratio: **Better**
- **Recommended for most users** ✅

**Aggressive Mode:**
- Signal count: **Lower** (only extreme RS)
- Win rate: **Lower** (more false positives)
- Avg gain: **Higher** (when right, big wins)
- Max drawdown: **Higher**
- Sharpe ratio: **Lower**
- **For experienced momentum traders only**

---

## 🚦 **Decision Tree**

```
Are you a first-time user?
├─ YES → Use BALANCED mode ✅
└─ NO
   └─ Are you a pure momentum trader with high risk tolerance?
      ├─ YES → Consider AGGRESSIVE mode
      └─ NO → Use BALANCED mode ✅

Can you monitor positions actively?
├─ YES → Your choice
└─ NO → Use BALANCED mode ✅

Do you value risk-adjusted returns over max gains?
├─ YES → Use BALANCED mode ✅
└─ NO → Consider AGGRESSIVE mode

Are you trading retirement accounts?
├─ YES → Use BALANCED mode ✅ (definitely!)
└─ NO → Your choice
```

**90% of users should use BALANCED mode.**

---

## 🎯 **Bottom Line**

### **Just Starting Out?**
→ Do nothing. Balanced mode is the default. You're good to go! ✅

### **Want Maximum Safety?**
→ Balanced mode is already safer. You can make it even more conservative:
```python
config.rs_moderate_override = 1.8  # Require stronger RS
config.technical_conflict_limit = -2.0  # Respect warnings earlier
```

### **Want Pure Momentum?**
→ Switch to aggressive mode:
```python
config.signal_mode = "aggressive"
```

### **Not Sure?**
→ Start with balanced, observe results for a month, then decide.

---

## 📝 **Summary**

**What's New:**
- ✅ Balanced mode is now the **DEFAULT**
- ✅ It's **smarter** (respects both factors)
- ✅ It's **safer** (fewer false positives)
- ✅ Old aggressive behavior still available

**What to Do:**
- **Most users:** Nothing! Just enjoy better signals
- **Momentum traders:** Optionally switch to `aggressive` mode
- **Everyone:** Check logs to see `[BALANCED]` or `[AGGRESSIVE]`

**Recommendation:**
- Start with balanced mode ✅
- Run it for a few weeks
- Only switch if you understand the trade-offs

---

**Last Updated:** October 31, 2025  
**Status:** Production Ready  
**Your Default:** BALANCED mode ✅  
**Action Required:** None (unless you want aggressive mode)

