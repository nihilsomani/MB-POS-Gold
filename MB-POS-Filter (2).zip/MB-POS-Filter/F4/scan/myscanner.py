import pandas as pd
import numpy as np
from kiteconnect import KiteConnect
import time
from datetime import datetime, timedelta
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class EMAPullbackScanner:
    def __init__(self, api_key, access_token):
        """Initialize scanner with Kite Connect credentials"""
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        
        # Rate limiting: 3 requests per second
        self.last_request_time = 0
        self.min_request_interval = 0.35  # Slightly above 1/3 second for safety
        
        # Cache for instruments
        self.instruments_cache = None
        self.symbol_token_map = {}
        
    def _rate_limit(self):
        """Enforce rate limiting"""
        current_time = time.time()
        time_since_last_request = current_time - self.last_request_time
        
        if time_since_last_request < self.min_request_interval:
            sleep_time = self.min_request_interval - time_since_last_request
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def load_instruments_cache(self):
        """Load NSE instruments and create symbol-token mapping"""
        logger.info("Loading NSE instruments cache...")
        self._rate_limit()
        
        try:
            instruments = self.kite.instruments("NSE")
            self.instruments_cache = pd.DataFrame(instruments)
            
            # Create symbol to instrument_token mapping
            for _, row in self.instruments_cache.iterrows():
                if row['segment'] == 'NSE':
                    self.symbol_token_map[row['tradingsymbol']] = row['instrument_token']
            
            logger.info(f"Loaded {len(self.symbol_token_map)} NSE instruments")
            return True
        except Exception as e:
            logger.error(f"Error loading instruments: {e}")
            return False
    
    def get_historical_data(self, symbol, days=100):
        """Fetch historical data for a symbol"""
        if symbol not in self.symbol_token_map:
            logger.warning(f"Symbol {symbol} not found in NSE instruments")
            return None
        
        instrument_token = self.symbol_token_map[symbol]
        to_date = datetime.now()
        from_date = to_date - timedelta(days=days)
        
        self._rate_limit()
        
        try:
            data = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="day"
            )
            
            df = pd.DataFrame(data)
            if not df.empty:
                df['date'] = pd.to_datetime(df['date'])
                df = df.sort_values('date').reset_index(drop=True)
            return df
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def calculate_ema(self, data, period):
        """Calculate EMA for given period"""
        return data['close'].ewm(span=period, adjust=False).mean()
    
    def detect_consolidation(self, prices, lookback=5):
        """Detect price consolidation (low volatility)"""
        if len(prices) < lookback:
            return False, 0
        
        recent_prices = prices[-lookback:]
        volatility = (recent_prices.max() - recent_prices.min()) / recent_prices.mean()
        
        # Consolidation if price range is less than 2% of mean price
        is_consolidating = volatility < 0.02
        return is_consolidating, round(volatility * 100, 2)
    
    def detect_volume_drying(self, volumes, lookback=5):
        """Detect decreasing volume trend"""
        if len(volumes) < lookback:
            return False, 0
        
        recent_volume = volumes[-lookback:]
        earlier_volume = volumes[-lookback*2:-lookback] if len(volumes) >= lookback*2 else volumes[:-lookback]
        
        if len(earlier_volume) == 0:
            return False, 0
        
        recent_avg = recent_volume.mean()
        earlier_avg = earlier_volume.mean()
        
        volume_decrease = ((earlier_avg - recent_avg) / earlier_avg) * 100
        
        # Volume drying if recent volume is 20% lower than earlier
        is_drying = volume_decrease > 20
        return is_drying, round(volume_decrease, 2)
    
    def check_price_near_ema(self, price, ema, tolerance=0.015):
        """Check if price is near EMA (within tolerance)"""
        distance = abs(price - ema) / ema
        return distance <= tolerance, round(distance * 100, 2)
    
    def analyze_symbol(self, symbol):
        """Analyze a single symbol for EMA pullback setups"""
        logger.info(f"Analyzing {symbol}...")
        
        # Fetch historical data
        df = self.get_historical_data(symbol, days=100)
        
        if df is None or len(df) < 60:
            return {
                'Symbol': symbol,
                'Status': 'INSUFFICIENT_DATA',
                'Setup_Type': 'N/A',
                'Current_Price': 0,
                'EMA_10': 0,
                'EMA_21': 0,
                'EMA_55': 0,
                'Notes': 'Insufficient historical data'
            }
        
        # Calculate EMAs
        df['EMA_10'] = self.calculate_ema(df, 11)
        df['EMA_21'] = self.calculate_ema(df, 23)
        df['EMA_55'] = self.calculate_ema(df, 55)
        
        # Get latest values
        latest = df.iloc[-1]
        current_price = latest['close']
        ema_10 = latest['EMA_10']
        ema_21 = latest['EMA_21']
        ema_55 = latest['EMA_55']
        
        result = {
            'Symbol': symbol,
            'Status': 'NO_SETUP',
            'Setup_Type': 'N/A',
            'Current_Price': round(current_price, 2),
            'EMA_10': round(ema_10, 2),
            'EMA_21': round(ema_21, 2),
            'EMA_55': round(ema_55, 2),
            'Volume_Status': 'N/A',
            'Consolidation_Status': 'N/A',
            'Notes': ''
        }
        
        # Primary condition: 21 EMA must be above 55 EMA
        if ema_21 <= ema_55:
            result['Notes'] = f"21 EMA ({round(ema_21, 2)}) not above 55 EMA ({round(ema_55, 2)})"
            return result
        
        ema_21_55_spread = round(((ema_21 - ema_55) / ema_55) * 100, 2)
        
        # Check consolidation and volume
        is_consolidating, consol_pct = self.detect_consolidation(df['close'], lookback=5)
        is_volume_drying, vol_decrease = self.detect_volume_drying(df['volume'], lookback=5)
        
        result['Volume_Status'] = f"Drying ({vol_decrease}%)" if is_volume_drying else f"Normal ({vol_decrease}%)"
        result['Consolidation_Status'] = f"Yes ({consol_pct}%)" if is_consolidating else f"No ({consol_pct}%)"
        
        # SETUP 1: Pullback to 21 EMA with consolidation and volume drying
        near_21_ema, dist_21 = self.check_price_near_ema(current_price, ema_21, tolerance=0.02)
        
        if near_21_ema:
            quality_score = 0
            notes = []
            
            if is_consolidating:
                quality_score += 1
                notes.append("✓ Consolidating")
            
            if is_volume_drying:
                quality_score += 1
                notes.append("✓ Volume drying")
            
            if current_price > ema_21:
                notes.append(f"Price {dist_21}% above 21 EMA")
            else:
                notes.append(f"Price {dist_21}% below 21 EMA")
            
            notes.append(f"21-55 EMA spread: {ema_21_55_spread}%")
            
            result['Status'] = 'SETUP_FOUND'
            result['Setup_Type'] = 'PULLBACK_TO_21_EMA'
            result['Quality_Score'] = f"{quality_score}/2"
            result['Notes'] = " | ".join(notes)
            return result
        
        # SETUP 2: Price between 21 and 55 EMA with consolidation
        if ema_55 < current_price < ema_21:
            quality_score = 0
            notes = []
            
            price_position = round(((current_price - ema_55) / (ema_21 - ema_55)) * 100, 2)
            notes.append(f"Price {price_position}% between 21-55 EMA")
            
            if is_consolidating:
                quality_score += 1
                notes.append("✓ Consolidating")
            
            if is_volume_drying:
                quality_score += 1
                notes.append("✓ Volume drying")
            
            notes.append(f"21-55 EMA spread: {ema_21_55_spread}%")
            
            result['Status'] = 'SETUP_FOUND'
            result['Setup_Type'] = 'BETWEEN_21_55_EMA'
            result['Quality_Score'] = f"{quality_score}/2"
            result['Notes'] = " | ".join(notes)
            return result
        
        # SETUP 3: Touched 10 or 21 EMA and bounced (upward journey started)
        lookback = 5
        if len(df) >= lookback:
            recent_df = df.tail(lookback)
            
            # Check if price touched 10 EMA
            touched_10_ema = any(
                abs(row['close'] - row['EMA_10']) / row['EMA_10'] < 0.015 
                for _, row in recent_df.iloc[:-1].iterrows()
            )
            
            # Check if price touched 21 EMA
            touched_21_ema = any(
                abs(row['close'] - row['EMA_21']) / row['EMA_21'] < 0.015 
                for _, row in recent_df.iloc[:-1].iterrows()
            )
            
            # Check if price is now above both EMAs and rising
            price_above_10 = current_price > ema_10
            price_above_21 = current_price > ema_21
            
            recent_prices = recent_df['close'].values
            is_rising = len(recent_prices) >= 2 and recent_prices[-1] > recent_prices[-2]
            
            if (touched_10_ema or touched_21_ema) and price_above_10 and is_rising:
                notes = []
                
                if touched_10_ema:
                    notes.append("✓ Touched 10 EMA recently")
                if touched_21_ema:
                    notes.append("✓ Touched 21 EMA recently")
                
                notes.append(f"Price above 10 EMA by {round(((current_price - ema_10)/ema_10)*100, 2)}%")
                
                if price_above_21:
                    notes.append(f"Price above 21 EMA by {round(((current_price - ema_21)/ema_21)*100, 2)}%")
                
                notes.append("✓ Upward momentum started")
                notes.append(f"21-55 EMA spread: {ema_21_55_spread}%")
                
                result['Status'] = 'SETUP_FOUND'
                result['Setup_Type'] = 'BOUNCED_FROM_EMA'
                result['Quality_Score'] = '2/2'
                result['Notes'] = " | ".join(notes)
                return result
        
        # No setup found
        result['Notes'] = f"21 EMA above 55 EMA by {ema_21_55_spread}% but no pullback/consolidation setup yet"
        return result
    
    def scan_symbols(self, input_csv, output_csv):
        """Scan all symbols from input CSV"""
        logger.info(f"Reading symbols from {input_csv}")
        
        try:
            input_df = pd.read_csv(input_csv)
            
            if 'Symbol' not in input_df.columns:
                logger.error("Input CSV must have 'Symbol' column")
                return
            
            symbols = input_df['Symbol'].dropna().unique().tolist()
            logger.info(f"Found {len(symbols)} symbols to scan")
            
            # Load instruments cache
            if not self.load_instruments_cache():
                logger.error("Failed to load instruments cache")
                return
            
            # Analyze each symbol
            results = []
            for i, symbol in enumerate(symbols, 1):
                logger.info(f"Processing {i}/{len(symbols)}: {symbol}")
                result = self.analyze_symbol(symbol)
                results.append(result)
                
                # Progress update every 10 symbols
                if i % 10 == 0:
                    logger.info(f"Progress: {i}/{len(symbols)} symbols completed")
            
            # Create output DataFrame
            output_df = pd.DataFrame(results)
            
            # Sort by status and setup type
            setup_order = {'BOUNCED_FROM_EMA': 1, 'PULLBACK_TO_21_EMA': 2, 'BETWEEN_21_55_EMA': 3}
            output_df['_sort'] = output_df['Setup_Type'].map(setup_order).fillna(999)
            output_df = output_df.sort_values(['Status', '_sort'], ascending=[False, True])
            output_df = output_df.drop('_sort', axis=1)
            
            # Save to CSV
            output_df.to_csv(output_csv, index=False)
            logger.info(f"Results saved to {output_csv}")
            
            # Summary
            setups_found = len(output_df[output_df['Status'] == 'SETUP_FOUND'])
            logger.info(f"\n{'='*60}")
            logger.info(f"SCAN COMPLETE")
            logger.info(f"{'='*60}")
            logger.info(f"Total symbols scanned: {len(symbols)}")
            logger.info(f"Setups found: {setups_found}")
            logger.info(f"  - Bounced from EMA: {len(output_df[output_df['Setup_Type'] == 'BOUNCED_FROM_EMA'])}")
            logger.info(f"  - Pullback to 21 EMA: {len(output_df[output_df['Setup_Type'] == 'PULLBACK_TO_21_EMA'])}")
            logger.info(f"  - Between 21-55 EMA: {len(output_df[output_df['Setup_Type'] == 'BETWEEN_21_55_EMA'])}")
            logger.info(f"{'='*60}")
            
        except Exception as e:
            logger.error(f"Error during scanning: {e}")
            raise


# Example usage
if __name__ == "__main__":
    # Configuration
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "gfG1Mq3uGRYdYe0Uzqa9S8ROVOWRVQ7U"
    
    INPUT_CSV = "data\\MB_symbols_enriched_sector.csv"
    OUTPUT_CSV = f"ema_pullback_scan_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    
    # Create scanner
    scanner = EMAPullbackScanner(API_KEY, ACCESS_TOKEN)
    
    # Run scan
    scanner.scan_symbols(INPUT_CSV, OUTPUT_CSV)