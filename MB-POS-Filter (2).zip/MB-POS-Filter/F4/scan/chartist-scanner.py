"""
Advanced Breakout Scanner for NSE Stocks - IMPROVED VERSION
Addresses logical improvements, robust pattern detection, and retest recognition
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
import time
import logging
from typing import Dict, List, Tuple, Optional
import json
from pathlib import Path
from sklearn.cluster import DBSCAN

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('breakout_scanner.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Configuration Constants
MIN_PRICE = 50  # Minimum stock price to avoid penny stocks
MIN_AVG_VOLUME = 100000  # Minimum average daily volume for liquidity
RESISTANCE_TOLERANCE = 0.02  # 2% tolerance for resistance matching
MAX_VOLATILITY_STRONG_RESISTANCE = 0.40  # Max volatility for strong resistance pattern
LOOKBACK_DAYS = 60
SMA_SHORT = 20
SMA_LONG = 50
RSI_PERIOD = 14


class RateLimiter:
    """Implements rate limiting for API calls"""
    def __init__(self, calls_per_second: float = 3):
        self.calls_per_second = calls_per_second
        self.min_interval = 1.0 / calls_per_second
        self.last_call = 0
    
    def wait(self):
        """Wait if necessary to respect rate limit"""
        elapsed = time.time() - self.last_call
        if elapsed < self.min_interval:
            time.sleep(self.min_interval - elapsed)
        self.last_call = time.time()


class InstrumentCache:
    """Manages NSE instrument cache"""
    def __init__(self, cache_file: str = 'nse_instruments_cache.json'):
        self.cache_file = cache_file
        self.instruments = {}
        self.load_cache()
    
    def load_cache(self):
        """Load instruments from cache file"""
        if Path(self.cache_file).exists():
            with open(self.cache_file, 'r') as f:
                self.instruments = json.load(f)
            logger.info(f"Loaded {len(self.instruments)} instruments from cache")
        else:
            logger.warning("No instrument cache found")
    
    def save_cache(self, instruments_list: List[Dict]):
        """Save instruments to cache"""
        self.instruments = {inst['tradingsymbol']: inst for inst in instruments_list}
        with open(self.cache_file, 'w') as f:
            json.dump(self.instruments, f)
        logger.info(f"Saved {len(self.instruments)} instruments to cache")
    
    def get_instrument_token(self, symbol: str) -> Optional[int]:
        """Get instrument token for a symbol"""
        inst = self.instruments.get(symbol)
        return inst['instrument_token'] if inst else None


class BreakoutAnalyzer:
    """Analyzes price action for breakout patterns"""
    
    @staticmethod
    def find_consolidation_high_clustered(df: pd.DataFrame, lookback_days: int = LOOKBACK_DAYS) -> Tuple[float, int, str, List[int]]:
        """
        Find consolidation high using DBSCAN clustering for better resistance identification
        Returns: (breakout_level, touch_points, pattern_type, touch_indices)
        """
        if len(df) < 10:
            return None, 0, "insufficient_data", []
        
        recent_data = df.tail(lookback_days).copy()
        high_prices = recent_data['high'].values
        
        # Filter significant highs (above 95th percentile of closes)
        close_95_percentile = np.percentile(recent_data['close'].values, 95)
        significant_highs = [(i, price) for i, price in enumerate(high_prices) 
                            if price >= close_95_percentile]
        
        if len(significant_highs) < 2:
            return recent_data['high'].max(), 1, "simple_high", [len(recent_data) - 1]
        
        # Use DBSCAN clustering to find resistance levels
        prices_array = np.array([h[1] for h in significant_highs]).reshape(-1, 1)
        
        # eps is tolerance as percentage of mean price
        mean_price = np.mean(prices_array)
        eps = RESISTANCE_TOLERANCE * mean_price
        
        clustering = DBSCAN(eps=eps, min_samples=2).fit(prices_array)
        labels = clustering.labels_
        
        # Find the cluster with most points (main resistance)
        if len(set(labels)) <= 1 and -1 in labels:
            # No clusters found, use highest high
            max_high = max(significant_highs, key=lambda x: x[1])
            return max_high[1], 1, "simple_high", [max_high[0]]
        
        # Get cluster with most touches (excluding noise points labeled -1)
        valid_clusters = [l for l in labels if l != -1]
        if not valid_clusters:
            max_high = max(significant_highs, key=lambda x: x[1])
            return max_high[1], 1, "simple_high", [max_high[0]]
        
        cluster_counts = {}
        for label in set(valid_clusters):
            cluster_counts[label] = list(labels).count(label)
        
        best_cluster = max(cluster_counts.items(), key=lambda x: x[1])[0]
        
        # Get all prices and indices in best cluster
        cluster_points = [(significant_highs[i][0], significant_highs[i][1]) 
                         for i, label in enumerate(labels) if label == best_cluster]
        
        resistance_level = np.mean([p[1] for p in cluster_points])
        touch_count = len(cluster_points)
        touch_indices = [p[0] for p in cluster_points]
        
        # Determine pattern type with improved logic
        pattern_type = BreakoutAnalyzer._classify_pattern_type(
            recent_data, resistance_level, touch_count, touch_indices
        )
        
        return resistance_level, touch_count, pattern_type, touch_indices
    
    @staticmethod
    def _classify_pattern_type(df: pd.DataFrame, resistance: float, touch_count: int, touch_indices: List[int]) -> str:
        """Improved pattern classification"""
        price_range = df['high'].max() - df['low'].min()
        avg_price = df['close'].mean()
        volatility = price_range / avg_price
        
        # Check if touches are distributed over time (not clustered in one period)
        if len(touch_indices) >= 2:
            touch_spread = max(touch_indices) - min(touch_indices)
            total_period = len(df)
            time_distribution = touch_spread / total_period
        else:
            time_distribution = 0
        
        # Calculate average distance of touches from resistance
        touches_data = df.iloc[touch_indices]
        avg_distance = np.mean(np.abs(touches_data['high'].values - resistance) / resistance)
        
        # Tight consolidation: low volatility, multiple touches, well distributed
        if volatility < 0.15 and touch_count >= 3 and time_distribution > 0.3:
            return "tight_consolidation"
        
        # Base formation: moderate volatility, good touches, reasonable distribution
        elif volatility < 0.25 and touch_count >= 2 and time_distribution > 0.2:
            return "base_formation"
        
        # Strong resistance: many touches but must have reasonable volatility
        elif touch_count >= 4 and volatility < MAX_VOLATILITY_STRONG_RESISTANCE and time_distribution > 0.25:
            return "strong_resistance"
        
        # Weak resistance: high touches but poor quality (clustered or high volatility)
        elif touch_count >= 4:
            return "weak_resistance"
        
        # Emerging pattern: few touches but good distribution
        elif touch_count >= 2 and time_distribution > 0.3:
            return "emerging_pattern"
        
        else:
            return "simple_high"
    
    @staticmethod
    def detect_false_breakouts(df: pd.DataFrame, resistance_level: float, touch_indices: List[int]) -> Dict:
        """
        Detect if previous breakout attempts failed
        """
        false_breakouts = 0
        breakout_failure_indices = []
        
        for i in range(1, len(df)):
            prev_close = df.iloc[i-1]['close']
            curr_open = df.iloc[i]['open']
            curr_high = df.iloc[i]['high']
            curr_close = df.iloc[i]['close']
            
            # Check if broke above resistance but closed back below
            if prev_close <= resistance_level and curr_high > resistance_level * 1.01:
                # Confirmed breakout: closed above resistance
                if curr_close > resistance_level:
                    # Check next 3 days for failure
                    if i + 3 < len(df):
                        next_3_lows = df.iloc[i+1:i+4]['low'].min()
                        if next_3_lows < resistance_level * 0.98:
                            false_breakouts += 1
                            breakout_failure_indices.append(i)
                else:
                    # Failed immediately
                    false_breakouts += 1
                    breakout_failure_indices.append(i)
        
        return {
            'false_breakout_count': false_breakouts,
            'failure_indices': breakout_failure_indices,
            'reliability_score': max(0, 100 - (false_breakouts * 20))  # Penalty for each failure
        }
    
    @staticmethod
    def detect_retest_pattern(df: pd.DataFrame, resistance_level: float) -> Dict:
        """
        Detect if stock broke out and is now retesting the breakout level
        This is often a high-probability entry point
        """
        if len(df) < 5:
            return {'is_retest': False, 'retest_quality': 'none'}
        
        # Look at last 10 candles for retest pattern
        recent_data = df.tail(10)
        
        # Find if there was a breakout in recent past
        breakout_found = False
        breakout_index = None
        
        for i in range(len(recent_data) - 2):
            if (recent_data.iloc[i]['close'] > resistance_level * 1.02 and
                recent_data.iloc[i]['volume'] > df['volume'].tail(20).mean() * 1.2):
                breakout_found = True
                breakout_index = i
                break
        
        if not breakout_found:
            return {'is_retest': False, 'retest_quality': 'none', 'days_since_breakout': None}
        
        # Check if price has come back to test the breakout level
        after_breakout = recent_data.iloc[breakout_index + 1:]
        
        if len(after_breakout) == 0:
            return {'is_retest': False, 'retest_quality': 'none', 'days_since_breakout': 0}
        
        # Retest conditions
        lowest_after_breakout = after_breakout['low'].min()
        current_price = recent_data.iloc[-1]['close']
        
        # Check if price came back near resistance (within 3%)
        is_retesting = (resistance_level * 0.97 <= lowest_after_breakout <= resistance_level * 1.03)
        
        if is_retesting:
            # Quality of retest
            current_distance = abs(current_price - resistance_level) / resistance_level
            
            # Check if holding above breakout level
            holding_above = current_price > resistance_level * 0.99
            
            # Check volume during retest (should be lower than breakout)
            breakout_volume = recent_data.iloc[breakout_index]['volume']
            retest_avg_volume = after_breakout['volume'].mean()
            volume_healthy = retest_avg_volume < breakout_volume * 0.8
            
            # Determine retest quality
            if holding_above and volume_healthy and current_distance < 0.02:
                quality = "excellent"
            elif holding_above and current_distance < 0.03:
                quality = "good"
            elif current_distance < 0.05:
                quality = "fair"
            else:
                quality = "poor"
            
            return {
                'is_retest': True,
                'retest_quality': quality,
                'days_since_breakout': len(after_breakout),
                'holding_above_level': holding_above,
                'retest_distance_pct': round(current_distance * 100, 2),
                'volume_healthy': volume_healthy
            }
        
        return {'is_retest': False, 'retest_quality': 'none', 'days_since_breakout': len(after_breakout)}
    
    @staticmethod
    def calculate_volume_metrics(df: pd.DataFrame, current_volume: float = None) -> Dict:
        """Calculate volume analysis metrics"""
        if len(df) < SMA_LONG:
            return {'insufficient_data': True}
        
        avg_volume_20 = df['volume'].tail(SMA_SHORT).mean()
        avg_volume_50 = df['volume'].tail(SMA_LONG).mean()
        
        volume_trend = "increasing" if avg_volume_20 > avg_volume_50 * 1.1 else \
                       "decreasing" if avg_volume_20 < avg_volume_50 * 0.9 else "stable"
        
        metrics = {
            'avg_volume_20d': avg_volume_20,
            'avg_volume_50d': avg_volume_50,
            'volume_trend': volume_trend,
            'volume_ratio_20_50': avg_volume_20 / avg_volume_50 if avg_volume_50 > 0 else 0,
            'sufficient_liquidity': avg_volume_20 >= MIN_AVG_VOLUME
        }
        
        if current_volume:
            metrics['current_vs_avg'] = current_volume / avg_volume_20 if avg_volume_20 > 0 else 0
        
        return metrics
    
    @staticmethod
    def analyze_price_strength(df: pd.DataFrame, breakout_level: float) -> Dict:
        """Analyze price strength and momentum"""
        if len(df) < max(SMA_LONG, RSI_PERIOD + 1):
            return {'insufficient_data': True}
        
        latest = df.iloc[-1]
        prev_close = df.iloc[-2]['close'] if len(df) >= 2 else latest['close']
        
        # Price position relative to breakout
        distance_from_breakout = (latest['close'] - breakout_level) / breakout_level * 100
        
        # Calculate momentum indicators
        sma_20 = df['close'].tail(SMA_SHORT).mean()
        sma_50 = df['close'].tail(SMA_LONG).mean()
        
        # RSI calculation with safety checks
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=RSI_PERIOD).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=RSI_PERIOD).mean()
        
        # Handle division by zero
        rs = gain / loss.replace(0, 0.001)
        rsi = 100 - (100 / (1 + rs))
        current_rsi = rsi.iloc[-1] if not rsi.empty and not np.isnan(rsi.iloc[-1]) else 50
        
        # Price action analysis
        body_size = abs(latest['close'] - latest['open'])
        candle_range = latest['high'] - latest['low']
        body_to_range = (body_size / candle_range * 100) if candle_range > 0 else 0
        
        return {
            'distance_from_breakout_pct': distance_from_breakout,
            'sma_20': sma_20,
            'sma_50': sma_50,
            'trend_alignment': 'bullish' if latest['close'] > sma_20 > sma_50 else 
                               'neutral' if latest['close'] > sma_20 else 'bearish',
            'rsi': current_rsi,
            'body_to_range_pct': body_to_range,
            'intraday_change_pct': (latest['close'] - latest['open']) / latest['open'] * 100,
            'previous_day_change_pct': (latest['close'] - prev_close) / prev_close * 100,
            'price_above_minimum': latest['close'] >= MIN_PRICE
        }
    
    @staticmethod
    def classify_breakout_quality(
        distance_pct: float,
        volume_ratio: float,
        touch_points: int,
        pattern_type: str,
        trend_alignment: str,
        rsi: float,
        false_breakout_info: Dict,
        retest_info: Dict,
        liquidity_ok: bool
    ) -> Tuple[str, int]:
        """
        Improved breakout quality classification with false breakout and retest consideration
        """
        score = 0
        
        # Distance from breakout (max 20 points)
        if retest_info.get('is_retest'):
            score += 20  # Retest is ideal entry
        elif 0 <= distance_pct <= 0.5:
            score += 18  # Perfect entry zone
        elif 0.5 < distance_pct <= 1.5:
            score += 15  # Good entry zone
        elif 1.5 < distance_pct <= 3:
            score += 10  # Acceptable
        elif distance_pct > 5:
            score += 3   # Extended
        
        # Volume confirmation (max 25 points)
        if volume_ratio >= 2.0:
            score += 25
        elif volume_ratio >= 1.5:
            score += 20
        elif volume_ratio >= 1.2:
            score += 15
        elif volume_ratio >= 0.8:
            score += 10
        else:
            score += 5
        
        # Pattern quality (max 20 points) - updated scores
        pattern_scores = {
            'tight_consolidation': 20,
            'strong_resistance': 18,
            'base_formation': 16,
            'emerging_pattern': 12,
            'weak_resistance': 8,
            'simple_high': 5
        }
        score += pattern_scores.get(pattern_type, 5)
        
        # Touch points (max 10 points)
        score += min(touch_points * 2, 10)
        
        # Trend alignment (max 10 points)
        if trend_alignment == 'bullish':
            score += 10
        elif trend_alignment == 'neutral':
            score += 5
        
        # RSI (max 5 points)
        if 50 <= rsi <= 70:
            score += 5
        elif 40 <= rsi < 50 or 70 < rsi <= 80:
            score += 3
        elif rsi < 30:
            score += 0  # Oversold, not ideal for breakout
        
        # False breakout penalty/bonus (max 10 points)
        reliability = false_breakout_info.get('reliability_score', 100)
        score += int(reliability / 10)  # Convert 0-100 to 0-10 points
        
        # Retest bonus (max 10 points)
        if retest_info.get('is_retest'):
            retest_quality = retest_info.get('retest_quality')
            retest_scores = {'excellent': 10, 'good': 7, 'fair': 4, 'poor': 2}
            score += retest_scores.get(retest_quality, 0)
        
        # Liquidity check (mandatory)
        if not liquidity_ok:
            score = int(score * 0.5)  # Halve score for low liquidity
        
        # Determine quality grade (out of 100 possible points)
        if score >= 80:
            quality = "EXCELLENT"
        elif score >= 65:
            quality = "VERY_GOOD"
        elif score >= 50:
            quality = "GOOD"
        elif score >= 35:
            quality = "FAIR"
        else:
            quality = "POOR"
        
        return quality, score


class BreakoutScanner:
    """Main scanner class integrating all components"""
    
    def __init__(self, api_key: str, access_token: str, calls_per_second: float = 3):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.rate_limiter = RateLimiter(calls_per_second)
        self.instrument_cache = InstrumentCache()
        self.analyzer = BreakoutAnalyzer()
        
    def update_instrument_cache(self):
        """Fetch and cache NSE instruments"""
        try:
            instruments = self.kite.instruments("NSE")
            self.instrument_cache.save_cache(instruments)
            logger.info("Instrument cache updated successfully")
        except Exception as e:
            logger.error(f"Failed to update instrument cache: {e}")
    
    def fetch_historical_data(self, symbol: str, days: int = 90) -> Optional[pd.DataFrame]:
        """Fetch historical data with rate limiting"""
        try:
            self.rate_limiter.wait()
            
            instrument_token = self.instrument_cache.get_instrument_token(symbol)
            if not instrument_token:
                logger.warning(f"Instrument token not found for {symbol}")
                return None
            
            to_date = datetime.now()
            from_date = to_date - timedelta(days=days)
            
            data = self.kite.historical_data(
                instrument_token,
                from_date.strftime("%Y-%m-%d"),
                to_date.strftime("%Y-%m-%d"),
                "day"
            )
            
            if not data:
                return None
            
            df = pd.DataFrame(data)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            
            return df
            
        except Exception as e:
            logger.error(f"Error fetching data for {symbol}: {e}")
            return None
    
    def scan_symbol(self, symbol: str) -> Optional[Dict]:
        """Perform comprehensive scan on a single symbol"""
        try:
            # Fetch historical data
            df = self.fetch_historical_data(symbol)
            if df is None or len(df) < SMA_LONG:
                return {
                    'symbol': symbol,
                    'status': 'insufficient_data',
                    'comment': 'Not enough historical data available'
                }
            
            # Get latest price
            latest = df.iloc[-1]
            
            # Check minimum price and liquidity filters
            volume_metrics = self.analyzer.calculate_volume_metrics(df, latest['volume'])
            
            if 'insufficient_data' in volume_metrics:
                return {
                    'symbol': symbol,
                    'status': 'insufficient_data',
                    'comment': 'Not enough data for volume analysis'
                }
            
            if latest['close'] < MIN_PRICE:
                return {
                    'symbol': symbol,
                    'status': 'filtered_out',
                    'comment': f'Price below minimum threshold (₹{MIN_PRICE})'
                }
            
            if not volume_metrics['sufficient_liquidity']:
                return {
                    'symbol': symbol,
                    'status': 'filtered_out',
                    'comment': f'Insufficient liquidity (avg vol < {MIN_AVG_VOLUME})'
                }
            
            # Find breakout level using improved clustering method
            breakout_level, touch_points, pattern_type, touch_indices = \
                self.analyzer.find_consolidation_high_clustered(df)
            
            if breakout_level is None:
                return {
                    'symbol': symbol,
                    'status': 'no_pattern',
                    'comment': 'No clear consolidation or base pattern found'
                }
            
            # Detect false breakouts
            false_breakout_info = self.analyzer.detect_false_breakouts(df, breakout_level, touch_indices)
            
            # Detect retest pattern
            retest_info = self.analyzer.detect_retest_pattern(df, breakout_level)
            
            # Analyze price strength
            strength_metrics = self.analyzer.analyze_price_strength(df, breakout_level)
            
            if 'insufficient_data' in strength_metrics:
                return {
                    'symbol': symbol,
                    'status': 'insufficient_data',
                    'comment': 'Not enough data for technical analysis'
                }
            
            # Determine if breakout has occurred
            is_breakout = latest['close'] > breakout_level
            
            # Special handling for retest
            if retest_info.get('is_retest'):
                breakout_type = "RETEST"
            elif is_breakout:
                breakout_type = "ACTIVE"
            else:
                breakout_type = "PENDING"
            
            # Classify breakout quality
            quality, score = self.analyzer.classify_breakout_quality(
                strength_metrics['distance_from_breakout_pct'],
                volume_metrics.get('current_vs_avg', volume_metrics['volume_ratio_20_50']),
                touch_points,
                pattern_type,
                strength_metrics['trend_alignment'],
                strength_metrics['rsi'],
                false_breakout_info,
                retest_info,
                volume_metrics['sufficient_liquidity']
            )
            
            # Calculate stop loss levels
            stop_loss_day_low = latest['low']
            stop_loss_3pct = breakout_level * 0.97
            recommended_stop = max(stop_loss_day_low, stop_loss_3pct)
            risk_pct = (latest['close'] - recommended_stop) / latest['close'] * 100
            
            # Generate trading comment
            comment = self._generate_trading_comment(
                breakout_type, quality, score, pattern_type, 
                touch_points, strength_metrics, volume_metrics, risk_pct,
                false_breakout_info, retest_info
            )
            
            # Compile results
            result = {
                'symbol': symbol,
                'status': breakout_type,
                'current_price': round(latest['close'], 2),
                'breakout_level': round(breakout_level, 2),
                'distance_from_breakout_pct': round(strength_metrics['distance_from_breakout_pct'], 2),
                'pattern_type': pattern_type,
                'touch_points': touch_points,
                'breakout_quality': quality,
                'quality_score': score,
                'is_retest': retest_info.get('is_retest', False),
                'retest_quality': retest_info.get('retest_quality', 'none'),
                'false_breakouts': false_breakout_info['false_breakout_count'],
                'reliability_score': false_breakout_info['reliability_score'],
                'volume_vs_20d_avg': round(volume_metrics.get('current_vs_avg', volume_metrics['volume_ratio_20_50']), 2),
                'volume_trend': volume_metrics['volume_trend'],
                'trend_alignment': strength_metrics['trend_alignment'],
                'rsi': round(strength_metrics['rsi'], 2),
                'sma_20': round(strength_metrics['sma_20'], 2),
                'sma_50': round(strength_metrics['sma_50'], 2),
                'intraday_change_pct': round(strength_metrics['intraday_change_pct'], 2),
                'recommended_stop_loss': round(recommended_stop, 2),
                'risk_pct': round(risk_pct, 2),
                'potential_reward_5pct': round(latest['close'] * 1.05, 2),
                'risk_reward_ratio': round(5.0 / risk_pct, 2) if risk_pct > 0 else 0,
                'comment': comment,
                'scan_timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error scanning {symbol}: {e}")
            return {
                'symbol': symbol,
                'status': 'error',
                'comment': f'Error during scan: {str(e)}'
            }
    
    def _generate_trading_comment(
        self, breakout_type: str, quality: str, score: int,
        pattern_type: str, touch_points: int, strength_metrics: Dict,
        volume_metrics: Dict, risk_pct: float,
        false_breakout_info: Dict, retest_info: Dict
    ) -> str:
        """Generate nuanced trading commentary with retest and false breakout info"""
        comments = []
        
        # Retest pattern takes priority
        if retest_info.get('is_retest'):
            retest_quality = retest_info.get('retest_quality')
            if retest_quality == 'excellent':
                comments.append("🎯 EXCELLENT RETEST: Price holding above breakout - high probability entry")
            elif retest_quality == 'good':
                comments.append("✅ GOOD RETEST: Price testing breakout level with healthy volume")
            elif retest_quality == 'fair':
                comments.append("⚠️ FAIR RETEST: Near breakout level but needs confirmation")
            else:
                comments.append("⚠️ WEAK RETEST: Too far from breakout level")
        else:
            # Breakout status
            if breakout_type == "ACTIVE":
                if strength_metrics['distance_from_breakout_pct'] < 1:
                    comments.append("🚀 Fresh breakout - ideal entry zone")
                elif strength_metrics['distance_from_breakout_pct'] < 3:
                    comments.append("⚡ Breakout in progress - monitor for continuation")
                else:
                    comments.append("⚠️ Extended from breakout - wait for pullback or retest")
            else:
                if strength_metrics['distance_from_breakout_pct'] > -2:
                    comments.append("👀 Approaching breakout level - prepare for entry")
                else:
                    comments.append("👁️ Below breakout - watch for setup")
        
        # False breakout warning
        if false_breakout_info['false_breakout_count'] > 0:
            comments.append(f"⚠️ WARNING: {false_breakout_info['false_breakout_count']} false breakout(s) detected - trade with caution")
        elif false_breakout_info['reliability_score'] == 100:
            comments.append("✅ Clean resistance - no false breakouts")
        
        # Pattern quality
        pattern_descriptions = {
            'tight_consolidation': f"Tight {touch_points}-touch consolidation (high probability)",
            'strong_resistance': f"Strong resistance at {touch_points} touch points (well distributed)",
            'base_formation': f"Base formation with {touch_points} tests",
            'emerging_pattern': "Emerging pattern - needs confirmation",
            'weak_resistance': f"Weak resistance ({touch_points} touches but clustered/volatile)",
            'simple_high': "Simple high - monitor for pattern development"
        }
        comments.append(pattern_descriptions.get(pattern_type, "Standard pattern"))
        
        # Volume analysis
        vol_ratio = volume_metrics.get('current_vs_avg', volume_metrics.get('volume_ratio_20_50', 0))
        if vol_ratio >= 2.0:
            comments.append("💪 Explosive volume - strong institutional interest")
        elif vol_ratio >= 1.5:
            comments.append("💪 Strong volume support - institutional interest")
        elif vol_ratio >= 1.2:
            comments.append("✅ Good volume confirmation")
        elif vol_ratio < 0.8:
            comments.append("⚠️ Low volume - needs volume confirmation on breakout")
        
        # Trend analysis
        if strength_metrics['trend_alignment'] == 'bullish':
            comments.append("📈 Bullish trend alignment - all SMAs stacked")
        elif strength_metrics['trend_alignment'] == 'neutral':
            comments.append("➡️ Neutral trend - watch for direction")
        else:
            comments.append("📉 Bearish trend - higher risk setup")
        
        # RSI analysis
        rsi = strength_metrics['rsi']
        if rsi > 70:
            comments.append("⚠️ Overbought RSI - potential consolidation ahead")
        elif 50 <= rsi <= 70:
            comments.append("✅ Healthy RSI in bullish zone")
        elif rsi < 30:
            comments.append("⚠️ Oversold - not ideal for breakout")
        
        # Risk/reward
        if risk_pct < 3:
            comments.append("✅ Tight stop - excellent risk/reward")
        elif risk_pct < 5:
            comments.append("✅ Acceptable risk level")
        else:
            comments.append("⚠️ Wide stop - size position accordingly")
        
        # Overall recommendation with retest consideration
        if retest_info.get('is_retest') and retest_info.get('retest_quality') in ['excellent', 'good']:
            comments.append("🎯 HIGH PRIORITY RETEST: Ideal entry at support (previous resistance)")
        elif quality == "EXCELLENT" and breakout_type == "ACTIVE":
            comments.append("🎯 HIGH PRIORITY: Strong buy signal with volume")
        elif quality in ["EXCELLENT", "VERY_GOOD"] and breakout_type == "PENDING":
            comments.append("📋 WATCHLIST: Add alert at breakout level")
        elif quality == "GOOD":
            comments.append("👍 DECENT SETUP: Monitor for follow-through")
        elif quality == "FAIR":
            comments.append("⚖️ MARGINAL: Wait for better confirmation")
        else:
            comments.append("❌ SKIP: Low quality setup")
        
        return " | ".join(comments)
    
    def scan_portfolio(self, symbols: List[str]) -> pd.DataFrame:
        """Scan multiple symbols and return results"""
        results = []
        total = len(symbols)
        
        logger.info(f"Starting scan of {total} symbols...")
        
        for i, symbol in enumerate(symbols, 1):
            logger.info(f"Scanning {symbol} ({i}/{total})...")
            result = self.scan_symbol(symbol)
            if result:
                results.append(result)
            
            # Progress update every 50 symbols
            if i % 50 == 0:
                logger.info(f"Progress: {i}/{total} symbols scanned")
        
        df = pd.DataFrame(results)
        
        # Sort by quality score (descending)
        if 'quality_score' in df.columns:
            df = df.sort_values('quality_score', ascending=False)
        
        return df


def main():
    """Main execution function"""
    
    # Configuration - MOVE THESE TO ENVIRONMENT VARIABLES IN PRODUCTION
    API_KEY = "3bi2yh8g830vq3y6"
    ACCESS_TOKEN = "m4wusZxFGJff3P7P6c3rQzEe2o6Awpn6"
    INPUT_CSV = "data/Stage2Shortlist.csv"
    OUTPUT_CSV = f"chartist_breakout_scan_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    CALLS_PER_SECOND = 3  # Adjust based on your API limits
    
    # Initialize scanner
    logger.info("Initializing Breakout Scanner...")
    scanner = BreakoutScanner(API_KEY, ACCESS_TOKEN, CALLS_PER_SECOND)
    
    # Update instrument cache (do this once daily)
    # Uncomment the line below on first run or to update cache
    scanner.update_instrument_cache()
    
    # Read symbols from CSV
    try:
        symbols_df = pd.read_csv(INPUT_CSV)
        # Fixed: Check for 'Symbol' with capital S
        if 'Symbol' in symbols_df.columns:
            symbols = symbols_df['Symbol'].tolist()
        elif 'symbol' in symbols_df.columns:
            symbols = symbols_df['symbol'].tolist()
        else:
            symbols = symbols_df.iloc[:, 0].tolist()
        
        logger.info(f"Loaded {len(symbols)} symbols from {INPUT_CSV}")
    except Exception as e:
        logger.error(f"Error reading input CSV: {e}")
        return
    
    # Run scan
    start_time = time.time()
    results_df = scanner.scan_portfolio(symbols)
    elapsed_time = time.time() - start_time
    
    # Save results
    results_df.to_csv(OUTPUT_CSV, index=False)
    logger.info(f"Scan completed in {elapsed_time:.2f} seconds")
    logger.info(f"Results saved to {OUTPUT_CSV}")
    
    # Print summary statistics
    print("\n" + "="*80)
    print("SCAN SUMMARY")
    print("="*80)
    
    if not results_df.empty:
        breakouts = results_df[results_df['status'] == 'ACTIVE']
        retests = results_df[results_df['status'] == 'RETEST']
        excellent = results_df[results_df['breakout_quality'] == 'EXCELLENT']
        very_good = results_df[results_df['breakout_quality'] == 'VERY_GOOD']
        
        print(f"Total symbols scanned: {len(results_df)}")
        print(f"Active breakouts: {len(breakouts)}")
        print(f"Retest opportunities: {len(retests)}")
        print(f"Excellent quality: {len(excellent)}")
        print(f"Very good quality: {len(very_good)}")
        
        # Show retests first (highest priority)
        excellent_retests = results_df[
            (results_df['breakout_quality'].isin(['EXCELLENT', 'VERY_GOOD'])) & 
            (results_df['status'] == 'RETEST')
        ]
        
        if len(excellent_retests) > 0:
            print("\n🎯 TOP RETEST OPPORTUNITIES:")
            print("-" * 80)
            for _, row in excellent_retests.head(10).iterrows():
                print(f"{row['symbol']:15} | Score: {row['quality_score']:3.0f} | "
                      f"Price: ₹{row['current_price']:8.2f} | "
                      f"Risk: {row['risk_pct']:4.1f}% | Retest: {row['retest_quality']}")
        
        # Show excellent quality breakouts
        if len(excellent) > 0:
            print("\n🎯 TOP OPPORTUNITIES (EXCELLENT Quality):")
            print("-" * 80)
            for _, row in excellent.head(10).iterrows():
                status_icon = "🎯" if row['status'] == 'RETEST' else "🚀" if row['status'] == 'ACTIVE' else "👀"
                print(f"{status_icon} {row['symbol']:15} | Score: {row['quality_score']:3.0f} | "
                      f"Price: ₹{row['current_price']:8.2f} | "
                      f"Risk: {row['risk_pct']:4.1f}% | {row['pattern_type']}")
                if row.get('false_breakouts', 0) > 0:
                    print(f"   ⚠️  Warning: {row['false_breakouts']} false breakout(s)")
        
        # Statistics on false breakouts
        with_false_breakouts = results_df[results_df.get('false_breakouts', 0) > 0]
        print(f"\n⚠️ Patterns with false breakouts: {len(with_false_breakouts)}")
        
        # Pattern type distribution
        print("\n📊 Pattern Distribution:")
        if 'pattern_type' in results_df.columns:
            pattern_counts = results_df['pattern_type'].value_counts()
            for pattern, count in pattern_counts.items():
                print(f"  {pattern}: {count}")
    
    print("="*80 + "\n")


if __name__ == "__main__":
    main()