import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
from scipy import stats
from typing import List, Dict, Optional, Tuple
from kiteconnect import KiteConnect
import logging
import time

warnings.filterwarnings('ignore')

class KiteAVWAPScanner:
    def __init__(self, api_key: str, access_token: str, lookback_years=4, min_consolidation_weeks=10, volume_threshold=100000):
        """
        Advanced AVWAP Scanner using Kite Connect API
        
        Parameters:
        - api_key: Your Kite Connect API key
        - access_token: Your access token
        - lookback_years: Years to look back for historical analysis
        - min_consolidation_weeks: Minimum weeks for consolidation pattern
        - volume_threshold: Minimum average volume for liquidity filter
        """
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.instrument_cache = self._load_instrument_cache()
        self.lookback_years = lookback_years
        self.min_consolidation_weeks = min_consolidation_weeks
        self.volume_threshold = volume_threshold
        
        # Test connection
        try:
            self.kite.profile()
            print("✅ Kite Connect API connected successfully!")
        except Exception as e:
            print(f"❌ Kite Connect API connection failed: {e}")
            raise

    def _load_instrument_cache(self):
        print("📦 Loading NSE instrument list into memory...")
        instruments = self.kite.instruments("NSE")
        cache = {inst["tradingsymbol"]: inst["instrument_token"] for inst in instruments}
        print(f"✅ Loaded {len(cache)} NSE instruments into cache.")
        return cache

    def get_instrument_token(self, symbol):
        """Fetch instrument token from cache instead of making API calls."""
        return self.instrument_cache.get(symbol)
    
    def get_historical_data(self, instrument_token: str, from_date: datetime, to_date: datetime) -> pd.DataFrame:
        """
        Fetch historical data from Kite Connect
        """
        try:
            # Fetch weekly data
            records = self.kite.historical_data(
                instrument_token=instrument_token,
                from_date=from_date,
                to_date=to_date,
                interval="week"
            )
            
            if not records:
                return pd.DataFrame()
            
            # Convert to DataFrame
            df = pd.DataFrame(records)
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            
            # Rename columns to match our analysis
            df = df.rename(columns={
                'open': 'Open',
                'high': 'High', 
                'low': 'Low',
                'close': 'Close',
                'volume': 'Volume'
            })
            
            return df
            
        except Exception as e:
            print(f"Error fetching data for {instrument_token}: {e}")
            return pd.DataFrame()
    
    def get_instrument_token(self, tradingsymbol: str, exchange: str = "NSE") -> Optional[str]:
        """
        Get instrument token for a trading symbol
        """
        try:
            # Get all instruments (cache this in production)
            instruments = self.kite.instruments(exchange)
            instrument_df = pd.DataFrame(instruments)
            
            # Find matching instrument
            match = instrument_df[
                (instrument_df['tradingsymbol'] == tradingsymbol) & 
                (instrument_df['segment'] == exchange)
            ]
            
            if len(match) > 0:
                return match.iloc[0]['instrument_token']
            else:
                print(f"⚠️ Instrument {tradingsymbol} not found in {exchange}")
                return None
                
        except Exception as e:
            print(f"Error getting instrument token for {tradingsymbol}: {e}")
            return None
    
    def calculate_dynamic_avwap(self, data: pd.DataFrame, anchor_date: pd.Timestamp) -> Dict:
        """
        Calculate enhanced AVWAP with multiple timeframe analysis
        """
        anchor_data = data[data.index >= anchor_date].copy()
        
        if len(anchor_data) < 5:
            return None
            
        # Multiple typical price calculations for robustness
        anchor_data['typical_price'] = (anchor_data['High'] + anchor_data['Low'] + anchor_data['Close']) / 3
        anchor_data['hlc2'] = (anchor_data['High'] + anchor_data['Low']) / 2
        anchor_data['ohlc4'] = (anchor_data['Open'] + anchor_data['High'] + anchor_data['Low'] + anchor_data['Close']) / 4
        
        # Volume-weighted calculations
        anchor_data['cum_volume'] = anchor_data['Volume'].cumsum()
        anchor_data['cum_vol_price'] = (anchor_data['Volume'] * anchor_data['typical_price']).cumsum()
        anchor_data['avwap'] = anchor_data['cum_vol_price'] / anchor_data['cum_volume']
        
        # Standard deviation bands
        anchor_data['price_vol_sq'] = anchor_data['Volume'] * (anchor_data['typical_price'] ** 2)
        anchor_data['cum_price_vol_sq'] = anchor_data['price_vol_sq'].cumsum()
        
        variance = (anchor_data['cum_price_vol_sq'] / anchor_data['cum_volume']) - (anchor_data['avwap'] ** 2)
        anchor_data['avwap_std'] = np.sqrt(np.maximum(variance, 0))
        
        # AVWAP bands
        current_avwap = anchor_data['avwap'].iloc[-1]
        current_std = anchor_data['avwap_std'].iloc[-1]
        
        return {
            'avwap': current_avwap,
            'upper_band_1': current_avwap + (1 * current_std),
            'lower_band_1': current_avwap - (1 * current_std),
            'upper_band_2': current_avwap + (2 * current_std),
            'lower_band_2': current_avwap - (2 * current_std),
            'std_dev': current_std,
            'weeks_from_anchor': len(anchor_data),
            'volume_profile': self._calculate_volume_profile(anchor_data)
        }
    
    def _calculate_volume_profile(self, data: pd.DataFrame) -> Dict:
        """
        Calculate volume profile for better entry timing
        """
        # Volume distribution analysis
        price_ranges = pd.cut(data['typical_price'], bins=20)
        volume_by_price = data.groupby(price_ranges)['Volume'].sum()
        
        # Point of Control (POC) - price level with highest volume
        poc_range = volume_by_price.idxmax()
        poc_price = poc_range.mid
        
        # Volume-weighted average price concentration
        total_volume = data['Volume'].sum()
        high_volume_threshold = total_volume * 0.7  # 70% of volume
        
        return {
            'poc_price': poc_price,
            'volume_concentration': volume_by_price.max() / total_volume,
            'price_acceptance': len(volume_by_price[volume_by_price > volume_by_price.quantile(0.6)])
        }
    
    def identify_significant_lows(self, data: pd.DataFrame) -> List[Dict]:
        """
        Identify multiple significant lows with strength scoring
        """
        # Enhanced swing low detection
        window = 7  # Weekly data, so 7 weeks lookback/forward
        data['local_min'] = data['Low'].rolling(window=window*2+1, center=True).min()
        data['is_swing_low'] = (data['Low'] == data['local_min']) & (data['Low'].shift(window) > data['Low']) & (data['Low'].shift(-window) > data['Low'])
        
        swing_lows = []
        
        for idx in data[data['is_swing_low']].index:
            low_price = data.loc[idx, 'Low']
            
            # Calculate swing low strength
            volume_strength = data.loc[idx, 'Volume'] / data['Volume'].rolling(20).mean().loc[idx] if data['Volume'].rolling(20).mean().loc[idx] > 0 else 1
            
            # Price reaction strength (how much it bounced)
            future_data = data.loc[idx:]
            if len(future_data) > 8:
                future_high = future_data.head(8)['High'].max()
            else:
                future_high = future_data['High'].max()
            bounce_strength = (future_high - low_price) / low_price * 100 if low_price > 0 else 0
            
            # Time-based relevance (more recent lows get higher score)
            weeks_ago = len(data) - data.index.get_loc(idx)
            recency_score = max(0, 100 - weeks_ago * 2)  # Decay over time
            
            # Overall strength score
            strength_score = (volume_strength * 30) + (bounce_strength * 0.5) + (recency_score * 0.5)
            
            swing_lows.append({
                'date': idx,
                'price': low_price,
                'volume_strength': volume_strength,
                'bounce_strength': bounce_strength,
                'recency_score': recency_score,
                'overall_strength': strength_score
            })
        
        # Sort by strength and return top candidates
        swing_lows.sort(key=lambda x: x['overall_strength'], reverse=True)
        return swing_lows[:3]  # Top 3 significant lows
    
    def analyze_consolidation_quality(self, data: pd.DataFrame, weeks_back: int = 26) -> Dict:
        """
        Advanced consolidation pattern analysis
        """
        recent_data = data.tail(weeks_back)
        
        if len(recent_data) < self.min_consolidation_weeks:
            return {'is_quality_consolidation': False, 'reason': 'Insufficient data'}
        
        # Price metrics
        highs = recent_data['High']
        lows = recent_data['Low']
        closes = recent_data['Close']
        
        # Consolidation range analysis
        range_high = highs.max()
        range_low = lows.min()
        range_pct = ((range_high - range_low) / range_low) * 100 if range_low > 0 else 0
        
        # Price distribution within range
        price_std = closes.std()
        price_mean = closes.mean()
        coefficient_of_variation = price_std / price_mean * 100 if price_mean > 0 else 0
        
        # Volume analysis during consolidation
        volumes = recent_data['Volume']
        volume_trend = np.polyfit(range(len(volumes)), volumes.values, 1)[0] if len(volumes) > 1 else 0
        volume_consistency = volumes.std() / volumes.mean() * 100 if volumes.mean() > 0 else 0
        
        # Breakout probability indicators
        recent_closes = closes.tail(5)
        position_in_range = (recent_closes.mean() - range_low) / (range_high - range_low) * 100 if range_high > range_low else 50
        
        # Support/Resistance strength
        support_threshold = range_low + (range_high - range_low) * 0.03
        resistance_threshold = range_high - (range_high - range_low) * 0.03
        
        support_tests = sum(1 for low in lows.tail(13) if low <= support_threshold)
        resistance_tests = sum(1 for high in highs.tail(13) if high >= resistance_threshold)
        
        # Quality scoring
        quality_score = 0
        quality_reasons = []
        
        # Range criteria (15-45% is ideal for swing trading)
        if 15 <= range_pct <= 45:
            quality_score += 25
            quality_reasons.append(f"Good range: {range_pct:.1f}%")
        elif range_pct < 15:
            quality_score += 10
            quality_reasons.append(f"Tight range: {range_pct:.1f}%")
        
        # Volume criteria
        if volume_trend > 0:  # Increasing volume during consolidation
            quality_score += 20
            quality_reasons.append("Increasing volume")
        elif volume_trend > -volumes.mean() * 0.1:  # Stable volume
            quality_score += 15
            quality_reasons.append("Stable volume")
        
        # Support/resistance tests
        if support_tests >= 2:
            quality_score += 15
            quality_reasons.append(f"Strong support ({support_tests} tests)")
        if resistance_tests >= 2:
            quality_score += 15
            quality_reasons.append(f"Strong resistance ({resistance_tests} tests)")
        
        # Position in range (prefer middle to upper-middle)
        if 40 <= position_in_range <= 70:
            quality_score += 15
            quality_reasons.append(f"Good position: {position_in_range:.0f}%")
        
        # Volatility consistency
        if coefficient_of_variation < 8:  # Low volatility
            quality_score += 10
            quality_reasons.append("Low volatility")
        
        return {
            'is_quality_consolidation': quality_score >= 60,
            'quality_score': quality_score,
            'range_pct': range_pct,
            'position_in_range': position_in_range,
            'support_tests': support_tests,
            'resistance_tests': resistance_tests,
            'volume_trend': volume_trend,
            'volume_consistency': volume_consistency,
            'coefficient_of_variation': coefficient_of_variation,
            'quality_reasons': quality_reasons,
            'weeks_analyzed': len(recent_data)
        }
    
    def calculate_risk_reward_metrics(self, current_price: float, avwap_data: Dict, historical_lows: List[Dict], consolidation_data: Dict) -> Dict:
        """
        Calculate comprehensive risk-reward metrics
        """
        if not avwap_data or not historical_lows:
            return {}
        
        avwap = avwap_data['avwap']
        best_low = historical_lows[0]  # Strongest historical low
        
        # AVWAP positioning
        avwap_distance = ((current_price - avwap) / avwap) * 100 if avwap > 0 else 0
        
        # Risk metrics (downside potential)
        support_level = best_low['price'] * 1.05  # 5% buffer above historical low
        risk_pct = ((current_price - support_level) / current_price) * 100 if current_price > support_level else 0
        
        # Reward metrics (upside potential)
        if consolidation_data.get('is_quality_consolidation'):
            # Use consolidation high as target
            resistance_level = current_price * (1 + consolidation_data['range_pct'] / 200)  # Conservative target
        else:
            # Use AVWAP upper band as target
            resistance_level = avwap_data.get('upper_band_2', avwap * 1.2)
        
        reward_pct = ((resistance_level - current_price) / current_price) * 100 if current_price > 0 else 0
        
        # Risk-reward ratio
        risk_reward_ratio = reward_pct / risk_pct if risk_pct > 0 else float('inf')
        
        # AVWAP band positioning
        if current_price <= avwap_data.get('lower_band_2', avwap * 0.9):
            band_position = "Oversold (Below -2σ)"
            position_score = 100
        elif current_price <= avwap_data.get('lower_band_1', avwap * 0.95):
            band_position = "Undervalued (Below -1σ)"
            position_score = 85
        elif current_price <= avwap:
            band_position = "Below AVWAP"
            position_score = 70
        elif current_price <= avwap_data.get('upper_band_1', avwap * 1.05):
            band_position = "Above AVWAP"
            position_score = 50
        else:
            band_position = "Extended"
            position_score = 20
        
        # Value assessment
        avwap_premium = ((avwap - best_low['price']) / best_low['price']) * 100 if best_low['price'] > 0 else 0
        current_premium = ((current_price - best_low['price']) / best_low['price']) * 100 if best_low['price'] > 0 else 0
        
        # Overall buy score (0-100)
        buy_score = 0
        
        # Position scoring (40 points max)
        buy_score += min(position_score * 0.4, 40)
        
        # Risk-reward scoring (30 points max)
        if risk_reward_ratio > 3:
            buy_score += 30
        elif risk_reward_ratio > 2:
            buy_score += 25
        elif risk_reward_ratio > 1.5:
            buy_score += 20
        elif risk_reward_ratio > 1:
            buy_score += 15
        
        # Consolidation quality (20 points max)
        if consolidation_data.get('is_quality_consolidation'):
            buy_score += min(consolidation_data['quality_score'] * 0.2, 20)
        
        # Historical low strength (10 points max)
        buy_score += min(best_low.get('overall_strength', 50) * 0.1, 10)
        
        return {
            'avwap_distance': round(avwap_distance, 2),
            'risk_pct': round(risk_pct, 2),
            'reward_pct': round(reward_pct, 2),
            'risk_reward_ratio': round(risk_reward_ratio, 2),
            'band_position': band_position,
            'position_score': round(position_score, 1),
            'buy_score': round(buy_score, 1),
            'support_level': round(support_level, 2),
            'target_level': round(resistance_level, 2),
            'avwap_premium': round(avwap_premium, 2),
            'current_premium': round(current_premium, 2),
            'value_gap': round(avwap_premium - (current_premium - avwap_premium), 2) if avwap_premium > 0 else 0
        }
    
    def scan_stock_detailed(self, tradingsymbol: str) -> Optional[Dict]:
        """
        Comprehensive stock analysis using Kite Connect
        """
        try:
            # Get instrument token
            instrument_token = self.get_instrument_token(tradingsymbol)
            if not instrument_token:
                return None
            
            # Fetch historical data
            end_date = datetime.now()
            start_date = end_date - timedelta(days=self.lookback_years * 365)
            
            data = self.get_historical_data(instrument_token, start_date, end_date)
            
            if len(data) < 52:  # At least 1 year of data
                return None
            
            # Basic filters
            avg_volume = data['Volume'].tail(20).mean()
            if avg_volume < self.volume_threshold:
                return None
            
            current_price = data['Close'].iloc[-1]
            if current_price < 10:  # Penny stock filter
                return None
            
            # Core analysis
            historical_lows = self.identify_significant_lows(data)
            if not historical_lows:
                return None
            
            best_low = historical_lows[0]
            avwap_data = self.calculate_dynamic_avwap(data, best_low['date'])
            
            if not avwap_data:
                return None
            
            consolidation_analysis = self.analyze_consolidation_quality(data)
            risk_reward_metrics = self.calculate_risk_reward_metrics(
                current_price, avwap_data, historical_lows, consolidation_analysis
            )
            
            # Additional technical indicators
            data['sma_10'] = data['Close'].rolling(10).mean()
            data['sma_20'] = data['Close'].rolling(20).mean()
            data['sma_50'] = data['Close'].rolling(50).mean()
            data['rsi'] = self._calculate_rsi(data['Close'], 14)
            
            # Trend analysis
            short_trend = "Bullish" if data['sma_10'].iloc[-1] > data['sma_20'].iloc[-1] else "Bearish"
            long_trend = "Bullish" if data['sma_20'].iloc[-1] > data['sma_50'].iloc[-1] else "Bearish"
            
            # Volume analysis
            volume_sma = data['Volume'].rolling(20).mean()
            volume_trend = "Increasing" if data['Volume'].tail(5).mean() > volume_sma.iloc[-1] else "Decreasing"
            
            # Get current market data
            try:
                quote = self.kite.quote([f"NSE:{tradingsymbol}"])
                current_data = quote.get(f"NSE:{tradingsymbol}", {})
                
                # Real-time metrics
                day_change = current_data.get('net_change', 0)
                day_change_pct = current_data.get('last_price', current_price) / current_data.get('last_price', current_price) * 100 - 100 if current_data.get('last_price') else 0
                
            except Exception as e:
                day_change = 0
                day_change_pct = 0
            
            # Compile results
            result = {
                # Basic info
                'symbol': tradingsymbol,
                'current_price': round(current_price, 2),
                'day_change': round(day_change, 2),
                'day_change_pct': round(day_change_pct, 2),
                'avg_volume_20w': int(avg_volume),
                
                # AVWAP analysis
                'avwap': round(avwap_data['avwap'], 2),
                'avwap_upper_1': round(avwap_data['upper_band_1'], 2),
                'avwap_lower_1': round(avwap_data['lower_band_1'], 2),
                'weeks_from_anchor': avwap_data['weeks_from_anchor'],
                
                # Historical context
                'best_low_price': round(best_low['price'], 2),
                'best_low_date': best_low['date'].strftime('%Y-%m-%d'),
                'low_strength_score': round(best_low['overall_strength'], 1),
                
                # Consolidation quality
                'is_consolidating': consolidation_analysis['is_quality_consolidation'],
                'consolidation_score': consolidation_analysis['quality_score'],
                'consolidation_range': round(consolidation_analysis['range_pct'], 1),
                'position_in_range': round(consolidation_analysis['position_in_range'], 1),
                'support_tests': consolidation_analysis['support_tests'],
                
                # Risk-reward metrics
                **risk_reward_metrics,
                
                # Technical indicators
                'rsi': round(data['rsi'].iloc[-1], 1),
                'short_trend': short_trend,
                'long_trend': long_trend,
                'volume_trend': volume_trend,
                
                # Final assessment
                'investment_grade': self._get_investment_grade(risk_reward_metrics.get('buy_score', 0))
            }
            
            return result
            
        except Exception as e:
            print(f"Error analyzing {tradingsymbol}: {str(e)}")
            return None
    
    def _calculate_rsi(self, prices: pd.Series, window: int = 14) -> pd.Series:
        """Calculate RSI"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))
    
    def _get_investment_grade(self, score: float) -> str:
        """Convert buy score to investment grade"""
        if score >= 80:
            return "A+ (Strong Buy)"
        elif score >= 70:
            return "A (Buy)"
        elif score >= 60:
            return "B+ (Moderate Buy)"
        elif score >= 50:
            return "B (Watch)"
        elif score >= 40:
            return "C (Neutral)"
        else:
            return "D (Avoid)"
    
    def scan_portfolio(self, symbols: List[str]) -> pd.DataFrame:
        """
        Scan multiple stocks with detailed analysis using Kite Connect
        """
        results = []
        total_symbols = len(symbols)
        
        print(f"🔍 Scanning {total_symbols} stocks with Kite Connect AVWAP analysis...")
        print("=" * 70)
        
        for i, symbol in enumerate(symbols, 1):
            try:
                print(f"📈 Processing {symbol} ({i}/{total_symbols})")
                result = self.scan_stock_detailed(symbol)
            except Exception as e:
                print(f"❌ Error processing {symbol}: {str(e)}")
                time.sleep(0.4)  # ~2.5 requests/sec
                continue
            
            if result and result.get('buy_score', 0) > 30:  # Only include promising candidates
                results.append(result)
                print(f"   ✅ Added - Score: {result['buy_score']:.1f}, Grade: {result['investment_grade']}")
            else:
                print(f"   ❌ Filtered out")
        
        print("=" * 70)
        
        if not results:
            return pd.DataFrame()
        
        df = pd.DataFrame(results)
        
        # Sort by buy score and other factors
        df = df.sort_values([
            'buy_score',
            'risk_reward_ratio',
            'is_consolidating'
        ], ascending=[False, False, False])
        
        return df.reset_index(drop=True)
    
    def display_top_opportunities(self, df: pd.DataFrame, top_n: int = 8):
        """
        Display formatted results with rich details
        """
        if len(df) == 0:
            print("❌ No qualifying opportunities found.")
            return
        
        print(f"\n🎯 TOP {min(top_n, len(df))} KITE CONNECT AVWAP OPPORTUNITIES")
        print("=" * 120)
        
        for i, (_, row) in enumerate(df.head(top_n).iterrows(), 1):
            # Header
            grade_emoji = {"A+": "🟢", "A": "🟢", "B+": "🟡", "B": "🟡", "C": "🔴", "D": "🔴"}.get(row['investment_grade'][:2], "⚪")
            day_emoji = "📈" if row.get('day_change_pct', 0) > 0 else "📉" if row.get('day_change_pct', 0) < 0 else "➡️"
            print(f"\n{grade_emoji} #{i}. {row['symbol']} - {row['investment_grade']}")
            
            # Price and AVWAP info
            print(f"💰 Current: ₹{row['current_price']} {day_emoji}({row.get('day_change_pct', 0):+.1f}%) | AVWAP: ₹{row['avwap']} | Distance: {row['avwap_distance']:+.1f}%")
            print(f"📊 Band Position: {row['band_position']} | Historical Low: ₹{row['best_low_price']} ({row['best_low_date']})")
            
            # Risk-Reward
            print(f"⚖️  Risk: {row['risk_pct']:.1f}% | Reward: {row['reward_pct']:.1f}% | R:R = 1:{row['risk_reward_ratio']:.1f}")
            print(f"🎯 Support: ₹{row['support_level']} | Target: ₹{row['target_level']}")
            
            # Consolidation and Technical
            consol_status = "✅ High Quality" if row['is_consolidating'] else "⚠️ No Clear Pattern"
            print(f"📈 Consolidation: {consol_status} (Score: {row['consolidation_score']}/100)")
            print(f"🔄 Trends: {row['short_trend']} (10w) | {row['long_trend']} (50w) | RSI: {row['rsi']}")
            print(f"📊 Volume: {row['volume_trend']} | Tests - Support: {row['support_tests']}")
            
            # Investment summary
            if row['buy_score'] >= 70 and row['risk_reward_ratio'] > 2:
                action = "🚀 STRONG BUY CANDIDATE"
            elif row['buy_score'] >= 60 and row['risk_reward_ratio'] > 1.5:
                action = "📈 GOOD BUY OPPORTUNITY"
            elif row['buy_score'] >= 50:
                action = "👀 WATCH CLOSELY"
            else:
                action = "⏳ WAIT FOR BETTER SETUP"
            
            print(f"🎯 Action: {action} | Overall Score: {row['buy_score']:.1f}/100")
            print("-" * 120)
        
        # Summary statistics
        avg_score = df.head(top_n)['buy_score'].mean()
        avg_rr = df.head(top_n)['risk_reward_ratio'].mean()
        consolidating_count = df.head(top_n)['is_consolidating'].sum()
        
        print(f"\n📊 SUMMARY:")
        print(f"Average Score: {avg_score:.1f}/100 | Average R:R: 1:{avg_rr:.1f} | Quality Consolidations: {consolidating_count}/{min(top_n, len(df))}")

# Example usage with Kite Connect API
if __name__ == "__main__":
    import os
    
    # === USER CONFIG ===
    API_KEY = os.getenv("KITE_API_KEY", "3bi2yh8g830vq3y6")
    ACCESS_TOKEN = os.getenv("KITE_ACCESS_TOKEN", "qkrCLxrB5IjP39TbN3cN3pzvmorUKIqO")
    SYMBOLS_CSV = "data/FNOStock.csv"  # CSV with column 'symbol'
    LOOKBACK_YEARS = 4
    MIN_CONSOLIDATION_WEEKS = 10
    VOLUME_THRESHOLD = 100000
    TOP_N_RESULTS = 8
    OUTPUT_FILE = "kite_avwap_scan_results.csv"

    # === Logging setup ===
    logging.basicConfig(
        filename="kite_avwap_scanner.log",
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s"
    )
    
    try:
        # Load symbols list
        if not os.path.exists(SYMBOLS_CSV):
            raise FileNotFoundError(f"❌ Symbols CSV '{SYMBOLS_CSV}' not found.")
        
        symbols_df = pd.read_csv(SYMBOLS_CSV)
        if 'Symbol' not in symbols_df.columns:
            raise ValueError("❌ 'Symbol' column not found in CSV.")
        
        symbols_list = symbols_df['Symbol'].dropna().unique().tolist()
        if not symbols_list:
            raise ValueError("❌ No valid symbols found in CSV.")

        # Init scanner
        scanner = KiteAVWAPScanner(
            api_key=API_KEY,
            access_token=ACCESS_TOKEN,
            lookback_years=LOOKBACK_YEARS,
            min_consolidation_weeks=MIN_CONSOLIDATION_WEEKS,
            volume_threshold=VOLUME_THRESHOLD
        )

        # Scan portfolio
        results_df = scanner.scan_portfolio(symbols_list)

        if not results_df.empty:
            # Save to CSV
            results_df.to_csv(OUTPUT_FILE, index=False)
            print(f"\n📁 Results saved to: {OUTPUT_FILE}")
            
            # Display top N
            scanner.display_top_opportunities(results_df, top_n=TOP_N_RESULTS)
        else:
            print("\n❌ No qualifying opportunities found.")

    except Exception as e:
        logging.error(f"Main execution failed: {e}", exc_info=True)
        print(f"❌ ERROR: {e}")
