import pandas as pd
import numpy as np
import logging
import time
from kiteconnect import KiteConnect
from datetime import datetime, timedelta
import os
from pathlib import Path
import csv
import json
from typing import Dict, List, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('stage_analysis.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Constants
API_KEY = "3bi2yh8g830vq3y6"
API_SECRET = "r391yM3HcLLx0J20ZyeXvDtquXQc4jOK"
ACCESS_TOKEN = "YqgeaKQ3o9144fk9LZEUyH6Y5J8gcrP2"
SYMBOLS_CSV = "data/MCAP-great2500.csv"
OUTPUT_CSV = os.path.join("data", f"StainWeinsteinStagev2Cluade_analysis_output_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")
DETAILED_OUTPUT_CSV = os.path.join("data", f"detailed_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv")

# Analysis Parameters
WEEKS_OF_DATA = 112  # 2 years
RATE_LIMIT_DELAY = 0.34  # 3 requests/second
MA_PERIODS = [10, 20, 30, 50]  # Multiple MA periods
VOLUME_MA_PERIOD = 10
RS_INDEX = "NIFTYBEES"
SUPPORT_RESISTANCE_WINDOW = 52
BREAKOUT_THRESHOLD = 1.02
BREAKDOWN_THRESHOLD = 0.98
VCP_WEEKS = 30
VCP_CONTRACTION_THRESHOLD = 0.8
BASE_VOLUME_THRESHOLD = 1.2
LOW_LIQUIDITY_VOLUME_THRESHOLD = 1.1
LIQUIDITY_CUTOFF = 1e6
MIN_PRICE = 10  # Minimum stock price for analysis
MAX_RETRIES = 3  # API retry attempts

class EnhancedStageAnalysisScanner:
    def __init__(self, api_key: str, access_token: str, symbols_csv: str, output_csv: str):
        self.kite = KiteConnect(api_key=api_key)
        self.kite.set_access_token(access_token)
        self.symbols_csv = symbols_csv
        self.output_csv = output_csv
        self.detailed_output_csv = DETAILED_OUTPUT_CSV
        self.instruments_cache = None
        self.results = []
        self.detailed_results = []
        self.rate_limit_delay = RATE_LIMIT_DELAY
        self.failed_symbols = []
        
    def load_instruments(self) -> None:
        """Cache instrument tokens with retry logic."""
        for attempt in range(MAX_RETRIES):
            try:
                logger.info(f"Fetching instruments (attempt {attempt + 1}/{MAX_RETRIES})...")
                instruments = self.kite.instruments(exchange="NSE")
                self.instruments_cache = pd.DataFrame(instruments)
                # Create lookup dictionary for faster access
                self.token_lookup = dict(zip(
                    self.instruments_cache['tradingsymbol'], 
                    self.instruments_cache['instrument_token']
                ))
                logger.info(f"Cached {len(self.instruments_cache)} instruments successfully.")
                return
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed: {e}")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                else:
                    logger.error("Failed to fetch instruments after all retries")
                    raise

    def get_instrument_token(self, symbol: str) -> Optional[int]:
        """Retrieve instrument token from cache with fallback."""
        if self.instruments_cache is None:
            self.load_instruments()
        
        # Try direct lookup first (faster)
        if hasattr(self, 'token_lookup') and symbol in self.token_lookup:
            return self.token_lookup[symbol]
        
        # Fallback to DataFrame query
        tokens = self.instruments_cache[
            (self.instruments_cache['tradingsymbol'] == symbol) &
            (self.instruments_cache['exchange'] == 'NSE')
        ]['instrument_token'].values
        
        return tokens[0] if len(tokens) > 0 else None

    def fetch_historical_data(self, instrument_token: int, interval: str = "week") -> Optional[pd.DataFrame]:
        """Fetch historical data with enhanced error handling and validation."""
        for attempt in range(MAX_RETRIES):
            try:
                to_date = datetime.now()
                from_date = to_date - timedelta(weeks=WEEKS_OF_DATA)
                
                data = self.kite.historical_data(
                    instrument_token=instrument_token,
                    from_date=from_date.strftime('%Y-%m-%d'),
                    to_date=to_date.strftime('%Y-%m-%d'),
                    interval=interval
                )
                
                time.sleep(self.rate_limit_delay)
                
                if not data:
                    logger.warning(f"No data returned for token {instrument_token}")
                    return None
                
                df = pd.DataFrame(data)
                if df.empty:
                    return None
                
                # Data validation and cleaning
                df['date'] = pd.to_datetime(df['date'])
                df = df.sort_values('date').reset_index(drop=True)
                
                # Remove rows with zero/negative prices or volumes
                df = df[(df['close'] > 0) & (df['volume'] > 0) & (df['high'] >= df['low'])]
                
                if len(df) < 30:  # Minimum data points required
                    logger.warning(f"Insufficient data points ({len(df)}) for token {instrument_token}")
                    return None
                
                return df[['date', 'open', 'high', 'low', 'close', 'volume']]
                
            except Exception as e:
                logger.warning(f"Attempt {attempt + 1} failed for token {instrument_token}: {e}")
                if attempt < MAX_RETRIES - 1:
                    time.sleep(2 ** attempt)
                else:
                    logger.error(f"Failed to fetch data for token {instrument_token} after all retries")
                    return None

    def calculate_enhanced_indicators(self, df: pd.DataFrame) -> pd.DataFrame:
        """Calculate comprehensive technical indicators."""
        # Multiple moving averages
        for period in MA_PERIODS:
            df[f'ma{period}'] = df['close'].rolling(window=period, min_periods=period//2).mean()
            df[f'ma{period}_slope'] = df[f'ma{period}'].diff()
        
        # Volume indicators
        df['volume_ma'] = df['volume'].rolling(window=VOLUME_MA_PERIOD, min_periods=VOLUME_MA_PERIOD//2).mean()
        df['volume_surge'] = df['volume'] / df['volume_ma']
        df['volume_avg_20'] = df['volume'].rolling(window=20, min_periods=10).mean()
        
        # Price momentum
        df['roc_10'] = df['close'].pct_change(periods=10) * 100  # 10-week ROC
        df['price_vs_ma30'] = (df['close'] / df['ma30'] - 1) * 100  # % above/below MA30
        
        # Volatility
        df['true_range'] = np.maximum(
            df['high'] - df['low'],
            np.maximum(
                abs(df['high'] - df['close'].shift(1)),
                abs(df['low'] - df['close'].shift(1))
            )
        )
        df['atr_14'] = df['true_range'].rolling(window=14, min_periods=7).mean()
        
        # Support and Resistance (dynamic lookback)
        window_data = df['close'][-SUPPORT_RESISTANCE_WINDOW:] if len(df) >= SUPPORT_RESISTANCE_WINDOW else df['close']
        df['support'] = window_data.min()
        df['resistance'] = window_data.max()
        
        # Recent highs and lows
        df['high_52w'] = df['high'].rolling(window=52, min_periods=26).max()
        df['low_52w'] = df['low'].rolling(window=52, min_periods=26).min()
        df['near_52w_high'] = (df['close'] / df['high_52w'] >= 0.95).astype(int)
        df['near_52w_low'] = (df['close'] / df['low_52w'] <= 1.05).astype(int)
        
        return df

    def detect_enhanced_vcp(self, df: pd.DataFrame, weeks: int = VCP_WEEKS) -> Dict:
        """Enhanced VCP detection with multiple criteria."""
        if len(df) < weeks:
            return {'is_vcp': False, 'vcp_score': 0, 'vcp_details': 'Insufficient data'}
        
        recent_data = df[-weeks:].copy()
        ranges = (recent_data['high'] - recent_data['low']).values
        
        # Multiple VCP criteria
        vcp_score = 0
        details = []
        
        # 1. Range contraction
        if len(ranges) >= 4:
            latest_avg = np.mean(ranges[-4:])
            earlier_avg = np.mean(ranges[:4])
            if latest_avg < earlier_avg * VCP_CONTRACTION_THRESHOLD:
                vcp_score += 2
                details.append("Range contraction detected")
        
        # 2. Volume contraction during consolidation
        volume_trend = recent_data['volume'].rolling(window=5).mean()
        if volume_trend.iloc[-1] < volume_trend.iloc[0] * 0.8:
            vcp_score += 1
            details.append("Volume contraction")
        
        # 3. Price holding above key MA
        if recent_data['close'].iloc[-1] > recent_data['ma30'].iloc[-1]:
            vcp_score += 1
            details.append("Above MA30")
        
        # 4. Tightening price action (decreasing volatility)
        if len(recent_data) >= 10:
            early_volatility = recent_data['true_range'][:10].mean()
            late_volatility = recent_data['true_range'][-10:].mean()
            if late_volatility < early_volatility * 0.7:
                vcp_score += 1
                details.append("Decreasing volatility")
        
        is_vcp = vcp_score >= 3
        
        return {
            'is_vcp': is_vcp,
            'vcp_score': vcp_score,
            'vcp_details': '; '.join(details) if details else 'No VCP characteristics'
        }

    def calculate_relative_strength(self, stock_df: pd.DataFrame, index_df: pd.DataFrame) -> Optional[float]:
        """Enhanced relative strength calculation."""
        if stock_df is None or index_df is None or stock_df.empty or index_df.empty:
            return None
        
        try:
            # Align data by dates
            stock_data = stock_df.set_index('date')['close']
            index_data = index_df.set_index('date')['close']
            
            # Find common date range
            common_dates = stock_data.index.intersection(index_data.index)
            if len(common_dates) < 20:  # Need minimum data points
                return None
            
            stock_aligned = stock_data.loc[common_dates]
            index_aligned = index_data.loc[common_dates]
            
            # Calculate relative performance over multiple periods
            periods = [4, 13, 26, 52]  # 1 month, 3 months, 6 months, 1 year
            rs_scores = []
            
            for period in periods:
                if len(stock_aligned) >= period:
                    stock_return = (stock_aligned.iloc[-1] / stock_aligned.iloc[-period] - 1) * 100
                    index_return = (index_aligned.iloc[-1] / index_aligned.iloc[-period] - 1) * 100
                    relative_perf = stock_return - index_return
                    rs_scores.append(relative_perf)
            
            # Weighted average (recent periods weighted more)
            if rs_scores:
                weights = [4, 3, 2, 1][:len(rs_scores)]
                weighted_rs = sum(score * weight for score, weight in zip(rs_scores, weights)) / sum(weights)
                return weighted_rs / 100  # Convert back to ratio
            
            return None
            
        except Exception as e:
            logger.warning(f"Error calculating relative strength: {e}")
            return None

    def get_dynamic_volume_threshold(self, df: pd.DataFrame) -> float:
        """Enhanced dynamic volume threshold calculation."""
        if df is None or df.empty:
            return BASE_VOLUME_THRESHOLD
        
        avg_volume = df['volume'][-VOLUME_MA_PERIOD:].mean()
        recent_volume = df['volume'][-5:].mean()  # Last 5 weeks
        
        # Adjust threshold based on multiple factors
        if avg_volume < LIQUIDITY_CUTOFF:
            base_threshold = LOW_LIQUIDITY_VOLUME_THRESHOLD
        else:
            base_threshold = BASE_VOLUME_THRESHOLD
        
        # Further adjust based on recent volume patterns
        if recent_volume > avg_volume * 1.5:  # Recently active
            return base_threshold * 0.9  # Lower threshold
        elif recent_volume < avg_volume * 0.5:  # Recently quiet
            return base_threshold * 1.2  # Higher threshold
        
        return base_threshold

    def determine_enhanced_stage(self, df: pd.DataFrame, rs: Optional[float], symbol: str) -> Dict:
        """Enhanced stage determination with more nuanced analysis."""
        if df is None or df.empty or len(df) < 30:
            return self._create_error_result(symbol, 'Insufficient Data', 'Not enough data to analyze')
        
        latest = df.iloc[-1]
        close = float(latest['close'])
        
        # Skip penny stocks
        if close < MIN_PRICE:
            return self._create_error_result(symbol, 'Penny Stock', f'Price {close:.2f} below minimum {MIN_PRICE}')
        
        # Extract key metrics
        ma10, ma20, ma30, ma50 = latest['ma10'], latest['ma20'], latest['ma30'], latest['ma50']
        ma30_slope = latest['ma30_slope']
        volume_surge = latest['volume_surge']
        support, resistance = latest['support'], latest['resistance']
        price_vs_ma30 = latest['price_vs_ma30']
        roc_10 = latest['roc_10']
        near_52w_high = latest['near_52w_high']
        near_52w_low = latest['near_52w_low']
        
        # VCP analysis
        vcp_analysis = self.detect_enhanced_vcp(df)
        
        # Dynamic thresholds
        dynamic_volume_threshold = self.get_dynamic_volume_threshold(df)
        
        # Stage determination logic
        stage_info = self._analyze_stage_conditions(
            close, ma10, ma20, ma30, ma50, ma30_slope, volume_surge, 
            support, resistance, price_vs_ma30, roc_10, rs,
            dynamic_volume_threshold, vcp_analysis, near_52w_high, near_52w_low
        )
        
        # Create comprehensive result
        result = {
            'symbol': symbol,
            'stage': stage_info['stage'],
            'recommendation': stage_info['recommendation'],
            'confidence': stage_info['confidence'],
            'close': close,
            'ma10': ma10, 'ma20': ma20, 'ma30': ma30, 'ma50': ma50,
            'ma30_slope': ma30_slope,
            'price_vs_ma30': price_vs_ma30,
            'volume_surge': volume_surge,
            'roc_10': roc_10,
            'rs': rs if rs is not None else np.nan,
            'support': support,
            'resistance': resistance,
            'next_key_level': stage_info['next_key_level'],
            'vcp_detected': vcp_analysis['is_vcp'],
            'vcp_score': vcp_analysis['vcp_score'],
            'near_52w_high': bool(near_52w_high),
            'near_52w_low': bool(near_52w_low),
            'reason': stage_info['reason']
        }
        
        return result

    def _analyze_stage_conditions(self, close, ma10, ma20, ma30, ma50, ma30_slope, volume_surge,
                                support, resistance, price_vs_ma30, roc_10, rs,
                                dynamic_volume_threshold, vcp_analysis, near_52w_high, near_52w_low):
        """Analyze conditions to determine stage."""
        
        reasons = []
        confidence = 0
        
        # Stage 2: Advancing (Strong uptrend)
        if (close > ma30 and ma30_slope > 0 and 
            volume_surge >= dynamic_volume_threshold and 
            close > resistance * BREAKOUT_THRESHOLD):
            
            stage = "Stage 2 - Advancing"
            recommendation = "Buy"
            confidence = 80
            next_key_level = resistance * 1.1
            reasons.append(f"Breakout above resistance with volume surge ≥ {dynamic_volume_threshold:.2f}")
            
            # Confidence boosters
            if rs and rs > 0.1: confidence += 10; reasons.append("Strong relative strength")
            if vcp_analysis['is_vcp']: confidence += 5; reasons.append("VCP breakout")
            if close > ma10 > ma20 > ma30: confidence += 5; reasons.append("Bullish MA alignment")
            if near_52w_high: reasons.append("Near 52-week high")
            
        # Pre-Stage 2: Potential Breakout
        elif (close > ma30 and ma30_slope > 0 and 
              support <= close <= resistance * BREAKOUT_THRESHOLD):
            
            stage = "Pre-Stage 2 - Potential Breakout"
            recommendation = "Monitor Closely" if vcp_analysis['is_vcp'] else "Monitor"
            confidence = 60
            next_key_level = resistance * BREAKOUT_THRESHOLD
            reasons.append("Above rising MA30, approaching resistance")
            
            if vcp_analysis['is_vcp']: confidence += 15; reasons.append("VCP setup detected")
            if volume_surge > 0.8: confidence += 5; reasons.append("Volume building")
            if rs and rs > 0: confidence += 5; reasons.append("Positive relative strength")
            
        # Stage 1: Basing
        elif (abs(price_vs_ma30) < 10 and abs(ma30_slope) < close * 0.01 and
              support <= close <= resistance):
            
            stage = "Stage 1 - Basing"
            recommendation = "Monitor" if vcp_analysis['is_vcp'] else "Hold"
            confidence = 50
            next_key_level = resistance * BREAKOUT_THRESHOLD
            reasons.append("Consolidating near MA30")
            
            if vcp_analysis['is_vcp']: confidence += 20; reasons.append("High-quality VCP base")
            if volume_surge < 0.8: confidence += 5; reasons.append("Quiet accumulation")
            
        # Stage 3: Topping
        elif (close >= ma30 and ma30_slope <= 0 and 
              volume_surge > 1.2 and support <= close <= resistance):
            
            stage = "Stage 3 - Topping"
            recommendation = "Hold/Sell"
            confidence = 65
            next_key_level = support * BREAKDOWN_THRESHOLD
            reasons.append("High volume distribution, flattening MA30")
            
            if near_52w_high: confidence += 10; reasons.append("Topping near 52-week high")
            if rs and rs < -0.05: confidence += 5; reasons.append("Weakening relative strength")
            
        # Stage 4: Declining
        elif (close < ma30 and ma30_slope < 0 and 
              close < support * BREAKDOWN_THRESHOLD):
            
            stage = "Stage 4 - Declining"
            recommendation = "Avoid/Short"
            confidence = 75
            next_key_level = support * 0.9
            reasons.append("Breakdown below support, declining MA30")
            
            if volume_surge > 1.0: confidence += 10; reasons.append("High volume selling")
            if near_52w_low: confidence += 5; reasons.append("Near 52-week low")
            if close < ma10 < ma20 < ma30: confidence += 10; reasons.append("Bearish MA alignment")
            
        else:
            stage = "Unclear/Transition"
            recommendation = "Monitor"
            confidence = 30
            next_key_level = resistance if close > ma30 else support
            reasons.append("Mixed signals, stage unclear")
        
        return {
            'stage': stage,
            'recommendation': recommendation,
            'confidence': min(confidence, 95),  # Cap at 95%
            'next_key_level': next_key_level,
            'reason': "; ".join(reasons)
        }

    def _create_error_result(self, symbol: str, stage: str, reason: str) -> Dict:
        """Create standardized error result."""
        return {
            'symbol': symbol, 'stage': stage, 'recommendation': 'Avoid',
            'confidence': 0, 'close': None, 'ma10': None, 'ma20': None, 
            'ma30': None, 'ma50': None, 'ma30_slope': None, 'price_vs_ma30': None,
            'volume_surge': None, 'roc_10': None, 'rs': None, 'support': None,
            'resistance': None, 'next_key_level': None, 'vcp_detected': False,
            'vcp_score': 0, 'near_52w_high': False, 'near_52w_low': False,
            'reason': reason
        }

    def load_symbols(self) -> List[str]:
        """Load symbols from CSV with validation."""
        try:
            if not os.path.exists(self.symbols_csv):
                raise FileNotFoundError(f"Input CSV {self.symbols_csv} not found")
            
            df = pd.read_csv(self.symbols_csv)
            if 'Symbol' not in df.columns:
                raise ValueError("CSV must contain 'Symbol' column")
            
            symbols = df['Symbol'].dropna().str.strip().unique().tolist()
            logger.info(f"Loaded {len(symbols)} unique symbols from {self.symbols_csv}")
            return symbols
            
        except Exception as e:
            logger.error(f"Failed to load symbols: {e}")
            raise

    def run_enhanced_scanner(self):
        """Run the enhanced scanner with progress tracking."""
        logger.info("Starting Enhanced Stage Analysis Scanner...")
        
        # Setup output directories
        for output_file in [self.output_csv, self.detailed_output_csv]:
            output_dir = os.path.dirname(output_file)
            if output_dir:
                os.makedirs(output_dir, exist_ok=True)
        
        symbols = self.load_symbols()
        total_symbols = len(symbols)
        
        # Load index data once
        logger.info(f"Fetching {RS_INDEX} data for relative strength calculation...")
        index_token = self.get_instrument_token(RS_INDEX)
        index_df = self.fetch_historical_data(index_token, interval="week") if index_token else None
        
        if index_df is None:
            logger.warning("Could not fetch index data - relative strength will be unavailable")
        
        start_time = time.time()
        
        for i, symbol in enumerate(symbols, 1):
            try:
                logger.info(f"[{i}/{total_symbols}] Analyzing {symbol}...")
                
                token = self.get_instrument_token(symbol)
                if not token:
                    logger.warning(f"No instrument token for {symbol}")
                    self.failed_symbols.append((symbol, "Invalid symbol"))
                    self.results.append(self._create_error_result(symbol, 'Invalid Symbol', 'No instrument token found'))
                    continue
                
                df = self.fetch_historical_data(token, interval="week")
                if df is None or df.empty:
                    logger.warning(f"No data for {symbol}")
                    self.failed_symbols.append((symbol, "No data"))
                    self.results.append(self._create_error_result(symbol, 'No Data', 'No historical data available'))
                    continue
                
                # Calculate indicators
                df = self.calculate_enhanced_indicators(df)
                
                # Calculate relative strength
                rs = self.calculate_relative_strength(df, index_df)
                
                # Determine stage
                result = self.determine_enhanced_stage(df, rs, symbol)
                self.results.append(result)
                
                # Log progress every 10 symbols
                if i % 10 == 0:
                    elapsed = time.time() - start_time
                    avg_time = elapsed / i
                    eta = (total_symbols - i) * avg_time
                    logger.info(f"Progress: {i}/{total_symbols} ({i/total_symbols*100:.1f}%) - ETA: {eta/60:.1f} min")
                
            except Exception as e:
                logger.error(f"Error processing {symbol}: {e}")
                self.failed_symbols.append((symbol, str(e)))
                self.results.append(self._create_error_result(symbol, 'Processing Error', f"Error: {str(e)}"))
        
        elapsed_time = time.time() - start_time
        logger.info(f"Analysis completed in {elapsed_time/60:.1f} minutes")
        logger.info(f"Successfully analyzed: {len(self.results) - len(self.failed_symbols)}/{total_symbols}")
        logger.info(f"Failed symbols: {len(self.failed_symbols)}")
        
        self.save_enhanced_results()
        self.generate_summary_report()

    def save_enhanced_results(self):
        """Save results with enhanced formatting and multiple outputs."""
        try:
            df_results = pd.DataFrame(self.results)
            
            # Clean and format numeric columns
            numeric_cols = ['close', 'ma10', 'ma20', 'ma30', 'ma50', 'ma30_slope',
                          'price_vs_ma30', 'volume_surge', 'roc_10', 'rs', 'support',
                          'resistance', 'next_key_level', 'confidence', 'vcp_score']
            
            for col in numeric_cols:
                if col in df_results.columns:
                    df_results[col] = pd.to_numeric(df_results[col], errors='coerce').round(4)
            
            # Save main results (summary)
            summary_cols = ['symbol', 'stage', 'recommendation', 'confidence', 'close',
                          'ma30', 'volume_surge', 'rs', 'vcp_detected', 'reason']
            
            df_summary = df_results[summary_cols].copy()
            df_summary.to_csv(self.output_csv, index=False, na_rep='')
            logger.info(f"Summary results saved to {self.output_csv}")
            
            # Save detailed results
            df_results.to_csv(self.detailed_output_csv, index=False, na_rep='')
            logger.info(f"Detailed results saved to {self.detailed_output_csv}")
            
            # Save failed symbols report
            if self.failed_symbols:
                failed_df = pd.DataFrame(self.failed_symbols, columns=['Symbol', 'Error'])
                failed_csv = self.output_csv.replace('.csv', '_failed.csv')
                failed_df.to_csv(failed_csv, index=False)
                logger.info(f"Failed symbols report saved to {failed_csv}")
            
        except Exception as e:
            logger.error(f"Failed to save results: {e}")
            raise

    def generate_summary_report(self):
        """Generate summary statistics and insights."""
        try:
            df = pd.DataFrame(self.results)
            
            print("\n" + "="*60)
            print("STAGE ANALYSIS SUMMARY REPORT")
            print("="*60)
            
            # Stage distribution
            stage_counts = df['stage'].value_counts()
            print(f"\nStage Distribution:")
            for stage, count in stage_counts.items():
                pct = count / len(df) * 100
                print(f"  {stage}: {count} ({pct:.1f}%)")
            
            # Recommendations
            rec_counts = df['recommendation'].value_counts()
            print(f"\nRecommendation Distribution:")
            for rec, count in rec_counts.items():
                pct = count / len(df) * 100
                print(f"  {rec}: {count} ({pct:.1f}%)")
            
            # Top opportunities (Stage 2 and Pre-Stage 2 with high confidence)
            opportunities = df[
                (df['stage'].str.contains('Stage 2')) & 
                (df['confidence'] > 70)
            ].sort_values('confidence', ascending=False)
            
            print(f"\nTop Buy Opportunities ({len(opportunities)} stocks):")
            for _, row in opportunities.head(10).iterrows():
                print(f"  {row['symbol']}: {row['stage']} (Confidence: {row['confidence']:.0f}%)")
            
            # VCP opportunities
            vcp_stocks = df[df['vcp_detected'] == True]
            print(f"\nVCP Setups Detected: {len(vcp_stocks)}")
            if not vcp_stocks.empty:
                for _, row in vcp_stocks.sort_values('vcp_score', ascending=False).head(10).iterrows():
                    print(f"  {row['symbol']}: VCP Score {row['vcp_score']} - Stage: {row['stage']}")
            
            print("\nSummary report generation complete.")
        
        except Exception as e:
            logger.error(f"Failed to generate summary report: {e}")


# Main block
if __name__ == "__main__":
    try:
        scanner = EnhancedStageAnalysisScanner(
            api_key=API_KEY,
            access_token=ACCESS_TOKEN,
            symbols_csv=SYMBOLS_CSV,
            output_csv=OUTPUT_CSV
        )
        scanner.run_enhanced_scanner()
    except Exception as e:
        logger.exception(f"Fatal error occurred: {e}")
