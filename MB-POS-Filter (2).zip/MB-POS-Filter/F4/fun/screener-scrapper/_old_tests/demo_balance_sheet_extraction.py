#!/usr/bin/env python3
"""
Demonstration of Balance Sheet Extraction Feature
"""

from advanced_screener_scraper import AdvancedScreenerScraper
import pandas as pd

def demo_balance_sheet_extraction():
    """Demonstrate Balance Sheet extraction functionality"""
    
    print("Balance Sheet Extraction Demo")
    print("=" * 40)
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Test with Reliance Industries
    company_symbol = 'RELIANCE'
    print(f"Scraping Balance Sheet data for {company_symbol}...")
    
    try:
        metrics = scraper.scrape_single_company(company_symbol)
        
        if metrics and metrics.get('status') == 'success':
            print("✓ Successfully scraped company data")
            
            # Check Balance Sheet data
            has_balance_sheet = metrics.get('has_balance_sheet_data', False)
            print(f"Has Balance Sheet data: {has_balance_sheet}")
            
            if has_balance_sheet:
                balance_sheet_data = metrics.get('balance_sheet_data', {})
                print(f"✓ Balance Sheet data extracted successfully!")
                print(f"  Years available: {balance_sheet_data.get('total_years', 0)}")
                print(f"  Metrics extracted: {balance_sheet_data.get('total_metrics', 0)}")
                
                # Show sample data
                if 'data' in balance_sheet_data and balance_sheet_data['data']:
                    print("\nSample Balance Sheet metrics:")
                    for i, row in enumerate(balance_sheet_data['data'][:3]):  # Show first 3 metrics
                        metric_name = row.get('metric', 'Unknown')
                        print(f"  {i+1}. {metric_name}")
                
                # Show growth metrics
                if 'growth_metrics' in balance_sheet_data:
                    print("\nGrowth metrics available:")
                    for title in balance_sheet_data['growth_metrics'].keys():
                        print(f"  - {title}")
                
                # Save to CSV to demonstrate output
                df = pd.DataFrame([metrics])
                output_file = scraper.save_to_csv(df, "demo_balance_sheet_output.csv")
                print(f"\n✓ Data saved to: {output_file}")
                
                # Check if Balance Sheet files were created
                import os
                balance_sheet_dir = os.path.join('output', 'balance_sheet_data')
                if os.path.exists(balance_sheet_dir):
                    balance_sheet_files = [f for f in os.listdir(balance_sheet_dir) if f.endswith('.csv')]
                    print(f"✓ Balance Sheet files created: {len(balance_sheet_files)}")
                    for file in balance_sheet_files:
                        print(f"  - {file}")
                
            else:
                print("✗ No Balance Sheet data found for this company")
                
        else:
            print("✗ Failed to scrape company data")
            
    except Exception as e:
        print(f"✗ Error: {e}")

def demo_multiple_companies():
    """Demonstrate Balance Sheet extraction for multiple companies"""
    
    print("\n" + "="*40)
    print("Testing Balance Sheet extraction for multiple companies...")
    
    scraper = AdvancedScreenerScraper(max_workers=2)
    
    # Test with a few companies
    test_companies = ['RELIANCE', 'TCS', 'HDFCBANK']
    
    all_metrics = []
    for company in test_companies:
        print(f"\nScraping {company}...")
        try:
            metrics = scraper.scrape_single_company(company)
            
            if metrics and metrics.get('status') == 'success':
                has_balance_sheet = metrics.get('has_balance_sheet_data', False)
                company_name = metrics.get('company_name', company)
                print(f"  ✓ {company_name}: {'Has Balance Sheet' if has_balance_sheet else 'No Balance Sheet'}")
                
                if has_balance_sheet:
                    balance_sheet_data = metrics.get('balance_sheet_data', {})
                    print(f"    Years: {balance_sheet_data.get('total_years', 0)}, Metrics: {balance_sheet_data.get('total_metrics', 0)}")
                
                all_metrics.append(metrics)
            else:
                print(f"  ✗ {company}: Failed to scrape")
                
        except Exception as e:
            print(f"  ✗ {company}: Error - {e}")
    
    # Save results
    if all_metrics:
        df = pd.DataFrame(all_metrics)
        output_file = scraper.save_to_csv(df, "demo_multiple_balance_sheet.csv")
        print(f"\n✓ Results saved to: {output_file}")
        
        # Show summary
        successful = df[df['status'] == 'success']
        balance_sheet_available = successful[successful['has_balance_sheet_data'] == True]
        print(f"Successfully scraped: {len(successful)}/{len(test_companies)} companies")
        print(f"Companies with Balance Sheet data: {len(balance_sheet_available)}/{len(successful)}")

if __name__ == "__main__":
    demo_balance_sheet_extraction()
    demo_multiple_companies()
    
    print("\n" + "="*40)
    print("Demo completed! Check the output/ directory for generated files.") 