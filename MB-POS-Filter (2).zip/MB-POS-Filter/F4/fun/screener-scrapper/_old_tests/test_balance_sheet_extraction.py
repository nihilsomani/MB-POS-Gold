#!/usr/bin/env python3
"""
Test script to verify Balance Sheet extraction functionality
"""

from advanced_screener_scraper import AdvancedScreenerScraper
import pandas as pd

def test_balance_sheet_extraction():
    """Test the Balance Sheet extraction functionality"""
    
    print("Testing Balance Sheet Extraction")
    print("=" * 40)
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Test with a well-known company that should have Balance Sheet data
    company_symbol = 'RELIANCE'
    print(f"Testing Balance Sheet extraction for {company_symbol}...")
    
    try:
        metrics = scraper.scrape_single_company(company_symbol)
        
        if metrics and metrics.get('status') == 'success':
            print("✓ Successfully scraped company data")
            
            # Check if Balance Sheet data was extracted
            has_balance_sheet = metrics.get('has_balance_sheet_data', False)
            print(f"Has Balance Sheet data: {has_balance_sheet}")
            
            if has_balance_sheet:
                balance_sheet_data = metrics.get('balance_sheet_data', {})
                print(f"✓ Balance Sheet data extracted successfully")
                print(f"  Years: {balance_sheet_data.get('total_years', 0)}")
                print(f"  Metrics: {balance_sheet_data.get('total_metrics', 0)}")
                
                # Show some sample data
                if 'data' in balance_sheet_data and balance_sheet_data['data']:
                    print("\nSample Balance Sheet metrics:")
                    for i, row in enumerate(balance_sheet_data['data'][:5]):  # Show first 5 metrics
                        metric_name = row.get('metric', 'Unknown')
                        print(f"  {i+1}. {metric_name}")
                
                # Show growth metrics if available
                if 'growth_metrics' in balance_sheet_data:
                    print("\nGrowth metrics:")
                    for title, data in balance_sheet_data['growth_metrics'].items():
                        print(f"  {title}:")
                        for period, value in data.items():
                            print(f"    {period}: {value}")
            else:
                print("✗ No Balance Sheet data found")
                
        else:
            print("✗ Failed to scrape company data")
            
    except Exception as e:
        print(f"✗ Error: {e}")

def test_multiple_companies():
    """Test Balance Sheet extraction for multiple companies"""
    
    print("\n" + "="*40)
    print("Testing Balance Sheet extraction for multiple companies...")
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=2)
    
    # Test with a few companies
    test_companies = ['RELIANCE', 'TCS', 'HDFCBANK']
    
    for company in test_companies:
        print(f"\nTesting {company}...")
        try:
            metrics = scraper.scrape_single_company(company)
            
            if metrics and metrics.get('status') == 'success':
                has_balance_sheet = metrics.get('has_balance_sheet_data', False)
                company_name = metrics.get('company_name', company)
                print(f"  ✓ {company_name}: {'Has Balance Sheet' if has_balance_sheet else 'No Balance Sheet'}")
                
                if has_balance_sheet:
                    balance_sheet_data = metrics.get('balance_sheet_data', {})
                    print(f"    Years: {balance_sheet_data.get('total_years', 0)}, Metrics: {balance_sheet_data.get('total_metrics', 0)}")
            else:
                print(f"  ✗ {company}: Failed to scrape")
                
        except Exception as e:
            print(f"  ✗ {company}: Error - {e}")

def test_csv_output():
    """Test saving Balance Sheet data to CSV"""
    
    print("\n" + "="*40)
    print("Testing CSV output with Balance Sheet data...")
    
    # Initialize scraper
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Test with a single company
    company_symbol = 'RELIANCE'
    print(f"Scraping {company_symbol} and saving to CSV...")
    
    try:
        metrics = scraper.scrape_single_company(company_symbol)
        
        if metrics and metrics.get('status') == 'success':
            # Create DataFrame
            df = pd.DataFrame([metrics])
            
            # Save to CSV
            filename = scraper.save_to_csv(df, "test_balance_sheet_output.csv")
            print(f"✓ Data saved to: {filename}")
            
            # Check if Balance Sheet files were created
            import os
            balance_sheet_dir = os.path.join('output', 'balance_sheet_data')
            if os.path.exists(balance_sheet_dir):
                balance_sheet_files = [f for f in os.listdir(balance_sheet_dir) if f.endswith('.csv')]
                print(f"✓ Balance Sheet files created: {len(balance_sheet_files)}")
                for file in balance_sheet_files:
                    print(f"  - {file}")
            else:
                print("✗ No Balance Sheet directory created")
                
        else:
            print("✗ Failed to scrape company data")
            
    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    test_balance_sheet_extraction()
    test_multiple_companies()
    test_csv_output()
    
    print("\n" + "="*40)
    print("Balance Sheet extraction test completed!") 