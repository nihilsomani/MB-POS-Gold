#!/usr/bin/env python3
"""
Simple test script for the screener scraper
"""

try:
    import requests
    import pandas as pd
    from bs4 import BeautifulSoup
    print("✓ All required dependencies are available")
except ImportError as e:
    print(f"✗ Missing dependency: {e}")
    print("Please install dependencies with: pip install -r requirements.txt")
    exit(1)

def test_basic_functionality():
    """Test basic web scraping functionality"""
    print("\n=== Testing Basic Functionality ===")
    
    try:
        # Test basic HTTP request
        response = requests.get("https://www.screener.in", timeout=10)
        print(f"✓ Successfully connected to screener.in (Status: {response.status_code})")
        
        # Test BeautifulSoup parsing
        soup = BeautifulSoup(response.content, 'html.parser')
        print("✓ Successfully parsed HTML content")
        
        # Test pandas functionality
        test_data = {'company': ['Test'], 'price': [100]}
        df = pd.DataFrame(test_data)
        print("✓ Successfully created pandas DataFrame")
        
        return True
        
    except Exception as e:
        print(f"✗ Error during basic functionality test: {e}")
        return False

def test_scraper_import():
    """Test if scraper modules can be imported"""
    print("\n=== Testing Scraper Import ===")
    
    try:
        from screener_scraper import ScreenerScraper
        print("✓ Successfully imported basic scraper")
        
        from advanced_screener_scraper import AdvancedScreenerScraper
        print("✓ Successfully imported advanced scraper")
        
        return True
        
    except Exception as e:
        print(f"✗ Error importing scraper modules: {e}")
        return False

def test_single_company_scraping():
    """Test scraping a single company"""
    print("\n=== Testing Single Company Scraping ===")
    
    try:
        from screener_scraper import ScreenerScraper
        
        scraper = ScreenerScraper()
        print("✓ Successfully initialized scraper")
        
        # Test with a well-known company
        metrics = scraper.scrape_single_company('RELIANCE')
        
        if metrics:
            print("✓ Successfully scraped company data")
            print(f"  Company URL: {metrics.get('company_url', 'N/A')}")
            print(f"  Metrics extracted: {len(metrics)}")
            
            # Show some key metrics
            key_metrics = ['Company_Name', 'Current Price', 'Market Cap', 'Stock P/E']
            for metric in key_metrics:
                if metric in metrics:
                    print(f"  {metric}: {metrics[metric]}")
            
            return True
        else:
            print("✗ No data extracted from company page")
            return False
            
    except Exception as e:
        print(f"✗ Error during single company scraping test: {e}")
        return False

def main():
    """Run all tests"""
    print("Screener.in Scraper Test Suite")
    print("=" * 40)
    
    tests = [
        test_basic_functionality,
        test_scraper_import,
        test_single_company_scraping
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print(f"\n=== Test Results ===")
    print(f"Passed: {passed}/{total}")
    
    if passed == total:
        print("✓ All tests passed! The scraper is ready to use.")
        print("\nYou can now run:")
        print("  python example_usage.py")
        print("  python screener_scraper.py")
    else:
        print("✗ Some tests failed. Please check the errors above.")
        print("\nTroubleshooting tips:")
        print("1. Install dependencies: pip install -r requirements.txt")
        print("2. Check internet connection")
        print("3. Verify screener.in is accessible")

if __name__ == "__main__":
    main() 