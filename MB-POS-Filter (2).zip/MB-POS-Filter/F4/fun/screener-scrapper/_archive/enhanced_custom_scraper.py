#!/usr/bin/env python3
"""
Enhanced Custom Company Scraper with Quarterly Data
This script demonstrates how to use AdvancedScreenerScraper with quarterly data extraction.
"""

import pandas as pd
import json
from advanced_screener_scraper import AdvancedScreenerScraper
from custom_companies_config import (
    get_custom_companies, 
    get_sector_companies, 
    get_scraper_config, 
    get_output_config
)

def scrape_with_quarterly_data():
    """Scrape companies with quarterly data extraction"""
    
    # Get configuration
    companies = get_custom_companies()
    scraper_config = get_scraper_config()
    output_config = get_output_config()
    
    print("Enhanced AdvancedScreenerScraper - With Quarterly Data")
    print("=" * 60)
    print(f"Companies to scrape: {len(companies)}")
    print(f"Companies: {', '.join(companies[:5])}{'...' if len(companies) > 5 else ''}")
    print(f"Scraper config: {scraper_config}")
    print("-" * 60)
    
    # Initialize scraper with custom configuration
    scraper = AdvancedScreenerScraper(**scraper_config)
    
    # Scrape companies
    print("Starting to scrape companies with quarterly data...")
    all_metrics = []
    
    for i, company in enumerate(companies, 1):
        print(f"[{i}/{len(companies)}] Scraping {company}...")
        
        try:
            metrics = scraper.scrape_single_company(company)
            
            if metrics and metrics.get('status') == 'success':
                all_metrics.append(metrics)
                company_name = metrics.get('company_name', company)
                current_price = metrics.get('current_price', 'N/A')
                pe_ratio = metrics.get('pe_ratio', 'N/A')
                has_quarterly = metrics.get('has_quarterly_data', False)
                
                print(f"  ✓ {company_name} - ₹{current_price}, P/E: {pe_ratio}")
                if has_quarterly:
                    quarterly_data = metrics.get('quarterly_data', {})
                    quarters = quarterly_data.get('total_quarters', 0)
                    metrics_count = quarterly_data.get('total_metrics', 0)
                    print(f"    📊 Quarterly data: {quarters} quarters, {metrics_count} metrics")
                else:
                    print(f"    ⚠️  No quarterly data available")
            else:
                print(f"  ✗ Failed to scrape {company}")
                
        except Exception as e:
            print(f"  ✗ Error: {str(e)}")
    
    # Save results
    if all_metrics:
        df = pd.DataFrame(all_metrics)
        output_file = scraper.save_to_csv(df, output_config['output_filename'])
        print(f"\n✓ Results saved to: {output_file}")
        
        # Show summary
        successful = len(all_metrics)
        companies_with_quarterly = sum(1 for m in all_metrics if m.get('has_quarterly_data', False))
        print(f"Successfully scraped: {successful}/{len(companies)} companies")
        print(f"Companies with quarterly data: {companies_with_quarterly}")
        
        if successful > 0:
            print("\nTop 5 companies by current price:")
            df_sorted = df.sort_values('current_price', ascending=False)
            for _, row in df_sorted.head().iterrows():
                name = row.get('company_name', 'Unknown')
                price = row.get('current_price', 'N/A')
                pe = row.get('pe_ratio', 'N/A')
                quarterly = "✓" if row.get('has_quarterly_data', False) else "✗"
                print(f"  {name}: ₹{price} (P/E: {pe}) [Quarterly: {quarterly}]")
    else:
        print("No companies were successfully scraped")

def analyze_quarterly_data():
    """Analyze quarterly data for companies"""
    
    scraper = AdvancedScreenerScraper(max_workers=2)
    
    # Test with a few companies that are likely to have quarterly data
    test_companies = ['MIDHANI', 'PSPPROJECT', 'HLEGLAS', 'HAPPYFORGE', 'FINEORG', 'BANDHANBNK', 'DELHIVERY', 'DMART', 'ZEEL', 'TITAN']
    
    print("\nAnalyzing Quarterly Data")
    print("=" * 40)
    
    for company in test_companies:
        print(f"\nAnalyzing {company}...")
        metrics = scraper.scrape_single_company(company)
        
        if metrics and metrics.get('status') == 'success':
            company_name = metrics.get('company_name', company)
            quarterly_data = metrics.get('quarterly_data', {})
            
            if quarterly_data:
                print(f"  ✓ {company_name} - Quarterly data found")
                print(f"    Quarters: {quarterly_data.get('total_quarters', 0)}")
                print(f"    Metrics: {quarterly_data.get('total_metrics', 0)}")
                
                # Show some sample quarterly metrics
                data = quarterly_data.get('data', [])
                if data:
                    print("    Sample metrics:")
                    for metric in data[:3]:  # Show first 3 metrics
                        metric_name = metric.get('metric', 'Unknown')
                        latest_value = None
                        for key in metric.keys():
                            if key not in ['metric'] and metric[key] is not None:
                                latest_value = metric[key]
                                break
                        print(f"      {metric_name}: {latest_value}")
                
                if 'upcoming_result_date' in quarterly_data:
                    print(f"    Upcoming result: {quarterly_data['upcoming_result_date']}")
            else:
                print(f"  ⚠️  {company_name} - No quarterly data")
        else:
            print(f"  ✗ Failed to scrape {company}")

def save_quarterly_example():
    """Save a detailed example of quarterly data"""
    
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    print("\nSaving Detailed Quarterly Example")
    print("=" * 40)
    
    # Scrape a single company with detailed quarterly data
    company = 'MIDHANI'
    print(f"Scraping {company} for detailed quarterly analysis...")
    
    metrics = scraper.scrape_single_company(company)
    
    if metrics and metrics.get('status') == 'success':
        quarterly_data = metrics.get('quarterly_data', {})
        
        if quarterly_data:
            # Save detailed quarterly data
            import os
            os.makedirs('output', exist_ok=True)
            
            # Save as JSON for detailed analysis
            detailed_file = os.path.join('output', f'{company}_quarterly_detailed.json')
            with open(detailed_file, 'w', encoding='utf-8') as f:
                json.dump(quarterly_data, f, indent=2, ensure_ascii=False)
            
            print(f"✓ Detailed quarterly data saved to: {detailed_file}")
            
            # Show quarterly data structure
            print(f"\nQuarterly Data Structure for {company}:")
            print(f"  Total quarters: {quarterly_data.get('total_quarters', 0)}")
            print(f"  Total metrics: {quarterly_data.get('total_metrics', 0)}")
            print(f"  Quarters: {quarterly_data.get('quarters', [])}")
            
            # Show metrics
            data = quarterly_data.get('data', [])
            if data:
                print(f"\nAvailable metrics:")
                for metric in data:
                    metric_name = metric.get('metric', 'Unknown')
                    print(f"  - {metric_name}")
        else:
            print(f"  ⚠️  No quarterly data found for {company}")
    else:
        print(f"  ✗ Failed to scrape {company}")

if __name__ == "__main__":
    print("Enhanced Custom Company Scraper with Quarterly Data")
    print("=" * 60)
    
    # Run the main scraping function with quarterly data
    scrape_with_quarterly_data()
    
    # Run quarterly data analysis
    analyze_quarterly_data()
    
    # Save detailed quarterly example
    save_quarterly_example()
    
    print("\n" + "="*60)
    print("Quarterly data files are saved in:")
    print("  - output/quarterly_data/ (individual company files)")
    print("  - output/quarterly_data/quarterly_summary.txt (summary)")
    print("  - output/[company]_quarterly_detailed.json (detailed JSON)")
    print("\nDone! Check the generated files for results.") 