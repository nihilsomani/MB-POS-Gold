#!/usr/bin/env python3
"""
Updated company list for financial analysis
"""

# Updated list of 95 companies to be analyzed
UPDATED_COMPANY_URLS = [
    "https://www.screener.in/company/MIDHANI/",
    "https://www.screener.in/company/PSPPROJECT/",
    "https://www.screener.in/company/HLEGLAS/",
    "https://www.screener.in/company/HAPPYFORGE/",
    "https://www.screener.in/company/FINEORG/",
    "https://www.screener.in/company/BANDHANBNK/",
    "https://www.screener.in/company/DELHIVERY/",
    "https://www.screener.in/company/MASFIN/",
    "https://www.screener.in/company/ALKYLAMINE/",
    "https://www.screener.in/company/SAGCEM/",
    "https://www.screener.in/company/ANURAS/",
    "https://www.screener.in/company/NUVOCO/",
    "https://www.screener.in/company/BIRLACORPN/",
    "https://www.screener.in/company/MAXESTATES/",
    "https://www.screener.in/company/KOLTEPATIL/",
    "https://www.screener.in/company/DALBHARAT/",
    "https://www.screener.in/company/VRLLOG/",
    "https://www.screener.in/company/TMB/",
    "https://www.screener.in/company/IOLCP/",
    "https://www.screener.in/company/BERGEPAINT/",
    "https://www.screener.in/company/UJJIVANSFB/",
    "https://www.screener.in/company/AUBANK/",
    "https://www.screener.in/company/VINATIORGA/",
    "https://www.screener.in/company/DMART/",
    "https://www.screener.in/company/KRBL/",
    "https://www.screener.in/company/IIFL/",
    "https://www.screener.in/company/ZEEL/",
    "https://www.screener.in/company/FLAIR/",
    "https://www.screener.in/company/MAITHANALL/",
    "https://www.screener.in/company/SSWL/",
    "https://www.screener.in/company/RBLBANK/",
    "https://www.screener.in/company/CONCORDBIO/",
    "https://www.screener.in/company/POONAWALLA/",
    "https://www.screener.in/company/INDIAMART/",
    "https://www.screener.in/company/MANKIND/",
    "https://www.screener.in/company/ATUL/",
    "https://www.screener.in/company/IDFCFIRSTB/",
    "https://www.screener.in/company/CREDITACC/",
    "https://www.screener.in/company/AARTIIND/",
    "https://www.screener.in/company/ALOKINDS/",
    "https://www.screener.in/company/ADANIENT/",
    "https://www.screener.in/company/AVANTEL/",
    "https://www.screener.in/company/CAMPUS/",
    "https://www.screener.in/company/CERA/",
    "https://www.screener.in/company/CONCOR/",
    "https://www.screener.in/company/CLEAN/",
    "https://www.screener.in/company/DALMIASUG/",
    "https://www.screener.in/company/EQUITASBNK/",
    "https://www.screener.in/company/FUSION/",
    "https://www.screener.in/company/HONASA/",
    "https://www.screener.in/company/HATHWAY/",
    "https://www.screener.in/company/HONAUT/",
    "https://www.screener.in/company/IGL/",
    "https://www.screener.in/company/JAMNAAUTO/",
    "https://www.screener.in/company/MSUMI/",
    "https://www.screener.in/company/JSFB/",
    "https://www.screener.in/company/MTARTECH/",
    "https://www.screener.in/company/NUCLEUS/",
    "https://www.screener.in/company/RTNINDIA/",
    "https://www.screener.in/company/TANLA/",
    "https://www.screener.in/company/RBA/",
    "https://www.screener.in/company/TATAELXSI/",
    "https://www.screener.in/company/TRIDENT/",
    "https://www.screener.in/company/YESBANK/",
    "https://www.screener.in/company/ANGELONE/",
    "https://www.screener.in/company/ZFCVINDIA/",
    "https://www.screener.in/company/BALMLAWRIE/",
    "https://www.screener.in/company/BANKINDIA/",
    "https://www.screener.in/company/BHARATFORG/",
    "https://www.screener.in/company/DBREALTY/",
    "https://www.screener.in/company/CANFINHOME/",
    "https://www.screener.in/company/ELECTCAST/",
    "https://www.screener.in/company/FILATEX/",
    "https://www.screener.in/company/GESHIP/",
    "https://www.screener.in/company/GPPL/",
    "https://www.screener.in/company/GNFC/",
    "https://www.screener.in/company/HDFCLIFE/",
    "https://www.screener.in/company/HONDAPOWER/",
    "https://www.screener.in/company/IRCON/",
    "https://www.screener.in/company/JKPAPER/",
    "https://www.screener.in/company/J&KBANK/",
    "https://www.screener.in/company/JKTYRE/",
    "https://www.screener.in/company/MAHSEAMLES/",
    "https://www.screener.in/company/MRPL/",
    "https://www.screener.in/company/NETWORK18/",
    "https://www.screener.in/company/NESTLEIND/",
    "https://www.screener.in/company/NILKAMAL/",
    "https://www.screener.in/company/PRINCEPIPE/",
    "https://www.screener.in/company/REPCOHOME/",
    "https://www.screener.in/company/SANDHAR/",
    "https://www.screener.in/company/RITES/",
    "https://www.screener.in/company/SANOFI/",
    "https://www.screener.in/company/SURYAROSNI/",
    "https://www.screener.in/company/TITAN/",
    "https://www.screener.in/company/VARROC/"
]

def get_company_list():
    """Get the updated list of companies"""
    return UPDATED_COMPANY_URLS.copy()

def get_company_names():
    """Extract company names from URLs"""
    company_names = []
    for url in UPDATED_COMPANY_URLS:
        # Extract company name from URL
        company_name = url.split('/')[-2]
        company_names.append(company_name)
    return company_names

if __name__ == "__main__":
    print(f"Total companies in list: {len(UPDATED_COMPANY_URLS)}")
    print("Company names:")
    for i, name in enumerate(get_company_names(), 1):
        print(f"{i:2d}. {name}") 