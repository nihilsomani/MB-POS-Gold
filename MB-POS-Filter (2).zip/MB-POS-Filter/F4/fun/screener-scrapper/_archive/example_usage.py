#!/usr/bin/env python3
"""
Example usage of the Screener.in Web Scraper

This script demonstrates how to use the screener scraper to extract financial metrics
from company pages and save them to CSV files.
"""

from screener_scraper import ScreenerScraper
from advanced_screener_scraper import AdvancedScreenerScraper
import json
import pandas as pd

def example_basic_scraper():
    """Example using the basic scraper"""
    print("=== Basic Scraper Example ===")
    
    # Initialize the scraper
    scraper = ScreenerScraper()
    
    # Scrape a single company
    print("Scraping MIDHANI...")
    metrics = scraper.scrape_single_company('MIDHANI')
    
    if metrics:
        print("Extracted metrics:")
        for key, value in metrics.items():
            print(f"  {key}: {value}")
    else:
        print("Failed to extract metrics")
        
    # Scrape multiple companies (limited for testing)
    print("\nScraping multiple companies...")
    df = scraper.scrape_companies(max_companies=3)
    
    if not df.empty:
        output_file = scraper.save_to_csv(df, "basic_scraper_results.csv")
        print(f"Results saved to: {output_file}")
        print(f"Total companies scraped: {len(df)}")
    else:
        print("No data was scraped successfully")

def example_advanced_scraper():
    """Example using the advanced scraper with parallel processing"""
    print("\n=== Advanced Scraper Example ===")
    
    # Initialize the advanced scraper
    scraper = AdvancedScreenerScraper(
        max_workers=2,  # Number of parallel workers
        delay_range=(1, 2),  # Delay between requests (1-2 seconds)
        retry_attempts=3  # Number of retry attempts for failed requests
    )
    
    # Scrape a single company
    print("Scraping HAPPYFORGE...")
    metrics = scraper.scrape_single_company('HAPPYFORGE')
    
    if metrics and metrics.get('status') == 'success':
        print("Extracted metrics:")
        # Print only the main financial metrics
        main_metrics = ['company_name', 'sector', 'current_price', 'market_cap', 
                       'pe_ratio', 'roe', 'roce', 'eps']
        for key in main_metrics:
            if key in metrics:
                print(f"  {key}: {metrics[key]}")
    else:
        print("Failed to extract metrics")
        
    # Scrape multiple companies with parallel processing
    print("\nScraping multiple companies with parallel processing...")
    df = scraper.scrape_companies_parallel(max_companies=5)
    
    if not df.empty:
        output_file = scraper.save_to_csv(df, "advanced_scraper_results.csv")
        print(f"Results saved to: {output_file}")
        print(f"Total companies scraped: {len(df)}")
        print(f"Successful scrapes: {len(df[df['status'] == 'success'])}")
        
        # Show some statistics
        if 'current_price' in df.columns:
            print(f"Average current price: ₹{df['current_price'].mean():.2f}")
        if 'pe_ratio' in df.columns:
            print(f"Average P/E ratio: {df['pe_ratio'].mean():.2f}")
    else:
        print("No data was scraped successfully")

def example_custom_company_list():
    """Example with a custom list of companies"""
    print("\n=== Custom Company List Example ===")
    
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Define a custom list of companies to scrape
    companies = [
        'MIDHANI',     # Mishra Dhatu Nigam
        'PSPPROJECT',  # PSP Projects
        'HLEGLAS',     # HLE Glascoat
        'HAPPYFORGE',  # Happy Forgings
        'FINEORG'      # Fine Organic Industries
    ]
    
    print(f"Scraping custom list of {len(companies)} companies...")
    
    all_metrics = []
    for company in companies:
        print(f"Scraping {company}...")
        metrics = scraper.scrape_single_company(company)
        if metrics and metrics.get('status') == 'success':
            all_metrics.append(metrics)
            print(f"  ✓ Successfully scraped {metrics.get('company_name', company)}")
        else:
            print(f"  ✗ Failed to scrape {company}")
    
    if all_metrics:
        df = pd.DataFrame(all_metrics)
        output_file = scraper.save_to_csv(df, "custom_companies_results.csv")
        print(f"\nResults saved to: {output_file}")
        
        # Display summary
        print("\nSummary:")
        for _, row in df.iterrows():
            name = row.get('company_name', 'Unknown')
            price = row.get('current_price', 'N/A')
            pe = row.get('pe_ratio', 'N/A')
            print(f"  {name}: Price ₹{price}, P/E {pe}")
    else:
        print("No companies were successfully scraped")

def example_data_analysis():
    """Example of basic data analysis on scraped data"""
    print("\n=== Data Analysis Example ===")
    
    scraper = AdvancedScreenerScraper(max_workers=1)
    
    # Scrape some companies
    df = scraper.scrape_companies_parallel(max_companies=10)
    
    if not df.empty:
        print("Data Analysis Results:")
        print("-" * 40)
        
        # Filter successful scrapes
        successful_df = df[df['status'] == 'success']
        
        if len(successful_df) > 0:
            print(f"Total companies analyzed: {len(successful_df)}")
            
            # Sector analysis
            if 'sector' in successful_df.columns:
                sector_counts = successful_df['sector'].value_counts()
                print(f"\nSector distribution:")
                for sector, count in sector_counts.head().items():
                    print(f"  {sector}: {count} companies")
            
            # Financial metrics analysis
            if 'pe_ratio' in successful_df.columns:
                pe_stats = successful_df['pe_ratio'].describe()
                print(f"\nP/E Ratio Statistics:")
                print(f"  Mean: {pe_stats['mean']:.2f}")
                print(f"  Median: {pe_stats['50%']:.2f}")
                print(f"  Min: {pe_stats['min']:.2f}")
                print(f"  Max: {pe_stats['max']:.2f}")
            
            if 'roe' in successful_df.columns:
                roe_stats = successful_df['roe'].describe()
                print(f"\nROE Statistics:")
                print(f"  Mean: {roe_stats['mean']:.2f}%")
                print(f"  Median: {roe_stats['50%']:.2f}%")
            
            # Find companies with good metrics
            print(f"\nCompanies with P/E < 20 and ROE > 15%:")
            good_companies = successful_df[
                (successful_df['pe_ratio'] < 20) & 
                (successful_df['roe'] > 15)
            ]
            
            for _, company in good_companies.iterrows():
                name = company.get('company_name', 'Unknown')
                pe = company.get('pe_ratio', 'N/A')
                roe = company.get('roe', 'N/A')
                print(f"  {name}: P/E {pe}, ROE {roe}%")
        else:
            print("No successful scrapes to analyze")
    else:
        print("No data available for analysis")

if __name__ == "__main__":
    # Run examples
    try:
        example_basic_scraper()
        example_advanced_scraper()
        example_custom_company_list()
        example_data_analysis()
        
        print("\n=== All examples completed successfully! ===")
        
    except Exception as e:
        print(f"Error running examples: {e}")
        print("Make sure you have installed all required dependencies:")
        print("pip install -r requirements.txt") 