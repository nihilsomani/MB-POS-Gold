#!/usr/bin/env python3
"""
Custom Company List Scraper for Screener.in
This script demonstrates how to use AdvancedScreenerScraper with a custom list of companies.
"""

import pandas as pd
from advanced_screener_scraper import AdvancedScreenerScraper

def scrape_custom_companies():
    """Scrape a custom list of companies using AdvancedScreenerScraper"""
    
    # Initialize the advanced scraper
    scraper = AdvancedScreenerScraper(
        max_workers=2,  # Number of parallel workers
        delay_range=(2, 5),  # Slightly higher randomized delay to avoid rate limits
        timeout=30,  # Request timeout in seconds
        retry_attempts=3  # Number of retry attempts for failed requests
    )
    
    # Import the custom companies from configuration
    from custom_companies_config import CUSTOM_COMPANIES
    
    # Use the companies from configuration (limit to 50 to be polite to the site)
    custom_companies = CUSTOM_COMPANIES[:100]
    
    print(f"Starting to scrape {len(custom_companies)} companies...")
    print("Companies to scrape:", ", ".join(custom_companies))
    print("-" * 60)
    
    # Method 1: Scrape companies one by one (more control)
    print("Method 1: Scraping companies individually...")
    all_metrics = []
    
    for i, company in enumerate(custom_companies, 1):
        print(f"[{i}/{len(custom_companies)}] Scraping {company}...")
        
        try:
            metrics = scraper.scrape_single_company(company)
            
            if metrics and metrics.get('status') == 'success':
                all_metrics.append(metrics)
                company_name = metrics.get('company_name', company)
                current_price = metrics.get('current_price', 'N/A')
                pe_ratio = metrics.get('pe_ratio', 'N/A')
                print(f"  ✓ Success: {company_name} - Price: ₹{current_price}, P/E: {pe_ratio}")
            else:
                print(f"  ✗ Failed to scrape {company}")
                
        except Exception as e:
            print(f"  ✗ Error scraping {company}: {str(e)}")
    
    # Save results to CSV
    if all_metrics:
        df = pd.DataFrame(all_metrics)
        output_file = scraper.save_to_csv(df, "custom_companies_results.csv")
        print(f"\n✓ Results saved to: {output_file}")
        
        # Display summary
        print("\nSummary of scraped data:")
        print("-" * 40)
        for _, row in df.iterrows():
            name = row.get('company_name', 'Unknown')
            price = row.get('current_price', 'N/A')
            pe = row.get('pe_ratio', 'N/A')
            sector = row.get('sector', 'N/A')
            has_pnl = row.get('has_pnl_data', False)
            has_quarterly = row.get('has_quarterly_data', False)
            has_balance_sheet = row.get('has_balance_sheet_data', False)
            print(f"  {name} ({sector}): Price ₹{price}, P/E {pe}")
            print(f"    P&L Data: {'✓' if has_pnl else '✗'}, Quarterly Data: {'✓' if has_quarterly else '✗'}, Balance Sheet: {'✓' if has_balance_sheet else '✗'}")
    else:
        print("No companies were successfully scraped")
    
    print("\n" + "="*60)
    
    # Method 2: Scrape companies in parallel (faster)
    print("Method 2: Scraping companies in parallel...")
    
    # Convert company symbols to URLs
    company_urls = [f"https://www.screener.in/company/{company}/" for company in custom_companies]
    
    try:
        df_parallel = scraper.scrape_companies_parallel(
            company_urls=company_urls,
            max_companies=len(custom_companies)
        )
        
        if not df_parallel.empty:
            output_file_parallel = scraper.save_to_csv(df_parallel, "custom_companies_parallel_results.csv")
            print(f"✓ Parallel results saved to: {output_file_parallel}")
            
            # Show success rate
            successful = df_parallel[df_parallel['status'] == 'success']
            print(f"Successfully scraped: {len(successful)}/{len(custom_companies)} companies")
            
            # Show data availability
            pnl_available = successful[successful['has_pnl_data'] == True]
            quarterly_available = successful[successful['has_quarterly_data'] == True]
            balance_sheet_available = successful[successful['has_balance_sheet_data'] == True]
            print(f"Companies with P&L data: {len(pnl_available)}/{len(successful)}")
            print(f"Companies with quarterly data: {len(quarterly_available)}/{len(successful)}")
            print(f"Companies with Balance Sheet data: {len(balance_sheet_available)}/{len(successful)}")
        else:
            print("No data was scraped in parallel mode")
            
    except Exception as e:
        print(f"Error in parallel scraping: {str(e)}")

def scrape_specific_sectors():
    """Example: Scrape companies from specific sectors"""
    
    scraper = AdvancedScreenerScraper(max_workers=2)
    
    # Define companies by sector (using new company list)
    banking_companies = ['BANDHANBNK', 'UJJIVANSFB', 'AUBANK', 'RBLBANK', 'IDFCFIRSTB', 'YESBANK', 'J&KBANK', 'BANKINDIA', 'EQUITASBNK']
    it_companies = ['TATAELXSI', 'MTARTECH', 'AVANTEL', 'NETWORK18']
    energy_companies = ['MRPL', 'GNFC', 'GESHIP', 'GPPL']
    
    all_sectors = {
        'Banking': banking_companies,
        'IT': it_companies,
        'Energy': energy_companies
    }
    
    print("Scraping companies by sector...")
    print("=" * 50)
    
    for sector, companies in all_sectors.items():
        print(f"\nScraping {sector} sector ({len(companies)} companies)...")
        
        sector_metrics = []
        for company in companies:
            print(f"  Scraping {company}...")
            metrics = scraper.scrape_single_company(company)
            
            if metrics and metrics.get('status') == 'success':
                metrics['sector_group'] = sector  # Add sector grouping
                sector_metrics.append(metrics)
                print(f"    ✓ Success")
            else:
                print(f"    ✗ Failed")
        
        if sector_metrics:
            df_sector = pd.DataFrame(sector_metrics)
            output_file = scraper.save_to_csv(df_sector, f"{sector.lower()}_companies.csv")
            print(f"  ✓ {sector} results saved to: {output_file}")

if __name__ == "__main__":
    print("Custom Company List Scraper for Screener.in")
    print("=" * 50)
    
    # Run the main scraping function
    scrape_custom_companies()
    
    print("\n" + "="*50)
    print("Additional example: Scraping by sectors")
    print("="*50)
    
    # Uncomment the line below to run the sector-based scraping
    # scrape_specific_sectors()
    
    print("\nDone! Check the generated CSV files for results.") 