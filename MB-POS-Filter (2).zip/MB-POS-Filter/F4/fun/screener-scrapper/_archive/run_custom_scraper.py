#!/usr/bin/env python3
"""
Simple script to run AdvancedScreenerScraper with custom company list
Uses the configuration from custom_companies_config.py
"""

import pandas as pd
from advanced_screener_scraper import AdvancedScreenerScraper
from custom_companies_config import (
    get_custom_companies, 
    get_sector_companies, 
    get_scraper_config, 
    get_output_config
)

def main():
    """Main function to run the custom scraper"""
    
    # Get configuration
    companies = get_custom_companies()
    scraper_config = get_scraper_config()
    output_config = get_output_config()
    
    print("AdvancedScreenerScraper - Custom Company List")
    print("=" * 50)
    print(f"Companies to scrape: {len(companies)}")
    print(f"Companies: {', '.join(companies[:5])}{'...' if len(companies) > 5 else ''}")
    print(f"Scraper config: {scraper_config}")
    print("-" * 50)
    
    # Initialize scraper with custom configuration
    scraper = AdvancedScreenerScraper(**scraper_config)
    
    # Scrape companies
    print("Starting to scrape companies...")
    all_metrics = []
    
    for i, company in enumerate(companies, 1):
        print(f"[{i}/{len(companies)}] Scraping {company}...")
        
        try:
            metrics = scraper.scrape_single_company(company)
            
            if metrics and metrics.get('status') == 'success':
                all_metrics.append(metrics)
                company_name = metrics.get('company_name', company)
                current_price = metrics.get('current_price', 'N/A')
                pe_ratio = metrics.get('pe_ratio', 'N/A')
                print(f"  ✓ {company_name} - ₹{current_price}, P/E: {pe_ratio}")
            else:
                print(f"  ✗ Failed to scrape {company}")
                
        except Exception as e:
            print(f"  ✗ Error: {str(e)}")
    
    # Save results
    if all_metrics:
        df = pd.DataFrame(all_metrics)
        output_file = scraper.save_to_csv(df, output_config['output_filename'])
        print(f"\n✓ Results saved to: {output_file}")
        
        # Show summary
        successful = len(all_metrics)
        print(f"Successfully scraped: {successful}/{len(companies)} companies")
        
        if successful > 0:
            print("\nTop 5 companies by current price:")
            df_sorted = df.sort_values('current_price', ascending=False)
            for _, row in df_sorted.head().iterrows():
                name = row.get('company_name', 'Unknown')
                price = row.get('current_price', 'N/A')
                pe = row.get('pe_ratio', 'N/A')
                print(f"  {name}: ₹{price} (P/E: {pe})")
    else:
        print("No companies were successfully scraped")

def scrape_by_sectors():
    """Example: Scrape companies organized by sectors"""
    
    sector_companies = get_sector_companies()
    scraper_config = get_scraper_config()
    
    scraper = AdvancedScreenerScraper(**scraper_config)
    
    print("\nScraping companies by sector...")
    print("=" * 50)
    
    for sector, companies in sector_companies.items():
        print(f"\nScraping {sector} sector ({len(companies)} companies)...")
        
        sector_metrics = []
        for company in companies:
            print(f"  Scraping {company}...")
            metrics = scraper.scrape_single_company(company)
            
            if metrics and metrics.get('status') == 'success':
                metrics['sector_group'] = sector
                sector_metrics.append(metrics)
                print(f"    ✓ Success")
            else:
                print(f"    ✗ Failed")
        
        if sector_metrics:
            df_sector = pd.DataFrame(sector_metrics)
            output_file = scraper.save_to_csv(df_sector, f"{sector.lower()}_companies.csv")
            print(f"  ✓ {sector} results saved to: {output_file}")

if __name__ == "__main__":
    # Run the main scraper
    main()
    
    # Uncomment the line below to also run sector-based scraping
    # scrape_by_sectors()
    
    print("\nDone! Check the generated CSV files for results.") 