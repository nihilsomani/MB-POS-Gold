# Screener.in Financial Metrics Web Scraper

A comprehensive Python web scraper for extracting financial metrics from [screener.in](https://www.screener.in), a popular Indian stock market analysis platform.

## Features

- **Comprehensive Data Extraction**: Captures all major financial ratios and metrics
- **Advanced Financial Statements**: Extracts year-wise Profit & Loss (P&L) and Balance Sheet data
- **Quarterly Data**: Extracts quarterly financial results with growth metrics
- **Dual Scraper Options**: Basic scraper for simple use cases and advanced scraper with parallel processing
- **Robust Error Handling**: Retry logic, rate limiting, and graceful error recovery
- **Data Export**: Saves extracted data to CSV format with proper formatting
- **Respectful Scraping**: Built-in delays and rate limiting to be respectful to the server
- **Logging**: Comprehensive logging for debugging and monitoring
- **Unicode Support**: Proper handling of special characters and currency symbols

## Extracted Financial Metrics

The scraper extracts the following financial metrics for each company:

### Basic Metrics
- **Market Cap**: Company's market capitalization
- **Current Price**: Current stock price
- **High/Low**: 52-week high and low prices
- **Stock P/E**: Price-to-Earnings ratio
- **Book Value**: Book value per share
- **Dividend Yield**: Dividend yield percentage
- **ROCE**: Return on Capital Employed
- **ROE**: Return on Equity
- **Face Value**: Face value per share

### Advanced Metrics
- **EPS**: Earnings Per Share
- **Industry PE**: Industry average P/E ratio
- **3Yrs PE**: 3-year average P/E ratio
- **Free Cash Flow 3Yrs**: 3-year free cash flow
- **Price to Cash Flow**: Price to cash flow ratio
- **Price to Earning**: Price to earnings ratio
- **Price to Book Value**: Price to book value ratio
- **Intrinsic Value**: Calculated intrinsic value
- **OPM**: Operating Profit Margin
- **Enterprise Value**: Total enterprise value
- **PEG Ratio**: Price/Earnings to Growth ratio
- **Earning Power**: Earning power percentage
- **Net Block**: Net block value
- **Price to Sales**: Price to sales ratio
- **Interest Coverage**: Interest coverage ratio
- **Asset Turnover**: Asset turnover ratio

## Advanced Data Extraction

### Profit & Loss (P&L) Statements
The advanced scraper extracts year-wise P&L data including:
- **Revenue Metrics**: Sales, Total Revenue, Other Income
- **Expense Metrics**: Total Expenses, Cost of Materials, Employee Cost
- **Profit Metrics**: Net Profit, Operating Profit, EBITDA
- **Growth Metrics**: Compounded Sales Growth, Compounded Profit Growth
- **Per Share Metrics**: EPS, Book Value, Dividend Payout

### Balance Sheet Data
Year-wise Balance Sheet extraction includes:
- **Assets**: Total Assets, Current Assets, Non-Current Assets, Fixed Assets
- **Liabilities**: Total Liabilities, Current Liabilities, Non-Current Liabilities
- **Equity**: Shareholders' Equity, Retained Earnings, Reserves
- **Working Capital**: Current Assets, Current Liabilities, Net Working Capital
- **Debt Structure**: Total Debt, Short-term Debt, Long-term Debt
- **Cash & Investments**: Cash, Bank Balances, Investments

### Quarterly Results
Quarterly financial data with:
- **Revenue Trends**: Quarter-over-quarter revenue changes
- **Profit Trends**: Quarterly profit growth patterns
- **Growth Metrics**: Sales growth, profit growth, and other key ratios
- **Upcoming Results**: Information about upcoming quarterly results

### Output Structure
Advanced data is saved in separate directories:
```
output/
├── pnl_data/                    # Profit & Loss files
│   ├── RELIANCE_pnl.csv
│   ├── TCS_pnl.csv
│   └── pnl_summary.txt
├── balance_sheet_data/          # Balance Sheet files
│   ├── RELIANCE_balance_sheet.csv
│   ├── TCS_balance_sheet.csv
│   └── balance_sheet_summary.txt
└── quarterly_data/              # Quarterly data files
    ├── RELIANCE_quarterly.csv
    ├── TCS_quarterly.csv
    └── quarterly_summary.txt
```

## Installation

1. **Clone or download the project files**

2. **Install required dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Verify installation**:
   ```bash
   python -c "import requests, bs4, pandas; print('All dependencies installed successfully!')"
   ```

## Usage

### Basic Usage

```python
from screener_scraper import ScreenerScraper

# Initialize scraper
scraper = ScreenerScraper()

# Scrape a single company
metrics = scraper.scrape_single_company('RELIANCE')
print(metrics)

# Scrape multiple companies
df = scraper.scrape_companies(max_companies=10)
scraper.save_to_csv(df, "financial_metrics.csv")
```

### Advanced Usage with Parallel Processing

```python
from advanced_screener_scraper import AdvancedScreenerScraper

# Initialize advanced scraper
scraper = AdvancedScreenerScraper(
    max_workers=3,  # Number of parallel workers
    delay_range=(1, 2),  # Delay between requests (1-2 seconds)
    retry_attempts=3  # Number of retry attempts
)

# Scrape companies with parallel processing
df = scraper.scrape_companies_parallel(max_companies=50)
output_file = scraper.save_to_csv(df)
print(f"Data saved to: {output_file}")

# Check for advanced data availability
successful = df[df['status'] == 'success']
pnl_available = successful[successful['has_pnl_data'] == True]
balance_sheet_available = successful[successful['has_balance_sheet_data'] == True]
quarterly_available = successful[successful['has_quarterly_data'] == True]

print(f"Companies with P&L data: {len(pnl_available)}/{len(successful)}")
print(f"Companies with Balance Sheet data: {len(balance_sheet_available)}/{len(successful)}")
print(f"Companies with quarterly data: {len(quarterly_available)}/{len(successful)}")
```

### Advanced Data Access

```python
# Access P&L data for a specific company
metrics = scraper.scrape_single_company('RELIANCE')
if metrics.get('has_pnl_data'):
    pnl_data = metrics['pnl_data']
    print(f"P&L Years: {pnl_data['total_years']}")
    print(f"P&L Metrics: {pnl_data['total_metrics']}")

# Access Balance Sheet data
if metrics.get('has_balance_sheet_data'):
    balance_sheet_data = metrics['balance_sheet_data']
    print(f"Balance Sheet Years: {balance_sheet_data['total_years']}")
    print(f"Balance Sheet Metrics: {balance_sheet_data['total_metrics']}")
```

### Custom Company List

```python
# Define your own list of companies
companies = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'ICICIBANK']

all_metrics = []
for company in companies:
    metrics = scraper.scrape_single_company(company)
    if metrics:
        all_metrics.append(metrics)

df = pd.DataFrame(all_metrics)
scraper.save_to_csv(df, "custom_companies.csv")
```

## File Structure

```
├── screener_scraper.py           # Basic scraper implementation
├── advanced_screener_scraper.py  # Advanced scraper with parallel processing
├── example_usage.py              # Example usage scripts
├── requirements.txt              # Python dependencies
├── README.md                    # This file
└── output/                      # Output directory for CSV files
    ├── screener_financial_metrics_YYYYMMDD_HHMMSS.csv
    └── advanced_screener_metrics_YYYYMMDD_HHMMSS.csv
```

## Configuration Options

### Basic Scraper
- `base_url`: Base URL for screener.in (default: "https://www.screener.in")
- `delay_range`: Range of seconds to delay between requests (default: (1, 3))

### Advanced Scraper
- `max_workers`: Number of parallel workers (default: 3)
- `timeout`: Request timeout in seconds (default: 30)
- `retry_attempts`: Number of retry attempts for failed requests (default: 3)

## Output Format

The scraper generates CSV files with the following columns:

### Standard Columns
- `company_name`: Company name
- `sector`: Business sector
- `company_url`: Source URL
- `scraped_at`: Timestamp of scraping
- `status`: Success/failure status
- `has_pnl_data`: Whether P&L data was extracted
- `has_balance_sheet_data`: Whether Balance Sheet data was extracted
- `has_quarterly_data`: Whether quarterly data was extracted

### Financial Metrics
- `current_price`: Current stock price
- `market_cap`: Market capitalization
- `pe_ratio`: Price-to-Earnings ratio
- `book_value`: Book value per share
- `eps`: Earnings per share
- `roe`: Return on Equity
- `roce`: Return on Capital Employed
- `dividend_yield`: Dividend yield
- `high_price`: 52-week high
- `low_price`: 52-week low
- And many more...

## Error Handling

The scraper includes comprehensive error handling:

- **Network Errors**: Automatic retry with exponential backoff
- **Rate Limiting**: Built-in delays to respect server limits
- **Invalid Data**: Graceful handling of missing or malformed data
- **Logging**: Detailed logs for debugging

## Best Practices

1. **Respect Rate Limits**: Use appropriate delays between requests
2. **Start Small**: Test with a few companies before large-scale scraping
3. **Monitor Logs**: Check log files for any issues
4. **Validate Data**: Always verify the extracted data quality
5. **Legal Compliance**: Ensure compliance with website terms of service

## Example Output

```csv
company_name,sector,current_price,market_cap,pe_ratio,roe,roce,eps
Reliance Industries,Oil & Gas,2456.75,1654321.50,18.45,12.34,15.67,133.25
TCS,IT,3456.80,1234567.90,25.67,28.90,32.45,134.56
HDFC Bank,Banking,1567.45,987654.32,22.34,16.78,18.90,70.23
```

## Testing Advanced Features

### Test P&L Extraction
```bash
python test_pnl_extraction.py
```

### Test Balance Sheet Extraction
```bash
python test_balance_sheet_extraction.py
```

### Demo Scripts
```bash
# P&L demo
python demo_pnl_extraction.py

# Balance Sheet demo
python demo_balance_sheet_extraction.py
```

### Verification Script
```bash
python verify_balance_sheet.py
```

## Troubleshooting

### Common Issues

1. **Import Errors**: Make sure all dependencies are installed
   ```bash
   pip install -r requirements.txt
   ```

2. **Network Timeouts**: Increase timeout value or check internet connection
   ```python
   scraper = AdvancedScreenerScraper(timeout=60)
   ```

3. **Rate Limiting**: Increase delays between requests
   ```python
   scraper = ScreenerScraper(delay_range=(2, 5))
   ```

4. **No Data Extracted**: Check if the website structure has changed
   - Review log files for errors
   - Verify company symbols are correct

### Log Files

The scraper creates detailed log files:
- `screener_scraper.log`: Basic scraper logs
- `advanced_screener_scraper.log`: Advanced scraper logs

## Legal and Ethical Considerations

- **Terms of Service**: Always review and comply with screener.in's terms of service
- **Rate Limiting**: Use appropriate delays to avoid overwhelming the server
- **Data Usage**: Use extracted data responsibly and in accordance with applicable laws
- **Attribution**: Consider providing attribution when using scraped data

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is for educational and research purposes. Please ensure compliance with screener.in's terms of service and applicable laws when using this scraper.

## Disclaimer

This scraper is provided as-is without any warranties. Users are responsible for ensuring compliance with website terms of service and applicable laws. The authors are not responsible for any misuse of this tool.

## Support

For issues and questions:
1. Check the log files for error details
2. Review the troubleshooting section
3. Ensure all dependencies are properly installed
4. Verify internet connectivity and website accessibility

---

**Note**: This scraper is designed to be respectful to the screener.in servers. Please use it responsibly and in accordance with the website's terms of service. 