#!/usr/bin/env python3
"""
Document Analyzer - Intelligent PDF Analysis
=============================================

Reads concalls and annual reports, extracts meaningful insights,
and generates qualitative scores based on actual content analysis.

Features:
- PDF text extraction
- Management quality assessment
- Growth trajectory analysis
- Risk identification
- Competitive moat evaluation
- Financial discipline scoring

Author: Intelligent Document Analyzer
Date: 2025-10-16
"""

import os
import re
import pandas as pd
from pathlib import Path
from typing import Dict, List, Optional
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)


class DocumentAnalyzer:
    """Intelligent analyzer for concalls and annual reports"""
    
    def __init__(self, downloads_dir: str = "downloads"):
        self.downloads_dir = downloads_dir
        self.concalls_dir = os.path.join(downloads_dir, "concalls")
        self.reports_dir = os.path.join(downloads_dir, "annual_reports")
        
    def extract_pdf_text(self, pdf_path: str) -> str:
        """Extract text from PDF"""
        try:
            import PyPDF2
            text = ""
            with open(pdf_path, 'rb') as file:
                reader = PyPDF2.PdfReader(file)
                # Extract from all pages
                for page in reader.pages:
                    text += page.extract_text() + "\n"
            return text
        except Exception as e:
            logger.error(f"Error extracting text from {pdf_path}: {e}")
            return ""
    
    def analyze_management_quality(self, text: str) -> Dict[str, any]:
        """Analyze management communication quality"""
        score = 0
        max_score = 100
        insights = []
        
        text_lower = text.lower()
        
        # 1. Transparency (25 points)
        transparency_keywords = {
            'positive': ['transparent', 'disclosed', 'acknowledged', 'admitted', 'challenge', 'headwind', 'difficult'],
            'negative': ['cannot disclose', 'competitive reasons', 'proprietary']
        }
        
        transparency_positives = sum(text_lower.count(k) for k in transparency_keywords['positive'])
        transparency_negatives = sum(text_lower.count(k) for k in transparency_keywords['negative'])
        
        if transparency_positives > 5:
            score += 25
            insights.append("✅ High transparency - acknowledges challenges")
        elif transparency_positives > 2:
            score += 15
        
        if transparency_negatives > 3:
            score -= 10
            insights.append("⚠️ Limited disclosure")
        
        # 2. Strategic Clarity (25 points)
        strategy_keywords = ['vision', 'strategy', 'plan', 'roadmap', 'target', 'guidance', 'focus']
        strategy_mentions = sum(text_lower.count(k) for k in strategy_keywords)
        
        if strategy_mentions > 15:
            score += 25
            insights.append("✅ Clear strategic vision")
        elif strategy_mentions > 8:
            score += 15
        elif strategy_mentions > 3:
            score += 5
        
        # 3. Execution Track Record (25 points)
        execution_keywords = {
            'positive': ['achieved', 'delivered', 'completed', 'commissioned', 'launched', 'exceeded'],
            'negative': ['delayed', 'postponed', 'missed', 'below expectation']
        }
        
        execution_positives = sum(text_lower.count(k) for k in execution_keywords['positive'])
        execution_negatives = sum(text_lower.count(k) for k in execution_keywords['negative'])
        
        if execution_positives > 8:
            score += 25
            insights.append("✅ Strong execution track record")
        elif execution_positives > 4:
            score += 15
        
        if execution_negatives > 2:
            score -= 10
            insights.append("⚠️ Execution delays mentioned")
        
        # 4. Financial Discipline (25 points)
        discipline_keywords = ['debt free', 'roce', 'capital allocation', 'dividend', 'cash flow', 'working capital']
        discipline_mentions = sum(text_lower.count(k) for k in discipline_keywords)
        
        if discipline_mentions > 10:
            score += 25
            insights.append("✅ Strong financial discipline focus")
        elif discipline_mentions > 5:
            score += 15
        elif discipline_mentions > 2:
            score += 5
        
        return {
            'score': max(0, min(max_score, score)),
            'insights': insights
        }
    
    def analyze_growth_trajectory(self, text: str) -> Dict[str, any]:
        """Analyze growth prospects and momentum"""
        score = 0
        max_score = 100
        insights = []
        
        text_lower = text.lower()
        
        # 1. Revenue Growth (30 points)
        growth_indicators = {
            'strong': ['strong growth', 'robust growth', 'excellent growth', 'growth momentum'],
            'moderate': ['steady growth', 'growth', 'increased revenue', 'revenue growth'],
            'weak': ['flat', 'stagnant', 'declined', 'decreased']
        }
        
        strong_mentions = sum(text_lower.count(k) for k in growth_indicators['strong'])
        moderate_mentions = sum(text_lower.count(k) for k in growth_indicators['moderate'])
        weak_mentions = sum(text_lower.count(k) for k in growth_indicators['weak'])
        
        if strong_mentions > 3:
            score += 30
            insights.append("✅ Strong growth trajectory")
        elif moderate_mentions > 5:
            score += 20
        
        if weak_mentions > 3:
            score -= 15
            insights.append("⚠️ Growth challenges mentioned")
        
        # 2. Expansion & Capex (30 points)
        expansion_keywords = ['expansion', 'new plant', 'capacity addition', 'greenfield', 'brownfield', 'capex']
        expansion_mentions = sum(text_lower.count(k) for k in expansion_keywords)
        
        if expansion_mentions > 8:
            score += 30
            insights.append("✅ Aggressive expansion underway")
        elif expansion_mentions > 4:
            score += 20
        elif expansion_mentions > 1:
            score += 10
        
        # 3. Market Share & Competitive Position (20 points)
        competitive_keywords = ['market leader', 'market share', 'number one', '#1', 'dominant', 'competitive advantage']
        competitive_mentions = sum(text_lower.count(k) for k in competitive_keywords)
        
        if competitive_mentions > 3:
            score += 20
            insights.append("✅ Strong competitive position")
        elif competitive_mentions > 1:
            score += 10
        
        # 4. New Products/Services (20 points)
        innovation_keywords = ['new product', 'innovation', 'r&d', 'research', 'development', 'launched']
        innovation_mentions = sum(text_lower.count(k) for k in innovation_keywords)
        
        if innovation_mentions > 5:
            score += 20
            insights.append("✅ Active innovation pipeline")
        elif innovation_mentions > 2:
            score += 10
        
        return {
            'score': max(0, min(max_score, score)),
            'insights': insights
        }
    
    def analyze_risks(self, text: str) -> Dict[str, any]:
        """Identify and assess risks"""
        score = 100  # Start high, deduct for serious risks
        risks_found = []
        
        text_lower = text.lower()
        
        # Major risk indicators
        major_risks = {
            'debt': ['high debt', 'debt burden', 'leverage concern'],
            'regulatory': ['regulatory risk', 'compliance issue', 'legal proceeding'],
            'competition': ['intense competition', 'pricing pressure', 'market share loss'],
            'demand': ['weak demand', 'demand slowdown', 'volume decline'],
            'margins': ['margin pressure', 'margin compression', 'cost inflation']
        }
        
        for risk_type, keywords in major_risks.items():
            mentions = sum(text_lower.count(k) for k in keywords)
            if mentions > 0:
                score -= 10 * min(mentions, 3)  # Max -30 per risk type
                risks_found.append(f"⚠️ {risk_type.title()} concerns mentioned ({mentions}x)")
        
        # Positive risk management
        risk_mgmt_keywords = ['mitigate', 'hedging', 'diversification', 'risk management']
        mgmt_mentions = sum(text_lower.count(k) for k in risk_mgmt_keywords)
        
        if mgmt_mentions > 3:
            score += 10
            risks_found.append("✅ Active risk mitigation")
        
        return {
            'score': max(0, min(100, score)),
            'risks': risks_found
        }
    
    def analyze_financial_claims(self, text: str) -> Dict[str, any]:
        """Extract and score financial claims"""
        score = 50  # Neutral baseline
        claims = []
        
        text_lower = text.lower()
        
        # Positive financial indicators
        positive_indicators = {
            'margin improvement': r'margin\s+(?:improved|expansion|up)',
            'revenue growth': r'revenue\s+(?:growth|increased|up)\s+(\d+)',
            'profitability': r'(?:roe|roce|roa)\s+(?:improved|increased)',
            'debt reduction': r'debt\s+(?:free|reduced|declined)',
            'cash generation': r'cash\s+flow\s+(?:strong|improved|positive)'
        }
        
        for indicator, pattern in positive_indicators.items():
            matches = re.findall(pattern, text_lower)
            if matches:
                score += 10
                claims.append(f"✅ {indicator.title()} mentioned")
        
        # Extract specific numbers
        revenue_growth = re.findall(r'revenue\s+(?:growth|up|increased)\s+(?:by\s+)?(\d+)%', text_lower)
        if revenue_growth:
            growth = int(revenue_growth[0])
            if growth > 20:
                score += 15
                claims.append(f"🚀 High revenue growth: {growth}%")
            elif growth > 10:
                score += 10
        
        margin_data = re.findall(r'(?:ebitda|operating)\s+margin\s+(?:of\s+)?(\d+)', text_lower)
        if margin_data:
            margin = int(margin_data[0])
            if margin > 20:
                score += 10
                claims.append(f"✅ Strong margins: {margin}%")
        
        return {
            'score': max(0, min(100, score)),
            'claims': claims
        }
    
    def calculate_document_score(self, text: str) -> Dict[str, any]:
        """Calculate comprehensive qualitative score from document"""
        
        if not text or len(text) < 100:
            return {
                'total_score': 50,
                'management_quality': 50,
                'growth_trajectory': 50,
                'risk_assessment': 50,
                'financial_claims': 50,
                'insights': ['⚠️ Insufficient text extracted'],
                'word_count': len(text.split()) if text else 0
            }
        
        # Run all analyses
        mgmt = self.analyze_management_quality(text)
        growth = self.analyze_growth_trajectory(text)
        risks = self.analyze_risks(text)
        claims = self.analyze_financial_claims(text)
        
        # Weighted score
        total_score = (
            mgmt['score'] * 0.30 +      # 30% weight
            growth['score'] * 0.30 +     # 30% weight
            risks['score'] * 0.25 +      # 25% weight
            claims['score'] * 0.15       # 15% weight
        )
        
        # Combine insights
        all_insights = (
            mgmt.get('insights', []) + 
            growth.get('insights', []) + 
            risks.get('risks', []) + 
            claims.get('claims', [])
        )
        
        return {
            'total_score': round(total_score, 2),
            'management_quality': mgmt['score'],
            'growth_trajectory': growth['score'],
            'risk_assessment': risks['score'],
            'financial_claims': claims['score'],
            'insights': all_insights,
            'word_count': len(text.split())
        }
    
    def analyze_company_documents(self, company_symbol: str) -> Dict[str, any]:
        """Analyze all available documents for a company"""
        
        logger.info(f"\n{'=' * 70}")
        logger.info(f"Analyzing: {company_symbol}")
        logger.info(f"{'=' * 70}")
        
        result = {
            'company': company_symbol,
            'concall_score': 50,
            'report_score': 50,
            'combined_score': 50,
            'concall_analyzed': False,
            'report_analyzed': False,
            'insights': []
        }
        
        # Analyze concall
        concall_path = os.path.join(self.concalls_dir, f"{company_symbol}_Concall.pdf")
        if os.path.exists(concall_path):
            logger.info(f"   📄 Reading concall: {concall_path}")
            concall_text = self.extract_pdf_text(concall_path)
            
            if concall_text:
                concall_analysis = self.calculate_document_score(concall_text)
                result['concall_score'] = concall_analysis['total_score']
                result['concall_analyzed'] = True
                result['concall_insights'] = concall_analysis['insights']
                result['concall_word_count'] = concall_analysis['word_count']
                
                logger.info(f"   ✅ Concall analyzed: {concall_analysis['word_count']} words")
                logger.info(f"      Score: {concall_analysis['total_score']:.1f}/100")
        
        # Analyze annual report
        report_files = list(Path(self.reports_dir).glob(f"{company_symbol}_*.pdf"))
        if report_files:
            report_path = report_files[0]
            logger.info(f"   📄 Reading annual report: {report_path}")
            report_text = self.extract_pdf_text(str(report_path))
            
            if report_text:
                report_analysis = self.calculate_document_score(report_text)
                result['report_score'] = report_analysis['total_score']
                result['report_analyzed'] = True
                result['report_insights'] = report_analysis['insights']
                result['report_word_count'] = report_analysis['word_count']
                
                logger.info(f"   ✅ Report analyzed: {report_analysis['word_count']} words")
                logger.info(f"      Score: {report_analysis['total_score']:.1f}/100")
        
        # Calculate combined qualitative score
        if result['concall_analyzed'] and result['report_analyzed']:
            # Both available - weighted average (concall 60%, report 40%)
            result['combined_score'] = (result['concall_score'] * 0.6 + 
                                       result['report_score'] * 0.4)
        elif result['concall_analyzed']:
            # Only concall
            result['combined_score'] = result['concall_score']
        elif result['report_analyzed']:
            # Only report
            result['combined_score'] = result['report_score']
        else:
            # No documents
            result['combined_score'] = 50
        
        logger.info(f"   🎯 Combined Qualitative Score: {result['combined_score']:.1f}/100")
        
        return result
    
    def analyze_all_with_financial_data(self, financial_csv: str, top_n: int = 50):
        """
        Analyze companies combining financial scores with document analysis
        
        Args:
            financial_csv: Path to financial scan CSV
            top_n: Number of top companies to analyze (default: 50)
        """
        
        logger.info("=" * 70)
        logger.info("INTELLIGENT DOCUMENT ANALYSIS")
        logger.info("=" * 70)
        
        # Load financial data
        df_financial = pd.read_csv(financial_csv)
        logger.info(f"\n✅ Loaded financial data: {len(df_financial)} companies")
        
        # Get top N companies
        top_companies = df_financial.nsmallest(top_n, 'Rank')
        logger.info(f"   Analyzing top {top_n} companies...")
        
        # Find which have documents
        concalls_available = [f.stem.replace('_Concall', '') for f in Path(self.concalls_dir).glob("*.pdf")]
        reports_available = [f.stem.split('_')[0] for f in Path(self.reports_dir).glob("*.pdf")]
        
        top_with_docs = top_companies[
            top_companies['Company'].isin(concalls_available) | 
            top_companies['Company'].isin(reports_available)
        ]
        
        logger.info(f"   Companies in top {top_n} with documents: {len(top_with_docs)}")
        
        # Analyze each
        results = []
        
        for i, (_, company_row) in enumerate(top_with_docs.iterrows(), 1):
            company = company_row['Company']
            
            logger.info(f"\n[{i}/{len(top_with_docs)}] {company}")
            
            # Document analysis
            doc_analysis = self.analyze_company_documents(company)
            
            # Combine with financial data
            quant_score = company_row['Composite_Score']
            qual_score = doc_analysis['combined_score']
            
            # Integrated score (60% quant, 40% qual)
            integrated_score = (quant_score * 0.6) + (qual_score * 0.4)
            
            result = {
                'Company': company,
                'Original_Rank': company_row['Rank'],
                'Quantitative_Score': quant_score,
                'Qualitative_Score': qual_score,
                'Integrated_Score': round(integrated_score, 2),
                
                # Detailed scores
                'Concall_Score': doc_analysis['concall_score'],
                'Report_Score': doc_analysis['report_score'],
                'Concall_Analyzed': doc_analysis['concall_analyzed'],
                'Report_Analyzed': doc_analysis['report_analyzed'],
                
                # Financial metrics
                'OPM_%': company_row['OPM_%'],
                'ROE_%': company_row['ROE_%'],
                'Sales_CAGR_5Y_%': company_row['Sales_CAGR_5Y_%'],
                'Debt_Equity': company_row['Debt_Equity'],
                'Red_Flag_Count': company_row['Red_Flag_Count'],
                
                # Category scores
                'Balance_Sheet_Score': company_row['Balance_Sheet_Score'],
                'Operational_Score': company_row['Operational_Score'],
                'Growth_Score': company_row['Growth_Score'],
                'Cash_Flow_Score': company_row['Cash_Flow_Score'],
                
                # Insights
                'Key_Insights': ' | '.join(doc_analysis.get('concall_insights', [])[:3])
            }
            
            results.append(result)
            
            logger.info(f"   📊 Quantitative: {quant_score:.2f}")
            logger.info(f"   📄 Qualitative: {qual_score:.2f}")
            logger.info(f"   🎯 Integrated: {integrated_score:.2f}")
        
        # Create DataFrame and sort by integrated score
        df_results = pd.DataFrame(results)
        df_results = df_results.sort_values('Integrated_Score', ascending=False)
        df_results['Final_Rank'] = range(1, len(df_results) + 1)
        
        # Save results
        timestamp = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
        output_file = f"intelligent_analysis_{timestamp}.csv"
        df_results.to_csv(output_file, index=False, encoding='utf-8-sig')
        
        logger.info(f"\n{'=' * 70}")
        logger.info(f"✅ Analysis complete!")
        logger.info(f"   Companies analyzed: {len(df_results)}")
        logger.info(f"   Output file: {output_file}")
        logger.info(f"{'=' * 70}")
        
        return df_results


def main():
    """Main function"""
    
    print("\n" + "🤖 " * 30)
    print("\nINTELLIGENT DOCUMENT ANALYZER")
    print("Reads PDFs, understands content, generates qualitative scores")
    print("\n" + "🤖 " * 30)
    
    # Initialize analyzer
    analyzer = DocumentAnalyzer(downloads_dir="downloads")
    
    # Find financial scan file
    import glob
    financial_files = glob.glob("output/financial_scan_*.csv")
    
    if not financial_files:
        print("\n❌ Financial scan file not found")
        print("   Run: python MB-POS-Filter/F4/fun/financial_scanner.py")
        return
    
    financial_csv = financial_files[0]
    print(f"\n✅ Using financial data: {financial_csv}")
    
    # Check documents
    concalls_count = len(list(Path("downloads/concalls").glob("*.pdf"))) if os.path.exists("downloads/concalls") else 0
    reports_count = len(list(Path("downloads/annual_reports").glob("*.pdf"))) if os.path.exists("downloads/annual_reports") else 0
    
    print(f"✅ Found {concalls_count} concalls, {reports_count} annual reports")
    
    if concalls_count == 0 and reports_count == 0:
        print("\n❌ No documents found in downloads/")
        print("   Make sure documents are downloaded first")
        return
    
    print("\n" + "=" * 70)
    print("Starting analysis of top 50 companies with available documents...")
    print("This will take 2-3 minutes depending on document count")
    print("=" * 70)
    
    input("\nPress Enter to start...")
    
    # Run analysis
    df = analyzer.analyze_all_with_financial_data(financial_csv, top_n=50)
    
    # Display top 10
    print("\n" + "=" * 70)
    print("🏆 TOP 10 BY INTEGRATED SCORE (Quant + Qual)")
    print("=" * 70)
    
    for idx, (_, row) in enumerate(df.head(10).iterrows(), 1):
        print(f"\n{idx}. {row['Company']}")
        print(f"   Integrated Score: {row['Integrated_Score']:.2f}/100")
        print(f"   └─ Quantitative: {row['Quantitative_Score']:.2f} (Financial metrics)")
        print(f"   └─ Qualitative: {row['Qualitative_Score']:.2f} (Document analysis)")
        print(f"   Original Rank: #{row['Original_Rank']} → New Rank: #{row['Final_Rank']}")
        
        if row['Concall_Analyzed']:
            print(f"   ✅ Concall analyzed (Score: {row['Concall_Score']:.1f})")
        if row['Report_Analyzed']:
            print(f"   ✅ Report analyzed (Score: {row['Report_Score']:.1f})")
        
        if row['Key_Insights']:
            print(f"   💡 {row['Key_Insights'][:80]}...")
    
    print("\n" + "=" * 70)
    print(f"📁 Full results saved to: intelligent_analysis_*.csv")
    print("=" * 70)
    
    print("\n💡 Next Steps:")
    print("   1. Open the CSV in Excel")
    print("   2. Sort by 'Integrated_Score'")
    print("   3. Focus on companies with both docs analyzed")
    print("   4. Read the PDFs for top 3-5 companies")
    print("   5. Make investment decisions!")


if __name__ == "__main__":
    main()

