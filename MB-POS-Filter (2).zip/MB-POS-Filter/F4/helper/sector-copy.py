"""
Data Merger Utility
===================

Merges scraped sector/market cap data with your existing stock lists.

This utility works with output from:
- sector-marketcap-scraper.py (unified scraper)
- Legacy sector scraper outputs

Features:
- Flexible column matching (handles 'Symbol' vs 'symbol')
- Handles different sector column formats (Sector_Level_X vs Level_X)
- Preserves all columns from both files
- Case-insensitive symbol matching

Usage:
    python sector-copy.py

Author: Market Analysis Framework
Version: 1.0.0
"""

import pandas as pd
import os
from datetime import datetime

# ============================================================================
# CONFIGURATION
# ============================================================================

# Input Files
STOCK_LIST_FILE = "../../../data/Nifty50stocks.csv"           # Your main stock list
SCRAPED_DATA_FILE = "./output/sector_marketcap_latest.csv"    # Output from sector-marketcap-scraper.py

# Output File
OUTPUT_FILE = "./output/enriched_stocks.csv"

# ============================================================================
# MAIN FUNCTION
# ============================================================================

def find_symbol_column(df, file_name):
    """Find the symbol column (case-insensitive)."""
    for col in df.columns:
        if col.strip().lower() == 'symbol':
            return col
    
    print(f"❌ 'Symbol' column not found in {file_name}")
    print(f"Available columns: {df.columns.tolist()}")
    raise ValueError("Symbol column not found")

def normalize_columns(df):
    """Normalize column names for consistency."""
    # Create a mapping for common variations
    column_mapping = {}
    
    for col in df.columns:
        # Normalize symbol column
        if col.strip().lower() == 'symbol':
            column_mapping[col] = 'Symbol'
        # Keep other columns as-is
        else:
            column_mapping[col] = col
    
    return df.rename(columns=column_mapping)

def main():
    """Main merger function."""
    
    print("\n" + "="*60)
    print("🔗 DATA MERGER UTILITY")
    print("="*60 + "\n")
    
    # Check if files exist
    if not os.path.exists(STOCK_LIST_FILE):
        print(f"❌ Stock list file not found: {STOCK_LIST_FILE}")
        return
    
    if not os.path.exists(SCRAPED_DATA_FILE):
        print(f"❌ Scraped data file not found: {SCRAPED_DATA_FILE}")
        print(f"💡 Tip: Run sector-marketcap-scraper.py first, then rename the output to 'sector_marketcap_latest.csv'")
        return
    
    try:
        # Load files
        print(f"📥 Loading stock list: {STOCK_LIST_FILE}")
        df_stocks = pd.read_csv(STOCK_LIST_FILE)
        print(f"   ✓ Loaded {len(df_stocks)} stocks")
        
        print(f"📥 Loading scraped data: {SCRAPED_DATA_FILE}")
        df_scraped = pd.read_csv(SCRAPED_DATA_FILE)
        print(f"   ✓ Loaded {len(df_scraped)} records")
        
        # Normalize column names
        df_stocks = normalize_columns(df_stocks)
        df_scraped = normalize_columns(df_scraped)
        
        # Ensure Symbol columns exist
        if 'Symbol' not in df_stocks.columns:
            find_symbol_column(df_stocks, STOCK_LIST_FILE)
        if 'Symbol' not in df_scraped.columns:
            find_symbol_column(df_scraped, SCRAPED_DATA_FILE)
        
        # Merge data
        print(f"\n🔗 Merging data...")
        merged = pd.merge(
            df_stocks, 
            df_scraped, 
            on='Symbol', 
            how='left',
            suffixes=('', '_scraped')
        )
        
        print(f"   ✓ Merged successfully")
        
        # Check merge results
        matched = merged['Market_Cap_Crores'].notna().sum() if 'Market_Cap_Crores' in merged.columns else 0
        print(f"\n📊 Merge Statistics:")
        print(f"   Total stocks in list: {len(df_stocks)}")
        print(f"   Matched with scraped data: {matched}")
        print(f"   Unmatched: {len(df_stocks) - matched}")
        
        # Save merged file
        os.makedirs(os.path.dirname(OUTPUT_FILE) if os.path.dirname(OUTPUT_FILE) else '.', exist_ok=True)
        merged.to_csv(OUTPUT_FILE, index=False)
        
        print(f"\n✅ Merged data saved to: {OUTPUT_FILE}")
        print(f"📊 Total columns: {len(merged.columns)}")
        print(f"📊 Total rows: {len(merged)}")
        
        # Display sample
        print("\n📋 Sample of merged data (first 5 rows):")
        print(merged.head().to_string(index=False))
        
        # Display column summary
        print(f"\n📋 Available columns:")
        for i, col in enumerate(merged.columns, 1):
            print(f"   {i}. {col}")
        
        print("\n✨ Done!")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
